// SPDX-License-Identifier: GPL-3.0-or-later
import { defineConfig } from 'vitest/config';

export default defineConfig( {
	test: {
		environment: 'jsdom',
		globals: true,
		setupFiles: [ './src/test-setup.ts' ],
		coverage: {
			provider: 'v8',
			reporter: [ 'text', 'html' ],
		},
	},
} );
