<?php
/**
 * General Settings Section
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Section_General' ) ) {
	/**
	 * General settings section.
	 */
	class WP_MCP_AI_Section_General extends WP_MCP_AI_Settings_Section {
		/**
		 * Get section ID.
		 *
		 * @return string
		 */
		public function get_id() {
			return 'general';
		}

		/**
		 * Get section title.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'General Settings', 'mcp-ai-wpoos' );
		}

		/**
		 * Get tab ID.
		 *
		 * @return string
		 */
		public function get_tab() {
			return 'general';
		}

		/**
		 * Get section priority.
		 *
		 * @return int
		 */
		public function get_priority() {
			return 10;
		}

		/**
		 * Get section description.
		 *
		 * @return string
		 */
		public function get_description() {
			return __( 'Configure basic plugin settings and operational parameters.', 'mcp-ai-wpoos' );
		}

		/**
		 * Get documentation URL for this section.
		 *
		 * @return string
		 */
		public function get_documentation_url() {
			return 'https://github.com/nvdigitalsolutions/mcp-ai-wpoos/blob/main/docs/getting-started/QUICK_START_5_MINUTES.md';
		}

		/**
		 * Get field definitions.
		 *
		 * @return array
		 */
		public function get_fields() {
			// Get available providers for dropdown using dynamic filtering.
			// This ensures only enabled+configured providers appear in the dropdown.
			$provider_options = WP_MCP_AI_Admin_Settings::get_available_providers();

			// Fallback to static list if get_available_providers returns empty.
			if ( empty( $provider_options ) ) {
				$provider_options = array(
					'openai'      => __( 'OpenAI', 'mcp-ai-wpoos' ),
					'gemini'      => __( 'Google Gemini', 'mcp-ai-wpoos' ),
					'ollama'      => __( 'Ollama (Local AI)', 'mcp-ai-wpoos' ),
					'lm_studio'   => __( 'LM Studio (Local AI)', 'mcp-ai-wpoos' ),
					'huggingface' => __( 'Hugging Face', 'mcp-ai-wpoos' ),
					'cloudflare'  => __( 'Cloudflare Worker AI', 'mcp-ai-wpoos' ),
					'embedded'    => __( 'Embedded LLM', 'mcp-ai-wpoos' ),
				);
			}

			// Get available assistants for dropdown.
			$assistant_options = $this->get_assistant_options();

			return array(
				'default_provider'                      => array(
					'type'        => 'select',
					'label'       => __( 'Default AI Provider', 'mcp-ai-wpoos' ),
					'description' => __( 'The primary AI provider used when no specific provider is specified. This affects new conversations and REST API requests. Make sure the selected provider is properly configured in the Providers tab.', 'mcp-ai-wpoos' ),
					'options'     => $provider_options,
					'default'     => 'openai',
				),
				'default_assistant'                     => array(
					'type'        => 'select',
					'label'       => __( 'Default Assistant', 'mcp-ai-wpoos' ),
					'description' => __( 'The assistant used by default when one is not explicitly specified in REST API interactions. Leave as "None" to require explicit assistant selection.', 'mcp-ai-wpoos' ),
					'options'     => $assistant_options,
					'default'     => 0,
				),
				'enable_logging'                        => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Logging', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Enable basic error and activity logging', 'mcp-ai-wpoos' ),
					'description'    => __( 'Records errors, warnings, and key activity (tool executions, API requests) to help troubleshoot issues. View logs in the Advanced tab.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_extended_logging'               => array(
					'type'           => 'checkbox',
					'label'          => __( 'Extended Logging', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Retain more context per log entry', 'mcp-ai-wpoos' ),
					'description'    => __( 'Raises the amount of context kept with each stored log entry, so larger request/response payloads and execution traces survive into the log views. Entries are still size-capped to protect the database, and assistant system prompts are always replaced with a length and hash fingerprint. Warning: this increases log size and may impact site performance. Only enable for short-term debugging.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_agentic_loop_logging'           => array(
					'type'           => 'checkbox',
					'label'          => __( 'Agentic Loop Logging', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Enable detailed logging for agentic loop iterations and tool calls', 'mcp-ai-wpoos' ),
					'description'    => __( 'Logs each iteration of the agentic loop, including tool calls, tool results, and iteration timing. Useful for debugging assistant behavior and tool execution flow.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_api_logging'                    => array(
					'type'           => 'checkbox',
					'label'          => __( 'API Request/Response Logging', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Enable logging for AI provider API requests and responses', 'mcp-ai-wpoos' ),
					'description'    => __( 'Logs API requests to OpenAI, Anthropic, Gemini, LM Studio and their responses. Helps debug API connectivity and response issues.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_tool_execution_logging'         => array(
					'type'           => 'checkbox',
					'label'          => __( 'Tool Execution Logging', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Enable detailed logging for individual tool executions', 'mcp-ai-wpoos' ),
					'description'    => __( 'Logs each tool execution with arguments and results. Useful for debugging tool behavior and data flow.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_chat_interaction_logging'       => array(
					'type'           => 'checkbox',
					'label'          => __( 'Chat Interaction Logging', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Enable logging for chat requests and responses', 'mcp-ai-wpoos' ),
					'description'    => __( 'Logs complete chat interactions including user messages and assistant responses. Helps track conversation flow and debugging message handling.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_debug_logging'                  => array(
					'type'           => 'checkbox',
					'label'          => __( 'Debug Logging', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Enable debug-level diagnostic messages', 'mcp-ai-wpoos' ),
					'description'    => __( 'Writes debug-level events (high-frequency diagnostics such as skipped registrations) to the PHP error log. Very noisy — only enable for short-term debugging.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'delete_on_uninstall'                   => array(
					'type'           => 'checkbox',
					'label'          => __( 'Delete Data on Uninstall', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Remove all plugin data when uninstalling', 'mcp-ai-wpoos' ),
					'description'    => __( 'When enabled, all settings and data will be deleted when the plugin is uninstalled.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_activation_tracking'            => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Activation Tracking', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Allow anonymous activation tracking (opt-in)', 'mcp-ai-wpoos' ),
					'description'    => sprintf(
						/* translators: %s: Link to external services documentation */
						__( 'When enabled, the plugin sends anonymous activation/deactivation events to NV Digital to help improve the product. Tracking is disabled by default — this requires your explicit consent. Only minimal, non-identifying data is collected: plugin version, WordPress version, PHP version, and a hashed site ID. No personal information or IP addresses are collected. %s', 'mcp-ai-wpoos' ),
						'<a href="https://github.com/nvdigitalsolutions/mcp-ai-wpoos/blob/main/docs/EXTERNAL_SERVICES.md#plugin-analytics-service" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Learn more about what data is collected', 'mcp-ai-wpoos' ) . '</a>'
					),
					'default'        => false,
				),
				'max_history_messages'                  => array(
					'type'        => 'number',
					'label'       => __( 'Max History Messages', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum number of previous messages to include in chat context. Higher values provide more context but increase token usage.', 'mcp-ai-wpoos' ),
					'default'     => 8,
					'placeholder' => '8',
					'min'         => 1,
					'max'         => 100,
				),
				'context_strategy'                      => array(
					'type'        => 'select',
					'label'       => __( 'Context Strategy', 'mcp-ai-wpoos' ),
					'description' => __( 'Sliding Window: keeps only the most recent messages. BME: summarizes older messages and keeps recent ones verbatim. BME+RAG: adds memory retrieval for cross-session context.', 'mcp-ai-wpoos' ),
					'default'     => 'sliding_window',
					'options'     => array(
						'sliding_window' => __( 'Sliding Window', 'mcp-ai-wpoos' ),
						'bme'            => __( 'Beginning-Middle-End (BME)', 'mcp-ai-wpoos' ),
						'bme_rag'        => __( 'BME + RAG Memory', 'mcp-ai-wpoos' ),
					),
				),
				'end_window_size'                       => array(
					'type'        => 'number',
					'label'       => __( 'End Window Size', 'mcp-ai-wpoos' ),
					'description' => __( 'Number of recent messages to keep verbatim in the End zone. Older messages will be summarized. Only used with BME strategy.', 'mcp-ai-wpoos' ),
					'default'     => 10,
					'placeholder' => '10',
					'min'         => 2,
					'max'         => 50,
				),
				'summary_trigger_count'                 => array(
					'type'        => 'number',
					'label'       => __( 'Summary Trigger Count', 'mcp-ai-wpoos' ),
					'description' => __( 'When total non-system messages exceed this count, older messages are summarized. Only used with BME strategy.', 'mcp-ai-wpoos' ),
					'default'     => 30,
					'placeholder' => '30',
					'min'         => 10,
					'max'         => 200,
				),
				'summary_trigger_tokens'                => array(
					'type'        => 'number',
					'label'       => __( 'Summary Trigger Tokens', 'mcp-ai-wpoos' ),
					'description' => __( 'Alternative token-based trigger. When set (>0), summarization triggers at 80% of this value instead of using count. Set to 0 to use count-based trigger.', 'mcp-ai-wpoos' ),
					'default'     => 0,
					'placeholder' => '0',
					'min'         => 0,
					'max'         => 200000,
				),
				'summary_model'                         => array(
					'type'        => 'text',
					'label'       => __( 'Summary Model', 'mcp-ai-wpoos' ),
					'description' => __( 'Model to use for conversation summarization. Leave blank to use the assistant model. Use a faster/cheaper model for cost-efficient summaries.', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => __( 'Default: assistant model', 'mcp-ai-wpoos' ),
				),
				'summary_max_tokens'                    => array(
					'type'        => 'number',
					'label'       => __( 'Summary Max Tokens', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum tokens for the generated conversation summary. Higher values preserve more detail.', 'mcp-ai-wpoos' ),
					'default'     => 500,
					'placeholder' => '500',
					'min'         => 100,
					'max'         => 4000,
				),
				'tool_result_summarize_threshold'       => array(
					'type'        => 'number',
					'label'       => __( 'Tool Result Summarize Threshold', 'mcp-ai-wpoos' ),
					'description' => __( 'Tool results longer than this many characters will be truncated before storing in chat history. Set to 0 to disable.', 'mcp-ai-wpoos' ),
					'default'     => 2000,
					'placeholder' => '2000',
					'min'         => 0,
					'max'         => 100000,
				),
				'request_timeout'                       => array(
					'type'        => 'number',
					'label'       => __( 'Request Timeout (seconds)', 'mcp-ai-wpoos' ),
					'description' => __( 'How long to wait for AI provider responses before timing out. Increase for complex requests or slower providers.', 'mcp-ai-wpoos' ),
					'default'     => 200,
					'placeholder' => '200',
					'min'         => 10,
					'max'         => 600,
				),
				'query_posts_limit'                     => array(
					'type'        => 'number',
					'label'       => __( 'Max Posts Query Results', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum number of posts returned by content query tools such as Get Recent Posts and Search Content. Increase this to allow AI tools to retrieve more posts per query. Default: 50.', 'mcp-ai-wpoos' ),
					'default'     => 50,
					'placeholder' => '50',
					'min'         => 1,
					'max'         => 500,
				),
				// Custom Filters fields.
				'filter_default_light_model'            => array(
					'type'        => 'text',
					'label'       => __( 'Default Light Model', 'mcp-ai-wpoos' ),
					'description' => __( 'Default AI model for simple tasks. Overrides the wp_mcp_ai_default_light_model filter. Default: gpt-4o-mini', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => 'gpt-4.1-mini',
				),
				'filter_default_advanced_model'         => array(
					'type'        => 'text',
					'label'       => __( 'Default Advanced Model', 'mcp-ai-wpoos' ),
					'description' => __( 'Default AI model for complex tasks. Overrides the wp_mcp_ai_default_advanced_model filter. Default: gpt-4.1', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => 'gpt-6.1-sol',
				),
				'filter_max_agentic_iterations'         => array(
					'type'        => 'number',
					'label'       => __( 'Max Agentic Iterations', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum number of tool execution loops per request. Prevents infinite loops. Range: 1-50. Default: 5', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => '5',
				),
				'filter_resource_max_tokens'            => array(
					'type'        => 'number',
					'label'       => __( 'Resource Max Tokens', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum tokens for AI responses based on workload tier. Overrides the wp_mcp_ai_resource_max_tokens filter. Leave empty for auto-detection.', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => 'Auto',
				),
				'filter_resource_request_timeout'       => array(
					'type'        => 'number',
					'label'       => __( 'Resource Request Timeout (seconds)', 'mcp-ai-wpoos' ),
					'description' => __( 'Request timeout based on workload tier. Overrides the wp_mcp_ai_resource_request_timeout filter. Leave empty for auto-detection.', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => 'Auto',
				),
				'filter_max_retries'                    => array(
					'type'        => 'number',
					'label'       => __( 'Max Retries', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum retry attempts for failed API requests. Overrides the wp_mcp_ai_max_retries filter. Default: 3', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => '3',
				),
				'filter_max_retry_delay'                => array(
					'type'        => 'number',
					'label'       => __( 'Max Retry Delay (seconds)', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum delay between retry attempts. Overrides the wp_mcp_ai_max_retry_delay filter. Default: 60', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => '60',
				),
				'filter_max_attachment_bytes'           => array(
					'type'        => 'number',
					'label'       => __( 'Max Attachment Size (bytes)', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum size for file attachments in chat. Overrides the wp_mcp_ai_max_attachment_bytes filter. Default: 10485760 (10MB)', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => '10485760',
				),
				'filter_default_ollama_endpoint_url'    => array(
					'type'        => 'url',
					'label'       => __( 'Default Ollama Endpoint URL', 'mcp-ai-wpoos' ),
					'description' => __( 'Default endpoint URL for Ollama local AI. Overrides the wp_mcp_ai_default_ollama_endpoint_url filter. Default: http://localhost:11434', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => 'http://localhost:11434',
				),
				'filter_default_lm_studio_endpoint_url' => array(
					'type'        => 'url',
					'label'       => __( 'Default LM Studio Endpoint URL', 'mcp-ai-wpoos' ),
					'description' => __( 'Default endpoint URL for LM Studio local AI. Overrides the wp_mcp_ai_default_lm_studio_endpoint_url filter. Default: http://localhost:1234', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => 'http://localhost:1234',
				),
			);
		}

		/**
		 * Get sub-tab groups configuration.
		 *
		 * @return array
		 */
		protected function get_subtab_groups() {
			return array(
				'core'           => array(
					'id'     => 'core',
					'label'  => __( 'Core Settings', 'mcp-ai-wpoos' ),
					'icon'   => 'dashicons-admin-settings',
					'fields' => array( 'default_provider', 'default_assistant' ),
				),
				'behavior'       => array(
					'id'     => 'behavior',
					'label'  => __( 'Behavior & Limits', 'mcp-ai-wpoos' ),
					'icon'   => 'dashicons-performance',
					'fields' => array(
						'max_history_messages',
						'context_strategy',
						'end_window_size',
						'summary_trigger_count',
						'summary_trigger_tokens',
						'summary_model',
						'summary_max_tokens',
						'tool_result_summarize_threshold',
						'request_timeout',
						'query_posts_limit',
					),
				),
				'logs'           => array(
					'id'     => 'logs',
					'label'  => __( 'Log Management', 'mcp-ai-wpoos' ),
					'icon'   => 'dashicons-database',
					'fields' => array(
						'enable_logging',
						'enable_extended_logging',
						'enable_agentic_loop_logging',
						'enable_api_logging',
						'enable_tool_execution_logging',
						'enable_chat_interaction_logging',
						'enable_debug_logging',
						'delete_on_uninstall',
						'enable_activation_tracking',
					),
				),
				'custom_filters' => array(
					'id'          => 'custom_filters',
					'label'       => __( 'Custom AI Settings (Filters)', 'mcp-ai-wpoos' ),
					'icon'        => 'dashicons-filter',
					'description' => __( 'Configure advanced AI behavior settings through a user-friendly interface. These settings override WordPress filter defaults and allow you to customize AI operations without writing code. <strong>Leave fields empty to use system defaults.</strong>', 'mcp-ai-wpoos' ),
					'fields'      => array(
						'filter_default_light_model',
						'filter_default_advanced_model',
						'filter_max_agentic_iterations',
						'filter_resource_max_tokens',
						'filter_resource_request_timeout',
						'filter_max_retries',
						'filter_max_retry_delay',
						'filter_max_attachment_bytes',
						'filter_default_ollama_endpoint_url',
						'filter_default_lm_studio_endpoint_url',
					),
				),
			);
		}

		/**
		 * Get active sub-tab.
		 *
		 * @return string
		 */
		protected function get_active_subtab() {
			$subtab_groups = $this->get_subtab_groups();
			$subtab        = '';

			// Check POST data first (when form is being submitted), then fall back to GET.
			// Use section-specific field name to avoid conflicts with other sections.
			// phpcs:disable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only parameter check for UI state.
			$subtab_field_name = 'subtab_' . $this->get_id();
			if ( isset( $_POST[ $subtab_field_name ] ) ) {
				$subtab = sanitize_key( wp_unslash( $_POST[ $subtab_field_name ] ) );
			} elseif ( isset( $_POST['subtab'] ) ) {
				// Fallback to legacy field name for backward compatibility.
				$subtab = sanitize_key( wp_unslash( $_POST['subtab'] ) );
			} elseif ( isset( $_GET['subtab'] ) ) {
				$subtab = sanitize_key( wp_unslash( $_GET['subtab'] ) );
			}
			// phpcs:enable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended

			// Default to 'core' if not set or invalid.
			if ( empty( $subtab ) || ! isset( $subtab_groups[ $subtab ] ) ) {
				$subtab = 'core';
			}

			return $subtab;
		}

		/**
		 * Get assistant options for select dropdown.
		 *
		 * @return array
		 */
		private function get_assistant_options() {
			$options = array(
				0 => __( 'None (explicit selection required)', 'mcp-ai-wpoos' ),
			);

			// Get published assistants.
			$assistants = get_posts(
				array(
					'post_type'      => 'mcp_ai_assistant',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'orderby'        => 'title',
					'order'          => 'ASC',
				)
			);

			if ( ! empty( $assistants ) ) {
				foreach ( $assistants as $assistant ) {
					$options[ $assistant->ID ] = $assistant->post_title;
				}
			}

			return $options;
		}

		/**
		 * Render section fields.
		 */
		public function render() {
			$fields        = $this->get_fields();
			$subtab_groups = $this->get_subtab_groups();
			$active_subtab = $this->get_active_subtab();

			// Get the active group.
			if ( ! isset( $subtab_groups[ $active_subtab ] ) ) {
				return;
			}

			$active_group = $subtab_groups[ $active_subtab ];

			// Special handling for custom_filters subtab with grouped fields.
			if ( 'custom_filters' === $active_subtab ) {
				$this->render_custom_filters_fields( $fields, $active_group );
			} else {
				// Render fields for other sub-tabs normally.
				foreach ( $active_group['fields'] as $key ) {
					if ( isset( $fields[ $key ] ) ) {
						$this->render_field( $key, $fields[ $key ] );
					}
				}
			}

			// Render logging table if we're on the log management sub-tab.
			if ( 'logs' === $active_subtab ) {
				echo '</table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Close the form table.
				$this->render_logging_table();
				echo '<table class="form-table" role="presentation" style="display:none;">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Re-open hidden table for structure.
			}
		}

		/**
		 * Render custom filters fields with grouping.
		 *
		 * @param array $fields All available fields.
		 * @param array $active_group Active subtab group configuration.
		 */
		private function render_custom_filters_fields( $fields, $active_group ) {
			// Organize fields into logical groups for better UX.
			$groups = array(
				'model_selection'     => array(
					'title'  => __( 'AI Model Selection', 'mcp-ai-wpoos' ),
					'fields' => array( 'filter_default_light_model', 'filter_default_advanced_model' ),
				),
				'resource_management' => array(
					'title'  => __( 'Resource Management', 'mcp-ai-wpoos' ),
					'fields' => array( 'filter_max_agentic_iterations', 'filter_resource_max_tokens', 'filter_resource_request_timeout' ),
				),
				'retry_handling'      => array(
					'title'  => __( 'Retry & Error Handling', 'mcp-ai-wpoos' ),
					'fields' => array( 'filter_max_retries', 'filter_max_retry_delay' ),
				),
				'file_limits'         => array(
					'title'  => __( 'File & Attachment Limits', 'mcp-ai-wpoos' ),
					'fields' => array( 'filter_max_attachment_bytes' ),
				),
				'endpoint_urls'       => array(
					'title'  => __( 'Local AI Endpoint URLs', 'mcp-ai-wpoos' ),
					'fields' => array( 'filter_default_ollama_endpoint_url', 'filter_default_lm_studio_endpoint_url' ),
				),
			);

			foreach ( $groups as $group_id => $group ) {
				?>
				<tr class="filter-group-header">
					<td colspan="2">
						<h3 class="filter-group-title">
							<?php echo esc_html( $group['title'] ); ?>
						</h3>
					</td>
				</tr>
				<?php
				foreach ( $group['fields'] as $field_key ) {
					if ( isset( $fields[ $field_key ] ) ) {
						$this->render_field( $field_key, $fields[ $field_key ] );
					}
				}
			}
		}

		/**
		 * Override render_wrapper to include sub-tab navigation.
		 */
		public function render_wrapper() {
			$description       = $this->get_description();
			$documentation_url = $this->get_documentation_url();
			$subtab_groups     = $this->get_subtab_groups();
			$active_subtab     = $this->get_active_subtab();
			$active_group      = isset( $subtab_groups[ $active_subtab ] ) ? $subtab_groups[ $active_subtab ] : null;
			?>
		<div class="settings-section" id="section-<?php echo esc_attr( $this->get_id() ); ?>">
			<h2><?php echo esc_html( $this->get_title() ); ?></h2>
			<?php if ( $description ) : ?>
				<p class="section-description"><?php echo wp_kses_post( $description ); ?></p>
			<?php endif; ?>
			<?php if ( $documentation_url ) : ?>
				<p class="section-documentation">
					<span class="dashicons dashicons-book-alt" style="color: #2271b1;"></span>
					<a href="<?php echo esc_url( $documentation_url ); ?>" target="_blank" rel="noopener noreferrer">
						<?php esc_html_e( 'View Documentation', 'mcp-ai-wpoos' ); ?>
						<span class="dashicons dashicons-external" style="font-size: 14px; text-decoration: none;"></span>
					</a>
				</p>
			<?php endif; ?>

			<div class="wp-mcp-ai-provider-subtabs">
				<nav class="wp-mcp-ai-subtab-nav" aria-label="<?php esc_attr_e( 'General settings sub-tabs', 'mcp-ai-wpoos' ); ?>">
					<?php foreach ( $subtab_groups as $group ) : ?>
						<?php
						$subtab_url = add_query_arg(
							array(
								'page'   => 'wp-mcp-ai-dashboard',
								'tab'    => 'general',
								'subtab' => $group['id'],
							),
							admin_url( 'admin.php' )
						);
						$is_active  = ( $group['id'] === $active_subtab );
						?>
						<a href="<?php echo esc_url( $subtab_url ); ?>"
							class="wp-mcp-ai-subtab <?php echo esc_attr( $is_active ? 'wp-mcp-ai-subtab-active' : '' ); ?>"
							data-subtab="<?php echo esc_attr( $group['id'] ); ?>">
							<span class="dashicons <?php echo esc_attr( $group['icon'] ); ?>"></span>
							<?php echo esc_html( $group['label'] ); ?>
						</a>
					<?php endforeach; ?>
				</nav>

				<!-- Hidden field to preserve subtab during form submission -->
				<input type="hidden" name="subtab_<?php echo esc_attr( $this->get_id() ); ?>" value="<?php echo esc_attr( $active_subtab ); ?>" />

				<div class="wp-mcp-ai-subtab-content">
					<?php if ( $active_group && isset( $active_group['description'] ) ) : ?>
						<p class="subtab-description"><?php echo wp_kses_post( $active_group['description'] ); ?></p>
					<?php endif; ?>
					<table class="form-table" role="presentation">
						<?php $this->render(); ?>
					</table>
				</div>
			</div>
		</div>
			<?php
		}

		/**
		 * Render the logging table if logging is enabled.
		 */
		private function render_logging_table() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			// Only show the logging table if logging is enabled.
			if ( empty( $settings['enable_logging'] ) ) {
				return;
			}

			$entries = WP_MCP_AI_Logger::get_recent_error_messages();
			?>
			<div class="wp-mcp-ai-error-log-section" style="margin-top: 30px;">
				<h3><?php esc_html_e( 'Recent Error & Activity Log', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Recent error and warning messages (most recent first). Expand an entry to view additional context.', 'mcp-ai-wpoos' ); ?></p>
				<?php if ( empty( $entries ) ) : ?>
					<p class="description"><?php esc_html_e( 'No error or warning messages have been recorded yet.', 'mcp-ai-wpoos' ); ?></p>
				<?php else : ?>
					<ul class="wp-mcp-ai-log-preview" style="list-style: none; padding: 0; margin: 15px 0;">
						<?php
						foreach ( $entries as $entry ) :
							$timestamp = '';

							if ( ! empty( $entry['timestamp'] ) ) {
								$timestamp = get_date_from_gmt(
									$entry['timestamp'],
									get_option( 'date_format' ) . ' ' . get_option( 'time_format' )
								);
							}

							$type_label    = strtoupper( $entry['type'] );
							$message_label = $entry['message'];
							$context_label = '';

							if ( isset( $entry['context'] ) && ! empty( $entry['context'] ) ) {
								$options = 0;

								if ( defined( 'JSON_PRETTY_PRINT' ) ) {
									$options |= JSON_PRETTY_PRINT;
								}

								if ( defined( 'JSON_UNESCAPED_SLASHES' ) ) {
									$options |= JSON_UNESCAPED_SLASHES;
								}

								$context_json = wp_json_encode( $entry['context'], $options );

								if ( false !== $context_json ) {
									$context_label = $context_json;
								}
							}
							?>
							<li style="background: #f9f9f9; padding: 15px; margin-bottom: 10px; border-left: 3px solid #dc3232; border-radius: 3px;">
								<?php if ( ! empty( $timestamp ) ) : ?>
									<span class="wp-mcp-ai-log-preview__time" style="color: #666; font-size: 0.9em;"><?php echo esc_html( $timestamp ); ?></span>
									&mdash;
								<?php endif; ?>
								<span class="wp-mcp-ai-log-preview__type" style="font-weight: bold; color: #dc3232;"><?php echo esc_html( $type_label ); ?></span>:
								<span class="wp-mcp-ai-log-preview__message"><?php echo esc_html( $message_label ); ?></span>
								<?php if ( '' !== $context_label ) : ?>
									<details class="wp-mcp-ai-log-preview__context" style="margin-top: 10px;">
										<summary style="cursor: pointer; color: #0073aa;"><?php esc_html_e( 'Context details', 'mcp-ai-wpoos' ); ?></summary>
										<pre style="background: #fff; padding: 10px; margin-top: 10px; overflow-x: auto; border: 1px solid #ddd; border-radius: 3px; font-size: 0.85em;"><?php echo esc_html( $context_label ); ?></pre>
									</details>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<?php
				$log_file_path    = WP_MCP_AI_Logger::get_log_file_path();
				$log_file_exists  = WP_MCP_AI_Logger::does_log_file_exist();
				$log_file_size    = WP_MCP_AI_Logger::get_log_file_size();
				$log_size_display = '';

				if ( null !== $log_file_size ) {
					$log_size_display = function_exists( 'size_format' )
					? size_format( $log_file_size, 2 )
					: $log_file_size . ' bytes';
				}
				?>
				<div class="wp-mcp-ai-log-meta" style="margin-top: 15px; padding: 15px; background: #fff; border: 1px solid #ddd; border-radius: 3px;">
					<?php if ( '' !== $log_file_path ) : ?>
						<p class="description">
							<?php
							if ( $log_file_exists ) {
								if ( '' === $log_size_display ) {
									$log_size_display = __( 'Unknown size', 'mcp-ai-wpoos' );
								}

								printf(
									wp_kses(
										/* translators: 1: Path to the PHP error log wrapped in <code> tags. 2: Human readable size. */
										__( 'PHP error log: %1$s (%2$s).', 'mcp-ai-wpoos' ),
										array( 'code' => array() )
									),
									'<code>' . esc_html( $log_file_path ) . '</code>',
									esc_html( $log_size_display )
								);
							} else {
								printf(
									wp_kses(
										/* translators: %s: Path to the PHP error log wrapped in <code> tags. */
										__( 'PHP error log: %s (not created yet).', 'mcp-ai-wpoos' ),
										array( 'code' => array() )
									),
									'<code>' . esc_html( $log_file_path ) . '</code>'
								);
							}
							?>
						</p>
					<?php else : ?>
						<p class="description"><?php esc_html_e( 'Unable to determine the PHP error log location. Check your server configuration if you need to inspect or prune the log.', 'mcp-ai-wpoos' ); ?></p>
					<?php endif; ?>
				</div>
			</div>
			<?php
		}

		/**
		 * Sanitize section input.
		 *
		 * @param array $input Raw input from form.
		 * @return array Sanitized input.
		 */
		public function sanitize( $input ) {
			// Use parent's subtab-aware sanitization.
			$sanitized = parent::sanitize( $input );

			// Special handling for default_assistant: convert to integer.
			if ( isset( $sanitized['default_assistant'] ) ) {
				$sanitized['default_assistant'] = absint( $sanitized['default_assistant'] );
			}

			return $sanitized;
		}

		/**
		 * Validate section input.
		 *
		 * @param array $input Raw input.
		 * @return array|WP_Error Validated input or error.
		 */
		public function validate( $input ) {
			$errors = array();

			// Validate default_provider.
			if ( isset( $input['default_provider'] ) ) {
				$valid_providers = array( 'openai', 'anthropic', 'gemini', 'huggingface', 'nvidia', 'deepseek', 'openrouter', 'digitalocean', 'kimi', 'baseten', 'ollama', 'lm_studio', 'cloudflare', 'embedded' );
				if ( ! in_array( $input['default_provider'], $valid_providers, true ) ) {
					$errors[] = __( 'Invalid AI provider selected.', 'mcp-ai-wpoos' );
				}
			}

			// Validate default_assistant.
			if ( isset( $input['default_assistant'] ) ) {
				$assistant_id = absint( $input['default_assistant'] );
				if ( $assistant_id > 0 ) {
					$assistant = get_post( $assistant_id );
					if ( ! $assistant || 'mcp_ai_assistant' !== $assistant->post_type ) {
						$errors[] = __( 'Invalid assistant selected.', 'mcp-ai-wpoos' );
					}
				}
			}

			// Validate max_history_messages.
			if ( isset( $input['max_history_messages'] ) ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['max_history_messages'],
					1,
					100
				);

				if ( is_wp_error( $result ) ) {
					$errors[] = $result->get_error_message();
				}
			}

			// Validate request_timeout.
			if ( isset( $input['request_timeout'] ) ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['request_timeout'],
					10,
					600
				);

				if ( is_wp_error( $result ) ) {
					$errors[] = $result->get_error_message();
				}
			}

			// Validate query_posts_limit.
			if ( isset( $input['query_posts_limit'] ) ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['query_posts_limit'],
					1,
					500
				);

				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Max Posts Query Results: ', 'mcp-ai-wpoos' ) . $result->get_error_message();
				}
			}

			// Validate filter_max_agentic_iterations.
			if ( isset( $input['filter_max_agentic_iterations'] ) && '' !== $input['filter_max_agentic_iterations'] ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['filter_max_agentic_iterations'],
					1,
					50
				);

				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Max Agentic Iterations: ', 'mcp-ai-wpoos' ) . $result->get_error_message();
				}
			}

			// Validate filter_resource_max_tokens.
			if ( isset( $input['filter_resource_max_tokens'] ) && '' !== $input['filter_resource_max_tokens'] ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['filter_resource_max_tokens'],
					100,
					128000
				);

				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Resource Max Tokens: ', 'mcp-ai-wpoos' ) . $result->get_error_message();
				}
			}

			// Validate filter_resource_request_timeout.
			if ( isset( $input['filter_resource_request_timeout'] ) && '' !== $input['filter_resource_request_timeout'] ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['filter_resource_request_timeout'],
					10,
					600
				);

				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Resource Request Timeout: ', 'mcp-ai-wpoos' ) . $result->get_error_message();
				}
			}

			// Validate filter_max_retries.
			if ( isset( $input['filter_max_retries'] ) && '' !== $input['filter_max_retries'] ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['filter_max_retries'],
					0,
					10
				);

				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Max Retries: ', 'mcp-ai-wpoos' ) . $result->get_error_message();
				}
			}

			// Validate filter_max_retry_delay.
			if ( isset( $input['filter_max_retry_delay'] ) && '' !== $input['filter_max_retry_delay'] ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['filter_max_retry_delay'],
					1,
					300
				);

				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Max Retry Delay: ', 'mcp-ai-wpoos' ) . $result->get_error_message();
				}
			}

			// Validate filter_max_attachment_bytes.
			if ( isset( $input['filter_max_attachment_bytes'] ) && '' !== $input['filter_max_attachment_bytes'] ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['filter_max_attachment_bytes'],
					1024,
					104857600 // 100MB max.
				);

				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Max Attachment Size: ', 'mcp-ai-wpoos' ) . $result->get_error_message();
				}
			}

			// Validate URLs.
			if ( isset( $input['filter_default_ollama_endpoint_url'] ) && '' !== $input['filter_default_ollama_endpoint_url'] ) {
				$url = filter_var( $input['filter_default_ollama_endpoint_url'], FILTER_VALIDATE_URL );
				if ( false === $url ) {
					$errors[] = __( 'Default Ollama Endpoint URL must be a valid URL.', 'mcp-ai-wpoos' );
				}
			}

			if ( isset( $input['filter_default_lm_studio_endpoint_url'] ) && '' !== $input['filter_default_lm_studio_endpoint_url'] ) {
				$url = filter_var( $input['filter_default_lm_studio_endpoint_url'], FILTER_VALIDATE_URL );
				if ( false === $url ) {
					$errors[] = __( 'Default LM Studio Endpoint URL must be a valid URL.', 'mcp-ai-wpoos' );
				}
			}

			if ( ! empty( $errors ) ) {
				return new WP_Error( 'validation_error', implode( ' ', $errors ) );
			}

			return $input;
		}
	}
}
