<?php
/**
 * Advanced Settings Section
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Section_Advanced' ) ) {
	/**
	 * Advanced settings section.
	 */
	class WP_MCP_AI_Section_Advanced extends WP_MCP_AI_Settings_Section {
			/**
			 * Constructor.
			 */
		public function __construct() {
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		}

			/**
			 * Enqueue admin styles for this section's inline CSS.
			 *
			 * @param string $hook_suffix The current admin page hook suffix.
			 */
		public function enqueue_admin_assets( $hook_suffix ) {
			// Only on our plugin's settings page.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only page slug detection, no state change.
			$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
			if ( 'wp-mcp-ai-dashboard' !== $page ) {
				return;
			}

			// Register a dummy handle for inline styles (no source file).
			// phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Inline style registered with no URL; version not applicable.
			wp_register_style( 'wp-mcp-ai-advanced-section', false );
			wp_enqueue_style( 'wp-mcp-ai-advanced-section' );

			$inline_css = '.wp-mcp-ai-status-badge{display:inline-block;padding:2px 8px;border-radius:3px;font-size:12px;font-weight:600;}'
				. '.wp-mcp-ai-status-success{background:#d4edda;color:#155724;}'
				. '.wp-mcp-ai-status-warning{background:#fff3cd;color:#856404;}'
				. '.wp-mcp-ai-status-error{background:#f8d7da;color:#721c24;}'
				. '.wp-mcp-ai-status-unknown{background:#e2e3e5;color:#383d41;}'
				. '.wp-mcp-ai-reseed-actions button .dashicons{vertical-align:middle;}'
				. '.wp-mcp-ai-reseed-actions button.disabled{opacity:0.6;cursor:not-allowed;}'
				. '@keyframes spin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}'
				. '.dashicons.spin{animation:spin 1s linear infinite;}';

			wp_add_inline_style( 'wp-mcp-ai-advanced-section', $inline_css );
		}

			/**
			 * Get section ID.
			 *
			 * @return string
			 */
		public function get_id() {
			return 'advanced';
		}

		/**
		 * Get section title.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Advanced Settings', 'mcp-ai-wpoos' );
		}

		/**
		 * Get tab ID.
		 *
		 * @return string
		 */
		public function get_tab() {
			return 'advanced';
		}

		/**
		 * Get section description.
		 *
		 * @return string
		 */
		public function get_description() {
			return __( 'Performance tuning, debugging options, and advanced configuration.', 'mcp-ai-wpoos' );
		}

		/**
		 * Get documentation URL for this section.
		 *
		 * @return string
		 */
		public function get_documentation_url() {
			return 'https://github.com/nvdigitalsolutions/mcp-ai-wpoos/blob/main/docs/admin-guides/settings/new-settings-december-2025.md';
		}

		/**
		 * Get field definitions.
		 *
		 * @return array
		 */
		public function get_fields() {
			return array(
				'profession_default_tool_count' => array(
					'type'        => 'number',
					'label'       => __( 'Recommended Default Tools per Profession', 'mcp-ai-wpoos' ),
					'description' => __( 'Recommended number of default tools to assign per profession. This is a guideline for profession configuration - actual tool count can vary based on profession needs. Default: 10', 'mcp-ai-wpoos' ),
					'default'     => 10,
					'min'         => 3,
					'max'         => 20,
					'placeholder' => '10',
				),
				'memory_max_file_bytes'         => array(
					'type'        => 'number',
					'label'       => __( 'Max Memory File Size (bytes)', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum file size for memory operations, in bytes. Examples: 5242880 = 5 MB, 10485760 = 10 MB, 52428800 = 50 MB.', 'mcp-ai-wpoos' ),
					'default'     => 5242880,
					'placeholder' => '5242880',
					'min'         => 1,
					'step'        => 1,
				),
				'enable_opcache_reset'          => array(
					'type'           => 'checkbox',
					'label'          => __( 'Auto OPcache Reset', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Automatically reset OPcache when needed', 'mcp-ai-wpoos' ),
					'description'    => __( 'Automatically clears OPcache when plugin files are updated. Helps ensure code changes take effect immediately without manually clearing cache. Recommended for development environments.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'disable_native_streaming'      => array(
					'type'           => 'checkbox',
					'label'          => __( 'Disable Native Streaming', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Use simulated chunking instead of real-time streaming', 'mcp-ai-wpoos' ),
					'description'    => __( 'When enabled, responses are fully buffered then split into chunks with delays (simulated streaming) instead of streaming token-by-token in real time. Use this if you encounter issues with real-time streaming or your server does not support long-running cURL connections.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_oos_engine'             => array(
					'type'           => 'checkbox',
					'label'          => __( 'OOS Engine (Experimental)', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Use the framework-agnostic OOS extraction engine', 'mcp-ai-wpoos' ),
					'description'    => __( 'Routes chat requests through the extracted oOS/core engine instead of the legacy WordPress-specific path. This cross-platform AI orchestration engine is designed to run identically on WordPress, Laravel, and Craft CMS via hexagonal Ports &amp; Adapters architecture. Requires PHP 8.1+. The legacy engine handles all requests when disabled.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				// Federation & Mesh Settings.
				'enable_mesh'                   => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Mesh Computing', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Enable distributed computing features', 'mcp-ai-wpoos' ),
					'description'    => __( 'Allows this instance to participate in mesh computing networks for distributed AI workload processing. Automatically generates a mesh inbound API key for peer connections.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_federation'             => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Federation', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Enable federated discovery', 'mcp-ai-wpoos' ),
					'description'    => __( 'Enables well-known endpoints (/.well-known/ai-peer, /.well-known/jwks.json) for AI peer discovery. This allows other sites to discover your site\'s capabilities without requiring the full directory service.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'enable_federation_directory'   => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Federation Directory', 'mcp-ai-wpoos' ),
					'checkbox_label' => __( 'Enable federation directory service', 'mcp-ai-wpoos' ),
					'description'    => __( 'Enables the full federation directory service including AI Peers custom post type, directory REST API, and peer verification. Requires "Enable Federation" to also publish well-known endpoints for directory participants.', 'mcp-ai-wpoos' ),
					'default'        => false,
				),
				'federation_regions'            => array(
					'type'        => 'text',
					'label'       => __( 'Federation Regions', 'mcp-ai-wpoos' ),
					'description' => __( 'Comma-separated list of geographic regions where this site operates (e.g., "us-east,us-west,eu-central"). Used for regional routing and data residency compliance.', 'mcp-ai-wpoos' ),
					'default'     => 'global',
					'placeholder' => 'global, us-east, eu-central',
				),
				'federation_data_tags'          => array(
					'type'        => 'text',
					'label'       => __( 'Federation Data Tags', 'mcp-ai-wpoos' ),
					'description' => __( 'Comma-separated data classification tags (e.g., "public,internal,confidential"). Used for data governance and access control in federated operations.', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => 'public, internal',
				),
				'federation_qps'                => array(
					'type'        => 'number',
					'label'       => __( 'Federation QPS Limit', 'mcp-ai-wpoos' ),
					'description' => __( 'Maximum queries per second (QPS) allowed for federation API requests. Prevents resource exhaustion from federated queries. Default: 5 QPS.', 'mcp-ai-wpoos' ),
					'default'     => 5,
					'min'         => 1,
					'max'         => 1000,
					'placeholder' => '5',
				),
				'federation_burst'              => array(
					'type'        => 'number',
					'label'       => __( 'Federation Burst Capacity', 'mcp-ai-wpoos' ),
					'description' => __( 'Burst capacity for federation rate limiting. Allows temporary spikes above QPS limit. Default: 10.', 'mcp-ai-wpoos' ),
					'default'     => 10,
					'min'         => 1,
					'max'         => 10000,
					'placeholder' => '10',
				),
				'federation_jwks_keys'          => array(
					'type'        => 'textarea',
					'label'       => __( 'Federation JWKS Keys', 'mcp-ai-wpoos' ),
					'description' => __( 'JSON Web Key Set (JWKS) for federation authentication. Advanced setting - only modify if implementing custom federation authentication. Must be valid JSON array of JWK objects.', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => '[{"kty":"RSA","use":"sig","kid":"...","n":"...","e":"AQAB"}]',
					'rows'        => 6,
				),
				'federation_price_hints'        => array(
					'type'        => 'textarea',
					'label'       => __( 'Federation Price Hints', 'mcp-ai-wpoos' ),
					'description' => __( 'JSON object with pricing information for federation services. Used for cost attribution in federated AI operations. Advanced setting. Format: {"model": "gpt-4", "cost_per_1k_tokens": 0.03}', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => '{"gpt-4": {"input": 0.03, "output": 0.06}}',
					'rows'        => 5,
				),
				'mesh_inbound_api_key'          => array(
					'type'        => 'text',
					'label'       => __( 'Mesh Inbound API Key', 'mcp-ai-wpoos' ),
					'description' => __( 'Auto-generated API key for receiving mesh network requests. This key is used by peer sites to authenticate inbound connections. Copy this key to configure peer sites. Key is auto-generated when mesh networking is enabled.', 'mcp-ai-wpoos' ),
					'default'     => '',
					'placeholder' => 'mesh_xxxxxxxx...',
					'readonly'    => true,
					'class'       => 'regular-text code',
				),
				'mesh_peer_sites'               => array(
					'type'        => 'custom',
					'label'       => __( 'Mesh Peer Sites', 'mcp-ai-wpoos' ),
					'description' => __( 'Configure peer sites for mesh computing. These are remote NV oOS instances that this site can query for distributed workload processing.', 'mcp-ai-wpoos' ),
					'callback'    => array( $this, 'render_mesh_peer_sites_custom_field' ),
				),

			);
		}

		/**
		 * Get sub-tab groups configuration.
		 *
		 * @return array
		 */
		protected function get_subtab_groups() {
			return array(
				'performance_monitoring' => array(
					'id'     => 'performance_monitoring',
					'label'  => __( 'Performance Monitoring', 'mcp-ai-wpoos' ),
					'icon'   => 'dashicons-chart-line',
					'fields' => array(), // No form fields, custom content only.
				),
				'performance'            => array(
					'id'     => 'performance',
					'label'  => __( 'Performance', 'mcp-ai-wpoos' ),
					'icon'   => 'dashicons-performance',
					'fields' => array( 'memory_max_file_bytes' ),
				),
				'data_management'        => array(
					'id'     => 'data_management',
					'label'  => __( 'Data Management', 'mcp-ai-wpoos' ),
					'icon'   => 'dashicons-database',
					'fields' => array(), // No form fields, custom content only.
				),
				'federation_mesh'        => array(
					'id'     => 'federation_mesh',
					'label'  => __( 'Federation & Mesh', 'mcp-ai-wpoos' ),
					'icon'   => 'dashicons-networking',
					'fields' => array(
						'enable_mesh',
						'enable_federation',
						'enable_federation_directory',
						'federation_regions',
						'federation_data_tags',
						'federation_qps',
						'federation_burst',
						'federation_jwks_keys',
						'federation_price_hints',
						'mesh_inbound_api_key',
						'mesh_peer_sites',
					),
				),
				'system'                 => array(
					'id'     => 'system',
					'label'  => __( 'System', 'mcp-ai-wpoos' ),
					'icon'   => 'dashicons-admin-settings',
					'fields' => array( 'enable_opcache_reset', 'enable_oos_engine', 'disable_native_streaming' ),
				),
				'settings_management'    => array(
					'id'     => 'settings_management',
					'label'  => __( 'Settings Management', 'mcp-ai-wpoos' ),
					'icon'   => 'dashicons-database-export',
					'fields' => array(), // No form fields, custom content only.
				),
			);
		}

		/**
		 * Get active sub-tab.
		 *
		 * @return string
		 */
		protected function get_active_subtab() {
			$subtab_groups = $this->get_subtab_groups();
			$subtab        = '';

			// Check POST data first (when form is being submitted), then fall back to GET.
			// Use section-specific field name to avoid conflicts with other sections.
			// phpcs:disable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$subtab_field_name = 'subtab_' . $this->get_id();
			if ( isset( $_POST[ $subtab_field_name ] ) ) {
				$subtab = sanitize_key( wp_unslash( $_POST[ $subtab_field_name ] ) );
			} elseif ( isset( $_POST['subtab'] ) ) {
				// Fallback to legacy field name for backward compatibility.
				$subtab = sanitize_key( wp_unslash( $_POST['subtab'] ) );
			} elseif ( isset( $_GET['subtab'] ) ) {
				$subtab = sanitize_key( wp_unslash( $_GET['subtab'] ) );
			}
			// phpcs:enable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended

			// Default to 'performance_monitoring' if not set or invalid.
			if ( empty( $subtab ) || ! isset( $subtab_groups[ $subtab ] ) ) {
				$subtab = 'performance_monitoring';
			}

			return $subtab;
		}

		/**
		 * Render section fields.
		 */
		public function render() {
			$fields        = $this->get_fields();
			$subtab_groups = $this->get_subtab_groups();
			$active_subtab = $this->get_active_subtab();

			// Get the active group.
			if ( ! isset( $subtab_groups[ $active_subtab ] ) ) {
				return;
			}

			$active_group = $subtab_groups[ $active_subtab ];

			// Render fields for the active sub-tab.
			foreach ( $active_group['fields'] as $key ) {
				if ( isset( $fields[ $key ] ) ) {
					$this->render_field( $key, $fields[ $key ] );
				}
			}

			// Render performance monitoring if we're on the performance_monitoring sub-tab.
			if ( 'performance_monitoring' === $active_subtab ) {
				echo '</table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Close the form table.
				$this->render_performance_monitoring();
				echo '<table class="form-table" role="presentation" style="display:none;">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Re-open hidden table for structure.
			}

			// Render data management if we're on the data_management sub-tab.
			if ( 'data_management' === $active_subtab ) {
				echo '</table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Close the form table.
				$this->render_data_management();
				echo '<table class="form-table" role="presentation" style="display:none;">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Re-open hidden table for structure.
			}

			// Render federation & mesh if we're on the federation_mesh sub-tab.
			if ( 'federation_mesh' === $active_subtab ) {
				echo '</table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Close the form table.
				$this->render_federation_mesh();
				echo '<table class="form-table" role="presentation" style="display:none;">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Re-open hidden table for structure.
			}

			// Render settings management if we're on the settings_management sub-tab.
			if ( 'settings_management' === $active_subtab ) {
				echo '</table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Close the form table.
				$this->render_settings_management();
				echo '<table class="form-table" role="presentation" style="display:none;">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Re-open hidden table for structure.
			}
		}

		/**
		 * Override render_wrapper to include sub-tab navigation.
		 */
		public function render_wrapper() {
			$description       = $this->get_description();
			$documentation_url = $this->get_documentation_url();
			$subtab_groups     = $this->get_subtab_groups();
			$active_subtab     = $this->get_active_subtab();
			?>
			<div class="settings-section" id="section-<?php echo esc_attr( $this->get_id() ); ?>">
				<h2><?php echo esc_html( $this->get_title() ); ?></h2>
				<?php if ( $description ) : ?>
					<p class="section-description"><?php echo wp_kses_post( $description ); ?></p>
				<?php endif; ?>
				<?php if ( $documentation_url ) : ?>
					<p class="section-documentation">
						<span class="dashicons dashicons-book-alt" style="color: #2271b1;"></span>
						<a href="<?php echo esc_url( $documentation_url ); ?>" target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'View Documentation', 'mcp-ai-wpoos' ); ?>
							<span class="dashicons dashicons-external" style="font-size: 14px; text-decoration: none;"></span>
						</a>
					</p>
				<?php endif; ?>

				<div class="wp-mcp-ai-provider-subtabs">
					<nav class="wp-mcp-ai-subtab-nav" aria-label="<?php esc_attr_e( 'Advanced settings sub-tabs', 'mcp-ai-wpoos' ); ?>">
						<?php foreach ( $subtab_groups as $group ) : ?>
							<?php
							$subtab_url = add_query_arg(
								array(
									'page'   => 'wp-mcp-ai-dashboard',
									'tab'    => 'advanced',
									'subtab' => $group['id'],
								),
								admin_url( 'admin.php' )
							);
							$is_active  = ( $group['id'] === $active_subtab );
							?>
							<a href="<?php echo esc_url( $subtab_url ); ?>"
								class="wp-mcp-ai-subtab <?php echo esc_attr( $is_active ? 'wp-mcp-ai-subtab-active' : '' ); ?>"
								data-subtab="<?php echo esc_attr( $group['id'] ); ?>">
								<span class="dashicons <?php echo esc_attr( $group['icon'] ); ?>"></span>
								<?php echo esc_html( $group['label'] ); ?>
							</a>
						<?php endforeach; ?>
					</nav>

					<!-- Hidden field to preserve subtab during form submission -->
					<input type="hidden" name="subtab_<?php echo esc_attr( $this->get_id() ); ?>" value="<?php echo esc_attr( $active_subtab ); ?>" />

					<div class="wp-mcp-ai-subtab-content">
						<table class="form-table" role="presentation">
							<?php $this->render(); ?>
						</table>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Render the logging table if logging is enabled.
		 */
		private function render_logging_table() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			// Only show the logging table if logging is enabled.
			if ( empty( $settings['enable_logging'] ) ) {
				return;
			}

			$entries = WP_MCP_AI_Logger::get_recent_error_messages();
			?>
			<div class="wp-mcp-ai-error-log-section" style="margin-top: 30px;">
				<h3><?php esc_html_e( 'Recent Error & Activity Log', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Recent error and warning messages (most recent first). Expand an entry to view additional context.', 'mcp-ai-wpoos' ); ?></p>
				<?php if ( empty( $entries ) ) : ?>
					<p class="description"><?php esc_html_e( 'No error or warning messages have been recorded yet.', 'mcp-ai-wpoos' ); ?></p>
				<?php else : ?>
					<ul class="wp-mcp-ai-log-preview" style="list-style: none; padding: 0; margin: 15px 0;">
						<?php
						foreach ( $entries as $entry ) :
							$timestamp = '';

							if ( ! empty( $entry['timestamp'] ) ) {
								$timestamp = get_date_from_gmt(
									$entry['timestamp'],
									get_option( 'date_format' ) . ' ' . get_option( 'time_format' )
								);
							}

							$type_label    = strtoupper( $entry['type'] );
							$message_label = $entry['message'];
							$context_label = '';

							if ( isset( $entry['context'] ) && ! empty( $entry['context'] ) ) {
								$options = 0;

								if ( defined( 'JSON_PRETTY_PRINT' ) ) {
									$options |= JSON_PRETTY_PRINT;
								}

								if ( defined( 'JSON_UNESCAPED_SLASHES' ) ) {
									$options |= JSON_UNESCAPED_SLASHES;
								}

								$context_json = wp_json_encode( $entry['context'], $options );

								if ( false !== $context_json ) {
									$context_label = $context_json;
								}
							}
							?>
							<li style="background: #f9f9f9; padding: 15px; margin-bottom: 10px; border-left: 3px solid #dc3232; border-radius: 3px;">
								<?php if ( ! empty( $timestamp ) ) : ?>
									<span class="wp-mcp-ai-log-preview__time" style="color: #666; font-size: 0.9em;"><?php echo esc_html( $timestamp ); ?></span>
									&mdash;
								<?php endif; ?>
								<span class="wp-mcp-ai-log-preview__type" style="font-weight: bold; color: #dc3232;"><?php echo esc_html( $type_label ); ?></span>:
								<span class="wp-mcp-ai-log-preview__message"><?php echo esc_html( $message_label ); ?></span>
								<?php if ( '' !== $context_label ) : ?>
									<details class="wp-mcp-ai-log-preview__context" style="margin-top: 10px;">
										<summary style="cursor: pointer; color: #0073aa;"><?php esc_html_e( 'Context details', 'mcp-ai-wpoos' ); ?></summary>
										<pre style="background: #fff; padding: 10px; margin-top: 10px; overflow-x: auto; border: 1px solid #ddd; border-radius: 3px; font-size: 0.85em;"><?php echo esc_html( $context_label ); ?></pre>
									</details>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<?php
				$log_file_path    = WP_MCP_AI_Logger::get_log_file_path();
				$log_file_exists  = WP_MCP_AI_Logger::does_log_file_exist();
				$log_file_size    = WP_MCP_AI_Logger::get_log_file_size();
				$log_size_display = '';

				if ( null !== $log_file_size ) {
					$log_size_display = function_exists( 'size_format' )
					? size_format( $log_file_size, 2 )
					: $log_file_size . ' bytes';
				}
				?>
				<div class="wp-mcp-ai-log-meta" style="margin-top: 15px; padding: 15px; background: #fff; border: 1px solid #ddd; border-radius: 3px;">
					<?php if ( '' !== $log_file_path ) : ?>
						<p class="description">
							<?php
							if ( $log_file_exists ) {
								if ( '' === $log_size_display ) {
									$log_size_display = __( 'Unknown size', 'mcp-ai-wpoos' );
								}

								printf(
									wp_kses(
										/* translators: 1: Path to the PHP error log. 2: Human readable size. */
										__( 'PHP error log: %1$s (%2$s).', 'mcp-ai-wpoos' ),
										array( 'code' => array() )
									),
									'<code>' . esc_html( $log_file_path ) . '</code>',
									esc_html( $log_size_display )
								);
							} else {
								printf(
									wp_kses(
										/* translators: %s: Path to the PHP error log. */
										__( 'PHP error log: %s (not created yet).', 'mcp-ai-wpoos' ),
										array( 'code' => array() )
									),
									'<code>' . esc_html( $log_file_path ) . '</code>'
								);
							}
							?>
						</p>
					<?php else : ?>
						<p class="description"><?php esc_html_e( 'Unable to determine the PHP error log location. Check your server configuration if you need to inspect or prune the log.', 'mcp-ai-wpoos' ); ?></p>
					<?php endif; ?>
				</div>
			</div>
			<?php
		}

		/**
		 * Validate section input.
		 *
		 * @param array $input Raw input.
		 * @return array|WP_Error Validated input or error.
		 */
		public function validate( $input ) {
			$errors = array();

			// Validate memory max file bytes: must be a positive integer when set (no upper limit).
			if ( isset( $input['memory_max_file_bytes'] ) ) {
				$result = WP_MCP_AI_Settings_Validator::validate_number(
					$input['memory_max_file_bytes'],
					1,    // Minimum: 1 byte.
					null  // No upper limit.
				);
				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Max Memory File Size must be a positive integer (bytes).', 'mcp-ai-wpoos' );
				}
			}

			if ( ! empty( $errors ) ) {
				return new WP_Error( 'validation_error', implode( ' ', $errors ) );
			}

			return $input;
		}

		/**
		 * Render the performance monitoring content.
		 * This includes both monitoring metrics and performance tests.
		 */
		private function render_performance_monitoring() {
			// Load performance reporter if available.
			if ( ! class_exists( 'WP_MCP_AI_Performance_Reporter' ) ) {
				require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-performance-reporter.php';
			}

			// Check if Performance section class is available.
			if ( class_exists( 'WP_MCP_AI_Section_Performance' ) ) {
				$performance_section = new WP_MCP_AI_Section_Performance();
				$performance_section->render();
			} else {
				?>
				<div class="notice notice-info inline">
					<p><?php esc_html_e( 'Performance monitoring section is not currently available.', 'mcp-ai-wpoos' ); ?></p>
				</div>
				<?php
			}
		}

		/**
		 * Render the data management content.
		 */
		private function render_data_management() {
			// Bust the post-type counts cache before reading it: core only
			// invalidates this cache on status transitions, and bulk
			// force-deletes/updates (the reseed paths) don't fire any. With
			// a persistent object cache (Redis/Memcached) the panel would
			// otherwise keep showing a stale, pre-deduplication total — the
			// "professions ballooned" symptom that drives users to the
			// destructive Replace All. One COUNT query per panel render is
			// cheap and keeps the displayed number truthful.
			wp_cache_delete( _count_posts_cache_key( 'mcp_ai_profession' ), 'counts' );

			// Get profession counts.
			$profession_count = wp_count_posts( 'mcp_ai_profession' );
			$total_count      = isset( $profession_count->publish ) ? $profession_count->publish : 0;
			$draft_count      = isset( $profession_count->draft ) ? $profession_count->draft : 0;

			// Get available profession count from knowledge base.
			$available_count = $this->get_available_profession_count();

			// Check if professions were seeded.
			$is_seeded    = get_option( WP_MCP_AI_Profession_Seeder::SEEDED_OPTION, false );
			$seeded_text  = $is_seeded ? __( 'Yes', 'mcp-ai-wpoos' ) : __( 'No', 'mcp-ai-wpoos' );
			$seeded_class = $is_seeded ? 'success' : 'warning';

			// Determine sync status.
			$sync_needed = ( $total_count < $available_count );
			$duplicates  = ( ! $sync_needed && $total_count > $available_count );

			if ( $sync_needed ) {
				$sync_status_text = __( 'Updates Available', 'mcp-ai-wpoos' );
				$sync_class       = 'warning';
			} elseif ( $duplicates ) {
				$sync_status_text = __( 'Duplicates Detected', 'mcp-ai-wpoos' );
				$sync_class       = 'error';
			} else {
				$sync_status_text = __( 'Up to Date', 'mcp-ai-wpoos' );
				$sync_class       = 'success';
			}
			?>
			<div class="wp-mcp-ai-data-management-section" style="margin-top: 30px;">
				<h3><?php esc_html_e( 'Profession Data Management', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Manage the profession templates used when creating new AI assistants. You can reload the latest profession definitions from the plugin\'s knowledge base.', 'mcp-ai-wpoos' ); ?>
				</p>

				<div class="wp-mcp-ai-profession-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
					<h4 style="margin-top: 0;"><?php esc_html_e( 'Current Status', 'mcp-ai-wpoos' ); ?></h4>
					<ul style="margin: 10px 0; padding-left: 20px;">
						<li><strong><?php esc_html_e( 'Published Professions:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $total_count ); ?></li>
						<li><strong><?php esc_html_e( 'Available in Knowledge Base:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $available_count ); ?></li>
						<?php if ( $draft_count > 0 ) : ?>
							<li><strong><?php esc_html_e( 'Draft Professions:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $draft_count ); ?></li>
						<?php endif; ?>
						<li><strong><?php esc_html_e( 'Sync Status:', 'mcp-ai-wpoos' ); ?></strong>
							<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $sync_class ); ?>">
								<?php echo esc_html( $sync_status_text ); ?>
							</span>
							<?php if ( $sync_needed ) : ?>
								<span class="description">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %d: Number of new professions */
											_n( '(%d new profession available)', '(%d new professions available)', $available_count - $total_count, 'mcp-ai-wpoos' ),
											$available_count - $total_count
										)
									);
									?>
								</span>
							<?php elseif ( $duplicates ) : ?>
								<span class="description">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %d: Number of extra professions beyond the knowledge base */
											__( '(%d more than the knowledge base — run "Update Professions" to deduplicate. This preserves existing professions and assistant links.)', 'mcp-ai-wpoos' ),
											$total_count - $available_count
										)
									);
									?>
								</span>
							<?php endif; ?>
						</li>
						<li><strong><?php esc_html_e( 'Initially Seeded:', 'mcp-ai-wpoos' ); ?></strong>
							<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $seeded_class ); ?>">
								<?php echo esc_html( $seeded_text ); ?>
							</span>
						</li>
					</ul>
					<p class="description" style="margin: 10px 0 0 0;">
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_profession' ) ); ?>">
							<?php esc_html_e( 'View all professions', 'mcp-ai-wpoos' ); ?> &rarr;
						</a>
					</p>
				</div>

				<div class="wp-mcp-ai-reseed-actions" style="margin-top: 20px;">
					<h4><?php esc_html_e( 'Reload Profession Data', 'mcp-ai-wpoos' ); ?></h4>
					<p class="description">
						<?php esc_html_e( 'Choose how to reload profession data from the plugin\'s knowledge base:', 'mcp-ai-wpoos' ); ?>
					</p>

					<div style="margin: 15px 0;">
						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-reseed-update-btn">
								<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Update Professions', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Updates existing professions and adds new ones. Your custom professions will be preserved.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-reseed-replace-btn">
								<span class="dashicons dashicons-backup" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Replace All Professions', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Deletes all existing professions and recreates them from the knowledge base. Use with caution!', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>
					</div>

					<div id="wp-mcp-ai-reseed-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				</div>

				<div class="wp-mcp-ai-playbook-sync-section" style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
					<h4><?php esc_html_e( 'Sync Profession Playbooks', 'mcp-ai-wpoos' ); ?></h4>
					<p class="description">
						<?php esc_html_e( 'Regenerate playbook attachments from the modular text files. This is useful after editing playbook content in includes/knowledge-base/profession-playbooks/', 'mcp-ai-wpoos' ); ?>
					</p>

					<?php
					// Get playbook statistics.
					$playbook_stats = $this->get_playbook_statistics();
					?>

					<div class="wp-mcp-ai-playbook-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
						<h4 style="margin-top: 0;"><?php esc_html_e( 'Playbook Status', 'mcp-ai-wpoos' ); ?></h4>
						<ul style="margin: 10px 0; padding-left: 20px;">
							<li><strong><?php esc_html_e( 'Total Playbook Attachments:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $playbook_stats['total_attachments'] ); ?></li>
							<li><strong><?php esc_html_e( 'Professions with Playbooks:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $playbook_stats['professions_with_playbooks'] ); ?> / <?php echo absint( $total_count ); ?></li>
							<li><strong><?php esc_html_e( 'Playbooks Seeded:', 'mcp-ai-wpoos' ); ?></strong>
								<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $playbook_stats['seeded'] ? 'success' : 'warning' ); ?>">
									<?php echo esc_html( $playbook_stats['seeded'] ? __( 'Yes', 'mcp-ai-wpoos' ) : __( 'No', 'mcp-ai-wpoos' ) ); ?>
								</span>
							</li>
							<?php if ( $playbook_stats['last_sync'] ) : ?>
								<li><strong><?php esc_html_e( 'Last Sync:', 'mcp-ai-wpoos' ); ?></strong> <?php echo esc_html( $playbook_stats['last_sync'] ); ?></li>
							<?php endif; ?>
							<?php if ( $playbook_stats['orphaned_playbooks'] > 0 ) : ?>
								<li style="color: #a00;"><strong><?php esc_html_e( 'Orphaned Playbooks:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $playbook_stats['orphaned_playbooks'] ); ?>
									<span class="description"><?php esc_html_e( '(old attachments no longer in use — use Delete button below to clean up)', 'mcp-ai-wpoos' ); ?></span>
								</li>
							<?php endif; ?>
						</ul>
					</div>

					<div style="margin: 15px 0;">
						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-sync-playbooks-btn">
								<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Sync Changed Playbooks', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Regenerates playbooks where content has changed and removes duplicates (fast, safe).', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-sync-playbooks-force-btn">
								<span class="dashicons dashicons-backup" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Force Regenerate All Playbooks', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Regenerates all playbooks even if unchanged and removes duplicates (slower, use after major updates).', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-delete-old-playbooks-btn" style="color: #a00;">
								<span class="dashicons dashicons-trash" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Delete Old Playbooks from Media Library', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Permanently deletes orphaned playbook attachments that are no longer associated with any profession.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>
					</div>

					<div id="wp-mcp-ai-playbook-sync-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				</div>

				<?php
				$reseed_processing      = __( 'Processing...', 'mcp-ai-wpoos' );
				$reseed_nonce           = wp_create_nonce( 'wp_mcp_ai_reseed_professions' );
				$reseed_error           = __( 'An error occurred.', 'mcp-ai-wpoos' );
				$reseed_ajax_error      = __( 'AJAX error: ', 'mcp-ai-wpoos' );
				$reseed_update_confirm  = __( 'This will update existing professions and add new ones from the knowledge base. Continue?', 'mcp-ai-wpoos' );
				$reseed_replace_confirm = __( 'WARNING: This will DELETE all existing professions and replace them with fresh data from the knowledge base. This cannot be undone! Continue?', 'mcp-ai-wpoos' );

				ob_start();
				?>
				jQuery(document).ready(function($) {
					function performReseed(actionType, buttonId) {
						var $button = $(buttonId);
						var $message = $('#wp-mcp-ai-reseed-message');
						var originalText = $button.html();

						// Disable both buttons.
						$('#wp-mcp-ai-reseed-update-btn, #wp-mcp-ai-reseed-replace-btn')
							.prop('disabled', true)
							.addClass('disabled');

						// Update button text.
						$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $reseed_processing ); ?>);

						// Hide any previous messages.
						$message.hide().removeClass('notice-success notice-error notice-warning');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'wp_mcp_ai_reseed_professions',
								action_type: actionType,
								nonce: <?php echo wp_json_encode( $reseed_nonce ); ?>
							},
							success: function(response) {
								if (response.success) {
									$message
										.removeClass('notice-error notice-warning')
										.addClass('notice-success')
										.find('p').html(response.data.message);
									$message.show();

									// Reload stats after a short delay.
									setTimeout(function() {
										location.reload();
									}, 2000);
								} else {
									$message
										.removeClass('notice-success notice-warning')
										.addClass('notice-error')
										.find('p').html(response.data.message || <?php echo wp_json_encode( $reseed_error ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').html(<?php echo wp_json_encode( $reseed_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								// Re-enable buttons and restore text.
								$('#wp-mcp-ai-reseed-update-btn, #wp-mcp-ai-reseed-replace-btn')
									.prop('disabled', false)
									.removeClass('disabled');
								$button.html(originalText);
							}
						});
					}

					$('#wp-mcp-ai-reseed-update-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $reseed_update_confirm ); ?>)) {
							performReseed('update', '#wp-mcp-ai-reseed-update-btn');
						}
					});

					$('#wp-mcp-ai-reseed-replace-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $reseed_replace_confirm ); ?>)) {
							performReseed('replace', '#wp-mcp-ai-reseed-replace-btn');
						}
					});
				});
				<?php
				$reseed_js = ob_get_clean();
				wp_print_inline_script_tag( $reseed_js );
				?>

			</div>

			<!-- AGENT ORCHESTRATION SEEDING SECTION -->
			<?php
			// Get orchestration seeding status.
			$orchestration_version = get_option( 'wp_mcp_ai_profession_orchestration_version', false );
			$orchestration_seeded  = $orchestration_version ? __( 'Yes', 'mcp-ai-wpoos' ) . ' (v' . esc_html( $orchestration_version ) . ')' : __( 'No', 'mcp-ai-wpoos' );
			$orchestration_class   = $orchestration_version ? 'success' : 'warning';

			// Get role distribution.
			$role_counts = array();
			$roles       = array( 'planner', 'executor', 'critic', 'specialist', 'generalist' );
			foreach ( $roles as $role ) {
				$query                = new WP_Query(
					array(
						'post_type'      => 'mcp_ai_profession',
						'post_status'    => 'publish',
						'posts_per_page' => -1,
						'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- meta_query required to filter assistant CPT by configuration meta; no alternative index-based query available.
							array(
								'key'   => '_wp_mcp_ai_profession_agent_role',
								'value' => $role,
							),
						),
						'fields'         => 'ids',
					)
				);
				$role_counts[ $role ] = $query->found_posts;
				wp_reset_postdata();
			}
			$total_with_roles = array_sum( $role_counts );
			?>
			<div class="wp-mcp-ai-orchestration-seeding-section" style="margin-top: 50px;">
				<h3><?php esc_html_e( 'Agent Orchestration Configuration', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Configure multi-agent orchestration settings for professions. This assigns agent roles (planner, executor, critic, specialist, generalist) and task patterns to enable coordinated multi-agent workflows.', 'mcp-ai-wpoos' ); ?>
				</p>

				<div class="wp-mcp-ai-orchestration-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
					<h4 style="margin-top: 0;"><?php esc_html_e( 'Current Status', 'mcp-ai-wpoos' ); ?></h4>
					<ul style="margin: 10px 0; padding-left: 20px;">
						<li><strong><?php esc_html_e( 'Orchestration Seeded:', 'mcp-ai-wpoos' ); ?></strong>
							<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $orchestration_class ); ?>">
								<?php echo esc_html( $orchestration_seeded ); ?>
							</span>
						</li>
						<li><strong><?php esc_html_e( 'Professions with Agent Roles:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $total_with_roles ); ?> / <?php echo absint( $total_count ); ?></li>
						<?php if ( $total_with_roles > 0 ) : ?>
							<li style="margin-left: 20px;">
								<strong><?php esc_html_e( 'Role Distribution:', 'mcp-ai-wpoos' ); ?></strong>
								<ul style="margin: 5px 0 0 20px;">
									<?php foreach ( $role_counts as $role => $count ) : ?>
										<?php if ( $count > 0 ) : ?>
											<li><?php echo esc_html( ucfirst( $role ) ); ?>: <?php echo absint( $count ); ?></li>
										<?php endif; ?>
									<?php endforeach; ?>
								</ul>
							</li>
						<?php endif; ?>
					</ul>
					<p class="description" style="margin: 10px 0 0 0;">
						<?php
						printf(
							wp_kses(
								/* translators: %s: Link to professions page */
								__( 'Edit individual profession orchestration settings in the %s metabox.', 'mcp-ai-wpoos' ),
								array( 'a' => array( 'href' => array() ) )
							),
							'<a href="' . esc_url( admin_url( 'edit.php?post_type=mcp_ai_profession' ) ) . '">' . esc_html__( 'Agent Orchestration', 'mcp-ai-wpoos' ) . '</a>'
						);
						?>
					</p>
				</div>

				<div class="wp-mcp-ai-orchestration-seed-actions" style="margin-top: 20px;">
					<h4><?php esc_html_e( 'Seed Orchestration Settings', 'mcp-ai-wpoos' ); ?></h4>
					<p class="description">
						<?php esc_html_e( 'Automatically assign agent roles to all professions based on their category and expertise. Task patterns will be created for common professions.', 'mcp-ai-wpoos' ); ?>
					</p>

					<div style="margin: 15px 0;">
						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-seed-orchestration-btn">
								<span class="dashicons dashicons-networking" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Seed Agent Orchestration', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Assigns agent roles to all professions using category-based and keyword-based heuristics. Safe to run multiple times (idempotent).', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-seed-orchestration-force-btn">
								<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Force Re-seed Orchestration', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Re-assigns all agent roles and task patterns, overwriting any existing orchestration settings.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>
					</div>

					<div id="wp-mcp-ai-orchestration-seed-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				</div>

				<?php
				$orch_processing    = __( 'Processing...', 'mcp-ai-wpoos' );
				$orch_nonce         = wp_create_nonce( 'wp_mcp_ai_seed_orchestration' );
				$orch_error         = __( 'An error occurred.', 'mcp-ai-wpoos' );
				$orch_ajax_error    = __( 'AJAX error: ', 'mcp-ai-wpoos' );
				$orch_seed_confirm  = __( 'This will assign agent roles to all professions based on their category and expertise. Continue?', 'mcp-ai-wpoos' );
				$orch_force_confirm = __( 'This will overwrite all existing orchestration settings. Continue?', 'mcp-ai-wpoos' );

				ob_start();
				?>
				jQuery(document).ready(function($) {
					function performOrchestrationSeed(force, buttonId) {
						var $button = $(buttonId);
						var $message = $('#wp-mcp-ai-orchestration-seed-message');
						var originalText = $button.html();

						// Disable both buttons.
						$('#wp-mcp-ai-seed-orchestration-btn, #wp-mcp-ai-seed-orchestration-force-btn')
							.prop('disabled', true)
							.addClass('disabled');

						// Update button text.
						$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $orch_processing ); ?>);

						// Hide any previous messages.
						$message.hide().removeClass('notice-success notice-error notice-warning');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'wp_mcp_ai_seed_orchestration',
								force: force,
								nonce: <?php echo wp_json_encode( $orch_nonce ); ?>
							},
							success: function(response) {
								if (response.success) {
									$message
										.removeClass('notice-error notice-warning')
										.addClass('notice-success')
										.find('p').html(response.data.message);
									$message.show();

									// Reload stats after a short delay.
									setTimeout(function() {
										location.reload();
									}, 2000);
								} else {
									$message
										.removeClass('notice-success notice-warning')
										.addClass('notice-error')
										.find('p').html(response.data.message || <?php echo wp_json_encode( $orch_error ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').html(<?php echo wp_json_encode( $orch_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								// Re-enable buttons and restore text.
								$('#wp-mcp-ai-seed-orchestration-btn, #wp-mcp-ai-seed-orchestration-force-btn')
									.prop('disabled', false)
									.removeClass('disabled');
								$button.html(originalText);
							}
						});
					}

					$('#wp-mcp-ai-seed-orchestration-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $orch_seed_confirm ); ?>)) {
							performOrchestrationSeed(false, '#wp-mcp-ai-seed-orchestration-btn');
						}
					});

					$('#wp-mcp-ai-seed-orchestration-force-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $orch_force_confirm ); ?>)) {
							performOrchestrationSeed(true, '#wp-mcp-ai-seed-orchestration-force-btn');
						}
					});
				});
				<?php
				$orch_js = ob_get_clean();
				wp_print_inline_script_tag( $orch_js );
				?>
			</div>

			<!-- TEAM DATA MANAGEMENT SECTION -->
			<?php
			// Get team counts for the section.
			$team_count       = wp_count_posts( 'mcp_ai_team' );
			$team_total_count = isset( $team_count->publish ) ? $team_count->publish : 0;
			$team_draft_count = isset( $team_count->draft ) ? $team_count->draft : 0;

			// Check if teams were seeded.
			if ( ! class_exists( 'WP_MCP_AI_Team_Seeder' ) ) {
				require_once WP_MCP_AI_PATH . 'includes/teams/class-wp-mcp-ai-team-seeder.php';
			}
			$team_is_seeded    = get_option( WP_MCP_AI_Team_Seeder::SEEDED_OPTION, false );
			$team_seeded_text  = $team_is_seeded ? __( 'Yes', 'mcp-ai-wpoos' ) : __( 'No', 'mcp-ai-wpoos' );
			$team_seeded_class = $team_is_seeded ? 'success' : 'warning';
			?>
			<div class="wp-mcp-ai-team-data-management-section" style="margin-top: 50px;">
				<h3><?php esc_html_e( 'Team Data Management', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Manage the team templates that group multiple professionals together. You can reload the latest team definitions from the plugin\'s knowledge base.', 'mcp-ai-wpoos' ); ?>
				</p>

				<div class="wp-mcp-ai-team-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
					<h4 style="margin-top: 0;"><?php esc_html_e( 'Current Status', 'mcp-ai-wpoos' ); ?></h4>
					<ul style="margin: 10px 0; padding-left: 20px;">
						<li><strong><?php esc_html_e( 'Published Teams:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $team_total_count ); ?></li>
						<?php if ( $team_draft_count > 0 ) : ?>
							<li><strong><?php esc_html_e( 'Draft Teams:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $team_draft_count ); ?></li>
						<?php endif; ?>
						<li><strong><?php esc_html_e( 'Initially Seeded:', 'mcp-ai-wpoos' ); ?></strong>
							<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $team_seeded_class ); ?>">
								<?php echo esc_html( $team_seeded_text ); ?>
							</span>
						</li>
					</ul>
					<p class="description" style="margin: 10px 0 0 0;">
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_team' ) ); ?>">
							<?php esc_html_e( 'View all teams', 'mcp-ai-wpoos' ); ?> &rarr;
						</a>
					</p>
				</div>

				<div class="wp-mcp-ai-reseed-team-actions" style="margin-top: 20px;">
					<h4><?php esc_html_e( 'Reload Team Data', 'mcp-ai-wpoos' ); ?></h4>
					<p class="description">
						<?php esc_html_e( 'Choose how to reload team data from the plugin\'s knowledge base:', 'mcp-ai-wpoos' ); ?>
					</p>

					<div style="margin: 15px 0;">
						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-reseed-teams-update-btn">
								<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Update Teams', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Updates existing teams and adds new ones. Your custom teams will be preserved.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-reseed-teams-replace-btn">
								<span class="dashicons dashicons-backup" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Replace All Teams', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Deletes all existing teams and recreates them from the knowledge base. Use with caution!', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>
					</div>

					<div id="wp-mcp-ai-reseed-teams-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				</div>

				<?php
				$team_processing      = __( 'Processing...', 'mcp-ai-wpoos' );
				$team_nonce           = wp_create_nonce( 'wp_mcp_ai_reseed_teams' );
				$team_error           = __( 'An error occurred.', 'mcp-ai-wpoos' );
				$team_ajax_error      = __( 'AJAX error: ', 'mcp-ai-wpoos' );
				$team_update_confirm  = __( 'This will update existing teams and add new ones from the knowledge base. Continue?', 'mcp-ai-wpoos' );
				$team_replace_confirm = __( 'WARNING: This will DELETE all existing teams and replace them with fresh data from the knowledge base. This cannot be undone! Continue?', 'mcp-ai-wpoos' );

				ob_start();
				?>
				jQuery(document).ready(function($) {
					function performTeamReseed(actionType, buttonId) {
						var $button = $(buttonId);
						var $message = $('#wp-mcp-ai-reseed-teams-message');
						var originalText = $button.html();

						// Disable both buttons.
						$('#wp-mcp-ai-reseed-teams-update-btn, #wp-mcp-ai-reseed-teams-replace-btn')
							.prop('disabled', true)
							.addClass('disabled');

						// Update button text.
						$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $team_processing ); ?>);

						// Hide any previous messages.
						$message.hide().removeClass('notice-success notice-error notice-warning');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'wp_mcp_ai_reseed_teams',
								action_type: actionType,
								nonce: <?php echo wp_json_encode( $team_nonce ); ?>
							},
							success: function(response) {
								if (response.success) {
									$message
										.removeClass('notice-error notice-warning')
										.addClass('notice-success')
										.find('p').html(response.data.message);
									$message.show();

									// Reload stats after a short delay.
									setTimeout(function() {
										location.reload();
									}, 2000);
								} else {
									$message
										.removeClass('notice-success notice-warning')
										.addClass('notice-error')
										.find('p').html(response.data.message || <?php echo wp_json_encode( $team_error ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').html(<?php echo wp_json_encode( $team_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								// Re-enable buttons and restore text.
								$('#wp-mcp-ai-reseed-teams-update-btn, #wp-mcp-ai-reseed-teams-replace-btn')
									.prop('disabled', false)
									.removeClass('disabled');
								$button.html(originalText);
							}
						});
					}

					$('#wp-mcp-ai-reseed-teams-update-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $team_update_confirm ); ?>)) {
							performTeamReseed('update', '#wp-mcp-ai-reseed-teams-update-btn');
						}
					});

					$('#wp-mcp-ai-reseed-teams-replace-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $team_replace_confirm ); ?>)) {
							performTeamReseed('replace', '#wp-mcp-ai-reseed-teams-replace-btn');
						}
					});
				});
				<?php
				$team_js = ob_get_clean();
				wp_print_inline_script_tag( $team_js );
				?>
			</div>

			<!-- TASK TEMPLATE LIBRARY SECTION -->
			<div class="wp-mcp-ai-task-template-management-section" style="margin-top: 50px;">
				<h3><?php esc_html_e( 'Task Template Library Management', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Manage the task template library used for autonomous task execution with the Ralph orchestration system. Templates provide pre-built workflows for common automation scenarios like research, content creation, and data analysis.', 'mcp-ai-wpoos' ); ?>
				</p>

				<?php
				// Get task template counts (Pro only if mcp_task_template exists).
				$has_templates          = post_type_exists( 'mcp_task_template' );
				$has_task_plans         = post_type_exists( 'mcp_task_plan' );
				$template_query         = null;
				$template_total_count   = 0;
				$template_publish_count = 0;
				$template_draft_count   = 0;

				if ( $has_templates ) {
					$template_query       = new WP_Query(
						array(
							'post_type'      => 'mcp_task_template',
							'post_status'    => 'any',
							'posts_per_page' => -1,
							'fields'         => 'ids',
						)
					);
					$template_total_count = $template_query->found_posts;

					foreach ( $template_query->posts as $template_id ) {
						$status = get_post_status( $template_id );
						if ( 'publish' === $status ) {
							++$template_publish_count;
						} elseif ( 'draft' === $status ) {
							++$template_draft_count;
						}
					}
				}

				// Get task plan counts (available in base).
				$plan_query       = null;
				$plan_total_count = 0;
				if ( $has_task_plans ) {
					$plan_query       = new WP_Query(
						array(
							'post_type'      => 'mcp_task_plan',
							'post_status'    => 'any',
							'posts_per_page' => -1,
							'fields'         => 'ids',
						)
					);
					$plan_total_count = $plan_query->found_posts;
				}

				// Check if templates were seeded.
				$template_is_seeded    = get_option( 'wp_mcp_ai_task_templates_seeded', false );
				$template_seeded_text  = $template_is_seeded ? __( 'Yes', 'mcp-ai-wpoos' ) : __( 'No', 'mcp-ai-wpoos' );
				$template_seeded_class = $template_is_seeded ? 'success' : 'warning';
				?>

				<div class="wp-mcp-ai-template-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
					<h4 style="margin-top: 0;"><?php esc_html_e( 'Current Status', 'mcp-ai-wpoos' ); ?></h4>
					<ul style="margin: 10px 0; padding-left: 20px;">
						<?php if ( $has_task_plans ) : ?>
							<li><strong><?php esc_html_e( 'Total Task Plans:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $plan_total_count ); ?></li>
						<?php endif; ?>
						<?php if ( $has_templates ) : ?>
							<li><strong><?php esc_html_e( 'Total Templates:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $template_total_count ); ?> 
								<span class="description">(Pro)</span>
							</li>
							<li><strong><?php esc_html_e( 'Published Templates:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $template_publish_count ); ?></li>
							<?php if ( $template_draft_count > 0 ) : ?>
								<li><strong><?php esc_html_e( 'Draft Templates:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $template_draft_count ); ?></li>
							<?php endif; ?>
							<li><strong><?php esc_html_e( 'Library Seeded:', 'mcp-ai-wpoos' ); ?></strong>
								<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $template_seeded_class ); ?>">
									<?php echo esc_html( $template_seeded_text ); ?>
								</span>
							</li>
						<?php endif; ?>
					</ul>
					<p class="description" style="margin: 10px 0 0 0;">
						<?php if ( $has_task_plans ) : ?>
							<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_task_plan' ) ); ?>">
								<?php esc_html_e( 'View all task plans', 'mcp-ai-wpoos' ); ?> &rarr;
							</a>
						<?php endif; ?>
						<?php if ( $has_templates && $has_task_plans ) : ?>
							&nbsp;|&nbsp;
						<?php endif; ?>
						<?php if ( $has_templates ) : ?>
							<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_task_template' ) ); ?>">
								<?php esc_html_e( 'View all task templates', 'mcp-ai-wpoos' ); ?> &rarr;
							</a>
						<?php endif; ?>
					</p>
				</div>

				<?php if ( $has_templates && defined( 'WP_MCP_AI_PRO_VERSION' ) ) : ?>
				<div class="wp-mcp-ai-seed-template-actions" style="margin-top: 20px;">
					<h4><?php esc_html_e( 'Seed Template Library (Pro)', 'mcp-ai-wpoos' ); ?></h4>
					<p class="description">
						<?php esc_html_e( 'Load pre-built professional templates for common workflows. Categories include research, content creation, data analysis, marketing, and more.', 'mcp-ai-wpoos' ); ?>
					</p>

					<div style="margin: 15px 0;">
						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-seed-templates-btn">
								<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Seed Template Library', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Adds pre-built templates without overwriting existing ones.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-seed-templates-overwrite-btn">
								<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Reseed with Overwrite', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Updates existing templates with latest versions from the library.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>
					</div>

					<div id="wp-mcp-ai-seed-templates-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				</div>

					<?php
					$tpl_seeding           = __( 'Seeding...', 'mcp-ai-wpoos' );
					$tpl_nonce             = wp_create_nonce( 'wp_mcp_ai_seed_task_templates' );
					$tpl_error             = __( 'An error occurred.', 'mcp-ai-wpoos' );
					$tpl_ajax_error        = __( 'AJAX error: ', 'mcp-ai-wpoos' );
					$tpl_seed_confirm      = __( 'This will seed the task template library with pre-built professional templates. Existing templates will not be modified. Continue?', 'mcp-ai-wpoos' );
					$tpl_overwrite_confirm = __( 'This will update existing templates with the latest versions from the library. Continue?', 'mcp-ai-wpoos' );

					ob_start();
					?>
				jQuery(document).ready(function($) {
					function performTemplateSeed(overwrite, buttonId) {
						var $button = $(buttonId);
						var $message = $('#wp-mcp-ai-seed-templates-message');
						var originalText = $button.html();

						// Disable both buttons.
						$('#wp-mcp-ai-seed-templates-btn, #wp-mcp-ai-seed-templates-overwrite-btn')
							.prop('disabled', true)
							.addClass('disabled');

						// Update button text.
						$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $tpl_seeding ); ?>);

						// Make AJAX request.
						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'wp_mcp_ai_seed_task_templates',
								overwrite: overwrite,
								nonce: <?php echo wp_json_encode( $tpl_nonce ); ?>
							},
							success: function(response) {
								if (response.success) {
									$message
										.removeClass('notice-error notice-warning')
										.addClass('notice-success')
										.find('p').html(response.data.message);
									$message.show();

									// Reload stats after a short delay.
									setTimeout(function() {
										location.reload();
									}, 2000);
								} else {
									$message
										.removeClass('notice-success notice-warning')
										.addClass('notice-error')
										.find('p').html(response.data.message || <?php echo wp_json_encode( $tpl_error ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').html(<?php echo wp_json_encode( $tpl_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								// Re-enable buttons and restore text.
								$('#wp-mcp-ai-seed-templates-btn, #wp-mcp-ai-seed-templates-overwrite-btn')
									.prop('disabled', false)
									.removeClass('disabled');
								$button.html(originalText);
							}
						});
					}

					$('#wp-mcp-ai-seed-templates-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $tpl_seed_confirm ); ?>)) {
							performTemplateSeed(false, '#wp-mcp-ai-seed-templates-btn');
						}
					});

					$('#wp-mcp-ai-seed-templates-overwrite-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $tpl_overwrite_confirm ); ?>)) {
							performTemplateSeed(true, '#wp-mcp-ai-seed-templates-overwrite-btn');
						}
					});
				});
					<?php
					$template_js = ob_get_clean();
					wp_print_inline_script_tag( $template_js );
					?>
				<?php endif; ?>
			</div>

			<!-- GEMINI COST TRACKING MIGRATION SECTION -->
			<div class="wp-mcp-ai-gemini-migration-section" style="margin-top: 50px;">
				<h3><?php esc_html_e( 'Gemini Cost Tracking Migration', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Fix historical cost tracking data where Gemini-specific tools were incorrectly attributed to OpenAI provider. This migration will identify tools that explicitly use Gemini API (tools with "gemini" in their name) and update their provider attribution and recalculate costs using correct Gemini pricing.', 'mcp-ai-wpoos' ); ?>
				</p>

				<div class="wp-mcp-ai-migration-info" style="margin: 20px 0; padding: 15px; background: #f0f6fc; border-left: 3px solid #0073aa; border-radius: 3px;">
					<h4 style="margin-top: 0;"><?php esc_html_e( 'What This Does', 'mcp-ai-wpoos' ); ?></h4>
					<ul style="margin: 10px 0; padding-left: 20px;">
						<li><?php esc_html_e( 'Identifies token tracking records for Gemini-specific tools that were incorrectly attributed to OpenAI', 'mcp-ai-wpoos' ); ?></li>
						<li><?php esc_html_e( 'Updates provider from OpenAI (or other providers) to Gemini', 'mcp-ai-wpoos' ); ?></li>
						<li><?php esc_html_e( 'Recalculates costs using correct Gemini pricing (which is typically lower than OpenAI)', 'mcp-ai-wpoos' ); ?></li>
						<li><?php esc_html_e( 'Updates the "is_estimated" flag to mark the data as actual, not estimated', 'mcp-ai-wpoos' ); ?></li>
					</ul>
					<p class="description" style="margin: 10px 0 0 0;">
						<strong><?php esc_html_e( 'Affected Tools:', 'mcp-ai-wpoos' ); ?></strong>
						generate_gemini_image, edit_gemini_image
					</p>
					<p class="description" style="margin: 10px 0 0 0;">
						<?php esc_html_e( 'Note: Tools that can use either OpenAI or Gemini based on your settings (like analyze_comment_content) are not migrated, as they may legitimately use OpenAI.', 'mcp-ai-wpoos' ); ?>
					</p>
				</div>

				<div class="wp-mcp-ai-migration-actions" style="margin-top: 20px;">
					<h4><?php esc_html_e( 'Run Migration', 'mcp-ai-wpoos' ); ?></h4>
					<p class="description">
						<?php esc_html_e( 'Preview the changes first to see what records would be updated, then run the migration to apply the fixes.', 'mcp-ai-wpoos' ); ?>
					</p>

					<div style="margin: 15px 0;">
						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-migrate-gemini-preview-btn">
								<span class="dashicons dashicons-visibility" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Preview Changes', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'See what records would be updated without making any changes.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-primary" id="wp-mcp-ai-migrate-gemini-run-btn">
								<span class="dashicons dashicons-database-import" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Run Migration', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Apply the fixes to your cost tracking data.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>
					</div>

					<div id="wp-mcp-ai-migrate-gemini-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				</div>

				<?php
				$gm_processing         = __( 'Processing...', 'mcp-ai-wpoos' );
				$gm_deleting           = __( 'Deleting...', 'mcp-ai-wpoos' );
				$gm_nonce_gemini       = wp_create_nonce( 'wp_mcp_ai_migrate_gemini_costs' );
				$gm_nonce_sync         = wp_create_nonce( 'wp_mcp_ai_sync_all_playbooks' );
				$gm_nonce_delete       = wp_create_nonce( 'wp_mcp_ai_delete_old_playbooks' );
				$gm_error              = __( 'An error occurred.', 'mcp-ai-wpoos' );
				$gm_ajax_error         = __( 'AJAX error: ', 'mcp-ai-wpoos' );
				$gm_migrate_confirm    = __( 'This will update historical cost tracking data to fix Gemini provider attribution. This cannot be undone, but you can preview the changes first. Continue?', 'mcp-ai-wpoos' );
				$gm_reload_confirm     = __( 'Migration completed successfully! Would you like to reload the page to see updated statistics?', 'mcp-ai-wpoos' );
				$gm_sync_force_confirm = __( 'This will force regenerate all profession playbooks even if unchanged. This may take a moment. Continue?', 'mcp-ai-wpoos' );
				$gm_delete_confirm     = __( 'WARNING: This will permanently delete all orphaned playbook attachments from the media library. This cannot be undone! Continue?', 'mcp-ai-wpoos' );

				ob_start();
				?>
				jQuery(document).ready(function($) {
					function performGeminiMigration(actionType, buttonId) {
						var $button = $(buttonId);
						var $message = $('#wp-mcp-ai-migrate-gemini-message');
						var originalText = $button.html();

						// Disable both buttons.
						$('#wp-mcp-ai-migrate-gemini-preview-btn, #wp-mcp-ai-migrate-gemini-run-btn')
							.prop('disabled', true)
							.addClass('disabled');

						// Update button text.
						$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $gm_processing ); ?>);

						// Hide any previous messages.
						$message.hide().removeClass('notice-success notice-error notice-warning notice-info');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'wp_mcp_ai_migrate_gemini_costs',
								action_type: actionType,
								nonce: <?php echo wp_json_encode( $gm_nonce_gemini ); ?>
							},
							success: function(response) {
								if (response.success) {
									var noticeClass = 'notice-success';
									if (response.data.dry_run && response.data.records_updated > 0) {
										noticeClass = 'notice-info';
									} else if (response.data.records_updated === 0) {
										noticeClass = 'notice-warning';
									}

									$message
										.removeClass('notice-error notice-success notice-warning notice-info')
										.addClass(noticeClass)
										.find('p').html(response.data.message);
									$message.show();

									// If actual migration was successful, offer to reload.
									if (!response.data.dry_run && response.data.records_updated > 0) {
										setTimeout(function() {
											if (confirm(<?php echo wp_json_encode( $gm_reload_confirm ); ?>)) {
												location.reload();
											}
										}, 1500);
									}
								} else {
									$message
										.removeClass('notice-success notice-warning notice-info')
										.addClass('notice-error')
										.find('p').html(response.data.message || <?php echo wp_json_encode( $gm_error ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message
									.removeClass('notice-success notice-warning notice-info')
									.addClass('notice-error')
									.find('p').html(<?php echo wp_json_encode( $gm_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								// Re-enable buttons and restore text.
								$('#wp-mcp-ai-migrate-gemini-preview-btn, #wp-mcp-ai-migrate-gemini-run-btn')
									.prop('disabled', false)
									.removeClass('disabled');
								$button.html(originalText);
							}
						});
					}

					$('#wp-mcp-ai-migrate-gemini-preview-btn').on('click', function(e) {
						e.preventDefault();
						performGeminiMigration('preview', '#wp-mcp-ai-migrate-gemini-preview-btn');
					});

					$('#wp-mcp-ai-migrate-gemini-run-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $gm_migrate_confirm ); ?>)) {
							performGeminiMigration('migrate', '#wp-mcp-ai-migrate-gemini-run-btn');
						}
					});
				});

				// Sync playbooks handlers.
				jQuery(document).ready(function($) {
					function syncPlaybooks(force) {
						var $button = force ? $('#wp-mcp-ai-sync-playbooks-force-btn') : $('#wp-mcp-ai-sync-playbooks-btn');
						var $message = $('#wp-mcp-ai-playbook-sync-message');
						var originalText = $button.html();

						// Disable both buttons.
						$('#wp-mcp-ai-sync-playbooks-btn, #wp-mcp-ai-sync-playbooks-force-btn')
							.prop('disabled', true)
							.addClass('disabled');

						// Update button text.
						$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $gm_processing ); ?>);

						// Hide any previous messages.
						$message.hide().removeClass('notice-success notice-error notice-warning');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'wp_mcp_ai_sync_all_playbooks',
								force: force ? 'true' : 'false',
								nonce: <?php echo wp_json_encode( $gm_nonce_sync ); ?>
							},
							success: function(response) {
								if (response.success) {
									$message
										.removeClass('notice-error notice-warning')
										.addClass('notice-success')
										.find('p').html(response.data.message);
									$message.show();

									// Reload after a short delay.
									setTimeout(function() {
										location.reload();
									}, 2000);
								} else {
									$message
										.removeClass('notice-success notice-warning')
										.addClass('notice-error')
										.find('p').html(response.data.message || <?php echo wp_json_encode( $gm_error ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').html(<?php echo wp_json_encode( $gm_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								// Re-enable buttons and restore text.
								$('#wp-mcp-ai-sync-playbooks-btn, #wp-mcp-ai-sync-playbooks-force-btn')
									.prop('disabled', false)
									.removeClass('disabled');
								$button.html(originalText);
							}
						});
					}

					$('#wp-mcp-ai-sync-playbooks-btn').on('click', function(e) {
						e.preventDefault();
						syncPlaybooks(false);
					});

					$('#wp-mcp-ai-sync-playbooks-force-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $gm_sync_force_confirm ); ?>)) {
							syncPlaybooks(true);
						}
					});

					$('#wp-mcp-ai-delete-old-playbooks-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $gm_delete_confirm ); ?>)) {
							deleteOldPlaybooks();
						}
					});

					function deleteOldPlaybooks() {
						var $button = $('#wp-mcp-ai-delete-old-playbooks-btn');
						var $message = $('#wp-mcp-ai-playbook-sync-message');
						var originalText = $button.html();

						// Disable all playbook buttons.
						$('#wp-mcp-ai-sync-playbooks-btn, #wp-mcp-ai-sync-playbooks-force-btn, #wp-mcp-ai-delete-old-playbooks-btn')
							.prop('disabled', true)
							.addClass('disabled');

						// Update button text.
						$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $gm_deleting ); ?>);

						// Hide any previous messages.
						$message.hide().removeClass('notice-success notice-error notice-warning');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'wp_mcp_ai_delete_old_playbooks',
								nonce: <?php echo wp_json_encode( $gm_nonce_delete ); ?>
							},
							success: function(response) {
								if (response.success) {
									$message
										.removeClass('notice-error notice-warning')
										.addClass('notice-success')
										.find('p').html(response.data.message);
									$message.show();

									// Reload after a short delay.
									setTimeout(function() {
										location.reload();
									}, 2000);
								} else {
									$message
										.removeClass('notice-success notice-warning')
										.addClass('notice-error')
										.find('p').html(response.data.message || <?php echo wp_json_encode( $gm_error ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').html(<?php echo wp_json_encode( $gm_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								// Re-enable buttons and restore text.
								$('#wp-mcp-ai-sync-playbooks-btn, #wp-mcp-ai-sync-playbooks-force-btn, #wp-mcp-ai-delete-old-playbooks-btn')
									.prop('disabled', false)
									.removeClass('disabled');
								$button.html(originalText);
							}
						});
					}
				});
				<?php
				$gemini_playbook_js = ob_get_clean();
				wp_print_inline_script_tag( $gemini_playbook_js );
				?>
			</div>

			<!-- SKILLS DATA MANAGEMENT SECTION -->
			<?php
			// Load skill registry classes.
			if ( ! class_exists( 'WP_MCP_AI_Skill_Registry' ) ) {
				require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-skill-registry.php';
			}
			if ( ! class_exists( 'WP_MCP_AI_Skill_Parser' ) ) {
				require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-skill-parser.php';
			}

			$skill_registry   = WP_MCP_AI_Skill_Registry::instance();
			$installed_skills = $skill_registry->get_all_skills();
			$installed_count  = count( $installed_skills );

			// Count bundled skills available (base + pro).
			$bundled_count        = 0;
			$bundled_dirs_to_scan = array( $skill_registry->get_bundled_skills_dir() );

			// Include pro addon bundled skills when the pro plugin is active.
			if ( defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				$pro_bundled_dir = trailingslashit( WP_MCP_AI_PRO_PATH ) . 'includes/bundled-skills';
				if ( is_dir( $pro_bundled_dir ) ) {
					$bundled_dirs_to_scan[] = $pro_bundled_dir;
				}
			}

			foreach ( $bundled_dirs_to_scan as $bundled_dir ) {
				if ( ! is_dir( $bundled_dir ) ) {
					continue;
				}
				$bundled_dirs = glob( $bundled_dir . '/*', GLOB_ONLYDIR );
				if ( is_array( $bundled_dirs ) ) {
					foreach ( $bundled_dirs as $b_dir ) {
						if ( file_exists( $b_dir . '/SKILL.md' ) ) {
							++$bundled_count;
						}
					}
				}
			}

			// Determine if bundled skills need installing.
			$skills_sync_needed = ( $installed_count < $bundled_count );
			$skills_sync_class  = $skills_sync_needed ? 'warning' : 'success';
			$skills_sync_text   = $skills_sync_needed ? __( 'Bundled Skills Available', 'mcp-ai-wpoos' ) : __( 'Up to Date', 'mcp-ai-wpoos' );
			?>
			<div class="wp-mcp-ai-skills-data-management-section" style="margin-top: 50px;">
				<h3><?php esc_html_e( 'Skills Data Management', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Manage Agent Skills (SKILL.md) installed on this site. Skills provide specialized instructions that can be attached to assistants to enhance their capabilities.', 'mcp-ai-wpoos' ); ?>
				</p>

				<div class="wp-mcp-ai-skills-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
					<h4 style="margin-top: 0;"><?php esc_html_e( 'Current Status', 'mcp-ai-wpoos' ); ?></h4>
					<ul style="margin: 10px 0; padding-left: 20px;">
						<li><strong><?php esc_html_e( 'Installed Skills:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $installed_count ); ?></li>
						<li><strong><?php esc_html_e( 'Bundled Skills Available:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $bundled_count ); ?></li>
						<li><strong><?php esc_html_e( 'Sync Status:', 'mcp-ai-wpoos' ); ?></strong>
							<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $skills_sync_class ); ?>">
								<?php echo esc_html( $skills_sync_text ); ?>
							</span>
							<?php if ( $skills_sync_needed ) : ?>
								<span class="description">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %d: Number of new bundled skills available */
											_n( '(%d bundled skill not yet installed)', '(%d bundled skills not yet installed)', $bundled_count - $installed_count, 'mcp-ai-wpoos' ),
											$bundled_count - $installed_count
										)
									);
									?>
								</span>
							<?php endif; ?>
						</li>
					</ul>
				</div>

				<div class="wp-mcp-ai-skills-actions" style="margin-top: 20px;">
					<h4><?php esc_html_e( 'Manage Skills', 'mcp-ai-wpoos' ); ?></h4>
					<p class="description">
						<?php esc_html_e( 'Refresh the skills index or install bundled skills that ship with the plugin:', 'mcp-ai-wpoos' ); ?>
					</p>

					<div style="margin: 15px 0;">
						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-refresh-skills-btn">
								<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Refresh Skills Index', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Rescans the skills directory and updates the cached index.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-install-bundled-skills-btn">
								<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Install Bundled Skills', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Installs bundled skills that are not yet installed. Existing skills are preserved.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-force-install-bundled-skills-btn">
								<span class="dashicons dashicons-backup" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Force Reinstall Bundled Skills', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Removes and reinstalls all bundled skills, resetting them to their default versions.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>
					</div>

					<div id="wp-mcp-ai-skills-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				</div>

				<?php
				// Phase 4 — Skill Packs UI.
				if ( ! class_exists( 'WP_MCP_AI_Skill_Pack_Registry' ) ) {
					require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-skill-pack-registry.php';
				}
				$skill_packs             = WP_MCP_AI_Skill_Pack_Registry::instance()->get_packs();
				$skill_pack_nonce        = wp_create_nonce( 'wp_mcp_ai_install_skill_pack' );
				$installed_skills_lookup = array();
				foreach ( $installed_skills as $_iskill ) {
					if ( isset( $_iskill['name'] ) ) {
						$installed_skills_lookup[ $_iskill['name'] ] = true;
					}
				}
				if ( ! empty( $skill_packs ) ) :
					?>
				<div class="wp-mcp-ai-skill-packs-actions" style="margin-top: 30px;">
					<h4><?php esc_html_e( 'Skill Packs', 'mcp-ai-wpoos' ); ?></h4>
					<p class="description">
						<?php esc_html_e( 'Install a curated bundle of related skills with one click. Already-installed skills are preserved.', 'mcp-ai-wpoos' ); ?>
					</p>

					<table class="widefat striped" style="margin-top: 10px;">
						<thead>
							<tr>
								<th style="width: 28%;"><?php esc_html_e( 'Pack', 'mcp-ai-wpoos' ); ?></th>
								<th><?php esc_html_e( 'Skills', 'mcp-ai-wpoos' ); ?></th>
								<th style="width: 14%;"><?php esc_html_e( 'Installed', 'mcp-ai-wpoos' ); ?></th>
								<th style="width: 16%;"><?php esc_html_e( 'Action', 'mcp-ai-wpoos' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php
							foreach ( $skill_packs as $pack ) :
								$pack_skill_count = count( $pack['skills'] );
								$pack_installed   = 0;
								foreach ( $pack['skills'] as $member ) {
									if ( isset( $installed_skills_lookup[ $member ] ) ) {
										++$pack_installed;
									}
								}
								?>
								<tr>
									<td>
										<strong><?php echo esc_html( $pack['name'] ); ?></strong>
										<br />
										<code style="font-size: 11px;"><?php echo esc_html( $pack['slug'] ); ?></code>
										<?php if ( ! empty( $pack['description'] ) ) : ?>
											<p class="description" style="margin: 4px 0 0;"><?php echo esc_html( $pack['description'] ); ?></p>
										<?php endif; ?>
									</td>
									<td>
										<?php
										$badges = array();
										foreach ( $pack['skills'] as $member ) {
											$badges[] = '<code style="display: inline-block; margin: 2px;">' . esc_html( $member ) . '</code>';
										}
										echo wp_kses(
											implode( ' ', $badges ),
											array( 'code' => array( 'style' => array() ) )
										);
										?>
									</td>
									<td>
										<?php
										echo esc_html(
											sprintf(
												/* translators: 1: installed count, 2: total count */
												__( '%1$d / %2$d', 'mcp-ai-wpoos' ),
												$pack_installed,
												$pack_skill_count
											)
										);
										?>
									</td>
									<td>
										<button type="button"
											class="button button-secondary wp-mcp-ai-install-skill-pack-btn"
											data-pack="<?php echo esc_attr( $pack['slug'] ); ?>">
											<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
											<?php esc_html_e( 'Install Pack', 'mcp-ai-wpoos' ); ?>
										</button>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>

					<div id="wp-mcp-ai-skill-pack-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				</div>
				<?php endif; ?>

				<?php
				$skills_processing      = __( 'Processing...', 'mcp-ai-wpoos' );
				$skills_nonce           = wp_create_nonce( 'wp_mcp_ai_refresh_skills' );
				$skills_error           = __( 'An error occurred.', 'mcp-ai-wpoos' );
				$skills_ajax_error      = __( 'AJAX error: ', 'mcp-ai-wpoos' );
				$skills_pack_fail       = __( 'Pack install failed.', 'mcp-ai-wpoos' );
				$skills_install_confirm = __( 'This will install any bundled skills that are not yet installed. Existing skills will be preserved. Continue?', 'mcp-ai-wpoos' );
				$skills_force_confirm   = __( 'WARNING: This will remove and reinstall all bundled skills, resetting them to their default versions. Any customizations to bundled skills will be lost. Continue?', 'mcp-ai-wpoos' );

				ob_start();
				?>
				jQuery(document).ready(function($) {
					function performSkillsAction(actionType, buttonId) {
						var $button = $(buttonId);
						var $message = $('#wp-mcp-ai-skills-message');
						var originalText = $button.html();

						// Disable all skills buttons.
						$('#wp-mcp-ai-refresh-skills-btn, #wp-mcp-ai-install-bundled-skills-btn, #wp-mcp-ai-force-install-bundled-skills-btn')
							.prop('disabled', true)
							.addClass('disabled');

						// Update button text.
						$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $skills_processing ); ?>);

						// Hide any previous messages.
						$message.hide().removeClass('notice-success notice-error notice-warning');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'wp_mcp_ai_refresh_skills',
								action_type: actionType,
								nonce: <?php echo wp_json_encode( $skills_nonce ); ?>
							},
							success: function(response) {
								if (response.success) {
									$message
										.removeClass('notice-error notice-warning')
										.addClass('notice-success')
										.find('p').html(response.data.message);
									$message.show();

									// Reload stats after a short delay.
									setTimeout(function() {
										location.reload();
									}, 2000);
								} else {
									$message
										.removeClass('notice-success notice-warning')
										.addClass('notice-error')
										.find('p').html(response.data.message || <?php echo wp_json_encode( $skills_error ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').html(<?php echo wp_json_encode( $skills_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								// Re-enable buttons and restore text.
								$('#wp-mcp-ai-refresh-skills-btn, #wp-mcp-ai-install-bundled-skills-btn, #wp-mcp-ai-force-install-bundled-skills-btn')
									.prop('disabled', false)
									.removeClass('disabled');
								$button.html(originalText);
							}
						});
					}

					$('#wp-mcp-ai-refresh-skills-btn').on('click', function(e) {
						e.preventDefault();
						performSkillsAction('refresh', '#wp-mcp-ai-refresh-skills-btn');
					});

					$('#wp-mcp-ai-install-bundled-skills-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $skills_install_confirm ); ?>)) {
							performSkillsAction('install_bundled', '#wp-mcp-ai-install-bundled-skills-btn');
						}
					});

					$('#wp-mcp-ai-force-install-bundled-skills-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $skills_force_confirm ); ?>)) {
							performSkillsAction('force_install_bundled', '#wp-mcp-ai-force-install-bundled-skills-btn');
						}
					});

					// Skill Packs (Phase 4).
					$('.wp-mcp-ai-install-skill-pack-btn').on('click', function(e) {
						e.preventDefault();
						var $btn = $(this);
						var pack = $btn.data('pack');
						var originalText = $btn.html();
						var $message = $('#wp-mcp-ai-skill-pack-message');

						$('.wp-mcp-ai-install-skill-pack-btn').prop('disabled', true).addClass('disabled');
						$btn.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $skills_processing ); ?>);
						$message.hide().removeClass('notice-success notice-error notice-warning');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'wp_mcp_ai_install_skill_pack',
								pack_slug: pack,
								nonce: <?php echo wp_json_encode( $skill_pack_nonce ); ?>
							},
							success: function(response) {
								if (response.success) {
									$message.removeClass('notice-error notice-warning').addClass('notice-success').find('p').html(response.data.message);
									$message.show();
									setTimeout(function() { location.reload(); }, 1800);
								} else {
									$message.removeClass('notice-success notice-warning').addClass('notice-error').find('p').html((response.data && response.data.message) || <?php echo wp_json_encode( $skills_pack_fail ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message.removeClass('notice-success notice-warning').addClass('notice-error').find('p').html(<?php echo wp_json_encode( $skills_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								$('.wp-mcp-ai-install-skill-pack-btn').prop('disabled', false).removeClass('disabled');
								$btn.html(originalText);
							}
						});
					});
				});
				<?php
				$skills_js = ob_get_clean();
				wp_print_inline_script_tag( $skills_js );
				?>
			</div>

			<!-- MEDIA TOOLKIT DATA MANAGEMENT SECTION -->
			<?php
			// Check if Pro addon is active and media toolkit is enabled.
			$pro_active                = defined( 'WP_MCP_AI_PRO_VERSION' );
			$media_settings            = get_option( 'wp_mcp_ai_settings', array() );
			$media_toolkit_enabled     = ! empty( $media_settings['enable_media_toolkit'] );
			$media_templates_count     = 0;
			$media_collections_count   = 0;
			$media_templates_presets   = 0;
			$media_collections_presets = 0;

			if ( $pro_active && $media_toolkit_enabled ) {
				// Count media templates.
				if ( post_type_exists( 'mcp_ai_media_tpl' ) ) {
					$tpl_counts            = wp_count_posts( 'mcp_ai_media_tpl' );
					$media_templates_count = isset( $tpl_counts->publish ) ? $tpl_counts->publish : 0;

					// Count preset templates.
					$preset_tpl_query        = new WP_Query(
						array(
							'post_type'      => 'mcp_ai_media_tpl',
							'post_status'    => 'publish',
							'posts_per_page' => -1,
							'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
								array(
									'key'   => '_mcp_ai_template_is_preset',
									'value' => true,
								),
							),
							'fields'         => 'ids',
						)
					);
					$media_templates_presets = $preset_tpl_query->found_posts;
					wp_reset_postdata();
				}

				// Count media collections.
				if ( post_type_exists( 'mcp_ai_media_coll' ) ) {
					$coll_counts             = wp_count_posts( 'mcp_ai_media_coll' );
					$media_collections_count = isset( $coll_counts->publish ) ? $coll_counts->publish : 0;

					// Count preset collections.
					$preset_coll_query         = new WP_Query(
						array(
							'post_type'      => 'mcp_ai_media_coll',
							'post_status'    => 'publish',
							'posts_per_page' => -1,
							'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
								array(
									'key'   => '_mcp_ai_collection_is_preset',
									'value' => true,
								),
							),
							'fields'         => 'ids',
						)
					);
					$media_collections_presets = $preset_coll_query->found_posts;
					wp_reset_postdata();
				}

				// Get available preset counts from the presets class.
				if ( class_exists( 'WP_MCP_AI_Media_Template_Presets' ) ) {
					$media_presets_available = count( WP_MCP_AI_Media_Template_Presets::get_presets() );
					$media_coll_available    = count( WP_MCP_AI_Media_Template_Presets::get_collection_presets() );
				} else {
					$media_presets_available = 0;
					$media_coll_available    = 0;
				}

				// Determine sync status.
				$tpl_sync_needed  = ( $media_templates_presets < $media_presets_available );
				$coll_sync_needed = ( $media_collections_presets < $media_coll_available );
				$media_seeded     = get_option( 'wp_mcp_ai_media_presets_seeded', '' );
				$coll_seeded      = get_option( 'wp_mcp_ai_media_collections_seeded', false );

				$tpl_status_text   = $tpl_sync_needed ? __( 'Updates Available', 'mcp-ai-wpoos' ) : __( 'Up to Date', 'mcp-ai-wpoos' );
				$tpl_status_class  = $tpl_sync_needed ? 'warning' : 'success';
				$coll_status_text  = $coll_sync_needed ? __( 'Presets Available', 'mcp-ai-wpoos' ) : __( 'Up to Date', 'mcp-ai-wpoos' );
				$coll_status_class = $coll_sync_needed ? 'warning' : 'success';
			}
			?>
			<div class="wp-mcp-ai-media-toolkit-data-management-section" style="margin-top: 50px;">
				<h3><?php esc_html_e( 'Media Toolkit Data Management', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Manage the pre-configured media templates and collections for the Pro Media Toolkit. Sync presets to get the latest template dimensions and collection groupings for your image processing workflows.', 'mcp-ai-wpoos' ); ?>
				</p>

				<?php if ( ! $pro_active ) : ?>
					<div class="wp-mcp-ai-media-toolkit-notice" style="margin: 15px 0; padding: 12px; background: #f0f6fc; border-left: 3px solid #0073aa; border-radius: 3px;">
						<p>
							<span class="dashicons dashicons-info" style="color: #0073aa;"></span>
							<?php esc_html_e( 'Media Toolkit presets require the Pro addon. Please install and activate the Pro addon to access pre-configured templates and collections.', 'mcp-ai-wpoos' ); ?>
						</p>
					</div>
				<?php elseif ( ! $media_toolkit_enabled ) : ?>
					<div class="wp-mcp-ai-media-toolkit-notice" style="margin: 15px 0; padding: 12px; background: #f0f6fc; border-left: 3px solid #0073aa; border-radius: 3px;">
						<p>
							<span class="dashicons dashicons-info" style="color: #0073aa;"></span>
							<?php
							printf(
								wp_kses(
									/* translators: %s: Link to toolkit settings page */
									__( 'The Media Toolkit is currently disabled. <a href="%s">Enable it in settings</a> to sync templates and collections.', 'mcp-ai-wpoos' ),
									array( 'a' => array( 'href' => array() ) )
								),
								esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=tools&subtab=features' ) )
							);
							?>
						</p>
					</div>
				<?php else : ?>
					<div class="wp-mcp-ai-media-toolkit-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
						<h4 style="margin-top: 0;"><?php esc_html_e( 'Current Status', 'mcp-ai-wpoos' ); ?></h4>
						<ul style="margin: 10px 0; padding-left: 20px;">
							<li><strong><?php esc_html_e( 'Published Templates:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $media_templates_count ); ?></li>
							<li><strong><?php esc_html_e( 'Preset Templates:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $media_templates_presets ); ?> / <?php echo absint( $media_presets_available ); ?> available</li>
							<li><strong><?php esc_html_e( 'Template Sync Status:', 'mcp-ai-wpoos' ); ?></strong>
								<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $tpl_status_class ); ?>">
									<?php echo esc_html( $tpl_status_text ); ?>
								</span>
							</li>
							<li><strong><?php esc_html_e( 'Published Collections:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $media_collections_count ); ?></li>
							<li><strong><?php esc_html_e( 'Preset Collections:', 'mcp-ai-wpoos' ); ?></strong> <?php echo absint( $media_collections_presets ); ?> / <?php echo absint( $media_coll_available ); ?> available</li>
							<li><strong><?php esc_html_e( 'Collection Sync Status:', 'mcp-ai-wpoos' ); ?></strong>
								<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $coll_status_class ); ?>">
									<?php echo esc_html( $coll_status_text ); ?>
								</span>
							</li>
						</ul>
						<p class="description" style="margin: 10px 0 0 0;">
							<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_media_tpl' ) ); ?>">
								<?php esc_html_e( 'View all media templates', 'mcp-ai-wpoos' ); ?> &rarr;
							</a>
							&nbsp;|&nbsp;
							<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_media_coll' ) ); ?>">
								<?php esc_html_e( 'View all media collections', 'mcp-ai-wpoos' ); ?> &rarr;
							</a>
						</p>
					</div>

					<div class="wp-mcp-ai-media-toolkit-actions" style="margin-top: 20px;">
						<h4><?php esc_html_e( 'Sync Media Presets', 'mcp-ai-wpoos' ); ?></h4>
						<p class="description">
							<?php esc_html_e( 'Load pre-configured template presets and collection groupings for the Media Toolkit. Templates include social media sizes, e-commerce product images, branding watermarks, and marketing graphics.', 'mcp-ai-wpoos' ); ?>
						</p>

						<div style="margin: 15px 0;">
							<p>
								<button type="button" class="button button-secondary" id="wp-mcp-ai-sync-media-templates-btn">
									<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
									<?php esc_html_e( 'Sync Media Templates &amp; Collections', 'mcp-ai-wpoos' ); ?>
								</button>
								<span class="description" style="margin-left: 10px;">
									<?php esc_html_e( 'Adds preset templates and collections without overwriting existing ones.', 'mcp-ai-wpoos' ); ?>
								</span>
							</p>

							<p>
								<button type="button" class="button button-secondary" id="wp-mcp-ai-force-reseed-media-btn">
									<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
									<?php esc_html_e( 'Force Reseed Media Presets', 'mcp-ai-wpoos' ); ?>
								</button>
								<span class="description" style="margin-left: 10px;">
									<?php esc_html_e( 'Updates existing presets with latest versions. Use after plugin updates to refresh template specs.', 'mcp-ai-wpoos' ); ?>
								</span>
							</p>
						</div>

						<div id="wp-mcp-ai-sync-media-templates-message" class="notice" style="display: none; margin: 15px 0;">
							<p></p>
						</div>
					</div>
				<?php endif; ?>
			</div>

			<!-- PLUGIN UPDATES SECTION -->
			<?php
			// Show for all builds (base and full). Base-only sees upgrade path,
			// full/GitHub builds see update checks.
			//
			// Detect GitHub/complete build by checking if the Pro addon
			// directory exists (addons/pro/mcp-ai-wpoos-pro.php). This is
			// more reliable than WP_MCP_AI_BASE_VERSION which persists even
			// after upgrading from base → complete since mcp-ai-wpoos-base.php
			// unconditionally defines the constant.
			$pro_addon_file     = WP_MCP_AI_PATH . 'addons/pro/mcp-ai-wpoos-pro.php';
			$is_github_build    = file_exists( $pro_addon_file );
			$is_base_only_build = ! $is_github_build && defined( 'WP_MCP_AI_BASE_VERSION' ) && WP_MCP_AI_BASE_VERSION;
			$update_nonce       = wp_create_nonce( 'wp_mcp_ai_plugin_update' );
			$update_error       = __( 'An error occurred.', 'mcp-ai-wpoos' );
			$update_ajax_error  = __( 'AJAX error: ', 'mcp-ai-wpoos' );

			if ( class_exists( 'WP_MCP_AI_Plugin_Updater' ) ) :
				?>
			<div class="wp-mcp-ai-plugin-updates-section" style="margin-top: 50px;">
				<?php if ( $is_github_build ) : ?>
				<!-- FULL/GITHUB BUILD: update check -->
				<h3><?php esc_html_e( 'Plugin Updates', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Check for and install updates from GitHub releases. The complete build includes the base plugin and all bundled addons.', 'mcp-ai-wpoos' ); ?>
				</p>

				<div class="wp-mcp-ai-update-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
					<h4 style="margin-top: 0;"><?php esc_html_e( 'Current Version', 'mcp-ai-wpoos' ); ?></h4>
					<ul style="margin: 10px 0; padding-left: 20px;">
						<li><strong><?php esc_html_e( 'Installed:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-installed-version"><?php echo esc_html( WP_MCP_AI_VERSION ); ?></span></li>
						<li><strong><?php esc_html_e( 'Latest:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-latest-version"><?php esc_html_e( 'Checking...', 'mcp-ai-wpoos' ); ?></span></li>
						<li id="wp-mcp-ai-update-status-li" style="display: none;">
							<strong><?php esc_html_e( 'Status:', 'mcp-ai-wpoos' ); ?></strong>
							<span id="wp-mcp-ai-update-status-text"></span>
						</li>
					</ul>
				</div>

				<div class="wp-mcp-ai-update-actions" style="margin-top: 20px;">
					<p>
						<button type="button" class="button button-secondary" id="wp-mcp-ai-check-update-btn">
							<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
							<?php esc_html_e( 'Check for Updates', 'mcp-ai-wpoos' ); ?>
						</button>
						<span class="description" style="margin-left: 10px;">
							<?php esc_html_e( 'Checks GitHub releases for a newer version of the complete plugin build.', 'mcp-ai-wpoos' ); ?>
						</span>
					</p>

					<p id="wp-mcp-ai-update-now-row" style="display: none;">
						<button type="button" class="button button-primary" id="wp-mcp-ai-update-now-btn">
							<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
							<?php esc_html_e( 'Update Now', 'mcp-ai-wpoos' ); ?>
						</button>
						<span class="description" style="margin-left: 10px;">
							<?php esc_html_e( 'Downloads and installs the latest complete build. A backup is created before updating.', 'mcp-ai-wpoos' ); ?>
						</span>
					</p>
				</div>

				<div id="wp-mcp-ai-update-message" class="notice" style="display: none; margin: 15px 0;">
					<p></p>
				</div>
			</div>

					<?php
					$update_checking  = __( 'Checking for updates...', 'mcp-ai-wpoos' );
					$update_updating  = __( 'Updating plugin...', 'mcp-ai-wpoos' );
					$update_confirm   = __( 'This will download and install the latest version of the complete plugin from GitHub. A backup will be created before updating. Continue?', 'mcp-ai-wpoos' );
					$update_uptodate  = __( 'You are running the latest version.', 'mcp-ai-wpoos' );
					$update_available = __( 'Update available!', 'mcp-ai-wpoos' );

					ob_start();
					?>
			jQuery(document).ready(function($) {
				var updateNonce = <?php echo wp_json_encode( $update_nonce ); ?>;

				// Auto-check on page load.
				checkForUpdates(true);

				function checkForUpdates(silent) {
					var $btn = $('#wp-mcp-ai-check-update-btn');
					var $msg = $('#wp-mcp-ai-update-message');

					if (!silent) {
						$btn.prop('disabled', true).find('.dashicons').addClass('spin');
						$msg.hide().removeClass('notice-success notice-error notice-warning');
						$('#wp-mcp-ai-latest-version').text(<?php echo wp_json_encode( $update_checking ); ?>);
					}

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'wp_mcp_ai_check_plugin_update',
							nonce: updateNonce
						},
						success: function(response) {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							if (response.success && response.data) {
								$('#wp-mcp-ai-latest-version').text(response.data.latest);
								if (response.data.update_available) {
									$('#wp-mcp-ai-update-status-li').show();
									$('#wp-mcp-ai-update-status-text').css('color','#46b450').text(<?php echo wp_json_encode( $update_available ); ?>);
									$('#wp-mcp-ai-update-now-row').show();
								} else {
									$('#wp-mcp-ai-update-status-li').show();
									$('#wp-mcp-ai-update-status-text').css('color','#2271b1').text(<?php echo wp_json_encode( $update_uptodate ); ?>);
									$('#wp-mcp-ai-update-now-row').hide();
								}
							} else {
								$('#wp-mcp-ai-latest-version').text('—');
								var errMsg = response.data && response.data.message ? response.data.message : <?php echo wp_json_encode( $update_error ); ?>;
								if (!silent) {
									$msg.removeClass('notice-success').addClass('notice-error').show().find('p').text(errMsg);
								}
							}
						},
						error: function() {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							$('#wp-mcp-ai-latest-version').text('—');
							if (!silent) {
								$msg.removeClass('notice-success').addClass('notice-error').show().find('p').text(<?php echo wp_json_encode( $update_ajax_error ); ?>);
							}
						}
					});
				}

				$('#wp-mcp-ai-check-update-btn').on('click', function() {
					checkForUpdates(false);
				});

				$('#wp-mcp-ai-update-now-btn').on('click', function() {
					if (!confirm(<?php echo wp_json_encode( $update_confirm ); ?>)) {
						return;
					}

					var $btn = $(this);
					var $msg = $('#wp-mcp-ai-update-message');

					$btn.prop('disabled', true).find('.dashicons').addClass('spin');
					$('#wp-mcp-ai-check-update-btn').prop('disabled', true);
					$msg.hide().removeClass('notice-success notice-error notice-warning');
					$msg.show().addClass('notice-info').find('p').text(<?php echo wp_json_encode( $update_updating ); ?>);

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'wp_mcp_ai_start_plugin_update',
							nonce: updateNonce
						},
						success: function(response) {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							$('#wp-mcp-ai-check-update-btn').prop('disabled', false);
							if (response.success) {
								$msg.removeClass('notice-info notice-error').addClass('notice-success').show()
									.find('p').text(response.data.message);
								$('#wp-mcp-ai-update-now-row').hide();
							} else {
								var errMsg = response.data && response.data.message ? response.data.message : <?php echo wp_json_encode( $update_error ); ?>;
								$msg.removeClass('notice-info notice-success').addClass('notice-error').show()
									.find('p').text(errMsg);
							}
						},
						error: function() {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							$('#wp-mcp-ai-check-update-btn').prop('disabled', false);
							$msg.removeClass('notice-info notice-success').addClass('notice-error').show()
								.find('p').text(<?php echo wp_json_encode( $update_ajax_error ); ?>);
						}
					});
				});
			});
					<?php
					$update_js = ob_get_clean();
					wp_print_inline_script_tag( $update_js );
					?>
		<?php else : ?>
			<!-- BASE-ONLY BUILD: upgrade path to complete version -->
			<h3><?php esc_html_e( 'Complete Version Available', 'mcp-ai-wpoos' ); ?></h3>
			<p class="description">
				<?php esc_html_e( 'You are running the base version from WordPress.org. Upgrade to the complete version to unlock all Pro toolkits, advanced AI features, and bundled addons.', 'mcp-ai-wpoos' ); ?>
			</p>

			<div class="wp-mcp-ai-update-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
				<h4 style="margin-top: 0;"><?php esc_html_e( 'Complete Version', 'mcp-ai-wpoos' ); ?></h4>
				<ul style="margin: 10px 0; padding-left: 20px;">
					<li><strong><?php esc_html_e( 'Installed:', 'mcp-ai-wpoos' ); ?></strong> <?php echo esc_html( WP_MCP_AI_VERSION ); ?> (base)</li>
					<li><strong><?php esc_html_e( 'Latest Complete:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-complete-version"><?php esc_html_e( 'Checking...', 'mcp-ai-wpoos' ); ?></span></li>
				</ul>
			</div>

			<div class="wp-mcp-ai-update-actions" style="margin-top: 20px;">
				<p>
					<button type="button" class="button button-secondary" id="wp-mcp-ai-check-complete-btn">
						<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
						<?php esc_html_e( 'Check Availability', 'mcp-ai-wpoos' ); ?>
					</button>
					<span class="description" style="margin-left: 10px;">
						<?php esc_html_e( 'Checks GitHub releases for the latest complete build.', 'mcp-ai-wpoos' ); ?>
					</span>
				</p>

				<p id="wp-mcp-ai-upgrade-row" style="display: none;">
					<button type="button" class="button button-primary" id="wp-mcp-ai-upgrade-complete-btn">
						<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
						<?php esc_html_e( 'Install Complete Version', 'mcp-ai-wpoos' ); ?>
					</button>
					<span class="description" style="margin-left: 10px;">
						<?php esc_html_e( 'Downloads and installs the complete plugin build including Pro addon and all toolkits.', 'mcp-ai-wpoos' ); ?>
					</span>
				</p>
			</div>

			<div id="wp-mcp-ai-upgrade-message" class="notice" style="display: none; margin: 15px 0;">
				<p></p>
			</div>

			<!-- BASE UPDATE: update the base plugin in place without upgrading to complete -->
			<div class="wp-mcp-ai-base-update-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
				<h4 style="margin-top: 0;"><?php esc_html_e( 'Base Version', 'mcp-ai-wpoos' ); ?></h4>
				<ul style="margin: 10px 0; padding-left: 20px;">
					<li><strong><?php esc_html_e( 'Installed:', 'mcp-ai-wpoos' ); ?></strong> <?php echo esc_html( WP_MCP_AI_VERSION ); ?></li>
					<li><strong><?php esc_html_e( 'Latest:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-base-latest-version"><?php esc_html_e( 'Checking...', 'mcp-ai-wpoos' ); ?></span></li>
					<li id="wp-mcp-ai-base-update-status-li" style="display: none;">
						<strong><?php esc_html_e( 'Status:', 'mcp-ai-wpoos' ); ?></strong>
						<span id="wp-mcp-ai-base-update-status-text"></span>
					</li>
				</ul>
			</div>

			<div class="wp-mcp-ai-base-update-actions" style="margin-top: 20px;">
				<p>
					<button type="button" class="button button-secondary" id="wp-mcp-ai-check-base-update-btn">
						<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
						<?php esc_html_e( 'Check for Base Updates', 'mcp-ai-wpoos' ); ?>
					</button>
					<span class="description" style="margin-left: 10px;">
						<?php esc_html_e( 'Checks GitHub releases for a newer version of the base plugin.', 'mcp-ai-wpoos' ); ?>
					</span>
				</p>

				<p id="wp-mcp-ai-base-update-now-row" style="display: none;">
					<button type="button" class="button button-primary" id="wp-mcp-ai-base-update-now-btn">
						<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
						<?php esc_html_e( 'Update Base Now', 'mcp-ai-wpoos' ); ?>
					</button>
					<span class="description" style="margin-left: 10px;">
						<?php esc_html_e( 'Downloads and installs the latest base plugin. A backup is created before updating. A separately installed Pro addon is not affected.', 'mcp-ai-wpoos' ); ?>
					</span>
				</p>
			</div>

			<div id="wp-mcp-ai-base-update-message" class="notice" style="display: none; margin: 15px 0;">
				<p></p>
			</div>

			<?php
			$complete_checking  = __( 'Checking availability...', 'mcp-ai-wpoos' );
			$complete_upgrading = __( 'Installing complete version...', 'mcp-ai-wpoos' );
			$complete_confirm   = __( 'This will download and install the complete plugin build from GitHub, which includes the Pro addon and all toolkits. If the Pro addon is currently installed as a separate plugin, it will be deactivated to avoid loading Pro twice. Continue?', 'mcp-ai-wpoos' );

			ob_start();
			?>
			jQuery(document).ready(function($) {
				// Auto-check on page load.
				checkComplete(true);

				function checkComplete(silent) {
					var $btn = $('#wp-mcp-ai-check-complete-btn');
					var $msg = $('#wp-mcp-ai-upgrade-message');

					if (!silent) {
						$btn.prop('disabled', true).find('.dashicons').addClass('spin');
						$msg.hide().removeClass('notice-success notice-error notice-warning');
					}

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'wp_mcp_ai_check_complete',
							nonce: <?php echo wp_json_encode( $update_nonce ); ?>
						},
						success: function(response) {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							if (response.success && response.data) {
								$('#wp-mcp-ai-complete-version').text(response.data.latest);
								if (response.data.available) {
									$('#wp-mcp-ai-upgrade-row').show();
									$msg.hide();
								} else {
									$('#wp-mcp-ai-upgrade-row').hide();
									// Show reason when available but explain why not.
									if (response.data.reason) {
										$msg.removeClass('notice-success notice-error').addClass('notice-warning').show()
											.find('p').text(response.data.reason);
									} else if (!silent) {
										$msg.removeClass('notice-error').addClass('notice-success').show()
											.find('p').text(<?php echo wp_json_encode( __( 'You are running the latest version.', 'mcp-ai-wpoos' ) ); ?>);
									}
								}
							} else {
								$('#wp-mcp-ai-complete-version').text('—');
								var errMsg = response.data && response.data.message ? response.data.message : <?php echo wp_json_encode( $update_error ); ?>;
								$msg.removeClass('notice-success').addClass('notice-error').show().find('p').text(errMsg);
							}
						},
						error: function() {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							$('#wp-mcp-ai-complete-version').text('—');
						}
					});
				}

				$('#wp-mcp-ai-check-complete-btn').on('click', function() {
					checkComplete(false);
				});

				$('#wp-mcp-ai-upgrade-complete-btn').on('click', function() {
					if (!confirm(<?php echo wp_json_encode( $complete_confirm ); ?>)) {
						return;
					}

					var $btn = $(this);
					var $msg = $('#wp-mcp-ai-upgrade-message');

					$btn.prop('disabled', true).find('.dashicons').addClass('spin');
					$('#wp-mcp-ai-check-complete-btn').prop('disabled', true);
					$msg.hide().removeClass('notice-success notice-error notice-warning');
					$msg.show().addClass('notice-info').find('p').text(<?php echo wp_json_encode( $complete_upgrading ); ?>);

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'wp_mcp_ai_upgrade_to_complete',
							nonce: <?php echo wp_json_encode( $update_nonce ); ?>
						},
						success: function(response) {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							$('#wp-mcp-ai-check-complete-btn').prop('disabled', false);
							if (response.success) {
								$msg.removeClass('notice-info notice-error').addClass('notice-success').show()
									.find('p').text(response.data.message);
								$('#wp-mcp-ai-upgrade-row').hide();
							} else {
								var errMsg = response.data && response.data.message ? response.data.message : <?php echo wp_json_encode( $update_error ); ?>;
								$msg.removeClass('notice-info notice-success').addClass('notice-error').show()
									.find('p').text(errMsg);
							}
						},
						error: function() {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							$('#wp-mcp-ai-check-complete-btn').prop('disabled', false);
							$msg.removeClass('notice-info notice-success').addClass('notice-error').show()
								.find('p').text(<?php echo wp_json_encode( $update_ajax_error ); ?>);
						}
					});
				});
			});
			<?php
			$complete_js = ob_get_clean();
			wp_print_inline_script_tag( $complete_js );
			?>

			<?php
			$base_checking  = __( 'Checking for base updates...', 'mcp-ai-wpoos' );
			$base_updating  = __( 'Updating base plugin...', 'mcp-ai-wpoos' );
			$base_confirm   = __( 'This will download and install the latest base plugin from GitHub. A backup will be created before updating. A separately installed Pro addon is not affected. Continue?', 'mcp-ai-wpoos' );
			$base_uptodate  = __( 'Base plugin is up to date.', 'mcp-ai-wpoos' );
			$base_available = __( 'Base plugin update available!', 'mcp-ai-wpoos' );

			ob_start();
			?>
			jQuery(document).ready(function($) {
				var baseUpdateNonce = <?php echo wp_json_encode( $update_nonce ); ?>;

				// Auto-check base on page load.
				checkBaseUpdates(true);

				function checkBaseUpdates(silent) {
					var $btn = $('#wp-mcp-ai-check-base-update-btn');
					var $msg = $('#wp-mcp-ai-base-update-message');

					if (!silent) {
						$btn.prop('disabled', true).find('.dashicons').addClass('spin');
						$msg.hide().removeClass('notice-success notice-error notice-warning');
						$('#wp-mcp-ai-base-latest-version').text(<?php echo wp_json_encode( $base_checking ); ?>);
					}

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'wp_mcp_ai_check_base_update',
							nonce: baseUpdateNonce
						},
						success: function(response) {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							if (response.success && response.data) {
								$('#wp-mcp-ai-base-latest-version').text(response.data.latest);
								if (response.data.update_available) {
									$('#wp-mcp-ai-base-update-status-li').show();
									$('#wp-mcp-ai-base-update-status-text').css('color','#46b450').text(<?php echo wp_json_encode( $base_available ); ?>);
									$('#wp-mcp-ai-base-update-now-row').show();
								} else {
									$('#wp-mcp-ai-base-update-status-li').show();
									$('#wp-mcp-ai-base-update-status-text').css('color','#2271b1').text(<?php echo wp_json_encode( $base_uptodate ); ?>);
									$('#wp-mcp-ai-base-update-now-row').hide();
								}
							} else {
								$('#wp-mcp-ai-base-latest-version').text('—');
								var errMsg = response.data && response.data.message ? response.data.message : <?php echo wp_json_encode( $update_error ); ?>;
								if (!silent) {
									$msg.removeClass('notice-success').addClass('notice-error').show().find('p').text(errMsg);
								}
							}
						},
						error: function() {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							$('#wp-mcp-ai-base-latest-version').text('—');
							if (!silent) {
								$msg.removeClass('notice-success').addClass('notice-error').show().find('p').text(<?php echo wp_json_encode( $update_ajax_error ); ?>);
							}
						}
					});
				}

				$('#wp-mcp-ai-check-base-update-btn').on('click', function() {
					checkBaseUpdates(false);
				});

				$('#wp-mcp-ai-base-update-now-btn').on('click', function() {
					if (!confirm(<?php echo wp_json_encode( $base_confirm ); ?>)) {
						return;
					}

					var $btn = $(this);
					var $msg = $('#wp-mcp-ai-base-update-message');

					$btn.prop('disabled', true).find('.dashicons').addClass('spin');
					$('#wp-mcp-ai-check-base-update-btn').prop('disabled', true);
					$msg.hide().removeClass('notice-success notice-error notice-warning');
					$msg.show().addClass('notice-info').find('p').text(<?php echo wp_json_encode( $base_updating ); ?>);

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'wp_mcp_ai_start_base_update',
							nonce: baseUpdateNonce
						},
						success: function(response) {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							$('#wp-mcp-ai-check-base-update-btn').prop('disabled', false);
							if (response.success) {
								$msg.removeClass('notice-info notice-error').addClass('notice-success').show()
									.find('p').text(response.data.message);
								$('#wp-mcp-ai-base-update-now-row').hide();
							} else {
								var errMsg = response.data && response.data.message ? response.data.message : <?php echo wp_json_encode( $update_error ); ?>;
								$msg.removeClass('notice-info notice-success').addClass('notice-error').show()
									.find('p').text(errMsg);
							}
						},
						error: function() {
							$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
							$('#wp-mcp-ai-check-base-update-btn').prop('disabled', false);
							$msg.removeClass('notice-info notice-success').addClass('notice-error').show()
								.find('p').text(<?php echo wp_json_encode( $update_ajax_error ); ?>);
						}
					});
				});
			});
			<?php
			$base_update_js = ob_get_clean();
			wp_print_inline_script_tag( $base_update_js );
			?>

		<?php endif; ?>

		<div id="wp-mcp-ai-update-message" class="notice" style="display: none; margin: 15px 0;">
			<p></p>
		</div>
	</div>
				<?php
				// Only show Pro updates when Pro is a standalone plugin (not bundled
				// inside the main plugin directory). The complete package update covers
				// both base and Pro together, so a separate Pro update is redundant.
				// Must work for both full builds ($is_github_build) and wp.org base
				// installs with a separately installed Pro addon.
				$pro_is_standalone = defined( 'WP_MCP_AI_PRO_VERSION' )
				&& defined( 'WP_MCP_AI_PRO_PATH' )
				&& 0 !== strpos( trailingslashit( untrailingslashit( WP_MCP_AI_PRO_PATH ) ), trailingslashit( untrailingslashit( WP_MCP_AI_PATH ) ) );

				// The installed Pro version comes from the Pro addon's plugin
				// header (stamped by the build script). The WP_MCP_AI_PRO_VERSION
				// constant is maintained manually and has drifted from the
				// shipped version in the past.
				$pro_installed_version = method_exists( 'WP_MCP_AI_Plugin_Updater', 'get_pro_installed_version' )
					? WP_MCP_AI_Plugin_Updater::get_pro_installed_version()
					: ( defined( 'WP_MCP_AI_PRO_VERSION' ) ? WP_MCP_AI_PRO_VERSION : '' );

				if ( $pro_is_standalone ) :
					?>
		<div class="wp-mcp-ai-pro-updates-section" style="margin-top: 50px; padding-top: 20px; border-top: 1px solid #ddd;">
			<h3><?php esc_html_e( 'Pro Addon Updates', 'mcp-ai-wpoos' ); ?></h3>
			<p class="description">
					<?php esc_html_e( 'Check for and install Pro addon updates from GitHub releases. The Pro addon provides advanced AI toolkits and integrations.', 'mcp-ai-wpoos' ); ?>
			</p>

			<div class="wp-mcp-ai-pro-update-stats" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
				<h4 style="margin-top: 0;"><?php esc_html_e( 'Pro Addon Version', 'mcp-ai-wpoos' ); ?></h4>
				<ul style="margin: 10px 0; padding-left: 20px;">
					<li><strong><?php esc_html_e( 'Installed:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-pro-installed-version"><?php echo esc_html( $pro_installed_version ); ?></span></li>
					<li><strong><?php esc_html_e( 'Latest:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-pro-latest-version"><?php esc_html_e( 'Checking...', 'mcp-ai-wpoos' ); ?></span></li>
					<li id="wp-mcp-ai-pro-update-status-li" style="display: none;">
						<strong><?php esc_html_e( 'Status:', 'mcp-ai-wpoos' ); ?></strong>
						<span id="wp-mcp-ai-pro-update-status-text"></span>
					</li>
				</ul>
			</div>

			<div class="wp-mcp-ai-pro-update-actions" style="margin-top: 20px;">
				<p>
					<button type="button" class="button button-secondary" id="wp-mcp-ai-check-pro-update-btn">
						<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
						<?php esc_html_e( 'Check for Pro Updates', 'mcp-ai-wpoos' ); ?>
					</button>
					<span class="description" style="margin-left: 10px;">
						<?php esc_html_e( 'Checks GitHub releases for a newer version of the Pro addon.', 'mcp-ai-wpoos' ); ?>
					</span>
				</p>

				<p id="wp-mcp-ai-pro-update-now-row" style="display: none;">
					<button type="button" class="button button-primary" id="wp-mcp-ai-pro-update-now-btn">
						<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
						<?php esc_html_e( 'Update Pro Now', 'mcp-ai-wpoos' ); ?>
					</button>
					<span class="description" style="margin-left: 10px;">
						<?php esc_html_e( 'Downloads and installs the latest Pro addon. A backup is created before updating.', 'mcp-ai-wpoos' ); ?>
					</span>
				</p>
			</div>

			<div id="wp-mcp-ai-pro-update-message" class="notice" style="display: none; margin: 15px 0;">
				<p></p>
			</div>
		</div>

					<?php
					$pro_update_checking  = __( 'Checking for Pro updates...', 'mcp-ai-wpoos' );
					$pro_update_updating  = __( 'Updating Pro addon...', 'mcp-ai-wpoos' );
					$pro_update_confirm   = __( 'This will download and install the latest version of the Pro addon from GitHub. A backup will be created before updating. Continue?', 'mcp-ai-wpoos' );
					$pro_update_uptodate  = __( 'Pro addon is up to date.', 'mcp-ai-wpoos' );
					$pro_update_available = __( 'Pro addon update available!', 'mcp-ai-wpoos' );

					ob_start();
					?>
		jQuery(document).ready(function($) {
			var updateNonce = <?php echo wp_json_encode( $update_nonce ); ?>;

			// Auto-check Pro on page load.
			checkProUpdates(true);

			function checkProUpdates(silent) {
				var $btn = $('#wp-mcp-ai-check-pro-update-btn');
				var $msg = $('#wp-mcp-ai-pro-update-message');

				if (!silent) {
					$btn.prop('disabled', true).find('.dashicons').addClass('spin');
					$msg.hide().removeClass('notice-success notice-error notice-warning');
					$('#wp-mcp-ai-pro-latest-version').text(<?php echo wp_json_encode( $pro_update_checking ); ?>);
				}

				$.ajax({
					url: ajaxurl,
					type: 'POST',
					data: {
						action: 'wp_mcp_ai_check_pro_update',
						nonce: updateNonce
					},
					success: function(response) {
						$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
						if (response.success && response.data) {
							$('#wp-mcp-ai-pro-latest-version').text(response.data.latest);
							if (response.data.update_available) {
								$('#wp-mcp-ai-pro-update-status-li').show();
								$('#wp-mcp-ai-pro-update-status-text').css('color','#46b450').text(<?php echo wp_json_encode( $pro_update_available ); ?>);
								$('#wp-mcp-ai-pro-update-now-row').show();
							} else {
								$('#wp-mcp-ai-pro-update-status-li').show();
								$('#wp-mcp-ai-pro-update-status-text').css('color','#2271b1').text(<?php echo wp_json_encode( $pro_update_uptodate ); ?>);
								$('#wp-mcp-ai-pro-update-now-row').hide();
							}
						} else {
							$('#wp-mcp-ai-pro-latest-version').text('—');
							var errMsg = response.data && response.data.message ? response.data.message : <?php echo wp_json_encode( $update_error ); ?>;
							if (!silent) {
								$msg.removeClass('notice-success').addClass('notice-error').show().find('p').text(errMsg);
							}
						}
					},
					error: function() {
						$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
						$('#wp-mcp-ai-pro-latest-version').text('—');
						if (!silent) {
							$msg.removeClass('notice-success').addClass('notice-error').show().find('p').text(<?php echo wp_json_encode( $update_ajax_error ); ?>);
						}
					}
				});
			}

			$('#wp-mcp-ai-check-pro-update-btn').on('click', function() {
				checkProUpdates(false);
			});

			$('#wp-mcp-ai-pro-update-now-btn').on('click', function() {
				if (!confirm(<?php echo wp_json_encode( $pro_update_confirm ); ?>)) {
					return;
				}

				var $btn = $(this);
				var $msg = $('#wp-mcp-ai-pro-update-message');

				$btn.prop('disabled', true).find('.dashicons').addClass('spin');
				$('#wp-mcp-ai-check-pro-update-btn').prop('disabled', true);
				$msg.hide().removeClass('notice-success notice-error notice-warning');
				$msg.show().addClass('notice-info').find('p').text(<?php echo wp_json_encode( $pro_update_updating ); ?>);

				$.ajax({
					url: ajaxurl,
					type: 'POST',
					data: {
						action: 'wp_mcp_ai_start_pro_update',
						nonce: updateNonce
					},
					success: function(response) {
						$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
						$('#wp-mcp-ai-check-pro-update-btn').prop('disabled', false);
						if (response.success) {
							$msg.removeClass('notice-info notice-error').addClass('notice-success').show()
								.find('p').text(response.data.message);
							$('#wp-mcp-ai-pro-update-now-row').hide();
						} else {
							var errMsg = response.data && response.data.message ? response.data.message : <?php echo wp_json_encode( $update_error ); ?>;
							$msg.removeClass('notice-info notice-success').addClass('notice-error').show()
								.find('p').text(errMsg);
						}
					},
					error: function() {
						$btn.prop('disabled', false).find('.dashicons').removeClass('spin');
						$('#wp-mcp-ai-check-pro-update-btn').prop('disabled', false);
						$msg.removeClass('notice-info notice-success').addClass('notice-error').show()
							.find('p').text(<?php echo wp_json_encode( $update_ajax_error ); ?>);
					}
				});
			});
		});
					<?php
					$pro_update_js = ob_get_clean();
					wp_print_inline_script_tag( $pro_update_js );
					?>
			<?php endif; ?>
	<?php endif; // Close class_exists( 'WP_MCP_AI_Plugin_Updater' ). ?>
</div>

			<?php
			$media_sync_processing    = __( 'Syncing...', 'mcp-ai-wpoos' );
			$media_sync_nonce         = wp_create_nonce( 'wp_mcp_ai_sync_media_templates' );
			$media_sync_error         = __( 'An error occurred.', 'mcp-ai-wpoos' );
			$media_sync_ajax_error    = __( 'AJAX error: ', 'mcp-ai-wpoos' );
			$media_sync_seed_confirm  = __( 'This will add pre-configured media templates and collections without modifying existing ones. Continue?', 'mcp-ai-wpoos' );
			$media_sync_force_confirm = __( 'This will update all preset media templates and collections with the latest versions. Existing presets will be overwritten. Continue?', 'mcp-ai-wpoos' );

			ob_start();
			?>
			jQuery(document).ready(function($) {
				function performMediaSync(actionType, buttonId) {
					var $button = $(buttonId);
					var $message = $('#wp-mcp-ai-sync-media-templates-message');
					var originalText = $button.html();

					// Disable both buttons.
					$('#wp-mcp-ai-sync-media-templates-btn, #wp-mcp-ai-force-reseed-media-btn')
						.prop('disabled', true)
						.addClass('disabled');

					// Update button text.
					$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $media_sync_processing ); ?>);

					// Hide any previous messages.
					$message.hide().removeClass('notice-success notice-error notice-warning');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'wp_mcp_ai_sync_media_templates',
							action_type: actionType,
							nonce: <?php echo wp_json_encode( $media_sync_nonce ); ?>
						},
						success: function(response) {
							if (response.success) {
								$message
									.removeClass('notice-error notice-warning')
									.addClass('notice-success')
									.find('p').html(response.data.message);
								$message.show();

								// Reload stats after a short delay.
								setTimeout(function() {
									location.reload();
								}, 2000);
							} else {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').html(response.data.message || <?php echo wp_json_encode( $media_sync_error ); ?>);
								$message.show();
							}
						},
						error: function(xhr, status, error) {
							$message
								.removeClass('notice-success notice-warning')
								.addClass('notice-error')
								.find('p').html(<?php echo wp_json_encode( $media_sync_ajax_error ); ?> + error);
							$message.show();
						},
						complete: function() {
							// Re-enable buttons and restore text.
							$('#wp-mcp-ai-sync-media-templates-btn, #wp-mcp-ai-force-reseed-media-btn')
								.prop('disabled', false)
								.removeClass('disabled');
							$button.html(originalText);
						}
					});
				}

				$('#wp-mcp-ai-sync-media-templates-btn').on('click', function(e) {
					e.preventDefault();
					if (confirm(<?php echo wp_json_encode( $media_sync_seed_confirm ); ?>)) {
						performMediaSync('seed', '#wp-mcp-ai-sync-media-templates-btn');
					}
				});

				$('#wp-mcp-ai-force-reseed-media-btn').on('click', function(e) {
					e.preventDefault();
					if (confirm(<?php echo wp_json_encode( $media_sync_force_confirm ); ?>)) {
						performMediaSync('force_reseed', '#wp-mcp-ai-force-reseed-media-btn');
					}
				});
			});
			<?php
			$media_sync_js = ob_get_clean();
			wp_print_inline_script_tag( $media_sync_js );
			?>

			<!-- PRODUCTION CLEANUP SECTION -->
			<div class="wp-mcp-ai-production-cleanup-section" style="margin-top: 50px; padding-top: 20px; border-top: 1px solid #ddd;">
				<h3><?php esc_html_e( 'Production Cleanup', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Remove development-only files from this cloned installation to make it production-ready. These actions are permanent on this server and cannot be undone; re-cloning the repository will restore the files.', 'mcp-ai-wpoos' ); ?>
				</p>

				<div class="wp-mcp-ai-cleanup-actions" style="margin-top: 20px;">
					<div style="margin: 15px 0;">
						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-clear-test-files-btn" style="color: #a00;">
								<span class="dashicons dashicons-trash" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Clear Test Files', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Removes PHPUnit test suites and fixtures. Safe to clear on a production server; re-cloning the repo restores them.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>

						<p>
							<button type="button" class="button button-secondary" id="wp-mcp-ai-clear-dev-files-btn" style="color: #a00;">
								<span class="dashicons dashicons-trash" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Clear Dev &amp; Build Files', 'mcp-ai-wpoos' ); ?>
							</button>
							<span class="description" style="margin-left: 10px;">
								<?php esc_html_e( 'Removes build tooling, documentation, CI configs, and dev scripts not needed in production. The plugin continues to function normally after removal.', 'mcp-ai-wpoos' ); ?>
							</span>
						</p>
					</div>

					<div id="wp-mcp-ai-cleanup-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				</div>

				<?php
				$cleanup_processing   = __( 'Processing...', 'mcp-ai-wpoos' );
				$cleanup_error        = __( 'An error occurred.', 'mcp-ai-wpoos' );
				$cleanup_ajax_error   = __( 'AJAX error: ', 'mcp-ai-wpoos' );
				$cleanup_test_nonce   = wp_create_nonce( 'wp_mcp_ai_clear_test_files' );
				$cleanup_dev_nonce    = wp_create_nonce( 'wp_mcp_ai_clear_dev_files' );
				$cleanup_test_confirm = __( 'This will permanently delete the tests directory and all PHPUnit configuration files. This cannot be undone on this server. Continue?', 'mcp-ai-wpoos' );
				$cleanup_dev_confirm  = __( 'This will permanently delete developer-only files (docs, build tools, CI configs, bin scripts). This cannot be undone on this server. Continue?', 'mcp-ai-wpoos' );

				ob_start();
				?>
				jQuery(document).ready(function($) {
					function performCleanup(action, buttonId, nonce) {
						var $button = $(buttonId);
						var $message = $('#wp-mcp-ai-cleanup-message');
						var originalText = $button.html();

						// Disable both buttons.
						$('#wp-mcp-ai-clear-test-files-btn, #wp-mcp-ai-clear-dev-files-btn')
							.prop('disabled', true)
							.addClass('disabled');

						// Update button text.
						$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $cleanup_processing ); ?>);

						// Hide any previous messages.
						$message.hide().removeClass('notice-success notice-error notice-warning');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: action,
								nonce: nonce
							},
							success: function(response) {
								if (response.success) {
									$message
										.removeClass('notice-error notice-warning')
										.addClass('notice-success')
										.find('p').html(response.data.message);
									$message.show();
								} else {
									$message
										.removeClass('notice-success notice-warning')
										.addClass('notice-error')
										.find('p').html(response.data.message || <?php echo wp_json_encode( $cleanup_error ); ?>);
									$message.show();
								}
							},
							error: function(xhr, status, error) {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').html(<?php echo wp_json_encode( $cleanup_ajax_error ); ?> + error);
								$message.show();
							},
							complete: function() {
								// Re-enable buttons and restore text.
								$('#wp-mcp-ai-clear-test-files-btn, #wp-mcp-ai-clear-dev-files-btn')
									.prop('disabled', false)
									.removeClass('disabled');
								$button.html(originalText);
							}
						});
					}

					$('#wp-mcp-ai-clear-test-files-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $cleanup_test_confirm ); ?>)) {
							performCleanup('wp_mcp_ai_clear_test_files', '#wp-mcp-ai-clear-test-files-btn', <?php echo wp_json_encode( $cleanup_test_nonce ); ?>);
						}
					});

					$('#wp-mcp-ai-clear-dev-files-btn').on('click', function(e) {
						e.preventDefault();
						if (confirm(<?php echo wp_json_encode( $cleanup_dev_confirm ); ?>)) {
							performCleanup('wp_mcp_ai_clear_dev_files', '#wp-mcp-ai-clear-dev-files-btn', <?php echo wp_json_encode( $cleanup_dev_nonce ); ?>);
						}
					});
				});
				<?php
				$cleanup_js = ob_get_clean();
				wp_print_inline_script_tag( $cleanup_js );
				?>
			</div>
			<?php
			$this->render_log_buffer_maintenance_section();
			$this->render_transcript_mining_section();
		}

		/**
		 * Render the log buffer maintenance subsection.
		 *
		 * The rolling `wp_mcp_ai_recent_errors` and `wp_mcp_ai_recent_activity`
		 * option rows are capped per entry at write time, but entries written before
		 * that cap existed still carry their full context, which can include a
		 * complete assistant system prompt. Compacting rewrites those entries in
		 * place so the space is reclaimed without losing the log history.
		 *
		 * @since 1.8.0
		 *
		 * @return void
		 */
		private function render_log_buffer_maintenance_section() {
			if ( ! class_exists( 'WP_MCP_AI_Logger' ) ) {
				return;
			}

			$stats       = WP_MCP_AI_Logger::get_recent_buffer_stats();
			$total_bytes = isset( $stats['total_bytes'] ) ? (int) $stats['total_bytes'] : 0;
			$buffers     = isset( $stats['buffers'] ) && is_array( $stats['buffers'] ) ? $stats['buffers'] : array();

			// Flag anything above 512 KB as worth reclaiming. Both rows together sit
			// well under this once the per-entry budget has been applied.
			$bloat_threshold = 512 * KB_IN_BYTES;
			$is_bloated      = $total_bytes > $bloat_threshold;
			$accent_colour   = $is_bloated ? '#d63638' : '#2271b1';
			?>
			<div class='wp-mcp-ai-log-buffer-maintenance-section' style='margin-top: 50px;'>
				<h3><?php esc_html_e( 'Log Buffer Maintenance', 'mcp-ai-wpoos' ); ?></h3>
				<p class='description'>
					<?php esc_html_e( 'NV oOS keeps rolling buffers of recent errors and activity in two database options. Each new entry is size-capped, but entries written by earlier plugin versions kept their full context, including complete assistant system prompts. Compacting rewrites those entries so the space is reclaimed without losing your log history.', 'mcp-ai-wpoos' ); ?>
				</p>

				<div class='wp-mcp-ai-log-buffer-stats' style='margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid <?php echo esc_attr( $accent_colour ); ?>; border-radius: 3px;'>
					<h4 style='margin-top: 0;'><?php esc_html_e( 'Current Storage', 'mcp-ai-wpoos' ); ?></h4>
					<table class='widefat striped' style='max-width: 720px; margin-top: 10px;'>
						<thead>
							<tr>
								<th><?php esc_html_e( 'Buffer', 'mcp-ai-wpoos' ); ?></th>
								<th><?php esc_html_e( 'Option', 'mcp-ai-wpoos' ); ?></th>
								<th><?php esc_html_e( 'Entries', 'mcp-ai-wpoos' ); ?></th>
								<th><?php esc_html_e( 'Stored Size', 'mcp-ai-wpoos' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $buffers as $buffer ) : ?>
								<tr>
									<td><?php echo esc_html( isset( $buffer['label'] ) ? $buffer['label'] : '' ); ?></td>
									<td><code><?php echo esc_html( isset( $buffer['option'] ) ? $buffer['option'] : '' ); ?></code></td>
									<td>
										<?php
										echo esc_html(
											sprintf(
												/* translators: 1: current entry count, 2: retention limit. */
												__( '%1$d of %2$d', 'mcp-ai-wpoos' ),
												isset( $buffer['entries'] ) ? (int) $buffer['entries'] : 0,
												isset( $buffer['limit'] ) ? (int) $buffer['limit'] : 0
											)
										);
										?>
									</td>
									<td><?php echo esc_html( size_format( max( 0, isset( $buffer['bytes'] ) ? (int) $buffer['bytes'] : 0 ), 2 ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan='3'><?php esc_html_e( 'Total', 'mcp-ai-wpoos' ); ?></th>
								<th><?php echo esc_html( size_format( max( 0, $total_bytes ), 2 ) ); ?></th>
							</tr>
						</tfoot>
					</table>

					<?php if ( $is_bloated ) : ?>
						<p style='margin-bottom: 0; color: #d63638;'>
							<span class='dashicons dashicons-warning' style='margin-top: 3px;'></span>
							<?php
							echo esc_html(
								sprintf(
									/* translators: %s: human-readable size threshold. */
									__( 'These buffers are larger than %s. Every log write re-reads and rewrites the whole row, so compacting will measurably reduce database work.', 'mcp-ai-wpoos' ),
									size_format( $bloat_threshold )
								)
							);
							?>
						</p>
					<?php endif; ?>
				</div>

				<div class='wp-mcp-ai-log-buffer-actions'>
					<p>
						<button type='button' class='button button-primary' id='wp-mcp-ai-compact-log-buffers-btn'>
							<span class='dashicons dashicons-editor-contract' style='margin-top: 3px;'></span>
							<?php esc_html_e( 'Compact Log Buffers', 'mcp-ai-wpoos' ); ?>
						</button>
						<span class='description' style='margin-left: 10px;'>
							<?php esc_html_e( 'Recommended. Rewrites stored entries to reclaim space and keeps your log history.', 'mcp-ai-wpoos' ); ?>
						</span>
					</p>

					<p>
						<button type='button' class='button button-secondary' id='wp-mcp-ai-clear-log-buffers-btn' style='color: #a00;'>
							<span class='dashicons dashicons-trash' style='margin-top: 3px;'></span>
							<?php esc_html_e( 'Delete All Log Entries', 'mcp-ai-wpoos' ); ?>
						</button>
						<span class='description' style='margin-left: 10px;'>
							<?php esc_html_e( 'Empties both buffers completely. Recent error and activity history will be lost.', 'mcp-ai-wpoos' ); ?>
						</span>
					</p>
				</div>

				<div id='wp-mcp-ai-log-buffer-message' class='notice' style='display: none; margin: 15px 0;'>
					<p></p>
				</div>
			</div>
			<?php
			$this->print_log_buffer_maintenance_script();
		}

		/**
		 * Print the inline script driving the log buffer maintenance buttons.
		 *
		 * @since 1.8.0
		 *
		 * @return void
		 */
		private function print_log_buffer_maintenance_script() {
			$nonce         = wp_create_nonce( 'wp_mcp_ai_maintain_log_buffers' );
			$processing    = __( 'Working...', 'mcp-ai-wpoos' );
			$generic_error = __( 'An error occurred.', 'mcp-ai-wpoos' );
			$ajax_error    = __( 'AJAX error: ', 'mcp-ai-wpoos' );
			$clear_confirm = __( 'WARNING: This permanently deletes all stored error and activity log entries. This cannot be undone. Continue?', 'mcp-ai-wpoos' );

			ob_start();
			?>
			jQuery(document).ready(function($) {
				var buttons = '#wp-mcp-ai-compact-log-buffers-btn, #wp-mcp-ai-clear-log-buffers-btn';

				function maintainBuffers(actionType, buttonId) {
					var $button = $(buttonId);
					var $message = $('#wp-mcp-ai-log-buffer-message');
					var originalText = $button.html();

					$(buttons).prop('disabled', true).addClass('disabled');
					$button.html('<span class="dashicons dashicons-update spin" style="margin-top: 3px;"></span> ' + <?php echo wp_json_encode( $processing ); ?>);
					$message.hide().removeClass('notice-success notice-error notice-warning');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'wp_mcp_ai_maintain_log_buffers',
							action_type: actionType,
							nonce: <?php echo wp_json_encode( $nonce ); ?>
						},
						success: function(response) {
							if (response.success) {
								$message
									.removeClass('notice-error notice-warning')
									.addClass('notice-success')
									.find('p').text(response.data.message);
								$message.show();

								// Reload so the storage table reflects the new sizes.
								setTimeout(function() {
									location.reload();
								}, 2000);
							} else {
								$message
									.removeClass('notice-success notice-warning')
									.addClass('notice-error')
									.find('p').text((response.data && response.data.message) ? response.data.message : <?php echo wp_json_encode( $generic_error ); ?>);
								$message.show();
							}
						},
						error: function(xhr, status, error) {
							$message
								.removeClass('notice-success notice-warning')
								.addClass('notice-error')
								.find('p').text(<?php echo wp_json_encode( $ajax_error ); ?> + error);
							$message.show();
						},
						complete: function() {
							$(buttons).prop('disabled', false).removeClass('disabled');
							$button.html(originalText);
						}
					});
				}

				$('#wp-mcp-ai-compact-log-buffers-btn').on('click', function(e) {
					e.preventDefault();
					maintainBuffers('compact', '#wp-mcp-ai-compact-log-buffers-btn');
				});

				$('#wp-mcp-ai-clear-log-buffers-btn').on('click', function(e) {
					e.preventDefault();
					if (confirm(<?php echo wp_json_encode( $clear_confirm ); ?>)) {
						maintainBuffers('clear', '#wp-mcp-ai-clear-log-buffers-btn');
					}
				});
			});
			<?php
			wp_print_inline_script_tag( ob_get_clean() );
		}

		/**
		 * Render the "Mine Memories from Transcripts" subsection.
		 *
		 * Drives the slice-2 REST endpoints under `/mcp-ai/v1/transcript-mining/`:
		 * - POST /jobs                — enqueue a mining job
		 * - GET  /jobs/{id}            — poll progress
		 * - POST /jobs/{id}/cancel     — cancel
		 *
		 * Authentication uses the standard WP REST cookie-auth path with an
		 * inline `wp_rest` nonce, matching how every other admin-driven REST
		 * call in this plugin authenticates. The endpoint itself is gated by
		 * `manage_options` in {@see WP_MCP_AI_REST_Transcript_Mining_Controller}.
		 *
		 * @return void
		 */
		private function render_transcript_mining_section() {
			$assistants = get_posts(
				array(
					'post_type'      => 'mcp_ai_assistant',
					'post_status'    => 'publish',
					'posts_per_page' => 100, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- Bounded admin selector; sites with more than 100 published assistants can use the Assistants post-type screen and target the rare ones via direct ID entry in a follow-up iteration.
					'orderby'        => 'title',
					'order'          => 'ASC',
					'fields'         => 'ids',
				)
			);
			?>
			<div class="wp-mcp-ai-transcript-mining-section" style="margin-top: 50px; padding-top: 20px; border-top: 1px solid #ddd;">
				<h3><?php esc_html_e( 'Mine Memories from Transcripts', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Retroactively extract durable memories from stored chat transcripts for a chosen assistant. Sessions are processed in small batches by a background worker so the page never blocks; you can poll progress and cancel at any time.', 'mcp-ai-wpoos' ); ?>
				</p>

				<?php if ( empty( $assistants ) ) : ?>
					<p>
						<em><?php esc_html_e( 'No published assistants found. Create at least one assistant before mining transcripts.', 'mcp-ai-wpoos' ); ?></em>
					</p>
				<?php else : ?>
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="wp-mcp-ai-tx-mine-assistant"><?php esc_html_e( 'Assistant', 'mcp-ai-wpoos' ); ?></label>
								</th>
								<td>
									<select id="wp-mcp-ai-tx-mine-assistant" class="regular-text">
										<?php foreach ( $assistants as $assistant_id ) : ?>
											<option value="<?php echo esc_attr( (string) $assistant_id ); ?>">
												<?php echo esc_html( get_the_title( $assistant_id ) . ' (#' . (string) $assistant_id . ')' ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="wp-mcp-ai-tx-mine-batch-size"><?php esc_html_e( 'Batch size', 'mcp-ai-wpoos' ); ?></label>
								</th>
								<td>
									<input type="number" id="wp-mcp-ai-tx-mine-batch-size" class="small-text" value="10" min="1" max="50" />
									<p class="description">
										<?php esc_html_e( 'Sessions processed per cron tick (1–50).', 'mcp-ai-wpoos' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e( 'Options', 'mcp-ai-wpoos' ); ?></th>
								<td>
									<label>
										<input type="checkbox" id="wp-mcp-ai-tx-mine-only-unextracted" checked />
										<?php esc_html_e( 'Skip transcripts that have already been mined (recommended).', 'mcp-ai-wpoos' ); ?>
									</label>
									<br />
									<label>
										<input type="checkbox" id="wp-mcp-ai-tx-mine-dry-run" />
										<?php esc_html_e( 'Dry run — extract candidates without writing memories.', 'mcp-ai-wpoos' ); ?>
									</label>
								</td>
							</tr>
						</tbody>
					</table>

					<p>
						<button type="button" class="button button-primary" id="wp-mcp-ai-tx-mine-start-btn">
							<span class="dashicons dashicons-search" style="margin-top: 3px;"></span>
							<?php esc_html_e( 'Start Mining', 'mcp-ai-wpoos' ); ?>
						</button>
						<button type="button" class="button button-secondary" id="wp-mcp-ai-tx-mine-cancel-btn" disabled style="margin-left: 8px;">
							<span class="dashicons dashicons-dismiss" style="margin-top: 3px;"></span>
							<?php esc_html_e( 'Cancel', 'mcp-ai-wpoos' ); ?>
						</button>
					</p>

					<div id="wp-mcp-ai-tx-mine-progress" style="display: none; margin-top: 15px; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
						<h4 style="margin-top: 0;"><?php esc_html_e( 'Job Progress', 'mcp-ai-wpoos' ); ?></h4>
						<ul style="margin: 10px 0; padding-left: 20px;">
							<li><strong><?php esc_html_e( 'Job ID:', 'mcp-ai-wpoos' ); ?></strong> <code id="wp-mcp-ai-tx-mine-job-id">—</code></li>
							<li><strong><?php esc_html_e( 'Status:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-tx-mine-status" class="wp-mcp-ai-status-badge">—</span></li>
							<li><strong><?php esc_html_e( 'Progress:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-tx-mine-progress-text">0 / 0 (0%)</span></li>
							<li><strong><?php esc_html_e( 'Mined / Skipped / Failed:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-tx-mine-counts">0 / 0 / 0</span></li>
							<li><strong><?php esc_html_e( 'Last Message:', 'mcp-ai-wpoos' ); ?></strong> <span id="wp-mcp-ai-tx-mine-last-msg">—</span></li>
						</ul>
						<div id="wp-mcp-ai-tx-mine-errors" style="display: none; color: #a00; margin-top: 10px;"></div>
					</div>

					<div id="wp-mcp-ai-tx-mine-message" class="notice" style="display: none; margin: 15px 0;">
						<p></p>
					</div>
				<?php endif; ?>

				<?php
				$tx_rest_base     = esc_url_raw( rest_url( 'mcp-ai/v1/transcript-mining' ) );
				$tx_rest_nonce    = wp_create_nonce( 'wp_rest' );
				$tx_errors_url    = esc_url_raw( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=advanced&subtab=logging' ) );
				$tx_completed_err = __( 'Mining job completed with errors.', 'mcp-ai-wpoos' );
				$tx_check_errors  = __( 'Check NV oOS → Settings → Advanced → Recent Errors.', 'mcp-ai-wpoos' );
				$tx_open_errors   = __( 'Open Recent Errors', 'mcp-ai-wpoos' );
				$tx_no_memories   = __( 'Job completed but no new memories were extracted. Common causes: (1) all eligible transcripts have already been mined — uncheck "Skip transcripts that have already been mined" to re-process them; (2) the assistant has no stored transcripts yet; (3) JetEngine data-stores is inactive — check Settings → NV oOS → Recent Errors for details.', 'mcp-ai-wpoos' );
				$tx_poll_failed   = __( 'Failed to poll job.', 'mcp-ai-wpoos' );
				$tx_choose_asst   = __( 'Choose an assistant first.', 'mcp-ai-wpoos' );
				$tx_job_started   = __( 'Mining job started.', 'mcp-ai-wpoos' );
				$tx_start_failed  = __( 'Failed to start mining job.', 'mcp-ai-wpoos' );
				$tx_job_cancelled = __( 'Mining job cancelled.', 'mcp-ai-wpoos' );
				$tx_cancel_failed = __( 'Failed to cancel job.', 'mcp-ai-wpoos' );

				ob_start();
				?>
				jQuery(document).ready(function($) {
					var restBase = <?php echo wp_json_encode( $tx_rest_base ); ?>;
					var restNonce = <?php echo wp_json_encode( $tx_rest_nonce ); ?>;
					var pollTimer = null;
					var currentJobId = null;

					function setStatusBadge(status) {
						var $badge = $('#wp-mcp-ai-tx-mine-status');
						$badge.removeClass('wp-mcp-ai-status-success wp-mcp-ai-status-warning wp-mcp-ai-status-error').text(status || '—');
						if (status === 'completed') {
							$badge.addClass('wp-mcp-ai-status-success');
						} else if (status === 'cancelled' || status === 'failed') {
							$badge.addClass('wp-mcp-ai-status-error');
						} else {
							$badge.addClass('wp-mcp-ai-status-warning');
						}
					}

					function renderProgress(p) {
						$('#wp-mcp-ai-tx-mine-job-id').text(p.id || '—');
						setStatusBadge(p.status);
						$('#wp-mcp-ai-tx-mine-progress-text').text(
							(p.processed || 0) + ' / ' + (p.total || 0) + ' (' + (p.percent || 0) + '%)'
						);
						$('#wp-mcp-ai-tx-mine-counts').text(
							(p.mined_count || 0) + ' / ' + (p.skipped_count || 0) + ' / ' + (p.failed_count || 0)
						);
						$('#wp-mcp-ai-tx-mine-last-msg').text(p.last_message || '—');
						var $errs = $('#wp-mcp-ai-tx-mine-errors');
						if (p.errors && p.errors.length) {
							$errs.empty();
							p.errors.forEach(function(msg) {
								$('<div></div>').text('• ' + msg).appendTo($errs);
							});
							$errs.show();
						} else {
							$errs.hide().empty();
						}
					}

					function showMessage(type, text) {
						var $m = $('#wp-mcp-ai-tx-mine-message');
						$m.removeClass('notice-success notice-error notice-warning').addClass('notice-' + type);
						$m.find('p').text(text);
						$m.show();
					}

					function stopPolling() {
						if (pollTimer) {
							clearInterval(pollTimer);
							pollTimer = null;
						}
					}

					function poll(jobId) {
						$.ajax({
							url: restBase + '/jobs/' + encodeURIComponent(jobId),
							method: 'GET',
							headers: { 'X-WP-Nonce': restNonce },
							dataType: 'json'
						}).done(function(progress) {
							renderProgress(progress);
							if (progress.status === 'completed' || progress.status === 'cancelled' || progress.status === 'failed') {
								stopPolling();
								$('#wp-mcp-ai-tx-mine-start-btn').prop('disabled', false);
								$('#wp-mcp-ai-tx-mine-cancel-btn').prop('disabled', true);

								if (progress.status === 'completed') {
									var mined = progress.mined_count || 0;
									var failed = progress.failed_count || 0;
									if (failed > 0) {
										var errorsUrl = <?php echo wp_json_encode( $tx_errors_url ); ?>;
										showMessage(
											'error',
											<?php echo wp_json_encode( $tx_completed_err ); ?> +
											' ' +
											<?php echo wp_json_encode( $tx_check_errors ); ?>
										);
										$('#wp-mcp-ai-tx-mine-message')
											.find('p')
											.append(' ')
											.append($('<a></a>').attr('href', errorsUrl).text(<?php echo wp_json_encode( $tx_open_errors ); ?>));
									} else if (mined === 0) {
										showMessage(
											'warning',
											<?php echo wp_json_encode( $tx_no_memories ); ?>
										);
									}
								}
							}
						}).fail(function(xhr) {
							stopPolling();
							var msg = (xhr.responseJSON && xhr.responseJSON.message) || <?php echo wp_json_encode( $tx_poll_failed ); ?>;
							showMessage('error', msg);
						});
					}

					$('#wp-mcp-ai-tx-mine-start-btn').on('click', function(e) {
						e.preventDefault();
						var assistantId = $('#wp-mcp-ai-tx-mine-assistant').val();
						if (!assistantId) {
							showMessage('error', <?php echo wp_json_encode( $tx_choose_asst ); ?>);
							return;
						}
						var batchSize = parseInt($('#wp-mcp-ai-tx-mine-batch-size').val(), 10) || 10;
						var payload = {
							agent_id: String(assistantId),
							batch_size: batchSize,
							dry_run: $('#wp-mcp-ai-tx-mine-dry-run').is(':checked'),
							transcript_query: {
								assistant_id: parseInt(assistantId, 10),
								only_unextracted: $('#wp-mcp-ai-tx-mine-only-unextracted').is(':checked')
							}
						};

						$('#wp-mcp-ai-tx-mine-message').hide();
						$('#wp-mcp-ai-tx-mine-start-btn').prop('disabled', true);

						$.ajax({
							url: restBase + '/jobs',
							method: 'POST',
							headers: { 'X-WP-Nonce': restNonce },
							contentType: 'application/json; charset=UTF-8',
							data: JSON.stringify(payload),
							dataType: 'json'
						}).done(function(progress) {
							currentJobId = progress.id;
							$('#wp-mcp-ai-tx-mine-progress').show();
							$('#wp-mcp-ai-tx-mine-cancel-btn').prop('disabled', false);
							renderProgress(progress);
							showMessage('success', <?php echo wp_json_encode( $tx_job_started ); ?>);
							stopPolling();
							pollTimer = setInterval(function() { poll(currentJobId); }, 2000);
						}).fail(function(xhr) {
							$('#wp-mcp-ai-tx-mine-start-btn').prop('disabled', false);
							var msg = (xhr.responseJSON && xhr.responseJSON.message) || <?php echo wp_json_encode( $tx_start_failed ); ?>;
							showMessage('error', msg);
						});
					});

					$('#wp-mcp-ai-tx-mine-cancel-btn').on('click', function(e) {
						e.preventDefault();
						if (!currentJobId) {
							return;
						}
						$('#wp-mcp-ai-tx-mine-cancel-btn').prop('disabled', true);
						$.ajax({
							url: restBase + '/jobs/' + encodeURIComponent(currentJobId) + '/cancel',
							method: 'POST',
							headers: { 'X-WP-Nonce': restNonce },
							dataType: 'json'
						}).done(function(progress) {
							renderProgress(progress);
							stopPolling();
							$('#wp-mcp-ai-tx-mine-start-btn').prop('disabled', false);
							showMessage('warning', <?php echo wp_json_encode( $tx_job_cancelled ); ?>);
						}).fail(function(xhr) {
							var msg = (xhr.responseJSON && xhr.responseJSON.message) || <?php echo wp_json_encode( $tx_cancel_failed ); ?>;
							showMessage('error', msg);
						});
					});
				});
				<?php
				$tx_mine_js = ob_get_clean();
				wp_print_inline_script_tag( $tx_mine_js );
				?>
			</div>
			<?php
		}

		/**
		 * Get playbook statistics for display.
		 *
		 * @return array Array with playbook statistics.
		 */
		private function get_playbook_statistics() {
			global $wpdb;

			// Load required class if not loaded.
			if ( ! class_exists( 'WP_MCP_AI_Profession_Playbook_Seeder' ) ) {
				require_once WP_MCP_AI_PATH . 'includes/professions/class-wp-mcp-ai-profession-playbook-seeder.php';
			}

			// Get total number of active playbook attachments.
			// Active attachments are those still referenced in profession's memory_files.
			// This excludes orphaned attachments from previous versions.
			$active_attachments         = 0;
			$professions_with_playbooks = 0;

			// Get all professions.
			$professions = get_posts(
				array(
					'post_type'      => 'mcp_ai_profession',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'fields'         => 'ids',
				)
			);

			if ( ! class_exists( 'WP_MCP_AI_Profession_CPT' ) ) {
				require_once WP_MCP_AI_PATH . 'includes/professions/class-wp-mcp-ai-profession-cpt.php';
			}

			// Count attachments that are in memory_files (active).
			foreach ( $professions as $profession_id ) {
				$memory_files = get_post_meta( $profession_id, WP_MCP_AI_Profession_CPT::META_MEMORY_FILES, true );

				if ( is_array( $memory_files ) && ! empty( $memory_files ) ) {
					$has_playbook = false;

					// Filter to only count playbook attachments.
					foreach ( $memory_files as $attachment_id ) {
						$profession_id_meta = get_post_meta( $attachment_id, '_wp_mcp_ai_playbook_profession_id', true );
						if ( ! empty( $profession_id_meta ) ) {
							++$active_attachments;
							$has_playbook = true;
						}
					}

					// Count this profession if it has at least one playbook.
					if ( $has_playbook ) {
						++$professions_with_playbooks;
					}
				}
			}

			$total_attachments = $active_attachments;

			// Check if playbooks were seeded.
			$playbooks_seeded = get_option( WP_MCP_AI_Profession_Playbook_Seeder::SEEDED_OPTION, false );

			// Get last sync timestamp if available.
			$last_sync_timestamp = get_option( 'wp_mcp_ai_playbooks_last_sync', 0 );
			$last_sync           = '';
			if ( $last_sync_timestamp ) {
				$last_sync = human_time_diff( $last_sync_timestamp, time() ) . ' ' . __( 'ago', 'mcp-ai-wpoos' );
			}

			return array(
				'total_attachments'          => absint( $total_attachments ),
				'professions_with_playbooks' => absint( $professions_with_playbooks ),
				'orphaned_playbooks'         => WP_MCP_AI_Profession_Playbook_Seeder::count_orphaned_system_playbooks(),
				'seeded'                     => $playbooks_seeded,
				'last_sync'                  => $last_sync,
			);
		}

		/**
		 * Get available profession count from knowledge base JSON files.
		 *
		 * Uses a 1-hour transient cache to avoid repeated file I/O operations.
		 * The cache is cleared automatically when professions are reseeded.
		 *
		 * Note: On cache miss, this loads full profession data from JSON files
		 * to get the count. The WP_MCP_AI_Profession_Knowledge_Base_Loader
		 * class is lightweight (no expensive initialization), but loading full
		 * profession data could be optimized in the future with a count-only method.
		 *
		 * @return int Number of professions available in knowledge base.
		 */
		private function get_available_profession_count() {
			// Check cache first (1 hour expiration).
			$cached_count = get_transient( 'wp_mcp_ai_available_profession_count' );
			if ( false !== $cached_count ) {
				return absint( $cached_count );
			}

			// Load the knowledge base loader if not already loaded.
			if ( ! class_exists( 'WP_MCP_AI_Profession_Knowledge_Base_Loader' ) ) {
				require_once WP_MCP_AI_PATH . 'includes/services/class-wp-mcp-ai-profession-knowledge-base-loader.php';
			}

			// Get all professions from knowledge base.
			$loader      = new WP_MCP_AI_Profession_Knowledge_Base_Loader();
			$professions = $loader->load_all();

			// Return count, handling WP_Error if load failed.
			if ( is_wp_error( $professions ) ) {
				return 0;
			}

			$count = count( $professions );

			// Cache for 1 hour.
			set_transient( 'wp_mcp_ai_available_profession_count', $count, HOUR_IN_SECONDS );

			return $count;
		}

		/**
		 * Render Federation & Mesh section.
		 *
		 * Provides UI for managing mesh peer connections and AI Peers.
		 */
		private function render_federation_mesh() {
			// Get mesh computing status from tools settings.
			$settings           = WP_MCP_AI_Admin_Settings::get_settings();
			$mesh_enabled       = ! empty( $settings['enable_mesh'] );
			$federation_enabled = ! empty( $settings['enable_federation'] );
			$directory_enabled  = ! empty( $settings['enable_federation_directory'] );

			// Get AI Peers count only if directory is enabled and post type exists.
			$total_peers = 0;
			if ( $directory_enabled && post_type_exists( 'ai_peer' ) ) {
				$ai_peer_count = wp_count_posts( 'ai_peer' );
				// Count all AI peers regardless of status to detect unpublished peers.
				// Exclude only trash and auto-draft statuses.
				foreach ( (array) $ai_peer_count as $status => $count ) {
					if ( ! in_array( $status, array( 'trash', 'auto-draft' ), true ) ) {
						$total_peers += absint( $count );
					}
				}
			}

			// Get mesh inbound API key.
			$mesh_inbound_key = ! empty( $settings['mesh_inbound_api_key'] ) ? $settings['mesh_inbound_api_key'] : '';
			?>
			<div class="wp-mcp-ai-federation-mesh-section" style="margin-top: 30px;">
				<h3><?php esc_html_e( 'Federation & Mesh Computing', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Manage federated AI peers and mesh computing connections. Federation enables discovery and sharing of AI capabilities across trusted sites.', 'mcp-ai-wpoos' ); ?>
				</p>

				<!-- Status Overview -->
				<div class="wp-mcp-ai-mesh-status" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
					<h4 style="margin-top: 0;"><?php esc_html_e( 'Current Status', 'mcp-ai-wpoos' ); ?></h4>
					<ul style="margin: 10px 0; padding-left: 20px;">
						<li>
							<strong><?php esc_html_e( 'Mesh Computing:', 'mcp-ai-wpoos' ); ?></strong>
							<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $mesh_enabled ? 'success' : 'warning' ); ?>">
								<?php echo esc_html( $mesh_enabled ? __( 'Enabled', 'mcp-ai-wpoos' ) : __( 'Disabled', 'mcp-ai-wpoos' ) ); ?>
							</span>
							<?php if ( ! $mesh_enabled ) : ?>
								<span class="description" style="margin-left: 10px;">
									<?php
									printf(
										wp_kses(
											/* translators: %s: Link to tools settings page. */
											__( 'Enable mesh computing in %s', 'mcp-ai-wpoos' ),
											array( 'a' => array( 'href' => array() ) )
										),
										'<a href="' . esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=tools&subtab=features' ) ) . '">' . esc_html__( 'Tools & Features', 'mcp-ai-wpoos' ) . '</a>'
									);
									?>
								</span>
							<?php endif; ?>
						</li>
						<li>
							<strong><?php esc_html_e( 'Federation (Well-Known Endpoints):', 'mcp-ai-wpoos' ); ?></strong>
							<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $federation_enabled ? 'success' : 'warning' ); ?>">
								<?php echo esc_html( $federation_enabled ? __( 'Enabled', 'mcp-ai-wpoos' ) : __( 'Disabled', 'mcp-ai-wpoos' ) ); ?>
							</span>
						</li>
						<li>
							<strong><?php esc_html_e( 'Federation Directory:', 'mcp-ai-wpoos' ); ?></strong>
							<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $directory_enabled ? 'success' : 'warning' ); ?>">
								<?php echo esc_html( $directory_enabled ? __( 'Enabled', 'mcp-ai-wpoos' ) : __( 'Disabled', 'mcp-ai-wpoos' ) ); ?>
							</span>
						</li>
						<li>
							<strong><?php esc_html_e( 'Registered AI Peers:', 'mcp-ai-wpoos' ); ?></strong>
							<?php echo absint( $total_peers ); ?>
						</li>
					</ul>
				</div>

				<!-- Mesh Inbound API Key -->
				<?php if ( $mesh_enabled || $federation_enabled || $directory_enabled ) : ?>
					<?php if ( $mesh_inbound_key ) : ?>
						<div class="wp-mcp-ai-mesh-api-key" style="margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1; border-radius: 3px;">
							<h4 style="margin-top: 0;"><?php esc_html_e( 'Mesh Inbound API Key', 'mcp-ai-wpoos' ); ?></h4>
							<p class="description">
								<?php esc_html_e( 'This key allows other NV oOS sites to connect to this instance as a mesh peer. Share this key only with trusted administrators who need to configure their sites to communicate with yours.', 'mcp-ai-wpoos' ); ?>
							</p>
							<div style="margin: 10px 0; display: flex; align-items: center; gap: 10px;">
								<input type="text" readonly value="<?php echo esc_attr( $mesh_inbound_key ); ?>" 
									id="wp-mcp-ai-mesh-key-display" 
									style="width: 100%; max-width: 500px; font-family: monospace; font-size: 12px;" />
								<button type="button" class="button button-secondary" id="wp-mcp-ai-copy-mesh-key">
									<span class="dashicons dashicons-clipboard" style="margin-top: 3px;"></span>
									<?php esc_html_e( 'Copy', 'mcp-ai-wpoos' ); ?>
								</button>
							</div>
							<p class="description" style="margin-top: 10px;">
								<strong><?php esc_html_e( 'How to use this key:', 'mcp-ai-wpoos' ); ?></strong><br>
								<?php esc_html_e( '1. Copy this key using the button above', 'mcp-ai-wpoos' ); ?><br>
								<?php esc_html_e( '2. On the peer site that wants to connect to this instance, go to Advanced → Federation & Mesh', 'mcp-ai-wpoos' ); ?><br>
								<?php
								printf(
									wp_kses(
										/* translators: %s: JSON example wrapped in <code> tags. */
										__( '3. Add this site to their "Mesh Peer Sites Configuration" JSON with format: %s', 'mcp-ai-wpoos' ),
										array( 'code' => array() )
									),
									'<code>{"url":"' . esc_html( get_site_url() ) . '","api_key":"[paste key here]","name":"' . esc_html( get_bloginfo( 'name' ) ) . '","enabled":true}</code>'
								);
								?>
							</p>
						</div>

						<?php
						$mesh_copied_text = __( 'Copied!', 'mcp-ai-wpoos' );

						ob_start();
						?>
						jQuery(document).ready(function($) {
							$('#wp-mcp-ai-copy-mesh-key').on('click', function() {
								var $input = $('#wp-mcp-ai-mesh-key-display');
								$input.select();
								document.execCommand('copy');
								
								var $button = $(this);
								var originalText = $button.html();
								$button.html('<span class="dashicons dashicons-yes" style="margin-top: 3px; color: #46b450;"></span> ' + <?php echo wp_json_encode( $mesh_copied_text ); ?>);
								
								setTimeout(function() {
									$button.html(originalText);
								}, 2000);
							});
						});
						<?php
						$mesh_copy_js = ob_get_clean();
						wp_print_inline_script_tag( $mesh_copy_js );
						?>
					<?php else : ?>
						<div class="notice notice-warning inline" style="margin: 20px 0;">
							<p>
								<strong><?php esc_html_e( 'Mesh Inbound API Key Not Generated', 'mcp-ai-wpoos' ); ?></strong><br>
								<?php esc_html_e( 'The mesh inbound API key should be automatically generated when mesh computing or federation is enabled. Click "Save Settings" below to generate your key.', 'mcp-ai-wpoos' ); ?>
							</p>
						</div>
					<?php endif; ?>
				<?php endif; ?>

				<!-- AI Peers Management -->
				<?php if ( $directory_enabled ) : ?>
					<div class="wp-mcp-ai-ai-peers-section" style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
						<h4><?php esc_html_e( 'AI Peers (Federation Directory)', 'mcp-ai-wpoos' ); ?></h4>
						<p class="description">
							<?php esc_html_e( 'AI Peers represent other NV oOS instances in the federation network. Each peer can provide capabilities, tools, and AI services that can be discovered and consumed by this site.', 'mcp-ai-wpoos' ); ?>
						</p>

						<?php if ( $total_peers > 0 ) : ?>
							<!-- AI Peers List -->
							<?php
							$ai_peers = get_posts(
								array(
									'post_type'      => 'ai_peer',
									'post_status'    => 'publish',
									'posts_per_page' => 10,
									'orderby'        => 'title',
									'order'          => 'ASC',
								)
							);

							if ( ! empty( $ai_peers ) ) :
								?>
								<div class="wp-mcp-ai-peers-list" style="margin: 15px 0;">
									<table class="widefat striped" style="margin-top: 15px;">
										<thead>
											<tr>
												<th><?php esc_html_e( 'Peer Name', 'mcp-ai-wpoos' ); ?></th>
												<th><?php esc_html_e( 'Site URL', 'mcp-ai-wpoos' ); ?></th>
												<th><?php esc_html_e( 'Health Status', 'mcp-ai-wpoos' ); ?></th>
												<th><?php esc_html_e( 'Last Verified', 'mcp-ai-wpoos' ); ?></th>
												<th><?php esc_html_e( 'Actions', 'mcp-ai-wpoos' ); ?></th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ( $ai_peers as $peer ) : ?>
												<?php
												$peer_id     = $peer->ID;
												$site_url    = get_post_meta( $peer_id, '_wp_mcp_ai_peer_site_url', true );
												$health      = get_post_meta( $peer_id, '_wp_mcp_ai_peer_health_status', true );
												$last_verify = get_post_meta( $peer_id, '_wp_mcp_ai_peer_last_verified', true );

												// Format health status.
												$health_class = 'unknown';
												$health_text  = __( 'Unknown', 'mcp-ai-wpoos' );
												if ( 'healthy' === $health ) {
													$health_class = 'success';
													$health_text  = __( 'Healthy', 'mcp-ai-wpoos' );
												} elseif ( 'degraded' === $health ) {
													$health_class = 'warning';
													$health_text  = __( 'Degraded', 'mcp-ai-wpoos' );
												} elseif ( 'unhealthy' === $health ) {
													$health_class = 'error';
													$health_text  = __( 'Unhealthy', 'mcp-ai-wpoos' );
												}

												// Format last verified.
												$last_verify_display = __( 'Never', 'mcp-ai-wpoos' );
												if ( $last_verify ) {
													$last_verify_display = human_time_diff( strtotime( $last_verify ), time() ) . ' ' . __( 'ago', 'mcp-ai-wpoos' );
												}

												$edit_url = admin_url( 'post.php?post=' . $peer_id . '&action=edit' );
												?>
												<tr>
													<td>
														<strong>
															<a href="<?php echo esc_url( $edit_url ); ?>">
																<?php echo esc_html( $peer->post_title ); ?>
															</a>
														</strong>
													</td>
													<td>
														<?php if ( $site_url ) : ?>
															<a href="<?php echo esc_url( $site_url ); ?>" target="_blank" rel="noopener noreferrer">
																<?php echo esc_html( $site_url ); ?>
																<span class="dashicons dashicons-external" style="font-size: 12px; text-decoration: none;"></span>
															</a>
														<?php else : ?>
															<span class="description"><?php esc_html_e( 'Not set', 'mcp-ai-wpoos' ); ?></span>
														<?php endif; ?>
													</td>
													<td>
														<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-<?php echo esc_attr( $health_class ); ?>">
															<?php echo esc_html( $health_text ); ?>
														</span>
													</td>
													<td><?php echo esc_html( $last_verify_display ); ?></td>
													<td>
														<a href="<?php echo esc_url( $edit_url ); ?>" class="button button-small" title="<?php esc_attr_e( 'Edit', 'mcp-ai-wpoos' ); ?>">
															<span class="dashicons dashicons-edit" aria-hidden="true"></span>
															<span class="screen-reader-text"><?php esc_html_e( 'Edit', 'mcp-ai-wpoos' ); ?></span>
														</a>
													</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
							<?php else : ?>
								<!-- Show message when peers exist but aren't published -->
								<div class="notice notice-warning inline" style="margin: 15px 0;">
									<p>
										<?php
										$message = sprintf(
											/* translators: %d: number of peers */
											_n(
												'You have %d AI peer registered, but it is not currently published.',
												'You have %d AI peers registered, but none are currently published.',
												$total_peers,
												'mcp-ai-wpoos'
											),
											$total_peers
										);
										$link = sprintf(
											'<a href="%s">%s</a>',
											esc_url( admin_url( 'edit.php?post_type=ai_peer' ) ),
											esc_html__( 'View all AI peers', 'mcp-ai-wpoos' )
										);
										echo wp_kses(
											sprintf(
												/* translators: 1: message about unpublished peers, 2: link to view AI peers */
												__( '%1$s %2$s to review and publish them.', 'mcp-ai-wpoos' ),
												esc_html( $message ),
												$link
											),
											array( 'a' => array( 'href' => array() ) )
										);
										?>
									</p>
								</div>
							<?php endif; ?>
						<?php else : ?>
							<!-- Show helpful info when no peers exist yet -->
							<div class="notice notice-info inline" style="margin: 15px 0;">
								<p>
									<strong><?php esc_html_e( 'No AI Peers Registered Yet', 'mcp-ai-wpoos' ); ?></strong><br>
									<?php esc_html_e( 'AI Peers allow this site to discover and consume AI capabilities from other NV oOS instances. To get started:', 'mcp-ai-wpoos' ); ?>
								</p>
								<ol style="margin: 10px 0 10px 20px;">
									<li><?php esc_html_e( 'Click "Add New AI Peer" below to register a peer site', 'mcp-ai-wpoos' ); ?></li>
									<li><?php esc_html_e( 'Provide the peer site\'s URL and well-known endpoint (e.g., https://peer-site.com/.well-known/ai-peer)', 'mcp-ai-wpoos' ); ?></li>
									<li><?php esc_html_e( 'The peer will be automatically discovered and its capabilities will be available to your assistants', 'mcp-ai-wpoos' ); ?></li>
								</ol>
							</div>
						<?php endif; ?>

						<!-- Add New Peer Button -->
						<div style="margin: 15px 0;">
							<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=ai_peer' ) ); ?>" class="button button-primary">
								<span class="dashicons dashicons-plus" style="margin-top: 3px;"></span>
								<?php esc_html_e( 'Add New AI Peer', 'mcp-ai-wpoos' ); ?>
							</a>
							<?php if ( $total_peers > 0 ) : ?>
								<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=ai_peer' ) ); ?>" class="button button-secondary" style="margin-left: 5px;">
									<?php esc_html_e( 'View All AI Peers', 'mcp-ai-wpoos' ); ?> (<?php echo absint( $total_peers ); ?>)
								</a>
							<?php endif; ?>
						</div>
					</div>
				<?php else : ?>
					<!-- Show message when directory is disabled -->
					<div class="wp-mcp-ai-ai-peers-section" style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
						<h4><?php esc_html_e( 'AI Peers (Federation Directory)', 'mcp-ai-wpoos' ); ?></h4>
						<p class="description">
							<?php esc_html_e( 'AI Peers represent other NV oOS instances in the federation network. Each peer can provide capabilities, tools, and AI services that can be discovered and consumed by this site.', 'mcp-ai-wpoos' ); ?>
						</p>
						<div class="notice notice-warning inline" style="margin: 15px 0;">
							<p>
								<strong><?php esc_html_e( 'Directory Service Disabled', 'mcp-ai-wpoos' ); ?></strong><br>
								<?php
								echo wp_kses(
									sprintf(
										/* translators: %s: link to federation mesh settings */
										__( 'The Federation Directory service is currently disabled. Enable it in %s to manage AI Peers.', 'mcp-ai-wpoos' ),
										'<a href="' . esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=advanced&subtab=federation_mesh' ) ) . '">' . esc_html__( 'Federation Mesh Settings', 'mcp-ai-wpoos' ) . '</a>'
									),
									array( 'a' => array( 'href' => array() ) )
								);
								?>
							</p>
						</div>
					</div>
				<?php endif; ?>

				<?php if ( ! $mesh_enabled && ! $federation_enabled ) : ?>
					<div class="notice notice-info inline" style="margin-top: 20px;">
						<p>
							<strong><?php esc_html_e( 'Note:', 'mcp-ai-wpoos' ); ?></strong>
							<?php esc_html_e( 'To use mesh computing and federation features, enable them in the Tools & Features settings.', 'mcp-ai-wpoos' ); ?>
						</p>
					</div>
				<?php endif; ?>
			</div>

			<?php
		}

		/**
		 * Render custom mesh peer sites field.
		 *
		 * This method is called as a callback when rendering the mesh_peer_sites field.
		 * It delegates to the WP_MCP_AI_Admin_Settings class for the actual rendering.
		 *
		 * @param array $field Field configuration array.
		 */
		public function render_mesh_peer_sites_custom_field( $field ) {
			// Call the existing custom field renderer for mesh_peer_sites.
			if ( class_exists( 'WP_MCP_AI_Admin_Settings' ) && method_exists( 'WP_MCP_AI_Admin_Settings', 'render_mesh_peer_sites_field' ) ) {
				$admin_settings = new WP_MCP_AI_Admin_Settings();
				$admin_settings->render_mesh_peer_sites_field();
			}
		}

		/**
		 * Render Settings Management section.
		 *
		 * Provides tools for backup, restore, import, export, and maintenance of plugin settings.
		 */
		private function render_settings_management() {
			// Get current settings count.
			$settings       = WP_MCP_AI_Admin_Settings::get_settings();
			$settings_count = count( $settings );

			// Get backup count.
			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin settings import query against wp_options; direct query needed to enumerate plugin backup option names.
			$backup_count = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",
					'wp_mcp_ai_settings_backup_%'
				)
			);
			?>
			<div class="wp-mcp-ai-settings-management" style="padding: 20px; max-width: 800px;">
				<h3><?php esc_html_e( 'Settings Management', 'mcp-ai-wpoos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Manage plugin settings: export for backup, import from file, clear caches, check system health, or reset to defaults.', 'mcp-ai-wpoos' ); ?>
				</p>

				<!-- Settings Health Status -->
				<div class="wp-mcp-ai-card" style="background: #fff; border: 1px solid #ccd0d4; padding: 15px; margin: 20px 0;">
					<h4 style="margin-top: 0;">
						<span class="dashicons dashicons-heart" style="color: #d63638;"></span>
						<?php esc_html_e( 'Settings Health', 'mcp-ai-wpoos' ); ?>
					</h4>
					<div id="wp-mcp-ai-settings-health-status">
						<p><em><?php esc_html_e( 'Click "Check Health" to run diagnostics...', 'mcp-ai-wpoos' ); ?></em></p>
					</div>
					<p>
						<button type="button" id="wp-mcp-ai-check-settings-health" class="button button-secondary">
							<span class="dashicons dashicons-search"></span>
							<?php esc_html_e( 'Check Settings Health', 'mcp-ai-wpoos' ); ?>
						</button>
					</p>
				</div>

				<!-- Backup & Restore Section (Enhanced with Provider Selection) -->
				<div class="wp-mcp-ai-card" style="background: #fff; border: 1px solid #ccd0d4; padding: 15px; margin: 20px 0;">
					<h4 style="margin-top: 0;">
						<span class="dashicons dashicons-database-export"></span>
						<?php esc_html_e( 'Backup & Restore', 'mcp-ai-wpoos' ); ?>
					</h4>
					<p>
						<strong><?php esc_html_e( 'Core Settings:', 'mcp-ai-wpoos' ); ?></strong>
						<?php
						printf(
							/* translators: %d: Number of settings fields */
							esc_html( _n( '%d field configured', '%d fields configured', $settings_count, 'mcp-ai-wpoos' ) ),
							absint( $settings_count )
						);
						?>
						<br>
						<strong><?php esc_html_e( 'Backups Available:', 'mcp-ai-wpoos' ); ?></strong>
						<?php echo esc_html( absint( $backup_count ) ); ?>
						<?php esc_html_e( '(automatic backups from recent saves)', 'mcp-ai-wpoos' ); ?>
					</p>

					<?php if ( class_exists( 'WP_MCP_AI_Export_Manager' ) ) : ?>
						<?php $export_manager = WP_MCP_AI_Export_Manager::instance(); ?>
						<?php $export_providers = $export_manager->get_available_providers(); ?>

						<div id="wp-mcp-ai-export-providers" style="margin: 15px 0;">
							<p><strong><?php esc_html_e( 'Select data to export:', 'mcp-ai-wpoos' ); ?></strong></p>
							<?php foreach ( $export_providers as $provider ) : ?>
								<?php $provider->render_checkbox( 'core_settings' === $provider->get_id() ); ?>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<!-- Password protection (optional) -->
					<div style="margin: 15px 0;">
						<label>
							<input type="checkbox" id="wp-mcp-ai-export-encrypt" />
							<?php esc_html_e( 'Password-protect export file (AES-256-CBC)', 'mcp-ai-wpoos' ); ?>
						</label>
						<input type="password" id="wp-mcp-ai-export-password" class="regular-text"
							style="display: none; margin-top: 5px; max-width: 300px;"
							placeholder="<?php esc_attr_e( 'Enter passphrase...', 'mcp-ai-wpoos' ); ?>"
							autocomplete="new-password" />
					</div>

					<div style="margin: 15px 0;">
						<button type="button" id="wp-mcp-ai-export-settings" class="button button-primary">
							<span class="dashicons dashicons-download"></span>
							<?php esc_html_e( 'Export Selected (JSON)', 'mcp-ai-wpoos' ); ?>
						</button>
						<button type="button" id="wp-mcp-ai-export-all" class="button button-secondary">
							<?php esc_html_e( 'Export All', 'mcp-ai-wpoos' ); ?>
						</button>
						<p class="description" style="margin: 5px 0 0 0;">
							<?php esc_html_e( 'Download selected data as a JSON file for backup or migration. Providers marked with', 'mcp-ai-wpoos' ); ?>
							<span class="dashicons dashicons-warning" style="color: #d63638; vertical-align: middle;"></span>
							<?php esc_html_e( 'contain API keys or tokens — secure the export file.', 'mcp-ai-wpoos' ); ?>
						</p>
					</div>

					<hr>

					<div style="margin: 15px 0;">
						<label for="wp-mcp-ai-import-file" style="display: inline-block; margin-right: 10px;">
							<span class="dashicons dashicons-upload"></span>
							<?php esc_html_e( 'Import Settings:', 'mcp-ai-wpoos' ); ?>
						</label>
						<input type="file" id="wp-mcp-ai-import-file" accept=".json,application/json" />
						<input type="password" id="wp-mcp-ai-import-password" class="regular-text"
							style="display: none; margin-top: 5px; max-width: 300px;"
							placeholder="<?php esc_attr_e( 'Decryption passphrase (if file is encrypted)...', 'mcp-ai-wpoos' ); ?>"
							autocomplete="new-password" />
						<button type="button" id="wp-mcp-ai-import-settings" class="button button-secondary" disabled>
							<?php esc_html_e( 'Upload & Import', 'mcp-ai-wpoos' ); ?>
						</button>
						<p class="description" style="margin: 5px 0 0 0;">
							<?php esc_html_e( 'Import settings from a previously exported JSON file. Current settings will be backed up before import.', 'mcp-ai-wpoos' ); ?>
						</p>
					</div>

					<!-- Import Results -->
					<div id="wp-mcp-ai-import-results" style="display: none; margin: 15px 0;"></div>
				</div>

				<!-- Cache Management Section -->
				<div class="wp-mcp-ai-card" style="background: #fff; border: 1px solid #ccd0d4; padding: 15px; margin: 20px 0;">
					<h4 style="margin-top: 0;">
						<span class="dashicons dashicons-update"></span>
						<?php esc_html_e( 'Cache Management', 'mcp-ai-wpoos' ); ?>
					</h4>
					<p><?php esc_html_e( 'If settings changes are not taking effect, clear all settings-related caches.', 'mcp-ai-wpoos' ); ?></p>
					<p>
						<button type="button" id="wp-mcp-ai-clear-cache" class="button button-secondary">
							<span class="dashicons dashicons-trash"></span>
							<?php esc_html_e( 'Clear All Caches', 'mcp-ai-wpoos' ); ?>
						</button>
					</p>
				</div>

				<!-- Reset Section -->
				<div class="wp-mcp-ai-card" style="background: #fff; border: 1px solid #f0c36d; padding: 15px; margin: 20px 0;">
					<h4 style="margin-top: 0; color: #996800;">
						<span class="dashicons dashicons-warning" style="color: #996800;"></span>
						<?php esc_html_e( 'Reset to Defaults', 'mcp-ai-wpoos' ); ?>
					</h4>
					<p class="description">
						<strong><?php esc_html_e( 'Warning:', 'mcp-ai-wpoos' ); ?></strong>
						<?php esc_html_e( 'This will reset ALL settings to their default values. Current settings will be backed up before reset.', 'mcp-ai-wpoos' ); ?>
					</p>
					<p>
						<button type="button" id="wp-mcp-ai-reset-settings" class="button button-secondary">
							<span class="dashicons dashicons-undo"></span>
							<?php esc_html_e( 'Reset All Settings', 'mcp-ai-wpoos' ); ?>
						</button>
					</p>
				</div>

				<!-- Status Messages -->
				<div id="wp-mcp-ai-settings-management-message" class="notice" style="display: none; margin: 15px 0;">
					<p></p>
				</div>
			</div>

			<?php
			$sm_nonce          = wp_create_nonce( 'wp-mcp-ai-dashboard' );
			$sm_select_file    = __( 'Please select a JSON file to import.', 'mcp-ai-wpoos' );
			$sm_import_confirm = __( 'Import settings from file? Your current settings will be backed up first.', 'mcp-ai-wpoos' );
			$sm_importing      = __( 'Importing...', 'mcp-ai-wpoos' );
			$sm_import_failed  = __( 'Import failed.', 'mcp-ai-wpoos' );
			$sm_upload_import  = __( 'Upload & Import', 'mcp-ai-wpoos' );
			$sm_ajax_error     = __( 'AJAX error occurred.', 'mcp-ai-wpoos' );
			$sm_clear_confirm  = __( 'Clear all settings caches?', 'mcp-ai-wpoos' );
			$sm_clearing       = __( 'Clearing...', 'mcp-ai-wpoos' );
			$sm_clear_failed   = __( 'Failed to clear cache.', 'mcp-ai-wpoos' );
			$sm_clear_all      = __( 'Clear All Caches', 'mcp-ai-wpoos' );
			$sm_reset_confirm  = __( 'Reset ALL settings to defaults? This cannot be undone! (Current settings will be backed up)', 'mcp-ai-wpoos' );
			$sm_resetting      = __( 'Resetting...', 'mcp-ai-wpoos' );
			$sm_reset_failed   = __( 'Failed to reset settings.', 'mcp-ai-wpoos' );
			$sm_reset_all      = __( 'Reset All Settings', 'mcp-ai-wpoos' );
			$sm_checking       = __( 'Checking...', 'mcp-ai-wpoos' );
			$sm_health_failed  = __( 'Health check failed.', 'mcp-ai-wpoos' );
			$sm_check_health   = __( 'Check Settings Health', 'mcp-ai-wpoos' );
			$sm_select_type    = __( 'Please select at least one data type to export.', 'mcp-ai-wpoos' );
			$sm_enter_password = __( 'Please enter a passphrase for encryption.', 'mcp-ai-wpoos' );

			ob_start();
			?>
			jQuery(document).ready(function($) {
				const nonce = <?php echo wp_json_encode( $sm_nonce ); ?>;

				// Enable import button when file is selected, show password field.
				$('#wp-mcp-ai-import-file').on('change', function() {
					$('#wp-mcp-ai-import-settings').prop('disabled', !this.files.length);
					$('#wp-mcp-ai-import-password').show();
				});

				// Export settings with provider selection.
				$('#wp-mcp-ai-export-settings').on('click', function() {
					var selected = [];
					$('.wp-mcp-ai-export-provider-checkbox:checked').each(function() {
						selected.push($(this).val());
					});
					if (selected.length === 0) {
						alert(<?php echo wp_json_encode( $sm_select_type ); ?>);
						return;
					}
					var url = ajaxurl + '?action=wp_mcp_ai_export_settings&nonce=' + nonce
						+ '&providers=' + selected.join(',');
					if ($('#wp-mcp-ai-export-encrypt').is(':checked')) {
						var pw = $('#wp-mcp-ai-export-password').val();
						if (!pw) {
							alert(<?php echo wp_json_encode( $sm_enter_password ); ?>);
							return;
						}
						url += '&password=' + encodeURIComponent(pw);
					}
					window.location.href = url;
				});

				// Export all (all checkboxes).
				$('#wp-mcp-ai-export-all').on('click', function() {
					$('.wp-mcp-ai-export-provider-checkbox').prop('checked', true);
					$('#wp-mcp-ai-export-settings').trigger('click');
				});

				// Toggle password field.
				$('#wp-mcp-ai-export-encrypt').on('change', function() {
					$('#wp-mcp-ai-export-password').toggle(this.checked);
				});

				// Import settings (enhanced with password and result display).
				$('#wp-mcp-ai-import-settings').on('click', function() {
					const fileInput = document.getElementById('wp-mcp-ai-import-file');
					if (!fileInput.files.length) {
						alert(<?php echo wp_json_encode( $sm_select_file ); ?>);
						return;
					}

					if (!confirm(<?php echo wp_json_encode( $sm_import_confirm ); ?>)) {
						return;
					}

					const formData = new FormData();
					formData.append('action', 'wp_mcp_ai_import_settings');
					formData.append('nonce', nonce);
					formData.append('settings_file', fileInput.files[0]);
					var pw = $('#wp-mcp-ai-import-password').val();
					if (pw) {
						formData.append('password', pw);
					}

					$(this).prop('disabled', true).text(<?php echo wp_json_encode( $sm_importing ); ?>);

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: formData,
						processData: false,
						contentType: false,
						success: function(response) {
							if (response.success) {
								var msg = response.data.message;
								// Display per-provider results if available.
								if (response.data.results) {
									var resultsHtml = '<ul style="margin: 8px 0 0 0; padding-left: 20px;">';
									$.each(response.data.results, function(id, r) {
										var icon = r.success ? '✅' : '❌';
										resultsHtml += '<li>' + icon + ' ' + r.message + '</li>';
									});
									resultsHtml += '</ul>';
									$('#wp-mcp-ai-import-results').html(resultsHtml).slideDown();
								}
								$('#wp-mcp-ai-settings-management-message')
									.removeClass('notice-error')
									.addClass('notice-success')
									.find('p').html(msg);
								$('#wp-mcp-ai-settings-management-message').slideDown();
								setTimeout(function() {
									window.location.reload();
								}, 3000);
							} else {
								var errMsg = response.data.message || <?php echo wp_json_encode( $sm_import_failed ); ?>;
								if (response.data.errors) {
									errMsg += '\n' + response.data.errors.join('\n');
								}
								$('#wp-mcp-ai-settings-management-message')
									.removeClass('notice-success')
									.addClass('notice-error')
									.find('p').text(errMsg);
								$('#wp-mcp-ai-settings-management-message').slideDown();
								$('#wp-mcp-ai-import-settings').prop('disabled', false).text(<?php echo wp_json_encode( $sm_upload_import ); ?>);
							}
						},
						error: function() {
							alert(<?php echo wp_json_encode( $sm_ajax_error ); ?>);
							$('#wp-mcp-ai-import-settings').prop('disabled', false).text(<?php echo wp_json_encode( $sm_upload_import ); ?>);
						}
					});
				});

				// Clear cache.
				$('#wp-mcp-ai-clear-cache').on('click', function() {
					if (!confirm(<?php echo wp_json_encode( $sm_clear_confirm ); ?>)) {
						return;
					}

					$(this).prop('disabled', true).text(<?php echo wp_json_encode( $sm_clearing ); ?>);

					$.post(ajaxurl, {
						action: 'wp_mcp_ai_clear_settings_cache',
						nonce: nonce
					}, function(response) {
						if (response.success) {
							$('#wp-mcp-ai-settings-management-message')
								.removeClass('notice-error')
								.addClass('notice-success')
								.find('p').text(response.data.message);
							$('#wp-mcp-ai-settings-management-message').slideDown();
						} else {
							alert(response.data.message || <?php echo wp_json_encode( $sm_clear_failed ); ?>);
						}
						$('#wp-mcp-ai-clear-cache').prop('disabled', false).text(<?php echo wp_json_encode( $sm_clear_all ); ?>);
					});
				});

				// Reset settings.
				$('#wp-mcp-ai-reset-settings').on('click', function() {
					if (!confirm(<?php echo wp_json_encode( $sm_reset_confirm ); ?>)) {
						return;
					}

					$(this).prop('disabled', true).text(<?php echo wp_json_encode( $sm_resetting ); ?>);

					$.post(ajaxurl, {
						action: 'wp_mcp_ai_reset_settings',
						nonce: nonce
					}, function(response) {
						if (response.success) {
							$('#wp-mcp-ai-settings-management-message')
								.removeClass('notice-error')
								.addClass('notice-success')
								.find('p').text(response.data.message);
							$('#wp-mcp-ai-settings-management-message').slideDown();
							setTimeout(function() {
								window.location.reload();
							}, 2000);
						} else {
							alert(response.data.message || <?php echo wp_json_encode( $sm_reset_failed ); ?>);
							$('#wp-mcp-ai-reset-settings').prop('disabled', false).text(<?php echo wp_json_encode( $sm_reset_all ); ?>);
						}
					});
				});

				// Check settings health.
				$('#wp-mcp-ai-check-settings-health').on('click', function() {
					$(this).prop('disabled', true).text(<?php echo wp_json_encode( $sm_checking ); ?>);

					$.post(ajaxurl, {
						action: 'wp_mcp_ai_check_settings_health',
						nonce: nonce
					}, function(response) {
						if (response.success) {
							let statusHtml = '<h5>' + response.data.message + '</h5>';
							
							if (response.data.issues && response.data.issues.length > 0) {
								statusHtml += '<div class="notice notice-error inline"><ul>';
								response.data.issues.forEach(function(issue) {
									statusHtml += '<li><strong>Issue:</strong> ' + issue + '</li>';
								});
								statusHtml += '</ul></div>';
							}

							if (response.data.warnings && response.data.warnings.length > 0) {
								statusHtml += '<div class="notice notice-warning inline"><ul>';
								response.data.warnings.forEach(function(warning) {
									statusHtml += '<li><strong>Warning:</strong> ' + warning + '</li>';
								});
								statusHtml += '</ul></div>';
							}

							if (response.data.info && response.data.info.length > 0) {
								statusHtml += '<div class="notice notice-info inline"><ul>';
								response.data.info.forEach(function(info) {
									statusHtml += '<li>' + info + '</li>';
								});
								statusHtml += '</ul></div>';
							}

							$('#wp-mcp-ai-settings-health-status').html(statusHtml);
						} else {
							$('#wp-mcp-ai-settings-health-status').html('<p class="notice notice-error inline">' + (response.data.message || <?php echo wp_json_encode( $sm_health_failed ); ?>) + '</p>');
						}
						$('#wp-mcp-ai-check-settings-health').prop('disabled', false).text(<?php echo wp_json_encode( $sm_check_health ); ?>);
					});
				});
			});
			<?php
			$settings_mgmt_js = ob_get_clean();
			wp_print_inline_script_tag( $settings_mgmt_js );
			?>
			<?php
		}
	}
}
