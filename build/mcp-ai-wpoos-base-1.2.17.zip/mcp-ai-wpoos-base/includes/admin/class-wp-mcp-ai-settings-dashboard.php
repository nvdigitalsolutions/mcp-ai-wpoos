<?php
/**
 * Settings Dashboard Controller for NV oOS
 *
 * Manages the modern tabbed settings interface.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Settings_Dashboard' ) ) {
	/**
	 * Main controller for the settings dashboard.
	 */
	class WP_MCP_AI_Settings_Dashboard {
		const PAGE_SLUG = 'wp-mcp-ai-dashboard';

		/**
		 * AJAX handlers component.
		 *
		 * @var WP_MCP_AI_Admin_AJAX_Handlers
		 */
		private $ajax_handlers;

		/**
		 * Constructor.
		 *
		 * @param WP_MCP_AI_Admin_AJAX_Handlers|null $ajax_handlers Optional. AJAX handlers instance for dependency injection.
		 */
		public function __construct( $ajax_handlers = null ) {
			// Initialize AJAX handlers using dependency injection or create instance.
			$this->ajax_handlers = $ajax_handlers ?? wp_mcp_ai_container()->get( 'admin.ajax_handlers' );

			add_action( 'admin_menu', array( $this, 'register_menu' ) );
			add_action( 'admin_menu', array( $this, 'reorder_main_menu' ), 999 );
			add_action( 'admin_init', array( $this, 'register_settings' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
			add_action( 'admin_post_wp_mcp_ai_save_settings', array( $this, 'handle_save_settings' ) );

			// Hide WordPress admin footer on the settings dashboard to prevent overlay issues.
			add_filter( 'admin_footer_text', array( $this, 'hide_admin_footer_text' ) );
			add_filter( 'update_footer', array( $this, 'hide_update_footer_text' ), 999 );

			// Register AJAX handlers.
			add_action( 'wp_ajax_wp_mcp_ai_test_ollama_connection', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_fetch_ollama_models', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_test_lm_studio_connection', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_fetch_lm_studio_models', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_fetch_cloudways_data', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_test_cloudflare_connection', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_test_brave_search_connection', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_test_tavily_connection', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_test_mubert_connection', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_test_plaid_connection', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_reset_user_token_usage', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_reset_all_token_usage', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_lift_user_restriction', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_get_restrictions', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_dismiss_restriction_notice', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_save_tool_limits', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_save_tool_settings', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_apply_orchestration_preset', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_export_token_usage_csv', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_bulk_assign_tier', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_apply_all_recommendations', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_apply_preset', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_get_usage_trend', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_get_tier_distribution', array( $this->ajax_handlers, 'safe_ajax_handler' ) );

			// Settings management AJAX handlers.
			add_action( 'wp_ajax_wp_mcp_ai_export_settings', array( $this, 'handle_export_settings' ) );
			add_action( 'wp_ajax_wp_mcp_ai_import_settings', array( $this, 'handle_import_settings' ) );
			add_action( 'wp_ajax_wp_mcp_ai_clear_settings_cache', array( $this, 'handle_clear_cache' ) );
			add_action( 'wp_ajax_wp_mcp_ai_reset_settings', array( $this, 'handle_reset_settings' ) );
			add_action( 'wp_ajax_wp_mcp_ai_check_settings_health', array( $this, 'handle_check_settings_health' ) );
			add_action( 'wp_ajax_wp_mcp_ai_get_tool_breakdown', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_get_provider_distribution', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_get_model_distribution', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_update_chart_period', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_refresh_chart', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_toggle_tool', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_reseed_professions', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_reseed_teams', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_seed_task_templates', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_seed_orchestration', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_migrate_gemini_costs', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_regenerate_playbook', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_sync_all_playbooks', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_delete_old_playbooks', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_sync_media_templates', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_get_models_for_provider', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_clear_test_files', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_clear_dev_files', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_maintain_log_buffers', array( $this->ajax_handlers, 'safe_ajax_handler' ) );
			add_action( 'wp_ajax_wp_mcp_ai_save_model_config', array( $this->ajax_handlers, 'handle_save_model_config' ) );
		}

		/**
		 * Register the settings page in WordPress admin menu.
		 */
		public function register_menu() {
			/**
			 * Kill-switch for the wp-admin settings dashboard (Proposal 084
			 * Phase 2). The Complete Console ships the schema-driven Settings
			 * page; flip this filter off per cohort once the SPA surface
			 * reaches parity (structural field types stay wp-admin-only for
			 * now — see the settings controller's SUPPORTED_FIELD_TYPES).
			 */
			if ( ! apply_filters( 'wp_mcp_ai_admin_page_enabled_settings_dashboard', true ) ) {
				return;
			}

			add_menu_page(
				__( 'NV oOS Settings', 'mcp-ai-wpoos' ),
				__( 'NV oOS', 'mcp-ai-wpoos' ),
				'manage_options',
				self::PAGE_SLUG,
				array( $this, 'render_dashboard' ),
				'dashicons-format-chat',
				null // Let WordPress automatically position the menu.
			);

			// Remove the auto-generated submenu item (has same title as top-level menu).
			remove_submenu_page( self::PAGE_SLUG, self::PAGE_SLUG );

			// Add submenu item for General Settings with proper label.
			add_submenu_page(
				self::PAGE_SLUG,
				__( 'General Settings', 'mcp-ai-wpoos' ),
				__( 'General Settings', 'mcp-ai-wpoos' ),
				'manage_options',
				self::PAGE_SLUG,
				array( $this, 'render_dashboard' )
			);
		}

		/**
		 * Reorder submenu items to ensure proper menu order.
		 *
		 * Ensures Getting Started appears first, followed by General Settings,
		 * Orchestration Dashboard, and Task Plans.
		 * This method reorganizes the submenu items under the main NV oOS menu to maintain
		 * a logical and consistent navigation structure.
		 *
		 * @since 2.1.0
		 * @return void
		 */
		public function reorder_main_menu() {
			global $submenu;

			// Only reorder if the main NV oOS submenu exists.
			if ( ! isset( $submenu[ self::PAGE_SLUG ] ) || ! is_array( $submenu[ self::PAGE_SLUG ] ) ) {
				return;
			}

			$main_submenu = $submenu[ self::PAGE_SLUG ];

			// Define desired order: Getting Started (0), General Settings (10), Orchestration (20), Task Plans (30).
			$ordered_items         = array();
			$getting_started_item  = null;
			$general_settings_item = null;
			$orchestration_item    = null;
			$task_plans_item       = null;
			$other_items           = array();

			// Categorize menu items.
			foreach ( $main_submenu as $item ) {
				if ( isset( $item[2] ) && 'wp-mcp-ai-getting-started' === $item[2] ) {
					// Getting Started wizard page.
					$getting_started_item = $item;
				} elseif ( isset( $item[2] ) && self::PAGE_SLUG === $item[2] ) {
					// General Settings (the main dashboard page).
					$general_settings_item = $item;
				} elseif ( isset( $item[2] ) && false !== strpos( $item[2], 'mcp-ai-orchestration' ) ) {
					// Orchestration Dashboard.
					$orchestration_item = $item;
				} elseif ( isset( $item[2] ) && false !== strpos( $item[2], 'post_type=mcp_task_plan' ) ) {
					// Task Plans CPT.
					$task_plans_item = $item;
				} else {
					// Other items.
					$other_items[] = $item;
				}
			}

			// Rebuild menu in desired order.
			if ( $getting_started_item ) {
				$ordered_items[0] = $getting_started_item;
			}
			if ( $general_settings_item ) {
				$ordered_items[10] = $general_settings_item;
			}
			if ( $orchestration_item ) {
				$ordered_items[20] = $orchestration_item;
			}
			if ( $task_plans_item ) {
				$ordered_items[30] = $task_plans_item;
			}

			// Add other items after.
			$position = 40;
			foreach ( $other_items as $item ) {
				$ordered_items[ $position ] = $item;
				++$position;
			}

			// Update global submenu.
			ksort( $ordered_items );
			// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Required to reorder admin menu items.
			$submenu[ self::PAGE_SLUG ] = $ordered_items;
		}

		/**
		 * Register settings with WordPress.
		 *
		 * The sanitize_callback provides a safety net for any direct update_option() calls.
		 * Primary sanitization is handled in handle_save_settings() with full context
		 * (active tab/subtab awareness) to prevent data loss during partial-form saves.
		 */
		public function register_settings() {
			register_setting(
				'wp_mcp_ai_settings_group',
				WP_MCP_AI_Admin_Settings::OPTION_NAME,
				array(
					'type'              => 'array',
					'sanitize_callback' => array( $this, 'sanitize_settings_callback' ),
				)
			);

			// Register settings sections with WordPress Settings API.
			// Each section is added to allow WordPress to properly track and manage them.
			$tabs = WP_MCP_AI_Settings_Registry::get_tabs();
			foreach ( $tabs as $tab_id => $tab_config ) {
				$sections = WP_MCP_AI_Settings_Registry::get_sections( $tab_id );
				foreach ( $sections as $section ) {
					add_settings_section(
						$section->get_id(),
						$section->get_title(),
						'__return_false', // Rendering is handled by section's render_wrapper() method.
						self::PAGE_SLUG
					);
				}
			}
		}

		/**
		 * Sanitize callback for register_setting().
		 *
		 * WordPress registers this as a `sanitize_option_{option_name}` filter via
		 * register_setting(), which means it fires on EVERY update_option() call for
		 * this option — including the one inside handle_save_settings() itself.
		 *
		 * Re-running the full section-based sanitization here causes data loss:
		 * subtab-aware sections (e.g. Providers) inspect $_POST to decide which subtab
		 * is active. When the current request is NOT a providers-tab save (e.g. it is a
		 * general-settings save, an OAuth callback, or an unrelated admin-post action),
		 * those sections find no matching subtab in $_POST and return an empty array,
		 * wiping stored API keys.
		 *
		 * This callback applies a general-purpose sanitization pass that covers string
		 * type safety while preserving the context-aware merge that all callers perform
		 * before calling update_option():
		 *  - handle_save_settings() runs full section-based sanitization with the
		 *    correct $_POST context and then calls array_merge with existing settings.
		 *  - OAuth/integration handlers (Gmail, QuickBooks, etc.) fetch the full
		 *    existing settings, modify only their specific keys, and save the result.
		 *
		 * @param mixed $input Settings value passed to update_option().
		 * @return array Sanitized settings array.
		 */
		public function sanitize_settings_callback( $input ) {
			if ( ! is_array( $input ) ) {
				// Preserve existing settings if input is not a valid array.
				$existing = get_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, array() );
				return is_array( $existing ) ? $existing : array();
			}
			return $this->sanitize_settings_array_recursive( $input );
		}

		/**
		 * Keys that hold API keys, passwords, or secrets.
		 *
		 * These fields are validated for type safety (must be strings) and trimmed,
		 * but are NOT passed through sanitize_textarea_field() because that function
		 * strips octets and certain characters that may be valid in credentials.
		 *
		 * Patterns use suffix matching to avoid false positives (e.g., a field named
		 * 'notification_token_count' would NOT match because '_count' is the suffix).
		 *
		 * @var array<string>
		 */
		private static $secret_field_suffixes = array(
			'_api_key',
			'_secret',
			'_password',
			'_token',
			'api_key',
			'client_id',
			'client_secret',
			'access_token',
			'refresh_token',
		);

		/**
		 * Check if a settings key represents a secret/credential field.
		 *
		 * Uses suffix matching to avoid false positives with unrelated fields
		 * (e.g., 'notification_token_count' would not match '_token' because
		 * the key does not end with that suffix).
		 *
		 * @param string $key The settings key to check.
		 * @return bool True if the key is a secret field.
		 */
		private function is_secret_field( $key ) {
			$key = (string) $key;
			foreach ( self::$secret_field_suffixes as $suffix ) {
				$suffix_len = strlen( $suffix );
				if ( strlen( $key ) >= $suffix_len && substr( $key, -$suffix_len ) === $suffix ) {
					return true;
				}
			}
			return false;
		}

		/**
		 * Recursively sanitize a settings array.
		 *
		 * Applies type-appropriate sanitization to each value:
		 * - Booleans are cast to bool.
		 * - Integers are cast to int.
		 * - Floats are cast to float.
		 * - Strings that look like URLs are passed through esc_url_raw().
		 * - Secret/credential fields (API keys, passwords, tokens) are trimmed but
		 *   NOT passed through sanitize_textarea_field() to avoid altering valid
		 *   credential characters.
		 * - All other strings use sanitize_textarea_field(), which strips HTML/PHP
		 *   tags but PRESERVES newlines — critical for multiline settings such as
		 *   ip_whitelist (newline-separated IPs) and textarea prompts.
		 *   sanitize_text_field() is intentionally NOT used here because it collapses
		 *   all whitespace including newlines, which would corrupt those values.
		 * - Arrays are processed recursively.
		 * - Array keys are preserved exactly as-is. sanitize_key() is intentionally
		 *   NOT applied to keys because the settings contain camelCase and mixed-case
		 *   keys (e.g. 'backgroundColor', 'High', 'Low') that would be corrupted by
		 *   the lowercase conversion sanitize_key() performs.
		 * - NULL and other scalar types are returned as-is.
		 *
		 * @param array $data The array to sanitize.
		 * @return array Sanitized array with original keys preserved.
		 */
		private function sanitize_settings_array_recursive( array $data ) {
			$sanitized = array();
			foreach ( $data as $key => $value ) {
				if ( is_array( $value ) ) {
					$sanitized[ $key ] = $this->sanitize_settings_array_recursive( $value );
				} elseif ( is_bool( $value ) ) {
					$sanitized[ $key ] = (bool) $value;
				} elseif ( is_int( $value ) ) {
					$sanitized[ $key ] = (int) $value;
				} elseif ( is_float( $value ) ) {
					$sanitized[ $key ] = (float) $value;
				} elseif ( is_string( $value ) ) {
					// Use esc_url_raw only for single-URL values. Multi-token strings
					// that merely start with a URL (e.g. space-delimited OAuth scope
					// lists) must keep their separators intact — esc_url_raw() would
					// encode every space as %20 and corrupt the value.
					if ( preg_match( '/^https?:\/\/[^\s]+$/i', trim( $value ) ) ) {
						$sanitized[ $key ] = esc_url_raw( $value );
					} elseif ( $this->is_secret_field( $key ) ) {
						// Secret fields: trim whitespace only; do not strip
						// octets or HTML entities that may be valid in credentials.
						$sanitized[ $key ] = trim( $value );
					} else {
						// sanitize_textarea_field strips HTML tags while preserving
						// newlines — safe for all string types in this option.
						$sanitized[ $key ] = sanitize_textarea_field( $value );
					}
				} else {
					$sanitized[ $key ] = $value;
				}
			}
			return $sanitized;
		}

		/**
		 * Sanitize settings before saving.
		 *
		 * @param array  $input Raw settings input.
		 * @param string $active_tab Optional. The active tab to process. If not provided, processes all tabs.
		 * @return array Sanitized settings.
		 */
		public function sanitize_settings( $input, $active_tab = '' ) {
			$sanitized = array();

			// Get sections to process - either from a specific tab or all sections.
			// A tab also pulls in its child-tab sections (subtab_of), so saves
			// from a subtabbed view (e.g. E-Commerce → Shopify Sync) sanitize
			// the posted fields.
			if ( ! empty( $active_tab ) ) {
				$sections = $this->get_sections_for_tab( $active_tab );
			} else {
				$sections = WP_MCP_AI_Settings_Registry::get_sections();
			}

			foreach ( $sections as $section ) {
				$section_input = $section->sanitize( $input );
				$validated     = $section->validate( $section_input );

				if ( is_wp_error( $validated ) ) {
					add_settings_error(
						'wp_mcp_ai_settings',
						$section->get_id(),
						$validated->get_error_message(),
						'error'
					);
					continue;
				}

				$sanitized = array_merge( $sanitized, $section_input );
			}

			// Clear settings cache.
			WP_MCP_AI_Admin_Settings::reset_settings_cache();

			return $sanitized;
		}

		/**
		 * Handle settings save via admin_post.
		 */
		public function handle_save_settings() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have permission to access this page.', 'mcp-ai-wpoos' ) );
			}

			check_admin_referer( 'wp_mcp_ai_save_settings' );

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Array passed to sanitize_settings() method below.
			$posted_settings = isset( $_POST['wp_mcp_ai_settings'] ) ? wp_unslash( $_POST['wp_mcp_ai_settings'] ) : array();
			$active_tab      = isset( $_POST['active_tab'] ) ? sanitize_key( wp_unslash( $_POST['active_tab'] ) ) : '';
			$active_view     = isset( $_POST['view'] ) ? sanitize_key( wp_unslash( $_POST['view'] ) ) : '';
			$save_all_tabs   = isset( $_POST['save_all_tabs'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['save_all_tabs'] ) );

			// ========================================================================
			// Bridge posted fields to their own option stores.
			// ========================================================================
			// Some dashboard fields (e.g. the Security Center Usage Monitor
			// configuration) are owned by a separate option, not
			// wp_mcp_ai_settings. Sections intentionally drop these keys, and the
			// 'wp_mcp_ai_admin_settings_sanitize' filter is the single bridge that
			// persists them (see WP_MCP_AI_Security_Monitor_Admin). The section-
			// based sanitize flow below never applies that filter, so apply it
			// here with the raw posted input; bridge handlers no-op when their
			// fields are absent from the submission.
			apply_filters( 'wp_mcp_ai_admin_settings_sanitize', array(), $posted_settings );

			// DEBUG: Log checkbox values in posted data.
			$existing_for_logging = get_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, array() );
			$enable_logging       = ! empty( $existing_for_logging['enable_logging'] ) || ! empty( $existing_for_logging['enable_extended_logging'] );
			if ( $enable_logging ) {
				$checkbox_keys     = array( 'enable_mesh', 'enable_federation', 'enable_federation_directory' );
				$posted_checkboxes = array();
				foreach ( $checkbox_keys as $key ) {
					if ( isset( $posted_settings[ $key ] ) ) {
						$posted_checkboxes[ $key ] = $posted_settings[ $key ];
					} else {
						$posted_checkboxes[ $key ] = 'NOT_IN_POST';
					}
				}
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
				error_log(
					sprintf(
						'[NV oOS Posted Data] Tab: %s, Checkbox values in $_POST[wp_mcp_ai_settings]: %s',
						$active_tab,
						wp_json_encode( $posted_checkboxes )
					)
				);
			}

			// Find subtab from explicit 'subtab' field first (for parent-level subtabs),
			// then from section-specific subtab fields (subtab_sectionid format).
			// Multiple sections on same tab may have subtabs, so we check all subtab_* fields.
			// IMPORTANT: Many sections use subtabs with critical data tables:
			// - Providers tab: Each provider (OpenAI, Gemini, Ollama, etc.) has its own subtab
			// - Advanced tab: Performance, Logging, Federation, Data Management, Settings Management
			// - Integrations tab: Various third-party integrations
			// - Tools tab: Tool categories and individual tool configurations
			// The subtab value is used to determine which specific fields to sanitize during save.
			$active_subtab = '';

			// PRIORITY 1: Check for explicit 'subtab' field first (used for parent-level subtabs).
			// This ensures that when nested sections are present (e.g., Tools > Connections > Google Drive),
			// the parent subtab value ('connections') is preserved for redirect, not the nested value ('google_drive').
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified at line 258 via check_admin_referer().
			if ( isset( $_POST['subtab'] ) && ! empty( $_POST['subtab'] ) ) {
				$active_subtab = sanitize_key( wp_unslash( $_POST['subtab'] ) );
			}

			// PRIORITY 2: Fall back to section-specific subtab fields if no explicit subtab is provided.
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified at line 417 via check_admin_referer().
			if ( empty( $active_subtab ) ) {
				$unslashed_post = wp_unslash( $_POST );
				foreach ( $unslashed_post as $raw_key => $value ) {
					$key = sanitize_key( $raw_key );
					if ( strpos( $key, 'subtab_' ) === 0 && ! empty( $value ) ) {
						$active_subtab = sanitize_key( wp_unslash( $value ) );
						break; // Use the first subtab found.
					}
				}
			}

			// Check for 'connection' parameter (used in Integrations section).
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
			$active_connection = isset( $_POST['connection'] ) ? sanitize_key( wp_unslash( $_POST['connection'] ) ) : '';

			// Check if logging is enabled for diagnostic purposes.
			$existing_for_logging = get_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, array() );
			$enable_logging       = ! empty( $existing_for_logging['enable_logging'] ) || ! empty( $existing_for_logging['enable_extended_logging'] );

			// Log save attempt for debugging (only if logging enabled).
			if ( $enable_logging ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
				error_log(
					sprintf(
						'[NV oOS Settings] Save attempt - Tab: %s, Subtab: %s, Save all tabs: %s, Posted fields: %d, Posted keys: %s',
						$active_tab,
						$active_subtab,
						$save_all_tabs ? 'YES' : 'NO',
						count( $posted_settings ),
						implode( ', ', array_keys( $posted_settings ) )
					)
				);
			}

			// DEPRECATED: Simple Settings Saver is disabled because it's incompatible with partial forms.
			// All settings pages in this plugin use tabs/subtabs that only show partial fields.
			// The Simple Settings Saver's checkbox handling (setting all unposted checkboxes to false)
			// causes data loss when saving from tabs/subtabs. Use section-based sanitization instead.
			// See: https://github.com/nvdigitalsolutions/mcp-ai-wpoos/issues/XXXX.
			$use_simple_settings_saver = false; // Force disabled.

			if ( $use_simple_settings_saver && $save_all_tabs && empty( $active_subtab ) && class_exists( 'WP_MCP_AI_Simple_Settings_Saver' ) ) {
				// Initialize field types for the Simple Settings Saver.
				WP_MCP_AI_Simple_Settings_Saver::init_field_types();

				// Use Simple Settings Saver for optimized individual field sanitization.
				$sanitized_new = WP_MCP_AI_Simple_Settings_Saver::save_settings( $posted_settings, true );

				// Log that we used the simplified saver.
				if ( $enable_logging ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
					error_log(
						sprintf(
							'[NV oOS Settings] Using Simple Settings Saver - Sanitized fields: %d, Keys: %s',
							count( $sanitized_new ),
							implode( ', ', array_keys( $sanitized_new ) )
						)
					);
				}

				// Since Simple Settings Saver already saves to database, we skip the merge below.
				// Set flag to skip the database update step.
				$already_saved = true;
			} else {
				// Use section-based sanitization for main dashboard.
				// When save_all_tabs is true (e.g., from Simple Settings page), sanitize ALL tabs.
				// Otherwise, only sanitize the active tab to avoid clearing checkboxes from other tabs.
				//
				// CLARIFICATION FOR save_all_tabs FLAG:
				// - When save_all_tabs=1: $tab_to_sanitize is empty string ''
				// - Empty string '' in sanitize_settings() triggers ALL sections across ALL tabs (see line 139)
				// - This is safe for Simple Settings Page because it displays ALL fields from multiple tabs
				// - For regular tab-based saves, we only sanitize the active tab to preserve other tabs' data
				//
				// SUBTAB HANDLING (VERY IMPORTANT):
				// - When saving from a subtab (e.g., Providers → Gemini), only that subtab's fields are posted
				// - Section-based sanitization knows which fields belong to each subtab
				// - The merge strategy below (line 326+) preserves data from OTHER subtabs
				// - Sensitive key protection (line 329+) prevents empty values from overwriting existing keys
				// - This ensures subtabbed views with important tables save correctly without data loss.
				$tab_to_sanitize = $save_all_tabs ? '' : $active_tab;
				$sanitized_new   = $this->sanitize_settings( $posted_settings, $tab_to_sanitize );
				$already_saved   = false;

				// DEBUG: Specifically log checkbox values in sanitized_new to diagnose save issue.
				if ( $enable_logging ) {
					$checkbox_keys              = array( 'enable_mesh', 'enable_federation', 'enable_federation_directory' );
					$sanitized_checkboxes_after = array();
					foreach ( $checkbox_keys as $key ) {
						$sanitized_checkboxes_after[ $key ] = isset( $sanitized_new[ $key ] ) ?
							( $sanitized_new[ $key ] ? 'true' : 'false' ) :
							'NOT_IN_SANITIZED';
					}
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
					error_log(
						sprintf(
							'[NV oOS After Sanitize] Tab: %s, Subtab: %s, Checkbox values in sanitized_new: %s',
							$active_tab,
							$active_subtab,
							wp_json_encode( $sanitized_checkboxes_after )
						)
					);
				}

				// Log sanitization results.
				if ( $enable_logging ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
					error_log(
						sprintf(
							'[NV oOS Settings] After section-based sanitization - Sanitized fields: %d, Sanitized keys: %s',
							count( $sanitized_new ),
							implode( ', ', array_keys( $sanitized_new ) )
						)
					);
				}
			}

			// Skip database operations if Simple Settings Saver already saved.
			if ( ! isset( $already_saved ) || ! $already_saved ) {
				// ========================================================================
				// CRITICAL SETTINGS PERSISTENCE FIX
				// ========================================================================
				// This section implements robust settings handling to prevent data loss:
				// 1. Cache invalidation BEFORE reading to prevent stale data
				// 2. Backup current settings before merge for rollback capability
				// 3. Atomic update with validation
				// 4. Clear all related caches (object cache, transients)
				// ========================================================================

				// ========================================================================
				// STEP 1: Suspend object cache additions during critical section.
				// ========================================================================
				// Suspending cache addition prevents stale data from being written
				// back to the persistent object cache (Redis/Memcached) while we're
				// performing the read-merge-write cycle. This eliminates the most
				// common source of intermittent key wipes in production.
				// Capture the previous suspension state first: wp_suspend_cache_addition()
				// returns the *new* state, so passing true directly would make the
				// restore step below re-suspend instead of resuming (WP 7.1's
				// WP_Object_Cache::add() returns false while suspended, which would
				// silently jam cooperative tick locks for the rest of the request).
				$was_cache_suspended = false;
				if ( function_exists( 'wp_suspend_cache_addition' ) ) {
					$was_cache_suspended = wp_suspend_cache_addition();
					wp_suspend_cache_addition( true );
				}

				// Step 2: Clear ALL caches before reading existing settings.
				// This prevents race conditions and ensures we have the latest database values.
				WP_MCP_AI_Admin_Settings::reset_settings_cache();

				// Also clear any object cache entries for both options.
				wp_cache_delete( WP_MCP_AI_Admin_Settings::OPTION_NAME, 'options' );
				wp_cache_delete( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, 'options' );

				// Clear any transients that might cache settings.
				delete_transient( 'wp_mcp_ai_settings_cache' );

				// Step 3: Read current settings from database (bypassing all caches).
				// Use get_option() directly to ensure we get fresh data.
				// With cache addition suspended, get_option still reads from DB
				// if the cache is empty (which we just cleared).
				$existing_settings    = get_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, array() );
				$existing_credentials = get_option( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, array() );

				if ( ! is_array( $existing_settings ) ) {
					$existing_settings = array();
				}
				if ( ! is_array( $existing_credentials ) ) {
					$existing_credentials = array();
				}

				// Step 4: Create a backup of current settings for potential rollback.
				// Store with timestamp for auditing purposes. Include credentials
				// in the backup so a complete restore is possible.
				$backup_key  = 'wp_mcp_ai_settings_backup_' . time();
				$full_backup = array_merge( $existing_settings, $existing_credentials );
				update_option( $backup_key, $full_backup, false ); // No autoload for backups.

				// Clean up old backups (keep last 5).
				$this->cleanup_old_setting_backups( 5 );

				// Log critical provider keys BEFORE merge to help diagnose data loss issues.
				if ( $enable_logging ) {
					$provider_keys       = array( 'openai_api_key', 'gemini_api_key', 'ollama_endpoint_url', 'lm_studio_endpoint_url' );
					$existing_providers  = array();
					$sanitized_providers = array();
					foreach ( $provider_keys as $pkey ) {
						$found_in_settings    = isset( $existing_settings[ $pkey ] ) && ! empty( $existing_settings[ $pkey ] );
						$found_in_credentials = isset( $existing_credentials[ $pkey ] ) && ! empty( $existing_credentials[ $pkey ] );
						if ( $found_in_settings || $found_in_credentials ) {
							$existing_providers[ $pkey ] = $found_in_credentials ? '(in credentials)' : '(in settings)';
						}
						if ( isset( $sanitized_new[ $pkey ] ) ) {
							$sanitized_providers[ $pkey ] = empty( $sanitized_new[ $pkey ] ) ? '(EMPTY!)' : '(has value)';
						}
					}
					if ( ! empty( $existing_providers ) || ! empty( $sanitized_providers ) ) {
						// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- user-enabled diagnostic logging.
						error_log(
							sprintf(
								'[NV oOS Settings] Provider keys - Existing: %s, Sanitized: %s',
								empty( $existing_providers ) ? 'none' : wp_json_encode( $existing_providers ),
								empty( $sanitized_providers ) ? 'none' : wp_json_encode( $sanitized_providers )
							)
						);
					}
				}

				// ========================================================================
				// STEP 4: Enhanced Sensitive Key Protection
				// ========================================================================
				// Filter out sensitive keys from sanitized data to prevent accidental
				// deletion. A sensitive key value is accepted ONLY when the user has
				// explicitly typed a new non-empty, non-placeholder value. In all other
				// cases (absent from POST, empty, masked placeholder), the key is
				// removed from $sanitized_new so array_merge preserves the existing
				// stored value.
				//
				// This is a defense-in-depth measure that works together with the
				// two-option split: even if a sensitive key leaks into $sanitized_new
				// from a non-provider tab, the merge won't overwrite the stored value
				// unless the user explicitly provided a new one.
				$sensitive_keys = WP_MCP_AI_Admin_Settings_Base::get_sensitive_fields();

				// Also protect any key matching the sensitive pattern that may not
				// be in the explicit list (e.g., addon-provided keys).
				$extra_sensitive_keys = array(
					'ollama_endpoint_url',
					'lm_studio_endpoint_url',
					'cloudflare_account_id',
					'removebg_api_key',
					'rabbitmq_password',
					'meta_app_secret',
					'meta_access_token',
					'tiktok_access_token',
					'tiktok_client_secret',
					'yahoo_client_id',
				);
				$sensitive_keys       = array_unique( array_merge( $sensitive_keys, $extra_sensitive_keys ) );

				foreach ( $sensitive_keys as $key ) {
					if ( ! isset( $sanitized_new[ $key ] ) ) {
						// Not in POST at all — existing value preserved by merge.
						continue;
					}

					$val = $sanitized_new[ $key ];

					// Accept the value ONLY if the user explicitly typed a new,
					// non-empty, non-placeholder value.
					$is_explicit_new_value = is_string( $val )
						&& '' !== $val
						&& WP_MCP_AI_Admin_Settings_Base::MASKED_SECRET_PLACEHOLDER !== $val;

					if ( ! $is_explicit_new_value ) {
						if ( $enable_logging ) {
							$reason = ! isset( $sanitized_new[ $key ] ) ? 'not in POST' :
								( '' === $val ? 'empty string' :
								( '**************' === $val ? 'masked placeholder' : 'falsy value' ) );
							// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- user-enabled diagnostic logging.
							error_log(
								sprintf(
									'[NV oOS Settings] PROTECTION: Removing %s from sanitized data (%s) (tab=%s, save_all=%s)',
									$key,
									$reason,
									$active_tab,
									$save_all_tabs ? 'YES' : 'NO'
								)
							);
						}
						unset( $sanitized_new[ $key ] );
					}
				}

				// ========================================================================
				// STEP 5: Auto-clear OAuth tokens when credentials change
				// ========================================================================
				// When a user changes their OAuth Client ID or Client Secret, the old
				// refresh token is no longer valid for the new credentials. Force-clear
				// associated tokens so the OAuth callback cannot resurrect stale
				// account bindings via its fallback that reuses old refresh tokens.
				$oauth_credential_token_map = array(
					// Gmail.
					'gmail_client_id'               => array( 'gmail_refresh_token', 'gmail_user_email' ),
					'gmail_client_secret'           => array( 'gmail_refresh_token', 'gmail_user_email' ),
					// Google Drive.
					'google_drive_client_id'        => array( 'google_drive_refresh_token', 'google_drive_user_email' ),
					'google_drive_client_secret'    => array( 'google_drive_refresh_token', 'google_drive_user_email' ),
					// Google Calendar. The scope profile is included because changing it
					// changes the requested scope set, which invalidates the existing grant.
					'google_calendar_client_id'     => array( 'google_calendar_refresh_token', 'google_calendar_user_email', 'google_calendar_granted_scopes' ),
					'google_calendar_client_secret' => array( 'google_calendar_refresh_token', 'google_calendar_user_email', 'google_calendar_granted_scopes' ),
					'google_calendar_scope_profile' => array( 'google_calendar_refresh_token', 'google_calendar_user_email', 'google_calendar_granted_scopes' ),
					// Meta.
					'meta_app_id'                   => array( 'meta_access_token', 'meta_connected_user_name', 'meta_connected_user_id' ),
					'meta_app_secret'               => array( 'meta_access_token', 'meta_connected_user_name', 'meta_connected_user_id' ),
				);

				foreach ( $oauth_credential_token_map as $credential_key => $token_keys ) {
					$old_value = isset( $existing_settings[ $credential_key ] ) ? $existing_settings[ $credential_key ] : '';
					$new_value = isset( $sanitized_new[ $credential_key ] ) ? $sanitized_new[ $credential_key ] : $old_value;

					if ( $new_value !== $old_value && '' !== $new_value ) {
						foreach ( $token_keys as $token_key ) {
							$sanitized_new[ $token_key ] = '';
						}
						if ( $enable_logging ) {
							// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- user-enabled diagnostic logging.
							error_log(
								sprintf(
									'[NV oOS Settings] Credential change: %s → clearing %s',
									$credential_key,
									implode( ', ', $token_keys )
								)
							);
						}
					}
				}

				// ========================================================================
				// STEP 6: Merge Settings with Validation
				// ========================================================================
				// DEBUG: Log checkbox values before merge to diagnose persistence issue.
				if ( $enable_logging ) {
					$checkbox_keys        = array( 'enable_mesh', 'enable_federation', 'enable_federation_directory' );
					$existing_checkboxes  = array();
					$sanitized_checkboxes = array();
					foreach ( $checkbox_keys as $key ) {
						if ( isset( $existing_settings[ $key ] ) ) {
							$existing_checkboxes[ $key ] = $existing_settings[ $key ] ? 'true' : 'false';
						}
						if ( isset( $sanitized_new[ $key ] ) ) {
							$sanitized_checkboxes[ $key ] = $sanitized_new[ $key ] ? 'true' : 'false';
						}
					}
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
					error_log(
						sprintf(
							'[NV oOS Checkbox Merge] Existing: %s, Sanitized: %s',
							wp_json_encode( $existing_checkboxes ),
							wp_json_encode( $sanitized_checkboxes )
						)
					);
				}

				$merged_settings = array_merge( $existing_settings, $sanitized_new );

				// Log federation checkbox merge for debugging (only if logging enabled).
				if ( $enable_logging ) {
					$fed_keys     = array( 'enable_mesh', 'enable_federation', 'enable_federation_directory' );
					$has_fed      = false;
					$before_merge = array();
					$after_merge  = array();
					foreach ( $fed_keys as $key ) {
						if ( isset( $existing_settings[ $key ] ) || isset( $sanitized_new[ $key ] ) || isset( $merged_settings[ $key ] ) ) {
							$has_fed                = true;
							$before_merge[ $key ]   = isset( $existing_settings[ $key ] ) ? var_export( $existing_settings[ $key ], true ) : 'NOT_SET';
							$from_sanitized[ $key ] = isset( $sanitized_new[ $key ] ) ? var_export( $sanitized_new[ $key ], true ) : 'NOT_SET';
							$after_merge[ $key ]    = isset( $merged_settings[ $key ] ) ? var_export( $merged_settings[ $key ], true ) : 'NOT_SET';
						}
					}
					if ( $has_fed ) {
						// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
						error_log(
							sprintf(
								'[NV oOS FEDERATION DEBUG] MERGE: Before=%s, From Sanitized=%s, After=%s',
								wp_json_encode( $before_merge ),
								wp_json_encode( $from_sanitized ),
								wp_json_encode( $after_merge )
							)
						);
					}
				}

				// ========================================================================
				// STEP 6a: Auto-generate mesh API key if needed
				// ========================================================================
				// Check if mesh networking or federation directory was just enabled and generate API key if needed.
				// This must happen BEFORE validation and save to avoid race conditions.
				$mesh_features_enabled = ! empty( $merged_settings['enable_mesh'] ) || ! empty( $merged_settings['enable_federation_directory'] );
				if ( $mesh_features_enabled && empty( $merged_settings['mesh_inbound_api_key'] ) ) {
					try {
						// Generate mesh inbound API key for peer authentication.
						$merged_settings['mesh_inbound_api_key'] = 'mesh_' . bin2hex( random_bytes( 32 ) );

						if ( $enable_logging ) {
							// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
							error_log( '[NV oOS Settings] Mesh/Federation enabled - auto-generated mesh_inbound_api_key' );
						}
					} catch ( Exception $e ) {
						// Handle random_bytes() exception gracefully.
						if ( $enable_logging ) {
							// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
							error_log(
								sprintf(
									'[NV oOS Settings] Failed to generate mesh API key: %s',
									$e->getMessage()
								)
							);
						}
						add_settings_error(
							'wp_mcp_ai_settings',
							'mesh_key_generation_failed',
							sprintf(
								/* translators: %s: Error message from exception */
								__( 'Failed to generate mesh API key due to insufficient system entropy: %s. This is typically a server configuration issue. Please ensure your server has proper random number generation available (check /dev/urandom on Linux systems) or contact your hosting provider.', 'mcp-ai-wpoos' ),
								esc_html( $e->getMessage() )
							),
							'error'
						);
					}
				}

				// Validate merged settings before saving.
				$validation_errors = $this->validate_merged_settings( $merged_settings, $existing_settings );
				if ( ! empty( $validation_errors ) ) {
					if ( $enable_logging ) {
						// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
						error_log(
							sprintf(
								'[NV oOS Settings] VALIDATION ERRORS: %s',
								implode( '; ', $validation_errors )
							)
						);
					}
					// Add settings errors for display to user.
					foreach ( $validation_errors as $error ) {
						add_settings_error( 'wp_mcp_ai_settings', 'validation_error', $error, 'error' );
					}
					// Rollback: Don't save if validation failed.
					$update_result = false;
				} else {
					// ========================================================================
					// STEP 6: Split and Save — Credentials vs Settings
					// ========================================================================
					// Sensitive credential fields (API keys, tokens, secrets) are stored
					// in wp_mcp_ai_credentials with autoload=false to keep them out of
					// the alloptions payload on every page request. Non-sensitive
					// configuration stays in wp_mcp_ai_settings with autoload=true.
					//
					// CRITICAL: Never delete the credentials option. It must persist
					// across saves from non-provider tabs. Incoming credentials are
					// merged with existing — the incoming value takes precedence only
					// when the user explicitly typed a new value (guaranteed by Step 4).
					$incoming_credentials   = array();
					$incoming_non_sensitive = array();

					foreach ( $merged_settings as $key => $value ) {
						if ( WP_MCP_AI_Admin_Settings_Base::is_sensitive_setting_key( $key ) ) {
							$incoming_credentials[ $key ] = $value;
						} else {
							$incoming_non_sensitive[ $key ] = $value;
						}
					}

					// Merge incoming credentials with existing — never wipe.
					// Existing credentials take precedence for keys the user did NOT
					// explicitly change (those keys were removed from $sanitized_new
					// in Step 4, so they're absent from $incoming_credentials too).
					$final_credentials = array_merge( $existing_credentials, $incoming_credentials );

					// Save non-sensitive settings (autoload=true for performance).
					$update_result = update_option(
						WP_MCP_AI_Admin_Settings::OPTION_NAME,
						$incoming_non_sensitive,
						true
					);

					// Save credentials (autoload=false to keep out of alloptions).
					// NEVER delete — absence of incoming credentials means "keep
					// what was already stored", not "delete everything".
					if ( count( $final_credentials ) > 0 ) {
						update_option(
							WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME,
							$final_credentials,
							false
						);
					}
					// NOTE: No else { delete_option(...) } here. The bug in #5685
					// was deleting the credentials option when no new credentials
					// arrived in POST, which wiped API keys from other providers.

					// Log credential save diagnostics.
					if ( $enable_logging ) {
						// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- user-enabled diagnostic logging.
						error_log(
							sprintf(
								'[NV oOS Settings] Credential split - Non-sensitive: %d fields, Credentials: %d existing + %d incoming = %d final',
								count( $incoming_non_sensitive ),
								count( $existing_credentials ),
								count( $incoming_credentials ),
								count( $final_credentials )
							)
						);
					}

					// Log federation checkbox save result for debugging (only if logging enabled).
					if ( $enable_logging ) {
						$fed_keys     = array( 'enable_mesh', 'enable_federation', 'enable_federation_directory' );
						$has_fed      = false;
						$saved_values = array();
						foreach ( $fed_keys as $fkey ) {
							if ( isset( $merged_settings[ $fkey ] ) ) {
								$has_fed               = true;
								$saved_values[ $fkey ] = var_export( $merged_settings[ $fkey ], true );
							}
						}
						if ( $has_fed ) {
							// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- user-enabled diagnostic logging.
							error_log(
								sprintf(
									'[NV oOS FEDERATION DEBUG] SAVE: Result=%s, Values=%s',
									$update_result ? 'SUCCESS' : 'UNCHANGED',
									wp_json_encode( $saved_values )
								)
							);
						}
					}

					if ( $enable_logging ) {
						// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- user-enabled diagnostic logging.
						error_log(
							sprintf(
								'[NV oOS Settings] Database update - Result: %s, Non-sensitive: %d fields, Credentials: %d fields',
								$update_result ? 'SUCCESS' : 'UNCHANGED',
								count( $incoming_non_sensitive ),
								count( $final_credentials )
							)
						);
					}

					// ========================================================================
					// STEP 7: Restore Cache and Final Invalidation
					// ========================================================================
					// Restore the previous cache addition state.
					if ( function_exists( 'wp_suspend_cache_addition' ) ) {
						wp_suspend_cache_addition( $was_cache_suspended );
					}

					// Clear all caches again after successful save.
					WP_MCP_AI_Admin_Settings::reset_settings_cache();
					wp_cache_delete( WP_MCP_AI_Admin_Settings::OPTION_NAME, 'options' );
					wp_cache_delete( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, 'options' );
					delete_transient( 'wp_mcp_ai_settings_cache' );

					// Fire action hook for extensions to clear their own caches.
					do_action( 'wp_mcp_ai_settings_saved', $merged_settings, $existing_settings, $sanitized_new );
				}

				// Check if media toolkit was just enabled and seed presets if needed.
				$was_toolkit_disabled = empty( $existing_settings['enable_media_toolkit'] );
				$is_toolkit_enabled   = ! empty( $merged_settings['enable_media_toolkit'] );
				if ( $was_toolkit_disabled && $is_toolkit_enabled ) {
					// Media toolkit was just enabled, seed the template presets.
					if ( class_exists( 'WP_MCP_AI_Media_Template_Presets' ) ) {
						WP_MCP_AI_Media_Template_Presets::seed_presets();

						if ( $enable_logging ) {
							// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
							error_log( '[NV oOS Settings] Media toolkit enabled - triggered template preset seeding' );
						}
					}
				}

				// Check if Architect Agent Toolkit was just enabled and create assistant.
				$was_architect_disabled = empty( $existing_settings['enable_architect_agent_toolkit'] );
				$is_architect_enabled   = ! empty( $merged_settings['enable_architect_agent_toolkit'] );
				if ( $was_architect_disabled && $is_architect_enabled ) {
					// Architect Agent Toolkit was just enabled, create the assistant.
					if ( class_exists( 'WP_MCP_AI_Default_Assistants' ) ) {
						$result = WP_MCP_AI_Default_Assistants::install_architect_agent_assistant();

						if ( $enable_logging ) {
							if ( is_wp_error( $result ) ) {
								// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
								error_log(
									sprintf(
										'[NV oOS Settings] Architect Agent Toolkit enabled - assistant creation failed: %s',
										$result->get_error_message()
									)
								);
							} else {
								// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
								error_log(
									sprintf(
										'[NV oOS Settings] Architect Agent Toolkit enabled - assistant created (ID: %d)',
										$result
									)
								);
							}
						}
					}
				}
			} else {
				// Get the merged settings from database (Simple Settings Saver already saved).
				$merged_settings = get_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, array() );

				if ( $enable_logging ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used for user-enabled diagnostic logging; active only when plugin logging is explicitly enabled in settings.
					error_log( '[NV oOS Settings] Skipped database update - Simple Settings Saver already saved' );
				}
			}

			// Clear caches when settings are updated.
			if ( 'orchestration' === $active_tab ) {
				// Clear orchestration-related caches using Cache Helper.
				WP_MCP_AI_Cache_Helper::invalidate_orchestration_caches();

				if ( class_exists( 'WP_MCP_AI_Orchestration_Health_Service' ) ) {
					WP_MCP_AI_Orchestration_Health_Service::clear_health_cache();
				}
			}

			// Redirect back to the same tab that was being edited.
			// Check if a custom redirect page is specified (e.g., for simple settings page).
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$redirect_page = isset( $_POST['redirect_page'] ) ? sanitize_key( wp_unslash( $_POST['redirect_page'] ) ) : self::PAGE_SLUG;

			$redirect_args = array(
				'page'    => $redirect_page,
				'updated' => 'true',
			);

			if ( ! empty( $active_tab ) ) {
				$redirect_args['tab'] = $active_tab;
			}

			// Preserve subtab parameter for sections with sub-navigation (e.g., Authentication).
			if ( ! empty( $active_subtab ) ) {
				$redirect_args['subtab'] = $active_subtab;
			}

			// Preserve connection parameter for Integrations section connections.
			if ( ! empty( $active_connection ) ) {
				$redirect_args['connection'] = $active_connection;
			}

			// Preserve view parameter for sections with view-based navigation (e.g., Orchestration, Token Manager).
			if ( ! empty( $active_view ) ) {
				$redirect_args['view'] = $active_view;
			}

			// Add count of saved fields for user feedback.
			if ( isset( $sanitized_new ) && is_array( $sanitized_new ) ) {
				$redirect_args['saved'] = count( $sanitized_new );
			}

			// Determine redirect URL based on page type.
			if ( self::PAGE_SLUG === $redirect_page ) {
				// Main dashboard - use admin.php.
				$redirect_url = admin_url( 'admin.php' );
			} else {
				// Simple settings page - use options-general.php.
				$redirect_url = admin_url( 'options-general.php' );
			}

			if ( wp_safe_redirect(
				add_query_arg(
					$redirect_args,
					$redirect_url
				)
			) ) {
				exit;
			}
		}

		/**
		 * Get the appropriate asset file (minified or unminified).
		 *
		 * Uses minified version in production, unminified when SCRIPT_DEBUG is enabled.
		 * Falls back to unminified if minified doesn't exist.
		 *
		 * @param string $file_path Relative path to the asset file (e.g., 'assets/js/settings-dashboard.js').
		 * @return array Array with 'url', 'path', and 'version' keys.
		 */
		private function get_asset_file( $file_path ) {
			$use_minified = ! ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG );
			$extension    = pathinfo( $file_path, PATHINFO_EXTENSION );
			$base_path    = preg_replace( '/\.' . $extension . '$/', '', $file_path );

			// Try minified version first if not in debug mode.
			if ( $use_minified ) {
				$minified_path = $base_path . '.min.' . $extension;
				$full_path     = WP_MCP_AI_PATH . $minified_path;

				if ( file_exists( $full_path ) ) {
					return array(
						'url'     => WP_MCP_AI_URL . $minified_path,
						'path'    => $full_path,
						'version' => filemtime( $full_path ),
					);
				}
			}

			// Fall back to unminified version.
			$full_path = WP_MCP_AI_PATH . $file_path;
			return array(
				'url'     => WP_MCP_AI_URL . $file_path,
				'path'    => $full_path,
				'version' => file_exists( $full_path ) ? filemtime( $full_path ) : WP_MCP_AI_VERSION,
			);
		}

		/**
		 * Enqueue CSS and JavaScript assets for the dashboard.
		 *
		 * @param string $hook Current admin page hook.
		 */
		public function enqueue_assets( $hook ) {
			if ( 'toplevel_page_' . self::PAGE_SLUG !== $hook ) {
				return;
			}

			// Get asset files (automatically uses minified in production, unminified in debug mode).
			$responsive_css = $this->get_asset_file( 'assets/css/admin-responsive-utilities.css' );
			$dashboard_css  = $this->get_asset_file( 'assets/css/settings-dashboard.css' );
			$ajax_error_js  = $this->get_asset_file( 'assets/js/ajax-error-service.js' );
			$dashboard_js   = $this->get_asset_file( 'assets/js/settings-dashboard.js' );

			// Enqueue responsive utilities first (base styles).
			wp_enqueue_style(
				'wp-mcp-ai-responsive-utilities',
				$responsive_css['url'],
				array(),
				$responsive_css['version']
			);

			// Enqueue dashboard styles with file modification time for cache busting.
			wp_enqueue_style(
				'wp-mcp-ai-dashboard',
				$dashboard_css['url'],
				array( 'wp-mcp-ai-responsive-utilities' ),
				$dashboard_css['version']
			);

			// Enqueue tools manager styles if on tools tab.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only query parameter check.
			if ( isset( $_GET['tab'] ) && 'tools' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ) {
				$tools_css = $this->get_asset_file( 'assets/css/tools-manager.css' );
				wp_enqueue_style(
					'wp-mcp-ai-tools-manager',
					$tools_css['url'],
					array( 'wp-mcp-ai-dashboard' ),
					$tools_css['version']
				);
			}

			$inline_style_handles = array(
				'wp-mcp-ai-orchestration-renderer',
				'wp-mcp-ai-section-providers',
				'wp-mcp-ai-section-security',
			);

			foreach ( $inline_style_handles as $inline_style_handle ) {
				// Register dummy stylesheet handles for section renderers that print inline styles later.
				// phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Dummy handle; version not applicable.
				wp_register_style( $inline_style_handle, false );
				wp_enqueue_style( $inline_style_handle );
			}

			// Enqueue AJAX error service (must be loaded before other scripts) with filemtime for cache busting.
			wp_enqueue_script(
				'wp-mcp-ai-ajax-error-service',
				$ajax_error_js['url'],
				array( 'jquery' ),
				$ajax_error_js['version'],
				true
			);

			// Enqueue dashboard scripts with jQuery UI Sortable dependency and filemtime for cache busting.
			wp_enqueue_script(
				'wp-mcp-ai-dashboard',
				$dashboard_js['url'],
				array( 'jquery', 'jquery-ui-sortable', 'wp-mcp-ai-ajax-error-service' ),
				$dashboard_js['version'],
				true
			);

			// Enqueue the WordPress REST API client (wp-api) on the security tab.
			// The security section prints inline scripts (posture refresh, IP tests,
			// snapshot restore, compliance export, self-test) that call wp.apiRequest().
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only query parameter check.
			if ( isset( $_GET['tab'] ) && 'security' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ) {
				wp_enqueue_script( 'wp-api' );
			}

			// Enqueue tools manager scripts if on tools tab.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only query parameter check.
			if ( isset( $_GET['tab'] ) && 'tools' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ) {
				$tools_js = $this->get_asset_file( 'assets/js/tools-manager.js' );
				wp_enqueue_script(
					'wp-mcp-ai-tools-manager',
					$tools_js['url'],
					array( 'jquery', 'wp-mcp-ai-ajax-error-service' ),
					$tools_js['version'],
					true
				);
			}

			// Enqueue admin settings scripts if on providers tab (for embedded model management).
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only query parameter check.
			if ( isset( $_GET['tab'] ) && 'providers' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ) {
				$admin_settings_js = $this->get_asset_file( 'assets/js/admin-settings.js' );
				wp_enqueue_script(
					'wp-mcp-ai-admin-settings',
					$admin_settings_js['url'],
					array( 'jquery', 'jquery-ui-sortable', 'wp-mcp-ai-ajax-error-service' ),
					$admin_settings_js['version'],
					true
				);
			}

			// Enqueue tool orchestration scripts if on orchestration tab.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only query parameter check.
			if ( isset( $_GET['tab'] ) && 'orchestration' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ) {
				$orchestration_js = $this->get_asset_file( 'assets/js/admin-tool-orchestration.js' );
				wp_enqueue_script(
					'wp-mcp-ai-tool-orchestration',
					$orchestration_js['url'],
					array( 'jquery', 'wp-mcp-ai-ajax-error-service', 'wp-i18n' ),
					$orchestration_js['version'],
					true
				);
				wp_set_script_translations( 'wp-mcp-ai-tool-orchestration', 'mcp-ai-wpoos' );
			}

			// Enqueue performance admin scripts if on advanced tab.
			// When no subtab is specified, performance_monitoring is the default (see
			// WP_MCP_AI_Section_Advanced::get_active_subtab).
			// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only query parameter checks.
			if ( isset( $_GET['tab'] ) && 'advanced' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ) {
				$subtab = isset( $_GET['subtab'] ) ? sanitize_key( wp_unslash( $_GET['subtab'] ) ) : 'performance_monitoring';
				// phpcs:enable WordPress.Security.NonceVerification.Recommended
				if ( 'performance_monitoring' === $subtab ) {
					$performance_js = $this->get_asset_file( 'assets/js/performance-admin.js' );
					wp_enqueue_script(
						'wp-mcp-ai-performance-admin',
						$performance_js['url'],
						array( 'jquery' ),
						$performance_js['version'],
						true
					);

					wp_localize_script(
						'wp-mcp-ai-performance-admin',
						'wpMcpAiPerformance',
						array(
							'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
							'nonce'       => wp_create_nonce( 'wp_mcp_ai_performance' ),
							'runningText' => __( 'Running...', 'mcp-ai-wpoos' ),
						)
					);
				}
			}

			// Enqueue mesh peer test scripts if on advanced tab with federation_mesh subtab.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only query parameter check.
			if ( isset( $_GET['tab'] ) && 'advanced' === sanitize_key( wp_unslash( $_GET['tab'] ) ) && isset( $_GET['subtab'] ) && 'federation_mesh' === sanitize_key( wp_unslash( $_GET['subtab'] ) ) ) {
				$mesh_test_js = $this->get_asset_file( 'assets/js/mesh-peer-test.js' );
				wp_enqueue_script(
					'wp-mcp-ai-mesh-peer-test',
					$mesh_test_js['url'],
					array( 'jquery' ),
					$mesh_test_js['version'],
					true
				);

				wp_localize_script(
					'wp-mcp-ai-mesh-peer-test',
					'wpMcpAiMeshTest',
					array(
						'restUrl'           => rest_url(),
						'nonce'             => wp_create_nonce( 'wp_rest' ),
						'testing'           => __( 'Testing...', 'mcp-ai-wpoos' ),
						'successMessage'    => __( 'Connection test successful!', 'mcp-ai-wpoos' ),
						'errorGeneric'      => __( 'Connection test failed. Please check the URL and API key.', 'mcp-ai-wpoos' ),
						'errorNoUrl'        => __( 'Please enter a site URL before testing.', 'mcp-ai-wpoos' ),
						'reachable'         => __( 'Site is reachable', 'mcp-ai-wpoos' ),
						'federationEnabled' => __( 'Federation enabled', 'mcp-ai-wpoos' ),
						'authSuccess'       => __( 'Authentication successful', 'mcp-ai-wpoos' ),
						'authFailed'        => __( 'Authentication failed', 'mcp-ai-wpoos' ),
						'authSkipped'       => __( 'Authentication not tested (no API key)', 'mcp-ai-wpoos' ),
					)
				);
			}

			// Localize script with settings.
			wp_localize_script(
				'wp-mcp-ai-dashboard',
				'wpMcpAiDashboard',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'wp_mcp_ai_dashboard' ),
				)
			);

			// Add admin nonce for tools manager and connection tests.
			// Using 'wp-mcp-ai-settings' nonce to match AJAX handler expectations.
			wp_localize_script(
				'wp-mcp-ai-dashboard',
				'wpMcpAiAdmin',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'wp-mcp-ai-settings' ),
					'i18n'    => array(
						'enabled'  => __( 'Enabled', 'mcp-ai-wpoos' ),
						'disabled' => __( 'Disabled', 'mcp-ai-wpoos' ),
					),
				)
			);
		}

		/**
		 * Get the currently active tab.
		 *
		 * @return string Active tab ID.
		 */
		private function get_active_tab() {
			$tabs = WP_MCP_AI_Settings_Registry::get_tabs();
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter for tab display.
			$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general';

			if ( ! isset( $tabs[ $active_tab ] ) ) {
				$active_tab = 'general';
			}

			// Child tabs (e.g. the commerce sync toolkits) render as subtabs of
			// their parent tab, so legacy ?tab=<child> URLs resolve to the parent.
			if ( ! empty( $tabs[ $active_tab ]['subtab_of'] ) && isset( $tabs[ $tabs[ $active_tab ]['subtab_of'] ] ) ) {
				$active_tab = $tabs[ $active_tab ]['subtab_of'];
			}

			return $active_tab;
		}

		/**
		 * Get the sections rendered on a tab, including sections that belong to
		 * child tabs (tabs declaring `subtab_of` pointing at this tab).
		 *
		 * The commerce sync toolkits (EZuite, Shopify Sync, FlowHub) keep their
		 * own registry tabs for the settings schema / SPA contract but render as
		 * subtabs of E-Commerce in wp-admin, so both render and save must see
		 * their sections when the parent tab is active.
		 *
		 * @since 1.2.14
		 *
		 * @param string $tab_id Tab ID.
		 * @return array<WP_MCP_AI_Settings_Section>
		 */
		private function get_sections_for_tab( $tab_id ) {
			$sections = WP_MCP_AI_Settings_Registry::get_sections( $tab_id );

			foreach ( WP_MCP_AI_Settings_Registry::get_tabs() as $candidate_id => $candidate ) {
				if ( ! empty( $candidate['subtab_of'] ) && $tab_id === $candidate['subtab_of'] ) {
					$sections = array_merge( $sections, WP_MCP_AI_Settings_Registry::get_sections( $candidate_id ) );
				}
			}

			return $sections;
		}

		/**
		 * Render the settings dashboard.
		 */
		public function render_dashboard() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have permission to access this page.', 'mcp-ai-wpoos' ) );
			}

			$active_tab = $this->get_active_tab();
			$tabs       = WP_MCP_AI_Settings_Registry::get_tabs();
			$sections   = $this->get_sections_for_tab( $active_tab );

			?>
			<div class="wrap wp-mcp-ai-settings-dashboard">
				<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

				<?php settings_errors( 'wp_mcp_ai_settings' ); ?>

				<?php
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only query parameter for admin notice display.
				if ( isset( $_GET['updated'] ) && 'true' === sanitize_key( wp_unslash( $_GET['updated'] ) ) ) :
					?>
					<div class="notice notice-success is-dismissible">
						<p><?php esc_html_e( 'Settings saved successfully.', 'mcp-ai-wpoos' ); ?></p>
					</div>
				<?php endif; ?>

				<nav class="nav-tab-wrapper wp-clearfix" aria-label="<?php esc_attr_e( 'Settings tabs', 'mcp-ai-wpoos' ); ?>">
					<?php foreach ( $tabs as $tab_id => $tab ) : ?>
						<?php
						// Tabs declared as children of another tab (subtab_of) render
						// inside their parent's content, not as top-level nav tabs.
						if ( ! empty( $tab['subtab_of'] ) ) {
							continue;
						}
						$tab_url = add_query_arg(
							array(
								'page' => self::PAGE_SLUG,
								'tab'  => $tab_id,
							),
							admin_url( 'admin.php' )
						);
						$active  = ( $tab_id === $active_tab ) ? 'nav-tab-active' : '';
						?>
						<a href="<?php echo esc_url( $tab_url ); ?>" class="nav-tab <?php echo esc_attr( $active ); ?>">
							<span class="dashicons <?php echo esc_attr( $tab['icon'] ); ?>"></span>
							<?php echo esc_html( $tab['title'] ); ?>
						</a>
					<?php endforeach; ?>
				</nav>

				<form id="wp-mcp-ai-settings-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'wp_mcp_ai_save_settings' ); ?>
					<input type="hidden" name="action" value="wp_mcp_ai_save_settings" />
					<input type="hidden" name="active_tab" value="<?php echo esc_attr( $active_tab ); ?>" />

					<div class="tab-content">
						<?php if ( empty( $sections ) ) : ?>
							<div class="notice notice-info">
								<p><?php esc_html_e( 'No settings available for this tab.', 'mcp-ai-wpoos' ); ?></p>
							</div>
						<?php else : ?>
							<?php foreach ( $sections as $section ) : ?>
								<?php $section->render_wrapper(); ?>
							<?php endforeach; ?>
						<?php endif; ?>
					</div>

					<?php if ( ! empty( $sections ) ) : ?>
						<?php submit_button(); ?>
					<?php endif; ?>
				</form>
			</div>
			<?php
		}

		/**
		 * Hide the WordPress admin footer text on the NV oOS settings dashboard.
		 *
		 * @param string $footer_text The default footer text.
		 * @return string Empty string on settings dashboard, original text elsewhere.
		 */
		public function hide_admin_footer_text( $footer_text ) {
			if ( ! $this->is_settings_dashboard() ) {
				return $footer_text;
			}

			return '';
		}

		/**
		 * Hide the WordPress version footer text on the NV oOS settings dashboard.
		 *
		 * @param string $footer_text The default version footer text.
		 * @return string Empty string on settings dashboard, original text elsewhere.
		 */
		public function hide_update_footer_text( $footer_text ) {
			if ( ! $this->is_settings_dashboard() ) {
				return $footer_text;
			}

			return '';
		}

		/**
		 * Check if the current admin page is the NV oOS settings dashboard.
		 *
		 * @return bool True if on settings dashboard, false otherwise.
		 */
		protected function is_settings_dashboard() {
			if ( ! function_exists( 'get_current_screen' ) ) {
				return false;
			}

			$screen = get_current_screen();
			if ( ! $screen ) {
				return false;
			}

			// Check if we're on the settings dashboard.
			// The screen ID format is 'toplevel_page_{page_slug}'.
			return 'toplevel_page_' . self::PAGE_SLUG === $screen->id;
		}

		/**
		 * Validate merged settings before saving.
		 *
		 * Performs integrity checks to prevent corrupt or invalid data from being saved.
		 *
		 * @param array $merged_settings The settings after merging new values with existing.
		 * @param array $existing_settings The previous settings from database.
		 * @return array Array of validation error messages (empty if valid).
		 */
		private function validate_merged_settings( $merged_settings, $existing_settings ) {
			$errors = array();

			// Check 1: Ensure merged settings is an array.
			if ( ! is_array( $merged_settings ) ) {
				$errors[] = 'Merged settings must be an array.';
				return $errors; // Fatal error, return immediately.
			}

			// Check 2: Verify no critical settings were accidentally removed.
			$critical_keys = array( 'default_provider', 'default_model', 'provider_priority_list' );
			foreach ( $critical_keys as $key ) {
				if ( isset( $existing_settings[ $key ] ) && ! isset( $merged_settings[ $key ] ) ) {
					$errors[] = sprintf( 'Critical setting "%s" was removed during merge.', $key );
				}
			}

			// Check 3: Validate provider priority list structure.
			if ( isset( $merged_settings['provider_priority_list'] ) && ! is_array( $merged_settings['provider_priority_list'] ) ) {
				$errors[] = 'Provider priority list must be an array.';
			}

			// Check 4: Validate mesh peer sites structure if present.
			if ( isset( $merged_settings['mesh_peer_sites'] ) && ! is_array( $merged_settings['mesh_peer_sites'] ) ) {
				$errors[] = 'Mesh peer sites must be an array.';
			}

			// Check 5: Ensure numeric settings are actually numeric.
			$numeric_keys = array( 'default_assistant', 'max_history_messages', 'request_timeout', 'memory_max_file_bytes' );
			foreach ( $numeric_keys as $key ) {
				if ( isset( $merged_settings[ $key ] ) && ! is_numeric( $merged_settings[ $key ] ) ) {
					$errors[] = sprintf( 'Setting "%s" must be numeric, got: %s', $key, gettype( $merged_settings[ $key ] ) );
				}
			}

			// Check 6: Validate URL format for endpoint settings.
			$url_keys = array( 'ollama_endpoint_url', 'lm_studio_endpoint_url', 'crawl4ai_base_url', 'playwright_service_url' );
			foreach ( $url_keys as $key ) {
				if ( ! empty( $merged_settings[ $key ] ) && false === filter_var( $merged_settings[ $key ], FILTER_VALIDATE_URL ) ) {
					$errors[] = sprintf( 'Setting "%s" must be a valid URL: %s', $key, esc_html( $merged_settings[ $key ] ) );
				}
			}

			// Check 7: Validate email format for email settings.
			$email_keys = array( 'cloudways_email', 'mailjet_from_email', 'gmail_user_email' );
			foreach ( $email_keys as $key ) {
				if ( ! empty( $merged_settings[ $key ] ) && ! is_email( $merged_settings[ $key ] ) ) {
					$errors[] = sprintf( 'Setting "%s" must be a valid email address: %s', $key, esc_html( $merged_settings[ $key ] ) );
				}
			}

			/**
			 * Filter validation errors before saving settings.
			 *
			 * Allows plugins to add custom validation rules.
			 *
			 * @param array $errors Array of error messages.
			 * @param array $merged_settings Settings after merge.
			 * @param array $existing_settings Previous settings.
			 */
			return apply_filters( 'wp_mcp_ai_validate_settings', $errors, $merged_settings, $existing_settings );
		}

		/**
		 * Clean up old settings backups.
		 *
		 * Keeps only the most recent N backups to prevent database bloat.
		 *
		 * @param int $keep_count Number of backups to keep.
		 */
		private function cleanup_old_setting_backups( $keep_count = 5 ) {
			global $wpdb;

			// Find all backup options.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query against wp_options for plugin backup option names; result caching would return a stale list of available backups.
			$backup_options = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT option_name FROM {$wpdb->options} 
					WHERE option_name LIKE %s 
					ORDER BY option_name DESC",
					'wp_mcp_ai_settings_backup_%'
				)
			);

			// If we have more backups than we want to keep, delete the oldest ones.
			if ( count( $backup_options ) > $keep_count ) {
				$backups_to_delete = array_slice( $backup_options, $keep_count );
				foreach ( $backups_to_delete as $backup_option ) {
					delete_option( $backup_option );
				}
			}
		}

		/**
		 * Handle settings export AJAX request.
		 *
		 * Delegates to the Export Manager for provider-based export.
		 * Supports ?providers=id1,id2 query param for selective export.
		 * Supports ?password=... for encrypted export.
		 *
		 * @since 1.0.0
		 */
		public function handle_export_settings() {
			check_ajax_referer( 'wp-mcp-ai-dashboard', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mcp-ai-wpoos' ) ) );
			}

			// Determine which providers to export.
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Split sanitized below.
			$provider_ids = array();
			if ( ! empty( $_GET['providers'] ) ) {
				$provider_ids = explode( ',', sanitize_text_field( wp_unslash( $_GET['providers'] ) ) );
				$provider_ids = array_map( 'sanitize_key', $provider_ids );
			}

			// Optional password for encrypted export.
			$password = '';
			if ( ! empty( $_GET['password'] ) ) {
				$password = sanitize_text_field( wp_unslash( $_GET['password'] ) );
			}

			// Delegate to Export Manager if available.
			if ( class_exists( 'WP_MCP_AI_Export_Manager' ) ) {
				$manager = WP_MCP_AI_Export_Manager::instance();
				$json    = $manager->export( $provider_ids, $password );
			} else {
				// Fallback: legacy export (core settings only).
				WP_MCP_AI_Admin_Settings::reset_settings_cache();
				wp_cache_delete( WP_MCP_AI_Admin_Settings::OPTION_NAME, 'options' );
				wp_cache_delete( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, 'options' );
				$settings = WP_MCP_AI_Admin_Settings::get_settings();
				$json     = wp_json_encode(
					array(
						'version'        => '1.0',
						'exported_at'    => current_time( 'mysql' ),
						'exported_by'    => wp_get_current_user()->user_login,
						'site_url'       => get_site_url(),
						'plugin_version' => defined( 'WP_MCP_AI_VERSION' ) ? WP_MCP_AI_VERSION : 'unknown',
						'settings'       => $settings,
					),
					JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
				);
			}

			if ( is_wp_error( $json ) ) {
				wp_send_json_error( array( 'message' => $json->get_error_message() ) );
			}

			if ( false === $json ) {
				wp_send_json_error( array( 'message' => __( 'Failed to encode settings as JSON.', 'mcp-ai-wpoos' ) ) );
			}

			// Generate filename with timestamp.
			$filename = 'nv-oos-settings-' . gmdate( 'Y-m-d-H-i-s' ) . '.json';

			// Send as downloadable file.
			header( 'Content-Type: application/json' );
			header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
			header( 'Content-Length: ' . strlen( $json ) );
			header( 'Cache-Control: no-cache, no-store, must-revalidate' );
			header( 'Pragma: no-cache' );
			header( 'Expires: 0' );

			// Output JSON for file download. JSON is already safely encoded via wp_json_encode().
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON output for file download, already encoded with wp_json_encode().
			echo $json;

			// Under PHPUnit the AJAX harness captures the buffered output when
			// the handler returns; a bare exit would kill the process.
			if ( defined( 'WP_MCP_AI_TESTS_RUNNING' ) && WP_MCP_AI_TESTS_RUNNING ) {
				return;
			}

			exit;
		}

		/**
		 * Handle settings import AJAX request.
		 *
		 * Delegates to the Export Manager for provider-based import.
		 * Supports legacy v1 format (auto-wrapped as core_settings).
		 * Supports encrypted files via ?password=... POST field.
		 *
		 * @since 1.0.0
		 */
		public function handle_import_settings() {
			check_ajax_referer( 'wp-mcp-ai-dashboard', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mcp-ai-wpoos' ) ) );
			}

			// Check if file was uploaded.
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Checking existence only, not using the value.
			if ( ! isset( $_FILES['settings_file'] ) || ! isset( $_FILES['settings_file']['error'] ) || UPLOAD_ERR_OK !== $_FILES['settings_file']['error'] ) {
				wp_send_json_error( array( 'message' => __( 'No file uploaded or upload error occurred.', 'mcp-ai-wpoos' ) ) );
			}

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- File data validated below.
			$file = $_FILES['settings_file'];

			// Validate file size (max 5MB for settings file).
			$max_size = 5 * MB_IN_BYTES;
			if ( $file['size'] > $max_size ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
						/* translators: %s: Maximum file size */
							__( 'File too large. Maximum size: %s', 'mcp-ai-wpoos' ),
							size_format( $max_size )
						),
					)
				);
			}

			// Validate file type using WordPress function (more secure than client MIME type).
			$filetype = wp_check_filetype( sanitize_file_name( $file['name'] ), array( 'json' => 'application/json' ) );
			if ( 'json' !== $filetype['ext'] || 'application/json' !== $filetype['type'] ) {
				wp_send_json_error( array( 'message' => __( 'Invalid file type. Please upload a JSON file.', 'mcp-ai-wpoos' ) ) );
			}

			// Read file contents with size validation.
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading uploaded file for import.
			$json_content = file_get_contents( $file['tmp_name'] );

			if ( false === $json_content || empty( $json_content ) ) {
				wp_send_json_error( array( 'message' => __( 'Failed to read uploaded file or file is empty.', 'mcp-ai-wpoos' ) ) );
			}

			// Additional size check after reading to prevent memory issues.
			if ( strlen( $json_content ) > $max_size ) {
				wp_send_json_error( array( 'message' => __( 'File content too large.', 'mcp-ai-wpoos' ) ) );
			}

			// Optional password for encrypted import.
			$password = '';
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
			if ( ! empty( $_POST['password'] ) ) {
				$password = sanitize_text_field( wp_unslash( $_POST['password'] ) );
			}

			// Determine which providers to import (empty = all in file).
			$provider_ids = array();
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
			if ( ! empty( $_POST['providers'] ) ) {
				$provider_ids = explode( ',', sanitize_text_field( wp_unslash( $_POST['providers'] ) ) );
				$provider_ids = array_map( 'sanitize_key', $provider_ids );
			}

			// Delegate to Export Manager if available.
			if ( class_exists( 'WP_MCP_AI_Export_Manager' ) ) {
				$manager = WP_MCP_AI_Export_Manager::instance();
				$result  = $manager->import( $json_content, $provider_ids, $password );
			} else {
				// Fallback: legacy import (core settings only).
				$import_data = json_decode( $json_content, true );
				if ( null === $import_data || ! isset( $import_data['settings'] ) ) {
					wp_send_json_error( array( 'message' => __( 'Invalid settings file structure.', 'mcp-ai-wpoos' ) ) );
				}

				// Legacy backup + sanitize + save logic.
				$current_settings    = get_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, array() );
				$current_credentials = get_option( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, array() );
				update_option(
					'wp_mcp_ai_settings_backup_pre_import_' . time(),
					array_merge( $current_settings, is_array( $current_credentials ) ? $current_credentials : array() ),
					false
				);

				$sanitized_settings = $this->sanitize_settings( $import_data['settings'], '' );
				$validation_errors  = $this->validate_merged_settings( $sanitized_settings, $current_settings );

				if ( ! empty( $validation_errors ) ) {
					wp_send_json_error(
						array(
							'message' => __( 'Settings validation failed:', 'mcp-ai-wpoos' ),
							'errors'  => $validation_errors,
						)
					);
				}

				$import_credentials   = array();
				$import_non_sensitive = array();
				foreach ( $sanitized_settings as $key => $value ) {
					if ( WP_MCP_AI_Admin_Settings_Base::is_sensitive_setting_key( $key ) ) {
						$import_credentials[ $key ] = $value;
					} else {
						$import_non_sensitive[ $key ] = $value;
					}
				}

				$final_credentials   = array_merge( is_array( $current_credentials ) ? $current_credentials : array(), $import_credentials );
				$final_non_sensitive = array_merge( is_array( $current_settings ) ? $current_settings : array(), $import_non_sensitive );
				$update_result       = update_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, $final_non_sensitive, true );

				if ( count( $final_credentials ) > 0 ) {
					update_option( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, $final_credentials, false );
				}

				WP_MCP_AI_Admin_Settings::reset_settings_cache();
				wp_cache_delete( WP_MCP_AI_Admin_Settings::OPTION_NAME, 'options' );
				wp_cache_delete( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, 'options' );
				delete_transient( 'wp_mcp_ai_settings_cache' );

				wp_send_json_success(
					array(
						'message'        => __( 'Settings imported successfully!', 'mcp-ai-wpoos' ),
						'imported_count' => count( $sanitized_settings ),
					)
				);
				return;
			}

			if ( is_wp_error( $result ) ) {
				wp_send_json_error( array( 'message' => $result->get_error_message() ) );
			}

			$results       = isset( $result['results'] ) ? $result['results'] : array();
			$success_count = 0;
			$error_count   = 0;
			$messages      = array();

			foreach ( $results as $pid => $r ) {
				if ( ! empty( $r['success'] ) ) {
					++$success_count;
				} else {
					++$error_count;
					$messages[] = $r['message'];
				}
			}

			if ( $error_count > 0 && 0 === $success_count ) {
				wp_send_json_error(
					array(
						'message' => __( 'Import failed for all providers.', 'mcp-ai-wpoos' ),
						'errors'  => $messages,
					)
				);
			}

			$msg = sprintf(
				/* translators: 1: number of successful imports, 2: number of failed imports */
				_n(
					'%1$d provider imported successfully.',
					'%1$d providers imported successfully.',
					$success_count,
					'mcp-ai-wpoos'
				),
				$success_count
			);

			if ( $error_count > 0 ) {
				$msg .= ' ' . sprintf(
					/* translators: %d: number of failed imports */
					_n(
						'(%d provider had errors.)',
						'(%d providers had errors.)',
						$error_count,
						'mcp-ai-wpoos'
					),
					$error_count
				);
			}

			wp_send_json_success(
				array(
					'message' => $msg,
					'results' => $results,
				)
			);
		}

		/**
		 * Handle clear cache AJAX request.
		 *
		 * Clears all settings-related caches.
		 */
		public function handle_clear_cache() {
			check_ajax_referer( 'wp-mcp-ai-dashboard', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mcp-ai-wpoos' ) ) );
			}

			// Clear all settings caches.
			WP_MCP_AI_Admin_Settings::reset_settings_cache();
			wp_cache_delete( WP_MCP_AI_Admin_Settings::OPTION_NAME, 'options' );
			wp_cache_delete( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, 'options' );
			delete_transient( 'wp_mcp_ai_settings_cache' );

			// Clear any other related caches.
			if ( function_exists( 'wp_cache_flush' ) ) {
				wp_cache_flush();
			}

			wp_send_json_success(
				array(
					'message' => __( 'All settings caches cleared successfully!', 'mcp-ai-wpoos' ),
				)
			);
		}

		/**
		 * Handle reset settings AJAX request.
		 *
		 * Resets all settings to default values.
		 */
		public function handle_reset_settings() {
			check_ajax_referer( 'wp-mcp-ai-dashboard', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mcp-ai-wpoos' ) ) );
			}

			// Backup current settings before reset (include credentials).
			$current_settings    = get_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, array() );
			$current_credentials = get_option( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, array() );
			update_option(
				'wp_mcp_ai_settings_backup_pre_reset_' . time(),
				array_merge( $current_settings, is_array( $current_credentials ) ? $current_credentials : array() ),
				false
			);

			// Get default settings and split into sensitive/non-sensitive.
			$default_settings = WP_MCP_AI_Admin_Settings_Base::get_default_settings();

			$reset_credentials   = array();
			$reset_non_sensitive = array();
			foreach ( $default_settings as $key => $value ) {
				if ( WP_MCP_AI_Admin_Settings_Base::is_sensitive_setting_key( $key ) ) {
					$reset_credentials[ $key ] = $value;
				} else {
					$reset_non_sensitive[ $key ] = $value;
				}
			}

			// Save non-sensitive settings (autoload=true).
			$update_result = update_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, $reset_non_sensitive, true );

			// Save default credential values (autoload=false).
			// Default credential values are empty strings, but we still save them
			// so the option structure is consistent.
			if ( count( $reset_credentials ) > 0 ) {
				update_option( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, $reset_credentials, false );
			}

			if ( false === $update_result ) {
				wp_send_json_error( array( 'message' => __( 'Failed to reset settings.', 'mcp-ai-wpoos' ) ) );
			}

			// Clear all caches.
			WP_MCP_AI_Admin_Settings::reset_settings_cache();
			wp_cache_delete( WP_MCP_AI_Admin_Settings::OPTION_NAME, 'options' );
			wp_cache_delete( WP_MCP_AI_Admin_Settings_Base::CREDENTIALS_OPTION_NAME, 'options' );
			delete_transient( 'wp_mcp_ai_settings_cache' );

			wp_send_json_success(
				array(
					'message' => __( 'Settings reset to defaults successfully!', 'mcp-ai-wpoos' ),
				)
			);
		}

		/**
		 * Handle settings health check AJAX request.
		 *
		 * Checks settings integrity and reports any issues.
		 */
		public function handle_check_settings_health() {
			check_ajax_referer( 'wp-mcp-ai-dashboard', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mcp-ai-wpoos' ) ) );
			}

			// Clear cache and get fresh settings.
			WP_MCP_AI_Admin_Settings::reset_settings_cache();
			wp_cache_delete( WP_MCP_AI_Admin_Settings::OPTION_NAME, 'options' );
			$settings = get_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, array() );

			$issues   = array();
			$warnings = array();
			$info     = array();

			// Check 1: Settings exist.
			if ( empty( $settings ) ) {
				$issues[] = __( 'No settings found in database. Settings may need to be initialized.', 'mcp-ai-wpoos' );
			}

			// Check 2: Settings is an array.
			if ( ! is_array( $settings ) ) {
				$issues[] = __( 'Settings data is not an array. Data corruption detected.', 'mcp-ai-wpoos' );
			} else {
				/* translators: %d: number of settings fields */
				$info[] = sprintf( __( 'Total settings fields: %d', 'mcp-ai-wpoos' ), count( $settings ) );
			}

			// Check 3: Critical settings present.
			$critical_fields = array( 'default_provider', 'default_model' );
			foreach ( $critical_fields as $field ) {
				if ( ! isset( $settings[ $field ] ) || empty( $settings[ $field ] ) ) {
					/* translators: %s: field name */
					$warnings[] = sprintf( __( 'Critical field "%s" is missing or empty.', 'mcp-ai-wpoos' ), $field );
				}
			}

			// Check 4: Provider keys configured.
			$configured_providers = 0;
			if ( class_exists( 'WP_MCP_AI_Credential_Resolver' ) ) {
				$providers_to_check = array( 'openai', 'gemini', 'ollama' );
				foreach ( $providers_to_check as $provider ) {
					if ( WP_MCP_AI_Credential_Resolver::has_credentials( $provider ) ) {
						++$configured_providers;
					}
				}
			} else {
				$provider_keys = array( 'openai_api_key', 'gemini_api_key', 'ollama_endpoint_url' );
				foreach ( $provider_keys as $key ) {
					if ( ! empty( $settings[ $key ] ) ) {
						++$configured_providers;
					}
				}
			}
			if ( 0 === $configured_providers ) {
				$warnings[] = __( 'No AI providers configured. At least one provider is required.', 'mcp-ai-wpoos' );
			} else {
				/* translators: %d: number of configured providers */
				$info[] = sprintf( __( 'Configured providers: %d', 'mcp-ai-wpoos' ), $configured_providers );
			}

			// Check 5: Cache status.
			$cache_exists = false !== wp_cache_get( WP_MCP_AI_Admin_Settings::OPTION_NAME, 'options' );
			/* translators: %s: cache status (Active or Not cached) */
			$info[] = sprintf( __( 'Object cache status: %s', 'mcp-ai-wpoos' ), $cache_exists ? 'Active' : 'Not cached' );

			// Check 6: Backup count.
			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query against wp_options for plugin backup option names; result caching would return a stale list of available backups.
			$backup_count = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",
					'wp_mcp_ai_settings_backup_%'
				)
			);
			/* translators: %d: number of settings backups */
			$info[] = sprintf( __( 'Settings backups available: %d', 'mcp-ai-wpoos' ), (int) $backup_count );

			// Prepare response.
			$health_status = 'good';
			if ( ! empty( $issues ) ) {
				$health_status = 'critical';
			} elseif ( ! empty( $warnings ) ) {
				$health_status = 'warning';
			}

			wp_send_json_success(
				array(
					'status'   => $health_status,
					'issues'   => $issues,
					'warnings' => $warnings,
					'info'     => $info,
					'message'  => sprintf(
						/* translators: %s: health status (GOOD, WARNING, or CRITICAL) */
						__( 'Health check complete. Status: %s', 'mcp-ai-wpoos' ),
						strtoupper( $health_status )
					),
				)
			);
		}
	}
}
