<?php
/**
 * Token Performance Stats Widget Template
 *
 * Displays database optimization and caching performance metrics.
 *
 * @package WP_MCP_AI
 * @var array $data Widget data containing performance statistics.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Enqueue widget styles.
wp_enqueue_style(
	'wp-mcp-ai-token-performance-stats',
	plugin_dir_url( __DIR__ . '/../' ) . 'assets/css/admin/widgets/token-performance-stats.css',
	array(),
	WP_MCP_AI_VERSION
);

$stats    = isset( $data['stats'] ) ? $data['stats'] : array();
$analysis = isset( $data['analysis'] ) ? $data['analysis'] : array();
?>

<div class="wp-mcp-ai-widget-performance-stats">
	<h3><?php esc_html_e( 'Performance Optimization', 'nvdigital-open-operator-system-oos' ); ?></h3>

	<!-- Optimization Status -->
	<div class="wp-mcp-ai-status-section">
		<h4><?php esc_html_e( 'Database Optimizations', 'nvdigital-open-operator-system-oos' ); ?></h4>
		<div class="wp-mcp-ai-status-grid">
			<div class="wp-mcp-ai-status-item">
				<span class="wp-mcp-ai-status-label"><?php esc_html_e( 'Status:', 'nvdigital-open-operator-system-oos' ); ?></span>
				<?php if ( ! empty( $stats['optimizations_active'] ) ) : ?>
					<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-active">
						<span class="dashicons dashicons-yes-alt"></span>
						<?php esc_html_e( 'Active', 'nvdigital-open-operator-system-oos' ); ?>
					</span>
				<?php else : ?>
					<span class="wp-mcp-ai-status-badge wp-mcp-ai-status-inactive">
						<span class="dashicons dashicons-warning"></span>
						<?php esc_html_e( 'Inactive', 'nvdigital-open-operator-system-oos' ); ?>
					</span>
				<?php endif; ?>
			</div>

			<div class="wp-mcp-ai-status-item">
				<span class="wp-mcp-ai-status-label"><?php esc_html_e( 'Schema Version:', 'nvdigital-open-operator-system-oos' ); ?></span>
				<span class="wp-mcp-ai-status-value"><?php echo esc_html( $stats['schema_version'] ?? 0 ); ?></span>
			</div>

			<div class="wp-mcp-ai-status-item">
				<span class="wp-mcp-ai-status-label"><?php esc_html_e( 'Token Indexes:', 'nvdigital-open-operator-system-oos' ); ?></span>
				<span class="wp-mcp-ai-status-value"><?php echo esc_html( $stats['wp_mcp_ai_indexes'] ?? 0 ); ?></span>
			</div>
		</div>
	</div>

	<!-- Index Status -->
	<div class="wp-mcp-ai-index-section">
		<h4><?php esc_html_e( 'Index Status', 'nvdigital-open-operator-system-oos' ); ?></h4>
		<table class="wp-mcp-ai-stats-table">
			<tbody>
				<tr>
					<td><?php esc_html_e( 'Tier Index:', 'nvdigital-open-operator-system-oos' ); ?></td>
					<td>
						<?php if ( ! empty( $stats['tier_index_exists'] ) ) : ?>
							<span class="wp-mcp-ai-badge-success">
								<span class="dashicons dashicons-yes"></span>
								<?php esc_html_e( 'Exists', 'nvdigital-open-operator-system-oos' ); ?>
							</span>
						<?php else : ?>
							<span class="wp-mcp-ai-badge-warning">
								<span class="dashicons dashicons-no"></span>
								<?php esc_html_e( 'Missing', 'nvdigital-open-operator-system-oos' ); ?>
							</span>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Usage Index:', 'nvdigital-open-operator-system-oos' ); ?></td>
					<td>
						<?php if ( ! empty( $stats['usage_index_exists'] ) ) : ?>
							<span class="wp-mcp-ai-badge-success">
								<span class="dashicons dashicons-yes"></span>
								<?php esc_html_e( 'Exists', 'nvdigital-open-operator-system-oos' ); ?>
							</span>
						<?php else : ?>
							<span class="wp-mcp-ai-badge-warning">
								<span class="dashicons dashicons-no"></span>
								<?php esc_html_e( 'Missing', 'nvdigital-open-operator-system-oos' ); ?>
							</span>
						<?php endif; ?>
					</td>
				</tr>
			</tbody>
		</table>
	</div>

	<!-- Data Volume -->
	<div class="wp-mcp-ai-volume-section">
		<h4><?php esc_html_e( 'Data Volume', 'nvdigital-open-operator-system-oos' ); ?></h4>
		<table class="wp-mcp-ai-stats-table">
			<tbody>
				<tr>
					<td><?php esc_html_e( 'Tier Records:', 'nvdigital-open-operator-system-oos' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $stats['tier_records'] ?? 0 ) ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Usage Records:', 'nvdigital-open-operator-system-oos' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $stats['usage_records'] ?? 0 ) ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Total Indexes:', 'nvdigital-open-operator-system-oos' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $stats['total_indexes'] ?? 0 ) ); ?></strong></td>
				</tr>
			</tbody>
		</table>
	</div>

	<!-- Query Performance -->
	<?php if ( ! empty( $analysis['tier_lookup'] ) || ! empty( $analysis['usage_lookup'] ) ) : ?>
		<div class="wp-mcp-ai-performance-section">
			<h4><?php esc_html_e( 'Query Performance', 'nvdigital-open-operator-system-oos' ); ?></h4>
			<table class="wp-mcp-ai-stats-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Query Type', 'nvdigital-open-operator-system-oos' ); ?></th>
						<th><?php esc_html_e( 'Index Used', 'nvdigital-open-operator-system-oos' ); ?></th>
						<th><?php esc_html_e( 'Rows Scanned', 'nvdigital-open-operator-system-oos' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( ! empty( $analysis['tier_lookup'] ) ) : ?>
						<tr>
							<td><?php esc_html_e( 'Tier Lookup', 'nvdigital-open-operator-system-oos' ); ?></td>
							<td>
								<?php if ( ! empty( $analysis['tier_lookup']['using_index'] ) ) : ?>
									<span class="wp-mcp-ai-badge-success">
										<?php echo esc_html( $analysis['tier_lookup']['index_name'] ?? 'yes' ); ?>
									</span>
								<?php else : ?>
									<span class="wp-mcp-ai-badge-warning">
										<?php esc_html_e( 'No index', 'nvdigital-open-operator-system-oos' ); ?>
									</span>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( number_format_i18n( $analysis['tier_lookup']['rows'] ?? 0 ) ); ?></td>
						</tr>
					<?php endif; ?>

					<?php if ( ! empty( $analysis['usage_lookup'] ) ) : ?>
						<tr>
							<td><?php esc_html_e( 'Usage Lookup', 'nvdigital-open-operator-system-oos' ); ?></td>
							<td>
								<?php if ( ! empty( $analysis['usage_lookup']['using_index'] ) ) : ?>
									<span class="wp-mcp-ai-badge-success">
										<?php echo esc_html( $analysis['usage_lookup']['index_name'] ?? 'yes' ); ?>
									</span>
								<?php else : ?>
									<span class="wp-mcp-ai-badge-warning">
										<?php esc_html_e( 'No index', 'nvdigital-open-operator-system-oos' ); ?>
									</span>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( number_format_i18n( $analysis['usage_lookup']['rows'] ?? 0 ) ); ?></td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>

	<!-- Actions -->
	<div class="wp-mcp-ai-widget-actions">
		<?php if ( empty( $stats['optimizations_active'] ) ) : ?>
			<button type="button" id="wp-mcp-ai-run-optimization" class="button button-primary">
				<span class="dashicons dashicons-update"></span>
				<?php esc_html_e( 'Run Optimization', 'nvdigital-open-operator-system-oos' ); ?>
			</button>
		<?php else : ?>
			<button type="button" id="wp-mcp-ai-reanalyze-performance" class="button">
				<span class="dashicons dashicons-chart-line"></span>
				<?php esc_html_e( 'Re-analyze Performance', 'nvdigital-open-operator-system-oos' ); ?>
			</button>
		<?php endif; ?>
	</div>
</div>

