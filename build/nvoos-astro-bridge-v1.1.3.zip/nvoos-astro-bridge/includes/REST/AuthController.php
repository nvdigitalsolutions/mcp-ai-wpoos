<?php
/**
 * Auth REST controller — customer accounts for the NV commerce contract.
 *
 * Serves `/funiq/v1/auth/*` and (aliased) `/nvoos-commerce/v1/auth/*`
 * (Proposal 092 — bridge enhancement B4, owner decision Q5: accounts
 * included in v1).
 *
 * Accounts are WordPress users (subscriber role by default; filterable via
 * `funiq_bridge_customer_role`). Cookie auth flows through the storefront's
 * same-origin proxy, so no CORS configuration is needed and authenticated
 * reads work with the standard logged-in cookie.
 *
 * @package NvoosAstroBridge\REST
 */

namespace NvoosAstroBridge\REST;

use NvoosAstroBridge\Schema;
use NvoosAstroBridge\Sources\ProductSources;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Customer account surface: nonce, register, login, logout, me.
 */
class AuthController extends BaseController {

	/**
	 * Controller namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'funiq/v1';

	/**
	 * REST base path.
	 *
	 * @var string
	 */
	protected $rest_base = 'auth';

	/**
	 * The Woo SSO handoff controller (token minting, 108 Phase 3).
	 *
	 * @var WooLoginController
	 */
	private $woo_login;

	/**
	 * Wire the SSO controller.
	 */
	public function __construct() {
		$this->woo_login = new WooLoginController();
	}

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/nonce',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_nonce' ),
					'permission_callback' => '__return_true',
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/register',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'register_user' ),
					'permission_callback' => '__return_true',
					'args'                => array(
						'email'    => array(
							'required'          => true,
							'type'              => 'string',
							'format'            => 'email',
							'sanitize_callback' => 'sanitize_email',
						),
						'password' => array(
							'required' => true,
							'type'     => 'string',
						),
						'name'     => array(
							'required'          => false,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'nonce'    => array(
							'description'       => 'REST nonce from GET /auth/nonce (CSRF guard).',
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/login',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'login_user' ),
					'permission_callback' => '__return_true',
					'args'                => array(
						'email'    => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'password' => array(
							'required' => true,
							'type'     => 'string',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/logout',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'logout_user' ),
					'permission_callback' => '__return_true',
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/me',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_me' ),
					'permission_callback' => array( $this, 'get_me_permissions_check' ),
				),
			)
		);
	}

	/**
	 * GET /auth/nonce — REST nonce for CSRF-protected register (and future
	 * state-changing calls).
	 *
	 * The nonce must be minted for the restored session, not user 0: the
	 * admin bundle sends this nonce on every call, and wp_verify_nonce
	 * recomputes with the user the determine_current_user chain resolves on
	 * that request — a guest-minted nonce fails with rest_cookie_invalid_nonce
	 * (HTTP 403) the moment the session is restored (the 2026-10-30 403s on
	 * /manage).
	 *
	 * @return WP_REST_Response
	 */
	public function get_nonce() {
		AuthSupport::maybe_restore_user_from_logged_in_cookie();

		return rest_ensure_response(
			array(
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);
	}

	/**
	 * POST /auth/register — create a customer account and log it in.
	 *
	 * CSRF-guarded: requires a nonce obtained from GET /auth/nonce.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function register_user( $request ) {
		$nonce = (string) $request->get_param( 'nonce' );
		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new WP_Error(
				'nvoos_invalid_nonce',
				'Invalid nonce. Refresh the page and try again.',
				array( 'status' => 403 )
			);
		}

		$email    = (string) $request->get_param( 'email' );
		$password = (string) $request->get_param( 'password' );
		$name     = (string) $request->get_param( 'name' );

		if ( ! is_email( $email ) ) {
			return new WP_Error( 'nvoos_invalid_email', 'A valid email address is required.', array( 'status' => 400 ) );
		}
		if ( strlen( $password ) < 8 ) {
			return new WP_Error( 'nvoos_weak_password', 'Password must be at least 8 characters.', array( 'status' => 400 ) );
		}
		if ( email_exists( $email ) ) {
			return new WP_Error( 'nvoos_email_exists', 'An account with this email already exists.', array( 'status' => 409 ) );
		}

		$login = sanitize_user( current( explode( '@', $email ) ), true );
		if ( username_exists( $login ) ) {
			$login .= wp_rand( 1000, 9999 );
		}

		$role = apply_filters( 'funiq_bridge_customer_role', 'subscriber' );

		$user_id = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_email'   => $email,
				'user_pass'    => $password,
				'display_name' => '' !== $name ? $name : $login,
				'role'         => $role,
			)
		);

		if ( is_wp_error( $user_id ) ) {
			return new WP_Error(
				'nvoos_registration_failed',
				'Account creation failed: ' . $user_id->get_error_message(),
				array( 'status' => 400 )
			);
		}

		wp_set_auth_cookie( $user_id, true );

		return rest_ensure_response( $this->me_payload( $user_id ) );
	}

	/**
	 * POST /auth/login — authenticate with email + password.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function login_user( $request ) {
		$email    = (string) $request->get_param( 'email' );
		$password = (string) $request->get_param( 'password' );

		$user = wp_signon(
			array(
				'user_login'    => $email,
				'user_password' => $password,
				'remember'      => true,
			),
			is_ssl()
		);

		if ( is_wp_error( $user ) ) {
			// Generic message — never reveal which field failed.
			return new WP_Error( 'nvoos_invalid_credentials', 'Invalid email or password.', array( 'status' => 401 ) );
		}

		wp_set_current_user( $user->ID );

		$payload = $this->me_payload( $user->ID );

		// Woo SSO handoff (108 Phase 3): when the owner toggle is on, a login
		// also mints the single-use token that signs the shopper into the
		// hosted checkout across the registrable-domain boundary.
		if ( $this->woo_login->is_enabled() ) {
			$payload['wooLoginToken'] = $this->woo_login->mint_token( $user->ID );
		}

		return rest_ensure_response( $payload );
	}

	/**
	 * POST /auth/logout — clear the session cookie.
	 *
	 * @return WP_REST_Response
	 */
	public function logout_user() {
		wp_logout();

		return rest_ensure_response( array( 'ok' => true ) );
	}

	/**
	 * GET /auth/me — current customer (cookie-authenticated).
	 *
	 * Sessions that can manage the store additionally get the dashboard
	 * fields (canManage + adminUrl) so same-origin consumers can surface
	 * a "Manage store" entry point without hardcoding backend URLs.
	 *
	 * @return WP_REST_Response
	 */
	public function get_me() {
		return rest_ensure_response( $this->me_payload( get_current_user_id() ) );
	}

	/**
	 * Permission check for GET /auth/me.
	 *
	 * The REST pipeline force-logs-out cookie sessions before the callback
	 * runs on single-site HTTPS installs (see AuthSupport) — restore the
	 * session from the logged-in cookie here, then require it.
	 *
	 * @return bool
	 */
	public function get_me_permissions_check(): bool {
		return (bool) AuthSupport::maybe_restore_user_from_logged_in_cookie();
	}

	/**
	 * Build the customer payload for a user ID.
	 *
	 * The payload is camelCase like every other bridge envelope (product
	 * docs carry oldPrice/imageId). It also carries the session's WordPress
	 * capabilities and the server-computed read-only collection map, so the
	 * admin SPA can gate surfaces without probing endpoints (the console's
	 * capability/endpoint-emptiness pattern — see Proposal 083/084).
	 *
	 * @param int $user_id WordPress user ID.
	 * @return array<string, mixed>
	 */
	private function me_payload( int $user_id ): array {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return array(
				'id'                  => 0,
				'email'               => '',
				'name'                => '',
				'canManage'           => false,
				'adminUrl'            => '',
				'capabilities'        => array(),
				'readOnlyCollections' => array(),
			);
		}

		$can_manage = current_user_can( Schema::CAP_MANAGE );

		return array(
			'id'                  => $user->ID,
			'email'               => $user->user_email,
			'name'                => ( '' !== $user->display_name ) ? $user->display_name : $user->user_login,
			'canManage'           => $can_manage,
			'adminUrl'            => $can_manage ? admin_url( 'admin.php?page=' . Schema::ADMIN_PAGE_SLUG ) : '',
			'capabilities'        => $this->user_capabilities( $user ),
			'readOnlyCollections' => $this->read_only_collections(),
		);
	}

	/**
	 * The session's granted capability slugs (sorted, stable order).
	 *
	 * Mirrors the console's users/me?context=edit capabilities contract so
	 * the admin SPA can reuse the same capability-driven gating model.
	 *
	 * @param \WP_User $user WordPress user.
	 * @return array<int, string>
	 */
	private function user_capabilities( \WP_User $user ): array {
		$caps = array_filter( (array) $user->get_role_caps() );
		$caps = array_keys( $caps );
		sort( $caps );
		return array_values( $caps );
	}

	/**
	 * Collections that are read-only for the current backend mode.
	 *
	 * Woo-mode stock statuses are WooCommerce enumerations — every write
	 * answers 405 (see StatusesController). The admin SPA uses this map to
	 * hide Add/Edit/Delete instead of surfacing the rejection.
	 *
	 * @return array<int, string>
	 */
	private function read_only_collections(): array {
		$read_only = array();
		if ( ProductSources::is_woo_active_mode() ) {
			$read_only[] = 'statuses';
		}
		return $read_only;
	}
}
