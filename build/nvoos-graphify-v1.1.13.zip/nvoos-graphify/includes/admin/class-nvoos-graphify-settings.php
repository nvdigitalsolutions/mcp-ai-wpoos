<?php
/**
 * NV oOS Graphify — Admin Settings Page
 *
 * Registers the "Knowledge Graph" settings page under the NV oOS admin menu.
 * Provides three setting sections (General, Build, Display) plus a graph
 * overview stats card with a rebuild button and the Cytoscape.js graph explorer.
 *
 * @package NV_oOS_Graphify
 * @since   0.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin settings for the Graphify addon.
 *
 * @since 0.5.0
 */
class NV_oOS_Graphify_Settings {

	/**
	 * Settings page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'nvoos-graphify';

	/**
	 * Register admin hooks.
	 *
	 * @since 0.5.0
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_nvoos_graphify_build', array( __CLASS__, 'handle_ajax_build' ) );
	}

	/**
	 * Add the "Knowledge Graph" submenu under the NV oOS parent menu.
	 *
	 * Falls back to a top-level menu if the parent isn't registered.
	 *
	 * @since 0.5.0
	 *
	 * @return void
	 */
	public static function add_menu_page() {
		$parent = 'mcp-ai-wpoos'; // NV oOS parent slug.

		if ( ! menu_page_url( $parent, false ) ) {
			// Fallback to standalone page.
			add_menu_page(
				__( 'Knowledge Graph', 'nvoos-graphify' ),
				__( 'Knowledge Graph', 'nvoos-graphify' ),
				'manage_options',
				self::PAGE_SLUG,
				array( __CLASS__, 'render_page' ),
				'dashicons-networking',
				85
			);
			return;
		}

		add_submenu_page(
			$parent,
			__( 'Knowledge Graph', 'nvoos-graphify' ),
			__( 'Knowledge Graph', 'nvoos-graphify' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Register settings, sections, and fields.
	 *
	 * @since 0.5.0
	 *
	 * @return void
	 */
	public static function register_settings() {
		register_setting(
			'nvoos_graphify_settings_group',
			NV_oOS_Graphify::OPTION_KEY,
			array( 'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ) )
		);

		// --- General section ---
		add_settings_section( 'nvoos_graphify_general', __( 'General', 'nvoos-graphify' ), '__return_false', self::PAGE_SLUG );
		add_settings_field( 'enabled', __( 'Enable Graphify', 'nvoos-graphify' ), array( __CLASS__, 'field_enabled' ), self::PAGE_SLUG, 'nvoos_graphify_general' );

		// --- Build section ---
		add_settings_section( 'nvoos_graphify_build', __( 'Build Settings', 'nvoos-graphify' ), '__return_false', self::PAGE_SLUG );
		add_settings_field( 'semantic_extraction', __( 'Semantic Extraction', 'nvoos-graphify' ), array( __CLASS__, 'field_semantic' ), self::PAGE_SLUG, 'nvoos_graphify_build' );
		add_settings_field( 'incremental_builds', __( 'Incremental Builds', 'nvoos-graphify' ), array( __CLASS__, 'field_incremental' ), self::PAGE_SLUG, 'nvoos_graphify_build' );
		add_settings_field( 'auto_rebuild', __( 'Auto-Rebuild on Save', 'nvoos-graphify' ), array( __CLASS__, 'field_auto_rebuild' ), self::PAGE_SLUG, 'nvoos_graphify_build' );
		add_settings_field( 'rebuild_schedule', __( 'Scheduled Rebuild', 'nvoos-graphify' ), array( __CLASS__, 'field_rebuild_schedule' ), self::PAGE_SLUG, 'nvoos_graphify_build' );
		add_settings_field( 'openai_api_key', __( 'OpenAI API Key (optional)', 'nvoos-graphify' ), array( __CLASS__, 'field_openai_key' ), self::PAGE_SLUG, 'nvoos_graphify_build' );

		// --- Remote sources section ---
		add_settings_section( 'nvoos_graphify_remote', __( 'Remote Enrichment', 'nvoos-graphify' ), '__return_false', self::PAGE_SLUG );
		add_settings_field( 'remote_enrich_enabled', __( 'Enable Remote Enrichment', 'nvoos-graphify' ), array( __CLASS__, 'field_remote_enrich_enabled' ), self::PAGE_SLUG, 'nvoos_graphify_remote' );
		add_settings_field( 'remote_enrich_budget', __( 'Enrichment Budget (nodes/run)', 'nvoos-graphify' ), array( __CLASS__, 'field_remote_enrich_budget' ), self::PAGE_SLUG, 'nvoos_graphify_remote' );
		add_settings_field( 'remote_enrich_async', __( 'Async Enrichment', 'nvoos-graphify' ), array( __CLASS__, 'field_remote_enrich_async' ), self::PAGE_SLUG, 'nvoos_graphify_remote' );

		// --- Embeddings section ---
		add_settings_section( 'nvoos_graphify_embeddings', __( 'Embeddings', 'nvoos-graphify' ), '__return_false', self::PAGE_SLUG );
		add_settings_field( 'embeddings_enabled', __( 'Enable Embeddings', 'nvoos-graphify' ), array( __CLASS__, 'field_embeddings_enabled' ), self::PAGE_SLUG, 'nvoos_graphify_embeddings' );
		add_settings_field( 'embeddings_model', __( 'Embeddings Model', 'nvoos-graphify' ), array( __CLASS__, 'field_embeddings_model' ), self::PAGE_SLUG, 'nvoos_graphify_embeddings' );

		// --- Display section ---
		add_settings_section( 'nvoos_graphify_display', __( 'Display', 'nvoos-graphify' ), '__return_false', self::PAGE_SLUG );
		add_settings_field( 'schema_injection', __( 'Schema.org Injection', 'nvoos-graphify' ), array( __CLASS__, 'field_schema' ), self::PAGE_SLUG, 'nvoos_graphify_display' );
		add_settings_field( 'related_content', __( 'Related Content Widget', 'nvoos-graphify' ), array( __CLASS__, 'field_related' ), self::PAGE_SLUG, 'nvoos_graphify_display' );
		add_settings_field( 'cytoscape_height', __( 'Graph Explorer Height', 'nvoos-graphify' ), array( __CLASS__, 'field_height' ), self::PAGE_SLUG, 'nvoos_graphify_display' );
		add_settings_field( 'max_display_nodes', __( 'Max Explorer Nodes', 'nvoos-graphify' ), array( __CLASS__, 'field_max_nodes' ), self::PAGE_SLUG, 'nvoos_graphify_display' );
	}

	/**
	 * Map of tab slug => list of setting keys rendered on that tab's form.
	 *
	 * Used by {@see sanitize_settings()} to decide which keys may be
	 * overwritten by a submission, so that saving one tab does not wipe
	 * values controlled by the other tabs.
	 *
	 * @since 0.7.10
	 *
	 * @return array<string,string[]>
	 */
	private static function get_tab_field_map() {
		return array(
			// "General" tab renders general + build + display sections.
			'general'    => array(
				'enabled',
				'semantic_extraction',
				'incremental_builds',
				'auto_rebuild',
				'rebuild_schedule',
				'openai_api_key',
				'schema_injection',
				'related_content',
				'cytoscape_height',
				'max_display_nodes',
				'max_related',
			),
			'remote'     => array(
				'remote_enrich_enabled',
				'remote_enrich_budget',
				'remote_enrich_async',
			),
			'embeddings' => array(
				'embeddings_enabled',
				'embeddings_model',
			),
		);
	}

	/**
	 * Sanitize a single setting key from the raw submission.
	 *
	 * Centralised so that {@see sanitize_settings()} can apply per-key
	 * sanitisation only to the keys belonging to the submitted tab, while
	 * preserving values from other tabs untouched.
	 *
	 * @since 0.7.10
	 *
	 * @param string $key Setting key.
	 * @param array  $raw Raw submitted settings array.
	 * @return mixed Sanitized value.
	 */
	private static function sanitize_field( $key, array $raw ) {
		switch ( $key ) {
			case 'enabled':
			case 'semantic_extraction':
			case 'incremental_builds':
			case 'auto_rebuild':
			case 'schema_injection':
			case 'related_content':
			case 'remote_enrich_enabled':
			case 'remote_enrich_async':
			case 'embeddings_enabled':
				return ! empty( $raw[ $key ] ) ? 1 : 0;

			case 'rebuild_schedule':
				$allowed = array( 'hourly', 'twicedaily', 'daily', 'weekly' );
				$value   = isset( $raw[ $key ] ) ? $raw[ $key ] : 'daily';
				return in_array( $value, $allowed, true ) ? $value : 'daily';

			case 'openai_api_key':
				return sanitize_text_field( isset( $raw[ $key ] ) ? $raw[ $key ] : '' );

			case 'cytoscape_height':
				return sanitize_text_field( isset( $raw[ $key ] ) ? $raw[ $key ] : '600px' );

			case 'max_display_nodes':
				return max( 50, min( 2000, absint( isset( $raw[ $key ] ) ? $raw[ $key ] : 300 ) ) );

			case 'max_related':
				return max( 1, min( 10, absint( isset( $raw[ $key ] ) ? $raw[ $key ] : 5 ) ) );

			case 'remote_enrich_budget':
				return max( 1, min( 500, absint( isset( $raw[ $key ] ) ? $raw[ $key ] : 50 ) ) );

			case 'embeddings_model':
				$allowed = array( 'text-embedding-3-small', 'text-embedding-3-large', 'text-embedding-ada-002' );
				$value   = isset( $raw[ $key ] ) ? $raw[ $key ] : '';
				return in_array( $value, $allowed, true ) ? $value : 'text-embedding-3-small';
		}

		// Defensive default: any key not explicitly handled above is not part
		// of the tab field map (see {@see get_tab_field_map()}) and should not
		// be written. Returning null lets {@see sanitize_settings()} skip it.
		return null;
	}

	/**
	 * Detect the tab being saved from the WP referer (`_wp_http_referer`).
	 *
	 * The settings page renders one form per tab, so the referer tells us
	 * which tab's fields were actually present in the submission.
	 *
	 * @since 0.7.10
	 *
	 * @return string One of: 'general', 'remote', 'embeddings'.
	 */
	private static function detect_submitted_tab() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Tab detection only; the option update itself is nonce-protected by options.php.
		$referer = isset( $_REQUEST['_wp_http_referer'] ) ? esc_url_raw( wp_unslash( $_REQUEST['_wp_http_referer'] ) ) : '';
		if ( ! is_string( $referer ) || '' === $referer ) {
			return 'general';
		}

		$query = wp_parse_url( $referer, PHP_URL_QUERY );
		if ( ! is_string( $query ) || '' === $query ) {
			return 'general';
		}

		$args = array();
		wp_parse_str( $query, $args );
		$tab = isset( $args['tab'] ) ? sanitize_key( $args['tab'] ) : 'general';

		$map = self::get_tab_field_map();
		return isset( $map[ $tab ] ) ? $tab : 'general';
	}

	/**
	 * Sanitize incoming settings array.
	 *
	 * The settings page splits fields across three tabs that each submit
	 * their own form to `options.php`. We must merge the submitted tab's
	 * fields into the existing stored option instead of rebuilding the
	 * whole array — otherwise saving one tab silently zeros out every
	 * checkbox controlled by the other tabs.
	 *
	 * @since 0.5.0
	 *
	 * @param array $raw Submitted form data.
	 * @return array Sanitized settings merged with previously-stored values.
	 */
	public static function sanitize_settings( $raw ) {
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		// Start from the currently-stored option (with defaults filled in)
		// so any field not part of the submitted tab keeps its value.
		$existing = NV_oOS_Graphify::get_settings();

		$tab    = self::detect_submitted_tab();
		$map    = self::get_tab_field_map();
		$keys   = isset( $map[ $tab ] ) ? $map[ $tab ] : $map['general'];
		$merged = $existing;

		foreach ( $keys as $key ) {
			$value = self::sanitize_field( $key, $raw );
			if ( null === $value ) {
				continue;
			}
			$merged[ $key ] = $value;
		}

		return $merged;
	}

	// -------------------------------------------------------------------------
	// Field renderers
	// -------------------------------------------------------------------------

	/** Render the enabled checkbox. */
	public static function field_enabled() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="checkbox" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[enabled]" value="1" ' . checked( 1, $s['enabled'], false ) . '>';
		echo '<p class="description">' . esc_html__( 'Enable the Knowledge Graph addon.', 'nvoos-graphify' ) . '</p>';
	}

	/** Render semantic extraction field. */
	public static function field_semantic() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="checkbox" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[semantic_extraction]" value="1" ' . checked( 1, $s['semantic_extraction'], false ) . '>';
		echo '<p class="description">' . esc_html__( 'Use AI to extract named entities and topics from content.', 'nvoos-graphify' ) . '</p>';
	}

	/** Render incremental builds field. */
	public static function field_incremental() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="checkbox" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[incremental_builds]" value="1" ' . checked( 1, $s['incremental_builds'], false ) . '>';
		echo '<p class="description">' . esc_html__( 'Only process content modified since last build.', 'nvoos-graphify' ) . '</p>';
	}

	/** Render auto-rebuild field. */
	public static function field_auto_rebuild() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="checkbox" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[auto_rebuild]" value="1" ' . checked( 1, $s['auto_rebuild'], false ) . '>';
		echo '<p class="description">' . esc_html__( 'Trigger an incremental rebuild whenever a post is published or updated.', 'nvoos-graphify' ) . '</p>';
	}

	/** Render rebuild schedule field. */
	public static function field_rebuild_schedule() {
		$s       = NV_oOS_Graphify::get_settings();
		$options = array(
			'hourly'     => __( 'Hourly', 'nvoos-graphify' ),
			'twicedaily' => __( 'Twice Daily', 'nvoos-graphify' ),
			'daily'      => __( 'Daily', 'nvoos-graphify' ),
			'weekly'     => __( 'Weekly', 'nvoos-graphify' ),
		);
		echo '<select name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[rebuild_schedule]">';
		foreach ( $options as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '" ' . selected( $s['rebuild_schedule'], $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
	}

	/** Render OpenAI key field. */
	public static function field_openai_key() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="password" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[openai_api_key]" value="' . esc_attr( $s['openai_api_key'] ) . '" class="regular-text" autocomplete="new-password">';
		echo '<p class="description">' . esc_html__( 'Used as fallback when the oOS AI provider is not available. Leave blank to use the global oOS key.', 'nvoos-graphify' ) . '</p>';
	}

	/** Render schema injection field. */
	public static function field_schema() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="checkbox" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[schema_injection]" value="1" ' . checked( 1, $s['schema_injection'], false ) . '>';
		echo '<p class="description">' . esc_html__( 'Inject Schema.org JSON-LD (about, relatedLink) on singular views.', 'nvoos-graphify' ) . '</p>';
	}

	/** Render related content field. */
	public static function field_related() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="checkbox" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[related_content]" value="1" ' . checked( 1, $s['related_content'], false ) . '>';
		echo '<p class="description">' . esc_html__( 'Append a "Related Content" list from graph neighbors below singular post content.', 'nvoos-graphify' ) . '</p>';
	}

	/** Render explorer height field. */
	public static function field_height() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="text" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[cytoscape_height]" value="' . esc_attr( $s['cytoscape_height'] ) . '" class="small-text">';
		echo '<p class="description">' . esc_html__( 'CSS height for the graph explorer (e.g. 600px, 80vh).', 'nvoos-graphify' ) . '</p>';
	}

	/** Render max display nodes field. */
	public static function field_max_nodes() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="number" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[max_display_nodes]" value="' . absint( $s['max_display_nodes'] ) . '" min="50" max="2000" class="small-text">';
		echo '<p class="description">' . esc_html__( 'Maximum nodes to render in the graph explorer. Lower values improve browser performance.', 'nvoos-graphify' ) . '</p>';
	}

	/**
	 * Field: Enable remote enrichment.
	 *
	 * @since 0.6.0
	 *
	 * @return void
	 */
	public static function field_remote_enrich_enabled() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<label><input type="checkbox" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[remote_enrich_enabled]" value="1"' . checked( 1, $s['remote_enrich_enabled'], false ) . '> ';
		echo esc_html__( 'Enrich graph nodes from configured remote sources during each build.', 'nvoos-graphify' ) . '</label>';
	}

	/**
	 * Field: Remote enrichment node budget per run.
	 *
	 * @since 0.6.0
	 *
	 * @return void
	 */
	public static function field_remote_enrich_budget() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<input type="number" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[remote_enrich_budget]" value="' . absint( $s['remote_enrich_budget'] ) . '" min="1" max="500" class="small-text">';
		echo '<p class="description">' . esc_html__( 'Maximum nodes to enrich per build run (1–500). Prevents long-running builds.', 'nvoos-graphify' ) . '</p>';
	}

	/**
	 * Field: Async remote enrichment.
	 *
	 * @since 0.6.0
	 *
	 * @return void
	 */
	public static function field_remote_enrich_async() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<label><input type="checkbox" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[remote_enrich_async]" value="1"' . checked( 1, $s['remote_enrich_async'], false ) . '> ';
		echo esc_html__( 'Run enrichment in the background via WP-Cron (recommended for large sites).', 'nvoos-graphify' ) . '</label>';
	}

	/**
	 * Field: Enable embeddings.
	 *
	 * @since 0.6.0
	 *
	 * @return void
	 */
	public static function field_embeddings_enabled() {
		$s = NV_oOS_Graphify::get_settings();
		echo '<label><input type="checkbox" name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[embeddings_enabled]" value="1"' . checked( 1, $s['embeddings_enabled'], false ) . '> ';
		echo esc_html__( 'Generate and store vector embeddings for nodes (requires OpenAI API key).', 'nvoos-graphify' ) . '</label>';
	}

	/**
	 * Field: Embeddings model selector.
	 *
	 * @since 0.6.0
	 *
	 * @return void
	 */
	public static function field_embeddings_model() {
		$s       = NV_oOS_Graphify::get_settings();
		$current = isset( $s['embeddings_model'] ) ? $s['embeddings_model'] : 'text-embedding-3-small';
		$models  = array(
			'text-embedding-3-small' => __( 'text-embedding-3-small (recommended)', 'nvoos-graphify' ),
			'text-embedding-3-large' => __( 'text-embedding-3-large (higher quality, slower)', 'nvoos-graphify' ),
			'text-embedding-ada-002' => __( 'text-embedding-ada-002 (legacy)', 'nvoos-graphify' ),
		);
		echo '<select name="' . esc_attr( NV_oOS_Graphify::OPTION_KEY ) . '[embeddings_model]">';
		foreach ( $models as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $current, $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__( 'OpenAI embedding model used when generating node vectors.', 'nvoos-graphify' ) . '</p>';
	}

	// -------------------------------------------------------------------------
	// Asset enqueuing
	// -------------------------------------------------------------------------

	/**
	 * Enqueue admin assets on the Graphify settings page.
	 *
	 * @since 0.5.0
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( false === strpos( $hook, self::PAGE_SLUG ) ) {
			return;
		}

		// Cytoscape.js + fcose layout (bundled locally — see assets/vendor/).
		// Load order matters: layout-base → cose-base → cytoscape → cytoscape-fcose
		// (fcose auto-registers itself on the global cytoscape when it evaluates).
		wp_enqueue_script(
			'layout-base',
			NVOOS_GRAPHIFY_URL . 'assets/vendor/layout-base/layout-base.js',
			array(),
			'2.0.1',
			true
		);
		wp_enqueue_script(
			'cose-base',
			NVOOS_GRAPHIFY_URL . 'assets/vendor/cose-base/cose-base.js',
			array( 'layout-base' ),
			'2.2.0',
			true
		);
		wp_enqueue_script(
			'cytoscape',
			NVOOS_GRAPHIFY_URL . 'assets/vendor/cytoscape/cytoscape.min.js',
			array(),
			'3.28.1',
			true
		);
		wp_enqueue_script(
			'cytoscape-fcose',
			NVOOS_GRAPHIFY_URL . 'assets/vendor/cytoscape-fcose/cytoscape-fcose.js',
			array( 'cytoscape', 'cose-base' ),
			'2.2.0',
			true
		);

		wp_enqueue_script(
			'nvoos-graphify-admin',
			NVOOS_GRAPHIFY_URL . 'assets/js/graphify-admin.js',
			array( 'jquery', 'cytoscape', 'cytoscape-fcose' ),
			NVOOS_GRAPHIFY_VERSION,
			true
		);

		wp_enqueue_style(
			'nvoos-graphify-admin',
			NVOOS_GRAPHIFY_URL . 'assets/css/graphify-admin.css',
			array(),
			NVOOS_GRAPHIFY_VERSION
		);

		$settings = NV_oOS_Graphify::get_settings();

		wp_localize_script(
			'nvoos-graphify-admin',
			'nvoosGraphifyAdmin',
			array(
				'rest_url'    => esc_url_raw( rest_url( 'nvoos-graphify/v1' ) ),
				'nonce'       => wp_create_nonce( 'wp_rest' ),
				'ajax_url'    => admin_url( 'admin-ajax.php' ),
				'ajax_nonce'  => wp_create_nonce( 'nvoos_graphify_admin' ),
				'height'      => esc_js( $settings['cytoscape_height'] ),
				'max_nodes'   => absint( $settings['max_display_nodes'] ),
				'type_labels' => self::get_type_labels(),
				'i18n'        => array(
					'all_types' => __( 'All types', 'nvoos-graphify' ),
				),
			)
		);
	}

	/**
	 * Build a slug => label map for every node type that may appear in the
	 * graph. Includes the built-in semantic node types (term, topic, entity,
	 * memory, agent, wing, room) plus every public custom post type / CCT
	 * registered on the site, so the Graph Explorer's type filter can present
	 * a friendly label for each.
	 *
	 * @since 0.7.0
	 *
	 * @return array<string,string>
	 */
	private static function get_type_labels() {
		$labels = array(
			'term'   => __( 'Terms', 'nvoos-graphify' ),
			'topic'  => __( 'Topics', 'nvoos-graphify' ),
			'entity' => __( 'Entities', 'nvoos-graphify' ),
			'memory' => __( 'Memories', 'nvoos-graphify' ),
			'agent'  => __( 'Agents', 'nvoos-graphify' ),
			'wing'   => __( 'Wings', 'nvoos-graphify' ),
			'room'   => __( 'Rooms', 'nvoos-graphify' ),
		);

		// Include every public post type (built-in and custom) so CPTs and
		// JetEngine-registered content types show up in the filter when
		// nodes for them exist in the graph.
		$post_type_objects = get_post_types( array( 'public' => true ), 'objects' );
		foreach ( $post_type_objects as $slug => $object ) {
			if ( 'attachment' === $slug ) {
				continue;
			}
			$plural = isset( $object->labels->name ) && '' !== $object->labels->name
				? $object->labels->name
				: $object->label;
			if ( '' === $plural ) {
				$plural = ucwords( str_replace( array( '_', '-' ), ' ', $slug ) );
			}
			$labels[ $slug ] = $plural;
		}

		return $labels;
	}

	// -------------------------------------------------------------------------
	// Page render
	// -------------------------------------------------------------------------

	/**
	 * Render the settings page.
	 *
	 * @since 0.5.0
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'nvoos-graphify' ) );
		}

		$stats      = NV_oOS_Graphify_DB::get_stats();
		$last_build = NV_oOS_Graphify_DB::get_meta( 'last_build_completed', __( 'Never', 'nvoos-graphify' ) );
		$status     = NV_oOS_Graphify_DB::get_meta( 'build_status', 'idle' );
		$settings   = NV_oOS_Graphify::get_settings();

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$current_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'general';
		$tabs        = array(
			'general'    => __( 'General', 'nvoos-graphify' ),
			'remote'     => __( 'Remote Sources', 'nvoos-graphify' ),
			'embeddings' => __( 'Embeddings', 'nvoos-graphify' ),
		);
		?>
		<div class="wrap nvoos-graphify-admin">
			<h1><?php esc_html_e( 'Knowledge Graph', 'nvoos-graphify' ); ?></h1>

			<?php settings_errors(); ?>

			<?php /* Graph overview card */ ?>
			<div class="nvoos-graphify-stats-card">
				<h2><?php esc_html_e( 'Graph Overview', 'nvoos-graphify' ); ?></h2>
				<div class="nvoos-graphify-stats-grid">
					<div class="nvoos-graphify-stat">
						<span class="nvoos-graphify-stat-value"><?php echo esc_html( number_format_i18n( $stats['node_count'] ) ); ?></span>
						<span class="nvoos-graphify-stat-label"><?php esc_html_e( 'Nodes', 'nvoos-graphify' ); ?></span>
					</div>
					<div class="nvoos-graphify-stat">
						<span class="nvoos-graphify-stat-value"><?php echo esc_html( number_format_i18n( $stats['edge_count'] ) ); ?></span>
						<span class="nvoos-graphify-stat-label"><?php esc_html_e( 'Edges', 'nvoos-graphify' ); ?></span>
					</div>
					<div class="nvoos-graphify-stat">
						<span class="nvoos-graphify-stat-value"><?php echo esc_html( number_format_i18n( $stats['community_count'] ) ); ?></span>
						<span class="nvoos-graphify-stat-label"><?php esc_html_e( 'Communities', 'nvoos-graphify' ); ?></span>
					</div>
				</div>
				<p class="nvoos-graphify-last-build">
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: build status, 2: last build time */
							__( 'Status: %1$s — Last build: %2$s', 'nvoos-graphify' ),
							$status,
							$last_build
						)
					);
					?>
				</p>
				<button id="nvoos-graphify-build-btn" class="button button-primary">
					<?php esc_html_e( 'Rebuild Graph', 'nvoos-graphify' ); ?>
				</button>
				<span id="nvoos-graphify-build-status" style="margin-left:12px; display:none;"></span>
			</div>

			<?php /* Graph explorer */ ?>
			<?php if ( $stats['node_count'] > 0 ) : ?>
			<div class="nvoos-graphify-explorer-wrap">
				<h2><?php esc_html_e( 'Graph Explorer', 'nvoos-graphify' ); ?></h2>
				<div class="nvoos-graphify-explorer-toolbar">
					<input type="text" id="nvoos-graphify-search" placeholder="<?php esc_attr_e( 'Search nodes…', 'nvoos-graphify' ); ?>">
					<select id="nvoos-graphify-type-filter">
						<option value=""><?php esc_html_e( 'All types', 'nvoos-graphify' ); ?></option>
					</select>
					<input type="text" id="nvoos-graphify-agent-filter" placeholder="<?php esc_attr_e( 'Agent ID…', 'nvoos-graphify' ); ?>" style="width:140px;">
					<input type="text" id="nvoos-graphify-wing-filter" placeholder="<?php esc_attr_e( 'Wing…', 'nvoos-graphify' ); ?>" style="width:120px;">
					<button id="nvoos-graphify-memory-preset-btn" class="button" title="<?php esc_attr_e( 'Show only the agent / wing combination above', 'nvoos-graphify' ); ?>">
						<?php esc_html_e( 'Apply', 'nvoos-graphify' ); ?>
					</button>
					<button id="nvoos-graphify-memory-clear-btn" class="button">
						<?php esc_html_e( 'Clear', 'nvoos-graphify' ); ?>
					</button>
					<button id="nvoos-graphify-fit-btn" class="button"><?php esc_html_e( 'Fit', 'nvoos-graphify' ); ?></button>
					<button id="nvoos-graphify-relayout-btn" class="button"><?php esc_html_e( 'Relayout', 'nvoos-graphify' ); ?></button>
					<button id="nvoos-graphify-export-png-btn" class="button"><?php esc_html_e( 'Export PNG', 'nvoos-graphify' ); ?></button>
				</div>
				<div id="nvoos-graphify-explorer" style="height:<?php echo esc_attr( $settings['cytoscape_height'] ); ?>;"></div>
				<div id="nvoos-graphify-sidebar" class="nvoos-graphify-sidebar" style="display:none;"></div>
			</div>
			<?php endif; ?>

			<?php /* Tabbed settings */ ?>
			<h2 class="nav-tab-wrapper">
				<?php foreach ( $tabs as $tab_key => $tab_label ) : ?>
					<a href="<?php echo esc_url( add_query_arg( 'tab', $tab_key ) ); ?>"
						class="nav-tab<?php echo ( $current_tab === $tab_key ) ? ' nav-tab-active' : ''; ?>">
						<?php echo esc_html( $tab_label ); ?>
					</a>
				<?php endforeach; ?>
			</h2>

			<?php if ( 'remote' === $current_tab ) : ?>
				<?php NV_oOS_Graphify_Remote_Admin::render_tab(); ?>
				<form method="post" action="options.php" style="margin-top:20px;">
					<?php
					settings_fields( 'nvoos_graphify_settings_group' );
					self::do_settings_sections_filtered( self::PAGE_SLUG, array( 'nvoos_graphify_remote' ) );
					submit_button( __( 'Save Remote Settings', 'nvoos-graphify' ) );
					?>
				</form>
			<?php elseif ( 'embeddings' === $current_tab ) : ?>
				<?php NV_oOS_Graphify_Remote_Admin::render_embeddings_panel(); ?>
				<form method="post" action="options.php" style="margin-top:20px;">
					<?php
					settings_fields( 'nvoos_graphify_settings_group' );
					self::do_settings_sections_filtered( self::PAGE_SLUG, array( 'nvoos_graphify_embeddings' ) );
					submit_button( __( 'Save Embeddings Settings', 'nvoos-graphify' ) );
					?>
				</form>
			<?php else : ?>
				<form method="post" action="options.php">
					<?php
					settings_fields( 'nvoos_graphify_settings_group' );
					self::do_settings_sections_filtered(
						self::PAGE_SLUG,
						array( 'nvoos_graphify_general', 'nvoos_graphify_build', 'nvoos_graphify_display' )
					);
					submit_button();
					?>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Output settings sections for a specific subset of section IDs.
	 *
	 * WordPress's `do_settings_sections()` prints ALL sections for a page slug.
	 * This wrapper lets us selectively print only the sections relevant to a tab.
	 *
	 * @since 0.6.0
	 *
	 * @global array $wp_settings_sections Registered settings sections.
	 * @global array $wp_settings_fields   Registered settings fields.
	 *
	 * @param string   $page     Settings page slug.
	 * @param string[] $sections Section IDs to render.
	 * @return void
	 */
	private static function do_settings_sections_filtered( $page, array $sections ) {
		global $wp_settings_sections, $wp_settings_fields;

		if ( ! isset( $wp_settings_sections[ $page ] ) ) {
			return;
		}

		foreach ( (array) $wp_settings_sections[ $page ] as $section ) {
			if ( ! in_array( $section['id'], $sections, true ) ) {
				continue;
			}
			if ( $section['title'] ) {
				echo '<h2>' . esc_html( $section['title'] ) . '</h2>';
			}
			if ( $section['callback'] ) {
				call_user_func( $section['callback'], $section );
			}
			if ( ! isset( $wp_settings_fields[ $page ][ $section['id'] ] ) ) {
				continue;
			}
			echo '<table class="form-table" role="presentation"><tbody>';
			do_settings_fields( $page, $section['id'] );
			echo '</tbody></table>';
		}
	}

	// -------------------------------------------------------------------------
	// AJAX: trigger build from settings page
	// -------------------------------------------------------------------------

	/**
	 * Handle AJAX request to trigger a graph build.
	 *
	 * @since 0.5.0
	 *
	 * @return void
	 */
	public static function handle_ajax_build() {
		check_ajax_referer( 'nvoos_graphify_admin', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'nvoos-graphify' ) ), 403 );
		}

		$incremental = ! empty( $_POST['incremental'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already checked above.

		$result = NV_oOS_Graphify_Builder::build(
			array(
				'incremental'    => $incremental,
				'semantic'       => true,
				'async_semantic' => true,
			)
		);

		wp_send_json_success( $result );
	}
}
