<?php
/**
 * Tool that creates or updates WordPress posts (Validated version).
 *
 * This is the Symfony Validator version of the save_post tool.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../validators/class-wp-mcp-ai-validated-tool.php';
require_once __DIR__ . '/../validators/arguments/class-save-post-arguments.php';
require_once __DIR__ . '/trait-wp-mcp-ai-tool-markdown-converter.php';

/**
 * Creates a new post or updates an existing one using Symfony Validator.
 */
class WP_MCP_AI_Tool_Save_Post_Validated extends WP_MCP_AI_Validated_Tool implements WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface, WP_MCP_AI_Tool_Data_Contract_Interface {
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Tool_Markdown_Converter;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'save_post_validated';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Create or Update Post (Validated)', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Creates a new post or updates an existing one with the supplied content. Uses Symfony Validator for argument validation.', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Use to create a new post or update an existing one with Symfony Validator argument checks.', 'mcp-ai-wpoos' ),
			'when_not_to_use' => __( 'Use create_post for strict creation without updates; use get_post for read-only retrieval.', 'mcp-ai-wpoos' ),
			'related_tools'   => array( 'create_post', 'get_post', 'update_term' ),
			'notes'           => __( 'Defaults to draft status. Pass post_id to update an existing post; leave it empty to create one.', 'mcp-ai-wpoos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'post_id'   => array(
					'type'        => 'integer',
					'description' => __( 'Existing post ID to update. Leave empty to create a new post.', 'mcp-ai-wpoos' ),
					'minimum'     => 1,
				),
				'post_type' => array(
					'type'        => 'string',
					'description' => __( 'The post type to create or update.', 'mcp-ai-wpoos' ),
					'default'     => 'post',
				),
				'title'     => array(
					'type'        => 'string',
					'description' => __( 'Title of the post.', 'mcp-ai-wpoos' ),
				),
				'content'   => array(
					'type'        => 'string',
					'description' => __( 'Main content for the post.', 'mcp-ai-wpoos' ),
				),
				'status'    => array(
					'type'        => 'string',
					'description' => __( 'The status to assign to the post, e.g. draft or publish.', 'mcp-ai-wpoos' ),
					'default'     => 'draft',
				),
				'excerpt'   => array(
					'type'        => 'string',
					'description' => __( 'Optional excerpt for the post.', 'mcp-ai-wpoos' ),
				),
				'slug'      => array(
					'type'        => 'string',
					'description' => __( 'Optional slug to use for the post permalink.', 'mcp-ai-wpoos' ),
				),
			),
			'required'             => array( 'content' ),
			'additionalProperties' => false,
		);
	}

		/**
		 * {@inheritdoc}
		 */
	public function get_data_contract() {
		return array(
			'produces' => 'post_id',
			'consumes' => array( 'post_id' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_validation_class() {
		return \WP_MCP_AI\Tools\Arguments\SavePostArguments::class;
	}

	/**
	 * Execute the tool with validated arguments.
	 *
	 * @param object $validated_args Validated arguments object.
	 * @param array  $context        Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	protected function execute_validated( $validated_args, $context ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'read' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to manage posts.', 'mcp-ai-wpoos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'mcp-ai-wpoos' ) );
		}

		$post_id   = $validated_args->post_id ?? 0;
		$post_type = $validated_args->post_type ?? 'post';

		$post = null;
		if ( $post_id > 0 ) {
			$post = get_post( $post_id );
			// Post existence already validated by WPPostExists constraint.

			if ( $post->post_type !== $post_type ) {
				return new WP_Error( 'wp_mcp_ai_invalid_post_type', __( 'The requested post type does not match the existing post.', 'mcp-ai-wpoos' ) );
			}

			if ( ! user_can( $user_id, 'edit_post', $post_id ) ) {
				return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to edit this post.', 'mcp-ai-wpoos' ) );
			}
		} else {
			$post_type_object = get_post_type_object( $post_type );
			if ( ! $post_type_object ) {
				return new WP_Error( 'wp_mcp_ai_invalid_post_type', __( 'The requested post type does not exist.', 'mcp-ai-wpoos' ) );
			}

			$create_cap = isset( $post_type_object->cap->create_posts ) ? $post_type_object->cap->create_posts : $post_type_object->cap->edit_posts;

			if ( ! user_can( $user_id, $create_cap ) ) {
				return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to create posts of this type.', 'mcp-ai-wpoos' ) );
			}
		}

		// Content is already validated as NotBlank by Symfony Validator.
		$raw_content = $validated_args->content;

		// Convert Markdown to HTML if the content appears to be Markdown rather
		// than already-formatted HTML or block markup.
		$raw_content = $this->maybe_convert_markdown( $raw_content );

		$content = wp_kses_post( $raw_content );

		// Preserve block structure for any post type that uses the block editor.
		// Hardcoding 'post' would corrupt pages and custom post types that also use blocks.
		if ( function_exists( 'use_block_editor_for_post_type' ) && use_block_editor_for_post_type( $post_type ) ) {
			$content = $this->ensure_post_content_uses_blocks( $content, $raw_content );
		}

		$post_data = array(
			'post_type'    => $post_type,
			'post_content' => $content,
		);

		if ( $post_id > 0 ) {
			$post_data['ID'] = $post_id;
		} else {
			$post_data['post_author'] = $user_id;
		}

		// Title is validated by SavePostArguments.
		if ( null !== $validated_args->title ) {
			$post_data['post_title'] = sanitize_text_field( $validated_args->title );
		} elseif ( ! $post_id ) {
			return new WP_Error( 'wp_mcp_ai_missing_title', __( 'A title is required when creating a new post.', 'mcp-ai-wpoos' ) );
		}

		if ( null !== $validated_args->excerpt ) {
			$post_data['post_excerpt'] = wp_kses_post( $validated_args->excerpt );
		}

		if ( null !== $validated_args->slug ) {
			$post_data['post_name'] = sanitize_title( $validated_args->slug );
		}

		// Status is validated by Choice constraint.
		$status = $validated_args->status ?? 'draft';
		if ( '' !== $status ) {
			$valid_statuses = get_post_stati();
			if ( in_array( $status, $valid_statuses, true ) ) {
				$post_data['post_status'] = $status;
			}
		} elseif ( $post_id > 0 && $post ) {
			$post_data['post_status'] = $post->post_status;
		} elseif ( ! $post_id ) {
			$post_data['post_status'] = 'draft';
		}

		if ( isset( $post_data['ID'] ) ) {
			$result = wp_update_post( wp_slash( $post_data ), true );
		} else {
			$result = wp_insert_post( wp_slash( $post_data ), true );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$updated_post = get_post( $result );
		if ( ! $updated_post ) {
			return new WP_Error( 'wp_mcp_ai_unknown_error', __( 'The post was saved but could not be retrieved.', 'mcp-ai-wpoos' ) );
		}

		$summary_text = sprintf(
			/* translators: 1: post ID, 2: post title */
			__( 'Post saved: %1$s (ID: %2$d)', 'mcp-ai-wpoos' ),
			get_the_title( $updated_post ),
			$updated_post->ID
		);

		$response = array(
			'message'   => $summary_text,
			'summary'   => $summary_text,
			'ID'        => $updated_post->ID,
			'title'     => get_the_title( $updated_post ),
			'status'    => get_post_status( $updated_post ),
			'post_type' => $updated_post->post_type,
			'permalink' => get_permalink( $updated_post ),
		);

		$edit_link = get_edit_post_link( $updated_post->ID, '' );
		if ( $edit_link ) {
			$response['edit_link'] = $edit_link;
		}

		return $response;
	}

	/**
	 * Ensures post content uses block markup when the post type supports the block editor.
	 *
	 * Plain text is converted to paragraph blocks; HTML that lacks block markers
	 * is wrapped in a single wp:html block to prevent block-editor corruption.
	 *
	 * @param string $sanitized_content The sanitized post content.
	 * @param string $raw_content       The raw post content, prior to sanitization.
	 *
	 * @return string
	 */
	private function ensure_post_content_uses_blocks( $sanitized_content, $raw_content ) {
		if ( $this->content_contains_blocks( $raw_content ) || $this->content_contains_blocks( $sanitized_content ) ) {
			return $sanitized_content;
		}

		$sanitized_content = trim( $sanitized_content );

		if ( '' === $sanitized_content ) {
			return $sanitized_content;
		}

		$is_plain_text = ( false === strpos( $sanitized_content, '<' ) );

		if ( $is_plain_text ) {
			return $this->convert_plain_text_to_paragraph_blocks( $sanitized_content );
		}

		return sprintf(
			"<!-- wp:html -->\n%s\n<!-- /wp:html -->",
			$sanitized_content
		);
	}

	/**
	 * Determines whether a piece of content already contains block markup.
	 *
	 * @param string $content The content to evaluate.
	 *
	 * @return bool
	 */
	private function content_contains_blocks( $content ) {
		if ( '' === $content ) {
			return false;
		}

		if ( false !== strpos( $content, '<!-- wp:' ) ) {
			return true;
		}

		if ( function_exists( 'has_blocks' ) && has_blocks( $content ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Converts plain text content into a sequence of core paragraph blocks.
	 *
	 * @param string $content Plain text content.
	 *
	 * @return string
	 */
	private function convert_plain_text_to_paragraph_blocks( $content ) {
		$normalized_content = preg_replace( "/\r\n?/", "\n", $content );
		$paragraphs         = preg_split( "/\n{2,}/", trim( $normalized_content ) );
		$blocks             = array();

		foreach ( $paragraphs as $paragraph ) {
			$paragraph = trim( $paragraph );

			if ( '' === $paragraph ) {
				continue;
			}

			$paragraph = str_replace( "\n", "<br />\n", $paragraph );

			$blocks[] = sprintf(
				"<!-- wp:paragraph -->\n<p>%s</p>\n<!-- /wp:paragraph -->",
				$paragraph
			);
		}

		if ( empty( $blocks ) ) {
			return "<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->";
		}

		return implode( "\n\n", $blocks );
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'content_publishing',

			'pattern_compatibility' => array( 'orchestrator', 'sequential' ),

			'profession_tags'       => array( 'writer', 'content_creator', 'journalist' ),

			'risk_level'            => 'standard',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'write',                // Creates or updates posts.
			'local-only',           // No external API calls.
			'requires-capability',  // Requires post editing capabilities.
			'state-changing',       // Modifies database state.
			'reversible',           // Can be undone via post revisions.
		);
	}
}
