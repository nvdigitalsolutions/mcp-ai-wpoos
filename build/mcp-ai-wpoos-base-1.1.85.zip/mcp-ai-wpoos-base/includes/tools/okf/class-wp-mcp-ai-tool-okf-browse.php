<?php
	/**
	 * Tool: okf_browse — Browse an OKF bundle directory.
	 *
	 * @package WP_MCP_AI
	 * @since   2.1.0
	 * @since   2.5.0 — Surfaces OKF v0.2 trust-signal fields for each concept.
	 * @since   1.1.62 — Bundle path resolution via WP_MCP_AI_OKF_Bundle_Manager.
	 * @author  NV Digital Solutions
	 * @copyright Copyright (c) 2026 NV Digital Solutions
	 * @license  GPL-3.0-or-later
	 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OKF — Browse tool.
 */
class WP_MCP_AI_Tool_OKF_Browse implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'okf_browse';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'OKF — Browse Bundle', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Browses an OKF bundle (v0.2) directory via its index.md, listing available concepts and subdirectories with trust-signal summaries (type, status, trust tier). Use this to discover what knowledge is available before reading specific concepts.', 'mcp-ai-wpoos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Discovering which concepts and subdirectories exist in an OKF bundle before reading specific ones.', 'mcp-ai-wpoos' ),
			'when_not_to_use' => __( 'Fetching one known concept body; use okf_read_concept. Filtering by criteria; use okf_search.', 'mcp-ai-wpoos' ),
			'related_tools'   => array( 'okf_read_concept', 'okf_search', 'okf_list_bundles' ),
			'notes'           => __( 'path is empty for the bundle root; trust-signal summaries are added for concept entries only.', 'mcp-ai-wpoos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'bundle' => array(
					'type'        => 'string',
					'description' => __( 'OKF bundle name (e.g. "skill-knowledge", "site-knowledge").', 'mcp-ai-wpoos' ),
				),
				'path'   => array(
					'type'        => 'string',
					'description' => __( 'Directory path within the bundle (empty for root).', 'mcp-ai-wpoos' ),
					'default'     => '',
				),
			),
			'required'   => array( 'bundle' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'read';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$bundle = sanitize_text_field( $arguments['bundle'] );
		$path   = isset( $arguments['path'] ) ? sanitize_text_field( $arguments['path'] ) : '';

		if ( empty( $bundle ) ) {
			return new WP_Error( 'missing_params', __( 'Bundle name is required.', 'mcp-ai-wpoos' ) );
		}

		if ( ! current_user_can( 'read' ) ) {
			return new WP_Error( 'forbidden', __( 'Permission denied.', 'mcp-ai-wpoos' ) );
		}

		$manager     = new WP_MCP_AI_OKF_Bundle_Manager();
		$bundle_root = $manager->resolve_bundle_root( $bundle );
		if ( is_wp_error( $bundle_root ) ) {
			return $bundle_root;
		}

		$reader  = new WP_MCP_AI_OKF_Reader( $bundle_root );
		$entries = $reader->browse( $path );

		if ( is_wp_error( $entries ) ) {
			return $entries;
		}

		$escaped_entries = array();
		foreach ( $entries as $entry ) {
			$item = array(
				'title'       => esc_html( $entry['title'] ),
				'path'        => esc_html( $entry['path'] ),
				'description' => esc_html( $entry['description'] ),
			);

			// Enrich with OKF v0.2 trust signals when available.
			if ( ! empty( $entry['path'] ) && '/' !== substr( $entry['path'], -1 ) ) {
				$concept_id = preg_replace( '/\.md$/', '', $entry['path'] );
				$concept    = $reader->get_concept( $concept_id );
				if ( ! is_wp_error( $concept ) ) {
					$fm                 = $concept['frontmatter'];
					$item['type']       = isset( $fm['type'] ) ? esc_html( $fm['type'] ) : '';
					$item['status']     = isset( $fm['status'] ) ? esc_html( $fm['status'] ) : 'stable';
					$item['trust_tier'] = esc_html( $reader->get_trust_tier( $fm ) );
					$item['stale']      = $reader->is_stale( $fm );
				}
			}

			$escaped_entries[] = $item;
		}

		return $this->format_success_response(
			sprintf(
				/* translators: 1: bundle name, 2: entry count */
				__( 'Browsed bundle "%1$s" — %2$d entries found.', 'mcp-ai-wpoos' ),
				$bundle,
				count( $escaped_entries )
			),
			array(
				'bundle'  => esc_html( $bundle ),
				'path'    => esc_html( $path ),
				'entries' => $escaped_entries,
			)
		);
	}
}
