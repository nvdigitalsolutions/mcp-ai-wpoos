<?php
/**
 * Tool for generating OpenAI images (Validated version).
 *
 * This is the Symfony Validator version of the generate_openai_image tool.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../validators/class-wp-mcp-ai-validated-tool.php';
require_once __DIR__ . '/../validators/arguments/class-generate-openai-image-arguments.php';
require_once __DIR__ . '/class-wp-mcp-ai-tool-generate-openai-image.php';

/**
 * Generates images using OpenAI with Symfony Validator.
 *
 * This class extends the original generate_openai_image tool to use
 * Symfony Validator for argument validation.
 */
class WP_MCP_AI_Tool_Generate_OpenAI_Image_Validated extends WP_MCP_AI_Validated_Tool implements WP_MCP_AI_Tool_Shortcuts_Interface, WP_MCP_AI_Tool_LLM_Sanitizer_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Model_Requirements_Interface, WP_MCP_AI_Tool_Rules_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * The original generate_openai_image tool instance for delegation.
	 *
	 * @var WP_MCP_AI_Tool_Generate_OpenAI_Image
	 */
	protected $original_tool;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
		$this->original_tool = new WP_MCP_AI_Tool_Generate_OpenAI_Image();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_openai_image_validated';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate OpenAI Image (Validated)', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Creates an image with OpenAI and stores it in the Media Library with Symfony Validator for argument validation.', 'mcp-ai-wpoos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Generating an OpenAI image with Symfony Validator enforcement of model, size, quality, and format.', 'mcp-ai-wpoos' ),
			'when_not_to_use' => __( 'When validation is unneeded or unavailable; use generate_openai_image.', 'mcp-ai-wpoos' ),
			'related_tools'   => array( 'generate_openai_image', 'edit_openai_image' ),
			'notes'           => __( 'Delegates to generate_openai_image after validation and shares its schema.', 'mcp-ai-wpoos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		// Use the same schema as the original tool.
		return $this->original_tool->get_parameters_schema();
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_validation_class() {
		return \WP_MCP_AI\Tools\Arguments\GenerateOpenAIImageArguments::class;
	}

	/**
	 * Execute the tool with validated arguments.
	 *
	 * @param \WP_MCP_AI\Tools\Arguments\GenerateOpenAIImageArguments $validated_args Validated arguments object.
	 * @param array                                                   $context        Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	protected function execute_validated( $validated_args, $context ) {
		// Convert validated arguments object back to array format.
		$arguments = array(
			'prompt' => $validated_args->prompt,
		);

		// Add optional arguments if provided.
		if ( null !== $validated_args->model ) {
			$arguments['model'] = $validated_args->model;
		}

		if ( null !== $validated_args->size ) {
			$arguments['size'] = $validated_args->size;
		}

		if ( null !== $validated_args->quality ) {
			$arguments['quality'] = $validated_args->quality;
		}

		if ( null !== $validated_args->style ) {
			$arguments['style'] = $validated_args->style;
		}

		if ( null !== $validated_args->response_format ) {
			$arguments['response_format'] = $validated_args->response_format;
		}

		if ( null !== $validated_args->format ) {
			$arguments['format'] = $validated_args->format;
		}

		if ( null !== $validated_args->file_name ) {
			$arguments['file_name'] = $validated_args->file_name;
		}

		if ( null !== $validated_args->timeout ) {
			$arguments['timeout'] = $validated_args->timeout;
		}

		// Delegate to the original tool's execute method.
		return $this->original_tool->execute( $arguments, $context );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_shortcut_tasks() {
		// Delegate to the original tool.
		return $this->original_tool->get_shortcut_tasks();
	}

	/**
	 * Sanitize result for LLM consumption.
	 *
	 * @param mixed $result The result to sanitize.
	 * @return mixed Sanitized result.
	 */
	public function sanitize_for_llm( $result ) {
		// Delegate to the original tool.
		return $this->original_tool->sanitize_for_llm( $result );
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'content_publishing',

			'pattern_compatibility' => array( 'orchestrator', 'sequential' ),

			'profession_tags'       => array( 'graphic_designer', 'content_creator' ),

			'risk_level'            => 'standard',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		// Delegate to the original tool.
		return $this->original_tool->get_capability_flags();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_model_requirements() {
		// Delegate to the original tool.
		return $this->original_tool->get_model_requirements();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_tool_rules() {
		// Delegate to the original tool.
		return $this->original_tool->get_tool_rules();
	}
}
