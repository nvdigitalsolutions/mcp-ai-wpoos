/**
 * WP MCP AI Assistant Builder Blocks - Frontend JavaScript
 *
 * Handles frontend interactivity for the blocks rendered via PHP.
 *
 * @package WP_MCP_AI
 */

/* global jQuery */

( function ( $ ) {
	'use strict';

	/**
	 * Initialize all assistant builder blocks on the page.
	 */
	function initBlocks() {
		initAssistantSelectors();
		initToolsGrids();
		initKnowledgeBases();
		initAssistantBuilders();
	}

	/**
	 * Initialize assistant selector blocks.
	 */
	function initAssistantSelectors() {
		$( '.wp-block-mcp-ai-wpoos-assistant-selector' ).each( function () {
			const $block = $( this );
			const $select = $block.find( '.wp-mcp-ai-assistant-selector__select' );
			const $startBtn = $block.find( '.wp-mcp-ai-assistant-selector__start' );

			// Enable/disable start button based on selection.
			$select.on( 'change', function () {
				$startBtn.prop( 'disabled', ! $( this ).val() );

				// Trigger custom event for other blocks to listen to.
				$block.trigger( 'assistantSelected', {
					assistantId: $( this ).val(),
					tools: $( this ).find( ':selected' ).data( 'tools' ) || [],
					shortcuts: $( this ).find( ':selected' ).data( 'shortcuts' ) || []
				} );
			} );

			// Handle start button click.
			$startBtn.on( 'click', function () {
				const assistantId = $select.val();
				if ( assistantId ) {
					$block.trigger( 'startChat', { assistantId: assistantId } );
				}
			} );
		} );
	}

	/**
	 * Initialize tools grid blocks.
	 */
	function initToolsGrids() {
		$( '.wp-block-mcp-ai-wpoos-tools-grid' ).each( function () {
			const $block = $( this );
			const $selectAll = $block.find( '.wp-mcp-ai-tools-grid__select-all' );
			const $deselectAll = $block.find( '.wp-mcp-ai-tools-grid__deselect-all' );
			const $selectedCount = $block.find( '.wp-mcp-ai-tools-grid__selected-count' );
			const $checkboxes = $block.find( '.wp-mcp-ai-tools-grid__checkbox' );
			const $searchInput = $block.find( '.wp-mcp-ai-tools-grid__search-input' );
			const $groupSelect = $block.find( '.wp-mcp-ai-tools-grid__group-select' );
			const $clearFilters = $block.find( '.wp-mcp-ai-tools-grid__clear-filters' );
			const $visibleCount = $block.find( '.wp-mcp-ai-tools-grid__visible-count' );
			const $visibleCountText = $block.find( '.wp-mcp-ai-tools-grid__visible-count-text' );

			let searchTerm = '';
			let selectedGroup = '';

			/**
			 * Apply filters to show/hide tools and groups.
			 */
			function applyFilters() {
				let visibleToolsCount = 0;
				const hasActiveFilters = searchTerm !== '' || selectedGroup !== '';

				// Show/hide clear filters button.
				$clearFilters.toggle( hasActiveFilters );

				// Filter each group and its tools.
				$block.find( '.wp-block-mcp-ai-wpoos-tools-grid__group' ).each( function () {
					const $group = $( this );
					const groupId = $group.find( 'summary' ).data( 'group-id' ) || '';
					let visibleInGroup = 0;

					// If a specific group is selected, hide all other groups.
					if ( selectedGroup && groupId !== selectedGroup ) {
						$group.addClass( 'wp-block-mcp-ai-wpoos-tools-grid__group--hidden' );
						return;
					}

					// Filter tools within the group.
					$group.find( '.wp-block-mcp-ai-wpoos-tools-grid__item' ).each( function () {
						const $item = $( this );
						const toolName = $item.find( '.wp-block-mcp-ai-wpoos-tools-grid__item-name' ).text().toLowerCase();
						const toolDesc = $item.find( '.wp-block-mcp-ai-wpoos-tools-grid__item-description' ).text().toLowerCase();
						const searchLower = searchTerm.toLowerCase();

						// Check if tool matches search term.
						const matchesSearch = ! searchTerm ||
							toolName.indexOf( searchLower ) !== -1 ||
							toolDesc.indexOf( searchLower ) !== -1;

						if ( matchesSearch ) {
							$item.removeClass( 'wp-block-mcp-ai-wpoos-tools-grid__item--hidden' );
							visibleInGroup++;
							visibleToolsCount++;
						} else {
							$item.addClass( 'wp-block-mcp-ai-wpoos-tools-grid__item--hidden' );
						}
					} );

					// Hide group if no visible tools.
					if ( visibleInGroup === 0 ) {
						$group.addClass( 'wp-block-mcp-ai-wpoos-tools-grid__group--hidden' );
					} else {
						$group.removeClass( 'wp-block-mcp-ai-wpoos-tools-grid__group--hidden' );
					}
				} );

				// Update visible count indicator.
				if ( hasActiveFilters ) {
					const totalTools = $block.find( '.wp-block-mcp-ai-wpoos-tools-grid__item' ).length;
					$visibleCountText.text( visibleToolsCount + ' of ' + totalTools + ' tools shown' );
					$visibleCount.show();
				} else {
					$visibleCount.hide();
				}

				// Update counts after filtering.
				updateCounts();
			}

			/**
			 * Update counts and selected state.
			 */
			function updateCounts() {
				const totalSelected = $checkboxes.filter( ':checked' ).length;
				$selectedCount.text( totalSelected );

				// Update group counts.
				$block.find( '.wp-block-mcp-ai-wpoos-tools-grid__group' ).each( function () {
					const $group = $( this );
					const $groupCheckboxes = $group.find( '.wp-mcp-ai-tools-grid__checkbox' );
					const groupSelected = $groupCheckboxes.filter( ':checked' ).length;
					$group.find( '.wp-mcp-ai-tools-grid__group-selected' ).text( groupSelected );
				} );

				// Update item classes.
				$checkboxes.each( function () {
					const $checkbox = $( this );
					$checkbox.closest( '.wp-block-mcp-ai-wpoos-tools-grid__item' )
						.toggleClass( 'wp-block-mcp-ai-wpoos-tools-grid__item--selected', $checkbox.is( ':checked' ) );
				} );

				// Trigger custom event.
				const selectedTools = $checkboxes.filter( ':checked' ).map( function () {
					return $( this ).val();
				} ).get();
				$block.trigger( 'toolsChanged', { tools: selectedTools } );
			}

			/**
			 * Clear all filters.
			 */
			function clearFilters() {
				searchTerm = '';
				selectedGroup = '';
				$searchInput.val( '' );
				$groupSelect.val( '' );
				applyFilters();
			}

			// Store group IDs in summary elements for filtering.
			$block.find( '.wp-block-mcp-ai-wpoos-tools-grid__group' ).each( function () {
				const $group = $( this );
				const $select = $groupSelect.find( 'option' ).filter( function () {
					return $( this ).text() === $group.find( '.wp-block-mcp-ai-wpoos-tools-grid__group-title' ).text();
				} );
				if ( $select.length ) {
					$group.find( 'summary' ).attr( 'data-group-id', $select.val() );
				}
			} );

			// Handle search input.
			$searchInput.on( 'input', function () {
				searchTerm = $( this ).val();
				applyFilters();
			} );

			// Handle group filter.
			$groupSelect.on( 'change', function () {
				selectedGroup = $( this ).val();
				applyFilters();
			} );

			// Handle clear filters button.
			$clearFilters.on( 'click', clearFilters );

			// Handle checkbox changes.
			$checkboxes.on( 'change', updateCounts );

			// Handle select all (only visible checkboxes).
			$selectAll.on( 'click', function () {
				$checkboxes.not( '.wp-block-mcp-ai-wpoos-tools-grid__item--hidden .wp-mcp-ai-tools-grid__checkbox' )
					.prop( 'checked', true );
				updateCounts();
			} );

			// Handle deselect all (only visible checkboxes).
			$deselectAll.on( 'click', function () {
				$checkboxes.not( '.wp-block-mcp-ai-wpoos-tools-grid__item--hidden .wp-mcp-ai-tools-grid__checkbox' )
					.prop( 'checked', false );
				updateCounts();
			} );

			// Initial count update.
			updateCounts();
		} );
	}

	/**
	 * Initialize knowledge base blocks.
	 */
	function initKnowledgeBases() {
		$( '.wp-block-mcp-ai-wpoos-knowledge-base' ).each( function () {
			const $block = $( this );
			const $dropzone = $block.find( '.wp-block-mcp-ai-wpoos-knowledge-base__dropzone' );
			const $fileInput = $block.find( '.wp-block-mcp-ai-wpoos-knowledge-base__file-input' );
			const $fileList = $block.find( '.wp-block-mcp-ai-wpoos-knowledge-base__file-list' );
			const $fileIds = $block.find( '.wp-block-mcp-ai-wpoos-knowledge-base__file-ids' );
			const $count = $block.find( '.wp-mcp-ai-knowledge-base__count' );
			const $clearAll = $block.find( '.wp-block-mcp-ai-wpoos-knowledge-base__clear-all' );
			const $progress = $block.find( '.wp-block-mcp-ai-wpoos-knowledge-base__progress' );
			const $progressFill = $block.find( '.wp-block-mcp-ai-wpoos-knowledge-base__progress-fill' );
			const $progressText = $block.find( '.wp-block-mcp-ai-wpoos-knowledge-base__progress-text' );

			const allowedTypes = ( $block.data( 'allowed-types' ) || '' ).split( ',' );
			const maxFiles = $block.data( 'max-files' ) || 10;
			const maxSize = $block.data( 'max-size' ) || 10485760; // 10MB default.
			const uploadUrl = $block.data( 'upload-url' ) || '';
			const nonce = $block.data( 'nonce' ) || '';

			let files = [];
			let uploading = false;

			/**
			 * Update the file count and clear button visibility.
			 */
			function updateUI() {
				$count.text( files.length );
				$clearAll.toggle( files.length > 0 );
				$fileIds.val( files.filter( function ( f ) { return f.id; } ).map( function ( f ) { return f.id; } ).join( ',' ) );
				$block.trigger( 'filesChanged', { files: files } );
			}

			/**
			 * Get file extension.
			 *
			 * @param {string} filename File name.
			 * @return {string} Extension.
			 */
			function getExtension( filename ) {
				return '.' + filename.split( '.' ).pop().toLowerCase();
			}

			/**
			 * Format file size.
			 *
			 * @param {number} bytes File size in bytes.
			 * @return {string} Formatted size.
			 */
			function formatSize( bytes ) {
				if ( bytes < 1024 ) {
					return bytes + ' B';
				}
				if ( bytes < 1048576 ) {
					return ( bytes / 1024 ).toFixed( 1 ) + ' KB';
				}
				return ( bytes / 1048576 ).toFixed( 1 ) + ' MB';
			}

			/**
			 * Validate a file.
			 *
			 * @param {File} file File to validate.
			 * @return {string|null} Error message or null if valid.
			 */
			function validateFile( file ) {
				if ( files.length >= maxFiles ) {
					return 'Maximum number of files reached';
				}

				const ext = getExtension( file.name );
				if ( allowedTypes.length > 0 && allowedTypes.indexOf( ext ) === -1 ) {
					return 'Invalid file type: ' + ext;
				}

				if ( file.size > maxSize ) {
					return 'File too large: ' + formatSize( file.size );
				}

				return null;
			}

			/**
			 * Add a file to the list.
			 *
			 * @param {File} file The file object.
			 * @param {string|null} error Error message if any.
			 * @return {Object} File data object.
			 */
			function addFileToList( file, error ) {
				const fileData = {
					file: file,
					name: file.name,
					size: file.size,
					error: error,
					id: null,
					status: error ? 'error' : 'pending'
				};

				files.push( fileData );

				let itemClass = 'wp-block-mcp-ai-wpoos-knowledge-base__file-item';
				if ( error ) {
					itemClass += ' wp-block-mcp-ai-wpoos-knowledge-base__file-item--error';
				}

				const $item = $( '<li>', { class: itemClass, 'data-index': files.length - 1 } );

				const ext = getExtension( file.name ).replace( '.', '' ).toUpperCase();
				$item.append( $( '<span>', { class: 'wp-block-mcp-ai-wpoos-knowledge-base__file-icon', text: ext } ) );

				const $info = $( '<span>', { class: 'wp-block-mcp-ai-wpoos-knowledge-base__file-info' } );
				$info.append( $( '<span>', { class: 'wp-block-mcp-ai-wpoos-knowledge-base__file-name', text: file.name } ) );

				if ( error ) {
					$info.append( $( '<span>', { class: 'wp-block-mcp-ai-wpoos-knowledge-base__file-error', text: error } ) );
				} else {
					$info.append( $( '<span>', { class: 'wp-block-mcp-ai-wpoos-knowledge-base__file-meta', text: formatSize( file.size ) } ) );
				}

				$item.append( $info );
				$item.append( $( '<button>', {
					type: 'button',
					class: 'wp-block-mcp-ai-wpoos-knowledge-base__file-remove',
					text: 'Remove'
				} ) );

				$fileList.append( $item );
				updateUI();

				return fileData;
			}

			/**
			 * Upload pending files.
			 */
			function uploadFiles() {
				if ( uploading || ! uploadUrl ) {
					return;
				}

				const pendingFiles = files.filter( function ( f ) { return f.status === 'pending'; } );
				if ( pendingFiles.length === 0 ) {
					return;
				}

				uploading = true;
				$progress.show();
				$progressFill.css( 'width', '0%' );

				const total = pendingFiles.length;
				let completed = 0;

				function uploadNext() {
					if ( completed >= total ) {
						uploading = false;
						$progress.hide();
						updateUI();
						return;
					}

					const fileData = pendingFiles[ completed ];
					const $item = $fileList.find( '[data-index="' + files.indexOf( fileData ) + '"]' );
					$item.addClass( 'wp-block-mcp-ai-wpoos-knowledge-base__file-item--uploading' );

					const formData = new FormData();
					formData.append( 'file', fileData.file );

					$.ajax( {
						url: uploadUrl,
						type: 'POST',
						data: formData,
						processData: false,
						contentType: false,
						headers: { 'X-WP-Nonce': nonce },
						success: function ( response ) {
							fileData.id = response.id;
							fileData.status = 'uploaded';
							$item.removeClass( 'wp-block-mcp-ai-wpoos-knowledge-base__file-item--uploading' );
						},
						error: function ( xhr ) {
							let errorMsg = 'Upload failed';
							try {
								const resp = JSON.parse( xhr.responseText );
								if ( resp.message ) {
									errorMsg = resp.message;
								}
							} catch ( e ) {
								// Keep default error.
							}
							fileData.error = errorMsg;
							fileData.status = 'error';
							$item.addClass( 'wp-block-mcp-ai-wpoos-knowledge-base__file-item--error' );
							$item.find( '.wp-block-mcp-ai-wpoos-knowledge-base__file-meta' )
								.removeClass( 'wp-block-mcp-ai-wpoos-knowledge-base__file-meta' )
								.addClass( 'wp-block-mcp-ai-wpoos-knowledge-base__file-error' )
								.text( errorMsg );
						},
						complete: function () {
							completed++;
							const percent = Math.round( ( completed / total ) * 100 );
							$progressFill.css( 'width', percent + '%' );
							$progressText.text( 'Uploading... ' + completed + '/' + total );
							uploadNext();
						}
					} );
				}

				uploadNext();
			}

			/**
			 * Handle files being added.
			 *
			 * @param {FileList} fileList Files to add.
			 */
			function handleFiles( fileList ) {
				for ( let i = 0; i < fileList.length; i++ ) {
					const file = fileList[ i ];
					const error = validateFile( file );
					addFileToList( file, error );
				}
				uploadFiles();
			}

			// Handle dropzone click.
			$dropzone.on( 'click', function () {
				$fileInput.click();
			} );

			// Handle file input change.
			$fileInput.on( 'change', function () {
				handleFiles( this.files );
				this.value = '';
			} );

			// Handle drag and drop.
			$dropzone.on( 'dragover dragenter', function ( e ) {
				e.preventDefault();
				e.stopPropagation();
				$dropzone.addClass( 'wp-block-mcp-ai-wpoos-knowledge-base__dropzone--dragover' );
			} );

			$dropzone.on( 'dragleave dragend drop', function ( e ) {
				e.preventDefault();
				e.stopPropagation();
				$dropzone.removeClass( 'wp-block-mcp-ai-wpoos-knowledge-base__dropzone--dragover' );
			} );

			$dropzone.on( 'drop', function ( e ) {
				e.preventDefault();
				const dt = e.originalEvent.dataTransfer;
				if ( dt && dt.files ) {
					handleFiles( dt.files );
				}
			} );

			// Handle remove button.
			$fileList.on( 'click', '.wp-block-mcp-ai-wpoos-knowledge-base__file-remove', function () {
				const $item = $( this ).closest( '.wp-block-mcp-ai-wpoos-knowledge-base__file-item' );
				const index = parseInt( $item.data( 'index' ), 10 );
				files.splice( index, 1 );
				$item.remove();

				// Re-index remaining items.
				$fileList.find( '.wp-block-mcp-ai-wpoos-knowledge-base__file-item' ).each( function ( i ) {
					$( this ).data( 'index', i );
				} );

				updateUI();
			} );

			// Handle clear all.
			$clearAll.on( 'click', function () {
				files = [];
				$fileList.empty();
				updateUI();
			} );

			// Handle keyboard navigation for dropzone.
			$dropzone.on( 'keydown', function ( e ) {
				if ( e.key === 'Enter' || e.key === ' ' ) {
					e.preventDefault();
					$fileInput.click();
				}
			} );
		} );
	}

	/**
	 * Initialize assistant builder blocks.
	 */
	function initAssistantBuilders() {
		$( '.wp-block-mcp-ai-wpoos-assistant-builder' ).each( function () {
			const $block = $( this );
			const $config = $block.find( '.wp-mcp-ai-assistant-builder-config' );
			let config = {};

			try {
				config = JSON.parse( $config.text() || '{}' );
			} catch ( e ) {
				// Keep empty config.
			}

			const $selector = $block.find( '.wp-block-mcp-ai-wpoos-assistant-selector' );
			const $tools = $block.find( '.wp-block-mcp-ai-wpoos-assistant-builder__tools' );
			const $knowledgeBase = $block.find( '.wp-block-mcp-ai-wpoos-assistant-builder__knowledge-base' );
			const $chat = $block.find( '.wp-block-mcp-ai-wpoos-assistant-builder__chat' );

			// Listen for assistant selection to show other components.
			$selector.on( 'startChat', function ( e, data ) {
				// Show tools and knowledge base.
				$tools.slideDown();
				$knowledgeBase.slideDown();
				$chat.slideDown();

				// Initialize chat if available.
				if ( window.wpMcpAiChat && typeof window.wpMcpAiChat.init === 'function' ) {
					window.wpMcpAiChat.init( $chat[ 0 ], {
						assistantId: data.assistantId,
						enableStreaming: config.enableStreaming,
						placeholder: config.chatPlaceholder
					} );
				}
			} );

			// Sync tools selection with chat.
			$tools.on( 'toolsChanged', function ( e, data ) {
				$chat.trigger( 'updateTools', data );
			} );

			// Sync knowledge base files with chat.
			$knowledgeBase.on( 'filesChanged', function ( e, data ) {
				$chat.trigger( 'updateKnowledgeBase', data );
			} );
		} );
	}

	// Initialize on document ready.
	$( document ).ready( initBlocks );

}( jQuery ) );
