/**
 * NV oOS Settings Dashboard JavaScript
 *
 * Handles tab switching, AJAX operations, and UI interactions.
 */

(function($) {
	'use strict';

	// eslint-disable-next-line camelcase
	const WP_MCP_AI_Dashboard = {
		/**
		 * Initialize the dashboard.
		 */
		init: function() {
			this.bindEvents();
			this.initTooltips();
			this.initTokenManager();
			this.initProviderPriorityList();
			this.initSliders();
			this.initPresets();
			this.initMeshPeers();
			this.initFederationMeshDiagnostics();
		},

		/**
		 * Bind event handlers.
		 */
		bindEvents: function() {
			// Form submission - use event delegation to handle dynamically loaded forms
			// Only attach handler to POST forms since GET forms (like filters) should use default browser navigation
			// Using multiple selectors for broader browser compatibility
			$(document).on('submit', 'form[method="post"], form[method="POST"]', this.handleFormSubmit.bind(this));

			// Tab switching
			$('.nav-tab').on('click', this.handleTabSwitch.bind(this));

			// Sub-tab switching
			$('.wp-mcp-ai-subtab').on('click', this.handleSubTabSwitch.bind(this));
		},

		/**
		 * Initialize token manager functionality.
		 */
		initTokenManager: function() {
			// Reset user token usage
			$('.wp-mcp-ai-reset-user-usage').on('click', this.handleResetUserUsage.bind(this));

			// Reset all users' token usage
			$('#wp-mcp-ai-reset-all-usage').on('click', this.handleResetAllUsage.bind(this));

			// View user details
			$('.wp-mcp-ai-view-user-details').on('click', this.handleViewUserDetails.bind(this));

			// Save all tool limits
			$('#wp-mcp-ai-save-all-tool-limits').on('click', this.handleSaveToolLimits.bind(this));
			// Save all tool settings (new enhanced button with multipliers)
			$('#wp-mcp-ai-save-all-tool-settings').on('click', this.handleSaveToolSettings.bind(this));

			// Export token usage to CSV
			$('#wp-mcp-ai-export-usage-csv').on('click', this.handleExportUsageCSV.bind(this));

			// Bulk tier assignment
			$('#wp-mcp-ai-select-all-users').on('change', this.handleSelectAllUsers.bind(this));
			$('.wp-mcp-ai-user-checkbox').on('change', this.handleUserCheckboxChange.bind(this));
			$('#bulk-tier-selector').on('change', this.handleBulkTierSelectorChange.bind(this));
			$('#wp-mcp-ai-apply-bulk-tier').on('click', this.handleApplyBulkTier.bind(this));

			// Tool recommendations
			$('#wp-mcp-ai-view-recommendations').on('click', this.handleViewRecommendations.bind(this));
			$('#wp-mcp-ai-apply-all-recommendations').on('click', this.handleApplyAllRecommendations.bind(this));
			$('#wp-mcp-ai-apply-preset').on('click', this.handleApplyPreset.bind(this));
			$('.wp-mcp-ai-modal-close, .wp-mcp-ai-modal-overlay').on('click', this.handleCloseModal.bind(this));

			// Preset description update
			$('#wp-mcp-ai-preset-selector').on('change', this.handlePresetChange.bind(this));
		},

		/**
		 * Handle reset user token usage.
		 *
		 * @param {Event} e Click event.
		 */
		handleResetUserUsage: function(e) {
			e.preventDefault();
			const $button = $(e.currentTarget);
			const userId = $button.data('user-id');
			const userName = $button.data('user-name');

			if (!confirm('Are you sure you want to reset token usage for ' + userName + '? This action cannot be undone.')) {
				return;
			}

			$button.prop('disabled', true).text('Resetting...');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiDashboard.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_reset_user_token_usage',
					nonce: wpMcpAiDashboard.nonce,
					user_id: userId
				}
			}, {
				success: function(response) {
					if (response.success) {
						// Use window.location.href instead of reload() to prevent browser form resubmission
						window.location.href = window.location.href;
					} else {
						alert(response.data.message || 'Failed to reset user token usage.');
						$button.prop('disabled', false).text('Reset');
					}
				},
				error: function(error) {
					alert(error.userMessage || 'An error occurred while resetting user token usage.');
					$button.prop('disabled', false).text('Reset');
				}
			});
		},

		/**
		 * Handle reset all users' token usage.
		 *
		 * @param {Event} e Click event.
		 */
		handleResetAllUsage: function(e) {
			e.preventDefault();
			const $button = $(e.currentTarget);

			if (!confirm('Are you sure you want to reset token usage for ALL users? This action cannot be undone.')) {
				return;
			}

			$button.prop('disabled', true).text('Resetting...');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiDashboard.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_reset_all_token_usage',
					nonce: wpMcpAiDashboard.nonce
				}
			}, {
				success: function(response) {
					if (response.success) {
						// Use window.location.href instead of reload() to prevent browser form resubmission
						window.location.href = window.location.href;
					} else {
						alert(response.data.message || 'Failed to reset all token usage.');
						$button.prop('disabled', false).text('Reset All Users\' Token Usage');
					}
				},
				error: function(error) {
					alert(error.userMessage || 'An error occurred while resetting token usage.');
					$button.prop('disabled', false).text('Reset All Users\' Token Usage');
				}
			});
		},

		/**
		 * Handle view user details toggle.
		 *
		 * @param {Event} e Click event.
		 */
		handleViewUserDetails: function(e) {
			e.preventDefault();
			const $button = $(e.currentTarget);
			const userId = $button.data('user-id');
			const $detailsRow = $('#user-details-' + userId);

			if ($detailsRow.is(':visible')) {
				$detailsRow.hide();
				$button.text('Details');
			} else {
				$detailsRow.show();
				$button.text('Hide Details');
			}
		},

		/**
		 * Handle save tool limits.
		 *
		 * @param {Event} e Click event.
		 */
		handleSaveToolLimits: function(e) {
			e.preventDefault();
			const $button = $(e.currentTarget);
			const limits = {};

			$('.wp-mcp-ai-tool-limit-input').each(function() {
				const $input = $(this);
				limits[$input.data('tool-slug')] = $input.val();
			});

			$button.prop('disabled', true).text('Saving...');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiDashboard.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_save_tool_limits',
					nonce: wpMcpAiDashboard.nonce,
					limits: limits
				}
			}, {
				success: function(response) {
					if (response.success) {
						// Check if this is a "no changes" response
						if (response.data.no_changes) {
							alert(response.data.message);
							$button.prop('disabled', false).text('Save All Tool Limits');
						} else {
							$button.text('Saved!');
							setTimeout(function() {
								window.location.href = window.location.href;
							}, 1000);
						}
					} else {
						alert(response.data.message || 'Failed to save tool limits.');
						$button.prop('disabled', false).text('Save All Tool Limits');
					}
				},
				error: function(error) {
					alert(error.userMessage || 'An error occurred while saving tool limits.');
					$button.prop('disabled', false).text('Save All Tool Limits');
				}
			});
		},

		/**
		 * Handle save tool settings (limits + multipliers + model preferences).
		 *
		 * @param {Event} e Click event.
		 */
		handleSaveToolSettings: function(e) {
			e.preventDefault();
			const $button = $(e.currentTarget);
			const $spinner = $button.next('.spinner');
			const $message = $('#wp-mcp-ai-tool-settings-message');
			const limits = {};
			const multipliers = {};
			const modelPreferences = {};

			// Collect all limits
			$('.wp-mcp-ai-tool-limit-input').each(function() {
				const $input = $(this);
				limits[$input.data('tool-slug')] = $input.val();
			});

			// Collect all multipliers
			$('.wp-mcp-ai-tool-multiplier-input').each(function() {
				const $input = $(this);
				multipliers[$input.data('tool-slug')] = $input.val();
			});

			// Collect all model preferences
			$('.wp-mcp-ai-tool-model-input').each(function() {
				const $select = $(this);
				modelPreferences[$select.data('tool-slug')] = $select.val();
			});

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$message.text('').removeClass('error success');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiDashboard.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_save_tool_limits',
					nonce: wpMcpAiDashboard.nonce,
					limits: limits,
					multipliers: multipliers,
					model_preferences: modelPreferences
				}
			}, {
				success: function(response) {
					$spinner.removeClass('is-active');
					if (response.success) {
						// Check if this is a "no changes" response
						if (response.data.no_changes) {
							$message.text(response.data.message).addClass('notice notice-info');
							$button.prop('disabled', false);
						} else {
							$message.text(response.data.message).addClass('notice notice-success');
							setTimeout(function() {
								window.location.href = window.location.href;
							}, 1500);
						}
					} else {
						$message.text(response.data.message || 'Failed to save tool settings.').addClass('notice notice-error');
						$button.prop('disabled', false);
					}
				},
				error: function(error) {
					$spinner.removeClass('is-active');
					$message.text(error.userMessage || 'An error occurred while saving tool settings.').addClass('notice notice-error');
					$button.prop('disabled', false);
				}
			});
		},

		/**
		 * Handle export token usage to CSV.
		 *
		 * @param {Event} e Click event.
		 */
		handleExportUsageCSV: function(e) {
			e.preventDefault();
			const $button = $(e.currentTarget);

			$button.prop('disabled', true).text('Exporting...');

			// Create a form to submit the export request
			const $form = $('<form>', {
				method: 'POST',
				action: wpMcpAiDashboard.ajaxUrl,
				target: '_blank'
			});

			// Add hidden fields
			$form.append($('<input>', {
				type: 'hidden',
				name: 'action',
				value: 'wp_mcp_ai_export_token_usage_csv'
			}));

			$form.append($('<input>', {
				type: 'hidden',
				name: 'nonce',
				value: wpMcpAiDashboard.nonce
			}));

			// TODO: Add filter inputs when filter UI is implemented
			// For now, export all users

			// Append form to body and submit
			$form.appendTo('body').submit();

			// Clean up and reset button
			setTimeout(function() {
				$form.remove();
				$button.prop('disabled', false).text('Export to CSV');
			}, 1000);
		},

		/**
		 * Handle select all users checkbox.
		 *
		 * @param {Event} e Change event.
		 */
		handleSelectAllUsers: function(e) {
			const checked = $(e.currentTarget).prop('checked');
			$('.wp-mcp-ai-user-checkbox').prop('checked', checked);
			this.updateBulkActionButton();
		},

		/**
		 * Handle individual user checkbox change.
		 */
		handleUserCheckboxChange: function() {
			// Update select all checkbox state
			const totalCheckboxes = $('.wp-mcp-ai-user-checkbox').length;
			const checkedCheckboxes = $('.wp-mcp-ai-user-checkbox:checked').length;

			$('#wp-mcp-ai-select-all-users').prop('checked', totalCheckboxes === checkedCheckboxes);
			this.updateBulkActionButton();
		},

		/**
		 * Handle bulk tier selector change.
		 */
		handleBulkTierSelectorChange: function() {
			this.updateBulkActionButton();
		},

		/**
		 * Update bulk action button state.
		 */
		updateBulkActionButton: function() {
			const hasSelection = $('.wp-mcp-ai-user-checkbox:checked').length > 0;
			const hasTier = $('#bulk-tier-selector').val() !== '';
			$('#wp-mcp-ai-apply-bulk-tier').prop('disabled', !hasSelection || !hasTier);
		},

		/**
		 * Handle apply bulk tier action.
		 *
		 * @param {Event} e Click event.
		 */
		handleApplyBulkTier: function(e) {
			e.preventDefault();
			const $button = $(e.currentTarget);
			const tier = $('#bulk-tier-selector').val();
			const userIds = [];

			$('.wp-mcp-ai-user-checkbox:checked').each(function() {
				userIds.push($(this).val());
			});

			if (userIds.length === 0) {
				alert('Please select at least one user.');
				return;
			}

			if (!tier) {
				alert('Please select a tier.');
				return;
			}

			const tierName = $('#bulk-tier-selector option:selected').text();
			if (!confirm('Are you sure you want to assign ' + tierName + ' to ' + userIds.length + ' user(s)?')) {
				return;
			}

			$button.prop('disabled', true).text('Applying...');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiDashboard.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_bulk_assign_tier',
					nonce: wpMcpAiDashboard.nonce,
					user_ids: userIds,
					tier: tier
				}
			}, {
				success: function(response) {
					if (response.success) {
						alert(response.data.message);
						// Use window.location.href instead of reload() to prevent browser form resubmission
						window.location.href = window.location.href;
					} else {
						alert(response.data.message || 'Failed to assign tiers.');
						$button.prop('disabled', false).text('Apply');
					}
				},
				error: function(error) {
					alert(error.userMessage || 'An error occurred while assigning tiers.');
					$button.prop('disabled', false).text('Apply');
				}
			});
		},

		/**
		 * Handle form submission with loading state.
		 *
		 * @param {Event} e Submit event.
		 */
		handleFormSubmit: function(e) {
			const $form = $(e.target);
			const $submit = $form.find('input[type="submit"]');
			
			// CRITICAL FIX: Ensure subtab hidden fields are set correctly before submission.
			// This fixes the issue where subtab settings (like enable_federation_directory) don't persist.
			// The hidden field value must match the current URL subtab parameter to ensure
			// correct field sanitization in subtab-aware sections.
			const urlParams = new URLSearchParams(window.location.search);
			const currentSubtab = urlParams.get('subtab');
			const currentConnection = urlParams.get('connection');
			
			// Find all subtab hidden fields in the form.
			const $subtabFields = $form.find('input[type="hidden"][name^="subtab_"]');
			
			if ($subtabFields.length > 0) {
				// Process each subtab hidden field.
				$subtabFields.each(function() {
					const $hiddenField = $(this);
					const fieldName = $hiddenField.attr('name');
					const oldValue = $hiddenField.val();
					
					// Determine the correct subtab value to use:
					// 1. If URL has connection parameter, use it (for Integrations section)
					// 2. If URL has subtab parameter, use it (for other sections)
					// 3. Otherwise, keep the existing field value (from PHP rendering)
					// 4. As last resort, try to detect from active subtab link
					let newValue = currentConnection || currentSubtab;
					
					if (!newValue) {
						// No URL parameter - check if field already has a valid value.
						if (oldValue && oldValue !== '') {
							newValue = oldValue;
							console.log('[NV oOS Settings] Subtab field', fieldName, 'kept existing value:', oldValue, '(no URL param)');
						} else {
							// Try to detect from active subtab link in the section.
							const $activeSubtab = $form.find('.wp-mcp-ai-subtab-active[data-subtab]');
							if ($activeSubtab.length > 0) {
								newValue = $activeSubtab.data('subtab');
								console.log('[NV oOS Settings] Subtab field', fieldName, 'detected from active link:', newValue);
							}
						}
					}
					
					// Update the field value if we have a valid value.
					if (newValue && newValue !== oldValue) {
						$hiddenField.val(newValue);
						console.log('[NV oOS Settings] Updated subtab hidden field:', fieldName, 'from', oldValue, 'to', newValue);
					} else if (newValue === oldValue) {
						console.log('[NV oOS Settings] Subtab field', fieldName, 'already has correct value:', newValue);
					} else {
						console.warn('[NV oOS Settings] WARNING: Could not determine subtab value for field:', fieldName);
					}
				});
			} else {
				console.log('[NV oOS Settings] No subtab hidden fields found in form (this is OK for tabs without subtabs)');
			}
			
			// CRITICAL FIX: Add hidden fields for unchecked checkboxes to ensure they're submitted.
			// Standard HTML behavior: unchecked checkboxes don't appear in FormData.
			// This ensures unchecked checkboxes are submitted as value="0" so backend can process them.
			
			// First, remove any existing placeholder hidden fields from previous submission attempts.
			$form.find('input[type="hidden"][data-checkbox-placeholder="true"]').remove();
			
			// Then, scan all checkboxes and add hidden fields for unchecked ones.
			const checkboxes = {};
			const uncheckedCheckboxes = [];
			$form.find('input[type="checkbox"][name^="wp_mcp_ai_settings"]').each(function() {
				const $checkbox = $(this);
				const checkboxName = $checkbox.attr('name');
				const name = checkboxName.replace('wp_mcp_ai_settings[', '').replace(']', '');
				const isChecked = $checkbox.is(':checked');
				checkboxes[name] = isChecked;
				
				// If checkbox is unchecked, add a hidden field with value="0" to ensure it's submitted.
				if (!isChecked) {
					uncheckedCheckboxes.push(name);
					$form.append(
						$('<input>')
							.attr('type', 'hidden')
							.attr('name', checkboxName)
							.attr('data-checkbox-placeholder', 'true')
							.val('0')
					);
				}
			});
			console.log('[NV oOS Settings] Checkbox states:', checkboxes);
			if (uncheckedCheckboxes.length > 0) {
				console.log('[NV oOS Settings] Added hidden fields for unchecked checkboxes:', uncheckedCheckboxes);
			}
			
			// ENHANCED LOGGING: Specifically log federation/mesh checkbox states for debugging.
			const federationCheckboxes = ['enable_mesh', 'enable_federation', 'enable_federation_directory'];
			const federationStates = {};
			federationCheckboxes.forEach(function(name) {
				if (typeof checkboxes[name] !== 'undefined') {
					federationStates[name] = checkboxes[name];
				}
			});
			if (Object.keys(federationStates).length > 0) {
				console.log('[NV oOS Settings] Federation/Mesh checkbox states at submission:', federationStates);
			}
			
			// Get form data for logging.
			const formData = new FormData($form[0]);
			const activeTab = formData.get('active_tab');
			const settingsData = {};
			let fieldCount = 0;
			
			// Extract wp_mcp_ai_settings fields for logging.
			for (const [key, value] of formData.entries()) {
				if (key.startsWith('wp_mcp_ai_settings[')) {
					const fieldName = key.match(/wp_mcp_ai_settings\[([^\]]+)\]/)[1];
					settingsData[fieldName] = value;
					fieldCount++;
				}
			}
			
			// Log form submission details to console.
			console.log('[NV oOS Settings] Form submission initiated');
			console.log('[NV oOS Settings] Active tab:', activeTab);
			console.log('[NV oOS Settings] Fields being submitted:', fieldCount);
			console.log('[NV oOS Settings] Field names:', Object.keys(settingsData).join(', '));
			console.log('[NV oOS Settings] Form action:', $form.attr('action'));
			
			// Check for potential issues.
			if (fieldCount === 0) {
				console.warn('[NV oOS Settings] WARNING: No settings fields found in form data!');
			}
			
			if (!activeTab) {
				console.warn('[NV oOS Settings] WARNING: No active_tab value found!');
			}

			// Add loading state.
			$submit.prop('disabled', true);
			$form.addClass('loading');
			
			console.log('[NV oOS Settings] Form is now submitting...');

			// Original text will be restored on page reload after redirect.
			// Note: This is a standard POST submission, not AJAX.
			// The page will reload after the server processes and redirects.
		},

		/**
		 * Handle tab switching.
		 *
		 * @param {Event} e Click event.
		 */
		handleTabSwitch: function(e) {
			// Allow default navigation - we're using server-side rendering.
			// Just add a visual loading indicator.
			const $tab = $(e.currentTarget);
			$tab.addClass('loading');
		},

		/**
		 * Handle sub-tab switching (provider sub-tabs).
		 *
		 * @param {Event} e Click event.
		 */
		handleSubTabSwitch: function(e) {
			// Allow default navigation for sub-tabs.
			const $subtab = $(e.currentTarget);
			$subtab.addClass('loading');
		},

		/**
		 * Initialize tooltips for help text.
		 */
		initTooltips: function() {
			// Add tooltips if WordPress tooltip library is available.
			if (typeof jQuery.fn.tooltip !== 'undefined') {
				$('.help-text').tooltip({
					position: {
						my: 'center bottom-5',
						at: 'center top'
					}
				});
			}
		},

		/**
		 * Initialize provider priority list sortable.
		 */
		initProviderPriorityList: function() {
			const $sortable = $('#wp-mcp-ai-provider-sortable');

			if ($sortable.length && typeof $sortable.sortable === 'function') {
				$sortable.sortable({
					axis: 'y',
					handle: '.dashicons-menu',
					cursor: 'move',
					placeholder: 'ui-sortable-placeholder',
					opacity: 0.8,
					tolerance: 'pointer',
					update: function() {
						// Update hidden input values to maintain order
						$sortable.find('li').each(function() {
							const $item = $(this);
							const provider = $item.data('provider');
							$item.find('input[type="hidden"]').val(provider);
						});
					}
				});
			}
		},

		/**
		 * Show a notice message.
		 *
		 * @param {string} message Notice message.
		 * @param {string} type Notice type (success, error, warning, info).
		 */
		showNotice: function(message, type) {
			type = type || 'info';
			const noticeClass = 'notice-' + type;

			const $notice = $('<div>')
				.addClass('notice ' + noticeClass + ' is-dismissible')
				.append($('<p>').text(message));

			$('.wrap h1').after($notice);

			// Auto-dismiss after 5 seconds.
			setTimeout(function() {
				$notice.fadeOut(function() {
					$(this).remove();
				});
			}, 5000);
		},

		/**
		 * Initialize range sliders.
		 */
		initSliders: function() {
			$('.wp-mcp-ai-slider').on('input', function() {
				const $slider = $(this);
				const value = $slider.val();
				const suffix = $slider.data('suffix') || '';
				const valueId = $slider.attr('id') + '-value';
				$('#' + valueId).text('[' + value + suffix + ']');
			});
		},

		/**
		 * Initialize preset selectors.
		 */
		initPresets: function() {
			const self = this;

			$('.apply-preset').on('click', function(e) {
				e.preventDefault();
				const $button = $(this);
				const presetId = $button.data('preset');

				if (!presetId) {
					return;
				}

				// Confirm before applying (except for custom preset)
				if (presetId !== 'custom' && !confirm('Apply the "' + $button.closest('.preset-card').find('h4').text() + '" preset? This will update all orchestration settings.')) {
					return;
				}

				$button.prop('disabled', true).text('Applying...');

				// Use the error service for consistent error handling
				$.wpMcpAiAjax({
					url: wpMcpAiDashboard.ajaxUrl,
					type: 'POST',
					data: {
						action: 'wp_mcp_ai_apply_orchestration_preset',
						nonce: wpMcpAiDashboard.nonce,
						preset_id: presetId
					}
				}, {
					success: function(response) {
						if (response.success) {
							// Update the hidden field value immediately so if user clicks "Save Changes" 
							// before reload, the correct preset will be saved
							$('#orchestration_preset').val(presetId);
							
							// Update the active preset indicator text immediately
							const presetName = $('.preset-card[data-preset="' + presetId + '"] h4').text();
							$('.current-preset-name').text(presetName);
							
							self.showNotice('Preset applied successfully. Reloading page...', 'success');
							setTimeout(function() {
								window.location.href = window.location.href;
							}, 1000);
						} else {
							self.showNotice(response.data.message || 'Failed to apply preset.', 'error');
							$button.prop('disabled', false).text('Apply');
						}
					},
					error: function(error) {
						self.showNotice(error.userMessage || 'An error occurred while applying the preset.', 'error');
						$button.prop('disabled', false).text('Apply');
					}
				});
			});
		},

		/**
		 * Initialize mesh peer sites functionality.
		 */
		initMeshPeers: function() {
			const $meshPeers = $('#wp-mcp-ai-mesh-peers');
			if ($meshPeers.length === 0) {
				return;
			}

			let peerIndex = parseInt($meshPeers.data('peer-index'), 10) || 0;
			const $addButton = $('#wp-mcp-ai-add-peer');
			const optionName = $meshPeers.data('option-name');
			const placeholderName = $addButton.data('placeholder-name');
			const placeholderUrl = $addButton.data('placeholder-url');
			const placeholderKey = $addButton.data('placeholder-key');
			const btnRemove = $addButton.data('btn-remove');

			// Add peer site
			$addButton.on('click', function() {
				const newRow = $('<tr class="wp-mcp-ai-mesh-peer-row">' +
					'<td><input type="text" name="' + optionName + '[mesh_peer_sites][' + peerIndex + '][name]" value="" class="regular-text" placeholder="' + placeholderName + '" /></td>' +
					'<td><input type="url" name="' + optionName + '[mesh_peer_sites][' + peerIndex + '][url]" value="" class="regular-text" placeholder="' + placeholderUrl + '" /></td>' +
					'<td><input type="text" name="' + optionName + '[mesh_peer_sites][' + peerIndex + '][api_key]" value="" class="regular-text" placeholder="' + placeholderKey + '" /></td>' +
					'<td><button type="button" class="button wp-mcp-ai-remove-peer">' + btnRemove + '</button></td>' +
					'</tr>');
				$meshPeers.find('tbody').append(newRow);
				peerIndex++;
			});

			// Remove peer site (delegated event)
			$meshPeers.on('click', '.wp-mcp-ai-remove-peer', function() {
				$(this).closest('tr').remove();
			});
		},

		/**
		 * Handle view recommendations modal.
		 *
		 * @param {Event} e Click event.
		 */
		handleViewRecommendations: function(e) {
			e.preventDefault();
			$('#wp-mcp-ai-recommendations-modal').fadeIn(200);
		},

		/**
		 * Handle apply all recommendations.
		 *
		 * @param {Event} e Click event.
		 */
		handleApplyAllRecommendations: function(e) {
			e.preventDefault();
			const $button = $(e.currentTarget);

			if (!confirm('Are you sure you want to apply recommended settings to all tools? This will overwrite your current multiplier and model preference settings.')) {
				return;
			}

			$button.prop('disabled', true).text('Applying...');

			$.wpMcpAiAjax({
				url: wpMcpAiDashboard.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_apply_all_recommendations',
					nonce: wpMcpAiDashboard.nonce
				}
			}, {
				success: function(response) {
					if (response.success) {
						alert(response.data.message || 'Recommendations applied successfully!');
						// Use window.location.href instead of reload() to prevent browser form resubmission
						window.location.href = window.location.href;
					} else {
						alert(response.data.message || 'Failed to apply recommendations.');
						$button.prop('disabled', false).text('Apply Recommended Settings to All Tools');
					}
				},
				error: function(error) {
					alert(error.userMessage || 'An error occurred while applying recommendations.');
					$button.prop('disabled', false).text('Apply Recommended Settings to All Tools');
				}
			});
		},

		/**
		 * Handle close modal.
		 *
		 * @param {Event} e Click event.
		 */
		handleCloseModal: function(e) {
			e.preventDefault();
			$('#wp-mcp-ai-recommendations-modal').fadeOut(200);
		},

		/**
		 * Handle preset change.
		 *
		 * @param {Event} e Change event.
		 */
		handlePresetChange: function(e) {
			const preset = $(e.currentTarget).val();
			const descriptions = {
				'conservative': 'Lower token limits for cost control. Best for budget-conscious deployments.',
				'balanced': 'Optimal balance between performance and cost. Uses our analyzed recommendations.',
				'performance': 'Higher token limits for maximum performance. Best for high-traffic or demanding applications.',
				'aggressive': 'Maximum token limits for complex operations. Use when cost is not a concern.'
			};

			$('#wp-mcp-ai-preset-description').text(descriptions[preset] || descriptions['balanced']);
		},

		/**
		 * Handle apply preset.
		 *
		 * @param {Event} e Click event.
		 */
		handleApplyPreset: function(e) {
			e.preventDefault();
			const $button = $(e.currentTarget);
			const preset = $('#wp-mcp-ai-preset-selector').val();

			if (!preset) {
				alert('Please select a preset.');
				return;
			}

			const presetNames = {
				'conservative': 'Conservative',
				'balanced': 'Balanced',
				'performance': 'Performance',
				'aggressive': 'Aggressive'
			};

			if (!confirm('Apply the ' + (presetNames[preset] || preset) + ' preset to all tools? This will overwrite your current settings.')) {
				return;
			}

			$button.prop('disabled', true).text('Applying...');

			$.wpMcpAiAjax({
				url: wpMcpAiDashboard.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_apply_preset',
					nonce: wpMcpAiDashboard.nonce,
					preset: preset
				}
			}, {
				success: function(response) {
					if (response.success) {
						alert(response.data.message || 'Preset applied successfully!');
						// Use window.location.href instead of reload() to prevent browser form resubmission
						// This ensures we don't trigger POST form resubmission warnings or cached form data
						window.location.href = window.location.href;
					} else {
						alert(response.data.message || 'Failed to apply preset.');
						$button.prop('disabled', false).text('Apply Preset');
					}
				},
				error: function(error) {
					alert(error.userMessage || 'An error occurred while applying the preset.');
					$button.prop('disabled', false).text('Apply Preset');
				}
			});
		},

		/**
		 * Initialize diagnostics for Federation & Mesh checkboxes.
		 * Adds console logging and click handlers to help debug checkbox issues.
		 */
		initFederationMeshDiagnostics: function() {
			// Only run on advanced tab, federation_mesh subtab
			const urlParams = new URLSearchParams(window.location.search);
			const tab = urlParams.get('tab');
			const subtab = urlParams.get('subtab');
			
			if (tab !== 'advanced' || subtab !== 'federation_mesh') {
				return;
			}

			console.log('[NV oOS Federation Mesh] Diagnostics initialized');

			// Add timestamp helper
			const logWithTimestamp = function(message, ...args) {
				const timestamp = new Date().toISOString().split('T')[1].slice(0, -1); // HH:MM:SS.mmm
				console.log('[' + timestamp + '] ' + message, ...args);
			};

			logWithTimestamp('[NV oOS Federation Mesh] Diagnostics initialized');

			// Add a visual indicator that diagnostics are running
			$('.wrap.wp-mcp-ai-settings-dashboard').prepend(
				'<div class="notice notice-info" style="margin: 15px 0; padding: 10px 15px;">' +
				'<p><strong>🔍 Diagnostics Mode:</strong> Federation Mesh checkbox diagnostics are active. Check browser console (F12) for detailed logs.</p>' +
				'<p><strong>Note:</strong> The checkbox <code>value</code> attribute is always "1" regardless of checked state. This is normal HTML behavior. ' +
				'The <code>checked</code> property indicates whether the checkbox is actually selected.</p>' +
				'</div>'
			);

			// Target the three federation/mesh checkboxes
			const checkboxIds = ['enable_mesh', 'enable_federation', 'enable_federation_directory'];
			
			checkboxIds.forEach(function(id) {
				const $checkbox = $('#' + id);
				
				if ($checkbox.length === 0) {
					console.warn('[NV oOS Federation Mesh] Checkbox not found:', id);
					return;
				}

				// Get the actual checked state from the DOM
				const isChecked = $checkbox.is(':checked');
				const $slider = $checkbox.siblings('.wp-mcp-ai-settings-toggle-slider');
				const sliderBackgroundColor = $slider.length > 0 ? $slider.css('background-color') : 'N/A';
				
				// Determine the visual state description
				const visualState = isChecked ? '✅ ON (checked)' : '❌ OFF (unchecked)';
				
				// Log current state with visual verification
				logWithTimestamp('[NV oOS Federation Mesh] Checkbox found: ' + id, {
					visualState: visualState,
					checked: isChecked,
					disabled: $checkbox.is(':disabled'),
					visible: $checkbox.is(':visible'),
					name: $checkbox.attr('name'),
					value: $checkbox.val() + ' (always "1" for checkboxes, use "checked" property for state)',
					sliderBgColor: sliderBackgroundColor
				});

				// Add change handler for debugging
				$checkbox.on('change', function() {
					const newIsChecked = $(this).is(':checked');
					const newVisualState = newIsChecked ? '✅ ON' : '❌ OFF';
					logWithTimestamp('[NV oOS Federation Mesh] Checkbox changed: ' + id + ' → ' + newVisualState + ' (checked=' + newIsChecked + ')');
				});

				// Check if the checkbox is actually clickable
				const $label = $('label[for="' + id + '"]');
				if ($label.length > 0) {
					logWithTimestamp('[NV oOS Federation Mesh] Label found for: ' + id);
				} else {
					console.warn('[NV oOS Federation Mesh] No label found for:', id);
				}

				// Check for overlapping elements that might block clicks
				// Note: The checkbox itself is hidden (opacity: 0, width/height: 0), so we check the visible slider
				if ($slider.length > 0) {
					const rect = $slider[0].getBoundingClientRect();
					// Only check if the slider has valid dimensions
					if (rect.width > 0 && rect.height > 0) {
						const centerX = rect.left + rect.width / 2;
						const centerY = rect.top + rect.height / 2;
						const elementAtPoint = document.elementFromPoint(centerX, centerY);
						
						// Check if element at center is the slider itself or within its container
						const isSliderItself = (elementAtPoint === $slider[0]);
						const isWithinContainer = $checkbox.closest('.wp-mcp-ai-settings-toggle-switch').find(elementAtPoint).length > 0;
						
						if (elementAtPoint && !isSliderItself && !isWithinContainer) {
							console.warn('[NV oOS Federation Mesh] Element covering slider for checkbox:', id, elementAtPoint);
						} else if (elementAtPoint) {
							logWithTimestamp('[NV oOS Federation Mesh] Slider clickable for: ' + id);
						}
					}
				}
			});

			// Log when save button is clicked
			$('input[type="submit"][name="submit"]').on('click', function() {
				logWithTimestamp('[NV oOS Federation Mesh] Save button clicked');
				checkboxIds.forEach(function(id) {
					const $checkbox = $('#' + id);
					if ($checkbox.length > 0) {
						logWithTimestamp('[NV oOS Federation Mesh] Checkbox state at save: ' + id + ' = ' + $checkbox.is(':checked'));
					}
				});
			});
		}
	};

	/**
	 * Initialize Brave Search connection test handlers.
	 */
	function initBraveSearchHandlers() {
		// Test Brave Search connection
		$('#wp-mcp-ai-test-brave-search-connection').on('click', function (e) {
			e.preventDefault();
			const $button = $(this);
			const $result = $('#wp-mcp-ai-brave-search-test-result');
			const apiKey = $('input[name="wp_mcp_ai_settings[brave_search_api_key]"]').val();

			if (!apiKey) {
				$result.html('<span style="color: #d63638;">Please enter an API key first.</span>');
				return;
			}

			$button.prop('disabled', true).text('Testing...');
			$result.html('<span style="color: #3c434a;">Connecting to Brave Search...</span>');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_test_brave_search_connection',
					nonce: wpMcpAiAdmin.nonce,
					api_key: apiKey
				}
			}, {
				success: function (response) {
					if (response.success) {
						$result.html('<span style="color: #00a32a;">✓ ' + response.data.message + '</span>');
					} else {
						$result.html('<span style="color: #d63638;">✗ ' + response.data.message + '</span>');
					}
				},
				error: function (error) {
					$result.html('<span style="color: #d63638;">✗ ' + (error.userMessage || 'Connection failed') + '</span>');
				},
				complete: function () {
					$button.prop('disabled', false).text('Test Connection');
				}
			});
		});
	}

	/**
	 * Initialize Yahoo Sports connection test handlers.
	 */
	function initYahooHandlers() {
		// Test Yahoo connection
		$('#wp-mcp-ai-test-yahoo-connection').on('click', function (e) {
			e.preventDefault();
			const $button = $(this);
			const $result = $('#wp-mcp-ai-yahoo-test-result');
			const clientId = $('input[name="wp_mcp_ai_settings[yahoo_client_id]"]').val();
			const clientSecret = $('input[name="wp_mcp_ai_settings[yahoo_client_secret]"]').val();

			if (!clientId || !clientSecret) {
				$result.html('<span style="color: #d63638;">Please enter both Client ID and Client Secret first.</span>');
				return;
			}

			$button.prop('disabled', true).text('Testing...');
			$result.html('<span style="color: #3c434a;">Validating Yahoo credentials...</span>');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_test_yahoo_connection',
					nonce: wpMcpAiAdmin.nonce,
					client_id: clientId,
					client_secret: clientSecret
				}
			}, {
				success: function (response) {
					if (response.success) {
						let message = '✓ ' + response.data.message;
						if (response.data.note) {
							message += '<br><small>' + response.data.note + '</small>';
						}
						$result.html('<span style="color: #00a32a;">' + message + '</span>');
					} else {
						$result.html('<span style="color: #d63638;">✗ ' + response.data.message + '</span>');
					}
				},
				error: function (error) {
					$result.html('<span style="color: #d63638;">✗ ' + (error.userMessage || 'Connection test failed') + '</span>');
				},
				complete: function () {
					$button.prop('disabled', false).text('Test Connection');
				}
			});
		});
	}

	/**
	 * Initialize Remove.bg connection test handlers.
	 */
	function initRemovebgHandlers() {
		// Test remove.bg connection
		$('#wp-mcp-ai-test-removebg-connection').on('click', function (e) {
			e.preventDefault();
			const $button = $(this);
			const $result = $('#wp-mcp-ai-removebg-test-result');
			const apiKey = $('input[name="wp_mcp_ai_settings[removebg_api_key]"]').val();

			if (!apiKey) {
				$result.html('<span style="color: #d63638;">Please enter an API key first.</span>');
				return;
			}

			$button.prop('disabled', true).text('Testing...');
			$result.html('<span style="color: #3c434a;">Connecting to remove.bg...</span>');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_test_removebg_connection',
					nonce: wpMcpAiAdmin.nonce,
					api_key: apiKey
				}
			}, {
				success: function (response) {
					if (response.success) {
						$result.html('<span style="color: #00a32a;">✓ ' + response.data.message + '</span>');
					} else {
						$result.html('<span style="color: #d63638;">✗ ' + response.data.message + '</span>');
					}
				},
				error: function (error) {
					$result.html('<span style="color: #d63638;">✗ ' + (error.userMessage || 'Connection failed') + '</span>');
				},
				complete: function () {
					$button.prop('disabled', false).text('Test Connection');
				}
			});
		});
	}

	/**
	 * Initialize Cloudflare connection test handlers.
	 */
	function initCloudflareHandlers() {
		$('#wp-mcp-ai-test-cloudflare-connection').on('click', function (e) {
			e.preventDefault();
			const $button = $(this);
			const $result = $('#wp-mcp-ai-cloudflare-test-result');
			const $zoneInfo = $('#wp-mcp-ai-cloudflare-zone-info');
			const zoneId = $('input[name="wp_mcp_ai_settings[cloudflare_zone_id]"]').val();
			const apiToken = $('input[name="wp_mcp_ai_settings[cloudflare_api_token]"]').val();

			if (!zoneId || !apiToken) {
				$result.html('<span style="color: #d63638;">Please enter both Zone ID and API Token first.</span>');
				return;
			}

			$button.prop('disabled', true).text('Testing...');
			$result.html('<span style="color: #3c434a;">Connecting to Cloudflare...</span>');
			$zoneInfo.html('');

			$.wpMcpAiAjax({
				url: wpMcpAiAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_test_cloudflare_connection',
					nonce: wpMcpAiAdmin.nonce,
					zone_id: zoneId,
					api_token: apiToken
				}
			}, {
				success: function (response) {
					if (response.success) {
						$result.html('<span style="color: #00a32a;">✓ ' + response.data.message + '</span>');
						if (response.data.zone_info) {
							const zoneData = response.data.zone_info;
							let html = '<div style="background: #f0f0f1; padding: 10px; border-radius: 4px; margin-top: 10px;">';
							html += '<p style="margin: 0 0 5px 0;"><strong>Zone Information:</strong></p>';
							html += '<ul style="margin: 0; padding-left: 20px;">';
							if (zoneData.name) {
								html += '<li><strong>Domain:</strong> ' + zoneData.name + '</li>';
							}
							if (zoneData.status) {
								html += '<li><strong>Status:</strong> ' + zoneData.status + '</li>';
							}
							if (zoneData.plan) {
								html += '<li><strong>Plan:</strong> ' + zoneData.plan + '</li>';
							}
							html += '</ul></div>';
							$zoneInfo.html(html);
						}
					} else {
						$result.html('<span style="color: #d63638;">✗ ' + response.data.message + '</span>');
						$zoneInfo.html('');
					}
				},
				error: function (error) {
					$result.html('<span style="color: #d63638;">✗ ' + (error.userMessage || 'Connection failed') + '</span>');
					$zoneInfo.html('');
				},
				complete: function () {
					$button.prop('disabled', false).text('Test Connection');
				}
			});
		});
	}

	/**
	 * Initialize Cloudways connection test handlers.
	 */
	function initCloudwaysHandlers() {
		// Test Cloudways connection
		$('#wp-mcp-ai-test-cloudways-connection').on('click', function (e) {
			e.preventDefault();
			const $button = $(this);
			const $result = $('#wp-mcp-ai-cloudways-test-result');
			const $accountInfo = $('#wp-mcp-ai-cloudways-account-info');
			const email = $('input[name="wp_mcp_ai_settings[cloudways_email]"]').val();
			const apiKey = $('input[name="wp_mcp_ai_settings[cloudways_api_key]"]').val();

			if (!email || !apiKey) {
				$result.html('<span style="color: #d63638;">Please enter both email and API key first.</span>');
				return;
			}

			$button.prop('disabled', true).text('Testing...');
			$result.html('<span style="color: #3c434a;">Connecting to Cloudways...</span>');
			$accountInfo.html('');

			$.wpMcpAiAjax({
				url: wpMcpAiAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_test_cloudways_connection',
					nonce: wpMcpAiAdmin.nonce,
					email: email,
					api_key: apiKey
				}
			}, {
				success: function (response) {
					if (response.success) {
						$result.html('<span style="color: #00a32a;">✓ ' + response.data.message + '</span>');
						if (response.data.account_info) {
							const accountData = response.data.account_info;
							let html = '<div style="background: #f0f0f1; padding: 10px; border-radius: 4px; margin-top: 10px;">';
							html += '<p style="margin: 0 0 5px 0;"><strong>Account Information:</strong></p>';
							html += '<ul style="margin: 0; padding-left: 20px;">';
							if (accountData.email) {
								html += '<li><strong>Email:</strong> ' + accountData.email + '</li>';
							}
							if (accountData.server_count !== undefined) {
								html += '<li><strong>Servers:</strong> ' + accountData.server_count + '</li>';
							}
							html += '</ul></div>';
							$accountInfo.html(html);
						}
					} else {
						$result.html('<span style="color: #d63638;">✗ ' + response.data.message + '</span>');
						$accountInfo.html('');
					}
				},
				error: function (error) {
					$result.html('<span style="color: #d63638;">✗ ' + (error.userMessage || 'Connection failed') + '</span>');
					$accountInfo.html('');
				},
				complete: function () {
					$button.prop('disabled', false).text('Test Connection');
				}
			});
		});

		// Existing fetch data handler
		$('#wp-mcp-ai-fetch-cloudways-data').on('click', function (e) {
			e.preventDefault();
			const $button = $(this);
			const $result = $('#wp-mcp-ai-cloudways-fetch-result');
			const $serversList = $('#wp-mcp-ai-cloudways-servers-list');
			const $appsList = $('#wp-mcp-ai-cloudways-apps-list');
			const email = $('input[name="wp_mcp_ai_settings[cloudways_email]"]').val();
			const apiKey = $('input[name="wp_mcp_ai_settings[cloudways_api_key]"]').val();

			if (!email || !apiKey) {
				$result.html('<span style="color: #d63638;">Please enter both email and API key first.</span>');
				return;
			}

			$button.prop('disabled', true).text('Fetching...');
			$result.html('<span style="color: #3c434a;">Connecting to Cloudways...</span>');
			$serversList.html('');
			$appsList.html('');

			$.wpMcpAiAjax({
				url: wpMcpAiAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_fetch_cloudways_data',
					nonce: wpMcpAiAdmin.nonce,
					email: email,
					api_key: apiKey
				}
			}, {
				success: function (response) {
					if (response.success) {
						$result.html('<span style="color: #00a32a;">✓ Successfully fetched Cloudways data</span>');
						
						// Display servers
						if (response.data.servers && response.data.servers.length > 0) {
							const $list = $('#wp-mcp-ai-cloudways-servers-list');
							$list.empty();
							const $title = $('<p><strong>Select a server:</strong></p>');
							const $ul = $('<ul style="list-style: disc; margin-left: 20px;"></ul>');
							response.data.servers.forEach(function (server) {
								const $li = $('<li style="margin-bottom: 5px;"></li>');
								const $link = $('<a href="#" class="wp-mcp-ai-select-cloudways-server"></a>');
								$link.attr('data-server-id', server.id);
								$link.text(server.label + ' (ID: ' + server.id + ', Status: ' + server.status + ')');
								$li.append($link);
								$ul.append($li);
							});
							$list.append($title).append($ul);
						}
						
						// Display apps
						if (response.data.apps && response.data.apps.length > 0) {
							const $list = $('#wp-mcp-ai-cloudways-apps-list');
							$list.empty();
							const $title = $('<p><strong>Select an application:</strong></p>');
							const $ul = $('<ul style="list-style: disc; margin-left: 20px;"></ul>');
							response.data.apps.forEach(function (app) {
								const $li = $('<li style="margin-bottom: 5px;"></li>');
								const $link = $('<a href="#" class="wp-mcp-ai-select-cloudways-app"></a>');
								$link.attr('data-app-id', app.id);
								$link.attr('data-server-id', app.server_id);
								$link.text(app.label + ' (ID: ' + app.id + ')');
								$li.append($link);
								$ul.append($li);
							});
							$list.append($title).append($ul);
						}
					} else {
						$result.html('<span style="color: #d63638;">✗ ' + response.data.message + '</span>');
					}
				},
				error: function (error) {
					$result.html('<span style="color: #d63638;">✗ ' + (error.userMessage || 'Failed to connect to Cloudways') + '</span>');
				},
				complete: function () {
					$button.prop('disabled', false).text('Fetch Cloudways Data');
				}
			});
		});
		
		// Handle server selection
		$(document).on('click', '.wp-mcp-ai-select-cloudways-server', function (e) {
			e.preventDefault();
			const serverId = $(this).data('server-id');
			$('input[name="wp_mcp_ai_settings[cloudways_server_id]"]').val(serverId);
			const $message = $('<p style="color: #00a32a; font-weight: bold;"></p>');
			$message.text('Selected Server ID: ' + serverId);
			$('#wp-mcp-ai-cloudways-servers-list').prepend($message);
		});
		
		// Handle app selection
		$(document).on('click', '.wp-mcp-ai-select-cloudways-app', function (e) {
			e.preventDefault();
			const appId = $(this).data('app-id');
			const serverId = $(this).data('server-id');
			$('input[name="wp_mcp_ai_settings[cloudways_app_id]"]').val(appId);
			$('input[name="wp_mcp_ai_settings[cloudways_server_id]"]').val(serverId);
			const $message = $('<p style="color: #00a32a; font-weight: bold;"></p>');
			$message.text('Selected App ID: ' + appId + ' (Server ID: ' + serverId + ')');
			$('#wp-mcp-ai-cloudways-apps-list').prepend($message);
		});
	}

	/**
	 * Initialize iSAMS connection test handlers.
	 */
	function initISAMSHandlers() {
		// Test iSAMS connection
		$('#wp-mcp-ai-test-isams-connection').on('click', function (e) {
			e.preventDefault();
			const $button = $(this);
			const $result = $('#wp-mcp-ai-isams-test-result');
			const apiUrl = $('input[name="wp_mcp_ai_settings[isams_api_url]"]').val();
			const apiKey = $('input[name="wp_mcp_ai_settings[isams_api_key]"]').val();
			const apiSecret = $('input[name="wp_mcp_ai_settings[isams_api_secret]"]').val();

			if (!apiUrl || !apiKey || !apiSecret) {
				$result.html('<span style="color: #d63638;">Please enter all credentials (URL, API Key, and API Secret) first.</span>');
				return;
			}

			$button.prop('disabled', true).text('Testing...');
			$result.html('<span style="color: #3c434a;">Connecting to iSAMS...</span>');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_test_isams_connection',
					nonce: wpMcpAiAdmin.nonce,
					api_url: apiUrl,
					api_key: apiKey,
					api_secret: apiSecret
				}
			}, {
				success: function (response) {
					if (response.success) {
						$result.html('<span style="color: #00a32a;">✓ ' + response.data.message + '</span>');
					} else {
						$result.html('<span style="color: #d63638;">✗ ' + response.data.message + '</span>');
					}
				},
				error: function (error) {
					$result.html('<span style="color: #d63638;">✗ ' + (error.userMessage || 'Connection failed') + '</span>');
				},
				complete: function () {
					$button.prop('disabled', false).text('Test Connection');
				}
			});
		});
	}

	/**
	 * Initialize Mubert connection test handlers.
	 */
	function initMubertHandlers() {
		// Test Mubert connection
		$('#wp-mcp-ai-test-mubert-connection').on('click', function (e) {
			e.preventDefault();
			const $button = $(this);
			const $result = $('#wp-mcp-ai-mubert-test-result');
			const apiKey = $('input[name="wp_mcp_ai_settings[mubert_api_key]"]').val();

			if (!apiKey) {
				$result.html('<span style="color: #d63638;">Please enter an API key first.</span>');
				return;
			}

			$button.prop('disabled', true).text('Testing...');
			$result.html('<span style="color: #3c434a;">Connecting to Mubert...</span>');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_test_mubert_connection',
					nonce: wpMcpAiAdmin.nonce,
					api_key: apiKey
				}
			}, {
				success: function (response) {
					if (response.success) {
						$result.html('<span style="color: #00a32a;">✓ ' + response.data.message + '</span>');
					} else {
						$result.html('<span style="color: #d63638;">✗ ' + response.data.message + '</span>');
					}
				},
				error: function (error) {
					$result.html('<span style="color: #d63638;">✗ ' + (error.userMessage || 'Connection failed') + '</span>');
				},
				complete: function () {
					$button.prop('disabled', false).text('Test Connection');
				}
			});
		});
	}

	/**
	 * Initialize Flowhub connection test handlers.
	 */
	function initFlowhubHandlers() {
		// Test Flowhub connection
		$('#wp-mcp-ai-test-flowhub-connection').on('click', function (e) {
			e.preventDefault();
			const $button = $(this);
			const $result = $('#wp-mcp-ai-flowhub-test-result');
			const apiKey = $('input[name="wp_mcp_ai_settings[flowhub_api_key]"]').val();
			const clientId = $('input[name="wp_mcp_ai_settings[flowhub_client_id]"]').val();
			const clientSecret = $('input[name="wp_mcp_ai_settings[flowhub_client_secret]"]').val();
			const locationId = $('input[name="wp_mcp_ai_settings[flowhub_location_id]"]').val();

			if (!apiKey || !clientId || !clientSecret || !locationId) {
				$result.html('<span style="color: #d63638;">Please enter all Flowhub credentials first.</span>');
				return;
			}

			$button.prop('disabled', true).text('Testing...');
			$result.html('<span style="color: #3c434a;">Connecting to Flowhub...</span>');

			// Use the error service for consistent error handling
			$.wpMcpAiAjax({
				url: wpMcpAiAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'wp_mcp_ai_test_flowhub_connection',
					nonce: wpMcpAiAdmin.nonce,
					api_key: apiKey,
					client_id: clientId,
					client_secret: clientSecret,
					location_id: locationId
				}
			}, {
				success: function (response) {
					if (response.success) {
						$result.html('<span style="color: #00a32a;">✓ ' + response.data.message + '</span>');
					} else {
						$result.html('<span style="color: #d63638;">✗ ' + response.data.message + '</span>');
					}
				},
				error: function (error) {
					$result.html('<span style="color: #d63638;">✗ ' + (error.userMessage || 'Connection failed') + '</span>');
				},
				complete: function () {
					$button.prop('disabled', false).text('Test Connection');
				}
			});
		});
	}

	// Initialize when DOM is ready.
	$(document).ready(function() {
		// eslint-disable-next-line camelcase
		WP_MCP_AI_Dashboard.init();
		
		// Initialize connection test handlers if wpMcpAiAdmin is available
		if (typeof wpMcpAiAdmin !== 'undefined') {
			initBraveSearchHandlers();
			initYahooHandlers();
			initRemovebgHandlers();
			initMubertHandlers();
			initFlowhubHandlers();
			initCloudflareHandlers();
			initCloudwaysHandlers();
			initISAMSHandlers();
			initChatClientPresetsHandlers();
		}
	});

	/**
	 * Initialize Chat Client preset handlers
	 */
	function initChatClientPresetsHandlers() {
		// Handle preset application
		jQuery('.wp-mcp-ai-apply-preset').on('click', function (e) {
			e.preventDefault();
			const preset = jQuery(this).data('preset');
			const presetSettings = getChatClientPresetSettings(preset);

			if (!presetSettings) {
				return;
			}

			// Apply the preset settings to form fields
			Object.keys(presetSettings).forEach(function (fieldName) {
				const fieldValue = presetSettings[fieldName];
				const $field = jQuery('[name="wp_mcp_ai_settings[' + fieldName + ']"]');

				if ($field.length) {
					if ($field.attr('type') === 'checkbox') {
						$field.prop('checked', fieldValue);
					} else {
						$field.val(fieldValue);
					}
				}
			});

			// Show confirmation notice
			jQuery('.wp-mcp-ai-preset-notice').slideDown();

			// Scroll to top
			jQuery('html, body').animate({
				scrollTop: jQuery('.wp-mcp-ai-chat-presets').offset().top - 100
			}, 500);

			// Auto-hide notice after 5 seconds
			setTimeout(function () {
				jQuery('.wp-mcp-ai-preset-notice').slideUp();
			}, 5000);
		});
	}

	/**
	 * Get preset settings for Chat Client
	 *
	 * @param {string} preset Preset name
	 * @return {Object|null} Preset settings object
	 */
	function getChatClientPresetSettings(preset) {
		const presets = {
			minimal: {
				// Appearance
				chat_theme: 'light',
				chat_primary_color: '',
				chat_user_bubble_color: '',
				chat_assistant_bubble_color: '',
				chat_border_radius: 12,
				chat_font_size: 14,
				chat_show_timestamps: false,
				chat_show_avatars: false,
				chat_compact_mode: true,
				// Behavior
				chat_max_history_display: 30,
				chat_message_delay: 0,
				chat_enable_typing_indicator: true,
				chat_auto_scroll: true,
				chat_enable_markdown: true,
				chat_enable_code_highlighting: false,
				chat_persist_history: true,
				chat_welcome_message: '',
				chat_placeholder_text: '',
				chat_send_button_text: '',
				// Features
				chat_enable_copy_button: true,
				chat_enable_save_button: false,
				chat_enable_delete_button: false,
				chat_enable_speech_button: false,
				chat_enable_transcribe_button: false,
				chat_enable_file_upload: false,
				chat_enable_tool_shortcuts: false,
				chat_enable_search: false,
				chat_enable_export: false,
				chat_enable_regenerate: false,
				chat_allowed_file_types: '',
				chat_max_file_size_mb: 0,
				// LLM Sanitization
				chat_llm_sanitize_level: 'moderate',
				chat_llm_max_response_length: 0,
				chat_llm_show_3_results_buttons: false
			},
			full_featured: {
				// Appearance
				chat_theme: 'auto',
				chat_primary_color: '#0073aa',
				chat_user_bubble_color: '#E3F2FD',
				chat_assistant_bubble_color: '#F5F5F5',
				chat_border_radius: 12,
				chat_font_size: 14,
				chat_show_timestamps: true,
				chat_show_avatars: true,
				chat_compact_mode: false,
				// Behavior
				chat_max_history_display: 100,
				chat_message_delay: 300,
				chat_enable_typing_indicator: true,
				chat_auto_scroll: true,
				chat_enable_markdown: true,
				chat_enable_code_highlighting: true,
				chat_persist_history: true,
				chat_welcome_message: 'Hello! How can I help you today?',
				chat_placeholder_text: 'Type your message...',
				chat_send_button_text: 'Send',
				// Features
				chat_enable_copy_button: true,
				chat_enable_save_button: true,
				chat_enable_delete_button: true,
				chat_enable_speech_button: true,
				chat_enable_transcribe_button: true,
				chat_enable_file_upload: true,
				chat_enable_tool_shortcuts: true,
				chat_enable_search: true,
				chat_enable_export: true,
				chat_enable_regenerate: true,
				chat_allowed_file_types: 'jpg,png,pdf,docx,txt',
				chat_max_file_size_mb: 10,
				// LLM Sanitization
				chat_llm_sanitize_level: 'moderate',
				chat_llm_max_response_length: 0,
				chat_llm_show_3_results_buttons: true,
				chat_llm_result_button_1_label: 'Refine',
				chat_llm_result_button_1_prompt: 'Please refine your previous response: {original_response}',
				chat_llm_result_button_2_label: 'Alternative',
				chat_llm_result_button_2_prompt: 'Please provide an alternative approach to: {original_response}',
				chat_llm_result_button_3_label: 'Expand',
				chat_llm_result_button_3_prompt: 'Please expand on your previous response with more detail: {original_response}'
			},
			professional: {
				// Appearance
				chat_theme: 'light',
				chat_primary_color: '#2C3E50',
				chat_user_bubble_color: '#3498DB',
				chat_assistant_bubble_color: '#ECF0F1',
				chat_border_radius: 8,
				chat_font_size: 14,
				chat_show_timestamps: true,
				chat_show_avatars: true,
				chat_compact_mode: false,
				// Behavior
				chat_max_history_display: 75,
				chat_message_delay: 200,
				chat_enable_typing_indicator: true,
				chat_auto_scroll: true,
				chat_enable_markdown: true,
				chat_enable_code_highlighting: true,
				chat_persist_history: true,
				chat_welcome_message: 'Welcome to our professional assistant. How may I assist you?',
				chat_placeholder_text: 'Enter your message...',
				chat_send_button_text: 'Send',
				// Features
				chat_enable_copy_button: true,
				chat_enable_save_button: true,
				chat_enable_delete_button: true,
				chat_enable_speech_button: false,
				chat_enable_transcribe_button: false,
				chat_enable_file_upload: true,
				chat_enable_tool_shortcuts: false,
				chat_enable_search: true,
				chat_enable_export: true,
				chat_enable_regenerate: true,
				chat_allowed_file_types: 'pdf,docx,xlsx,txt,csv',
				chat_max_file_size_mb: 20,
				// LLM Sanitization
				chat_llm_sanitize_level: 'strict',
				chat_llm_max_response_length: 0,
				chat_llm_show_3_results_buttons: false
			},
			accessible: {
				// Appearance
				chat_theme: 'light',
				chat_primary_color: '#000000',
				chat_user_bubble_color: '#0066CC',
				chat_assistant_bubble_color: '#FFFFFF',
				chat_border_radius: 4,
				chat_font_size: 18,
				chat_show_timestamps: true,
				chat_show_avatars: true,
				chat_compact_mode: false,
				// Behavior
				chat_max_history_display: 50,
				chat_message_delay: 500,
				chat_enable_typing_indicator: true,
				chat_auto_scroll: true,
				chat_enable_markdown: true,
				chat_enable_code_highlighting: true,
				chat_persist_history: true,
				chat_welcome_message: 'Hello! I am here to help you. You can type or use voice input.',
				chat_placeholder_text: 'Type or speak your message...',
				chat_send_button_text: 'Send Message',
				// Features
				chat_enable_copy_button: true,
				chat_enable_save_button: true,
				chat_enable_delete_button: true,
				chat_enable_speech_button: true,
				chat_enable_transcribe_button: true,
				chat_enable_file_upload: true,
				chat_enable_tool_shortcuts: true,
				chat_enable_search: true,
				chat_enable_export: true,
				chat_enable_regenerate: true,
				chat_allowed_file_types: 'jpg,png,pdf,docx,txt',
				chat_max_file_size_mb: 10,
				// LLM Sanitization
				chat_llm_sanitize_level: 'moderate',
				chat_llm_max_response_length: 0,
				chat_llm_show_3_results_buttons: false
			}
		};

		return presets[preset] || null;
	}

	// Expose to global scope if needed.
	// eslint-disable-next-line camelcase
	window.WP_MCP_AI_Dashboard = WP_MCP_AI_Dashboard;

})(jQuery);
