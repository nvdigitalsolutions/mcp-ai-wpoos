<?php
/**
 * Privacy API Integration for GDPR Compliance
 *
 * Implements WordPress Privacy API for personal data export and erasure.
 * Handles chat transcripts, assistant credentials, user settings, and usage data.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Privacy API Integration Class
 *
 * Integrates with WordPress Privacy Tools to provide GDPR-compliant
 * data export and erasure functionality for NV oOS plugin data.
 */
class WP_MCP_AI_Privacy {

	/**
	 * Initialize privacy integration
	 */
	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register WordPress hooks
	 */
	private function register_hooks() {
		// Register privacy policy content.
		add_action( 'admin_init', array( $this, 'add_privacy_policy_content' ) );

		// Register personal data exporters.
		add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'register_exporters' ) );

		// Register personal data erasers.
		add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'register_erasers' ) );
	}

	/**
	 * Add privacy policy content suggestion
	 */
	public function add_privacy_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		// WP 6.9+ flags registrations outside wp-admin as incorrect usage
		// (and the PHPUnit context is never wp-admin). Privacy guide content
		// only ever renders in the admin, so skip gracefully elsewhere.
		if ( ! is_admin() ) {
			return;
		}

		$content = $this->get_privacy_policy_content();

		wp_add_privacy_policy_content(
			'NV Digital Open Operator System (NV oOS)',
			wp_kses_post( wpautop( $content, false ) )
		);
	}

	/**
	 * Get privacy policy content
	 *
	 * @return string Privacy policy content
	 */
	private function get_privacy_policy_content() {
		return __(
			'<h2>What Personal Data We Collect and Why</h2>

<h3>AI Assistant Interactions</h3>
<p>When you use our AI Assistant features, we collect:</p>
<ul>
<li><strong>Chat Transcripts:</strong> Messages you send to AI assistants are stored locally in your browser for 24 hours and optionally on our server if enabled.</li>
<li><strong>Usage Analytics:</strong> We track which assistants and tools you use to improve performance and user experience.</li>
<li><strong>Assistant Credentials:</strong> If you create custom AI assistants, we store associated API credentials securely.</li>
</ul>

<h3>AI Transparency & Labelling</h3>
<p>In compliance with the EU AI Act Article 50 and related regulations, we provide:</p>
<ul>
<li><strong>AI Disclosure:</strong> All AI-powered chat interfaces display a visible notice informing you that you are interacting with an artificial intelligence system.</li>
<li><strong>Consent:</strong> Before your first interaction, you are asked to acknowledge that responses are AI-generated.</li>
<li><strong>Provenance Headers:</strong> API responses from our AI chat endpoints include machine-readable headers (X-AI-Generated) identifying the content as AI-generated.</li>
<li><strong>Generation Logging:</strong> We maintain immutable, cryptographically verifiable records of AI interactions for compliance and audit purposes.</li>
</ul>

<h3>User Settings and Preferences</h3>
<p>We store your AI assistant preferences, including:</p>
<ul>
<li>Selected AI models and providers</li>
<li>Custom system prompts and configurations</li>
<li>Tool selections and permissions</li>
<li>AI consent preferences (whether you have acknowledged AI interactions)</li>
</ul>

<h3>How Long We Retain Your Data</h3>
<ul>
<li><strong>Chat Transcripts:</strong> Browser storage for 24 hours; server storage (if enabled) until manually deleted or account deletion.</li>
<li><strong>Generation Provenance Records:</strong> Retained for the configured period (default 365 days) for compliance auditing.</li>
<li><strong>Consent Records:</strong> Retained until you revoke consent or your account is deleted.</li>
<li><strong>Usage Analytics:</strong> Aggregated data retained for 90 days; individual records for 30 days.</li>
<li><strong>API Credentials:</strong> Retained until you delete them or your account is deleted.</li>
<li><strong>User Settings:</strong> Retained until you delete them or your account is deleted.</li>
</ul>

<h3>Where We Send Your Data</h3>
<p>Your chat messages and data may be sent to third-party AI providers you select:</p>
<ul>
<li><strong>OpenAI:</strong> If using OpenAI GPT models</li>
<li><strong>Google:</strong> If using Google Gemini models</li>
<li><strong>Anthropic:</strong> If using Claude models</li>
<li><strong>Local AI (Ollama):</strong> Data stays on your server if using local models</li>
</ul>
<p>Please review the privacy policies of these providers for information on how they handle your data. Note that your messages may be processed by these providers to generate AI responses.</p>

<h3>Your Data Rights</h3>
<p>You have the right to:</p>
<ul>
<li>Export all personal data we have collected, including generation provenance records associated with your account</li>
<li>Request erasure of your personal data, including chat transcripts and generation records</li>
<li>Object to processing of your personal data by AI systems</li>
<li>Restrict processing of your personal data</li>
<li>Withdraw consent for AI interactions at any time</li>
</ul>
<p>You can exercise these rights using the Privacy Tools in your WordPress admin area or by contacting the site administrator.</p>',
			'nvdigital-open-operator-system-oos'
		);
	}

	/**
	 * Register personal data exporters
	 *
	 * @param array $exporters Existing exporters.
	 * @return array Modified exporters array
	 */
	public function register_exporters( $exporters ) {
		$exporters['wp-mcp-ai-chat-transcripts'] = array(
			'exporter_friendly_name' => __( 'NV oOS Chat Transcripts', 'nvdigital-open-operator-system-oos' ),
			'callback'               => array( $this, 'export_chat_transcripts' ),
		);

		$exporters['wp-mcp-ai-assistant-credentials'] = array(
			'exporter_friendly_name' => __( 'NV oOS Assistant Credentials', 'nvdigital-open-operator-system-oos' ),
			'callback'               => array( $this, 'export_assistant_credentials' ),
		);

		$exporters['wp-mcp-ai-user-settings'] = array(
			'exporter_friendly_name' => __( 'NV oOS User Settings', 'nvdigital-open-operator-system-oos' ),
			'callback'               => array( $this, 'export_user_settings' ),
		);

		$exporters['wp-mcp-ai-usage-analytics'] = array(
			'exporter_friendly_name' => __( 'NV oOS Usage Analytics', 'nvdigital-open-operator-system-oos' ),
			'callback'               => array( $this, 'export_usage_analytics' ),
		);

		return $exporters;
	}

	/**
	 * Register personal data erasers
	 *
	 * @param array $erasers Existing erasers.
	 * @return array Modified erasers array
	 */
	public function register_erasers( $erasers ) {
		$erasers['wp-mcp-ai-chat-transcripts'] = array(
			'eraser_friendly_name' => __( 'NV oOS Chat Transcripts', 'nvdigital-open-operator-system-oos' ),
			'callback'             => array( $this, 'erase_chat_transcripts' ),
		);

		$erasers['wp-mcp-ai-assistant-credentials'] = array(
			'eraser_friendly_name' => __( 'NV oOS Assistant Credentials', 'nvdigital-open-operator-system-oos' ),
			'callback'             => array( $this, 'erase_assistant_credentials' ),
		);

		$erasers['wp-mcp-ai-user-settings'] = array(
			'eraser_friendly_name' => __( 'NV oOS User Settings', 'nvdigital-open-operator-system-oos' ),
			'callback'             => array( $this, 'erase_user_settings' ),
		);

		$erasers['wp-mcp-ai-usage-analytics'] = array(
			'eraser_friendly_name' => __( 'NV oOS Usage Analytics', 'nvdigital-open-operator-system-oos' ),
			'callback'             => array( $this, 'erase_usage_analytics' ),
		);

		return $erasers;
	}

	/**
	 * Export chat transcripts for user
	 *
	 * @param string $email_address User email address.
	 * @param int    $page Page number for pagination.
	 * @return array Export data response
	 */
	public function export_chat_transcripts( $email_address, $page = 1 ) {
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return array(
				'data' => array(),
				'done' => true,
			);
		}

		$data_to_export = array();

		// Check if JetEngine CCT integration is active for chat transcripts.
		if ( class_exists( 'Jet_Engine' ) && function_exists( 'jet_engine' ) ) {
			$transcripts = $this->get_jet_engine_chat_transcripts( $user->ID, $page );

			foreach ( $transcripts as $transcript ) {
				$data_to_export[] = array(
					'group_id'    => 'wp-mcp-ai-chat-transcripts',
					'group_label' => __( 'Chat Transcripts', 'nvdigital-open-operator-system-oos' ),
					'item_id'     => 'chat-transcript-' . $transcript['id'],
					'data'        => array(
						array(
							'name'  => __( 'Transcript ID', 'nvdigital-open-operator-system-oos' ),
							'value' => $transcript['id'],
						),
						array(
							'name'  => __( 'Assistant', 'nvdigital-open-operator-system-oos' ),
							'value' => $transcript['assistant_name'],
						),
						array(
							'name'  => __( 'Date', 'nvdigital-open-operator-system-oos' ),
							'value' => $transcript['date'],
						),
						array(
							'name'  => __( 'Messages', 'nvdigital-open-operator-system-oos' ),
							'value' => $transcript['messages'],
						),
					),
				);
			}
		}

		// Note: Browser localStorage transcripts cannot be exported server-side.
		// Users would need to use browser developer tools to access local storage data.

		return array(
			'data' => $data_to_export,
			'done' => true,
		);
	}

	/**
	 * Export assistant credentials for user
	 *
	 * @param string $email_address User email address.
	 * @param int    $page Page number for pagination.
	 * @return array Export data response
	 */
	public function export_assistant_credentials( $email_address, $page = 1 ) {
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return array(
				'data' => array(),
				'done' => true,
			);
		}

		$data_to_export = array();

		// Get assistants created by user.
		$args = array(
			'post_type'      => 'mcp_ai_assistant',
			'author'         => $user->ID,
			'posts_per_page' => 50,
			'paged'          => $page,
		);

		$assistants = get_posts( $args );

		foreach ( $assistants as $assistant ) {
			$credentials = get_post_meta( $assistant->ID, '_wp_mcp_ai_credentials', true );

			$data_to_export[] = array(
				'group_id'    => 'wp-mcp-ai-assistant-credentials',
				'group_label' => __( 'Assistant Credentials', 'nvdigital-open-operator-system-oos' ),
				'item_id'     => 'assistant-cred-' . $assistant->ID,
				'data'        => array(
					array(
						'name'  => __( 'Assistant Name', 'nvdigital-open-operator-system-oos' ),
						'value' => $assistant->post_title,
					),
					array(
						'name'  => __( 'Created Date', 'nvdigital-open-operator-system-oos' ),
						'value' => $assistant->post_date,
					),
					array(
						'name'  => __( 'Credential Type', 'nvdigital-open-operator-system-oos' ),
						'value' => ! empty( $credentials ) ? __( 'Active', 'nvdigital-open-operator-system-oos' ) : __( 'None', 'nvdigital-open-operator-system-oos' ),
					),
					array(
						'name'  => __( 'Note', 'nvdigital-open-operator-system-oos' ),
						'value' => __( 'Credential tokens are hashed and cannot be exported in plain text for security reasons.', 'nvdigital-open-operator-system-oos' ),
					),
				),
			);
		}

		return array(
			'data' => $data_to_export,
			'done' => count( $assistants ) < 50,
		);
	}

	/**
	 * Export user settings
	 *
	 * @param string $email_address User email address.
	 * @param int    $page Page number for pagination.
	 * @return array Export data response
	 */
	public function export_user_settings( $email_address, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Required by WordPress privacy callback signature.
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return array(
				'data' => array(),
				'done' => true,
			);
		}

		$data_to_export = array();

		// Get user meta related to MCP AI.
		$user_meta_keys = array(
			'wp_mcp_ai_default_assistant',
			'wp_mcp_ai_preferred_model',
			'wp_mcp_ai_ui_preferences',
			'wp_mcp_ai_tool_permissions',
		);

		$user_settings = array();
		foreach ( $user_meta_keys as $key ) {
			$value = get_user_meta( $user->ID, $key, true );
			if ( ! empty( $value ) ) {
				$user_settings[] = array(
					'name'  => $key,
					'value' => is_array( $value ) ? wp_json_encode( $value ) : $value,
				);
			}
		}

		if ( ! empty( $user_settings ) ) {
			$data_to_export[] = array(
				'group_id'    => 'wp-mcp-ai-user-settings',
				'group_label' => __( 'User Settings', 'nvdigital-open-operator-system-oos' ),
				'item_id'     => 'user-settings-' . $user->ID,
				'data'        => $user_settings,
			);
		}

		return array(
			'data' => $data_to_export,
			'done' => true,
		);
	}

	/**
	 * Export usage analytics
	 *
	 * @param string $email_address User email address.
	 * @param int    $page Page number for pagination.
	 * @return array Export data response
	 */
	public function export_usage_analytics( $email_address, $page = 1 ) {
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return array(
				'data' => array(),
				'done' => true,
			);
		}

		$data_to_export = array();

		// Get usage analytics if JetEngine CCT is available.
		if ( class_exists( 'Jet_Engine' ) && function_exists( 'jet_engine' ) ) {
			$analytics = $this->get_jet_engine_usage_analytics( $user->ID, $page );

			if ( ! empty( $analytics ) ) {
				$data_to_export[] = array(
					'group_id'    => 'wp-mcp-ai-usage-analytics',
					'group_label' => __( 'Usage Analytics', 'nvdigital-open-operator-system-oos' ),
					'item_id'     => 'usage-analytics-' . $user->ID,
					'data'        => $analytics,
				);
			}
		}

		return array(
			'data' => $data_to_export,
			'done' => true,
		);
	}

	/**
	 * Erase chat transcripts for user
	 *
	 * @param string $email_address User email address.
	 * @param int    $page Page number for pagination.
	 * @return array Erasure response
	 */
	public function erase_chat_transcripts( $email_address, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Required by WordPress privacy callback signature.
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return array(
				'items_removed'  => false,
				'items_retained' => false,
				'messages'       => array(),
				'done'           => true,
			);
		}

		$items_removed  = false;
		$items_retained = false;
		$messages       = array();

		// Delete JetEngine CCT chat transcripts if available.
		if ( class_exists( 'Jet_Engine' ) && function_exists( 'jet_engine' ) ) {
			$deleted = $this->delete_jet_engine_chat_transcripts( $user->ID );
			if ( $deleted > 0 ) {
				$items_removed = true;
				/* translators: %d: number of transcripts deleted */
				$messages[] = sprintf( __( 'Deleted %d chat transcripts.', 'nvdigital-open-operator-system-oos' ), $deleted );
			}
		}

		// Note about browser localStorage.
		$messages[] = __( 'Note: Chat transcripts stored in browser localStorage must be cleared by the user manually.', 'nvdigital-open-operator-system-oos' );

		return array(
			'items_removed'  => $items_removed,
			'items_retained' => $items_retained,
			'messages'       => $messages,
			'done'           => true,
		);
	}

	/**
	 * Erase assistant credentials for user
	 *
	 * @param string $email_address User email address.
	 * @param int    $page Page number for pagination.
	 * @return array Erasure response
	 */
	public function erase_assistant_credentials( $email_address, $page = 1 ) {
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return array(
				'items_removed'  => false,
				'items_retained' => false,
				'messages'       => array(),
				'done'           => true,
			);
		}

		$items_removed  = false;
		$items_retained = false;
		$messages       = array();

		// Get assistants created by user.
		$args = array(
			'post_type'      => 'mcp_ai_assistant',
			'author'         => $user->ID,
			'posts_per_page' => 50,
			'paged'          => $page,
			'fields'         => 'ids',
		);

		$assistant_ids = get_posts( $args );

		if ( ! empty( $assistant_ids ) ) {
			foreach ( $assistant_ids as $assistant_id ) {
				// Delete credential meta.
				delete_post_meta( $assistant_id, '_wp_mcp_ai_credentials' );
				delete_post_meta( $assistant_id, '_wp_mcp_ai_credential_hash' );
				$items_removed = true;
			}

			/* translators: %d: number of assistants updated */
			$messages[] = sprintf( __( 'Removed credentials from %d assistants.', 'nvdigital-open-operator-system-oos' ), count( $assistant_ids ) );
		}

		return array(
			'items_removed'  => $items_removed,
			'items_retained' => $items_retained,
			'messages'       => $messages,
			'done'           => count( $assistant_ids ) < 50,
		);
	}

	/**
	 * Erase user settings
	 *
	 * @param string $email_address User email address.
	 * @param int    $page Page number for pagination.
	 * @return array Erasure response
	 */
	public function erase_user_settings( $email_address, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Required by WordPress privacy callback signature.
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return array(
				'items_removed'  => false,
				'items_retained' => false,
				'messages'       => array(),
				'done'           => true,
			);
		}

		$items_removed = false;
		$messages      = array();

		// Delete user meta related to MCP AI.
		$user_meta_keys = array(
			'wp_mcp_ai_default_assistant',
			'wp_mcp_ai_preferred_model',
			'wp_mcp_ai_ui_preferences',
			'wp_mcp_ai_tool_permissions',
		);

		$deleted_count = 0;
		foreach ( $user_meta_keys as $key ) {
			if ( delete_user_meta( $user->ID, $key ) ) {
				++$deleted_count;
				$items_removed = true;
			}
		}

		if ( $deleted_count > 0 ) {
			/* translators: %d: number of settings deleted */
			$messages[] = sprintf( __( 'Deleted %d user settings.', 'nvdigital-open-operator-system-oos' ), $deleted_count );
		}

		return array(
			'items_removed'  => $items_removed,
			'items_retained' => false,
			'messages'       => $messages,
			'done'           => true,
		);
	}

	/**
	 * Erase usage analytics
	 *
	 * @param string $email_address User email address.
	 * @param int    $page Page number for pagination.
	 * @return array Erasure response
	 */
	public function erase_usage_analytics( $email_address, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Required by WordPress privacy callback signature.
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return array(
				'items_removed'  => false,
				'items_retained' => false,
				'messages'       => array(),
				'done'           => true,
			);
		}

		$items_removed = false;
		$messages      = array();

		// Delete usage analytics if JetEngine CCT is available.
		if ( class_exists( 'Jet_Engine' ) && function_exists( 'jet_engine' ) ) {
			$deleted = $this->delete_jet_engine_usage_analytics( $user->ID );
			if ( $deleted > 0 ) {
				$items_removed = true;
				/* translators: %d: number of analytics records deleted */
				$messages[] = sprintf( __( 'Deleted %d usage analytics records.', 'nvdigital-open-operator-system-oos' ), $deleted );
			}
		}

		return array(
			'items_removed'  => $items_removed,
			'items_retained' => false,
			'messages'       => $messages,
			'done'           => true,
		);
	}

	/**
	 * Get chat transcripts from JetEngine CCT
	 *
	 * @param int $user_id User ID.
	 * @param int $page Page number.
	 * @return array Chat transcripts
	 */
	private function get_jet_engine_chat_transcripts( $user_id, $page = 1 ) {
		if ( ! class_exists( 'WP_MCP_AI_JetEngine_CCT' ) ) {
			return array();
		}

			$handler = WP_MCP_AI_JetEngine_CCT::get_item_handler();
		if ( ! $handler ) {
			return array();
		}

			$limit  = 50;
			$offset = ( $page - 1 ) * $limit;

			// The JetEngine CCT structure uses WP_MCP_AI_JetEngine_CCT::SLUG.
						// It has standard fields like _ID, and custom fields defined in WP_MCP_AI_JetEngine_CCT.
			$items = $handler->query(
				array(
					'user_id' => $user_id,
				),
				$limit,
				$offset
			);

		if ( empty( $items ) || ! is_array( $items ) ) {
			return array();
		}

			$transcripts = array();
		foreach ( $items as $item ) {
			// Provide fallbacks in case properties are missing.
			$transcripts[] = array(
				'id'             => isset( $item['_ID'] ) ? $item['_ID'] : '',
				'assistant_name' => isset( $item['assistant_id'] ) ? get_the_title( $item['assistant_id'] ) : __( 'Unknown Assistant', 'nvdigital-open-operator-system-oos' ),
				'date'           => isset( $item['cct_created'] ) ? get_date_from_gmt( $item['cct_created'], get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) : '',
				'messages'       => isset( $item['messages'] ) ? wp_trim_words( wp_strip_all_tags( $item['messages'] ), 50 ) : '',
			);
		}

			return $transcripts;
	}

	/**
	 * Get usage analytics from JetEngine CCT
	 *
	 * @param int $user_id User ID.
	 * @param int $page Page number.
	 * @return array Usage analytics
	 */
	private function get_jet_engine_usage_analytics( $user_id, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Parameters reserved for future JetEngine integration.
		// Placeholder for JetEngine CCT integration.
		// Implementation depends on CCT structure.
		return array();
	}

	/**
	 * Delete chat transcripts from JetEngine CCT
	 *
	 * @param int $user_id User ID.
	 * @return int Number of items deleted
	 */
	private function delete_jet_engine_chat_transcripts( $user_id ) {
		if ( ! class_exists( 'WP_MCP_AI_JetEngine_CCT' ) ) {
			return 0;
		}

			$handler = WP_MCP_AI_JetEngine_CCT::get_item_handler();
		if ( ! $handler ) {
			return 0;
		}

			$items = $handler->query(
				array(
					'user_id' => $user_id,
				),
				-1 // Get all items.
			);

		if ( empty( $items ) || ! is_array( $items ) ) {
			return 0;
		}

			$deleted_count = 0;
		foreach ( $items as $item ) {
			if ( isset( $item['_ID'] ) ) {
				$deleted = $handler->delete_item( $item['_ID'] );
				if ( $deleted ) {
					++$deleted_count;
				}
			}
		}

			return $deleted_count;
	}

	/**
	 * Delete usage analytics from JetEngine CCT
	 *
	 * @param int $user_id User ID.
	 * @return int Number of items deleted
	 */
	private function delete_jet_engine_usage_analytics( $user_id ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Parameter reserved for future JetEngine integration.
		// Placeholder for JetEngine CCT integration.
		// Implementation depends on CCT structure.
		return 0;
	}
}
