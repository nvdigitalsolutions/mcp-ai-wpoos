<?php
/**
 * DietPi List Radarr Movies Tool
 *
 * @package WP_MCP_AI_Pro
 * @subpackage DietPi_Toolkit
 * @since 1.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_DietPi_List_Radarr_Movies' ) ) {
	/**
	 * Lists movies in Radarr via the Radarr API.
	 */
	class WP_MCP_AI_Tool_DietPi_List_Radarr_Movies extends WP_MCP_AI_Tool_DietPi_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {
		/**
		 * {@inheritdoc}
		 */
		public function get_slug() {
			return 'dietpi_list_radarr_movies';
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_name() {
			return __( 'List Radarr Movies', 'mcp-ai-wpoos-pro' );
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_description() {
			return __( 'List all movies in Radarr with status, quality profile, availability, and file info.', 'mcp-ai-wpoos-pro' );
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Listing movies already in Radarr with status, monitored state, and file info.', 'mcp-ai-wpoos-pro' ),
				'when_not_to_use' => __( 'Adding a new movie; use dietpi_add_radarr_movie. Changing existing entries; use dietpi_manage_radarr.', 'mcp-ai-wpoos-pro' ),
				'related_tools'   => array( 'dietpi_add_radarr_movie', 'dietpi_manage_radarr', 'dietpi_dashboard_summary' ),
			);
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				// Empty stdClass encodes as `{}`; an empty PHP array would encode
				// as `[]`, which strict providers (DeepSeek) reject.
				'properties' => new stdClass(),
			);
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_required_capability() {
			return 'edit_posts';
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_capability_flags() {
			return array_merge(
				parent::get_capability_flags(),
				array( 'read-only', 'cacheable' )
			);
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Execution context including user_id.
		 * @return array|WP_Error Tool results or error.
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			if ( ! $this->app_client()->is_app_configured( 'radarr' ) ) {
				return new WP_Error( 'wp_mcp_ai_radarr_not_configured', __( 'Radarr is not configured.', 'mcp-ai-wpoos-pro' ) );
			}
			$movies = $this->app_client()->get( 'radarr', '/api/v3/movie', array(), 20 );
			if ( is_wp_error( $movies ) ) {
				return $movies;
			}
			$out = array();
			if ( is_array( $movies ) ) {
				foreach ( $movies as $m ) {
					$out[] = array(
						'id'        => isset( $m['id'] ) ? (int) $m['id'] : 0,
						'title'     => isset( $m['title'] ) ? sanitize_text_field( $m['title'] ) : '',
						'tmdb_id'   => isset( $m['tmdbId'] ) ? (int) $m['tmdbId'] : 0,
						'imdb_id'   => isset( $m['imdbId'] ) ? sanitize_text_field( $m['imdbId'] ) : '',
						'year'      => isset( $m['year'] ) ? (int) $m['year'] : 0,
						'monitored' => ! empty( $m['monitored'] ),
						'status'    => isset( $m['status'] ) ? sanitize_text_field( $m['status'] ) : '',
						'has_file'  => isset( $m['hasFile'] ) ? (bool) $m['hasFile'] : false,
						'path'      => isset( $m['path'] ) ? sanitize_text_field( $m['path'] ) : '',
					);
				}
			}
			return $this->success(
				sprintf(
					/* translators: %d: number of movies */
					_n( 'Found %d movie.', 'Found %d movies.', count( $out ), 'mcp-ai-wpoos-pro' ),
					count( $out )
				),
				array( 'movies' => $out )
			);
		}
	}
}
