<?php
/**
 * Build Assistant Page.
 *
 * Admin page for building assistants with a tabbed interface.
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles the Build Assistant page in admin.
 */
class WP_MCP_AI_Build_Assistant_Page {
	/**
	 * Page hook suffix.
	 *
	 * @var string
	 */
	protected $page_hook;

	/**
	 * Initialize the page.
	 */
	public static function init() {
		$instance = new self();
		add_action( 'admin_menu', array( $instance, 'register_page' ) );
		add_action( 'admin_enqueue_scripts', array( $instance, 'enqueue_scripts' ) );
	}

	/**
	 * Register the admin page.
	 */
	public function register_page() {
		$this->page_hook = add_submenu_page(
			'edit.php?post_type=mcp_ai_assistant',
			__( 'Build Assistant', 'nvdigital-open-operator-system-oos' ),
			__( 'Build Assistant', 'nvdigital-open-operator-system-oos' ),
			'edit_posts',
			'wp-mcp-ai-build-assistant',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue scripts and styles for this page.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_scripts( $hook ) {
		// Check if we're on the Build Assistant page.
		if ( ! $this->is_build_assistant_page( $hook ) ) {
			return;
		}

		// Enqueue chat assets for the Prompt tab modal.
		$this->enqueue_chat_assets();

		wp_enqueue_style(
			'wp-mcp-ai-build-assistant',
			WP_MCP_AI_URL . 'assets/css/admin-build-assistant.css',
			array( 'wp-mcp-ai-chat' ),
			WP_MCP_AI_VERSION
		);

		wp_enqueue_script(
			'wp-mcp-ai-build-assistant',
			WP_MCP_AI_URL . 'assets/js/admin-build-assistant.js',
			array( 'jquery', 'wp-mcp-ai-chat' ),
			WP_MCP_AI_VERSION,
			true
		);

		// Enqueue blocks assets for the Prompt tab's enhanced components.
		wp_enqueue_style(
			'wp-mcp-ai-assistant-builder-blocks',
			WP_MCP_AI_URL . 'assets/css/blocks/assistant-builder-blocks.css',
			array(),
			WP_MCP_AI_VERSION
		);

		wp_enqueue_script(
			'wp-mcp-ai-assistant-builder-frontend',
			WP_MCP_AI_URL . 'assets/js/blocks/assistant-builder-blocks-frontend.js',
			array( 'jquery' ),
			WP_MCP_AI_VERSION,
			true
		);

		// Enqueue scripts for Manual and Prompt tabs (from the former modal).
		wp_localize_script(
			'wp-mcp-ai-build-assistant',
			'wpMcpAiCreateAssistant',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'wp_mcp_ai_create_assistant' ),
				'strings'     => array(
					'creating'          => __( 'Creating assistant...', 'nvdigital-open-operator-system-oos' ),
					'createAssistant'   => __( 'Create Assistant', 'nvdigital-open-operator-system-oos' ),
					'success'           => __( 'Assistant created successfully!', 'nvdigital-open-operator-system-oos' ),
					'error'             => __( 'Error creating assistant. Please try again.', 'nvdigital-open-operator-system-oos' ),
					'required'          => __( 'This field is required.', 'nvdigital-open-operator-system-oos' ),
					'maxProfessions'    => __( 'You can select up to 3 professions.', 'nvdigital-open-operator-system-oos' ),
					'maxRegions'        => __( 'You can select up to 2 regions.', 'nvdigital-open-operator-system-oos' ),
					'emptyConversation' => __( 'Please describe what kind of assistant you want to create before clicking Build.', 'nvdigital-open-operator-system-oos' ),
				),
				'professions' => $this->get_professions(),
				'regions'     => $this->get_regions(),
			)
		);
	}

	/**
	 * Enqueue chat interface assets.
	 * Provides chat functionality for the Build with AI modal.
	 *
	 * Uses the bundled chat-bundle.js which combines all chat-related services
	 * into a single optimized file, reducing HTTP requests from 9 files to 1 file.
	 */
	private function enqueue_chat_assets() {
		// Enqueue cron status styles (CSS only - JS is bundled).

		wp_enqueue_style(
			'wp-mcp-ai-cron-status',
			WP_MCP_AI_URL . 'assets/css/cron-status.css',
			array(),
			$this->get_asset_version( 'assets/css/cron-status.css' )
		);

		wp_enqueue_style(
			'wp-mcp-ai-chat',
			WP_MCP_AI_URL . 'assets/css/chat.css',
			array( 'wp-mcp-ai-cron-status' ),
			$this->get_asset_version( 'assets/css/chat.css' )
		);

		// Register bundled chat script (includes all services in a single file).
		// The chat-bundle.js is an entry point for esbuild with ES6 imports,.

		// so we must load the bundled output (chat-bundle.min.js) which is browser-compatible.
		wp_enqueue_script(
			'wp-mcp-ai-chat',
			WP_MCP_AI_URL . 'assets/js/chat-bundle.min.js',
			array(), // No dependencies - all services are bundled together.
			$this->get_asset_version( 'assets/js/chat-bundle.min.js' ),
			true
		);

		// Safety check: Ensure REST constants exist.
		$rest_namespace = defined( 'WP_MCP_AI_REST::REST_NAMESPACE' ) ? WP_MCP_AI_REST::REST_NAMESPACE : 'mcp-ai/v1';

		// Use the shortcode helper method for consistent async tool timeout calculation.
		$async_timeout_ms = class_exists( 'WP_MCP_AI_Shortcode' )
			? WP_MCP_AI_Shortcode::get_async_tool_timeout_ms()
			: 300000;

		wp_localize_script(
			'wp-mcp-ai-chat',
			'wpMcpAiChat',
			array(
				'restUrl'             => esc_url_raw( $this->normalise_rest_url( rest_url( $rest_namespace ) ) ),
				'uploadEndpoint'      => esc_url_raw( $this->normalise_rest_url( rest_url( 'wp/v2/media' ) ) ),
				'filesEndpoint'       => esc_url_raw( trailingslashit( $this->normalise_rest_url( rest_url( $rest_namespace . '/files' ) ) ) ),
				'toolsEndpoint'       => esc_url_raw( $this->normalise_rest_url( rest_url( $rest_namespace . '/tools' ) ) ),
				'transcriptsEndpoint' => esc_url_raw( $this->normalise_rest_url( rest_url( $rest_namespace . '/chat-transcripts' ) ) ),
				'historyPerPage'      => 20,
				'currentUserId'       => get_current_user_id(),
				'nonce'               => wp_create_nonce( 'wp_rest' ),
				'asyncToolTimeout'    => $async_timeout_ms,
				'strings'             => $this->get_chat_strings(),
			)
		);
	}

	/**
	 * Normalize REST URL.
	 *
	 * @param string $url REST URL to normalize.
	 * @return string Normalized URL.
	 */
	private function normalise_rest_url( $url ) {
		if ( class_exists( 'WP_MCP_AI_Request_Context' ) && method_exists( 'WP_MCP_AI_Request_Context', 'normalise_rest_url' ) ) {
			return WP_MCP_AI_Request_Context::normalise_rest_url( $url );
		}
		return $url;
	}

	/**
	 * Get asset version based on file modification time.
	 *
	 * @param string $relative_path Asset path relative to plugin root.
	 * @return string
	 */
	private function get_asset_version( $relative_path ) {
		$relative_path = ltrim( $relative_path, '/' );
		$absolute_path = WP_MCP_AI_PATH . $relative_path;

		if ( file_exists( $absolute_path ) ) {
			$modified = filemtime( $absolute_path );

			if ( $modified ) {
				return WP_MCP_AI_VERSION . '.' . $modified;
			}
		}

		return WP_MCP_AI_VERSION;
	}

	/**
	 * Get chat interface strings for localization.
	 *
	 * @return array
	 */
	private function get_chat_strings() {
		return array(
			'placeholder'                   => __( 'Describe the assistant you want to create…', 'nvdigital-open-operator-system-oos' ),
			'send'                          => __( 'Send', 'nvdigital-open-operator-system-oos' ),
			'bundlingMessages'              => __( 'Preparing to send…', 'nvdigital-open-operator-system-oos' ),
			'sending'                       => __( 'Sending message…', 'nvdigital-open-operator-system-oos' ),
			'waiting'                       => __( 'Waiting for the AI builder…', 'nvdigital-open-operator-system-oos' ),
			'error'                         => __( 'Something went wrong. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'missingAssistant'              => __( 'Builder assistant configuration was not found.', 'nvdigital-open-operator-system-oos' ),
			'notAuthorized'                 => __( 'You do not have permission to use the builder.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: tool name */
			'toolExecuting'                 => __( 'Running tool: %s', 'nvdigital-open-operator-system-oos' ),
			'toolSuccess'                   => __( 'Tool completed successfully.', 'nvdigital-open-operator-system-oos' ),
			'toolError'                     => __( 'The tool request failed.', 'nvdigital-open-operator-system-oos' ),
			'toolQueued'                    => __( 'Tool queued. Results will appear shortly.', 'nvdigital-open-operator-system-oos' ),
			'toolPolling'                   => __( 'Tool is processing…', 'nvdigital-open-operator-system-oos' ),
			'toolTimeout'                   => __( 'Tool timed out before completing.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: error message */
			'toolFailed'                    => __( 'Tool failed: %s', 'nvdigital-open-operator-system-oos' ),
			'speechToolSuccess'             => __( 'Speech audio saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'imageToolSuccess'              => __( 'Image saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: task description */
			'toolShortcutLabel'             => __( 'Insert task: %s', 'nvdigital-open-operator-system-oos' ),
			'emptyMessage'                  => __( 'Enter a description before sending.', 'nvdigital-open-operator-system-oos' ),
			'attachFile'                    => __( 'Attach file', 'nvdigital-open-operator-system-oos' ),
			'transcribe'                    => __( 'Transcribe', 'nvdigital-open-operator-system-oos' ),
			'transcribeAudio'               => __( 'Transcribe audio', 'nvdigital-open-operator-system-oos' ),
			'transcribing'                  => __( 'Transcribing audio…', 'nvdigital-open-operator-system-oos' ),
			'recording'                     => __( 'Recording… tap to stop.', 'nvdigital-open-operator-system-oos' ),
			'stopRecording'                 => __( 'Stop recording', 'nvdigital-open-operator-system-oos' ),
			'recordingError'                => __( 'Could not access your microphone. Please allow access or upload an audio file instead.', 'nvdigital-open-operator-system-oos' ),
			'transcriptionError'            => __( 'The transcription request failed. Please try again.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: audio filename */
			'transcriptionSuccess'          => __( 'Inserted transcription from "%s".', 'nvdigital-open-operator-system-oos' ),
			'transcriptionFileTooLarge'     => __( 'The selected audio file is too large. Please choose a file under 25MB.', 'nvdigital-open-operator-system-oos' ),
			'transcribeChooseSource'        => __( 'Press OK to record with your microphone, or Cancel to choose an audio file.', 'nvdigital-open-operator-system-oos' ),
			'attachmentsLabel'              => __( 'Attachments', 'nvdigital-open-operator-system-oos' ),
			'removeAttachment'              => __( 'Remove', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: filename */
			'uploadingFile'                 => __( 'Uploading "%s"…', 'nvdigital-open-operator-system-oos' ),
			'uploadError'                   => __( 'The file could not be uploaded. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'uploadInProgress'              => __( 'Please wait for uploads to finish before sending.', 'nvdigital-open-operator-system-oos' ),
			'downloadAttachment'            => __( 'Download attachment', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: filename */
			'unsupportedFileType'           => __( '"%s" is not a supported file type. Please choose a different file.', 'nvdigital-open-operator-system-oos' ),
			'unsupportedMultipleFiles'      => __( 'Some selected files are not supported. Please try different files.', 'nvdigital-open-operator-system-oos' ),
			'unsupportedFileLabel'          => __( 'This file', 'nvdigital-open-operator-system-oos' ),
			'expandTranscript'              => __( 'Expand conversation', 'nvdigital-open-operator-system-oos' ),
			'collapseTranscript'            => __( 'Collapse conversation', 'nvdigital-open-operator-system-oos' ),
			'newConversation'               => __( 'Start new conversation', 'nvdigital-open-operator-system-oos' ),
			'loadConversation'              => __( 'Load conversation', 'nvdigital-open-operator-system-oos' ),
			'jsonResponse'                  => __( 'JSON response', 'nvdigital-open-operator-system-oos' ),
			'historyToggleShow'             => __( 'Show previous conversations', 'nvdigital-open-operator-system-oos' ),
			'historyToggleHide'             => __( 'Hide previous conversations', 'nvdigital-open-operator-system-oos' ),
			'historyLoading'                => __( 'Loading conversations…', 'nvdigital-open-operator-system-oos' ),
			'historyEmpty'                  => __( 'No previous conversations yet.', 'nvdigital-open-operator-system-oos' ),
			'historyError'                  => __( 'Unable to load conversation history.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %d: number of messages */
			'historyMessageCount'           => __( '%d messages', 'nvdigital-open-operator-system-oos' ),
			'historySingleMessage'          => __( '1 message', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: conversation number */
			'historyPreviewFallback'        => __( 'Conversation %s', 'nvdigital-open-operator-system-oos' ),
			'historySessionLoading'         => __( 'Loading conversation…', 'nvdigital-open-operator-system-oos' ),
			'historySessionError'           => __( 'Unable to load this conversation. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'historyNoMessages'             => __( 'No messages were saved for this conversation.', 'nvdigital-open-operator-system-oos' ),
			'saveConversation'              => __( 'Save conversation', 'nvdigital-open-operator-system-oos' ),
			'savingConversation'            => __( 'Saving current conversation...', 'nvdigital-open-operator-system-oos' ),
			'conversationSaved'             => __( 'Conversation saved successfully.', 'nvdigital-open-operator-system-oos' ),
			'saveFailed'                    => __( 'Failed to save conversation. See console for details.', 'nvdigital-open-operator-system-oos' ),
			'saveFailedProceed'             => __( 'Failed to save conversation: ', 'nvdigital-open-operator-system-oos' ),
			'proceedAnyway'                 => __( 'Do you want to proceed anyway? Your current conversation will be lost.', 'nvdigital-open-operator-system-oos' ),
			'saveFailedKeepingConversation' => __( 'Conversation not cleared. You can try again later.', 'nvdigital-open-operator-system-oos' ),
			'noConversationToSave'          => __( 'No conversation to save. Start chatting first!', 'nvdigital-open-operator-system-oos' ),
			'saveSkipped'                   => __( 'Save not available for this conversation.', 'nvdigital-open-operator-system-oos' ),
			'confirmClearConversation'      => __( 'Start a new conversation? Your current conversation will be saved automatically.', 'nvdigital-open-operator-system-oos' ),
			'noConversationToExport'        => __( 'No conversation to export. Start chatting first!', 'nvdigital-open-operator-system-oos' ),
			'exportFormatPrompt'            => __( 'Choose export format:\n- json\n- markdown\n- text', 'nvdigital-open-operator-system-oos' ),
			'invalidExportFormat'           => __( 'Invalid format. Please choose json, markdown, or text.', 'nvdigital-open-operator-system-oos' ),
			'exportFailed'                  => __( 'Export failed: ', 'nvdigital-open-operator-system-oos' ),
			'exportSuccess'                 => __( 'Conversation exported successfully as ', 'nvdigital-open-operator-system-oos' ),
			'deleteConversation'            => __( 'Delete this conversation', 'nvdigital-open-operator-system-oos' ),
			'confirmDeleteConversation'     => __( 'Are you sure you want to delete this conversation? This action cannot be undone.', 'nvdigital-open-operator-system-oos' ),
			'veoVideoToolSuccess'           => __( 'Video generated successfully and saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'videoNotSupported'             => __( 'Your browser does not support video playback.', 'nvdigital-open-operator-system-oos' ),
			'downloadVideo'                 => __( 'Download video', 'nvdigital-open-operator-system-oos' ),
			'geminiImageToolSuccess'        => __( 'Gemini image saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'editGeminiImageToolSuccess'    => __( 'Gemini image edited and saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'roleLabels'                    => array(
				'assistant' => __( 'AI Builder', 'nvdigital-open-operator-system-oos' ),
				'user'      => __( 'You', 'nvdigital-open-operator-system-oos' ),
				'system'    => __( 'System', 'nvdigital-open-operator-system-oos' ),
				'tool'      => __( 'Tool', 'nvdigital-open-operator-system-oos' ),
			),
		);
	}

	/**
	 * Check if we're on the Build Assistant page.
	 *
	 * @param string $hook Current admin page hook.
	 * @return bool True if on Build Assistant page, false otherwise.
	 */
	private function is_build_assistant_page( $hook ) {
		// Primary check: use page_hook property if available.
		if ( ! empty( $this->page_hook ) ) {
			return $hook === $this->page_hook;
		}

		// Fallback: check using get_current_screen() if available.
		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();
			if ( $screen && isset( $screen->id ) ) {
				// The screen ID for submenus is typically parent-page_page_menu-slug.
				// Check for exact match or if it ends with our page slug.
				return 'mcp_ai_assistant_page_wp-mcp-ai-build-assistant' === $screen->id
					|| false !== strpos( $screen->id, '_page_wp-mcp-ai-build-assistant' );
			}
		}

		// Last resort: check page query parameter (with sanitization).
		// This is a read-only check for admin page routing, not user input processing.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin page check.
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		return 'wp-mcp-ai-build-assistant' === $page;
	}

	/**
	 * Get the currently active tab.
	 *
	 * @return string Active tab ID.
	 */
	private function get_active_tab() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only query parameter check.
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'manual';

		$valid_tabs = array( 'manual', 'prompt', 'configuration', 'advanced' );
		if ( ! in_array( $tab, $valid_tabs, true ) ) {
			$tab = 'manual';
		}

		return $tab;
	}

	/**
	 * Get tab definitions.
	 *
	 * @return array
	 */
	private function get_tabs() {
		return array(
			'manual'        => array(
				'title' => __( 'Manual', 'nvdigital-open-operator-system-oos' ),
				'icon'  => 'dashicons-edit',
			),
			'prompt'        => array(
				'title' => __( 'Prompt', 'nvdigital-open-operator-system-oos' ),
				'icon'  => 'dashicons-format-chat',
			),
			'configuration' => array(
				'title' => __( 'Configuration', 'nvdigital-open-operator-system-oos' ),
				'icon'  => 'dashicons-admin-settings',
			),
			'advanced'      => array(
				'title' => __( 'Advanced', 'nvdigital-open-operator-system-oos' ),
				'icon'  => 'dashicons-admin-generic',
			),
		);
	}

	/**
	 * Render the page content.
	 */
	public function render_page() {
		$active_tab = $this->get_active_tab();
		$tabs       = $this->get_tabs();

		?>
		<div class="wrap wp-mcp-ai-build-assistant-page">
			<h1><?php esc_html_e( 'Build Assistant', 'nvdigital-open-operator-system-oos' ); ?></h1>
			<p class="description">
				<?php esc_html_e( 'Configure and build custom AI assistants with advanced settings and options.', 'nvdigital-open-operator-system-oos' ); ?>
			</p>

			<nav class="nav-tab-wrapper wp-clearfix" aria-label="<?php esc_attr_e( 'Build Assistant tabs', 'nvdigital-open-operator-system-oos' ); ?>">
				<?php foreach ( $tabs as $tab_id => $tab ) : ?>
					<?php
					$tab_url = add_query_arg(
						array(
							'post_type' => 'mcp_ai_assistant',
							'page'      => 'wp-mcp-ai-build-assistant',
							'tab'       => $tab_id,
						),
						admin_url( 'edit.php' )
					);
					$active  = ( $tab_id === $active_tab ) ? 'nav-tab-active' : '';
					?>
					<a href="<?php echo esc_url( $tab_url ); ?>" class="nav-tab <?php echo esc_attr( $active ); ?>">
						<span class="dashicons <?php echo esc_attr( $tab['icon'] ); ?>"></span>
						<?php echo esc_html( $tab['title'] ); ?>
					</a>
				<?php endforeach; ?>
			</nav>

			<div class="tab-content">
				<?php
				if ( 'manual' === $active_tab ) {
					$this->render_manual_tab();
				} elseif ( 'prompt' === $active_tab ) {
					$this->render_prompt_tab();
				} elseif ( 'configuration' === $active_tab ) {
					$this->render_configuration_tab();
				} elseif ( 'advanced' === $active_tab ) {
					$this->render_advanced_tab();
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the Manual tab content.
	 */
	private function render_manual_tab() {
		?>
		<div class="wp-mcp-ai-tab-content wp-mcp-ai-manual-tab">
			<div class="wp-mcp-ai-section">
				<h2><?php esc_html_e( 'Create Assistant Manually', 'nvdigital-open-operator-system-oos' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Fill in the form below to create a new AI assistant with custom settings.', 'nvdigital-open-operator-system-oos' ); ?></p>

				<form id="wp-mcp-ai-create-assistant-form" class="wp-mcp-ai-assistant-form">
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="assistant-title">
										<?php esc_html_e( 'Assistant Title', 'nvdigital-open-operator-system-oos' ); ?> <span class="required">*</span>
									</label>
								</th>
								<td>
									<input type="text" id="assistant-title" name="title" class="regular-text" required>
									<p class="description">
										<?php esc_html_e( 'E.g., "Jamaica Tax Assistant", "Sri Lanka Customs Broker - Perfumes"', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="assistant-professions">
										<?php esc_html_e( 'Professions', 'nvdigital-open-operator-system-oos' ); ?> <span class="required">*</span>
									</label>
								</th>
								<td>
									<select id="assistant-professions" name="professions[]" multiple class="regular-text" required style="height: 150px;">
										<?php foreach ( $this->get_professions() as $key => $label ) : ?>
											<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
										<?php endforeach; ?>
									</select>
									<p class="description">
										<?php esc_html_e( 'Select up to 3 professions. Hold Ctrl/Cmd to select multiple.', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="assistant-regions">
										<?php esc_html_e( 'Regions', 'nvdigital-open-operator-system-oos' ); ?> <span class="required">*</span>
									</label>
								</th>
								<td>
									<select id="assistant-regions" name="regions[]" multiple class="regular-text" required style="height: 150px;">
										<?php foreach ( $this->get_regions() as $key => $label ) : ?>
											<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
										<?php endforeach; ?>
									</select>
									<p class="description">
										<?php esc_html_e( 'Select up to 2 regions. Hold Ctrl/Cmd to select multiple.', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="assistant-industry">
										<?php esc_html_e( 'Industry Focus', 'nvdigital-open-operator-system-oos' ); ?>
									</label>
								</th>
								<td>
									<input type="text" id="assistant-industry" name="industry_focus" class="regular-text">
									<p class="description">
										<?php esc_html_e( 'Optional: E.g., "perfumes", "technology", "restaurants"', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="assistant-attachments">
										<?php esc_html_e( 'Knowledge Files', 'nvdigital-open-operator-system-oos' ); ?>
									</label>
								</th>
								<td>
									<input type="file" id="assistant-attachments" name="attachments[]" multiple accept=".txt,.md,.pdf,.doc,.docx">
									<p class="description">
										<?php esc_html_e( 'Optional: Upload files to include in the assistant\'s knowledge base (.txt, .md, .pdf, .doc, .docx)', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
									<ul id="assistant-attachments-list" class="wp-mcp-ai-attachments-list"></ul>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="assistant-provider">
										<?php esc_html_e( 'AI Provider', 'nvdigital-open-operator-system-oos' ); ?>
									</label>
								</th>
								<td>
									<select id="assistant-provider" name="provider" class="regular-text">
										<?php
										$available_providers = WP_MCP_AI_Admin_Settings::get_available_providers();
										$first               = true;
										foreach ( $available_providers as $provider_slug => $provider_label ) {
											?>
											<option value="<?php echo esc_attr( $provider_slug ); ?>"<?php echo $first ? ' selected' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML attribute. ?>><?php echo esc_html( $provider_label ); ?></option>
											<?php
											$first = false;
										}
										?>
									</select>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="assistant-model">
										<?php esc_html_e( 'Model', 'nvdigital-open-operator-system-oos' ); ?>
									</label>
								</th>
								<td>
									<input type="text" id="assistant-model" name="model" class="regular-text" value="gpt-4">
									<p class="description">
										<?php esc_html_e( 'E.g., "gpt-4", "gpt-4-turbo", "gemini-pro"', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="assistant-temperature">
										<?php esc_html_e( 'Temperature', 'nvdigital-open-operator-system-oos' ); ?>
									</label>
								</th>
								<td>
									<input type="number" id="assistant-temperature" name="temperature" class="small-text" min="0" max="2" step="0.1" value="0.7">
									<p class="description">
										<?php esc_html_e( '0-2. Lower is more deterministic, higher is more creative.', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="assistant-async">
										<input type="checkbox" id="assistant-async" name="async" value="1">
										<?php esc_html_e( 'Create in Background', 'nvdigital-open-operator-system-oos' ); ?>
									</label>
								</th>
								<td>
									<p class="description">
										<?php esc_html_e( 'For complex assistants, create asynchronously via cron. You will be notified when complete.', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
					<p class="submit">
						<button type="submit" class="button button-primary" id="wp-mcp-ai-submit-create">
							<?php esc_html_e( 'Create Assistant', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
					</p>
				</form>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the Prompt tab content.
	 */
	private function render_prompt_tab() {
		$builder_assistant_id = $this->get_builder_assistant_id();
		?>
		<div class="wp-mcp-ai-tab-content wp-mcp-ai-prompt-tab wp-mcp-ai-admin-blocks">
			<div class="wp-mcp-ai-section">
				<h2><?php esc_html_e( 'Build with AI Prompt', 'nvdigital-open-operator-system-oos' ); ?></h2>
				<div class="wp-mcp-ai-prompt-intro">
					<strong><?php esc_html_e( 'Describe your assistant', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<p><?php esc_html_e( 'Tell the AI what kind of assistant you want to create. Describe its purpose, expertise, target audience, and any specific capabilities. You can also upload files to include in its knowledge base and select tools for the assistant to use. When ready, click the "Build" button to create your assistant.', 'nvdigital-open-operator-system-oos' ); ?></p>
				</div>

				<?php
				// Render the Tools Grid component.
				$this->render_tools_grid_component();
				?>

				<?php
				// Render the Knowledge Base component.
				$this->render_knowledge_base_component();
				?>

				<div class="wp-mcp-ai-prompt-action">
					<?php if ( $builder_assistant_id ) : ?>
						<button
							type="button"
							class="button button-primary button-hero wp-mcp-ai-build-with-ai-btn"
							data-assistant-id="<?php echo esc_attr( $builder_assistant_id ); ?>"
							data-assistant-title="<?php esc_attr_e( 'AI Assistant Builder', 'nvdigital-open-operator-system-oos' ); ?>"
						>
							<span class="dashicons dashicons-format-chat"></span>
							<?php esc_html_e( 'Build with AI', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<p class="description"><?php esc_html_e( 'Click to open the AI chat interface and describe your assistant.', 'nvdigital-open-operator-system-oos' ); ?></p>
					<?php else : ?>
						<div class="wp-mcp-ai-no-builder">
							<p><?php esc_html_e( 'The Assistant Builder is not configured. Please create an assistant with the slug "assistant-builder" or set one in the plugin settings.', 'nvdigital-open-operator-system-oos' ); ?></p>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<!-- Modal container for Build with AI chat interface -->
		<div id="wp-mcp-ai-build-assistant-modal" class="wp-mcp-ai-test-modal" style="display: none;">
			<div class="wp-mcp-ai-test-modal__backdrop"></div>
			<div class="wp-mcp-ai-test-modal__panel">
				<div class="wp-mcp-ai-test-modal__header">
					<h2 id="wp-mcp-ai-build-assistant-modal__title"><?php esc_html_e( 'Build with AI', 'nvdigital-open-operator-system-oos' ); ?></h2>
					<button type="button" class="wp-mcp-ai-test-modal__close" aria-label="<?php esc_attr_e( 'Close', 'nvdigital-open-operator-system-oos' ); ?>">
						<span class="dashicons dashicons-no-alt"></span>
					</button>
				</div>
				<div class="wp-mcp-ai-test-modal__body">
					<!-- Chat interface will be initialized here -->
					<div id="wp-mcp-ai-build-assistant-chat-container"></div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the Tools Grid component for the Prompt tab.
	 *
	 * This includes the tools-grid block render template for use in the admin context.
	 */
	private function render_tools_grid_component() {
		$render_file = WP_MCP_AI_PATH . 'includes/blocks/tools-grid/render.php';

		// Verify the render file exists before including.
		if ( ! file_exists( $render_file ) ) {
			return;
		}

		// Set up attributes for the tools grid render.
		$attributes = array(
			'title'            => __( 'Tools Configuration', 'nvdigital-open-operator-system-oos' ),
			'description'      => __( 'Select the tools you want your assistant to be able to use.', 'nvdigital-open-operator-system-oos' ),
			'showDescriptions' => true,
			'startCollapsed'   => true,
			'showActions'      => true,
			'selectedTools'    => array(),
		);

		echo '<div class="wp-mcp-ai-prompt-tools-section">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
		include $render_file;
		echo '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
	}

	/**
	 * Render the Knowledge Base component for the Prompt tab.
	 *
	 * This includes the knowledge-base block render template for use in the admin context.
	 */
	private function render_knowledge_base_component() {
		// Check if user can upload files.
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}

		$render_file = WP_MCP_AI_PATH . 'includes/blocks/knowledge-base/render.php';

		// Verify the render file exists before including.
		if ( ! file_exists( $render_file ) ) {
			return;
		}

		// Set up attributes for the knowledge base render.
		$attributes = array(
			'title'         => __( 'Knowledge Base', 'nvdigital-open-operator-system-oos' ),
			'description'   => __( 'Upload files to include in the assistant\'s knowledge base. These files will be used to provide context to the AI.', 'nvdigital-open-operator-system-oos' ),
			'allowedTypes'  => '.pdf,.txt,.md,.doc,.docx,.csv,.json',
			'maxFiles'      => 10,
			'maxFileSizeMB' => 10,
			'showPreview'   => true,
		);

		echo '<div class="wp-mcp-ai-prompt-knowledge-section">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
		include $render_file;
		echo '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
	}

	/**
	 * Get the builder assistant ID for the Prompt tab.
	 *
	 * Looks for an assistant with the slug "assistant-builder" or uses a configured default.
	 *
	 * @return int Builder assistant ID or 0 if not found.
	 */
	private function get_builder_assistant_id() {
		// First, try to find an assistant with the slug "assistant-builder".
		$builder_assistant = get_page_by_path( 'assistant-builder', OBJECT, 'mcp_ai_assistant' );

		if ( $builder_assistant && 'publish' === $builder_assistant->post_status ) {
			return (int) $builder_assistant->ID;
		}

		// Fallback: Check plugin settings for a configured builder assistant.
		if ( class_exists( 'WP_MCP_AI_Admin_Settings' ) ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			if ( ! empty( $settings['builder_assistant'] ) ) {
				$builder_id = absint( $settings['builder_assistant'] );
				$post       = get_post( $builder_id );
				if ( $post && 'mcp_ai_assistant' === $post->post_type && 'publish' === $post->post_status ) {
					return $builder_id;
				}
			}
		}

		// Final fallback: Use the default assistant if available.
		if ( class_exists( 'WP_MCP_AI_Admin_Settings' ) ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			if ( ! empty( $settings['default_assistant'] ) ) {
				return absint( $settings['default_assistant'] );
			}
		}

		return 0;
	}

	/**
	 * Get profession options.
	 *
	 * Now integrates with profession CPT system.
	 * Falls back to hardcoded list for backward compatibility.
	 *
	 * @return array Profession key => label pairs.
	 */
	private function get_professions() {
		// Try to get professions from CPT system.
		if ( function_exists( 'wp_mcp_ai_get_profession_service' ) ) {
			$profession_service = wp_mcp_ai_get_profession_service();
			$professions        = $profession_service->get_professions_for_dropdown();

			// If we have professions from CPT, use them.
			if ( ! empty( $professions ) ) {
				return $professions;
			}
		}

		// Fallback to hardcoded list for backward compatibility.
		return array(
			'tax_advisor'              => __( 'Tax Advisor', 'nvdigital-open-operator-system-oos' ),
			'accountant'               => __( 'Accountant', 'nvdigital-open-operator-system-oos' ),
			'bookkeeper'               => __( 'Bookkeeper', 'nvdigital-open-operator-system-oos' ),
			'lawyer'                   => __( 'Lawyer', 'nvdigital-open-operator-system-oos' ),
			'legal_advisor'            => __( 'Legal Advisor', 'nvdigital-open-operator-system-oos' ),
			'customs_broker'           => __( 'Customs Broker', 'nvdigital-open-operator-system-oos' ),
			'import_export_specialist' => __( 'Import/Export Specialist', 'nvdigital-open-operator-system-oos' ),
			'financial_advisor'        => __( 'Financial Advisor', 'nvdigital-open-operator-system-oos' ),
			'business_consultant'      => __( 'Business Consultant', 'nvdigital-open-operator-system-oos' ),
			'real_estate_agent'        => __( 'Real Estate Agent', 'nvdigital-open-operator-system-oos' ),
			'healthcare_advisor'       => __( 'Healthcare Advisor', 'nvdigital-open-operator-system-oos' ),
			'marketing_consultant'     => __( 'Marketing Consultant', 'nvdigital-open-operator-system-oos' ),
			'hr_consultant'            => __( 'HR Consultant', 'nvdigital-open-operator-system-oos' ),
			'it_consultant'            => __( 'IT Consultant', 'nvdigital-open-operator-system-oos' ),
			'restaurant_consultant'    => __( 'Restaurant Consultant', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * Get region options.
	 *
	 * @return array Region key => label pairs.
	 */
	private function get_regions() {
		return array(
			'united_states'        => __( 'United States', 'nvdigital-open-operator-system-oos' ),
			'canada'               => __( 'Canada', 'nvdigital-open-operator-system-oos' ),
			'united_kingdom'       => __( 'United Kingdom', 'nvdigital-open-operator-system-oos' ),
			'australia'            => __( 'Australia', 'nvdigital-open-operator-system-oos' ),
			'jamaica'              => __( 'Jamaica', 'nvdigital-open-operator-system-oos' ),
			'sri_lanka'            => __( 'Sri Lanka', 'nvdigital-open-operator-system-oos' ),
			'india'                => __( 'India', 'nvdigital-open-operator-system-oos' ),
			'singapore'            => __( 'Singapore', 'nvdigital-open-operator-system-oos' ),
			'united_arab_emirates' => __( 'United Arab Emirates', 'nvdigital-open-operator-system-oos' ),
			'germany'              => __( 'Germany', 'nvdigital-open-operator-system-oos' ),
			'france'               => __( 'France', 'nvdigital-open-operator-system-oos' ),
			'spain'                => __( 'Spain', 'nvdigital-open-operator-system-oos' ),
			'italy'                => __( 'Italy', 'nvdigital-open-operator-system-oos' ),
			'netherlands'          => __( 'Netherlands', 'nvdigital-open-operator-system-oos' ),
			'brazil'               => __( 'Brazil', 'nvdigital-open-operator-system-oos' ),
			'mexico'               => __( 'Mexico', 'nvdigital-open-operator-system-oos' ),
			'south_africa'         => __( 'South Africa', 'nvdigital-open-operator-system-oos' ),
			'new_zealand'          => __( 'New Zealand', 'nvdigital-open-operator-system-oos' ),
			'ireland'              => __( 'Ireland', 'nvdigital-open-operator-system-oos' ),
			'japan'                => __( 'Japan', 'nvdigital-open-operator-system-oos' ),
			'china'                => __( 'China', 'nvdigital-open-operator-system-oos' ),
			'global'               => __( 'Global', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * Render the Configuration tab content.
	 */
	private function render_configuration_tab() {
		?>
		<div class="wp-mcp-ai-tab-content wp-mcp-ai-configuration-tab">
			<div class="wp-mcp-ai-section">
				<h2><?php esc_html_e( 'Assistant Configuration', 'nvdigital-open-operator-system-oos' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Configure the basic settings for your AI assistant.', 'nvdigital-open-operator-system-oos' ); ?></p>

				<div class="wp-mcp-ai-config-grid">
					<div class="wp-mcp-ai-config-card">
						<span class="dashicons dashicons-format-chat"></span>
						<h3><?php esc_html_e( 'Create from Template', 'nvdigital-open-operator-system-oos' ); ?></h3>
						<p><?php esc_html_e( 'Create a new assistant using a professional template with pre-configured settings.', 'nvdigital-open-operator-system-oos' ); ?></p>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_assistant&page=wp-mcp-ai-add-assistant' ) ); ?>" class="button button-primary">
							<?php esc_html_e( 'Use Template', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</div>

					<div class="wp-mcp-ai-config-card">
						<span class="dashicons dashicons-plus-alt"></span>
						<h3><?php esc_html_e( 'Create Custom', 'nvdigital-open-operator-system-oos' ); ?></h3>
						<p><?php esc_html_e( 'Create a new custom assistant from scratch with your own configuration.', 'nvdigital-open-operator-system-oos' ); ?></p>
						<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=mcp_ai_assistant' ) ); ?>" class="button button-secondary">
							<?php esc_html_e( 'Add New', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</div>

					<div class="wp-mcp-ai-config-card">
						<span class="dashicons dashicons-list-view"></span>
						<h3><?php esc_html_e( 'Manage Assistants', 'nvdigital-open-operator-system-oos' ); ?></h3>
						<p><?php esc_html_e( 'View and manage all existing AI assistants in your system.', 'nvdigital-open-operator-system-oos' ); ?></p>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_assistant' ) ); ?>" class="button button-secondary">
							<?php esc_html_e( 'View All', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</div>
				</div>
			</div>

			<div class="wp-mcp-ai-section">
				<h2><?php esc_html_e( 'Quick Statistics', 'nvdigital-open-operator-system-oos' ); ?></h2>
				<?php $this->render_assistant_stats(); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the Advanced tab content.
	 */
	private function render_advanced_tab() {
		?>
		<div class="wp-mcp-ai-tab-content wp-mcp-ai-advanced-tab">
			<div class="wp-mcp-ai-section">
				<h2><?php esc_html_e( 'Advanced Settings', 'nvdigital-open-operator-system-oos' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Advanced configuration options for power users.', 'nvdigital-open-operator-system-oos' ); ?></p>

				<div class="wp-mcp-ai-config-grid">
					<div class="wp-mcp-ai-config-card">
						<span class="dashicons dashicons-admin-users"></span>
						<h3><?php esc_html_e( 'Professional Templates', 'nvdigital-open-operator-system-oos' ); ?></h3>
						<p><?php esc_html_e( 'Manage professional templates that define roles, tools, and knowledge bases for assistants.', 'nvdigital-open-operator-system-oos' ); ?></p>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_profession' ) ); ?>" class="button button-secondary">
							<?php esc_html_e( 'Manage Templates', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</div>

					<div class="wp-mcp-ai-config-card">
						<span class="dashicons dashicons-groups"></span>
						<h3><?php esc_html_e( 'Teams', 'nvdigital-open-operator-system-oos' ); ?></h3>
						<p><?php esc_html_e( 'Create teams of assistants that can work together on complex tasks.', 'nvdigital-open-operator-system-oos' ); ?></p>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_team' ) ); ?>" class="button button-secondary">
							<?php esc_html_e( 'Manage Teams', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</div>

					<div class="wp-mcp-ai-config-card">
						<span class="dashicons dashicons-admin-tools"></span>
						<h3><?php esc_html_e( 'Tools & Features', 'nvdigital-open-operator-system-oos' ); ?></h3>
						<p><?php esc_html_e( 'Configure available tools and features that assistants can use.', 'nvdigital-open-operator-system-oos' ); ?></p>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=tools' ) ); ?>" class="button button-secondary">
							<?php esc_html_e( 'Configure Tools', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</div>

					<div class="wp-mcp-ai-config-card">
						<span class="dashicons dashicons-admin-generic"></span>
						<h3><?php esc_html_e( 'AI Providers', 'nvdigital-open-operator-system-oos' ); ?></h3>
						<p><?php esc_html_e( 'Configure API keys and settings for AI providers (OpenAI, Anthropic, Gemini, etc.).', 'nvdigital-open-operator-system-oos' ); ?></p>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=providers' ) ); ?>" class="button button-secondary">
							<?php esc_html_e( 'Configure Providers', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</div>
				</div>
			</div>

			<div class="wp-mcp-ai-section">
				<h2><?php esc_html_e( 'Documentation', 'nvdigital-open-operator-system-oos' ); ?></h2>
				<p class="description">
					<?php
					printf(
						/* translators: %s: URL to documentation */
						esc_html__( 'For detailed documentation on building and configuring assistants, visit the %s.', 'nvdigital-open-operator-system-oos' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=overview' ) ) . '">' . esc_html__( 'Overview page', 'nvdigital-open-operator-system-oos' ) . '</a>'
					);
					?>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render assistant statistics.
	 */
	private function render_assistant_stats() {
		$assistants_count  = wp_count_posts( 'mcp_ai_assistant' );
		$professions_count = wp_count_posts( 'mcp_ai_profession' );
		$teams_count       = wp_count_posts( 'mcp_ai_team' );

		$published_assistants  = isset( $assistants_count->publish ) ? $assistants_count->publish : 0;
		$published_professions = isset( $professions_count->publish ) ? $professions_count->publish : 0;
		$published_teams       = isset( $teams_count->publish ) ? $teams_count->publish : 0;
		?>
		<div class="wp-mcp-ai-stats-grid">
			<div class="wp-mcp-ai-stat-card">
				<span class="wp-mcp-ai-stat-number"><?php echo esc_html( $published_assistants ); ?></span>
				<span class="wp-mcp-ai-stat-label"><?php esc_html_e( 'Active Assistants', 'nvdigital-open-operator-system-oos' ); ?></span>
			</div>
			<div class="wp-mcp-ai-stat-card">
				<span class="wp-mcp-ai-stat-number"><?php echo esc_html( $published_professions ); ?></span>
				<span class="wp-mcp-ai-stat-label"><?php esc_html_e( 'Professional Templates', 'nvdigital-open-operator-system-oos' ); ?></span>
			</div>
			<div class="wp-mcp-ai-stat-card">
				<span class="wp-mcp-ai-stat-number"><?php echo esc_html( $published_teams ); ?></span>
				<span class="wp-mcp-ai-stat-label"><?php esc_html_e( 'Teams', 'nvdigital-open-operator-system-oos' ); ?></span>
			</div>
		</div>
		<?php
	}
}
