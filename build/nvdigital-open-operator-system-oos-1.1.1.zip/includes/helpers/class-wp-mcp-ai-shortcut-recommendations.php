<?php
/**
 * Shortcut Recommendations Helper.
 *
 * Provides industry-standard prompt shortcut recommendations for tools
 * that don't explicitly define their own shortcuts.
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Helper class for providing shortcut recommendations based on tool patterns.
 */
class WP_MCP_AI_Shortcut_Recommendations {

	/**
	 * Get recommended shortcuts for a tool based on its slug and metadata.
	 *
	 * @param WP_MCP_AI_Tool_Interface $tool Tool instance.
	 * @return array|null Array of shortcut recommendations or null if no recommendations.
	 */
	public static function get_recommendations_for_tool( $tool ) {
		if ( ! $tool || ! method_exists( $tool, 'get_slug' ) ) {
			return null;
		}

		$slug = $tool->get_slug();
		$name = method_exists( $tool, 'get_name' ) ? $tool->get_name() : $slug;

		// Check for pattern-based recommendations.
		$recommendations = self::get_pattern_based_recommendations( $slug, $name );

		if ( ! empty( $recommendations ) ) {
			return $recommendations;
		}

		// Return null to indicate no recommendations (allows fallback shortcuts).
		return null;
	}

	/**
	 * Get recommendations based on tool slug patterns.
	 *
	 * @param string $slug Tool slug.
	 * @param string $name Tool name.
	 * @return array Array of recommendations.
	 */
	protected static function get_pattern_based_recommendations( $slug, $name ) {
		$recommendations = array();

		// Content & Publishing Tools.
		if ( preg_match( '/^(get|search|list).*posts?$/i', $slug ) ) {
			$recommendations[] = array(
				/* translators: %s: tool name in lowercase */
				'label'       => sprintf( __( 'Show recent %s', 'nvdigital-open-operator-system-oos' ), strtolower( $name ) ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to retrieve and display recent content', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Quick access to latest published content', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Search Tools.
		if ( preg_match( '/^search/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => sprintf( __( 'Search for content', 'nvdigital-open-operator-system-oos' ) ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to find specific content. Ask what to search for, then execute the search.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Find specific content or data', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Create/Add Tools.
		if ( preg_match( '/^(create|add|new)/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => sprintf( __( 'Create new item', 'nvdigital-open-operator-system-oos' ) ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to create a new item. Gather required information, then execute creation.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Add new content or data', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Update/Edit Tools.
		if ( preg_match( '/^(update|edit|modify|save)/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => sprintf( __( 'Update existing item', 'nvdigital-open-operator-system-oos' ) ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to modify existing content. Identify what to update, then apply changes.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Modify existing content or settings', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Delete/Remove Tools.
		if ( preg_match( '/^(delete|remove)/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => sprintf( __( 'Delete item', 'nvdigital-open-operator-system-oos' ) ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to remove content. Confirm what to delete, then execute removal.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Remove content or data', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Image Generation Tools.
		if ( preg_match( '/generate.*image/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'Generate image', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to create an image. Gather description details, style preferences, and size requirements, then generate the image.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Create AI-generated images', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Image Editing Tools.
		if ( preg_match( '/(edit|modify).*image|image.*(edit|modify)/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'Edit image', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to modify an existing image. Specify what changes to make, then apply edits.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Modify or enhance images', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Video Tools.
		if ( preg_match( '/video/i', $slug ) ) {
			if ( preg_match( '/generate|create/i', $slug ) ) {
				$recommendations[] = array(
					'label'       => __( 'Generate video', 'nvdigital-open-operator-system-oos' ),
					/* translators: %s: tool slug */
					'payload'     => sprintf( __( 'Use the `%s` tool to create a video. Provide scene descriptions, duration, and style preferences.', 'nvdigital-open-operator-system-oos' ), $slug ),
					'description' => __( 'Create AI-generated videos', 'nvdigital-open-operator-system-oos' ),
				);
			} elseif ( preg_match( '/analyze|check|status/i', $slug ) ) {
				$recommendations[] = array(
					'label'       => __( 'Analyze video', 'nvdigital-open-operator-system-oos' ),
					/* translators: %s: tool slug */
					'payload'     => sprintf( __( 'Use the `%s` tool to analyze or check video status.', 'nvdigital-open-operator-system-oos' ), $slug ),
					'description' => __( 'Get video information or processing status', 'nvdigital-open-operator-system-oos' ),
				);
			}
		}

		// Email/Communication Tools.
		if ( preg_match( '/send.*(email|message)/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'Send message', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to send a communication. Gather recipient, subject, and message content.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Send emails or messages', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// WooCommerce/Product Tools.
		if ( preg_match( '/woo|product/i', $slug ) ) {
			if ( preg_match( '/order/i', $slug ) ) {
				$recommendations[] = array(
					'label'       => __( 'View orders', 'nvdigital-open-operator-system-oos' ),
					/* translators: %s: tool slug */
					'payload'     => sprintf( __( 'Use the `%s` tool to retrieve order information. Specify date range or other filters.', 'nvdigital-open-operator-system-oos' ), $slug ),
					'description' => __( 'Access e-commerce order data', 'nvdigital-open-operator-system-oos' ),
				);
			} elseif ( preg_match( '/product/i', $slug ) && preg_match( '/create|add/i', $slug ) ) {
				$recommendations[] = array(
					'label'       => __( 'Add product', 'nvdigital-open-operator-system-oos' ),
					/* translators: %s: tool slug */
					'payload'     => sprintf( __( 'Use the `%s` tool to create a new product. Gather name, description, price, and other details.', 'nvdigital-open-operator-system-oos' ), $slug ),
					'description' => __( 'Create new product listings', 'nvdigital-open-operator-system-oos' ),
				);
			} elseif ( preg_match( '/product/i', $slug ) ) {
				$recommendations[] = array(
					'label'       => __( 'List products', 'nvdigital-open-operator-system-oos' ),
					/* translators: %s: tool slug */
					'payload'     => sprintf( __( 'Use the `%s` tool to retrieve product information.', 'nvdigital-open-operator-system-oos' ), $slug ),
					'description' => __( 'Browse product catalog', 'nvdigital-open-operator-system-oos' ),
				);
			}
		}

		// Analytics/Reporting Tools.
		if ( preg_match( '/analytics|report|stats|insights/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'View analytics', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to retrieve analytics data. Specify date range and metrics.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Access performance metrics', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Chart/Visualization Tools.
		if ( preg_match( '/chart|visualiz/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'Create chart', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to create a data visualization. Provide data and specify chart type.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Generate visual representations of data', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Cache/Performance Tools.
		if ( preg_match( '/cache|purge|clear/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'Clear cache', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to clear cached data and improve performance.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Purge cache for fresh content', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// SEO Tools.
		if ( preg_match( '/seo|rankmath/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'SEO analysis', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to analyze SEO performance and get optimization recommendations.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Check search engine optimization', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Site Health/Status Tools.
		if ( preg_match( '/health|status|check/i', $slug ) && preg_match( '/site|system|environment/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'Check system status', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to check system health and identify any issues.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Monitor site health and performance', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Cron/Scheduled Job Tools.
		if ( preg_match( '/cron|schedule/i', $slug ) ) {
			if ( preg_match( '/create|add/i', $slug ) ) {
				$recommendations[] = array(
					'label'       => __( 'Schedule task', 'nvdigital-open-operator-system-oos' ),
					/* translators: %s: tool slug */
					'payload'     => sprintf( __( 'Use the `%s` tool to create a scheduled task. Specify timing and action.', 'nvdigital-open-operator-system-oos' ), $slug ),
					'description' => __( 'Set up automated tasks', 'nvdigital-open-operator-system-oos' ),
				);
			} elseif ( preg_match( '/list|get/i', $slug ) ) {
				$recommendations[] = array(
					'label'       => __( 'View scheduled tasks', 'nvdigital-open-operator-system-oos' ),
					/* translators: %s: tool slug */
					'payload'     => sprintf( __( 'Use the `%s` tool to list all scheduled tasks and their status.', 'nvdigital-open-operator-system-oos' ), $slug ),
					'description' => __( 'Check scheduled jobs', 'nvdigital-open-operator-system-oos' ),
				);
			}
		}

		// AI/ML Embedding Tools.
		if ( preg_match( '/embed|embedding/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'Generate embeddings', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to create vector embeddings for semantic analysis.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Create AI embeddings for content', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Moderation Tools.
		if ( preg_match( '/moderat|filter|check.*content/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'Moderate content', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to check content for policy violations or inappropriate material.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Content moderation and filtering', 'nvdigital-open-operator-system-oos' ),
			);
		}

		// Location/Places Tools.
		if ( preg_match( '/place|location|map|geo/i', $slug ) ) {
			$recommendations[] = array(
				'label'       => __( 'Find location', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: tool slug */
				'payload'     => sprintf( __( 'Use the `%s` tool to search for locations or places. Specify type and area.', 'nvdigital-open-operator-system-oos' ), $slug ),
				'description' => __( 'Search for places and locations', 'nvdigital-open-operator-system-oos' ),
			);
		}

		return $recommendations;
	}
}
