<?php
/**
 * Promotions REST controller.
 *
 * @package NvoosAstroBridge\REST
 */

namespace NvoosAstroBridge\REST;

use NvoosAstroBridge\Schema;
use NvoosAstroBridge\Transformers\PromotionTransformer;
use WP_Post;

/**
 * Handles /funiq/v1/promotions.
 */
class PromotionsController extends PostTypeController {

	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'funiq/v1';

	/**
	 * REST base path.
	 *
	 * @var string
	 */
	protected $rest_base = 'promotions';

	/**
	 * Get the post type slug.
	 *
	 * @return string
	 */
	protected function post_type(): string {
		return Schema::CPT_PROMOTION;
	}

	/**
	 * Transform a WP_Post into the output shape.
	 *
	 * @param WP_Post $post Post object.
	 * @return array<string, mixed>
	 */
	protected function transform( WP_Post $post ): array {
		return ( new PromotionTransformer() )->transform( $post );
	}

	/**
	 * Build post insert/update args from request data.
	 *
	 * @param array<string, mixed> $data Request body.
	 * @param int|null             $id   Post ID (null for create).
	 * @return array<string, mixed>
	 */
	protected function post_args( array $data, ?int $id ): array {
		$args = array(
			'post_type' => Schema::CPT_PROMOTION,
		);

		if ( null !== $id ) {
			$args['ID'] = $id;
		}

		if ( isset( $data['title'] ) ) {
			$args['post_title'] = sanitize_text_field( $data['title'] );
		}
		if ( isset( $data['description'] ) ) {
			$args['post_content'] = wp_kses_post( $data['description'] );
		}

		return $args;
	}

	/**
	 * Save meta fields after creating/updating the post.
	 *
	 * @param int                  $post_id Post ID.
	 * @param array<string, mixed> $data    Request body.
	 * @return void
	 */
	protected function save_meta( int $post_id, array $data ): void {
		$fields = array(
			Schema::META_PROMO_START_DATE => 'startDate',
			Schema::META_PROMO_END_DATE   => 'endDate',
			Schema::META_PROMO_ACTIVE     => 'active',
		);

		foreach ( $fields as $key => $field ) {
			if ( array_key_exists( $field, $data ) ) {
				$value = 'active' === $field ? (bool) $data[ $field ] : $data[ $field ];
				update_post_meta( $post_id, $key, $value );
			}
		}
	}
}
