<?php
/**
 * Pro Settings Page
 *
 * Displays system information including npm package versions and pro toolkit settings.
 * Read-only status display for monitoring active packages and dependencies.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Pro_Settings' ) ) {
	/**
	 * Pro Settings page for displaying system information.
	 *
	 * Provides a centralized view of:
	 * - NPM package versions (dependencies and devDependencies)
	 * - Pro toolkit configuration status
	 * - System information relevant to pro features
	 *
	 * @since 1.1.0
	 */
	class WP_MCP_AI_Pro_Settings {
		/**
		 * Parent page slug (Pro Dashboard).
		 */
		const PARENT_SLUG = 'nvoos-pro-dashboard';

		/**
		 * Pro Settings page slug.
		 */
		const PAGE_SLUG = 'nvoos-pro-settings';

		/**
		 * Get npm package information from package.json.
		 *
		 * Parses package.json to extract dependencies, devDependencies, and optionalDependencies.
		 * Now includes Pro addon packages as well.
		 * Lightweight approach that doesn't require npm CLI.
		 *
		 * @return array Array containing dependencies, devDependencies, and optionalDependencies.
		 */
		public static function get_npm_packages() {
			$package_json_path = WP_MCP_AI_PATH . 'package.json';
			$packages          = array(
				'dependencies'         => array(),
				'devDependencies'      => array(),
				'optionalDependencies' => array(),
				'error'                => null,
			);

			if ( ! file_exists( $package_json_path ) ) {
				$packages['error'] = 'package.json not found';
				return $packages;
			}

			$json_content = file_get_contents( $package_json_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; WP_Filesystem not available in this context.
			if ( false === $json_content ) {
				$packages['error'] = 'Unable to read package.json';
				return $packages;
			}

			$package_data = json_decode( $json_content, true );
			if ( null === $package_data ) {
				$packages['error'] = 'Invalid JSON in package.json';
				return $packages;
			}

			// Extract dependencies.
			if ( isset( $package_data['dependencies'] ) && is_array( $package_data['dependencies'] ) ) {
				$packages['dependencies'] = $package_data['dependencies'];
			}

			// Extract devDependencies.
			if ( isset( $package_data['devDependencies'] ) && is_array( $package_data['devDependencies'] ) ) {
				$packages['devDependencies'] = $package_data['devDependencies'];
			}

			// Extract optionalDependencies.
			if ( isset( $package_data['optionalDependencies'] ) && is_array( $package_data['optionalDependencies'] ) ) {
				$packages['optionalDependencies'] = $package_data['optionalDependencies'];
			}

			// Extract project metadata.
			$packages['name']    = isset( $package_data['name'] ) ? $package_data['name'] : 'unknown';
			$packages['version'] = isset( $package_data['version'] ) ? $package_data['version'] : 'unknown';

			// Merge in Pro addon packages if available.
			if ( defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				$pro_package_json_path = WP_MCP_AI_PRO_PATH . 'package.json';
				if ( file_exists( $pro_package_json_path ) ) {
					$pro_json_content = file_get_contents( $pro_package_json_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; WP_Filesystem not available in this context.
					if ( false !== $pro_json_content ) {
						$pro_package_data = json_decode( $pro_json_content, true );
						if ( null !== $pro_package_data ) {
							// Merge Pro dependencies.
							if ( isset( $pro_package_data['dependencies'] ) && is_array( $pro_package_data['dependencies'] ) ) {
								$packages['dependencies'] = array_merge( $packages['dependencies'], $pro_package_data['dependencies'] );
							}
							// Pro addon doesn't have devDependencies, but check anyway.
							if ( isset( $pro_package_data['devDependencies'] ) && is_array( $pro_package_data['devDependencies'] ) ) {
								$packages['devDependencies'] = array_merge( $packages['devDependencies'], $pro_package_data['devDependencies'] );
							}
							// Pro addon doesn't have optionalDependencies, but check anyway.
							if ( isset( $pro_package_data['optionalDependencies'] ) && is_array( $pro_package_data['optionalDependencies'] ) ) {
								$packages['optionalDependencies'] = array_merge( $packages['optionalDependencies'], $pro_package_data['optionalDependencies'] );
							}
						}
					}
				}
			}

			return $packages;
		}

		/**
		 * Get Composer package information from composer.json.
		 *
		 * Parses composer.json to extract require and require-dev dependencies.
		 * Lightweight approach that doesn't require Composer CLI.
		 *
		 * @return array Array containing require and require-dev dependencies.
		 */
		public static function get_composer_packages() {
			$composer_json_path = WP_MCP_AI_PATH . 'composer.json';
			$packages           = array(
				'require'     => array(),
				'require-dev' => array(),
				'error'       => null,
			);

			if ( ! file_exists( $composer_json_path ) ) {
				$packages['error'] = 'composer.json not found';
				return $packages;
			}

			$json_content = file_get_contents( $composer_json_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; WP_Filesystem not available in this context.
			if ( false === $json_content ) {
				$packages['error'] = 'Unable to read composer.json';
				return $packages;
			}

			$composer_data = json_decode( $json_content, true );
			if ( null === $composer_data ) {
				$packages['error'] = 'Invalid JSON in composer.json';
				return $packages;
			}

			// Extract require dependencies.
			if ( isset( $composer_data['require'] ) && is_array( $composer_data['require'] ) ) {
				$packages['require'] = $composer_data['require'];
			}

			// Extract require-dev dependencies.
			if ( isset( $composer_data['require-dev'] ) && is_array( $composer_data['require-dev'] ) ) {
				$packages['require-dev'] = $composer_data['require-dev'];
			}

			// Extract project metadata.
			$packages['name']        = isset( $composer_data['name'] ) ? $composer_data['name'] : 'unknown';
			$packages['description'] = isset( $composer_data['description'] ) ? $composer_data['description'] : '';
			$packages['type']        = isset( $composer_data['type'] ) ? $composer_data['type'] : 'unknown';

			// Extract platform requirements (php, ext-*, lib-*).
			if ( isset( $composer_data['config']['platform'] ) && is_array( $composer_data['config']['platform'] ) ) {
				// Add platform requirements to the require array so they display in the table.
				$packages['require'] = array_merge( $composer_data['config']['platform'], $packages['require'] );
			}

			// Merge in Pro addon packages if available.
			if ( defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				$pro_composer_json_path = WP_MCP_AI_PRO_PATH . 'composer.json';
				if ( file_exists( $pro_composer_json_path ) ) {
					$pro_json_content = file_get_contents( $pro_composer_json_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; WP_Filesystem not available in this context.
					if ( false !== $pro_json_content ) {
						$pro_composer_data = json_decode( $pro_json_content, true );
						if ( null !== $pro_composer_data ) {
							// Merge Pro require dependencies.
							// Note: If a package exists in both base and Pro with different versions,
							// the Pro version will override the base version (array_merge behavior).
							// This is intentional as Pro packages may require specific versions.
							if ( isset( $pro_composer_data['require'] ) && is_array( $pro_composer_data['require'] ) ) {
								$packages['require'] = array_merge( $packages['require'], $pro_composer_data['require'] );
							}
							// Merge Pro require-dev dependencies (if any).
							if ( isset( $pro_composer_data['require-dev'] ) && is_array( $pro_composer_data['require-dev'] ) ) {
								$packages['require-dev'] = array_merge( $packages['require-dev'], $pro_composer_data['require-dev'] );
							}
						}
					}
				}
			}

			return $packages;
		}

		/**
		 * Get individual pro toolkit status information.
		 *
		 * Returns enable/disable status of each individual pro toolkit.
		 *
		 * @return array Individual toolkit status information.
		 */
		public static function get_individual_toolkit_status() {
			$settings = get_option( 'wp_mcp_ai_settings', array() );

			$toolkits = array(
				'enable_media_toolkit'                   => __( 'Media Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_document_generation_toolkit'     => __( 'Document Generation Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_quiz_system'                     => __( 'Quiz System', 'nvdigital-open-operator-system-oos' ),
				'enable_project_management'              => __( 'Project Management', 'nvdigital-open-operator-system-oos' ),
				'enable_health_wellness_management'      => __( 'Health & Wellness Management', 'nvdigital-open-operator-system-oos' ),
				'enable_places_management'               => __( 'Places Management', 'nvdigital-open-operator-system-oos' ),
				'enable_eca_management'                  => __( 'ECA Management', 'nvdigital-open-operator-system-oos' ),
				'enable_crm_toolkit'                     => __( 'CRM & Email Marketing Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_ecommerce_toolkit'               => __( 'E-commerce Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_social_media_toolkit'            => __( 'Social Media Management Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_analytics_toolkit'               => __( 'Advanced Analytics Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_multilingual_toolkit'            => __( 'Multilingual Content Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_video_production_toolkit'        => __( 'Video Production Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_ai_tool_builder_toolkit'         => __( 'AI Tool Builder Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_architect_agent_toolkit'         => __( 'Architect Agent Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_architectural_design_toolkit'    => __( 'Architectural Design Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_calendar_booking_toolkit'        => __( 'Calendar Booking Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_chat_channels_toolkit'           => __( 'Chat Channels Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_dj_management_toolkit'           => __( 'DJ Management Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_financial_planner_toolkit'       => __( 'Financial Planner Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_image_production_toolkit'        => __( 'Image Production Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_regulatory_registration_toolkit' => __( 'Regulatory Registration Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_webchat_integration'             => __( 'WebChat Integration', 'nvdigital-open-operator-system-oos' ),
				'enable_woocommerce_tools'               => __( 'WooCommerce Tools', 'nvdigital-open-operator-system-oos' ),
				'enable_jetengine_tools'                 => __( 'JetEngine Tools', 'nvdigital-open-operator-system-oos' ),
				'enable_site_creator'                    => __( 'Site Creator', 'nvdigital-open-operator-system-oos' ),
				'enable_ai_cpt_management'               => __( 'AI CPT Management', 'nvdigital-open-operator-system-oos' ),
				'enable_fantasy_football'                => __( 'Fantasy Football Toolkit', 'nvdigital-open-operator-system-oos' ),
				'enable_healthcare_imaging'              => __( 'Healthcare Imaging Viewer', 'nvdigital-open-operator-system-oos' ),
			);

			$toolkit_status = array();
			foreach ( $toolkits as $setting_key => $toolkit_name ) {
				$toolkit_status[ $setting_key ] = array(
					'name'    => $toolkit_name,
					'enabled' => ! empty( $settings[ $setting_key ] ),
				);
			}

			return $toolkit_status;
		}

		/**
		 * Get PHP function requirements status grouped by system.
		 *
		 * Checks availability of PHP functions needed for Pro features.
		 * Functions are grouped by the system/feature that requires them.
		 *
		 * @return array PHP function status information grouped by system.
		 */
		public static function get_php_requirements_status() {
			// Systems and their required PHP functions.
			$systems = array(
				'process_service' => array(
					'name'        => __( 'Process Service & Node.js Integration', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Core service for external process execution, Node.js tools, and NPM package integration.', 'nvdigital-open-operator-system-oos' ),
					'functions'   => array( 'proc_open', 'proc_close', 'proc_terminate' ),
					'critical'    => true,
					'tools'       => array(
						__( 'All Node.js-based tools', 'nvdigital-open-operator-system-oos' ),
						__( 'NPM integration (Prettier, MJML, FFmpeg)', 'nvdigital-open-operator-system-oos' ),
						__( 'Image optimization (Sharp)', 'nvdigital-open-operator-system-oos' ),
						__( 'Video processing', 'nvdigital-open-operator-system-oos' ),
						__( 'Math equation rendering', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'wp_cli'          => array(
					'name'        => __( 'WP-CLI Integration', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Command-line interface for WordPress management and automation.', 'nvdigital-open-operator-system-oos' ),
					'functions'   => array( 'proc_open', 'proc_close' ),
					'critical'    => false,
					'tools'       => array(
						__( 'check_wp_cli tool', 'nvdigital-open-operator-system-oos' ),
						__( 'WP-CLI command execution', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'performance'     => array(
					'name'        => __( 'Performance Monitoring & Testing', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'PHPUnit test execution and performance benchmarking from admin interface.', 'nvdigital-open-operator-system-oos' ),
					'functions'   => array( 'exec' ),
					'critical'    => false,
					'tools'       => array(
						__( 'Performance monitoring dashboard', 'nvdigital-open-operator-system-oos' ),
						__( 'PHPUnit test runner', 'nvdigital-open-operator-system-oos' ),
						__( 'Benchmark tests', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'documents'       => array(
					'name'        => __( 'Document Generation', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Advanced PDF, Word, and Excel document generation with external libraries.', 'nvdigital-open-operator-system-oos' ),
					'functions'   => array( 'exec' ),
					'critical'    => false,
					'tools'       => array(
						__( 'generate_pdf_document tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_word_document tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_excel_document tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
			);

			// Check function availability.
			$results         = array();
			$all_critical_ok = true;

			foreach ( $systems as $system_id => $system ) {
				$system_functions = array();
				$all_available    = true;

				foreach ( $system['functions'] as $func_name ) {
					$available                      = function_exists( $func_name );
					$system_functions[ $func_name ] = array(
						'available' => $available,
						'name'      => $func_name,
					);

					if ( ! $available ) {
						$all_available = false;
						if ( $system['critical'] ) {
							$all_critical_ok = false;
						}
					}
				}

				$results[ $system_id ] = array(
					'name'          => $system['name'],
					'description'   => $system['description'],
					'functions'     => $system_functions,
					'tools'         => $system['tools'],
					'critical'      => $system['critical'],
					'all_available' => $all_available,
					'status'        => $all_available ? 'ok' : ( $system['critical'] ? 'critical' : 'warning' ),
				);
			}

			// Get disabled functions list.
			$disabled_functions = ini_get( 'disable_functions' );
			$disabled_list      = $disabled_functions ? array_map( 'trim', explode( ',', $disabled_functions ) ) : array();

			// Check if any systems have issues.
			$systems_with_issues = array_filter(
				$results,
				function ( $s ) {
					return ! $s['all_available'];
				}
			);
			$has_any_issues      = ! $all_critical_ok || count( $systems_with_issues ) > 0;

			return array(
				'systems'         => $results,
				'disabled_list'   => $disabled_list,
				'all_critical_ok' => $all_critical_ok,
				'has_any_issues'  => $has_any_issues,
			);
		}

		/**
		 * Get comprehensive toolkit details grouped by system.
		 *
		 * Returns detailed information about each toolkit including status,
		 * PHP requirements, NPM dependencies, tools count, and categorization.
		 *
		 * @return array Toolkit details grouped by system.
		 */
		public static function get_toolkit_details() {
			$settings = get_option( 'wp_mcp_ai_settings', array() );

			$toolkits = array(
				'media_toolkit'                   => array(
					'name'          => __( 'Media Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Image optimization, video processing, SVG vectorization, and math equation rendering.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_media_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array( 'proc_open', 'proc_close', 'proc_terminate' ),
					'npm_packages'  => array( 'sharp', 'fluent-ffmpeg', 'katex', '@neplex/vectorizer' ),
					'tools_count'   => 4,
					'tools'         => array(
						__( 'optimize_image tool', 'nvdigital-open-operator-system-oos' ),
						__( 'process_video tool', 'nvdigital-open-operator-system-oos' ),
						__( 'render_math_equation tool', 'nvdigital-open-operator-system-oos' ),
						__( 'vectorize_image tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'document_generation'             => array(
					'name'              => __( 'Document Generation Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'       => __( 'Advanced PDF, Word, and Excel document generation with external libraries.', 'nvdigital-open-operator-system-oos' ),
					'enabled'           => ! empty( $settings['enable_document_generation_toolkit'] ),
					'category'          => 'specialized',
					'php_functions'     => array( 'exec' ),
					'npm_packages'      => array( 'pdfkit', 'docx', 'exceljs', 'pdf-parse', 'qrcode' ),
					'composer_packages' => array( 'smalot/pdfparser' ),
					'tools_count'       => 3,
					'tools'             => array(
						__( 'generate_pdf_document tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_word_document tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_excel_document tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'project_management'              => array(
					'name'          => __( 'Project Management', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'ICS calendar file generation for project scheduling and event management.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_project_management'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'ics' ),
					'tools_count'   => 1,
					'tools'         => array(
						__( 'generate_ics_calendar tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'places_management'               => array(
					'name'          => __( 'Places Management', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Geographic data processing and spatial analysis with Turf.js.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_places_management'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( '@turf/turf' ),
					'tools_count'   => 1,
					'tools'         => array(
						__( 'process_geospatial_data tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'health_wellness_management'      => array(
					'name'          => __( 'Health & Wellness Management', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Health data visualization and chart generation with Chart.js.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_health_wellness_management'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'chart.js' ),
					'tools_count'   => 1,
					'tools'         => array(
						__( 'generate_health_chart tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'healthcare_imaging'              => array(
					'name'          => __( 'Healthcare Imaging Viewer', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'DICOM medical imaging viewer with Cornerstone3D. Secure PET/CT/MR study upload, metadata extraction, REST API, and HIPAA-aligned audit logging.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_healthcare_imaging'] ),
					'category'      => 'specialized',
					'php_functions' => array( 'fopen', 'fread', 'fclose', 'move_uploaded_file' ),
					'npm_packages'  => array( '@cornerstonejs/core', '@cornerstonejs/tools', '@cornerstonejs/dicom-image-loader' ),
					'tools_count'   => 1,
					'tools'         => array(
						__( 'manage_imaging_studies tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'quiz_system'                     => array(
					'name'          => __( 'Quiz System', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Interactive quiz creation with math equation support.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_quiz_system'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'katex' ),
					'tools_count'   => 2,
					'tools'         => array(
						__( 'create_quiz tool', 'nvdigital-open-operator-system-oos' ),
						__( 'render_math_equation tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'eca_management'                  => array(
					'name'          => __( 'ECA Management', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Extracurricular activities management with no external dependencies.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_eca_management'] ),
					'category'      => 'core',
					'php_functions' => array(),
					'npm_packages'  => array(),
					'tools_count'   => 3,
					'tools'         => array(
						__( 'manage_eca tool', 'nvdigital-open-operator-system-oos' ),
						__( 'track_eca_attendance tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_eca_report tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'crm_toolkit'                     => array(
					'name'          => __( 'CRM & Email Marketing Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Comprehensive customer relationship management and email marketing automation with contact management, campaign creation, list segmentation, email sending with nodemailer, validation, CSV import/export, and calendar integration.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_crm_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array( 'proc_open', 'proc_close' ),
					'npm_packages'  => array( 'nodemailer', 'validator', 'email-validator', 'libphonenumber-js', 'mailparser', 'csv-parse', 'csv-stringify', 'ical-generator' ),
					'tools_count'   => 12,
					'tools'         => array(
						__( 'create_contact tool', 'nvdigital-open-operator-system-oos' ),
						__( 'update_contact tool', 'nvdigital-open-operator-system-oos' ),
						__( 'segment_contacts tool', 'nvdigital-open-operator-system-oos' ),
						__( 'import_contacts_csv tool', 'nvdigital-open-operator-system-oos' ),
						__( 'export_contacts_csv tool', 'nvdigital-open-operator-system-oos' ),
						__( 'create_email_campaign tool', 'nvdigital-open-operator-system-oos' ),
						__( 'send_email tool', 'nvdigital-open-operator-system-oos' ),
						__( 'parse_email tool', 'nvdigital-open-operator-system-oos' ),
						__( 'validate_email tool', 'nvdigital-open-operator-system-oos' ),
						__( 'validate_phone tool', 'nvdigital-open-operator-system-oos' ),
						__( 'track_campaign_metrics tool', 'nvdigital-open-operator-system-oos' ),
						__( 'send_calendar_invite tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'code_formatting'                 => array(
					'name'          => __( 'Code Formatting', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Code and email template formatting with Prettier and MJML.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => true,
					'category'      => 'infrastructure',
					'php_functions' => array( 'proc_open', 'proc_close' ),
					'npm_packages'  => array( 'prettier', 'mjml' ),
					'tools_count'   => 2,
					'tools'         => array(
						__( 'format_code tool', 'nvdigital-open-operator-system-oos' ),
						__( 'compile_mjml tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'ecommerce_toolkit'               => array(
					'name'          => __( 'E-commerce Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Advanced WooCommerce integration with product management, order processing, inventory tracking, payment gateway support, and customer management.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_ecommerce_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( '@woocommerce/woocommerce-rest-api', 'stripe', 'currency.js' ),
					'tools_count'   => 8,
					'tools'         => array(
						__( 'create_product_advanced tool', 'nvdigital-open-operator-system-oos' ),
						__( 'update_product_inventory tool', 'nvdigital-open-operator-system-oos' ),
						__( 'process_payment tool', 'nvdigital-open-operator-system-oos' ),
						__( 'manage_orders tool', 'nvdigital-open-operator-system-oos' ),
						__( 'calculate_pricing tool', 'nvdigital-open-operator-system-oos' ),
						__( 'manage_customers tool', 'nvdigital-open-operator-system-oos' ),
						__( 'track_shipments tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_reports tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'social_media_toolkit'            => array(
					'name'          => __( 'Social Media Management Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Multi-platform social media posting, scheduling, analytics, and engagement management for Twitter, Facebook, LinkedIn, and Instagram.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_social_media_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'twitter-api-v2', 'axios', 'facebook-nodejs-business-sdk', 'linkedin-api-client' ),
					'tools_count'   => 12,
					'tools'         => array(
						__( 'post_to_twitter tool', 'nvdigital-open-operator-system-oos' ),
						__( 'post_to_facebook tool', 'nvdigital-open-operator-system-oos' ),
						__( 'post_to_linkedin tool', 'nvdigital-open-operator-system-oos' ),
						__( 'post_to_instagram tool', 'nvdigital-open-operator-system-oos' ),
						__( 'schedule_social_post tool', 'nvdigital-open-operator-system-oos' ),
						__( 'analyze_engagement tool', 'nvdigital-open-operator-system-oos' ),
						__( 'manage_social_campaigns tool', 'nvdigital-open-operator-system-oos' ),
						__( 'cross_post_content tool', 'nvdigital-open-operator-system-oos' ),
						__( 'track_mentions tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_hashtags tool', 'nvdigital-open-operator-system-oos' ),
						__( 'schedule_thread tool', 'nvdigital-open-operator-system-oos' ),
						__( 'monitor_trends tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'analytics_toolkit'               => array(
					'name'          => __( 'Advanced Analytics Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Business intelligence, predictive analytics, data visualization with D3.js, statistical analysis with Math.js, regression modeling, and CSV data export.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_analytics_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'd3', 'mathjs', 'regression', 'fast-csv' ),
					'tools_count'   => 10,
					'tools'         => array(
						__( 'create_dashboard tool', 'nvdigital-open-operator-system-oos' ),
						__( 'visualize_data tool', 'nvdigital-open-operator-system-oos' ),
						__( 'perform_regression_analysis tool', 'nvdigital-open-operator-system-oos' ),
						__( 'calculate_statistics tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_predictions tool', 'nvdigital-open-operator-system-oos' ),
						__( 'export_csv tool', 'nvdigital-open-operator-system-oos' ),
						__( 'import_csv tool', 'nvdigital-open-operator-system-oos' ),
						__( 'create_charts tool', 'nvdigital-open-operator-system-oos' ),
						__( 'analyze_trends tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_insights tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'multilingual_toolkit'            => array(
					'name'          => __( 'Multilingual Content Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Multi-language content management with i18next, automatic language detection with franc, Google Translate API integration, and ISO 639-1 language code support.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_multilingual_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'i18next', 'franc', 'google-translate-api-x', 'iso-639-1' ),
					'tools_count'   => 6,
					'tools'         => array(
						__( 'translate_content tool', 'nvdigital-open-operator-system-oos' ),
						__( 'detect_language tool', 'nvdigital-open-operator-system-oos' ),
						__( 'manage_translations tool', 'nvdigital-open-operator-system-oos' ),
						__( 'localize_content tool', 'nvdigital-open-operator-system-oos' ),
						__( 'validate_language_codes tool', 'nvdigital-open-operator-system-oos' ),
						__( 'batch_translate tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'video_production_toolkit'        => array(
					'name'          => __( 'Video Production Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Professional video creation, editing, and processing with FFmpeg, subtitle generation, GIF creation, and video stitching for content creators and marketers.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_video_production_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array( 'proc_open', 'proc_close', 'proc_terminate', 'exec' ),
					'npm_packages'  => array( 'ffmpeg-static', 'ffprobe-static', 'gif-encoder', 'video-stitch', 'subtitle' ),
					'tools_count'   => 10,
					'tools'         => array(
						__( 'create_video tool', 'nvdigital-open-operator-system-oos' ),
						__( 'edit_video tool', 'nvdigital-open-operator-system-oos' ),
						__( 'convert_video tool', 'nvdigital-open-operator-system-oos' ),
						__( 'compress_video tool', 'nvdigital-open-operator-system-oos' ),
						__( 'add_subtitles tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_gif tool', 'nvdigital-open-operator-system-oos' ),
						__( 'stitch_videos tool', 'nvdigital-open-operator-system-oos' ),
						__( 'extract_audio tool', 'nvdigital-open-operator-system-oos' ),
						__( 'add_watermark tool', 'nvdigital-open-operator-system-oos' ),
						__( 'trim_video tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'ai_tool_builder_toolkit'         => array(
					'name'          => __( 'AI Tool Builder Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Meta-toolkit for creating custom AI tools with scaffolding, code generation, testing, and documentation capabilities.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_ai_tool_builder_toolkit'] ),
					'category'      => 'infrastructure',
					'php_functions' => array(),
					'npm_packages'  => array( 'prettier' ),
					'tools_count'   => 5,
					'tools'         => array(
						__( 'scaffold_tool tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_tool_code tool', 'nvdigital-open-operator-system-oos' ),
						__( 'test_tool tool', 'nvdigital-open-operator-system-oos' ),
						__( 'document_tool tool', 'nvdigital-open-operator-system-oos' ),
						__( 'validate_tool tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'architect_agent_toolkit'         => array(
					'name'          => __( 'Architect Agent Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Self-editing capabilities for AI agents with file operations, shell commands, git integration, and code search. Achieves GitHub Copilot CLI parity.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_architect_agent_toolkit'] ),
					'category'      => 'development',
					'php_functions' => array( 'proc_open', 'exec' ),
					'npm_packages'  => array(),
					'tools_count'   => 4,
					'tools'         => array(
						__( 'manage_files tool', 'nvdigital-open-operator-system-oos' ),
						__( 'execute_shell_command tool', 'nvdigital-open-operator-system-oos' ),
						__( 'git_operations tool', 'nvdigital-open-operator-system-oos' ),
						__( 'search_codebase tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'architectural_design_toolkit'    => array(
					'name'          => __( 'Architectural Design Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'AI-powered floor plan generation, 3D modeling, blueprint creation, code compliance checking, and cost estimation for architectural projects.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_architectural_design_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'd3' ),
					'tools_count'   => 6,
					'tools'         => array(
						__( 'generate_floor_plan tool', 'nvdigital-open-operator-system-oos' ),
						__( 'create_3d_model tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_blueprint tool', 'nvdigital-open-operator-system-oos' ),
						__( 'check_code_compliance tool', 'nvdigital-open-operator-system-oos' ),
						__( 'estimate_costs tool', 'nvdigital-open-operator-system-oos' ),
						__( 'optimize_layout tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'calendar_booking_toolkit'        => array(
					'name'          => __( 'Calendar Booking Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Appointment scheduling, availability management, calendar synchronization, booking management, and automated reminder system.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_calendar_booking_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'ics', 'ical-generator' ),
					'tools_count'   => 7,
					'tools'         => array(
						__( 'schedule_appointment tool', 'nvdigital-open-operator-system-oos' ),
						__( 'check_availability tool', 'nvdigital-open-operator-system-oos' ),
						__( 'sync_calendar tool', 'nvdigital-open-operator-system-oos' ),
						__( 'manage_bookings tool', 'nvdigital-open-operator-system-oos' ),
						__( 'send_reminders tool', 'nvdigital-open-operator-system-oos' ),
						__( 'cancel_booking tool', 'nvdigital-open-operator-system-oos' ),
						__( 'reschedule_appointment tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'dj_management_toolkit'           => array(
					'name'          => __( 'DJ Management Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Equipment tracking, playlist management, event scheduling, client management, and music library organization for DJs and event organizers.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_dj_management_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array(),
					'tools_count'   => 8,
					'tools'         => array(
						__( 'track_equipment tool', 'nvdigital-open-operator-system-oos' ),
						__( 'manage_playlists tool', 'nvdigital-open-operator-system-oos' ),
						__( 'schedule_events tool', 'nvdigital-open-operator-system-oos' ),
						__( 'manage_clients tool', 'nvdigital-open-operator-system-oos' ),
						__( 'organize_music_library tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_setlist tool', 'nvdigital-open-operator-system-oos' ),
						__( 'track_bookings tool', 'nvdigital-open-operator-system-oos' ),
						__( 'manage_invoices tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'financial_planner_toolkit'       => array(
					'name'          => __( 'Financial Planner Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Retirement planning, budgeting, investment tracking, debt management, and financial goal planning with advanced analytics.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_financial_planner_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'mathjs', 'regression', 'currency.js' ),
					'tools_count'   => 9,
					'tools'         => array(
						__( 'plan_retirement tool', 'nvdigital-open-operator-system-oos' ),
						__( 'create_budget tool', 'nvdigital-open-operator-system-oos' ),
						__( 'track_investments tool', 'nvdigital-open-operator-system-oos' ),
						__( 'manage_debt tool', 'nvdigital-open-operator-system-oos' ),
						__( 'set_financial_goals tool', 'nvdigital-open-operator-system-oos' ),
						__( 'calculate_roi tool', 'nvdigital-open-operator-system-oos' ),
						__( 'project_savings tool', 'nvdigital-open-operator-system-oos' ),
						__( 'analyze_expenses tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_financial_report tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'image_production_toolkit'        => array(
					'name'          => __( 'Image Production Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'AI-powered image generation, editing, enhancement, and optimization with advanced filters and effects.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_image_production_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array( 'proc_open', 'proc_close' ),
					'npm_packages'  => array( 'sharp' ),
					'tools_count'   => 8,
					'tools'         => array(
						__( 'generate_image tool', 'nvdigital-open-operator-system-oos' ),
						__( 'edit_image tool', 'nvdigital-open-operator-system-oos' ),
						__( 'enhance_image tool', 'nvdigital-open-operator-system-oos' ),
						__( 'apply_filters tool', 'nvdigital-open-operator-system-oos' ),
						__( 'remove_background tool', 'nvdigital-open-operator-system-oos' ),
						__( 'upscale_image tool', 'nvdigital-open-operator-system-oos' ),
						__( 'batch_process_images tool', 'nvdigital-open-operator-system-oos' ),
						__( 'create_thumbnail tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'regulatory_registration_toolkit' => array(
					'name'          => __( 'Regulatory Registration Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Comprehensive regulatory product registration and compliance management for multi-country regulatory submissions (NMRA, MOHAP, SFDA). Features product registration tracking, document management, compliance validation, PDF generation, and multi-country support with registration timeline tracking and expiry notifications.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_regulatory_registration_toolkit'] ),
					'category'      => 'specialized',
					'php_functions' => array(),
					'npm_packages'  => array( 'pdfkit', 'exceljs', 'docx', 'csv-parse', 'csv-stringify', 'validator' ),
					'tools_count'   => 40,
					'tools'         => array(
						__( 'create_reg_product tool', 'nvdigital-open-operator-system-oos' ),
						__( 'list_reg_products tool', 'nvdigital-open-operator-system-oos' ),
						__( 'get_reg_product tool', 'nvdigital-open-operator-system-oos' ),
						__( 'update_reg_product tool', 'nvdigital-open-operator-system-oos' ),
						__( 'delete_reg_product tool', 'nvdigital-open-operator-system-oos' ),
						__( 'search_reg_products tool', 'nvdigital-open-operator-system-oos' ),
						__( 'duplicate_reg_product tool', 'nvdigital-open-operator-system-oos' ),
						__( 'validate_reg_product tool', 'nvdigital-open-operator-system-oos' ),
						__( 'create_registration tool', 'nvdigital-open-operator-system-oos' ),
						__( 'list_registrations tool', 'nvdigital-open-operator-system-oos' ),
						__( 'get_registration tool', 'nvdigital-open-operator-system-oos' ),
						__( 'update_registration_status tool', 'nvdigital-open-operator-system-oos' ),
						__( 'list_expiring_registrations tool', 'nvdigital-open-operator-system-oos' ),
						__( 'submit_registration tool', 'nvdigital-open-operator-system-oos' ),
						__( 'approve_registration tool', 'nvdigital-open-operator-system-oos' ),
						__( 'renew_registration tool', 'nvdigital-open-operator-system-oos' ),
						__( 'get_registration_timeline tool', 'nvdigital-open-operator-system-oos' ),
						__( 'list_registrations_by_country tool', 'nvdigital-open-operator-system-oos' ),
						__( 'list_reg_documents tool', 'nvdigital-open-operator-system-oos' ),
						__( 'check_document_expiry tool', 'nvdigital-open-operator-system-oos' ),
						__( 'upload_reg_document tool', 'nvdigital-open-operator-system-oos' ),
						__( 'update_reg_document tool', 'nvdigital-open-operator-system-oos' ),
						__( 'get_reg_document tool', 'nvdigital-open-operator-system-oos' ),
						__( 'validate_document_checklist tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_submission_pack tool', 'nvdigital-open-operator-system-oos' ),
						__( 'track_document_version tool', 'nvdigital-open-operator-system-oos' ),
						__( 'add_regulatory_requirement tool', 'nvdigital-open-operator-system-oos' ),
						__( 'get_regulatory_requirements tool', 'nvdigital-open-operator-system-oos' ),
						__( 'check_product_compliance tool', 'nvdigital-open-operator-system-oos' ),
						__( 'validate_inci_ingredients tool', 'nvdigital-open-operator-system-oos' ),
						__( 'check_hs_code tool', 'nvdigital-open-operator-system-oos' ),
						__( 'get_regulatory_updates tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_pdf_dossier tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_cover_letter tool', 'nvdigital-open-operator-system-oos' ),
						__( 'generate_compliance_certificate tool', 'nvdigital-open-operator-system-oos' ),
						__( 'sync_with_nmra tool', 'nvdigital-open-operator-system-oos' ),
						__( 'sync_with_mohap tool', 'nvdigital-open-operator-system-oos' ),
						__( 'sync_with_sfda tool', 'nvdigital-open-operator-system-oos' ),
						__( 'validate_excel_import tool', 'nvdigital-open-operator-system-oos' ),
						__( 'configure_email_notifications tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
				'fantasy_football'                => array(
					'name'          => __( 'Fantasy Football Toolkit', 'nvdigital-open-operator-system-oos' ),
					'description'   => __( 'Yahoo Fantasy Sports integration with team management, player research, trade analysis, and league reporting.', 'nvdigital-open-operator-system-oos' ),
					'enabled'       => ! empty( $settings['enable_fantasy_football'] ),
					'category'      => 'sports',
					'php_functions' => array(),
					'npm_packages'  => array(),
					'tools_count'   => 9,
					'tools'         => array(
						__( 'yahoo_ff_auth tool', 'nvdigital-open-operator-system-oos' ),
						__( 'yahoo_ff_get_leagues tool', 'nvdigital-open-operator-system-oos' ),
						__( 'yahoo_ff_get_roster tool', 'nvdigital-open-operator-system-oos' ),
						__( 'yahoo_ff_get_player_stats tool', 'nvdigital-open-operator-system-oos' ),
						__( 'yahoo_ff_league_standings tool', 'nvdigital-open-operator-system-oos' ),
						__( 'yahoo_ff_trade_analyzer tool', 'nvdigital-open-operator-system-oos' ),
						__( 'ff_player_research tool', 'nvdigital-open-operator-system-oos' ),
						__( 'ff_create_league_report tool', 'nvdigital-open-operator-system-oos' ),
						__( 'ff_generate_team_logo tool', 'nvdigital-open-operator-system-oos' ),
					),
				),
			);

			// Check PHP function availability for each toolkit.
			foreach ( $toolkits as $toolkit_id => &$toolkit ) {
				$toolkit['php_available'] = true;
				$toolkit['php_status']    = array();

				foreach ( $toolkit['php_functions'] as $func_name ) {
					$available                           = function_exists( $func_name );
					$toolkit['php_status'][ $func_name ] = $available;
					if ( ! $available ) {
						$toolkit['php_available'] = false;
					}
				}

				// Check NPM package availability.
				$toolkit['npm_available'] = true;
				$toolkit['npm_status']    = array();

				foreach ( $toolkit['npm_packages'] as $package ) {
					$status                            = self::get_package_status( $package );
					$toolkit['npm_status'][ $package ] = $status;
					if ( ! $status['available'] ) {
						$toolkit['npm_available'] = false;
					}
				}

				// Check Composer package availability.
				$toolkit['composer_available'] = true;
				$toolkit['composer_status']    = array();

				if ( isset( $toolkit['composer_packages'] ) && is_array( $toolkit['composer_packages'] ) ) {
					foreach ( $toolkit['composer_packages'] as $package ) {
						$status                                 = self::get_composer_package_status( $package );
						$toolkit['composer_status'][ $package ] = $status;
						if ( ! $status['available'] ) {
							$toolkit['composer_available'] = false;
						}
					}
				}

				// Overall status.
				$toolkit['fully_operational'] = $toolkit['enabled'] && $toolkit['php_available'] && $toolkit['npm_available'] && $toolkit['composer_available'];
				$toolkit['has_issues']        = ! $toolkit['php_available'] || ! $toolkit['npm_available'] || ! $toolkit['composer_available'];
			}

			return $toolkits;
		}

		/**
		 * Render a toolkit card with detailed information.
		 *
		 * Displays toolkit status, requirements, dependencies, and tools list.
		 *
		 * @param string $toolkit_id Toolkit identifier.
		 * @param array  $toolkit    Toolkit details.
		 * @return void
		 */
		private static function render_toolkit_card( $toolkit_id, $toolkit ) {
			$status_class   = $toolkit['fully_operational'] ? 'operational' : ( $toolkit['enabled'] ? 'partial' : 'disabled' );
			$status_text    = $toolkit['fully_operational'] ? __( 'Operational', 'nvdigital-open-operator-system-oos' ) : ( $toolkit['enabled'] ? __( 'Enabled (Issues)', 'nvdigital-open-operator-system-oos' ) : __( 'Disabled', 'nvdigital-open-operator-system-oos' ) );
			$category_badge = $toolkit['category'];
			?>
			<div class="wp-mcp-ai-toolkit-card" data-toolkit="<?php echo esc_attr( $toolkit_id ); ?>">
					<div class="toolkit-header">
						<h3>
							<?php echo esc_html( $toolkit['name'] ); ?>
							<span class="toolkit-status-badge <?php echo esc_attr( $status_class ); ?>">
								<?php echo esc_html( $status_text ); ?>
							</span>
							<span class="toolkit-category-badge <?php echo esc_attr( $category_badge ); ?>">
								<?php echo esc_html( ucfirst( $category_badge ) ); ?>
							</span>
						</h3>
						<p class="toolkit-description"><?php echo esc_html( $toolkit['description'] ); ?></p>
					</div>

					<?php if ( $toolkit['has_issues'] && $toolkit['enabled'] ) : ?>
						<div class="toolkit-warning">
							<span class="dashicons dashicons-warning"></span>
							<strong><?php esc_html_e( 'Warning:', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<?php esc_html_e( 'This toolkit is enabled but has missing dependencies or PHP function requirements.', 'nvdigital-open-operator-system-oos' ); ?>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $toolkit['php_functions'] ) ) : ?>
						<details class="toolkit-section">
							<summary>
								<?php esc_html_e( 'PHP Requirements', 'nvdigital-open-operator-system-oos' ); ?>
								<span class="section-badge <?php echo esc_attr( $toolkit['php_available'] ? 'ok' : 'error' ); ?>">
									<?php echo $toolkit['php_available'] ? esc_html__( 'OK', 'nvdigital-open-operator-system-oos' ) : esc_html__( 'Missing', 'nvdigital-open-operator-system-oos' ); ?>
								</span>
							</summary>
							<table class="toolkit-details-table">
								<thead>
									<tr>
										<th><?php esc_html_e( 'PHP Function', 'nvdigital-open-operator-system-oos' ); ?></th>
										<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( $toolkit['php_status'] as $func_name => $available ) : ?>
										<tr>
											<td><code><?php echo esc_html( $func_name ); ?></code></td>
											<td>
												<span class="status-indicator <?php echo esc_attr( $available ? 'available' : 'unavailable' ); ?>">
													<?php echo $available ? '✓' : '✗'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static checkmark symbols. ?>
												</span>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</details>
					<?php endif; ?>

					<?php if ( ! empty( $toolkit['npm_packages'] ) ) : ?>
						<details class="toolkit-section">
							<summary>
								<?php esc_html_e( 'NPM Dependencies', 'nvdigital-open-operator-system-oos' ); ?>
								<span class="section-badge <?php echo esc_attr( $toolkit['npm_available'] ? 'ok' : 'error' ); ?>">
									<?php echo $toolkit['npm_available'] ? esc_html__( 'OK', 'nvdigital-open-operator-system-oos' ) : esc_html__( 'Missing', 'nvdigital-open-operator-system-oos' ); ?>
								</span>
							</summary>
							<table class="toolkit-details-table">
								<thead>
									<tr>
										<th><?php esc_html_e( 'Package Name', 'nvdigital-open-operator-system-oos' ); ?></th>
										<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( $toolkit['npm_status'] as $package => $status ) : ?>
										<tr>
											<td><code><?php echo esc_html( $package ); ?></code></td>
											<td>
												<?php if ( $status['available'] ) : ?>
													<span class="status-indicator available" title="<?php echo esc_attr( $status['message'] ); ?>">
														<?php echo '✓'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static checkmark symbol. ?>
														<?php if ( isset( $status['source'] ) && 'cdn' === $status['source'] ) : ?>
															<span class="status-source"><?php esc_html_e( '(CDN)', 'nvdigital-open-operator-system-oos' ); ?></span>
														<?php endif; ?>
													</span>
												<?php else : ?>
													<span class="status-indicator unavailable">
														<?php echo '✗'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static cross symbol. ?>
													</span>
												<?php endif; ?>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</details>
					<?php endif; ?>

					<?php if ( ! empty( $toolkit['composer_packages'] ) ) : ?>
						<details class="toolkit-section">
							<summary>
								<?php esc_html_e( 'Composer Dependencies', 'nvdigital-open-operator-system-oos' ); ?>
								<span class="section-badge <?php echo esc_attr( $toolkit['composer_available'] ? 'ok' : 'error' ); ?>">
									<?php echo $toolkit['composer_available'] ? esc_html__( 'OK', 'nvdigital-open-operator-system-oos' ) : esc_html__( 'Missing', 'nvdigital-open-operator-system-oos' ); ?>
								</span>
							</summary>
							<table class="toolkit-details-table">
								<thead>
									<tr>
										<th><?php esc_html_e( 'Package Name', 'nvdigital-open-operator-system-oos' ); ?></th>
										<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( $toolkit['composer_status'] as $package => $status ) : ?>
										<tr>
											<td><code><?php echo esc_html( $package ); ?></code></td>
											<td>
												<?php if ( $status['available'] ) : ?>
													<span class="status-indicator available" title="<?php echo esc_attr( $status['message'] ); ?>">
														<?php echo '✓'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static checkmark symbol. ?>
													</span>
												<?php else : ?>
													<span class="status-indicator unavailable">
														<?php echo '✗'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static cross symbol. ?>
													</span>
												<?php endif; ?>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</details>
					<?php endif; ?>

					<details class="toolkit-section">
						<summary>
							<?php esc_html_e( 'Tools', 'nvdigital-open-operator-system-oos' ); ?>
							<span class="tools-count">(<?php echo absint( $toolkit['tools_count'] ); ?>)</span>
						</summary>
						<ul class="toolkit-tools-list">
							<?php foreach ( $toolkit['tools'] as $tool ) : ?>
								<li><?php echo esc_html( $tool ); ?></li>
							<?php endforeach; ?>
						</ul>
					</details>
				</div>
			<?php
		}

		/**
		 * Get pro toolkit status information.
		 *
		 * Returns status of various pro features and configurations.
		 *
		 * @return array Pro toolkit status information.
		 */
		public static function get_pro_toolkit_status() {
			$status = array(
				'pro_dashboard_enabled' => defined( 'WP_MCP_AI_PRO_DASHBOARD_ENABLED' ) && WP_MCP_AI_PRO_DASHBOARD_ENABLED,
				'base_version'          => ! defined( 'WP_MCP_AI_PRO_VERSION' ),
				'debug_mode'            => defined( 'WP_DEBUG' ) && WP_DEBUG,
				'php_version'           => PHP_VERSION,
				'wp_version'            => get_bloginfo( 'version' ),
				'plugin_version'        => defined( 'WP_MCP_AI_VERSION' ) ? WP_MCP_AI_VERSION : 'unknown',
			);

			// Check optional integrations.
			$status['integrations'] = array(
				'jetengine'      => class_exists( 'Jet_Engine' ),
				'jetformbuilder' => class_exists( 'Jet_Form_Builder' ),
				'woocommerce'    => class_exists( 'WooCommerce' ),
				'elementor'      => defined( 'ELEMENTOR_VERSION' ),
				'rankmath'       => defined( 'RANK_MATH_VERSION' ),
				'wpcode'         => defined( 'WPCODE_VERSION' ),
				'newsletter'     => class_exists( 'Newsletter' ) || class_exists( 'NewsletterEmails' ),
				'wpallimport'    => class_exists( 'PMXI_Plugin' ) || defined( 'PMXI_VERSION' ),
				'wpallexport'    => class_exists( 'PMXE_Plugin' ) || defined( 'PMXE_VERSION' ),
			);

			return $status;
		}

		/**
		 * Render npm packages table.
		 *
		 * Displays packages in a WordPress standard table format.
		 *
		 * @param array  $packages Package list.
		 * @param string $title    Table title.
		 * @return void
		 */
		private static function render_packages_table( $packages, $title ) {
			if ( empty( $packages ) ) {
				echo '<p><em>' . esc_html__( 'No packages found.', 'nvdigital-open-operator-system-oos' ) . '</em></p>';
				return;
			}

			?>
			<h3><?php echo esc_html( $title ); ?> <span class="count">(<?php echo count( $packages ); ?>)</span></h3>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th style="width: 40%;"><?php esc_html_e( 'Package Name', 'nvdigital-open-operator-system-oos' ); ?></th>
						<th style="width: 20%;"><?php esc_html_e( 'Version', 'nvdigital-open-operator-system-oos' ); ?></th>
						<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					// Sort packages alphabetically.
					ksort( $packages );
					foreach ( $packages as $package => $version ) :
						// Get detailed package status (includes CDN detection).
						$status       = self::get_package_status( $package );
						$status_class = $status['available'] ? 'installed' : 'not-installed';
						$status_text  = $status['message'];

						// Add special CSS class for CDN packages.
						if ( isset( $status['source'] ) && 'cdn' === $status['source'] ) {
							$status_class .= ' cdn-loaded';
						}
						?>
						<tr>
							<td><code><?php echo esc_html( $package ); ?></code></td>
							<td><code><?php echo esc_html( $version ); ?></code></td>
							<td>
								<span class="wp-mcp-ai-status-badge <?php echo esc_attr( $status_class ); ?>">
									<?php echo esc_html( $status_text ); ?>
								</span>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php
		}

		/**
		 * Render Composer packages table.
		 *
		 * Displays Composer packages in a WordPress standard table format.
		 *
		 * @param array  $packages Package list.
		 * @param string $title    Table title.
		 * @return void
		 */
		private static function render_composer_table( $packages, $title ) {
			if ( empty( $packages ) ) {
				echo '<p><em>' . esc_html__( 'No packages found.', 'nvdigital-open-operator-system-oos' ) . '</em></p>';
				return;
			}

			?>
			<h4><?php echo esc_html( $title ); ?> <span class="count">(<?php echo count( $packages ); ?>)</span></h4>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th style="width: 50%;"><?php esc_html_e( 'Package Name', 'nvdigital-open-operator-system-oos' ); ?></th>
						<th style="width: 25%;"><?php esc_html_e( 'Version', 'nvdigital-open-operator-system-oos' ); ?></th>
						<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					// Sort packages alphabetically.
					ksort( $packages );
					foreach ( $packages as $package => $version ) :
						// Check if package is installed (vendor autoload exists).
						$package_installed = self::check_composer_package_installed( $package );
						$status_class      = $package_installed ? 'installed' : 'not-installed';
						$status_text       = $package_installed ? __( 'Installed', 'nvdigital-open-operator-system-oos' ) : __( 'Not Found', 'nvdigital-open-operator-system-oos' );

						// For PHP, show actual version instead of just installed status.
						if ( 'php' === $package ) {
							$current_php     = phpversion();
							$required_php    = trim( $version, '^><=~' ); // Remove version constraints.
							$version_compare = version_compare( $current_php, $required_php, '>=' );
							$status_class    = $version_compare ? 'installed' : 'not-installed';
							$status_text     = sprintf(
								/* translators: %s: PHP version number */
								__( 'PHP %s', 'nvdigital-open-operator-system-oos' ),
								$current_php
							);
						}
						?>
						<tr>
							<td><code><?php echo esc_html( $package ); ?></code></td>
							<td><code><?php echo esc_html( $version ); ?></code></td>
							<td>
								<span class="wp-mcp-ai-status-badge <?php echo esc_attr( $status_class ); ?>">
									<?php echo esc_html( $status_text ); ?>
								</span>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php
		}

		/**
		 * Check if a Composer package is installed.
		 *
		 * Checks if package exists in vendor directory by looking for composer autoload.
		 * For PHP platform requirement, checks the installed PHP version.
		 *
		 * @param string $package Package name.
		 * @return bool True if package appears to be installed.
		 */
		private static function check_composer_package_installed( $package ) {
			// Handle PHP as a special case - it's a platform requirement, not a package.
			if ( 'php' === $package ) {
				return true; // PHP is always "installed" since WordPress requires it.
			}

			// Check base plugin vendor autoload.
			$vendor_autoload = WP_MCP_AI_PATH . 'vendor/autoload.php';
			if ( file_exists( $vendor_autoload ) ) {
				// Derive vendor path from package name (e.g., 'symfony/http-client' -> 'vendor/symfony/http-client').
				$path = WP_MCP_AI_PATH . 'vendor/' . $package;
				if ( file_exists( $path ) ) {
					return true;
				}
			}

			// Check Pro addon vendor directory.
			if ( defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				$pro_vendor_autoload = WP_MCP_AI_PRO_PATH . 'vendor/autoload.php';
				if ( file_exists( $pro_vendor_autoload ) ) {
					$pro_vendor_path = WP_MCP_AI_PRO_PATH . 'vendor/' . $package;
					if ( file_exists( $pro_vendor_path ) ) {
						return true;
					}
				}
			}

			return false;
		}

		/**
		 * Get detailed package status including CDN availability.
		 *
		 * Returns an array with 'available', 'source', and 'message' keys.
		 *
		 * @param string $package Package name.
		 * @return array Status array.
		 */
		private static function get_package_status( $package ) {
			// Check if Pro CDN Loader is available and package is CDN-managed.
			if ( defined( 'WP_MCP_AI_PRO_PATH' ) && class_exists( 'WP_MCP_AI_Pro_CDN_Loader' ) ) {
				$cdn_packages = WP_MCP_AI_Pro_CDN_Loader::get_cdn_packages();
				if ( in_array( $package, $cdn_packages, true ) ) {
					$status = WP_MCP_AI_Pro_CDN_Loader::get_package_status( $package );
					if ( ! empty( $status ) && is_array( $status ) ) {
						return $status;
					}
				}
			}

			// For non-CDN packages, check if installed.
			$installed = self::check_package_installed( $package );

			if ( $installed ) {
				return array(
					'available' => true,
					'source'    => 'installed',
					'message'   => __( 'Installed', 'nvdigital-open-operator-system-oos' ),
				);
			}

			return array(
				'available' => false,
				'source'    => 'none',
				'message'   => __( 'Not Found', 'nvdigital-open-operator-system-oos' ),
			);
		}

		/**
		 * Get detailed Composer package status.
		 *
		 * Returns an array with 'available', 'source', and 'message' keys.
		 *
		 * @param string $package Package name (e.g., 'smalot/pdfparser').
		 * @return array Status array.
		 */
		private static function get_composer_package_status( $package ) {
			// Check if package is installed via Composer.
			$installed = self::check_composer_package_installed( $package );

			if ( $installed ) {
				return array(
					'available' => true,
					'source'    => 'composer',
					'message'   => __( 'Installed via Composer', 'nvdigital-open-operator-system-oos' ),
				);
			}

			// Check Pro addon vendor directory.
			if ( defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				$pro_vendor_path = WP_MCP_AI_PRO_PATH . 'vendor/' . $package;
				if ( file_exists( $pro_vendor_path ) ) {
					return array(
						'available' => true,
						'source'    => 'composer',
						'message'   => __( 'Installed via Composer (Pro)', 'nvdigital-open-operator-system-oos' ),
					);
				}
			}

			return array(
				'available' => false,
				'source'    => 'none',
				'message'   => __( 'Not Found', 'nvdigital-open-operator-system-oos' ),
			);
		}

		/**
		 * Check if a package is installed by looking for vendor files or bundled builds.
		 *
		 * Checks vendor directories FIRST (production), then bundled builds, then node_modules (development).
		 * This ensures production deployments with vendor files are detected before dev fallbacks.
		 *
		 * @param string $package Package name.
		 * @return bool True if package appears to be installed.
		 */
		private static function check_package_installed( $package ) {
			// Check for base vendor copies (chart.js, vectorizer).
			if ( 'chart.js' === $package ) {
				return file_exists( WP_MCP_AI_PATH . 'assets/js/vendor/chart.min.js' );
			}
			if ( '@neplex/vectorizer' === $package ) {
				return file_exists( WP_MCP_AI_PATH . 'assets/js/vendor/neplex-vectorizer/' );
			}

			// ===================================================================
			// PRIORITY 1: Check Pro addon packages in vendor directory FIRST
			// This is the production deployment - check BEFORE dev fallbacks
			// ===================================================================
			$pro_vendor_packages = array(
				// Original packages (Phase 1).
				'@turf/turf'                        => 'turf/dist/esm/index.js',
				'@types/pdfkit'                     => false, // TypeScript types only, no runtime file.
				'fluent-ffmpeg'                     => 'fluent-ffmpeg/index.js',
				'ics'                               => 'ics/index.js',
				'katex'                             => 'katex/dist/katex.min.js',
				'mjml'                              => 'mjml/lib/index.js',
				'prettier'                          => 'prettier/standalone.js',
				'sharp'                             => 'sharp/lib/index.js',
				// E-commerce Toolkit packages (Phase 2).
				'@woocommerce/woocommerce-rest-api' => 'woocommerce-rest-api/index.js',
				'stripe'                            => 'stripe/cjs/stripe.core.js',
				'currency.js'                       => 'currency.js/currency.min.js',
				// Social Media Toolkit packages (Phase 2).
				'twitter-api-v2'                    => 'twitter-api-v2/dist/cjs/index.js',
				'axios'                             => 'axios/dist/axios.js',
				'facebook-nodejs-business-sdk'      => 'facebook-nodejs-business-sdk/dist/cjs.js',
				'linkedin-api-client'               => 'linkedin-api-client/dist/lib/auth.js',
				// Analytics Toolkit packages (Phase 2).
				'd3'                                => 'd3/dist/d3.min.js',
				'mathjs'                            => 'mathjs/lib/cjs/index.js',
				'regression'                        => 'regression/regression.min.js',
				'fast-csv'                          => 'fast-csv/build/src/index.js',
				// Multilingual Toolkit packages (Phase 2).
				'i18next'                           => 'i18next/dist/cjs/i18next.js',
				'franc'                             => 'franc/index.js',
				'google-translate-api-x'            => 'google-translate-api-x/index.cjs',
				'iso-639-1'                         => 'iso-639-1/index.js',
				// Video Production Toolkit packages (Phase 2).
				'ffmpeg-static'                     => 'ffmpeg-static/index.js',
				'ffprobe-static'                    => 'ffprobe-static/index.js',
				'gif-encoder'                       => 'gif-encoder/lib/GIFEncoder.js',
				'video-stitch'                      => 'video-stitch/index.js',
				'subtitle'                          => 'subtitle/dist/index.js',
				// Remotion video generation packages.
				'remotion'                          => 'remotion/dist/cjs/index.js',
				'@remotion/bundler'                 => '@remotion/bundler/dist/index.js',
				'@remotion/renderer'                => '@remotion/renderer/dist/index.js',
				// CRM & Email Marketing Toolkit packages (Phase 2).
				'nodemailer'                        => 'nodemailer/lib/nodemailer.js',
				'validator'                         => 'validator/index.js',
				'email-validator'                   => 'email-validator/index.js',
				'libphonenumber-js'                 => 'libphonenumber-js/index.js',
				'mailparser'                        => 'mailparser/lib/mail-parser.js',
				'csv-parse'                         => 'csv-parse/lib/index.js',
				'csv-stringify'                     => 'csv-stringify/lib/index.js',
				'ical-generator'                    => 'ical-generator/dist/index.js',
				// Document generation packages.
				'pdf-lib'                           => 'pdf-lib/cjs/index.js',
				'pdf-parse'                         => 'pdf-parse/index.js',
				'pdfkit'                            => 'pdfkit/js/pdfkit.standalone.js',
				'exceljs'                           => 'exceljs/dist/exceljs.min.js',
				// docx ships only package.json in vendor; detected via bin/generate-word.bundle.js below.
				// Browser automation packages (optional).
				'puppeteer-core'                    => 'puppeteer-core/lib/cjs/puppeteer/puppeteer-core.js',
				'@puppeteer/browsers'               => '@puppeteer/browsers/lib/cjs/index.js',
			);
			if ( isset( $pro_vendor_packages[ $package ] ) && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				// @types packages don't have runtime files.
				if ( false === $pro_vendor_packages[ $package ] ) {
					return true; // TypeScript type definitions are always available.
				}
				$vendor_path = WP_MCP_AI_PRO_PATH . 'assets/vendor/' . $pro_vendor_packages[ $package ];
				if ( file_exists( $vendor_path ) ) {
					return true;
				}
			}

			// ===================================================================
			// PRIORITY 2: Check for packages bundled into built files
			// These are also production assets (chat-bundle, document bundles)
			// ===================================================================

			// Check for packages bundled into chat-bundle.min.js via esbuild.
			$bundled_packages = array(
				'@microsoft/fetch-event-source',
				'dompurify',
				'marked',
				'ky',
			);
			if ( in_array( $package, $bundled_packages, true ) ) {
				return file_exists( WP_MCP_AI_PATH . 'assets/js/chat-bundle.min.js' );
			}

			// Check for React packages bundled into workflow-builder via @wordpress/scripts.
			// These packages (react, react-dom, reactflow, @dnd-kit/*) are build-time dependencies
			// that get compiled into the workflow builder bundle for production.
			// The workflow builder is a PRO feature.
			$workflow_bundled_packages = array(
				'react',
				'react-dom',
				'reactflow',
				'@dnd-kit/core',
				'@dnd-kit/sortable',
				'@dnd-kit/utilities',
			);
			if ( in_array( $package, $workflow_bundled_packages, true ) ) {
				// Priority 1: Check for built workflow-builder bundle in Pro addon directory (production, correct location).
				// wp-scripts builds src/workflow-builder/index.jsx → build/workflow-builder/index.jsx.js.
				if ( defined( 'WP_MCP_AI_PRO_PATH' ) ) {
					$workflow_build_path = WP_MCP_AI_PRO_PATH . 'build/workflow-builder/index.jsx.js';
					if ( file_exists( $workflow_build_path ) ) {
						return true;
					}
				}
				// Priority 2: Check base build directory (legacy/development location).
				// NOTE: This should be moved to pro addon directory as per project standards.
				$legacy_workflow_build_path = WP_MCP_AI_PATH . 'build/workflow-builder/index.jsx.js';
				if ( file_exists( $legacy_workflow_build_path ) ) {
					return true;
				}
				// Priority 3: Check base node_modules (development).
				// These packages are in base package.json but used for Pro feature.
				$node_modules_path = WP_MCP_AI_PATH . 'node_modules/' . $package;
				if ( file_exists( $node_modules_path ) ) {
					return true;
				}
				// If none exist, return false (not installed/bundled).
				return false;
			}

			// Check for document generation and video packages bundled into bin/ scripts.
			// pdfkit and exceljs are detected via pro_vendor_packages above.
			// docx ships only package.json in vendor, so we detect it via its bin bundle.
			$script_bundled_packages = array(
				'docx'          => 'generate-word.bundle.js',
				'@remotion/cli' => 'remotion-render.bundle.js',
			);
			if ( isset( $script_bundled_packages[ $package ] ) && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				$script_path = WP_MCP_AI_PRO_PATH . 'bin/' . $script_bundled_packages[ $package ];
				if ( file_exists( $script_path ) ) {
					return true;
				}
			}

			// Check for research packages bundled into research-bundle.min.js.
			// These packages (cheerio, turndown) are in Pro addon's node_modules.
			$research_bundled_packages = array(
				'cheerio',
				'turndown',
			);
			if ( in_array( $package, $research_bundled_packages, true ) && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				// Priority 1: Check bundled file (production).
				$research_bundle_path = WP_MCP_AI_PRO_PATH . 'assets/js/research-bundle.min.js';
				if ( file_exists( $research_bundle_path ) ) {
					return true;
				}
				// Priority 2: Fallback to Pro addon's node_modules (development).
				$pro_node_modules_path = WP_MCP_AI_PRO_PATH . 'node_modules/' . $package;
				if ( file_exists( $pro_node_modules_path ) ) {
					return true;
				}
				// These packages are not in base, so return false if not found.
				return false;
			}

			// Check for orchestration packages bundled into orchestration-bundle.min.js.
			// These packages (p-queue) are in Pro addon's node_modules.
			$orchestration_bundled_packages = array(
				'p-queue', // Promise queue with concurrency control.
			);
			if ( in_array( $package, $orchestration_bundled_packages, true ) && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				// Priority 1: Check bundled file (production).
				$orchestration_bundle_path = WP_MCP_AI_PRO_PATH . 'assets/js/orchestration-bundle.min.js';
				if ( file_exists( $orchestration_bundle_path ) ) {
					return true;
				}
				// Priority 2: Fallback to Pro addon's node_modules (development).
				$pro_node_modules_path = WP_MCP_AI_PRO_PATH . 'node_modules/' . $package;
				if ( file_exists( $pro_node_modules_path ) ) {
					return true;
				}
				// These packages are not in base, so return false if not found.
				return false;
			}

			// Check for OCR packages used by Node.js services.
			// These packages (tesseract.js, pdfjs-dist, canvas) are dependencies for node-services.
			// They're bundled with the plugin in node-services directory for serverless OCR operations.
			$ocr_node_packages = array(
				'tesseract.js',
				'pdfjs-dist',
				'canvas',
			);
			if ( in_array( $package, $ocr_node_packages, true ) && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				// Priority 1: Check if Node.js OCR service exists (production).
				// The presence of this service file indicates OCR packages are available.
				$ocr_service_path = WP_MCP_AI_PRO_PATH . 'node-services/ocr-service.js';
				if ( file_exists( $ocr_service_path ) ) {
					return true;
				}
				// Priority 2: Check image preprocessing service (for sharp/canvas).
				$preprocess_service_path = WP_MCP_AI_PRO_PATH . 'node-services/image-preprocess-service.js';
				if ( file_exists( $preprocess_service_path ) ) {
					return true;
				}
				// Priority 3: Fallback to Pro addon's node_modules (development).
				$pro_node_modules_path = WP_MCP_AI_PRO_PATH . 'node_modules/' . $package;
				if ( file_exists( $pro_node_modules_path ) ) {
					return true;
				}
				// If none exist, return false (not installed).
				return false;
			}

			// Check for LangChain packages (optional dependencies).
			// These packages are used in langchain-orchestration.js and langchain-tool-adapter.js.
			// Files live in the Pro addon's assets directory (addons/pro/assets/js/).
			$langchain_packages = array(
				'langchain',
				'@langchain/core',
				'@langchain/community',
			);
			if ( in_array( $package, $langchain_packages, true ) ) {
				if ( ! defined( 'WP_MCP_AI_PRO_PATH' ) ) {
					return false;
				}
				// Priority 1: Check if langchain minified bundles exist (production).
				$langchain_orchestration = WP_MCP_AI_PRO_PATH . 'assets/js/langchain-orchestration.min.js';
				$langchain_adapter       = WP_MCP_AI_PRO_PATH . 'assets/js/langchain-tool-adapter.min.js';
				if ( file_exists( $langchain_orchestration ) || file_exists( $langchain_adapter ) ) {
					return true;
				}
				// Priority 2: Check if source files exist (development).
				$langchain_orchestration_src = WP_MCP_AI_PRO_PATH . 'assets/js/langchain-orchestration.js';
				$langchain_adapter_src       = WP_MCP_AI_PRO_PATH . 'assets/js/langchain-tool-adapter.js';
				if ( file_exists( $langchain_orchestration_src ) || file_exists( $langchain_adapter_src ) ) {
					return true;
				}
				// Priority 3: Check pro node_modules (development).
				$node_modules_path = WP_MCP_AI_PRO_PATH . 'node_modules/' . $package;
				if ( file_exists( $node_modules_path ) ) {
					return true;
				}
				// If none exist, return false (not installed).
				return false;
			}

			// Check for client-side WebLLM (loaded via CDN, not bundled).
			// This package is used in embedded-llm-client.js which loads it from CDN at runtime.
			if ( '@mlc-ai/web-llm' === $package ) {
				// Check if the client-side embedded LLM JavaScript file exists.
				$embedded_client_path = WP_MCP_AI_PATH . 'assets/js/embedded-llm-client.js';
				return file_exists( $embedded_client_path );
			}

			// Check for Cornerstone3D packages (loaded via CDN by imaging-viewer.js).
			// These packages are pre-packed/CDN-loaded; availability is indicated by
			// the presence of the imaging-viewer.js entry-point script.
			if ( defined( 'WP_MCP_AI_PRO_PATH' ) && function_exists( 'wp_mcp_ai_cornerstone_package_names' ) ) {
				$cornerstone_packages = wp_mcp_ai_cornerstone_package_names();
			} else {
				$cornerstone_packages = array(
					'@cornerstonejs/core',
					'@cornerstonejs/tools',
					'@cornerstonejs/dicom-image-loader',
				);
			}
			if ( in_array( $package, $cornerstone_packages, true ) && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				// Priority 1: Check if imaging-viewer.js exists (CDN-loads Cornerstone3D at runtime).
				$imaging_viewer_path = WP_MCP_AI_PRO_PATH . 'assets/js/imaging-viewer.js';
				if ( file_exists( $imaging_viewer_path ) ) {
					return true;
				}
				// Priority 2: Check pro node_modules (development).
				$node_modules_path = WP_MCP_AI_PRO_PATH . 'node_modules/' . $package;
				if ( file_exists( $node_modules_path ) ) {
					return true;
				}
				return false;
			}

			// Check for pdf-parse package (Pro addon).
			if ( 'pdf-parse' === $package && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				// Priority 1: Check if it's in Pro addon's vendor directory (production).
				$pdf_parse_vendor_path = WP_MCP_AI_PRO_PATH . 'assets/vendor/pdf-parse/lib/pdf-parse.js';
				if ( file_exists( $pdf_parse_vendor_path ) ) {
					return true;
				}

				// Priority 2: Check the package.json existence as fallback.
				$pdf_parse_pkg_path = WP_MCP_AI_PRO_PATH . 'assets/vendor/pdf-parse/package.json';
				if ( file_exists( $pdf_parse_pkg_path ) ) {
					return true;
				}

				// Priority 3: Check Pro addon's node_modules (development only).
				$pdf_parse_node_path = WP_MCP_AI_PRO_PATH . 'node_modules/pdf-parse';
				if ( file_exists( $pdf_parse_node_path ) ) {
					return true;
				}

				// If Pro addon is active, assume pdf-parse is available.
				return defined( 'WP_MCP_AI_PRO_VERSION' );
			}

			// Check for qrcode package (Pro addon).
			// This package should be bundled in Pro addon vendor directory.
			if ( 'qrcode' === $package && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				// Priority 1: Check if it's in Pro addon's vendor directory (production).
				$qrcode_vendor_path = WP_MCP_AI_PRO_PATH . 'assets/vendor/qrcode/lib/index.js';
				if ( file_exists( $qrcode_vendor_path ) ) {
					return true;
				}

				// Priority 2: Check the package.json existence as fallback.
				$qrcode_pkg_path = WP_MCP_AI_PRO_PATH . 'assets/vendor/qrcode/package.json';
				if ( file_exists( $qrcode_pkg_path ) ) {
					return true;
				}

				// Priority 3: Check if it's bundled into a Pro script.
				// QR code might be bundled into a specific tool bundle.
				$qrcode_bundle_path = WP_MCP_AI_PRO_PATH . 'bin/generate-qrcode.bundle.js';
				if ( file_exists( $qrcode_bundle_path ) ) {
					return true;
				}

				// Priority 4: Check Pro addon's node_modules (development only).
				$qrcode_node_path = WP_MCP_AI_PRO_PATH . 'node_modules/qrcode';
				if ( file_exists( $qrcode_node_path ) ) {
					return true;
				}

				// If Pro addon is active, assume qrcode is available.
				// This is more lenient for production deployments.
				return defined( 'WP_MCP_AI_PRO_VERSION' );
			}

			// Check for node-ensure package (Pro addon).
			// This is a lightweight shim package that's pre-packaged in vendor directory.
			if ( 'node-ensure' === $package && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				// Priority 1: Check if it's in Pro addon's vendor directory (production).
				$node_ensure_vendor_path = WP_MCP_AI_PRO_PATH . 'assets/vendor/node-ensure/index.js';
				if ( file_exists( $node_ensure_vendor_path ) ) {
					return true;
				}

				// Priority 2: Check the package.json existence as fallback.
				$node_ensure_pkg_path = WP_MCP_AI_PRO_PATH . 'assets/vendor/node-ensure/package.json';
				if ( file_exists( $node_ensure_pkg_path ) ) {
					return true;
				}

				// Priority 3: Check Pro addon's node_modules (development only).
				$node_ensure_node_path = WP_MCP_AI_PRO_PATH . 'node_modules/node-ensure';
				if ( file_exists( $node_ensure_node_path ) ) {
					return true;
				}

				// node-ensure is a lightweight shim that should always be available when Pro is active.
				// It's listed in package.json and copied to vendor directory during build.
				// However, it's version ^0.0.0 (a minimal package) and may not be physically present.
				// Used by pdf-parse's pdf.js library for async module loading pattern.
				// Returning true here is a pragmatic fallback for this special case.
				return defined( 'WP_MCP_AI_PRO_VERSION' );
			}

			// ===================================================================
			// PRIORITY 3: Fallback to node_modules (DEVELOPMENT ONLY)
			// Only check these if vendor files are not found
			// ===================================================================

			// Fallback: Check Pro node_modules (for development).
			if ( defined( 'WP_MCP_AI_PRO_PATH' ) ) {
				$pro_node_modules_path = WP_MCP_AI_PRO_PATH . 'node_modules/' . $package;
				if ( file_exists( $pro_node_modules_path ) ) {
					return true;
				}
			}

			// Check base node_modules (if present).
			$node_modules_path = WP_MCP_AI_PATH . 'node_modules/' . $package;
			return file_exists( $node_modules_path );
		}

		/**
		 * Render pro toolkit status section.
		 *
		 * @param array $status Pro toolkit status.
		 * @return void
		 */
		private static function render_pro_toolkit_status( $status ) {
			?>
			<h3><?php esc_html_e( 'Pro Toolkit Status', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th style="width: 40%;"><?php esc_html_e( 'Feature', 'nvdigital-open-operator-system-oos' ); ?></th>
						<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><strong><?php esc_html_e( 'Plugin Version', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
						<td><code><?php echo esc_html( $status['plugin_version'] ); ?></code></td>
					</tr>
					<tr>
						<td><strong><?php esc_html_e( 'Pro Dashboard', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
						<td>
							<span class="wp-mcp-ai-status-badge <?php echo esc_attr( $status['pro_dashboard_enabled'] ? 'enabled' : 'disabled' ); ?>">
								<?php echo $status['pro_dashboard_enabled'] ? esc_html__( 'Enabled', 'nvdigital-open-operator-system-oos' ) : esc_html__( 'Disabled', 'nvdigital-open-operator-system-oos' ); ?>
							</span>
						</td>
					</tr>
					<tr>
						<td><strong><?php esc_html_e( 'Base Version Mode', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
						<td>
							<span class="wp-mcp-ai-status-badge <?php echo esc_attr( $status['base_version'] ? 'active' : 'inactive' ); ?>">
								<?php echo $status['base_version'] ? esc_html__( 'Active (165 base tools)', 'nvdigital-open-operator-system-oos' ) : esc_html__( 'Inactive (519 total tools)', 'nvdigital-open-operator-system-oos' ); ?>
							</span>
						</td>
					</tr>
					<tr>
						<td><strong><?php esc_html_e( 'Debug Mode', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
						<td>
							<span class="wp-mcp-ai-status-badge <?php echo esc_attr( $status['debug_mode'] ? 'enabled' : 'disabled' ); ?>">
								<?php echo $status['debug_mode'] ? esc_html__( 'Enabled', 'nvdigital-open-operator-system-oos' ) : esc_html__( 'Disabled', 'nvdigital-open-operator-system-oos' ); ?>
							</span>
						</td>
					</tr>
					<tr>
						<td><strong><?php esc_html_e( 'PHP Version', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
						<td><code><?php echo esc_html( $status['php_version'] ); ?></code></td>
					</tr>
					<tr>
						<td><strong><?php esc_html_e( 'WordPress Version', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
						<td><code><?php echo esc_html( $status['wp_version'] ); ?></code></td>
					</tr>
				</tbody>
			</table>

			<h3><?php esc_html_e( 'Optional Integrations', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th style="width: 40%;"><?php esc_html_e( 'Integration', 'nvdigital-open-operator-system-oos' ); ?></th>
						<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					// Integration display names.
					$integration_names = array(
						'jetengine'      => __( 'JetEngine', 'nvdigital-open-operator-system-oos' ),
						'jetformbuilder' => __( 'JetFormBuilder', 'nvdigital-open-operator-system-oos' ),
						'woocommerce'    => __( 'WooCommerce', 'nvdigital-open-operator-system-oos' ),
						'elementor'      => __( 'Elementor', 'nvdigital-open-operator-system-oos' ),
						'rankmath'       => __( 'Rank Math', 'nvdigital-open-operator-system-oos' ),
						'wpcode'         => __( 'WPCode', 'nvdigital-open-operator-system-oos' ),
						'newsletter'     => __( 'Newsletter', 'nvdigital-open-operator-system-oos' ),
						'wpallimport'    => __( 'WP All Import', 'nvdigital-open-operator-system-oos' ),
						'wpallexport'    => __( 'WP All Export', 'nvdigital-open-operator-system-oos' ),
					);

					foreach ( $status['integrations'] as $integration => $is_active ) :
						$display_name = isset( $integration_names[ $integration ] ) ? $integration_names[ $integration ] : ucfirst( $integration );
						?>
						<tr>
							<td><strong><?php echo esc_html( $display_name ); ?></strong></td>
							<td>
								<span class="wp-mcp-ai-status-badge <?php echo esc_attr( $is_active ? 'active' : 'inactive' ); ?>">
									<?php echo $is_active ? esc_html__( 'Active', 'nvdigital-open-operator-system-oos' ) : esc_html__( 'Inactive', 'nvdigital-open-operator-system-oos' ); ?>
								</span>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php
		}

		/**
		 * Render individual pro toolkits status section.
		 *
		 * @param array $toolkit_status Individual toolkit status.
		 * @return void
		 */
		private static function render_individual_toolkits_status( $toolkit_status ) {
			?>
			<h3><?php esc_html_e( 'Individual Pro Toolkits', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th style="width: 40%;"><?php esc_html_e( 'Toolkit Name', 'nvdigital-open-operator-system-oos' ); ?></th>
						<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $toolkit_status as $setting_key => $toolkit_info ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $toolkit_info['name'] ); ?></strong></td>
							<td>
								<span class="wp-mcp-ai-status-badge <?php echo esc_attr( $toolkit_info['enabled'] ? 'enabled' : 'disabled' ); ?>">
									<?php echo $toolkit_info['enabled'] ? esc_html__( 'Enabled', 'nvdigital-open-operator-system-oos' ) : esc_html__( 'Disabled', 'nvdigital-open-operator-system-oos' ); ?>
								</span>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php
		}

		/**
		 * Render the Pro Settings page.
		 *
		 * @return void
		 */
		public static function render_page() {
			// Verify user capability.
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'nvdigital-open-operator-system-oos' ) );
			}

			$packages        = self::get_npm_packages();
			$composer        = self::get_composer_packages();
			$pro_status      = self::get_pro_toolkit_status();
			$toolkit_status  = self::get_individual_toolkit_status();
			$toolkit_details = self::get_toolkit_details();
			$total_packages  = count( $packages['dependencies'] ) + count( $packages['devDependencies'] ) + count( $packages['optionalDependencies'] );
			$total_composer  = count( $composer['require'] ) + count( $composer['require-dev'] );
			?>
			<div class="wrap wp-mcp-ai-pro-settings">
				<h1>
					<span class="dashicons dashicons-admin-settings"></span>
					<?php esc_html_e( 'Pro Settings & System Information', 'nvdigital-open-operator-system-oos' ); ?>
				</h1>

				<p class="description">
					<?php esc_html_e( 'View npm package status, pro toolkit configuration, and system information. This is a read-only display for monitoring your NV oOS installation.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>

				<?php if ( isset( $packages['error'] ) ) : ?>
					<div class="notice notice-info">
						<p>
							<strong><?php esc_html_e( 'NPM Package Information:', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<?php esc_html_e( 'Not available in this installation (package.json not found). This is normal for WordPress.org and production builds where development files are excluded.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
						<p style="margin: 5px 0 0 0;">
							<em><?php esc_html_e( 'Your plugin is fully functional. NPM package information is only needed for development purposes.', 'nvdigital-open-operator-system-oos' ); ?></em>
						</p>
					</div>
				<?php else : ?>
					<div class="notice notice-info">
						<p>
							<strong><?php esc_html_e( 'Project:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php echo esc_html( $packages['name'] ); ?> 
							<strong><?php esc_html_e( 'Version:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php echo esc_html( $packages['version'] ); ?>
							<strong style="margin-left: 20px;"><?php esc_html_e( 'Total NPM Packages:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php echo absint( $total_packages ); ?>
						</p>
					</div>
				<?php endif; ?>

				<div class="wp-mcp-ai-settings-columns">
					<!-- Pro Toolkit Status -->
					<div class="wp-mcp-ai-settings-column">
						<div class="wp-mcp-ai-settings-card">
							<?php self::render_pro_toolkit_status( $pro_status ); ?>
							
							<div style="margin-top: 30px;"></div>
							
							<?php self::render_individual_toolkits_status( $toolkit_status ); ?>

							<!-- Composer Packages (PHP Dependencies) -->
							<?php if ( ! isset( $composer['error'] ) && ! empty( $composer['require'] ) ) : ?>
								<div style="margin-top: 30px;"></div>
								
								<h3><?php esc_html_e( 'PHP Composer Packages', 'nvdigital-open-operator-system-oos' ); ?> <span class="count">(<?php echo absint( count( $composer['require'] ) ); ?>)</span></h3>
								<p class="description" style="margin-bottom: 15px;">
									<?php esc_html_e( 'Server-side PHP dependencies managed by Composer (Pro addon).', 'nvdigital-open-operator-system-oos' ); ?>
								</p>
								<?php self::render_composer_table( $composer['require'], __( 'Required PHP Packages', 'nvdigital-open-operator-system-oos' ) ); ?>
							<?php endif; ?>

							<!-- Optional Dependencies (NPM) -->
							<?php if ( ! isset( $packages['error'] ) && ! empty( $packages['optionalDependencies'] ) ) : ?>
								<div style="margin-top: 30px;"></div>
								
								<h3><?php esc_html_e( 'Optional Dependencies', 'nvdigital-open-operator-system-oos' ); ?> <span class="count">(<?php echo count( $packages['optionalDependencies'] ); ?>)</span></h3>
								<p class="description" style="margin-bottom: 15px;">
									<?php esc_html_e( 'Optional NPM packages for advanced features (LangChain, FFmpeg, Puppeteer).', 'nvdigital-open-operator-system-oos' ); ?>
								</p>
								<?php self::render_packages_table( $packages['optionalDependencies'], __( 'Optional NPM Packages', 'nvdigital-open-operator-system-oos' ) ); ?>
							<?php endif; ?>
						</div>
					</div>

					<!-- NPM Packages -->
					<div class="wp-mcp-ai-settings-column">
						<div class="wp-mcp-ai-settings-card">
							<h2><?php esc_html_e( 'NPM Packages', 'nvdigital-open-operator-system-oos' ); ?></h2>

							<?php if ( ! isset( $packages['error'] ) ) : ?>
								<?php self::render_packages_table( $packages['dependencies'], __( 'Production Dependencies', 'nvdigital-open-operator-system-oos' ) ); ?>
								
								<div style="margin-top: 30px;"></div>
								
								<?php self::render_packages_table( $packages['devDependencies'], __( 'Development Dependencies', 'nvdigital-open-operator-system-oos' ) ); ?>

								<div style="margin-top: 20px; padding: 15px; background: #f0f0f1; border-left: 4px solid #72aee6;">
									<p style="margin: 0;">
										<strong><?php esc_html_e( 'Note:', 'nvdigital-open-operator-system-oos' ); ?></strong>
										<?php esc_html_e( 'Package status is determined by checking for vendor files. Some packages may be installed in node_modules but not visible here after deployment.', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
								</div>
							<?php else : ?>
								<div style="padding: 20px; background: #f0f0f1; border-left: 4px solid #72aee6; text-align: center;">
									<p style="margin: 0 0 10px 0;">
										<span class="dashicons dashicons-info" style="font-size: 48px; width: 48px; height: 48px; color: #72aee6;"></span>
									</p>
									<p style="margin: 0 0 5px 0; font-weight: 600;">
										<?php esc_html_e( 'NPM Package Information Not Available', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
									<p style="margin: 0; color: #666;">
										<?php esc_html_e( 'This is normal for WordPress.org and production builds.', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
									<p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">
										<?php esc_html_e( 'Your plugin functionality is not affected. Package information is only for development reference.', 'nvdigital-open-operator-system-oos' ); ?>
									</p>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>

				<!-- Toolkit Details Section -->
				<div style="margin-top: 30px;">
					<h2><?php esc_html_e( 'Comprehensive Toolkit Information', 'nvdigital-open-operator-system-oos' ); ?></h2>
					<p class="description">
						<?php esc_html_e( 'Detailed view of each toolkit including status, dependencies, and tools.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
					
					<div class="wp-mcp-ai-toolkit-grid">
						<?php foreach ( $toolkit_details as $toolkit_id => $toolkit ) : ?>
							<?php self::render_toolkit_card( $toolkit_id, $toolkit ); ?>
						<?php endforeach; ?>
					</div>
				</div>


<!-- Embedded LLM (Client-Side) Section -->
<div style="margin-top: 30px;">
			<?php self::render_embedded_llm_section(); ?>
</div>

<!-- NPM Production: WebGPU/WebAssembly Section -->
<div style="margin-top: 30px;">
			<?php self::render_webgpu_webassembly_section(); ?>
</div>

<!-- Visual Workflow Builder Card -->
<div style="margin-top: 30px;">
			<?php self::render_visual_workflow_builder_card(); ?>
</div>

<!-- Telegram Mini App Template Builder Card -->
<div style="margin-top: 30px;">
			<?php self::render_tma_template_builder_card(); ?>
</div>

<!-- Pro Toolkit Features Card -->
<div style="margin-top: 30px;">
			<?php self::render_pro_toolkit_features_card(); ?>
</div>

				<div style="margin-top: 20px; padding: 15px; background: #fff; border: 1px solid #c3c4c7;">
					<h3><?php esc_html_e( 'About This Page', 'nvdigital-open-operator-system-oos' ); ?></h3>
					<p>
						<?php esc_html_e( 'This page provides a centralized view of your NV oOS Pro installation. It displays:', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'NPM package versions from package.json (read-only)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Pro Dashboard and feature flags status', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Optional integration status (JetEngine, WooCommerce, etc.)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'System information (PHP, WordPress versions)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Comprehensive toolkit details with dependencies and requirements', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
					<p>
						<em><?php esc_html_e( 'This is a lightweight, read-only display. No package management functionality is included to keep the plugin size minimal.', 'nvdigital-open-operator-system-oos' ); ?></em>
					</p>
				</div>
			</div>

			<?php
			// phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Small inline styles for pro settings page layout and styling on this admin page only
			?>
			<style>
				.wp-mcp-ai-pro-settings h1 .dashicons {
					font-size: 30px;
					width: 30px;
					height: 30px;
					vertical-align: middle;
					margin-right: 8px;
					color: #2271b1;
				}

				.wp-mcp-ai-settings-columns {
					display: grid;
					grid-template-columns: 1fr 1fr;
					gap: 20px;
					margin-top: 20px;
				}

				@media (max-width: 1280px) {
					.wp-mcp-ai-settings-columns {
						grid-template-columns: 1fr;
					}
				}

				.wp-mcp-ai-settings-card {
					background: #fff;
					border: 1px solid #c3c4c7;
					padding: 20px;
					box-shadow: 0 1px 1px rgba(0,0,0,.04);
				}

				.wp-mcp-ai-settings-card h2 {
					margin-top: 0;
					padding-bottom: 10px;
					border-bottom: 1px solid #c3c4c7;
				}

				.wp-mcp-ai-settings-card h3 {
					margin-top: 20px;
					margin-bottom: 10px;
					font-size: 14px;
					font-weight: 600;
					color: #1d2327;
				}

				.wp-mcp-ai-settings-card h3 .count {
					color: #646970;
					font-weight: 400;
				}

				.wp-mcp-ai-status-badge {
					display: inline-block;
					padding: 3px 10px;
					border-radius: 3px;
					font-size: 12px;
					font-weight: 600;
					text-transform: uppercase;
				}

				.wp-mcp-ai-status-badge.installed,
				.wp-mcp-ai-status-badge.enabled,
				.wp-mcp-ai-status-badge.active {
					background: #00a32a;
					color: #fff;
				}

				.wp-mcp-ai-status-badge.not-installed,
				.wp-mcp-ai-status-badge.disabled,
				.wp-mcp-ai-status-badge.inactive {
					background: #dba617;
					color: #fff;
				}

				.wp-mcp-ai-pro-settings .wp-list-table {
					margin-top: 10px;
				}

				.wp-mcp-ai-pro-settings code {
					background: #f0f0f1;
					padding: 2px 6px;
					border-radius: 3px;
					font-size: 13px;
				}

				/* Toolkit Grid */
				.wp-mcp-ai-toolkit-grid {
					display: grid;
					grid-template-columns: repeat(auto-fill, minmax(450px, 1fr));
					gap: 20px;
					margin-top: 20px;
				}

				@media (max-width: 768px) {
					.wp-mcp-ai-toolkit-grid {
						grid-template-columns: 1fr;
					}
				}

				/* Toolkit Cards */
				.wp-mcp-ai-toolkit-card {
					background: #fff;
					border: 1px solid #c3c4c7;
					padding: 20px;
					box-shadow: 0 1px 1px rgba(0,0,0,.04);
					border-radius: 4px;
				}

				.wp-mcp-ai-toolkit-card .toolkit-header h3 {
					margin: 0 0 10px 0;
					font-size: 16px;
					font-weight: 600;
					display: flex;
					align-items: center;
					gap: 8px;
					flex-wrap: wrap;
				}

				.wp-mcp-ai-toolkit-card .toolkit-description {
					margin: 0 0 15px 0;
					color: #646970;
					font-size: 14px;
				}

				/* Toolkit Status Badges */
				.toolkit-status-badge {
					display: inline-block;
					padding: 3px 10px;
					border-radius: 3px;
					font-size: 11px;
					font-weight: 600;
					text-transform: uppercase;
				}

				.toolkit-status-badge.operational {
					background: #00a32a;
					color: #fff;
				}

				.toolkit-status-badge.partial {
					background: #d63638;
					color: #fff;
				}

				.toolkit-status-badge.disabled {
					background: #646970;
					color: #fff;
				}

				/* Category Badges */
				.toolkit-category-badge {
					display: inline-block;
					padding: 3px 10px;
					border-radius: 3px;
					font-size: 11px;
					font-weight: 600;
					text-transform: uppercase;
				}

				.toolkit-category-badge.core {
					background: #2271b1;
					color: #fff;
				}

				.toolkit-category-badge.specialized {
					background: #8c7ae6;
					color: #fff;
				}

				.toolkit-category-badge.infrastructure {
					background: #50e3c2;
					color: #000;
				}

				/* Toolkit Warning */
				.toolkit-warning {
					background: #fcf0f1;
					border-left: 4px solid #d63638;
					padding: 12px;
					margin-bottom: 15px;
					display: flex;
					align-items: center;
					gap: 8px;
					font-size: 13px;
				}

				.toolkit-warning .dashicons {
					color: #d63638;
					flex-shrink: 0;
				}

				/* Toolkit Sections (Collapsible) */
				.toolkit-section {
					margin: 15px 0;
					border: 1px solid #e0e0e0;
					border-radius: 4px;
					overflow: hidden;
				}

				.toolkit-section summary {
					padding: 12px 15px;
					background: #f6f7f7;
					cursor: pointer;
					font-weight: 600;
					font-size: 13px;
					display: flex;
					justify-content: space-between;
					align-items: center;
					user-select: none;
				}

				.toolkit-section summary:hover {
					background: #e9eaeb;
				}

				.toolkit-section[open] summary {
					border-bottom: 1px solid #e0e0e0;
				}

				.toolkit-section .section-badge {
					display: inline-block;
					padding: 2px 8px;
					border-radius: 3px;
					font-size: 11px;
					font-weight: 600;
					text-transform: uppercase;
				}

				.toolkit-section .section-badge.ok {
					background: #00a32a;
					color: #fff;
				}

				.toolkit-section .section-badge.error {
					background: #d63638;
					color: #fff;
				}

				.toolkit-section .tools-count {
					color: #646970;
					font-weight: 400;
				}

				/* Toolkit Details Tables */
				.toolkit-details-table {
					width: 100%;
					border-collapse: collapse;
					margin: 0;
				}

				.toolkit-details-table thead th {
					background: #f9f9f9;
					padding: 10px 15px;
					text-align: left;
					font-size: 12px;
					font-weight: 600;
					border-bottom: 1px solid #e0e0e0;
				}

				.toolkit-details-table tbody td {
					padding: 10px 15px;
					border-bottom: 1px solid #f0f0f1;
					font-size: 13px;
				}

				.toolkit-details-table tbody tr:last-child td {
					border-bottom: none;
				}

				.toolkit-details-table .status-indicator {
					font-size: 16px;
					font-weight: bold;
				}

				.toolkit-details-table .status-indicator.available {
					color: #00a32a;
				}

				.toolkit-details-table .status-indicator.unavailable {
					color: #d63638;
				}

				.toolkit-details-table .status-source {
					font-size: 11px;
					font-weight: 500;
					color: #2271b1;
					margin-left: 4px;
					text-transform: uppercase;
				}

				/* Toolkit Tools List */
				.toolkit-tools-list {
					margin: 0;
					padding: 15px 15px 15px 40px;
					list-style: disc;
				}

				.toolkit-tools-list li {
					padding: 5px 0;
					font-size: 13px;
					color: #646970;
				}
			</style>
			<?php
		}

		/**
		 * Add Pro Settings page to Pro Dashboard menu.
		 *
		 * @return void
		 */
		/**
		 * Render Embedded LLM (Client-Side) section.
		 *
		 * @return void
		 */
		private static function render_embedded_llm_section() {
			// Get embedded LLM models.
			// All available models are listed. Some models support function calling, others are for general chat.
			$models = array(
				'Hermes-2-Pro-Llama-3-8B-q4f16_1-MLC' => array(
					'name'        => 'Hermes 2 Pro Llama 3 8B',
					'size'        => '~4.5GB',
					'description' => 'Best for function calling and tool use',
					'context'     => '8K tokens',
					'license'     => 'Apache 2.0',
					'recommended' => true,
				),
				'Qwen2.5-7B-Instruct-q4f16_1-MLC'     => array(
					'name'        => 'Qwen2.5 7B Instruct',
					'size'        => '~4.5GB',
					'description' => 'Advanced multilingual model with function calling',
					'context'     => '32K tokens',
					'license'     => 'Apache 2.0',
					'recommended' => false,
				),
				'Phi-3.5-mini-instruct-q4f16_1-MLC'   => array(
					'name'        => 'Phi-3.5 Mini Instruct',
					'size'        => '~2.5GB',
					'description' => 'Smaller Microsoft model, supports function calling',
					'context'     => '128K tokens',
					'license'     => 'MIT',
					'recommended' => false,
				),
				'Llama-3.2-3B-Instruct-q4f16_1-MLC'   => array(
					'name'        => 'Llama 3.2 3B Instruct',
					'size'        => '~2GB',
					'description' => 'Balanced model for general chat (does not support function calling)',
					'context'     => '128K tokens',
					'license'     => 'Llama 3.2 Community License',
					'recommended' => false,
				),
				'Qwen2.5-1.5B-Instruct-q4f16_1-MLC'   => array(
					'name'        => 'Qwen2.5 1.5B Instruct',
					'size'        => '~1GB',
					'description' => 'Compact multilingual model with function calling support',
					'context'     => '32K tokens',
					'license'     => 'Apache 2.0',
					'recommended' => false,
				),
				'Llama-3.2-1B-Instruct-q4f16_1-MLC'   => array(
					'name'        => 'Llama 3.2 1B Instruct',
					'size'        => '~800MB',
					'description' => 'Fast, lightweight model for basic chat (does not support function calling)',
					'context'     => '128K tokens',
					'license'     => 'Llama 3.2 Community License',
					'recommended' => false,
				),
				'Qwen2.5-0.5B-Instruct-q4f16_1-MLC'   => array(
					'name'        => 'Qwen2.5 0.5B Instruct',
					'size'        => '~400MB',
					'description' => 'Ultra-compact model for simple responses (does not support function calling)',
					'context'     => '32K tokens',
					'license'     => 'Apache 2.0',
					'recommended' => false,
				),
			);
			?>
<div class="wp-mcp-ai-settings-card">
<h2>
<span class="dashicons dashicons-smartphone"></span>
			<?php esc_html_e( 'Embedded LLM (Client-Side) - Pro Feature', 'nvdigital-open-operator-system-oos' ); ?>
</h2>

<div class="notice notice-success inline" style="margin: 15px 0;">
<p>
<strong><?php esc_html_e( '✓ Everything Pre-Packaged', 'nvdigital-open-operator-system-oos' ); ?></strong><br>
			<?php esc_html_e( 'Client-side LLM inference using WebLLM. No server installation required. Runs in user browser with WebGPU/WebAssembly.', 'nvdigital-open-operator-system-oos' ); ?>
</p>
</div>

<div style="margin: 20px 0;">
<h3><?php esc_html_e( 'NPM Dependencies', 'nvdigital-open-operator-system-oos' ); ?></h3>
<table class="wp-list-table widefat fixed striped" style="max-width: 800px;">
<thead>
<tr>
<th style="width: 40%;"><?php esc_html_e( 'Package', 'nvdigital-open-operator-system-oos' ); ?></th>
<th style="width: 20%;"><?php esc_html_e( 'Version', 'nvdigital-open-operator-system-oos' ); ?></th>
<th style="width: 40%;"><?php esc_html_e( 'Purpose', 'nvdigital-open-operator-system-oos' ); ?></th>
</tr>
</thead>
<tbody>
<tr>
<td><code>@mlc-ai/web-llm</code></td>
<td>^0.2.80</td>
<td><?php esc_html_e( 'Core WebLLM library for browser LLM inference', 'nvdigital-open-operator-system-oos' ); ?></td>
</tr>
</tbody>
</table>
</div>

<div style="margin: 20px 0;">
<h3><?php esc_html_e( 'Available Models', 'nvdigital-open-operator-system-oos' ); ?></h3>
<p class="description">
			<?php esc_html_e( 'All models are pre-configured and download automatically to browser cache when first used.', 'nvdigital-open-operator-system-oos' ); ?>
</p>

<div class="wp-mcp-ai-model-cards" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; margin-top: 15px;">
			<?php foreach ( $models as $model_id => $model ) : ?>
<div class="wp-mcp-ai-model-card" style="border: 1px solid <?php echo esc_attr( $model['recommended'] ? '#00a32a' : '#c3c4c7' ); ?>; padding: 15px; background: #fff; border-radius: 4px;">
<div style="display: flex; align-items: start; justify-content: space-between; margin-bottom: 10px;">
<h4 style="margin: 0; font-size: 14px;">
				<?php echo esc_html( $model['name'] ); ?>
				<?php if ( $model['recommended'] ) : ?>
<span class="dashicons dashicons-star-filled" style="color: #f0b849; font-size: 16px;" title="<?php esc_attr_e( 'Recommended', 'nvdigital-open-operator-system-oos' ); ?>"></span>
<?php endif; ?>
</h4>
<span style="background: #f0f0f1; padding: 3px 8px; border-radius: 3px; font-size: 12px; font-weight: bold;">
				<?php echo esc_html( $model['size'] ); ?>
</span>
</div>

<p style="margin: 10px 0; font-size: 13px; color: #50575e;">
				<?php echo esc_html( $model['description'] ); ?>
</p>

<div style="display: flex; gap: 15px; margin-top: 10px; font-size: 12px; color: #646970;">
<div>
<strong><?php esc_html_e( 'Context:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				<?php echo esc_html( $model['context'] ); ?>
</div>
<div>
<strong><?php esc_html_e( 'License:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				<?php echo esc_html( $model['license'] ); ?>
</div>
</div>

<div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #f0f0f1;">
<code style="font-size: 11px; background: #f6f7f7; padding: 4px 6px; display: block; word-break: break-all;">
				<?php echo esc_html( $model_id ); ?>
</code>
</div>
</div>
<?php endforeach; ?>
</div>
</div>

<div style="margin: 20px 0; padding: 15px; background: #f0f6fc; border-left: 4px solid #0073aa;">
<h4 style="margin-top: 0;"><?php esc_html_e( 'Browser Requirements', 'nvdigital-open-operator-system-oos' ); ?></h4>
<ul style="margin: 10px 0 0 20px;">
<li><?php esc_html_e( 'WebGPU support (Chrome 113+, Edge 113+, Safari 18+)', 'nvdigital-open-operator-system-oos' ); ?></li>
<li><?php esc_html_e( 'Automatic fallback to WebAssembly (CPU) if GPU unavailable', 'nvdigital-open-operator-system-oos' ); ?></li>
<li><?php esc_html_e( 'Models cached in browser IndexedDB (first load takes time, subsequent loads instant)', 'nvdigital-open-operator-system-oos' ); ?></li>
<li><?php esc_html_e( 'No server resources used - all inference runs in user browser', 'nvdigital-open-operator-system-oos' ); ?></li>
</ul>
</div>

<div style="margin: 20px 0; padding: 15px; background: #fff; border: 1px solid #c3c4c7;">
<h4 style="margin-top: 0;"><?php esc_html_e( 'How to Enable', 'nvdigital-open-operator-system-oos' ); ?></h4>
<ol style="margin: 10px 0 0 20px;">
<li>
			<?php
			printf(
			/* translators: %s: settings page URL */
				esc_html__( 'Go to %s', 'nvdigital-open-operator-system-oos' ),
				'<a href="' . esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=providers&subtab=embedded' ) ) . '"><strong>' . esc_html__( 'Settings → Providers → Embedded LLM', 'nvdigital-open-operator-system-oos' ) . '</strong></a>'
			);
			?>
</li>
<li><?php esc_html_e( 'Check "Enable client-side embedded language models (Pro)"', 'nvdigital-open-operator-system-oos' ); ?></li>
<li><?php esc_html_e( 'Select a default model (Llama 3.2 1B recommended)', 'nvdigital-open-operator-system-oos' ); ?></li>
<li><?php esc_html_e( 'Save settings', 'nvdigital-open-operator-system-oos' ); ?></li>
<li><?php esc_html_e( 'When users chat with assistants using "embedded" provider, models download automatically to their browser', 'nvdigital-open-operator-system-oos' ); ?></li>
</ol>
</div>
</div>
			<?php
		}

		/**
		 * Render WebGPU/WebAssembly NPM Production section.
		 *
		 * Displays production-ready NPM packages for WebGPU/WebAssembly deployment.
		 *
		 * @since 1.1.0
		 * @return void
		 */
		private static function render_webgpu_webassembly_section() {
			?>
<div class="wp-mcp-ai-settings-card">
	<h2>
		<span class="dashicons dashicons-performance"></span>
			<?php esc_html_e( 'NPM Production: WebGPU/WebAssembly', 'nvdigital-open-operator-system-oos' ); ?>
	</h2>

	<div class="notice notice-info inline" style="margin: 15px 0;">
		<p>
			<strong><?php esc_html_e( 'Production-Ready Browser AI', 'nvdigital-open-operator-system-oos' ); ?></strong><br>
			<?php esc_html_e( 'Leverage cutting-edge WebGPU and WebAssembly technologies for high-performance AI inference directly in the browser. No server resources required.', 'nvdigital-open-operator-system-oos' ); ?>
		</p>
	</div>

	<div style="margin: 20px 0;">
		<h3><?php esc_html_e( 'Core NPM Package', 'nvdigital-open-operator-system-oos' ); ?></h3>
		<table class="wp-list-table widefat fixed striped" style="max-width: 900px;">
			<thead>
				<tr>
					<th style="width: 30%;"><?php esc_html_e( 'Package', 'nvdigital-open-operator-system-oos' ); ?></th>
					<th style="width: 15%;"><?php esc_html_e( 'Version', 'nvdigital-open-operator-system-oos' ); ?></th>
					<th style="width: 55%;"><?php esc_html_e( 'Description', 'nvdigital-open-operator-system-oos' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>@mlc-ai/web-llm</code></td>
					<td><code>^0.2.80</code></td>
					<td><?php esc_html_e( 'High-performance browser-based LLM inference using WebGPU with automatic WebAssembly fallback', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<div style="margin: 20px 0;">
		<h3><?php esc_html_e( 'Technology Stack', 'nvdigital-open-operator-system-oos' ); ?></h3>
		<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
			<!-- WebGPU Card -->
			<div style="border: 1px solid #72aee6; padding: 15px; background: #f0f6fc; border-radius: 4px;">
				<h4 style="margin: 0 0 10px 0; color: #0073aa;">
					<span class="dashicons dashicons-performance"></span>
					<?php esc_html_e( 'WebGPU (Preferred)', 'nvdigital-open-operator-system-oos' ); ?>
				</h4>
				<ul style="margin: 0 0 0 20px; font-size: 13px;">
					<li><?php esc_html_e( 'Hardware-accelerated GPU compute', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Up to 100x faster than CPU', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Chrome 113+, Edge 113+, Safari 18+', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Best for real-time inference', 'nvdigital-open-operator-system-oos' ); ?></li>
				</ul>
			</div>

			<!-- WebAssembly Card -->
			<div style="border: 1px solid #c3c4c7; padding: 15px; background: #f6f7f7; border-radius: 4px;">
				<h4 style="margin: 0 0 10px 0; color: #50575e;">
					<span class="dashicons dashicons-admin-generic"></span>
					<?php esc_html_e( 'WebAssembly (Fallback)', 'nvdigital-open-operator-system-oos' ); ?>
				</h4>
				<ul style="margin: 0 0 0 20px; font-size: 13px;">
					<li><?php esc_html_e( 'CPU-based computation', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Automatic fallback if no GPU', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Universal browser support', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Slower but reliable', 'nvdigital-open-operator-system-oos' ); ?></li>
				</ul>
			</div>
		</div>
	</div>

	<div style="margin: 20px 0; padding: 15px; background: #fff3cd; border-left: 4px solid #f0b849;">
		<h4 style="margin-top: 0;">
			<span class="dashicons dashicons-warning"></span>
			<?php esc_html_e( 'Production Deployment Notes', 'nvdigital-open-operator-system-oos' ); ?>
		</h4>
		<ul style="margin: 10px 0 0 20px;">
			<li><?php esc_html_e( 'WebGPU requires HTTPS in production (security requirement)', 'nvdigital-open-operator-system-oos' ); ?></li>
			<li><?php esc_html_e( 'Models are cached in browser IndexedDB (persistent across sessions)', 'nvdigital-open-operator-system-oos' ); ?></li>
			<li><?php esc_html_e( 'First model download per user takes 30-60s depending on model size', 'nvdigital-open-operator-system-oos' ); ?></li>
			<li><?php esc_html_e( 'Subsequent loads are instant (served from cache)', 'nvdigital-open-operator-system-oos' ); ?></li>
			<li><?php esc_html_e( 'No server resources consumed - all inference runs client-side', 'nvdigital-open-operator-system-oos' ); ?></li>
			<li><?php esc_html_e( 'Fully GDPR compliant - data never leaves user device', 'nvdigital-open-operator-system-oos' ); ?></li>
		</ul>
	</div>

	<div style="margin: 20px 0; padding: 15px; background: #d5f4e6; border-left: 4px solid #00a32a;">
		<h4 style="margin-top: 0;">
			<span class="dashicons dashicons-yes-alt"></span>
			<?php esc_html_e( 'Benefits for Production', 'nvdigital-open-operator-system-oos' ); ?>
		</h4>
		<ul style="margin: 10px 0 0 20px;">
			<li><strong><?php esc_html_e( 'Zero API Costs:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'No OpenAI/Anthropic charges', 'nvdigital-open-operator-system-oos' ); ?></li>
			<li><strong><?php esc_html_e( 'Infinite Scale:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Each user runs inference on their own device', 'nvdigital-open-operator-system-oos' ); ?></li>
			<li><strong><?php esc_html_e( 'Privacy-First:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Data never transmitted to servers', 'nvdigital-open-operator-system-oos' ); ?></li>
			<li><strong><?php esc_html_e( 'Offline Capable:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Works without internet after initial download', 'nvdigital-open-operator-system-oos' ); ?></li>
			<li><strong><?php esc_html_e( 'Low Latency:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'No network round-trips for inference', 'nvdigital-open-operator-system-oos' ); ?></li>
		</ul>
	</div>

	<div style="margin: 20px 0;">
		<h3><?php esc_html_e( 'Browser Compatibility Matrix', 'nvdigital-open-operator-system-oos' ); ?></h3>
		<table class="wp-list-table widefat fixed striped" style="max-width: 800px;">
			<thead>
				<tr>
					<th style="width: 25%;"><?php esc_html_e( 'Browser', 'nvdigital-open-operator-system-oos' ); ?></th>
					<th style="width: 25%;"><?php esc_html_e( 'WebGPU', 'nvdigital-open-operator-system-oos' ); ?></th>
					<th style="width: 25%;"><?php esc_html_e( 'WebAssembly', 'nvdigital-open-operator-system-oos' ); ?></th>
					<th style="width: 25%;"><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><strong>Chrome 113+</strong></td>
					<td><span style="color: #00a32a;">✓</span></td>
					<td><span style="color: #00a32a;">✓</span></td>
					<td><span class="wp-mcp-ai-status-badge enabled"><?php esc_html_e( 'Fully Supported', 'nvdigital-open-operator-system-oos' ); ?></span></td>
				</tr>
				<tr>
					<td><strong>Edge 113+</strong></td>
					<td><span style="color: #00a32a;">✓</span></td>
					<td><span style="color: #00a32a;">✓</span></td>
					<td><span class="wp-mcp-ai-status-badge enabled"><?php esc_html_e( 'Fully Supported', 'nvdigital-open-operator-system-oos' ); ?></span></td>
				</tr>
				<tr>
					<td><strong>Safari 18+</strong></td>
					<td><span style="color: #00a32a;">✓</span></td>
					<td><span style="color: #00a32a;">✓</span></td>
					<td><span class="wp-mcp-ai-status-badge enabled"><?php esc_html_e( 'Fully Supported', 'nvdigital-open-operator-system-oos' ); ?></span></td>
				</tr>
				<tr>
					<td><strong>Firefox</strong></td>
					<td><span style="color: #f0b849;">⚠</span></td>
					<td><span style="color: #00a32a;">✓</span></td>
					<td><span class="wp-mcp-ai-status-badge active"><?php esc_html_e( 'WASM Only', 'nvdigital-open-operator-system-oos' ); ?></span></td>
				</tr>
				<tr>
					<td><strong>Mobile Browsers</strong></td>
					<td><span style="color: #f0b849;">⚠</span></td>
					<td><span style="color: #00a32a;">✓</span></td>
					<td><span class="wp-mcp-ai-status-badge active"><?php esc_html_e( 'WASM Only', 'nvdigital-open-operator-system-oos' ); ?></span></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
			<?php
		}

		/**
		 * Render Visual Workflow Builder card.
		 *
		 * Displays information about the React-based visual workflow builder Pro feature.
		 *
		 * @since 1.2.0
		 * @return void
		 */
		private static function render_visual_workflow_builder_card() {
			?>
<div class="wp-mcp-ai-settings-card">
	<h2>
		<span class="dashicons dashicons-networking" style="color: #2271b1;"></span>
			<?php esc_html_e( 'Visual Workflow Builder', 'nvdigital-open-operator-system-oos' ); ?>
		<span class="pro-badge" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 600; margin-left: 10px; text-transform: uppercase; letter-spacing: 0.5px;">PRO</span>
	</h2>

	<div class="notice notice-info inline" style="margin: 15px 0;">
		<p>
			<strong><?php esc_html_e( 'Modern React-Based Workflow Editor', 'nvdigital-open-operator-system-oos' ); ?></strong><br>
			<?php esc_html_e( 'Professional drag-and-drop workflow builder powered by React Flow. Create complex automation workflows visually without writing code.', 'nvdigital-open-operator-system-oos' ); ?>
		</p>
	</div>

	<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 20px 0;">
		
		<!-- Key Features -->
		<div style="border: 1px solid #2271b1; padding: 15px; background: #f0f6fc; border-radius: 4px;">
			<h3 style="margin: 0 0 15px 0; color: #2271b1;">
				<span class="dashicons dashicons-star-filled"></span>
				<?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<ul style="margin: 0; font-size: 13px; line-height: 1.8;">
				<li><strong><?php esc_html_e( 'Visual Canvas:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Zoom, pan, and navigate large workflows', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Drag & Drop:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Intuitive step creation and reordering', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Command Palette:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Searchable library of 250+ commands', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Form-Based Config:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'No more JSON editing! Visual forms', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Real-Time Validation:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Instant feedback as you build', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Undo/Redo:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Full history support', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Accessibility:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'WCAG 2.1 compliant, keyboard shortcuts', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Touch Support:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Works on mobile and tablets', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>
		</div>

		<!-- Technology Stack -->
		<div style="border: 1px solid #00a32a; padding: 15px; background: #f0f9f4; border-radius: 4px;">
			<h3 style="margin: 0 0 15px 0; color: #00a32a;">
				<span class="dashicons dashicons-admin-tools"></span>
				<?php esc_html_e( 'Technology Stack', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<table style="width: 100%; font-size: 13px;">
				<tr>
					<td style="padding: 5px 0;"><strong><?php esc_html_e( 'Framework:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
					<td style="padding: 5px 0;"><code>React 18.2</code></td>
				</tr>
				<tr>
					<td style="padding: 5px 0;"><strong><?php esc_html_e( 'Workflow Canvas:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
					<td style="padding: 5px 0;"><code>React Flow 11.10</code></td>
				</tr>
				<tr>
					<td style="padding: 5px 0;"><strong><?php esc_html_e( 'Drag & Drop:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
					<td style="padding: 5px 0;"><code>dnd-kit 6.1</code></td>
				</tr>
				<tr>
					<td style="padding: 5px 0;"><strong><?php esc_html_e( 'UI Components:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
					<td style="padding: 5px 0;"><code>@wordpress/components</code></td>
				</tr>
				<tr>
					<td style="padding: 5px 0;"><strong><?php esc_html_e( 'State Management:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
					<td style="padding: 5px 0;"><code>@wordpress/data</code></td>
				</tr>
				<tr>
					<td style="padding: 5px 0;"><strong><?php esc_html_e( 'Build Tools:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
					<td style="padding: 5px 0;"><code>@wordpress/scripts</code></td>
				</tr>
			</table>
		</div>
	</div>

	<div style="margin: 20px 0;">
		<h3><?php esc_html_e( 'npm Packages (Production)', 'nvdigital-open-operator-system-oos' ); ?></h3>
		<table class="wp-list-table widefat fixed striped" style="max-width: 900px;">
			<thead>
				<tr>
					<th style="width: 35%;"><?php esc_html_e( 'Package', 'nvdigital-open-operator-system-oos' ); ?></th>
					<th style="width: 15%;"><?php esc_html_e( 'Version', 'nvdigital-open-operator-system-oos' ); ?></th>
					<th style="width: 50%;"><?php esc_html_e( 'Purpose', 'nvdigital-open-operator-system-oos' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>react</code></td>
					<td><code>^18.2.0</code></td>
					<td><?php esc_html_e( 'Core UI framework for building interactive interfaces', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>react-dom</code></td>
					<td><code>^18.2.0</code></td>
					<td><?php esc_html_e( 'DOM rendering engine for React applications', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>reactflow</code></td>
					<td><code>^11.10.4</code></td>
					<td><?php esc_html_e( 'Visual workflow canvas - industry standard (MIT license)', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>@dnd-kit/core</code></td>
					<td><code>^6.1.0</code></td>
					<td><?php esc_html_e( 'Modern drag-and-drop toolkit with accessibility', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>@dnd-kit/sortable</code></td>
					<td><code>^8.0.0</code></td>
					<td><?php esc_html_e( 'Sortable list support for command palette', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>@dnd-kit/utilities</code></td>
					<td><code>^3.2.2</code></td>
					<td><?php esc_html_e( 'Helper utilities for drag-and-drop operations', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<div style="margin: 20px 0;">
		<h3><?php esc_html_e( 'npm Packages (Development)', 'nvdigital-open-operator-system-oos' ); ?></h3>
		<table class="wp-list-table widefat fixed striped" style="max-width: 900px;">
			<thead>
				<tr>
					<th style="width: 35%;"><?php esc_html_e( 'Package', 'nvdigital-open-operator-system-oos' ); ?></th>
					<th style="width: 15%;"><?php esc_html_e( 'Version', 'nvdigital-open-operator-system-oos' ); ?></th>
					<th style="width: 50%;"><?php esc_html_e( 'Purpose', 'nvdigital-open-operator-system-oos' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>@wordpress/scripts</code></td>
					<td><code>^27.0.0</code></td>
					<td><?php esc_html_e( 'Official WordPress build tooling (webpack, babel, eslint)', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>@wordpress/components</code></td>
					<td><code>^27.0.0</code></td>
					<td><?php esc_html_e( 'WordPress UI component library for consistent design', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>@wordpress/data</code></td>
					<td><code>^9.0.0</code></td>
					<td><?php esc_html_e( 'Redux-based state management for WordPress', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>@wordpress/i18n</code></td>
					<td><code>^4.0.0</code></td>
					<td><?php esc_html_e( 'Internationalization support for translations', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>@wordpress/element</code></td>
					<td><code>^5.0.0</code></td>
					<td><?php esc_html_e( 'WordPress abstraction over React', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
				<tr>
					<td><code>@wordpress/hooks</code></td>
					<td><code>^3.0.0</code></td>
					<td><?php esc_html_e( 'WordPress hooks system for extensibility', 'nvdigital-open-operator-system-oos' ); ?></td>
				</tr>
			</tbody>
		</table>
		<p class="description" style="margin-top: 10px;">
			<strong><?php esc_html_e( 'Note:', 'nvdigital-open-operator-system-oos' ); ?></strong>
			<?php esc_html_e( 'Development packages are NOT included in the plugin distribution. They are only used during the build process.', 'nvdigital-open-operator-system-oos' ); ?>
		</p>
	</div>

	<div style="margin: 20px 0; padding: 15px; background: #fff3cd; border-left: 4px solid #f0b849;">
		<h3 style="margin: 0 0 10px 0;">
			<span class="dashicons dashicons-info"></span>
			<?php esc_html_e( 'Build Information', 'nvdigital-open-operator-system-oos' ); ?>
		</h3>
		<table style="width: 100%; font-size: 13px;">
			<tr>
				<td style="padding: 5px 0; width: 30%;"><strong><?php esc_html_e( 'Build Command:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
				<td style="padding: 5px 0;"><code>npm run build:pro</code></td>
			</tr>
			<tr>
				<td style="padding: 5px 0;"><strong><?php esc_html_e( 'Output Location:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
				<td style="padding: 5px 0;"><code>build/workflow-builder/</code></td>
			</tr>
			<tr>
				<td style="padding: 5px 0;"><strong><?php esc_html_e( 'Bundle Size:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
				<td style="padding: 5px 0;">~200-300KB (minified & optimized)</td>
			</tr>
			<tr>
				<td style="padding: 5px 0;"><strong><?php esc_html_e( 'Compilation:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
				<td style="padding: 5px 0;">Webpack + Babel (via @wordpress/scripts)</td>
			</tr>
			<tr>
				<td style="padding: 5px 0;"><strong><?php esc_html_e( 'Pre-Built:', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
				<td style="padding: 5px 0;">✅ <?php esc_html_e( 'Yes - Committed to repository', 'nvdigital-open-operator-system-oos' ); ?></td>
			</tr>
		</table>
	</div>

	<div style="margin: 20px 0; padding: 15px; background: #f0f6fc; border-left: 4px solid #2271b1;">
		<h3 style="margin: 0 0 10px 0;">
			<span class="dashicons dashicons-admin-settings"></span>
			<?php esc_html_e( 'Usage', 'nvdigital-open-operator-system-oos' ); ?>
		</h3>
		<p style="margin: 0 0 10px 0;">
			<strong><?php esc_html_e( 'Location:', 'nvdigital-open-operator-system-oos' ); ?></strong>
			<?php esc_html_e( 'NV oOS → Workflows (Pro version only)', 'nvdigital-open-operator-system-oos' ); ?>
		</p>
		<p style="margin: 0 0 10px 0;">
			<strong><?php esc_html_e( 'Requirements:', 'nvdigital-open-operator-system-oos' ); ?></strong>
			<?php esc_html_e( 'Pro version of the plugin', 'nvdigital-open-operator-system-oos' ); ?>
		</p>
		<p style="margin: 0;">
			<strong><?php esc_html_e( 'Browser Support:', 'nvdigital-open-operator-system-oos' ); ?></strong>
			<?php esc_html_e( 'Modern browsers (Chrome, Firefox, Safari, Edge - latest 2 versions)', 'nvdigital-open-operator-system-oos' ); ?>
		</p>
	</div>

	<div style="margin: 20px 0;">
		<h3><?php esc_html_e( 'Why These Packages?', 'nvdigital-open-operator-system-oos' ); ?></h3>
		<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
			
			<div style="padding: 15px; background: #f9f9f9; border-left: 3px solid #2271b1;">
				<h4 style="margin: 0 0 8px 0; color: #2271b1;"><?php esc_html_e( 'React Flow', 'nvdigital-open-operator-system-oos' ); ?></h4>
				<p style="margin: 0; font-size: 13px;">
					<?php esc_html_e( 'Industry standard for workflow builders. Used by Stripe, Typeform, and thousands of production apps. 18K+ GitHub stars, MIT license.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
			</div>

			<div style="padding: 15px; background: #f9f9f9; border-left: 3px solid #00a32a;">
				<h4 style="margin: 0 0 8px 0; color: #00a32a;"><?php esc_html_e( 'dnd-kit', 'nvdigital-open-operator-system-oos' ); ?></h4>
				<p style="margin: 0; font-size: 13px;">
					<?php esc_html_e( 'Modern drag-and-drop with built-in accessibility. Keyboard support, screen readers, touch-friendly. Zero dependencies, performant.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
			</div>

			<div style="padding: 15px; background: #f9f9f9; border-left: 3px solid #f0b849;">
				<h4 style="margin: 0 0 8px 0; color: #f0b849;"><?php esc_html_e( '@wordpress/scripts', 'nvdigital-open-operator-system-oos' ); ?></h4>
				<p style="margin: 0; font-size: 13px;">
					<?php esc_html_e( 'Official WordPress tooling ensures compatibility and follows WordPress standards. Zero-config webpack, babel, and eslint.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
			</div>
		</div>
	</div>
</div>
			<?php
		}

		/**
		 * Render Telegram Mini App Template Builder card.
		 *
		 * Displayed on the Pro Settings page alongside the Visual Workflow Builder card.
		 * Documents the technology stack, npm packages, React Cosmos fixtures, build
		 * information, and links to the Chat Channels settings page for live configuration.
		 *
		 * @since 1.1.3
		 * @return void
		 */
		private static function render_tma_template_builder_card() {
			$active_template = get_option( 'wp_mcp_ai_telegram_mini_app_template', 'default' );
			$mini_app_url    = rest_url( 'mcp-ai/v1/telegram-mini-app' );

			$chat_channels_url    = admin_url( 'admin.php?page=wp-mcp-ai-chat-channels-toolkit-settings&tab=mini_app_builder' );
			$chat_channels_config = admin_url( 'admin.php?page=wp-mcp-ai-chat-channels-toolkit-settings&tab=configuration' );
			?>
<div class="wp-mcp-ai-settings-card">
	<h2>
		<span class="dashicons dashicons-smartphone" style="color: #2481cc;"></span>
			<?php esc_html_e( 'Telegram Mini App Template Builder', 'nvdigital-open-operator-system-oos' ); ?>
		<span class="pro-badge" style="background: linear-gradient(135deg, #2481cc 0%, #1565c0 100%); color: white; padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 600; margin-left: 10px; text-transform: uppercase; letter-spacing: 0.5px;">PRO</span>
	</h2>

	<div class="notice notice-info inline" style="margin: 15px 0;">
		<p>
			<strong><?php esc_html_e( 'Per-Bot Mini App Theming with Live Preview', 'nvdigital-open-operator-system-oos' ); ?></strong><br>
			<?php esc_html_e( 'Choose from 6 pre-built templates optimized for different Pro toolkits. Each bot connection can override the global default. Drag-to-reorder cards and live iframe preview — all bundled with the plugin, no additional setup required.', 'nvdigital-open-operator-system-oos' ); ?>
		</p>
	</div>

	<!-- Status row -->
	<table class="form-table" style="margin-bottom: 0;">
		<tr>
			<th scope="row" style="padding: 8px 10px 8px 0; width: 220px;"><?php esc_html_e( 'Active Global Template', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td style="padding: 8px 0;">
				<code><?php echo esc_html( $active_template ); ?></code>
				&nbsp;
				<a href="<?php echo esc_url( $chat_channels_url ); ?>" class="button button-small">
					<?php esc_html_e( 'Change Template →', 'nvdigital-open-operator-system-oos' ); ?>
				</a>
			</td>
		</tr>
		<tr>
			<th scope="row" style="padding: 8px 10px 8px 0;"><?php esc_html_e( 'Mini App URL', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td style="padding: 8px 0;">
				<input type="text" readonly value="<?php echo esc_url( $mini_app_url ); ?>"
					onclick="this.select();" class="large-text code"
					style="max-width:500px; background:#f0f0f0;" />
			</td>
		</tr>
	</table>

	<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 20px 0;">

		<!-- Pre-built Templates -->
		<div style="border: 1px solid #2481cc; padding: 15px; background: #f0f6fc; border-radius: 4px;">
			<h3 style="margin: 0 0 12px 0; color: #2481cc;">
				<span class="dashicons dashicons-layout"></span>
				<?php esc_html_e( '6 Pre-Built Templates', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<ul style="margin: 0; font-size: 13px; line-height: 2;">
				<li>📋 <strong><?php esc_html_e( 'Content Manager', 'nvdigital-open-operator-system-oos' ); ?></strong> — <?php esc_html_e( 'Default full-featured CMS', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li>💬 <strong><?php esc_html_e( 'AI Chat', 'nvdigital-open-operator-system-oos' ); ?></strong> — <?php esc_html_e( 'Clean conversational interface', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li>🛒 <strong><?php esc_html_e( 'E-Commerce', 'nvdigital-open-operator-system-oos' ); ?></strong> — <?php esc_html_e( 'WooCommerce shop assistant', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li>👥 <strong><?php esc_html_e( 'CRM Assistant', 'nvdigital-open-operator-system-oos' ); ?></strong> — <?php esc_html_e( 'Contact &amp; pipeline management', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li>📊 <strong><?php esc_html_e( 'Analytics Dashboard', 'nvdigital-open-operator-system-oos' ); ?></strong> — <?php esc_html_e( 'Chart.js visualisations', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li>📅 <strong><?php esc_html_e( 'Calendar Booking', 'nvdigital-open-operator-system-oos' ); ?></strong> — <?php esc_html_e( 'Appointment scheduling', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>
		</div>

		<!-- Technology Stack -->
		<div style="border: 1px solid #00a32a; padding: 15px; background: #f0f9f4; border-radius: 4px;">
			<h3 style="margin: 0 0 12px 0; color: #00a32a;">
				<span class="dashicons dashicons-admin-tools"></span>
				<?php esc_html_e( 'Technology Stack', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<table style="width: 100%; font-size: 13px;">
				<tr><td style="padding:4px 0;"><strong><?php esc_html_e( 'Framework:', 'nvdigital-open-operator-system-oos' ); ?></strong></td><td><code>@wordpress/element</code></td></tr>
				<tr><td style="padding:4px 0;"><strong><?php esc_html_e( 'i18n:', 'nvdigital-open-operator-system-oos' ); ?></strong></td><td><code>@wordpress/i18n</code></td></tr>
				<tr><td style="padding:4px 0;"><strong><?php esc_html_e( 'Drag &amp; Drop:', 'nvdigital-open-operator-system-oos' ); ?></strong></td><td><code>@dnd-kit/sortable</code></td></tr>
				<tr><td style="padding:4px 0;"><strong><?php esc_html_e( 'Bundler:', 'nvdigital-open-operator-system-oos' ); ?></strong></td><td><code>@wordpress/scripts</code></td></tr>
			</table>
		</div>

	</div>

	<!-- npm packages table (informational) -->
	<h3><?php esc_html_e( 'npm Packages Used', 'nvdigital-open-operator-system-oos' ); ?></h3>
	<table class="wp-list-table widefat fixed striped" style="max-width: 900px;">
		<thead>
			<tr>
				<th style="width: 35%;"><?php esc_html_e( 'Package', 'nvdigital-open-operator-system-oos' ); ?></th>
				<th style="width: 15%;"><?php esc_html_e( 'Version', 'nvdigital-open-operator-system-oos' ); ?></th>
				<th style="width: 50%;"><?php esc_html_e( 'Purpose', 'nvdigital-open-operator-system-oos' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td><code>@wordpress/element</code></td>
				<td><code>^5.0.0</code></td>
				<td><?php esc_html_e( 'React abstraction layer (createRoot, hooks)', 'nvdigital-open-operator-system-oos' ); ?></td>
			</tr>
			<tr>
				<td><code>@wordpress/i18n</code></td>
				<td><code>^4.0.0</code></td>
				<td><?php esc_html_e( 'Translations via __() — aligns with WordPress standards', 'nvdigital-open-operator-system-oos' ); ?></td>
			</tr>
			<tr>
				<td><code>@dnd-kit/core</code></td>
				<td><code>^6.1.0</code></td>
				<td><?php esc_html_e( 'Drag-and-drop context, sensors (pointer + keyboard a11y)', 'nvdigital-open-operator-system-oos' ); ?></td>
			</tr>
			<tr>
				<td><code>@dnd-kit/sortable</code></td>
				<td><code>^8.0.0</code></td>
				<td><?php esc_html_e( 'Drag-to-reorder template cards in the admin picker', 'nvdigital-open-operator-system-oos' ); ?></td>
			</tr>
			<tr>
				<td><code>@dnd-kit/utilities</code></td>
				<td><code>^3.2.2</code></td>
				<td><?php esc_html_e( 'CSS.Transform helper for smooth card animations', 'nvdigital-open-operator-system-oos' ); ?></td>
			</tr>
		</tbody>
	</table>

	<!-- CTA -->
	<div style="margin: 20px 0; padding: 15px; background: #f0f6fc; border-left: 4px solid #2271b1;">
		<h3 style="margin: 0 0 10px 0;">
			<span class="dashicons dashicons-admin-settings"></span>
			<?php esc_html_e( 'Configure Templates', 'nvdigital-open-operator-system-oos' ); ?>
		</h3>
		<p style="margin: 0 0 12px 0; font-size: 13px;">
			<?php esc_html_e( 'Set the global default template in the Mini App Builder tab, or override it per-connection in the Remote Site Manager.', 'nvdigital-open-operator-system-oos' ); ?>
		</p>
		<a href="<?php echo esc_url( $chat_channels_url ); ?>" class="button button-primary" style="margin-right: 8px;">
			📱 <?php esc_html_e( 'Open Mini App Builder', 'nvdigital-open-operator-system-oos' ); ?>
		</a>
		<a href="<?php echo esc_url( $chat_channels_config ); ?>" class="button button-secondary">
			⚙️ <?php esc_html_e( 'Telegram Configuration', 'nvdigital-open-operator-system-oos' ); ?>
		</a>
	</div>
</div>
			<?php
		}

		/**
		 * Render Pro Toolkit Features card.
		 *
		 * Displays a summary of all Pro toolkit features and capabilities.
		 *
		 * @since 1.1.0
		 * @return void
		 */
		private static function render_pro_toolkit_features_card() {
			?>
<div class="wp-mcp-ai-settings-card">
	<h2>
		<span class="dashicons dashicons-star-filled" style="color: #f0b849;"></span>
			<?php esc_html_e( 'Pro Toolkit Features & Capabilities', 'nvdigital-open-operator-system-oos' ); ?>
	</h2>

	<div class="notice notice-success inline" style="margin: 15px 0;">
		<p>
			<strong><?php esc_html_e( 'Enterprise-Grade AI Orchestration', 'nvdigital-open-operator-system-oos' ); ?></strong><br>
			<?php esc_html_e( 'Comprehensive suite of professional toolkits for advanced AI-powered automation, content generation, and business intelligence.', 'nvdigital-open-operator-system-oos' ); ?>
		</p>
	</div>

	<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 20px; margin: 20px 0;">
		
		<!-- Content & Media Production -->
		<div class="pro-feature-category">
			<h3 style="margin: 0 0 15px 0; padding-bottom: 10px; border-bottom: 2px solid #2271b1; color: #2271b1;">
				<span class="dashicons dashicons-admin-media"></span>
				<?php esc_html_e( 'Content & Media', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<ul style="margin: 0; list-style: none; padding: 0;">
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Media Toolkit', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Image optimization, video processing, SVG vectorization', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Video Production', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Professional video editing with FFmpeg, subtitle generation', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Image Production', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Advanced image generation and manipulation', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0;">
					<strong><?php esc_html_e( 'Document Generation', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'PDF, Word, Excel document creation with templates', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
			</ul>
		</div>

		<!-- Business & E-commerce -->
		<div class="pro-feature-category">
			<h3 style="margin: 0 0 15px 0; padding-bottom: 10px; border-bottom: 2px solid #00a32a; color: #00a32a;">
				<span class="dashicons dashicons-cart"></span>
				<?php esc_html_e( 'Business & E-commerce', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<ul style="margin: 0; list-style: none; padding: 0;">
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'E-commerce Toolkit', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'WooCommerce integration, product management, payments', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'CRM & Email Marketing', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Customer relationship management, email campaigns', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Financial Planner', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'QuickBooks integration, financial reports, budgeting', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0;">
					<strong><?php esc_html_e( 'Advanced Analytics', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Business intelligence, data visualization with D3.js', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
			</ul>
		</div>

		<!-- Marketing & Social -->
		<div class="pro-feature-category">
			<h3 style="margin: 0 0 15px 0; padding-bottom: 10px; border-bottom: 2px solid #f0b849; color: #f0b849;">
				<span class="dashicons dashicons-share"></span>
				<?php esc_html_e( 'Marketing & Social', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<ul style="margin: 0; list-style: none; padding: 0;">
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Social Media Management', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Twitter, Facebook, LinkedIn, Instagram posting & analytics', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Multilingual Content', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Translation, language detection, localization', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0;">
					<strong><?php esc_html_e( 'SEO & Analytics', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Google Analytics integration, SEO optimization', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
			</ul>
		</div>

		<!-- Project & Task Management -->
		<div class="pro-feature-category">
			<h3 style="margin: 0 0 15px 0; padding-bottom: 10px; border-bottom: 2px solid #9b51e0; color: #9b51e0;">
				<span class="dashicons dashicons-list-view"></span>
				<?php esc_html_e( 'Project Management', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<ul style="margin: 0; list-style: none; padding: 0;">
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Project Management', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Projects, tasks, events, calendar integration', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Calendar Booking', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Scheduling, bookings, Google Calendar sync', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0;">
					<strong><?php esc_html_e( 'AI Orchestration', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Autonomous task execution, Ralph pattern implementation', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
			</ul>
		</div>

		<!-- Specialized Toolkits -->
		<div class="pro-feature-category">
			<h3 style="margin: 0 0 15px 0; padding-bottom: 10px; border-bottom: 2px solid #d63638; color: #d63638;">
				<span class="dashicons dashicons-hammer"></span>
				<?php esc_html_e( 'Specialized Tools', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<ul style="margin: 0; list-style: none; padding: 0;">
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Architectural Design', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Architectural drawing generation and design tools', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'DJ Management', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Music library, playlist management, event planning', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Quiz System', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Interactive quizzes, assessments, learning management', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0;">
					<strong><?php esc_html_e( 'AI Tool Builder', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Create custom AI tools and integrations', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
			</ul>
		</div>

		<!-- Development & Integration -->
		<div class="pro-feature-category">
			<h3 style="margin: 0 0 15px 0; padding-bottom: 10px; border-bottom: 2px solid #1d2327; color: #1d2327;">
				<span class="dashicons dashicons-editor-code"></span>
				<?php esc_html_e( 'Development & Integration', 'nvdigital-open-operator-system-oos' ); ?>
			</h3>
			<ul style="margin: 0; list-style: none; padding: 0;">
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Remote Site Connections', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Connect to remote WordPress/WooCommerce sites via REST API', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'GitHub Integration', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Repository operations, Codespace management', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0; border-bottom: 1px solid #f0f0f1;">
					<strong><?php esc_html_e( 'Code Formatting', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'Prettier integration for code formatting', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
				<li style="padding: 8px 0;">
					<strong><?php esc_html_e( 'Password Vault', 'nvdigital-open-operator-system-oos' ); ?></strong>
					<br><small><?php esc_html_e( 'AES-256-GCM encrypted credential storage', 'nvdigital-open-operator-system-oos' ); ?></small>
				</li>
			</ul>
		</div>

	</div>

	<div style="margin: 20px 0; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 8px;">
		<h3 style="margin: 0 0 15px 0; color: white;">
			<span class="dashicons dashicons-chart-line" style="color: white;"></span>
			<?php esc_html_e( 'Key Statistics', 'nvdigital-open-operator-system-oos' ); ?>
		</h3>
		<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
			<div style="text-align: center; padding: 15px; background: rgba(255, 255, 255, 0.1); border-radius: 4px;">
				<div style="font-size: 32px; font-weight: bold; margin-bottom: 5px;">150+</div>
				<div style="font-size: 14px; opacity: 0.9;"><?php esc_html_e( 'Pro Tools', 'nvdigital-open-operator-system-oos' ); ?></div>
			</div>
			<div style="text-align: center; padding: 15px; background: rgba(255, 255, 255, 0.1); border-radius: 4px;">
				<div style="font-size: 32px; font-weight: bold; margin-bottom: 5px;">20+</div>
				<div style="font-size: 14px; opacity: 0.9;"><?php esc_html_e( 'Toolkits', 'nvdigital-open-operator-system-oos' ); ?></div>
			</div>
			<div style="text-align: center; padding: 15px; background: rgba(255, 255, 255, 0.1); border-radius: 4px;">
				<div style="font-size: 32px; font-weight: bold; margin-bottom: 5px;">50+</div>
				<div style="font-size: 14px; opacity: 0.9;"><?php esc_html_e( 'NPM Packages', 'nvdigital-open-operator-system-oos' ); ?></div>
			</div>
			<div style="text-align: center; padding: 15px; background: rgba(255, 255, 255, 0.1); border-radius: 4px;">
				<div style="font-size: 32px; font-weight: bold; margin-bottom: 5px;">10+</div>
				<div style="font-size: 14px; opacity: 0.9;"><?php esc_html_e( 'AI Providers', 'nvdigital-open-operator-system-oos' ); ?></div>
			</div>
		</div>
	</div>

	<div style="margin: 20px 0; padding: 15px; background: #f0f0f1; border-left: 4px solid #2271b1;">
		<p style="margin: 0;">
			<strong><?php esc_html_e( 'Getting Started:', 'nvdigital-open-operator-system-oos' ); ?></strong>
			<?php
			printf(
				/* translators: %s: settings page URL */
				esc_html__( 'Enable individual toolkits in %s to activate their features and tools.', 'nvdigital-open-operator-system-oos' ),
				'<a href="' . esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=advanced' ) ) . '"><strong>' . esc_html__( 'Settings → Advanced', 'nvdigital-open-operator-system-oos' ) . '</strong></a>'
			);
			?>
		</p>
	</div>
</div>
			<?php
		}

		/**
		 * Add Pro Settings submenu page.
		 *
		 * Registers the Pro Settings page under the Pro Dashboard menu.
		 *
		 * @since 1.1.0
		 * @return void
		 */
		public static function add_menu_page() {
			add_submenu_page(
				self::PARENT_SLUG,
				__( 'Pro Settings', 'nvdigital-open-operator-system-oos' ),
				__( 'Pro Settings', 'nvdigital-open-operator-system-oos' ),
				'manage_options',
				self::PAGE_SLUG,
				array( __CLASS__, 'render_page' )
			);
		}
	}
}

// Register Pro Settings page in admin menu.
add_action( 'admin_menu', array( 'WP_MCP_AI_Pro_Settings', 'add_menu_page' ), 100 );
