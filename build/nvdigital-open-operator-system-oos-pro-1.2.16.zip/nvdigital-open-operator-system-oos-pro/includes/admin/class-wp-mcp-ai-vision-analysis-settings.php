<?php
/**
 * WP MCP AI Vision Analysis — Admin Settings
 *
 * Provides the WordPress admin settings page for the Vision Analysis Toolkit.
 * All settings are stored under the main `wp_mcp_ai_settings` option with
 * `va_` prefixed keys (or `enable_vision_analysis_toolkit` for the toggle).
 *
 * @package WP_MCP_AI_Pro
 * @since   1.1.68
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin settings page handler for the Vision Analysis Toolkit.
 *
 * @since 1.1.68
 */
class WP_MCP_AI_Vision_Analysis_Settings {

	/**
	 * WordPress settings option name.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'wp_mcp_ai_settings';

	/**
	 * Settings group name used with settings_fields().
	 *
	 * @var string
	 */
	const SETTINGS_GROUP = 'wp_mcp_ai_vision_analysis_settings_group';

	/**
	 * Admin page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'wp-mcp-ai-vision-analysis';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ), 20 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Add the settings page under the NV oOS admin menu.
	 *
	 * @return void
	 */
	public static function add_menu() {
		add_submenu_page(
			'wp-mcp-ai-dashboard',
			__( 'Vision Analysis Toolkit', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Vision Analysis', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Register settings fields.
	 *
	 * @return void
	 */
	public static function register_settings() {
		register_setting(
			self::SETTINGS_GROUP,
			self::OPTION_NAME,
			array(
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
			)
		);

		// General section.
		add_settings_section(
			'wp_mcp_ai_va_general',
			__( 'General', 'nvdigital-open-operator-system-oos-pro' ),
			'__return_false',
			self::PAGE_SLUG
		);

		add_settings_field(
			'enable_vision_analysis_toolkit',
			__( 'Enable Toolkit', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_checkbox' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_general',
			array(
				'setting_key' => 'enable_vision_analysis_toolkit',
				'description' => __( 'Enable the Vision Analysis Toolkit and register the analyze_image_objects tool.', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		// Detector section.
		add_settings_section(
			'wp_mcp_ai_va_detector',
			__( 'Detector', 'nvdigital-open-operator-system-oos-pro' ),
			function () {
				echo '<p>' . esc_html__( 'Dedicated object detectors own the count. Boxes are counted per category — this is the most accurate counting path.', 'nvdigital-open-operator-system-oos-pro' ) . '</p>';
			},
			self::PAGE_SLUG
		);

		add_settings_field(
			'va_detection_model',
			__( 'Detection Model (HF)', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_text' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_detector',
			array(
				'setting_key' => 'va_detection_model',
				'description' => __( 'HuggingFace object-detection model ID. Default: google/owlv2-base-patch16. Supports OWLv2, YOLO, DETR, and any HF object-detection pipeline.', 'nvdigital-open-operator-system-oos-pro' ),
				'placeholder' => 'google/owlv2-base-patch16',
			)
		);

		add_settings_field(
			'va_min_confidence',
			__( 'Min Confidence', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_number' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_detector',
			array(
				'setting_key' => 'va_min_confidence',
				'min'         => 0.05,
				'max'         => 1.0,
				'step'        => 0.05,
				'description' => __( 'Default minimum confidence threshold (0.0–1.0). Detections below this are filtered out. Default: 0.5.', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		// VLM section.
		add_settings_section(
			'wp_mcp_ai_va_vlm',
			__( 'Vision Language Model (VLM)', 'nvdigital-open-operator-system-oos-pro' ),
			function () {
				echo '<p>' . esc_html__( 'Optional chat vision model for open-world counting and hybrid label normalization. It renames mislabeled categories — it never overrides detector counts.', 'nvdigital-open-operator-system-oos-pro' ) . '</p>';
			},
			self::PAGE_SLUG
		);

		add_settings_field(
			'va_vlm_provider',
			__( 'VLM Provider', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_select' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_vlm',
			array(
				'setting_key' => 'va_vlm_provider',
				'description' => __( 'Preferred chat vision provider for vlm mode and hybrid normalization. "auto" picks the first provider with a configured API key.', 'nvdigital-open-operator-system-oos-pro' ),
				'options'     => array(
					'auto'      => __( 'Auto', 'nvdigital-open-operator-system-oos-pro' ),
					'openai'    => 'OpenAI',
					'anthropic' => 'Anthropic',
					'gemini'    => 'Gemini',
				),
			)
		);

		add_settings_field(
			'va_vlm_model',
			__( 'VLM Model', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_text' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_vlm',
			array(
				'setting_key' => 'va_vlm_model',
				'description' => __( 'Optional explicit chat vision model (e.g. "gpt-4o-mini", "claude-sonnet-5", "gemini-3.8-flash"). Empty uses the provider default.', 'nvdigital-open-operator-system-oos-pro' ),
				'placeholder' => '',
			)
		);

		// Output section.
		add_settings_section(
			'wp_mcp_ai_va_output',
			__( 'Output', 'nvdigital-open-operator-system-oos-pro' ),
			'__return_false',
			self::PAGE_SLUG
		);

		add_settings_field(
			'va_annotate_default',
			__( 'Annotate by Default', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_checkbox' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_output',
			array(
				'setting_key' => 'va_annotate_default',
				'description' => __( 'Return an annotated copy of the image with labeled bounding boxes by default. Requires detector boxes and the PHP GD extension.', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		add_settings_field(
			'va_max_image_bytes',
			__( 'Max Image Size (bytes)', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_number' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_output',
			array(
				'setting_key' => 'va_max_image_bytes',
				'min'         => 1048576,
				'max'         => 10485760,
				'step'        => 262144,
				'description' => __( 'Maximum base64 payload sent to inference providers. Oversized images are downscaled first. Default: 5242880 (5 MB).', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		// Reverse-image web search section (search_similar_images tool).
		add_settings_section(
			'wp_mcp_ai_va_web_search',
			__( 'Reverse-Image Web Search', 'nvdigital-open-operator-system-oos-pro' ),
			function () {
				echo '<p>' . esc_html__( 'Credentials for the search_similar_images tool (Bing Visual Search / SerpApi Google Lens). Image bytes are sent to the selected provider when the tool is used.', 'nvdigital-open-operator-system-oos-pro' ) . '</p>';
			},
			self::PAGE_SLUG
		);

		add_settings_field(
			'va_reverse_search_provider',
			__( 'Search Provider', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_select' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_web_search',
			array(
				'setting_key' => 'va_reverse_search_provider',
				'description' => __( 'Preferred reverse-image search provider. "Auto" uses Bing when its key is configured, then SerpApi.', 'nvdigital-open-operator-system-oos-pro' ),
				'options'     => array(
					'auto'    => __( 'Auto', 'nvdigital-open-operator-system-oos-pro' ),
					'bing'    => 'Bing Visual Search',
					'serpapi' => 'SerpApi Google Lens',
				),
			)
		);

		add_settings_field(
			'va_bing_visual_search_key',
			__( 'Bing Visual Search Key', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_text' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_web_search',
			array(
				'setting_key' => 'va_bing_visual_search_key',
				'description' => __( 'Azure Bing Search resource key (Ocp-Apim-Subscription-Key). Enables the Bing provider.', 'nvdigital-open-operator-system-oos-pro' ),
				'placeholder' => '',
			)
		);

		add_settings_field(
			'va_serpapi_api_key',
			__( 'SerpApi Key', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_text' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_web_search',
			array(
				'setting_key' => 'va_serpapi_api_key',
				'description' => __( 'SerpApi API key. Enables the Google Lens provider, which requires a publicly reachable image URL.', 'nvdigital-open-operator-system-oos-pro' ),
				'placeholder' => '',
			)
		);

		// RF-DETR / Roboflow section.
		add_settings_section(
			'wp_mcp_ai_va_roboflow',
			__( 'RF-DETR (Roboflow)', 'nvdigital-open-operator-system-oos-pro' ),
			function () {
				echo '<p>' . esc_html__( 'RF-DETR is a state-of-the-art real-time detection transformer (Apache 2.0). Run it self-hosted via a Roboflow Inference Docker container (no API key needed locally), through the Serverless Cloud API, or against your own fine-tuned model. Self-hosted endpoints keep image bytes on your network.', 'nvdigital-open-operator-system-oos-pro' ) . '</p>';
			},
			self::PAGE_SLUG
		);

		add_settings_field(
			'va_roboflow_api_url',
			__( 'Inference Endpoint', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_text' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_roboflow',
			array(
				'setting_key' => 'va_roboflow_api_url',
				'description' => __( 'Deployment target. Default: https://serverless.roboflow.com (hosted). For a self-hosted server use http://<host>:9001 (loopback/private hosts only; no API key required).', 'nvdigital-open-operator-system-oos-pro' ),
				'placeholder' => 'https://serverless.roboflow.com',
			)
		);

		add_settings_field(
			'va_roboflow_api_key',
			__( 'Roboflow API Key', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_text' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_roboflow',
			array(
				'setting_key' => 'va_roboflow_api_key',
				'description' => __( 'Roboflow API key for the Serverless Cloud API or a dedicated deployment. Not required for self-hosted Inference servers.', 'nvdigital-open-operator-system-oos-pro' ),
				'placeholder' => '',
			)
		);

		add_settings_field(
			'va_roboflow_model',
			__( 'Detection Model', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_select' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_roboflow',
			array(
				'setting_key' => 'va_roboflow_model',
				'description' => __( 'Default RF-DETR detection checkpoint. Larger models are more accurate; nano is fastest. Default: rfdetr-small.', 'nvdigital-open-operator-system-oos-pro' ),
				'options'     => array(
					'rfdetr-nano'   => __( 'RF-DETR Nano (fastest)', 'nvdigital-open-operator-system-oos-pro' ),
					'rfdetr-small'  => __( 'RF-DETR Small', 'nvdigital-open-operator-system-oos-pro' ),
					'rfdetr-medium' => __( 'RF-DETR Medium', 'nvdigital-open-operator-system-oos-pro' ),
					'rfdetr-large'  => __( 'RF-DETR Large (most accurate)', 'nvdigital-open-operator-system-oos-pro' ),
				),
			)
		);

		add_settings_field(
			'va_roboflow_catalog_model',
			__( 'Catalog Model (fine-tuned)', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_text' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_roboflow',
			array(
				'setting_key' => 'va_roboflow_catalog_model',
				'description' => __( 'Optional fine-tuned model for the rfdetr_catalog_search tool. Accepts an RF-DETR alias or a workspace/project/version path (e.g. myworkspace/myproject/3). Empty disables catalog search.', 'nvdigital-open-operator-system-oos-pro' ),
				'placeholder' => '',
			)
		);

		add_settings_field(
			'va_roboflow_allow_pml',
			__( 'Allow PML-licensed Models', 'nvdigital-open-operator-system-oos-pro' ),
			array( __CLASS__, 'render_checkbox' ),
			self::PAGE_SLUG,
			'wp_mcp_ai_va_roboflow',
			array(
				'setting_key' => 'va_roboflow_allow_pml',
				'description' => __( 'Enable RF-DETR-XL/2XL. These checkpoints are licensed under PML 1.0 (restricted commercial use) — enable only after reviewing the license.', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);
	}

	/**
	 * Sanitize settings on save.
	 *
	 * Validates the submitted va_ fields and merges them into the main
	 * wp_mcp_ai_settings option, preserving all other keys.
	 *
	 * @param array $input Raw input values.
	 * @return array Merged settings array.
	 */
	public static function sanitize_settings( $input ) {
		$current = get_option( self::OPTION_NAME, array() );
		$current = is_array( $current ) ? $current : array();

		$current['enable_vision_analysis_toolkit'] = ! empty( $input['enable_vision_analysis_toolkit'] );
		$current['va_annotate_default']            = ! empty( $input['va_annotate_default'] );

		$current['va_detection_model'] = isset( $input['va_detection_model'] )
			? sanitize_text_field( $input['va_detection_model'] )
			: 'google/owlv2-base-patch16';

		$current['va_vlm_model'] = isset( $input['va_vlm_model'] )
			? sanitize_text_field( $input['va_vlm_model'] )
			: '';

		$allowed_providers          = array( 'auto', 'openai', 'anthropic', 'gemini' );
		$submitted_provider         = isset( $input['va_vlm_provider'] ) ? $input['va_vlm_provider'] : 'auto';
		$current['va_vlm_provider'] = in_array( $submitted_provider, $allowed_providers, true )
			? sanitize_text_field( $submitted_provider )
			: 'auto';

		$current['va_min_confidence'] = isset( $input['va_min_confidence'] )
			? max( 0.0, min( 1.0, (float) $input['va_min_confidence'] ) )
			: 0.5;

		$current['va_max_image_bytes'] = isset( $input['va_max_image_bytes'] )
			? max( 1048576, min( 10485760, absint( $input['va_max_image_bytes'] ) ) )
			: 5242880;

		$allowed_search_providers              = array( 'auto', 'bing', 'serpapi' );
		$submitted_search_provider             = isset( $input['va_reverse_search_provider'] ) ? $input['va_reverse_search_provider'] : 'auto';
		$current['va_reverse_search_provider'] = in_array( $submitted_search_provider, $allowed_search_providers, true )
			? sanitize_text_field( $submitted_search_provider )
			: 'auto';

		$current['va_bing_visual_search_key'] = isset( $input['va_bing_visual_search_key'] )
			? sanitize_text_field( $input['va_bing_visual_search_key'] )
			: '';

		$current['va_serpapi_api_key'] = isset( $input['va_serpapi_api_key'] )
			? sanitize_text_field( $input['va_serpapi_api_key'] )
			: '';

		$current['va_roboflow_api_url'] = isset( $input['va_roboflow_api_url'] )
			? esc_url_raw( sanitize_text_field( $input['va_roboflow_api_url'] ), array( 'http', 'https' ) )
			: '';

		$current['va_roboflow_api_key'] = isset( $input['va_roboflow_api_key'] )
			? sanitize_text_field( $input['va_roboflow_api_key'] )
			: '';

		$allowed_roboflow_models      = array( 'rfdetr-nano', 'rfdetr-small', 'rfdetr-medium', 'rfdetr-large' );
		$submitted_roboflow_model     = isset( $input['va_roboflow_model'] ) ? $input['va_roboflow_model'] : 'rfdetr-small';
		$current['va_roboflow_model'] = in_array( $submitted_roboflow_model, $allowed_roboflow_models, true )
			? sanitize_text_field( $submitted_roboflow_model )
			: 'rfdetr-small';

		$current['va_roboflow_catalog_model'] = isset( $input['va_roboflow_catalog_model'] )
			? sanitize_text_field( $input['va_roboflow_catalog_model'] )
			: '';

		$current['va_roboflow_allow_pml'] = ! empty( $input['va_roboflow_allow_pml'] );

		return $current;
	}

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Vision Analysis Toolkit Settings', 'nvdigital-open-operator-system-oos-pro' ); ?></h1>
			<p class="description">
				<?php esc_html_e( 'Configure image object detection and counting for AI agents. Dedicated detectors count bounding boxes per category; an optional chat vision model adds open-world counting and label normalization.', 'nvdigital-open-operator-system-oos-pro' ); ?>
			</p>
			<p class="description">
				<?php esc_html_e( 'Privacy note: when using hosted inference (HuggingFace, OpenAI, Anthropic, Gemini), image bytes leave this site. Configure a local Ollama vision model to keep images on-premises.', 'nvdigital-open-operator-system-oos-pro' ); ?>
			</p>
			<form method="post" action="options.php">
				<?php
				settings_fields( self::SETTINGS_GROUP );
				do_settings_sections( self::PAGE_SLUG );
				submit_button();
				?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render a checkbox field.
	 *
	 * @param array $args Field arguments including 'setting_key' and 'description'.
	 * @return void
	 */
	public static function render_checkbox( $args ) {
		$all   = get_option( self::OPTION_NAME, array() );
		$value = ! empty( $all[ $args['setting_key'] ] );
		?>
		<label>
			<input type="checkbox"
				name="<?php echo esc_attr( self::OPTION_NAME . '[' . $args['setting_key'] . ']' ); ?>"
				value="1"
				<?php checked( $value ); ?> />
			<?php echo esc_html( $args['description'] ?? '' ); ?>
		</label>
		<?php
	}

	/**
	 * Render a number field.
	 *
	 * @param array $args Field arguments including 'setting_key', 'min', 'max', 'description'.
	 * @return void
	 */
	public static function render_number( $args ) {
		$all   = get_option( self::OPTION_NAME, array() );
		$value = isset( $all[ $args['setting_key'] ] ) ? $all[ $args['setting_key'] ] : '';
		?>
		<input type="number"
			name="<?php echo esc_attr( self::OPTION_NAME . '[' . $args['setting_key'] . ']' ); ?>"
			value="<?php echo esc_attr( $value ); ?>"
			min="<?php echo esc_attr( $args['min'] ?? '' ); ?>"
			max="<?php echo esc_attr( $args['max'] ?? '' ); ?>"
			step="<?php echo esc_attr( $args['step'] ?? '1' ); ?>"
			class="small-text" />
		<?php if ( ! empty( $args['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $args['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render a select field.
	 *
	 * @param array $args Field arguments including 'setting_key', 'options', 'description'.
	 * @return void
	 */
	public static function render_select( $args ) {
		$all   = get_option( self::OPTION_NAME, array() );
		$value = isset( $all[ $args['setting_key'] ] ) ? $all[ $args['setting_key'] ] : '';
		?>
		<select name="<?php echo esc_attr( self::OPTION_NAME . '[' . $args['setting_key'] . ']' ); ?>">
			<?php foreach ( $args['options'] as $key => $label ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $value, $key ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php if ( ! empty( $args['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $args['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render a text field.
	 *
	 * @param array $args Field arguments including 'setting_key', 'placeholder', 'description'.
	 * @return void
	 */
	public static function render_text( $args ) {
		$all   = get_option( self::OPTION_NAME, array() );
		$value = isset( $all[ $args['setting_key'] ] ) ? $all[ $args['setting_key'] ] : '';
		?>
		<input type="text"
			name="<?php echo esc_attr( self::OPTION_NAME . '[' . $args['setting_key'] . ']' ); ?>"
			value="<?php echo esc_attr( $value ); ?>"
			placeholder="<?php echo esc_attr( $args['placeholder'] ?? '' ); ?>"
			class="regular-text" />
		<?php if ( ! empty( $args['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $args['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}
}
