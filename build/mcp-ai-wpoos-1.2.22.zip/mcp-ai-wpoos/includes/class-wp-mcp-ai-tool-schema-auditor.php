<?php
/**
 * Static MCP tool-schema auditor and normalizer.
 *
 * Encodes the cross-agent schema hazards measured by the M3 "Harness Quirks
 * Matrix" (SineFrame, 2026-10) and the MCP design guidelines:
 *
 * - A single tool whose inputSchema lacks a root `type` can make an agent
 *   client drop the entire tools/list catalog.
 * - Schemas over a client's per-server byte budget (Codex: ~20 KB) get
 *   compacted, which silently drops required nested fields.
 * - Root-level `oneOf`/`anyOf` next to `properties` loses property names on
 *   some clients.
 * - Property names containing brackets (`ids[]`) make Claude Code never call
 *   the tool.
 * - `prefixItems` tuple schemas and enum-inside-`anyOf` on large schemas are
 *   mis-translated by clients that compile JSON Schema to TypeScript.
 * - `integer` fields without an upper bound can exceed 2^53 (IDs, totals,
 *   timestamps) and get rounded by clients.
 * - Tool names longer than 64 characters violate the AWS MCP design
 *   guidelines for fully-qualified names.
 *
 * The auditor is dependency-free and side-effect-free so both the base
 * plugin and the standalone Content Graph AI port can share the same logic.
 * Callers decide how to react (skip at emit time, log, or surface via Site
 * Health).
 *
 * @package WP_MCP_AI
 * @since   1.2.4
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Audits and normalizes tool schemas for MCP agent clients.
 */
final class WP_MCP_AI_Tool_Schema_Auditor {

	/**
	 * Finding: inputSchema root has no `type` key.
	 *
	 * @var string
	 */
	const FINDING_ROOT_TYPE_MISSING = 'root_type_missing';

	/**
	 * Finding: root has `oneOf`/`anyOf` alongside `properties`.
	 *
	 * @var string
	 */
	const FINDING_ROOT_COMBINATOR = 'root_combinator_with_properties';

	/**
	 * Finding: a property name contains square brackets.
	 *
	 * @var string
	 */
	const FINDING_BRACKET_PROPERTY = 'bracket_property_name';

	/**
	 * Finding: schema uses the `prefixItems` tuple form.
	 *
	 * @var string
	 */
	const FINDING_PREFIX_ITEMS = 'prefix_items';

	/**
	 * Finding: an `enum` sits inside `anyOf`/`oneOf` on a large schema.
	 *
	 * @var string
	 */
	const FINDING_ENUM_IN_ANYOF_LARGE = 'enum_in_anyof_large_schema';

	/**
	 * Finding: schema byte size exceeds the emit budget.
	 *
	 * @var string
	 */
	const FINDING_OVER_BUDGET = 'schema_over_budget';

	/**
	 * Finding: an unbounded integer field risks 2^53 rounding.
	 *
	 * @var string
	 */
	const FINDING_UNSAFE_INTEGER = 'unsafe_integer_range';

	/**
	 * Finding: tool slug exceeds the maximum length.
	 *
	 * @var string
	 */
	const FINDING_SLUG_TOO_LONG = 'slug_too_long';

	/**
	 * Finding: a `required` entry names a key that is not in `properties`.
	 *
	 * @var string
	 */
	const FINDING_REQUIRED_UNDECLARED = 'required_key_undeclared';

	/**
	 * Finding: a property has neither `type` nor a union/combinator/enum.
	 *
	 * @var string
	 */
	const FINDING_PROPERTY_TYPE_MISSING = 'property_type_missing';

	/**
	 * Finding: an `array` property omits `items`.
	 *
	 * @var string
	 */
	const FINDING_ARRAY_ITEMS_MISSING = 'array_items_missing';

	/**
	 * Finding: `minimum` is greater than `maximum`.
	 *
	 * @var string
	 */
	const FINDING_MIN_ABOVE_MAX = 'minimum_above_maximum';

	/**
	 * Finding: an `enum` value does not match the declared `type`.
	 *
	 * @var string
	 */
	const FINDING_ENUM_TYPE_MISMATCH = 'enum_type_mismatch';

	/**
	 * Default per-schema byte budget for tools/list (20 KB).
	 *
	 * Matches the per-server schema budget Codex applies before compacting
	 * tool schemas; a single tool schema above this size gets its required
	 * nested fields dropped by that client.
	 *
	 * @var int
	 */
	const DEFAULT_MAX_SCHEMA_BYTES = 20480;

	/**
	 * Threshold above which enum-inside-combinator findings are reported (5 KB).
	 *
	 * @var int
	 */
	const LARGE_SCHEMA_BYTES = 5120;

	/**
	 * Default maximum tool slug length (AWS MCP design guidelines).
	 *
	 * @var int
	 */
	const DEFAULT_MAX_SLUG_LENGTH = 64;

	/**
	 * Maximum recursion depth for the schema walk.
	 *
	 * @var int
	 */
	const MAX_WALK_DEPTH = 4;

	/**
	 * Integer-like property names that must carry a `maximum`/`enum` bound.
	 *
	 * @var array<int,string>
	 */
	const INTEGER_KEYS = array( 'id', 'ids', 'total', 'amount', 'timestamp', 'price', 'quantity', 'count', 'balance' );

	/**
	 * Check whether a tool slug is safe to advertise on an MCP tools/list.
	 *
	 * Safe means: non-empty, no dots or other non-sanitized characters, and
	 * no longer than the maximum length (fully-qualified MCP tool names must
	 * stay under the 64-character guideline so client SDK prefixes fit).
	 *
	 * @since 1.2.4
	 *
	 * @param string   $slug       Tool slug.
	 * @param int|null $max_length Optional maximum length; defaults to 64.
	 * @return bool True when the slug is safe to advertise.
	 */
	public static function slug_is_mcp_safe( $slug, $max_length = null ) {
		if ( ! is_string( $slug ) || '' === $slug ) {
			return false;
		}

		$max_length = null === $max_length ? self::DEFAULT_MAX_SLUG_LENGTH : absint( $max_length );

		if ( strlen( $slug ) > $max_length ) {
			return false;
		}

		// Slugs must already be sanitized (lowercase a-z0-9, `_`, `-`).
		return (bool) preg_match( '/^[a-z0-9][a-z0-9_-]*$/', $slug );
	}

	/**
	 * Measure a schema's serialized byte size.
	 *
	 * @since 1.2.4
	 *
	 * @param array $schema Tool input schema.
	 * @return int Byte size of the JSON-encoded schema (0 on encode failure).
	 */
	public static function schema_byte_size( $schema ) {
		if ( ! is_array( $schema ) ) {
			return 0;
		}

		$json = function_exists( 'wp_json_encode' ) ? wp_json_encode( $schema ) : json_encode( $schema ); // phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode -- Fallback for non-WP contexts.

		return is_string( $json ) ? strlen( $json ) : 0;
	}

	/**
	 * Normalize a tool schema for the MCP tools/list surface.
	 *
	 * Injects the mandatory root `type: object` (and empty `properties` when
	 * absent) so a single non-conforming tool cannot make agent clients drop
	 * the whole catalog. Returns a WP_Error instead of a schema when the tool
	 * must be skipped:
	 *
	 * - `wp_mcp_ai_schema_over_budget`       — over the byte budget.
	 * - `wp_mcp_ai_schema_slug_too_long`     — slug over the length limit.
	 * - `wp_mcp_ai_schema_bracket_property`  — bracketed top-level property.
	 * - `wp_mcp_ai_schema_root_combinator`   — root oneOf/anyOf without a
	 *   `type` (injecting `type: object` beside a root combinator is itself a
	 *   known client hazard, so such tools are skipped and left to the
	 *   auditor for human review).
	 *
	 * @since 1.2.4
	 *
	 * @param string   $slug       Tool slug.
	 * @param array    $schema     Tool input schema.
	 * @param int|null $max_bytes  Optional byte budget; defaults to 20 KB.
	 * @param int|null $max_length Optional slug length limit; defaults to 64.
	 * @return array|WP_Error Normalized schema, or WP_Error with a skip reason.
	 */
	public static function normalize_for_mcp( $slug, $schema, $max_bytes = null, $max_length = null ) {
		$max_bytes  = null === $max_bytes ? self::DEFAULT_MAX_SCHEMA_BYTES : absint( $max_bytes );
		$max_length = null === $max_length ? self::DEFAULT_MAX_SLUG_LENGTH : absint( $max_length );

		if ( ! self::slug_is_mcp_safe( $slug, $max_length ) ) {
			return new WP_Error(
				'wp_mcp_ai_schema_slug_too_long',
				sprintf(
					/* translators: %d: maximum allowed slug length */
					__( 'Tool slug exceeds the %d-character MCP limit.', 'mcp-ai-wpoos' ),
					$max_length
				)
			);
		}

		if ( self::schema_byte_size( $schema ) > $max_bytes ) {
			return new WP_Error(
				'wp_mcp_ai_schema_over_budget',
				sprintf(
					/* translators: %d: maximum allowed schema size in kilobytes */
					__( 'Tool input schema exceeds the %d KB emit budget.', 'mcp-ai-wpoos' ),
					(int) floor( $max_bytes / 1024 )
				)
			);
		}

		if ( ! isset( $schema['type'] ) ) {
			if ( isset( $schema['oneOf'] ) || isset( $schema['anyOf'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_schema_root_combinator',
					__( 'Tool schema uses a root oneOf/anyOf without a root type; left for manual review.', 'mcp-ai-wpoos' )
				);
			}

			// Inject the root type so the catalog stays valid for clients
			// that reject schemas without one.
			$schema['type'] = 'object';
		}

		if ( ! isset( $schema['properties'] ) || ! is_array( $schema['properties'] ) ) {
			// An empty PHP array() serializes to `[]`, which strict providers
			// (DeepSeek) reject with "[] is not of type 'object'". Emit an empty
			// stdClass instead so an empty `properties` map encodes as `{}`.
			$schema['properties'] = new stdClass();
		} elseif ( array() === $schema['properties'] ) {
			$schema['properties'] = new stdClass();
		}

		if ( ! self::property_names_are_safe( $schema['properties'], 0 ) ) {
			return new WP_Error(
				'wp_mcp_ai_schema_bracket_property',
				__( 'Tool schema has a property name containing square brackets, which agent clients drop silently.', 'mcp-ai-wpoos' )
			);
		}

		return $schema;
	}

	/**
	 * Audit a single tool schema and return its findings.
	 *
	 * @since 1.2.4
	 *
	 * @param string $slug   Tool slug.
	 * @param array  $schema Tool input schema.
	 * @return array<int,array{code:string,path:string,detail:string}> Findings (empty when clean).
	 */
	public static function audit_schema( $slug, $schema ) {
		$findings = array();

		if ( ! is_array( $schema ) ) {
			$findings[] = array(
				'code'   => self::FINDING_ROOT_TYPE_MISSING,
				'path'   => '$',
				'detail' => __( 'Schema is not an array.', 'mcp-ai-wpoos' ),
			);
			return $findings;
		}

		if ( strlen( $slug ) > self::DEFAULT_MAX_SLUG_LENGTH ) {
			$findings[] = array(
				'code'   => self::FINDING_SLUG_TOO_LONG,
				'path'   => '$.name',
				'detail' => sprintf(
					/* translators: 1: slug length, 2: maximum allowed slug length */
					__( 'Slug is %1$d characters (limit %2$d).', 'mcp-ai-wpoos' ),
					strlen( $slug ),
					self::DEFAULT_MAX_SLUG_LENGTH
				),
			);
		}

		if ( self::schema_byte_size( $schema ) > self::DEFAULT_MAX_SCHEMA_BYTES ) {
			$findings[] = array(
				'code'   => self::FINDING_OVER_BUDGET,
				'path'   => '$',
				'detail' => __( 'Schema exceeds the 20 KB emit budget and will be compacted by budgeted clients.', 'mcp-ai-wpoos' ),
			);
		}

		if ( ! isset( $schema['type'] ) ) {
			$findings[] = array(
				'code'   => self::FINDING_ROOT_TYPE_MISSING,
				'path'   => '$.type',
				'detail' => __( 'Root type missing — clients that reject untyped schemas may drop the whole catalog.', 'mcp-ai-wpoos' ),
			);
		}

		if ( ( isset( $schema['oneOf'] ) || isset( $schema['anyOf'] ) ) && isset( $schema['properties'] ) ) {
			$findings[] = array(
				'code'   => self::FINDING_ROOT_COMBINATOR,
				'path'   => '$',
				'detail' => __( 'Root oneOf/anyOf next to properties — some clients lose property names when translating the schema.', 'mcp-ai-wpoos' ),
			);
		}

		// Enum-in-combinator is a client hazard only on large schemas, and
		// the size that matters is the whole tool schema (that is what
		// budgeted clients compact).
		self::walk( $schema, '$', 0, $findings, false, self::schema_byte_size( $schema ) >= self::LARGE_SCHEMA_BYTES );

		// De-duplicate on code so a schema reports each hazard class once.
		$seen = array();
		$kept = array();
		foreach ( $findings as $finding ) {
			if ( isset( $seen[ $finding['code'] ] ) ) {
				continue;
			}
			$seen[ $finding['code'] ] = true;
			$kept[]                   = $finding;
		}

		return $kept;
	}

	/**
	 * Audit a schema against its own declared contract.
	 *
	 * Separate from audit_schema(), which encodes client-emission hazards.
	 * These checks are about internal consistency — the failure class where a
	 * tool declares a `required` key it never defines, types an array without
	 * `items`, or writes a `minimum` above its `maximum`. None of those are
	 * visible to JSON-schema-less static analysis, and all of them produce
	 * confusing runtime validation instead of a clear authoring error.
	 *
	 * Pure and side-effect-free: no WordPress state, no emitted output.
	 *
	 * @since 1.2.18
	 *
	 * @param string $slug   Tool slug.
	 * @param array  $schema Tool input schema.
	 * @return array<int,array{code:string,path:string,detail:string}> Findings (empty when clean).
	 */
	public static function audit_contract( $slug, $schema ) {
		unset( $slug );

		$findings = array();

		if ( ! is_array( $schema ) || ! isset( $schema['properties'] ) || ! is_array( $schema['properties'] ) ) {
			return $findings;
		}

		$properties = $schema['properties'];
		$required   = isset( $schema['required'] ) && is_array( $schema['required'] ) ? $schema['required'] : array();

		foreach ( $required as $key ) {
			if ( ! is_string( $key ) ) {
				continue;
			}

			if ( ! array_key_exists( $key, $properties ) ) {
				$findings[] = array(
					'code'   => self::FINDING_REQUIRED_UNDECLARED,
					'path'   => '$.required.' . $key,
					'detail' => sprintf(
						/* translators: %s: parameter name */
						__( '`required` lists "%s" but `properties` does not declare it; the model is told to send a field the schema never describes.', 'mcp-ai-wpoos' ),
						$key
					),
				);
			}
		}

		foreach ( $properties as $name => $property ) {
			if ( ! is_array( $property ) ) {
				continue;
			}

			$path     = '$.properties.' . $name;
			$has_type = isset( $property['type'] );
			$is_union = isset( $property['anyOf'] ) || isset( $property['oneOf'] ) || isset( $property['allOf'] );
			$type     = $has_type ? $property['type'] : null;

			if ( ! $has_type && ! $is_union ) {
				$findings[] = array(
					'code'   => self::FINDING_PROPERTY_TYPE_MISSING,
					'path'   => $path,
					'detail' => __( 'Property declares no `type` and no union/combinator; clients cannot translate it and the model cannot validate against it.', 'mcp-ai-wpoos' ),
				);
			}

			if ( 'array' === $type && ! isset( $property['items'] ) ) {
				$findings[] = array(
					'code'   => self::FINDING_ARRAY_ITEMS_MISSING,
					'path'   => $path . '.items',
					'detail' => __( 'Array property has no `items` schema; generates `Array<unknown>` in TypeScript clients.', 'mcp-ai-wpoos' ),
				);
			}

			if ( isset( $property['minimum'], $property['maximum'] )
				&& is_numeric( $property['minimum'] ) && is_numeric( $property['maximum'] )
				&& (float) $property['minimum'] > (float) $property['maximum'] ) {
				$findings[] = array(
					'code'   => self::FINDING_MIN_ABOVE_MAX,
					'path'   => $path,
					'detail' => __( '`minimum` is greater than `maximum`; no value can satisfy the schema.', 'mcp-ai-wpoos' ),
				);
			}

			if ( isset( $property['enum'] ) && is_array( $property['enum'] ) && is_string( $type ) ) {
				foreach ( $property['enum'] as $value ) {
					if ( ! self::value_matches_type( $value, $type ) ) {
						$findings[] = array(
							'code'   => self::FINDING_ENUM_TYPE_MISMATCH,
							'path'   => $path . '.enum',
							'detail' => sprintf(
								/* translators: 1: declared JSON type, 2: enum value rendered as text */
								__( 'Enum value %2$s does not match the declared type "%1$s".', 'mcp-ai-wpoos' ),
								$type,
								is_scalar( $value ) ? (string) $value : gettype( $value )
							),
						);
						break;
					}
				}
			}
		}

		return $findings;
	}

	/**
	 * Whether a JSON-schema enum value matches a JSON type name.
	 *
	 * @since 1.2.18
	 *
	 * @param mixed  $value Enum value.
	 * @param string $type  JSON type name.
	 * @return bool
	 */
	private static function value_matches_type( $value, $type ) {
		switch ( $type ) {
			case 'string':
				return is_string( $value );
			case 'integer':
				return is_int( $value );
			case 'number':
				return is_int( $value ) || is_float( $value );
			case 'boolean':
				return is_bool( $value );
			case 'array':
				return is_array( $value ) && array_is_list( $value );
			case 'object':
				return is_object( $value );
			case 'null':
				return null === $value;
			default:
				return true;
		}
	}

	/**
	 * Audit every registered tool's schema contract.
	 *
	 * @since 1.2.18
	 *
	 * @param WP_MCP_AI_Tool_Registry|null $registry Optional registry; defaults to the singleton.
	 * @return array<string,array<int,array{code:string,path:string,detail:string}>> Slug => findings (only non-empty entries).
	 */
	public static function audit_registry_contract( $registry = null ) {
		if ( null === $registry && class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
			$registry = WP_MCP_AI_Tool_Registry::get_instance();
		}

		if ( ! $registry || ! method_exists( $registry, 'get_all_tools' ) ) {
			return array();
		}

		$findings = array();

		foreach ( $registry->get_all_tools() as $slug => $tool ) {
			if ( ! is_object( $tool ) || ! method_exists( $tool, 'get_parameters_schema' ) ) {
				continue;
			}

			$schema  = $tool->get_parameters_schema();
			$audited = self::audit_contract( $slug, is_array( $schema ) ? $schema : array() );

			if ( ! empty( $audited ) ) {
				$findings[ $slug ] = $audited;
			}
		}

		return $findings;
	}

	/**
	 * Audit every registered tool and map slugs to their findings.
	 *
	 * @since 1.2.4
	 *
	 * @param WP_MCP_AI_Tool_Registry|null $registry Optional registry; defaults to the singleton.
	 * @return array<string,array<int,array{code:string,path:string,detail:string}>> Slug => findings (only non-empty entries).
	 */
	public static function audit_registry( $registry = null ) {
		if ( null === $registry && class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
			$registry = WP_MCP_AI_Tool_Registry::get_instance();
		}

		if ( ! $registry || ! method_exists( $registry, 'get_all_tools' ) ) {
			return array();
		}

		$findings = array();

		foreach ( $registry->get_all_tools() as $slug => $tool ) {
			if ( ! is_object( $tool ) || ! method_exists( $tool, 'get_parameters_schema' ) ) {
				continue;
			}

			$schema  = $tool->get_parameters_schema();
			$audited = self::audit_schema( $slug, is_array( $schema ) ? $schema : array() );

			if ( ! empty( $audited ) ) {
				$findings[ $slug ] = $audited;
			}
		}

		return $findings;
	}

	/**
	 * Summarize audit findings into counts plus a small sample per code.
	 *
	 * @since 1.2.4
	 *
	 * @param array<string,array<int,array{code:string,path:string,detail:string}>> $findings Slug => findings.
	 * @return array{slugs_affected:int,counts:array<string,int>,samples:array<string,array<int,string>>}
	 */
	public static function summarize( $findings ) {
		$counts  = array();
		$samples = array();

		foreach ( $findings as $slug => $slug_findings ) {
			foreach ( $slug_findings as $finding ) {
				$code = $finding['code'];

				if ( ! isset( $counts[ $code ] ) ) {
					$counts[ $code ] = 0;
				}
				++$counts[ $code ];

				if ( ! isset( $samples[ $code ] ) ) {
					$samples[ $code ] = array();
				}
				if ( count( $samples[ $code ] ) < 5 ) {
					$samples[ $code ][] = $slug;
				}
			}
		}

		return array(
			'slugs_affected' => count( $findings ),
			'counts'         => $counts,
			'samples'        => $samples,
		);
	}

	/**
	 * Recursively walk a schema node collecting hazard findings.
	 *
	 * @since 1.2.4
	 *
	 * @param mixed  $node          Schema node.
	 * @param string $path          JSON-path of the node.
	 * @param int    $depth         Current depth (0 = root).
	 * @param array  $findings      Findings accumulator (by reference).
	 * @param bool   $in_combinator Whether this subtree sits under oneOf/anyOf.
	 * @param bool   $schema_large  Whether the whole schema exceeds the large-schema threshold.
	 * @return void
	 */
	private static function walk( $node, $path, $depth, array &$findings, $in_combinator = false, $schema_large = false ) {
		if ( ! is_array( $node ) || $depth > self::MAX_WALK_DEPTH ) {
			return;
		}

		if ( isset( $node['prefixItems'] ) ) {
			$findings[] = array(
				'code'   => self::FINDING_PREFIX_ITEMS,
				'path'   => $path . '.prefixItems',
				'detail' => __( 'Tuple-style prefixItems is translated to Array<string> by some clients.', 'mcp-ai-wpoos' ),
			);
		}

		if ( isset( $node['enum'] ) && $in_combinator && $schema_large ) {
			$findings[] = array(
				'code'   => self::FINDING_ENUM_IN_ANYOF_LARGE,
				'path'   => $path . '.enum',
				'detail' => __( 'Enum nested in a combinator on a large schema is erased by some clients.', 'mcp-ai-wpoos' ),
			);
		}

		if ( isset( $node['type'] ) && 'integer' === $node['type']
			&& ! isset( $node['maximum'] ) && ! isset( $node['enum'] ) && ! isset( $node['const'] )
			&& self::key_is_integer_like( $path ) ) {
			$findings[] = array(
				'code'   => self::FINDING_UNSAFE_INTEGER,
				'path'   => $path,
				'detail' => __( 'Unbounded integer on an id/total/amount-style field can exceed 2^53 and get rounded by clients; add a maximum or use a string type.', 'mcp-ai-wpoos' ),
			);
		}

		if ( isset( $node['properties'] ) && is_array( $node['properties'] ) ) {
			if ( ! self::property_names_are_safe( $node['properties'], $depth ) ) {
				$findings[] = array(
					'code'   => self::FINDING_BRACKET_PROPERTY,
					'path'   => $path . '.properties',
					'detail' => __( 'A property name contains square brackets, which agent clients drop silently.', 'mcp-ai-wpoos' ),
				);
			}

			foreach ( $node['properties'] as $key => $child ) {
				self::walk( $child, $path . '.properties.' . $key, $depth + 1, $findings, false, $schema_large );
			}
		}

		foreach ( array( 'oneOf', 'anyOf' ) as $combinator ) {
			if ( isset( $node[ $combinator ] ) && is_array( $node[ $combinator ] ) ) {
				foreach ( $node[ $combinator ] as $index => $child ) {
					self::walk( $child, $path . '.' . $combinator . '[' . $index . ']', $depth + 1, $findings, true, $schema_large );
				}
			}
		}

		if ( isset( $node['items'] ) && is_array( $node['items'] ) ) {
			self::walk( $node['items'], $path . '.items', $depth + 1, $findings, $in_combinator, $schema_large );
		}
	}

	/**
	 * Check property names for bracket characters.
	 *
	 * @since 1.2.4
	 *
	 * @param array $properties Properties map.
	 * @param int   $depth      Current depth (unused; reserved for future policy).
	 * @return bool True when every property name is safe.
	 */
	private static function property_names_are_safe( $properties, $depth = 0 ) {
		unset( $depth );

		// An empty stdClass (emitted for an empty properties map) has no keys;
		// array_keys() on an object is a TypeError on PHP 8+, so normalise both
		// arrays and stdClass to an array and iterate its keys.
		foreach ( (array) $properties as $key => $ignored ) {
			if ( is_string( $key ) && ( false !== strpos( $key, '[' ) || false !== strpos( $key, ']' ) ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Check whether a JSON-path terminal key looks like a large integer field.
	 *
	 * @since 1.2.4
	 *
	 * @param string $path JSON-path of the property.
	 * @return bool True when the key is id/total/amount-like.
	 */
	private static function key_is_integer_like( $path ) {
		if ( false === strrpos( $path, '.' ) ) {
			return false;
		}

		$key = strtolower( substr( $path, strrpos( $path, '.' ) + 1 ) );

		foreach ( self::INTEGER_KEYS as $candidate ) {
			if ( $key === $candidate || substr( $key, -strlen( $candidate ) - 1 ) === '_' . $candidate ) {
				return true;
			}
		}

		return false;
	}
}
