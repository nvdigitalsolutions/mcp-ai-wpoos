<?php
/**
 * Tool for importing Elementor template kits.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once WP_MCP_AI_PATH . 'includes/traits/trait-wp-mcp-ai-attachment-file-resolver.php';

/**
 * Imports Elementor template kits from ZIP files in the Media Library.
 */
class WP_MCP_AI_Tool_Import_Elementor_Template_Kit implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface {
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Attachment_File_Resolver;

	/**
	 * Determine whether Elementor is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		$has_elementor = defined( 'ELEMENTOR_VERSION' ) || class_exists( '\\Elementor\\Plugin', false );

		return $has_elementor;
	}

	/**
	 * Message explaining why the tool is unavailable.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'The Import Elementor Template Kit tool is disabled because Elementor is not active.', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'import_elementor_template_kit';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Import Elementor Template Kit', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Imports an Elementor template kit ZIP file from the Media Library and creates pages. Requires Elementor to be active.', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'attachment_id'      => array(
					'type'        => 'integer',
					'description' => __( 'Media Library attachment ID of the template kit ZIP file.', 'mcp-ai-wpoos' ),
				),
				'file_id'            => $this->get_file_id_parameter_schema(),
				'url'                => $this->get_url_parameter_schema( 'file', __( 'URL to template kit ZIP file.', 'mcp-ai-wpoos' ) ),
				'max_pages'          => array(
					'type'        => 'integer',
					'description' => __( 'Maximum number of pages to create (1-5).', 'mcp-ai-wpoos' ),
					'minimum'     => 1,
					'maximum'     => 5,
					'default'     => 5,
				),
				'page_status'        => array(
					'type'        => 'string',
					'description' => __( 'Status for created pages (draft or publish).', 'mcp-ai-wpoos' ),
					'enum'        => array( 'draft', 'publish' ),
					'default'     => 'draft',
				),
				'set_front_page'     => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to set the Home page as the static front page.', 'mcp-ai-wpoos' ),
					'default'     => false,
				),
				'overwrite_existing' => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to overwrite existing pages with the same title.', 'mcp-ai-wpoos' ),
					'default'     => false,
				),
				'dry_run'            => array(
					'type'        => 'boolean',
					'description' => __( 'If true, simulates the import without creating pages.', 'mcp-ai-wpoos' ),
					'default'     => false,
				),
			),
			'required'             => array( 'attachment_id' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! self::is_available() ) {
			return new WP_Error(
				'wp_mcp_ai_elementor_missing',
				__( 'Elementor is not active on this site.', 'mcp-ai-wpoos' )
			);
		}

		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to import Elementor template kits.', 'mcp-ai-wpoos' )
			);
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'mcp-ai-wpoos' ) );
		}

		// Check site creator settings.
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_site_creator'] ) || empty( $settings['site_creator_allow_elementor_kit_import'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_feature_disabled',
				__( 'The Elementor Kit Import tool is disabled. Enable it in NV oOS → Tools & Features → Site Creator settings.', 'mcp-ai-wpoos' )
			);
		}

		// Validate attachment_id, file_id, or url.
		$resolved = $this->resolve_attachment_id( $arguments );

		// Handle remote URL case.
		if ( is_array( $resolved ) && isset( $resolved['url'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_remote_url_not_supported',
				__( 'Remote URLs are not yet supported for template kits. Please upload to Media Library first.', 'mcp-ai-wpoos' ),
				array( 'status' => 400 )
			);
		}

		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		if ( ! $resolved ) {
			return new WP_Error(
				'wp_mcp_ai_missing_attachment',
				__( 'You must provide attachment_id, file_id, or url.', 'mcp-ai-wpoos' ),
				array( 'status' => 400 )
			);
		}

		$attachment_id = $resolved;
		$attachment    = get_post( $attachment_id );

		if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_attachment',
				__( 'Invalid attachment ID provided.', 'mcp-ai-wpoos' )
			);
		}

		// Validate file type.
		$file_path = get_attached_file( $attachment_id );
		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return new WP_Error(
				'wp_mcp_ai_file_not_found',
				__( 'Attachment file not found.', 'mcp-ai-wpoos' )
			);
		}

		$mime_type = get_post_mime_type( $attachment_id );
		if ( 'application/zip' !== $mime_type && 'application/x-zip-compressed' !== $mime_type ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_file_type',
				__( 'The attachment must be a ZIP file.', 'mcp-ai-wpoos' )
			);
		}

		// Parse arguments with defaults.
		$max_pages          = isset( $arguments['max_pages'] ) ? min( 5, max( 1, absint( $arguments['max_pages'] ) ) ) : 5;
		$page_status        = isset( $arguments['page_status'] ) && in_array( $arguments['page_status'], array( 'draft', 'publish' ), true ) ? $arguments['page_status'] : 'draft';
		$set_front_page     = ! empty( $arguments['set_front_page'] );
		$overwrite_existing = ! empty( $arguments['overwrite_existing'] );
		$dry_run            = ! empty( $arguments['dry_run'] );

		// Extract and parse the template kit.
		$extract_result = $this->extract_template_kit( $file_path );
		if ( is_wp_error( $extract_result ) ) {
			return $extract_result;
		}

		$manifest      = $extract_result['manifest'];
		$templates_dir = $extract_result['templates_dir'];
		$temp_dir      = $extract_result['temp_dir'];

		// Process templates and create pages.
		$result = $this->process_templates(
			$manifest,
			$templates_dir,
			array(
				'max_pages'          => $max_pages,
				'page_status'        => $page_status,
				'set_front_page'     => $set_front_page,
				'overwrite_existing' => $overwrite_existing,
				'dry_run'            => $dry_run,
				'user_id'            => $user_id,
			)
		);

		// Clean up temp directory.
		$this->cleanup_temp_dir( $temp_dir );

		return $result;
	}

	/**
	 * Extract the template kit ZIP file and parse manifest.
	 *
	 * @param string $file_path Path to the ZIP file.
	 * @return array|WP_Error Extracted data or error.
	 */
	protected function extract_template_kit( $file_path ) {
		// Require the filesystem API.
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		WP_Filesystem();
		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			return new WP_Error(
				'wp_mcp_ai_filesystem_error',
				__( 'Unable to initialize WordPress filesystem.', 'mcp-ai-wpoos' )
			);
		}

		// Create temp directory using WordPress uploads directory.
		$upload_dir = wp_upload_dir();
		$temp_dir   = trailingslashit( $upload_dir['basedir'] ) . 'wp-mcp-ai-temp/' . wp_generate_uuid4();
		wp_mkdir_p( $temp_dir );

		// Extract ZIP.
		$unzip_result = unzip_file( $file_path, $temp_dir );
		if ( is_wp_error( $unzip_result ) ) {
			$this->cleanup_temp_dir( $temp_dir );
			return new WP_Error(
				'wp_mcp_ai_unzip_failed',
				sprintf(
					/* translators: %s: Error message */
					__( 'Failed to extract ZIP file: %s', 'mcp-ai-wpoos' ),
					$unzip_result->get_error_message()
				)
			);
		}

		// Find manifest.json.
		$manifest_path = $this->find_manifest( $temp_dir );
		if ( ! $manifest_path ) {
			$this->cleanup_temp_dir( $temp_dir );
			return new WP_Error(
				'wp_mcp_ai_manifest_not_found',
				__( 'manifest.json not found in the template kit.', 'mcp-ai-wpoos' )
			);
		}

		// Parse manifest.
		$manifest_content = $wp_filesystem->get_contents( $manifest_path );
		if ( ! $manifest_content ) {
			$this->cleanup_temp_dir( $temp_dir );
			return new WP_Error(
				'wp_mcp_ai_manifest_read_error',
				__( 'Unable to read manifest.json.', 'mcp-ai-wpoos' )
			);
		}

		$manifest = json_decode( $manifest_content, true );
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			$this->cleanup_temp_dir( $temp_dir );
			return new WP_Error(
				'wp_mcp_ai_manifest_parse_error',
				sprintf(
					/* translators: %s: JSON error message */
					__( 'Invalid manifest.json: %s', 'mcp-ai-wpoos' ),
					json_last_error_msg()
				)
			);
		}

		$templates_dir = dirname( $manifest_path );

		return array(
			'manifest'      => $manifest,
			'templates_dir' => $templates_dir,
			'temp_dir'      => $temp_dir,
		);
	}

	/**
	 * Find manifest.json in extracted directory.
	 *
	 * @param string $dir Directory to search.
	 * @return string|false Path to manifest.json or false if not found.
	 */
	protected function find_manifest( $dir ) {
		// Check direct manifest.json.
		$manifest_path = trailingslashit( $dir ) . 'manifest.json';
		if ( file_exists( $manifest_path ) ) {
			return $manifest_path;
		}

		// Search in subdirectories (one level deep).
		$subdirs = glob( trailingslashit( $dir ) . '*', GLOB_ONLYDIR );
		if ( $subdirs ) {
			foreach ( $subdirs as $subdir ) {
				$manifest_path = trailingslashit( $subdir ) . 'manifest.json';
				if ( file_exists( $manifest_path ) ) {
					return $manifest_path;
				}
			}
		}

		return false;
	}

	/**
	 * Process templates and create pages.
	 *
	 * @param array  $manifest      Parsed manifest data.
	 * @param string $templates_dir Directory containing templates.
	 * @param array  $options       Processing options.
	 * @return array Results of the import.
	 */
	protected function process_templates( $manifest, $templates_dir, $options ) {
		$results = array(
			'success'       => true,
			'dry_run'       => $options['dry_run'],
			'pages_created' => array(),
			'pages_updated' => array(),
			'pages_skipped' => array(),
			'errors'        => array(),
			'front_page'    => null,
		);

		// Get templates from manifest.
		$templates = $this->get_prioritized_templates( $manifest );
		if ( empty( $templates ) ) {
			$results['errors'][] = __( 'No valid templates found in manifest.', 'mcp-ai-wpoos' );
			$results['success']  = false;
			return $results;
		}

		// Limit to max_pages.
		$templates = array_slice( $templates, 0, $options['max_pages'] );

		$home_page_id = null;

		foreach ( $templates as $template ) {
			$template_result = $this->process_single_template( $template, $templates_dir, $options );

			if ( is_wp_error( $template_result ) ) {
				$results['errors'][] = array(
					'template' => $template['title'],
					'message'  => $template_result->get_error_message(),
				);
				continue;
			}

			if ( 'created' === $template_result['action'] ) {
				$results['pages_created'][] = $template_result;
			} elseif ( 'updated' === $template_result['action'] ) {
				$results['pages_updated'][] = $template_result;
			} else {
				$results['pages_skipped'][] = $template_result;
			}

			// Track home page for front page setting.
			if ( $options['set_front_page'] && $this->is_home_template( $template ) ) {
				$home_page_id = $template_result['page_id'];
			}
		}

		// Set front page if requested and home page was created.
		if ( $options['set_front_page'] && $home_page_id && ! $options['dry_run'] ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $home_page_id );
			$results['front_page'] = $home_page_id;
		}

		$results['summary'] = $this->generate_summary( $results );

		return $results;
	}

	/**
	 * Get prioritized templates from manifest.
	 *
	 * @param array $manifest Parsed manifest data.
	 * @return array Prioritized list of templates.
	 */
	protected function get_prioritized_templates( $manifest ) {
		$templates = array();

		// Check for templates array in manifest.
		if ( isset( $manifest['templates'] ) && is_array( $manifest['templates'] ) ) {
			$templates = $manifest['templates'];
		} elseif ( isset( $manifest['content'] ) && is_array( $manifest['content'] ) ) {
			$templates = $manifest['content'];
		}

		// Filter to only page-type templates.
		$page_templates = array_filter(
			$templates,
			function ( $template ) {
				$type = isset( $template['type'] ) ? strtolower( $template['type'] ) : '';
				return in_array( $type, array( 'page', 'single', 'landing-page', 'landing_page' ), true ) || empty( $type );
			}
		);

		// Priority order: Home, About, Contact, Services, then alphabetical.
		$priority_keywords = array( 'home', 'index', 'front', 'about', 'contact', 'services', 'portfolio', 'blog' );

		usort(
			$page_templates,
			function ( $a, $b ) use ( $priority_keywords ) {
				$title_a        = strtolower( isset( $a['title'] ) ? $a['title'] : '' );
				$title_b        = strtolower( isset( $b['title'] ) ? $b['title'] : '' );
				$keywords_count = count( $priority_keywords );
				$priority_a     = $keywords_count; // Default to lowest priority (after all keywords).
				$priority_b     = $keywords_count;

				// Find the first (lowest index) keyword match for each title.
				foreach ( $priority_keywords as $index => $keyword ) {
					// Only update priority if we haven't found a match yet (still at default).
					if ( $keywords_count === $priority_a && false !== strpos( $title_a, $keyword ) ) {
						$priority_a = $index;
					}
					if ( $keywords_count === $priority_b && false !== strpos( $title_b, $keyword ) ) {
						$priority_b = $index;
					}
					// Early exit if both priorities are found.
					if ( $priority_a < $keywords_count && $priority_b < $keywords_count ) {
						break;
					}
				}

				if ( $priority_a !== $priority_b ) {
					return $priority_a - $priority_b;
				}

				return strcmp( $title_a, $title_b );
			}
		);

		return array_values( $page_templates );
	}

	/**
	 * Check if template is a home/front page template.
	 *
	 * @param array $template Template data.
	 * @return bool
	 */
	protected function is_home_template( $template ) {
		$title         = strtolower( isset( $template['title'] ) ? $template['title'] : '' );
		$home_keywords = array( 'home', 'index', 'front', 'homepage', 'frontpage' );

		foreach ( $home_keywords as $keyword ) {
			if ( strpos( $title, $keyword ) !== false ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Process a single template and create/update page.
	 *
	 * @param array  $template      Template data from manifest.
	 * @param string $templates_dir Directory containing template files.
	 * @param array  $options       Processing options.
	 * @return array|WP_Error Result of processing or error.
	 */
	protected function process_single_template( $template, $templates_dir, $options ) {
		$title = isset( $template['title'] ) ? sanitize_text_field( $template['title'] ) : '';
		if ( empty( $title ) ) {
			return new WP_Error(
				'wp_mcp_ai_empty_title',
				__( 'Template has no title.', 'mcp-ai-wpoos' )
			);
		}

		// Load template content.
		$template_content = $this->load_template_content( $template, $templates_dir );
		if ( is_wp_error( $template_content ) ) {
			return $template_content;
		}

		// Check for existing page by exact title match.
		// WP_Query doesn't support 'title' parameter directly, so we use 's' with exact match filter.
		$existing_page = $this->get_page_by_exact_title( $title );

		if ( $existing_page && ! $options['overwrite_existing'] ) {
			return array(
				'action'  => 'skipped',
				'page_id' => $existing_page->ID,
				'title'   => $title,
				'reason'  => __( 'Page already exists and overwrite is disabled.', 'mcp-ai-wpoos' ),
			);
		}

		// Dry run - don't actually create/update.
		if ( $options['dry_run'] ) {
			$action = $existing_page ? 'would_update' : 'would_create';
			return array(
				'action'  => $action,
				'page_id' => $existing_page ? $existing_page->ID : 0,
				'title'   => $title,
			);
		}

		// Prepare page data.
		$page_data = array(
			'post_title'   => $title,
			'post_content' => '', // Elementor uses meta, not post_content.
			'post_status'  => $options['page_status'],
			'post_type'    => 'page',
			'post_author'  => $options['user_id'],
			'meta_input'   => array(
				'_elementor_edit_mode' => 'builder',
				'_elementor_data'      => $template_content,
				'_elementor_version'   => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0',
			),
		);

		if ( $existing_page ) {
			$page_data['ID'] = $existing_page->ID;
			$page_id         = wp_update_post( $page_data, true );
			$action          = 'updated';
		} else {
			$page_id = wp_insert_post( $page_data, true );
			$action  = 'created';
		}

		if ( is_wp_error( $page_id ) ) {
			return $page_id;
		}

		// Set Elementor template type if available.
		if ( isset( $template['template_type'] ) ) {
			update_post_meta( $page_id, '_elementor_template_type', sanitize_key( $template['template_type'] ) );
		}

		return array(
			'action'    => $action,
			'page_id'   => $page_id,
			'title'     => $title,
			'edit_link' => get_edit_post_link( $page_id, 'raw' ),
			'permalink' => get_permalink( $page_id ),
		);
	}

	/**
	 * Load template content from file.
	 *
	 * @param array  $template      Template data from manifest.
	 * @param string $templates_dir Directory containing template files.
	 * @return string|WP_Error Template content JSON or error.
	 */
	protected function load_template_content( $template, $templates_dir ) {
		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			WP_Filesystem();
		}

		// Try different possible file locations.
		$possible_files = array();

		if ( isset( $template['file'] ) ) {
			$possible_files[] = trailingslashit( $templates_dir ) . $template['file'];
		}

		if ( isset( $template['id'] ) ) {
			$possible_files[] = trailingslashit( $templates_dir ) . $template['id'] . '.json';
			$possible_files[] = trailingslashit( $templates_dir ) . 'templates/' . $template['id'] . '.json';
		}

		$slug = isset( $template['title'] ) ? sanitize_title( $template['title'] ) : '';
		if ( $slug ) {
			$possible_files[] = trailingslashit( $templates_dir ) . $slug . '.json';
			$possible_files[] = trailingslashit( $templates_dir ) . 'templates/' . $slug . '.json';
		}

		// Check if template content is inline.
		if ( isset( $template['content'] ) && is_array( $template['content'] ) ) {
			return wp_json_encode( $template['content'] );
		}

		// Try to find and read template file.
		foreach ( $possible_files as $file_path ) {
			if ( file_exists( $file_path ) && is_readable( $file_path ) ) {
				$content = $wp_filesystem->get_contents( $file_path );
				if ( false !== $content ) {
					// Validate JSON.
					$decoded = json_decode( $content );
					if ( JSON_ERROR_NONE === json_last_error() ) {
						return $content;
					}
				}
			}
		}

		// If no file found but we have basic template data, create minimal content.
		if ( isset( $template['widgets'] ) || isset( $template['elements'] ) ) {
			$elements = isset( $template['widgets'] ) ? $template['widgets'] : $template['elements'];
			return wp_json_encode( $elements );
		}

		return new WP_Error(
			'wp_mcp_ai_template_file_not_found',
			sprintf(
				/* translators: %s: Template title */
				__( 'Template file not found for: %s', 'mcp-ai-wpoos' ),
				isset( $template['title'] ) ? $template['title'] : __( 'Unknown', 'mcp-ai-wpoos' )
			)
		);
	}

	/**
	 * Clean up temporary directory.
	 *
	 * @param string $temp_dir Directory to remove.
	 */
	protected function cleanup_temp_dir( $temp_dir ) {
		if ( ! $temp_dir || ! is_dir( $temp_dir ) ) {
			return;
		}

		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			WP_Filesystem();
		}

		if ( $wp_filesystem ) {
			$wp_filesystem->rmdir( $temp_dir, true );
		}
	}

	/**
	 * Get a page by exact title match.
	 *
	 * @param string $title Page title to search for.
	 * @return WP_Post|null The page post object or null if not found.
	 */
	protected function get_page_by_exact_title( $title ) {
		global $wpdb;

		// Generate cache key for this title lookup.
		$cache_key   = 'wp_mcp_ai_page_by_title_' . md5( $title );
		$cache_group = 'wp_mcp_ai';

		// Check cache first.
		$cached_id = wp_cache_get( $cache_key, $cache_group );
		if ( false !== $cached_id ) {
			if ( 0 === $cached_id ) {
				return null; // Cached negative result.
			}
			return get_post( $cached_id );
		}

		// Use direct database query for exact title match.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Cache is handled above.
		$page_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM $wpdb->posts WHERE post_title = %s AND post_type = 'page' AND post_status IN ('publish', 'draft', 'pending', 'private') LIMIT 1",
				$title
			)
		);

		// Cache the result (including negative results as 0).
		wp_cache_set( $cache_key, $page_id ? (int) $page_id : 0, $cache_group, 60 );

		if ( $page_id ) {
			return get_post( $page_id );
		}

		return null;
	}

	/**
	 * Generate a summary of the import.
	 *
	 * @param array $results Import results.
	 * @return string Summary message.
	 */
	protected function generate_summary( $results ) {
		$parts = array();

		if ( $results['dry_run'] ) {
			$parts[] = __( '[DRY RUN]', 'mcp-ai-wpoos' );
		}

		$created_count = count( $results['pages_created'] );
		$updated_count = count( $results['pages_updated'] );
		$skipped_count = count( $results['pages_skipped'] );
		$error_count   = count( $results['errors'] );

		if ( $created_count > 0 ) {
			$parts[] = sprintf(
				/* translators: %d: Number of pages */
				_n( '%d page created', '%d pages created', $created_count, 'mcp-ai-wpoos' ),
				$created_count
			);
		}

		if ( $updated_count > 0 ) {
			$parts[] = sprintf(
				/* translators: %d: Number of pages */
				_n( '%d page updated', '%d pages updated', $updated_count, 'mcp-ai-wpoos' ),
				$updated_count
			);
		}

		if ( $skipped_count > 0 ) {
			$parts[] = sprintf(
				/* translators: %d: Number of pages */
				_n( '%d page skipped', '%d pages skipped', $skipped_count, 'mcp-ai-wpoos' ),
				$skipped_count
			);
		}

		if ( $error_count > 0 ) {
			$parts[] = sprintf(
				/* translators: %d: Number of errors */
				_n( '%d error', '%d errors', $error_count, 'mcp-ai-wpoos' ),
				$error_count
			);
		}

		if ( $results['front_page'] ) {
			$parts[] = __( 'front page set', 'mcp-ai-wpoos' );
		}

		if ( empty( $parts ) ) {
			return __( 'No changes made.', 'mcp-ai-wpoos' );
		}

		return implode( ', ', $parts ) . '.';
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'developer_technical',

			'pattern_compatibility' => array( 'sequential' ),

			'profession_tags'       => array( 'web_developer', 'web_designer' ),

			'risk_level'            => 'standard',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'write',                // Creates and modifies data.
			'state-changing',       // Modifies database/site state.
			'requires-plugin',      // Requires Elementor plugin.
			'requires-capability',  // Requires manage_options capability.
			'local-only',           // No external API calls.
			'long-running',         // May take significant time for large kits.
			'performance-impact',   // May temporarily affect site performance.
		);
	}
}
