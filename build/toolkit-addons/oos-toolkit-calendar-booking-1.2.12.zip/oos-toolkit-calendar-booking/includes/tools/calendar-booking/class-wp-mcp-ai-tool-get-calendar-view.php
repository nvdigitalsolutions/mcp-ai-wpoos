<?php
/**
 * Tool for getting calendar view.
 *
 * Provides a unified calendar view combining projects, tasks, and events.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gets a unified calendar view of projects, tasks, and events.
 */
class WP_MCP_AI_Tool_Get_Calendar_View implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'get_calendar_view';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Get Calendar View', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Gets a unified calendar view combining projects, tasks, and events within a specified date range. Perfect for displaying comprehensive schedules and timelines.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Building a date-range overview that merges projects, tasks, events, and external bookings.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Finding bookable times; use get_available_slots or check_availability. Listing one project\'s events; use list_events.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'list_events', 'create_event', 'get_appointment_details' ),
			'notes'           => __( 'Use include_types to limit output; results are grouped by date by default.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'start_date'    => array(
					'type'        => 'string',
					'description' => __( 'Start date for calendar view (YYYY-MM-DD) (required)', 'mcp-ai-wpoos-pro' ),
					'pattern'     => '^\d{4}-\d{2}-\d{2}$',
				),
				'end_date'      => array(
					'type'        => 'string',
					'description' => __( 'End date for calendar view (YYYY-MM-DD) (required)', 'mcp-ai-wpoos-pro' ),
					'pattern'     => '^\d{4}-\d{2}-\d{2}$',
				),
				'project_id'    => array(
					'type'        => 'integer',
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
					'description' => __( 'Filter by specific project ID (optional)', 'mcp-ai-wpoos-pro' ),
				),
				'user_id'       => array(
					'type'        => 'integer',
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
					'description' => __( 'Filter by specific user ID (shows items assigned to or attended by user) (optional)', 'mcp-ai-wpoos-pro' ),
				),
				'include_types' => array(
					'type'        => 'array',
					'description' => __( 'Types to include in calendar view (default: all)', 'mcp-ai-wpoos-pro' ),
					'items'       => array(
						'type' => 'string',
						'enum' => array( 'projects', 'tasks', 'events' ),
					),
					'default'     => array( 'projects', 'tasks', 'events' ),
				),
				'group_by_date' => array(
					'type'        => 'boolean',
					'description' => __( 'Group results by date for easier calendar rendering (default: true)', 'mcp-ai-wpoos-pro' ),
					'default'     => true,
				),
			),
			'required'             => array( 'start_date', 'end_date' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Get extended tool definition including toolkit metadata.
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {
		return array(
			'name'                  => $this->get_name(),
			'description'           => $this->get_description(),
			'toolkit'               => 'event_management',
			'post_type'             => 'mcp_ai_event',
			'pattern_compatibility' => array( 'orchestrator', 'sequential' ),
			'profession_tags'       => array( 'event_manager', 'project_manager' ),
			'risk_level'            => 'info',
		);
	}

		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array(
			'pro',
			'read-only',
		);
	}

	/**
	 * Check if the tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		// Project management is a Pro feature.
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_project_management'] );
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$current_user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $current_user_id || ! user_can( $current_user_id, 'read' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to view calendar.', 'mcp-ai-wpoos-pro' ) );
		}

		$start_date = isset( $arguments['start_date'] ) ? sanitize_text_field( $arguments['start_date'] ) : '';
		$end_date   = isset( $arguments['end_date'] ) ? sanitize_text_field( $arguments['end_date'] ) : '';

		if ( ! $start_date || ! $end_date ) {
			return new WP_Error( 'wp_mcp_ai_missing_dates', __( 'Both start_date and end_date are required.', 'mcp-ai-wpoos-pro' ) );
		}

		if ( ! $this->validate_date( $start_date ) || ! $this->validate_date( $end_date ) ) {
			return new WP_Error( 'wp_mcp_ai_invalid_dates', __( 'Invalid date format. Use YYYY-MM-DD.', 'mcp-ai-wpoos-pro' ) );
		}

		$project_id    = isset( $arguments['project_id'] ) ? absint( $arguments['project_id'] ) : 0;
		$user_id       = isset( $arguments['user_id'] ) ? absint( $arguments['user_id'] ) : 0;
		$include_types = isset( $arguments['include_types'] ) && is_array( $arguments['include_types'] )
			? $arguments['include_types']
			: array( 'projects', 'tasks', 'events' );
		$group_by_date = isset( $arguments['group_by_date'] ) ? (bool) $arguments['group_by_date'] : true;

		$calendar_items = array();

		// Get projects within date range.
		if ( in_array( 'projects', $include_types, true ) ) {
			$calendar_items = array_merge( $calendar_items, $this->get_projects_in_range( $start_date, $end_date, $project_id, $user_id ) );
		}

		// Get tasks within date range.
		if ( in_array( 'tasks', $include_types, true ) ) {
			$calendar_items = array_merge( $calendar_items, $this->get_tasks_in_range( $start_date, $end_date, $project_id, $user_id ) );
		}

		// Get events within date range.
		if ( in_array( 'events', $include_types, true ) ) {
			$calendar_items = array_merge( $calendar_items, $this->get_events_in_range( $start_date, $end_date, $project_id, $user_id ) );
		}

		// --- External system items (v1.5.0) ---
		$include_external = ! isset( $arguments['include_external'] ) || ! empty( $arguments['include_external'] );
		if ( $include_external && class_exists( 'WP_MCP_AI_Booking_Adapter_Factory' ) ) {
			// JetAppointment appointments.
			if ( WP_MCP_AI_Booking_Adapter_Factory::has_jetappointment() ) {
				$adapter   = WP_MCP_AI_Booking_Adapter_Factory::get_jetappointment();
				$ja_result = $adapter->get_bookings(
					array(
						'date_from' => $start_date,
						'date_to'   => $end_date,
					)
				);
				if ( ! is_wp_error( $ja_result ) && ! empty( $ja_result['items'] ) ) {
					foreach ( $ja_result['items'] as $booking ) {
						$calendar_items[] = array(
							'type'        => 'appointment',
							'source'      => 'jetappointment',
							'id'          => $booking['id'],
							'title'       => sprintf(
								/* translators: %d: booking ID */
								__( 'Appointment #%d', 'mcp-ai-wpoos-pro' ),
								$booking['id']
							),
							'date'        => $booking['date'],
							'time'        => '',
							'status'      => $booking['status'],
							'provider_id' => $booking['provider_id'],
							'service_id'  => $booking['service_id'],
						);
					}
				}
			}

			// JetBooking bookings.
			if ( WP_MCP_AI_Booking_Adapter_Factory::has_jetbooking() ) {
				$adapter   = WP_MCP_AI_Booking_Adapter_Factory::get_jetbooking();
				$jb_result = $adapter->get_bookings(
					array(
						'date_from' => $start_date,
						'date_to'   => $end_date,
					)
				);
				if ( ! is_wp_error( $jb_result ) && ! empty( $jb_result['items'] ) ) {
					foreach ( $jb_result['items'] as $booking ) {
						$calendar_items[] = array(
							'type'        => 'booking',
							'source'      => 'jetbooking',
							'id'          => $booking['id'],
							'title'       => sprintf(
								/* translators: %s: unit title or booking ID */
								__( 'Booking: %s', 'mcp-ai-wpoos-pro' ),
								! empty( $booking['unit_title'] ) ? $booking['unit_title'] : '#' . $booking['id']
							),
							'date'        => $booking['check_in_date'],
							'end_date'    => $booking['check_out_date'],
							'status'      => $booking['status'],
							'instance_id' => $booking['instance_id'],
							'unit_id'     => $booking['unit_id'],
						);
					}
				}
			}
		}

		// Sort by date.
		usort(
			$calendar_items,
			function ( $a, $b ) {
				return strcmp( $a['date'], $b['date'] );
			}
		);

		$result = array(
			'success'    => true,
			'start_date' => $start_date,
			'end_date'   => $end_date,
			'count'      => count( $calendar_items ),
		);

		if ( $group_by_date ) {
			// Group items by date.
			$grouped = array();
			foreach ( $calendar_items as $item ) {
				$date = $item['date'];
				if ( ! isset( $grouped[ $date ] ) ) {
					$grouped[ $date ] = array();
				}
				$grouped[ $date ][] = $item;
			}
			$result['calendar'] = $grouped;
		} else {
			$result['items'] = $calendar_items;
		}

		return $result;
	}

	/**
	 * Get projects within date range.
	 *
	 * @param string $start_date Start date.
	 * @param string $end_date   End date.
	 * @param int    $project_id Project ID filter.
	 * @param int    $user_id    User ID filter.
	 * @return array
	 */
	private function get_projects_in_range( $start_date, $end_date, $project_id = 0, $user_id = 0 ) {
		$query_args = array(
			'post_type'      => 'mcp_ai_project',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'meta_query'     => array(
				'relation' => 'OR',
				array(
					'key'     => '_project_start_date',
					'value'   => array( $start_date, $end_date ),
					'compare' => 'BETWEEN',
					'type'    => 'DATE',
				),
				array(
					'key'     => '_project_end_date',
					'value'   => array( $start_date, $end_date ),
					'compare' => 'BETWEEN',
					'type'    => 'DATE',
				),
			),
		);

		if ( $project_id > 0 ) {
			$query_args['p'] = $project_id;
		}

		if ( $user_id > 0 ) {
			$query_args['meta_query'][] = array(
				'key'     => '_project_assigned_to',
				'value'   => sprintf( ':"%d";', $user_id ),
				'compare' => 'LIKE',
			);
		}

		$query = new WP_Query( $query_args );
		$items = array();

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$id            = get_the_ID();
				$project_start = get_post_meta( $id, '_project_start_date', true );

				$items[] = array(
					'type'       => 'project',
					'id'         => $id,
					'title'      => get_the_title(),
					'date'       => $project_start ? $project_start : get_the_date( 'Y-m-d' ),
					'status'     => get_post_meta( $id, '_project_status', true ),
					'project_id' => $id,
				);
			}
			wp_reset_postdata();
		}

		return $items;
	}

	/**
	 * Get tasks within date range.
	 *
	 * @param string $start_date Start date.
	 * @param string $end_date   End date.
	 * @param int    $project_id Project ID filter.
	 * @param int    $user_id    User ID filter.
	 * @return array
	 */
	private function get_tasks_in_range( $start_date, $end_date, $project_id = 0, $user_id = 0 ) {
		$meta_query = array(
			array(
				'key'     => '_task_due_date',
				'value'   => array( $start_date, $end_date ),
				'compare' => 'BETWEEN',
				'type'    => 'DATE',
			),
		);

		if ( $project_id > 0 ) {
			$meta_query[] = array(
				'key'     => '_task_project_id',
				'value'   => $project_id,
				'compare' => '=',
			);
		}

		if ( $user_id > 0 ) {
			$meta_query[] = array(
				'key'     => '_task_assigned_to',
				'value'   => $user_id,
				'compare' => '=',
			);
		}

		$query_args = array(
			'post_type'      => 'mcp_ai_task',
			'post_status'    => 'publish',
			'posts_per_page' => 200,
			'meta_query'     => $meta_query,
		);

		$query = new WP_Query( $query_args );
		$items = array();

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$id = get_the_ID();

				$items[] = array(
					'type'       => 'task',
					'id'         => $id,
					'title'      => get_the_title(),
					'date'       => get_post_meta( $id, '_task_due_date', true ),
					'status'     => get_post_meta( $id, '_task_status', true ),
					'priority'   => get_post_meta( $id, '_task_priority', true ),
					'project_id' => absint( get_post_meta( $id, '_task_project_id', true ) ) ? absint( get_post_meta( $id, '_task_project_id', true ) ) : null,
				);
			}
			wp_reset_postdata();
		}

		return $items;
	}

	/**
	 * Get events within date range.
	 *
	 * @param string $start_date Start date.
	 * @param string $end_date   End date.
	 * @param int    $project_id Project ID filter.
	 * @param int    $user_id    User ID filter.
	 * @return array
	 */
	private function get_events_in_range( $start_date, $end_date, $project_id = 0, $user_id = 0 ) {
		$meta_query = array(
			array(
				'key'     => '_event_start_date',
				'value'   => array( $start_date, $end_date ),
				'compare' => 'BETWEEN',
				'type'    => 'DATE',
			),
		);

		if ( $project_id > 0 ) {
			$meta_query[] = array(
				'key'     => '_event_project_id',
				'value'   => $project_id,
				'compare' => '=',
			);
		}

		if ( $user_id > 0 ) {
			$meta_query[] = array(
				'key'     => '_event_attendees',
				'value'   => sprintf( ':"%d";', $user_id ),
				'compare' => 'LIKE',
			);
		}

		$query_args = array(
			'post_type'      => 'mcp_ai_event',
			'post_status'    => 'publish',
			'posts_per_page' => 500,
			'meta_query'     => $meta_query,
		);

		$query = new WP_Query( $query_args );
		$items = array();

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$id = get_the_ID();

				$items[] = array(
					'type'       => 'event',
					'id'         => $id,
					'title'      => get_the_title(),
					'date'       => get_post_meta( $id, '_event_start_date', true ),
					'time'       => get_post_meta( $id, '_event_start_time', true ) ? get_post_meta( $id, '_event_start_time', true ) : null,
					'all_day'    => (bool) get_post_meta( $id, '_event_all_day', true ),
					'event_type' => get_post_meta( $id, '_event_type', true ),
					'location'   => get_post_meta( $id, '_event_location', true ) ? get_post_meta( $id, '_event_location', true ) : null,
					'project_id' => absint( get_post_meta( $id, '_event_project_id', true ) ) ? absint( get_post_meta( $id, '_event_project_id', true ) ) : null,
				);
			}
			wp_reset_postdata();
		}

		return $items;
	}

	/**
	 * Validate date format (YYYY-MM-DD).
	 *
	 * @param string $date Date string.
	 * @return bool
	 */
	private function validate_date( $date ) {
		$d = DateTime::createFromFormat( 'Y-m-d', $date );
		return $d && $d->format( 'Y-m-d' ) === $date;
	}
}
