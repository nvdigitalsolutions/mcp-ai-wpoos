<?php
/**
 * Get JetAppointment Services Tool
 *
 * Lists JetAppointment services from the configured service CPT.
 * Requires JetAppointment adapter to be available.
 *
 * @package   WP_MCP_AI_Pro
 * @subpackage Calendar_Booking_Toolkit
 * @since     1.5.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Queries JetAppointment services via the adapter.
 *
 * @since 1.5.0
 */
class WP_MCP_AI_Tool_Get_JetAppointment_Services implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * {@inheritdoc}
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_calendar_booking_toolkit'] );
	}

	/**
	 * {@inheritdoc}
	 */
	public static function get_unavailable_reason() {
		return __( 'Calendar Booking toolkit is not enabled.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'get_jetappointment_services';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Get JetAppointment Services', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'List JetAppointment services from the configured service CPT.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Listing JetAppointment service IDs, optionally filtered by provider_id.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Listing staff members; use get_jetappointment_providers. Managing native services; use create_service.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'get_jetappointment_providers', 'check_availability', 'create_appointment' ),
			'notes'           => __( 'Service IDs are required when booking with create_appointment against JetAppointment.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'provider_id' => array(
					'type'        => 'integer',
					'description' => __( 'Optional provider ID to filter services.', 'mcp-ai-wpoos-pro' ),
				),
				'search'      => array(
					'type'        => 'string',
					'description' => __( 'Search term to filter services.', 'mcp-ai-wpoos-pro' ),
				),
				'limit'       => array(
					'type'        => 'integer',
					'description' => __( 'Maximum services (default: 50).', 'mcp-ai-wpoos-pro' ),
					'default'     => 50,
					'minimum'     => 1,
					'maximum'     => 100,
				),
			),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'read';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array( 'pro', 'database-read', 'phase-1.5' );
	}

	/**
	 * {@inheritdoc}
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! self::is_available() ) {
			return new WP_Error( 'toolkit_not_available', self::get_unavailable_reason() );
		}

		if ( ! class_exists( 'WP_MCP_AI_Booking_Adapter_Factory' ) || ! WP_MCP_AI_Booking_Adapter_Factory::has_jetappointment() ) {
			return new WP_Error(
				'jetappointment_unavailable',
				__( 'JetAppointment adapter is not available.', 'mcp-ai-wpoos-pro' )
			);
		}

		$adapter = WP_MCP_AI_Booking_Adapter_Factory::get_jetappointment();
		$filters = array();

		if ( ! empty( $arguments['search'] ) ) {
			$filters['search'] = sanitize_text_field( $arguments['search'] );
		}

		return $adapter->get_services( $filters );
	}
}
