<?php
/**
 * WooCommerce Orders Tool - Pro add-on tool for WooCommerce order operations.
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tool for WooCommerce order operations.
 *
 * Provides read access to WooCommerce orders including:
 * - Listing orders
 * - Getting order details
 * - Searching orders
 *
 * Requires WooCommerce plugin to be active.
 *
 * @since 1.0.0
 */
class WP_MCP_AI_Pro_Tool_Woo_Orders implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Check if this tool is available.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if WooCommerce is active.
	 */
	public static function is_available() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Get the reason why this tool is unavailable.
	 *
	 * @since 1.0.0
	 *
	 * @return string Reason message.
	 */
	public static function get_unavailable_reason() {
		return __( 'WooCommerce Orders tool requires WooCommerce to be installed and activated.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get the tool slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'woo_orders';
	}

	/**
	 * Get the tool name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'WooCommerce Orders', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get the tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Comprehensive WooCommerce order management. View order details, statuses, customer information, order items, update statuses, add notes, and process refunds.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Viewing or updating WooCommerce orders: details, statuses, notes, and simple refunds.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Bulk status changes or advanced partial refunds; use bulk_order_status_update or refund_order_advanced.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'bulk_order_status_update', 'refund_order_advanced', 'woo_customers', 'process_order_workflow' ),
			'notes'           => __( 'Actions: get, list, and search. Status updates and refunds affect real order data, so confirm the target order first.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * Get the parameters schema.
	 *
	 * @return array
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'action'        => array(
					'type'        => 'string',
					'description' => __( 'The action to perform: get, list, search.', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'get', 'list', 'search' ),
					'default'     => 'list',
				),
				'order_id'      => array(
					'type'        => 'integer',
					'description' => __( 'Order ID for get action.', 'mcp-ai-wpoos-pro' ),
				),
				'per_page'      => array(
					'type'        => 'integer',
					'description' => __( 'Number of orders to return. Default: 10. Max: 100.', 'mcp-ai-wpoos-pro' ),
					'default'     => 10,
					'maximum'     => 100,
				),
				'page'          => array(
					'type'        => 'integer',
					'description' => __( 'Page number for pagination. Default: 1.', 'mcp-ai-wpoos-pro' ),
					'default'     => 1,
				),
				'status'        => array(
					'type'        => 'string',
					'description' => __( 'Filter by order status.', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed' ),
				),
				'customer'      => array(
					'type'        => 'integer',
					'description' => __( 'Filter by customer ID.', 'mcp-ai-wpoos-pro' ),
				),
				'new_status'    => array(
					'type'        => 'string',
					'description' => __( 'New status for update_status action.', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed' ),
				),
				'note'          => array(
					'type'        => 'string',
					'description' => __( 'Note content for add_note action.', 'mcp-ai-wpoos-pro' ),
				),
				'note_type'     => array(
					'type'        => 'string',
					'description' => __( 'Note type: customer (visible to customer) or private (internal only).', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'customer', 'private' ),
					'default'     => 'private',
				),
				'refund_amount' => array(
					'type'        => 'number',
					'description' => __( 'Amount to refund (for refund action).', 'mcp-ai-wpoos-pro' ),
				),
				'refund_reason' => array(
					'type'        => 'string',
					'description' => __( 'Reason for refund.', 'mcp-ai-wpoos-pro' ),
				),
				'restock_items' => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to restock items when refunding.', 'mcp-ai-wpoos-pro' ),
					'default'     => true,
				),
			),
			'required'   => array(),
		);
	}

	/**
	 * Get capability flags.
	 *
	 * @return array<string>
	 */
	public function get_capability_flags() {
		return array(
			'pro',              // Pro tier tool.
			'read-only',        // list/get/search operations.
			'write',            // update_status/add_note/refund operations.
			'requires-plugin',  // Requires WooCommerce.
			'local-only',       // No external API calls.
			'pii-data',         // May contain customer data.
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return mixed|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Check if WooCommerce is active.
		if ( ! self::is_available() ) {
			return new WP_Error(
				'woocommerce_not_active',
				__( 'WooCommerce is not installed or activated.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Check permission.
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();
		if ( ! user_can( $user_id, 'edit_shop_orders' ) ) {
			return new WP_Error(
				'permission_denied',
				__( 'You do not have permission to view orders.', 'mcp-ai-wpoos-pro' )
			);
		}

		$action = isset( $arguments['action'] ) ? sanitize_key( $arguments['action'] ) : 'list';

		switch ( $action ) {
			case 'get':
				return $this->get_order( $arguments );
			case 'list':
				return $this->list_orders( $arguments );
			case 'search':
				return $this->search_orders( $arguments );
			case 'update_status':
				return $this->update_order_status( $arguments, $context );
			case 'add_note':
				return $this->add_order_note( $arguments, $context );
			case 'refund':
				return $this->refund_order( $arguments, $context );
			default:
				return new WP_Error(
					'invalid_action',
					__( 'Invalid action specified.', 'mcp-ai-wpoos-pro' )
				);
		}
	}

	/**
	 * Get a single order by ID.
	 *
	 * @param array $arguments Tool arguments.
	 * @return array|WP_Error
	 */
	protected function get_order( $arguments ) {
		if ( empty( $arguments['order_id'] ) ) {
			return new WP_Error(
				'missing_order_id',
				__( 'Order ID is required for get action.', 'mcp-ai-wpoos-pro' )
			);
		}

		$order = wc_get_order( absint( $arguments['order_id'] ) );

		if ( ! $order ) {
			return new WP_Error(
				'order_not_found',
				__( 'Order not found.', 'mcp-ai-wpoos-pro' )
			);
		}

		return $this->format_order( $order );
	}

	/**
	 * List orders.
	 *
	 * @param array $arguments Tool arguments.
	 * @return array
	 */
	protected function list_orders( $arguments ) {
		$per_page = isset( $arguments['per_page'] ) ? min( absint( $arguments['per_page'] ), 100 ) : 10;
		$page     = isset( $arguments['page'] ) ? absint( $arguments['page'] ) : 1;

		$query_args = array(
			'limit'    => $per_page,
			'page'     => $page,
			'orderby'  => 'date',
			'order'    => 'DESC',
			'paginate' => true,
		);

		if ( ! empty( $arguments['status'] ) ) {
			$query_args['status'] = sanitize_key( $arguments['status'] );
		}

		if ( ! empty( $arguments['customer'] ) ) {
			$query_args['customer'] = absint( $arguments['customer'] );
		}

		$results = wc_get_orders( $query_args );

		$orders = array();
		foreach ( $results->orders as $order ) {
			$orders[] = $this->format_order( $order, false );
		}

		return array(
			'orders'      => $orders,
			'total'       => $results->total,
			'total_pages' => $results->max_num_pages,
			'page'        => $page,
		);
	}

	/**
	 * Search orders.
	 *
	 * @param array $arguments Tool arguments.
	 * @return array
	 */
	protected function search_orders( $arguments ) {
		// Use list with existing filters.
		return $this->list_orders( $arguments );
	}

	/**
	 * Format an order for output.
	 *
	 * @param WC_Order $order       Order object.
	 * @param bool     $include_items Whether to include line items.
	 * @return array
	 */
	protected function format_order( $order, $include_items = true ) {
		$data = array(
			'id'             => $order->get_id(),
			'status'         => $order->get_status(),
			'currency'       => $order->get_currency(),
			'total'          => $order->get_total(),
			'subtotal'       => $order->get_subtotal(),
			'total_tax'      => $order->get_total_tax(),
			'shipping_total' => $order->get_shipping_total(),
			'discount_total' => $order->get_discount_total(),
			'customer_id'    => $order->get_customer_id(),
			'billing_email'  => $order->get_billing_email(),
			'billing_name'   => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
			'payment_method' => $order->get_payment_method_title(),
			'date_created'   => $order->get_date_created() ? $order->get_date_created()->format( 'c' ) : null,
			'date_modified'  => $order->get_date_modified() ? $order->get_date_modified()->format( 'c' ) : null,
			'date_completed' => $order->get_date_completed() ? $order->get_date_completed()->format( 'c' ) : null,
			'item_count'     => $order->get_item_count(),
		);

		if ( $include_items ) {
			$data['items'] = array();
			foreach ( $order->get_items() as $item ) {
				$product         = $item->get_product();
				$data['items'][] = array(
					'id'       => $item->get_id(),
					'name'     => $item->get_name(),
					'quantity' => $item->get_quantity(),
					'total'    => $item->get_total(),
					'sku'      => $product ? $product->get_sku() : '',
				);
			}
		}

		return $data;
	}

	/**
	 * Update order status.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	protected function update_order_status( $arguments, $context ) {
		if ( empty( $arguments['order_id'] ) ) {
			return new WP_Error(
				'missing_order_id',
				__( 'Order ID is required for update_status action.', 'mcp-ai-wpoos-pro' )
			);
		}

		if ( empty( $arguments['new_status'] ) ) {
			return new WP_Error(
				'missing_new_status',
				__( 'New status is required for update_status action.', 'mcp-ai-wpoos-pro' )
			);
		}

		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! user_can( $user_id, 'edit_shop_orders' ) ) {
			return new WP_Error(
				'permission_denied',
				__( 'You do not have permission to update orders.', 'mcp-ai-wpoos-pro' )
			);
		}

		$order = wc_get_order( absint( $arguments['order_id'] ) );

		if ( ! $order ) {
			return new WP_Error(
				'order_not_found',
				__( 'Order not found.', 'mcp-ai-wpoos-pro' )
			);
		}

		$old_status = $order->get_status();
		$new_status = sanitize_key( $arguments['new_status'] );

		// Remove 'wc-' prefix if provided.
		$new_status = str_replace( 'wc-', '', $new_status );

		// Update the order status.
		$order->update_status( $new_status, '', true );

		return array(
			'success'    => true,
			'order_id'   => $order->get_id(),
			'old_status' => $old_status,
			'new_status' => $order->get_status(),
			'message'    => sprintf(
				/* translators: 1: order ID, 2: old status, 3: new status */
				__( 'Order #%1$d status updated from %2$s to %3$s.', 'mcp-ai-wpoos-pro' ),
				$order->get_id(),
				$old_status,
				$order->get_status()
			),
		);
	}

	/**
	 * Add a note to an order.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	protected function add_order_note( $arguments, $context ) {
		if ( empty( $arguments['order_id'] ) ) {
			return new WP_Error(
				'missing_order_id',
				__( 'Order ID is required for add_note action.', 'mcp-ai-wpoos-pro' )
			);
		}

		if ( empty( $arguments['note'] ) ) {
			return new WP_Error(
				'missing_note',
				__( 'Note content is required for add_note action.', 'mcp-ai-wpoos-pro' )
			);
		}

		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! user_can( $user_id, 'edit_shop_orders' ) ) {
			return new WP_Error(
				'permission_denied',
				__( 'You do not have permission to add order notes.', 'mcp-ai-wpoos-pro' )
			);
		}

		$order = wc_get_order( absint( $arguments['order_id'] ) );

		if ( ! $order ) {
			return new WP_Error(
				'order_not_found',
				__( 'Order not found.', 'mcp-ai-wpoos-pro' )
			);
		}

		$note_type   = isset( $arguments['note_type'] ) ? sanitize_key( $arguments['note_type'] ) : 'private';
		$is_customer = ( 'customer' === $note_type ) ? 1 : 0;

		// Add the note.
		$note_id = $order->add_order_note(
			wp_kses_post( $arguments['note'] ),
			$is_customer,
			false
		);

		if ( ! $note_id ) {
			return new WP_Error(
				'note_failed',
				__( 'Failed to add order note.', 'mcp-ai-wpoos-pro' )
			);
		}

		return array(
			'success'  => true,
			'order_id' => $order->get_id(),
			'note_id'  => $note_id,
			'type'     => $note_type,
			'message'  => __( 'Order note added successfully.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * Process a refund for an order.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	protected function refund_order( $arguments, $context ) {
		if ( empty( $arguments['order_id'] ) ) {
			return new WP_Error(
				'missing_order_id',
				__( 'Order ID is required for refund action.', 'mcp-ai-wpoos-pro' )
			);
		}

		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! user_can( $user_id, 'edit_shop_orders' ) ) {
			return new WP_Error(
				'permission_denied',
				__( 'You do not have permission to refund orders.', 'mcp-ai-wpoos-pro' )
			);
		}

		$order = wc_get_order( absint( $arguments['order_id'] ) );

		if ( ! $order ) {
			return new WP_Error(
				'order_not_found',
				__( 'Order not found.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Get refund amount (default to full order total).
		$refund_amount = isset( $arguments['refund_amount'] ) ? floatval( $arguments['refund_amount'] ) : $order->get_total();

		// Validate refund amount.
		if ( $refund_amount <= 0 ) {
			return new WP_Error(
				'invalid_refund_amount',
				__( 'Refund amount must be greater than zero.', 'mcp-ai-wpoos-pro' )
			);
		}

		if ( $refund_amount > $order->get_total() ) {
			return new WP_Error(
				'invalid_refund_amount',
				__( 'Refund amount cannot exceed order total.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Get refund reason.
		$refund_reason = isset( $arguments['refund_reason'] ) ? sanitize_text_field( $arguments['refund_reason'] ) : '';

		// Restock items flag.
		$restock_items = isset( $arguments['restock_items'] ) ? (bool) $arguments['restock_items'] : true;

		// Prepare line items for refund (refund all items proportionally).
		$line_items = array();

		foreach ( $order->get_items() as $item_id => $item ) {
			$line_items[ $item_id ] = array(
				'qty'          => $item->get_quantity(),
				'refund_total' => $item->get_total() * ( $refund_amount / $order->get_total() ),
				'refund_tax'   => array_sum( $item->get_taxes()['total'] ) * ( $refund_amount / $order->get_total() ),
			);
		}

		// Create the refund.
		$refund = wc_create_refund(
			array(
				'order_id'      => $order->get_id(),
				'amount'        => $refund_amount,
				'reason'        => $refund_reason,
				'line_items'    => $line_items,
				'restock_items' => $restock_items,
			)
		);

		if ( is_wp_error( $refund ) ) {
			return $refund;
		}

		return array(
			'success'       => true,
			'order_id'      => $order->get_id(),
			'refund_id'     => $refund->get_id(),
			'refund_amount' => $refund_amount,
			'reason'        => $refund_reason,
			'restocked'     => $restock_items,
			'message'       => sprintf(
				/* translators: 1: refund amount, 2: order ID */
				__( 'Refund of %1$s created for order #%2$d.', 'mcp-ai-wpoos-pro' ),
				wc_price( $refund_amount ),
				$order->get_id()
			),
		);
	}
}
