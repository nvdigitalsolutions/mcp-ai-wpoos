<?php
/**
 * Tool for analyzing structural feasibility.
 *
 * Performs basic structural analysis and load calculations.
 * Identifies potential structural issues.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @phase Phase 2.10
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';

/**
 * Analyze structural feasibility.
 */
class WP_MCP_AI_Tool_Analyze_Structural_Feasibility implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/* WP_MCP_AI_AVAILABILITY_BLOCK */
	/**
	 * Whether this tool is available for registration.
	 *
	 * @since 1.2.0
	 *
	 * @return bool True when the Architectural Design toolkit is enabled
	 *              and the host plugin is not running in base mode.
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_architectural_design_toolkit'] );
	}

	/**
	 * Reason this tool is unavailable, if any.
	 *
	 * @since 1.2.0
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'Architectural Design toolkit is not enabled.', 'mcp-ai-wpoos-pro' );
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'analyze_structural_feasibility';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Analyze Structural Feasibility', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Perform basic structural analysis and load calculations. Identifies potential structural issues and suggests solutions.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'First-pass structural checks on a floor plan: gravity loads, spans, foundation, and lateral loads by construction type.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'For building-code verdicts or detailed engineering - use check_building_code_compliance or engage a chartered structural engineer.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'check_building_code_compliance', 'estimate_construction_cost' ),
			'notes'           => __( 'construction_type accepts wood_frame, steel, concrete, masonry; analysis_type accepts gravity_loads, lateral_loads, foundation, spans.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'floor_plan'        => array(
					'type'        => 'object',
					'description' => __( 'Floor plan data to analyze.', 'mcp-ai-wpoos-pro' ),
				),
				'num_floors'        => array(
					'type'        => 'integer',
					'description' => __( 'Number of floors in building.', 'mcp-ai-wpoos-pro' ),
					'minimum'     => 1,
					'default'     => 1,
				),
				'construction_type' => array(
					'type'        => 'string',
					'description' => __( 'Construction type: "wood_frame", "steel", "concrete", "masonry".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'wood_frame', 'steel', 'concrete', 'masonry' ),
					'default'     => 'wood_frame',
				),
				'soil_type'         => array(
					'type'        => 'string',
					'description' => __( 'Soil type: "clay", "sand", "rock", "mixed".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'clay', 'sand', 'rock', 'mixed' ),
				),
				'seismic_zone'      => array(
					'type'        => 'string',
					'description' => __( 'Seismic design category: "A", "B", "C", "D", "E", "F".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'A', 'B', 'C', 'D', 'E', 'F' ),
				),
				'analysis_type'     => array(
					'type'        => 'array',
					'description' => __( 'Analysis types: "gravity_loads", "lateral_loads", "foundation", "spans".', 'mcp-ai-wpoos-pro' ),
					'items'       => array(
						'type' => 'string',
						'enum' => array( 'gravity_loads', 'lateral_loads', 'foundation', 'spans' ),
					),
					'default'     => array( 'gravity_loads', 'spans' ),
				),
			),
			'required'             => array( 'floor_plan' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-capability',
			'requires-credentials',
			'read-only',
			'consumes-tokens',
			'external-api',
			'model-dependent',
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'edit_posts' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to analyze structural feasibility.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Validate floor plan.
		if ( empty( $arguments['floor_plan'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_arguments',
				__( 'Floor plan data is required.', 'mcp-ai-wpoos-pro' )
			);
		}

		$floor_plan        = $arguments['floor_plan'];
		$num_floors        = isset( $arguments['num_floors'] ) ? absint( $arguments['num_floors'] ) : 1;
		$construction_type = isset( $arguments['construction_type'] ) ? sanitize_text_field( $arguments['construction_type'] ) : 'wood_frame';
		$soil_type         = isset( $arguments['soil_type'] ) ? sanitize_text_field( $arguments['soil_type'] ) : '';
		$seismic_zone      = isset( $arguments['seismic_zone'] ) ? sanitize_text_field( $arguments['seismic_zone'] ) : '';
		$analysis_type     = isset( $arguments['analysis_type'] ) ? (array) $arguments['analysis_type'] : array( 'gravity_loads', 'spans' );

		// Perform structural analysis.
		$analysis_results = $this->perform_analysis( $floor_plan, $num_floors, $construction_type, $soil_type, $seismic_zone, $analysis_type, $context );

		if ( is_wp_error( $analysis_results ) ) {
			return $analysis_results;
		}

		// Return structured analysis results.
		return array(
			'success'  => true,
			'analysis' => $analysis_results,
			'message'  => __( 'Structural feasibility analysis complete.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * Perform structural analysis.
	 *
	 * @param array  $floor_plan        Floor plan data.
	 * @param int    $num_floors        Number of floors.
	 * @param string $construction_type Construction type.
	 * @param string $soil_type         Soil type.
	 * @param string $seismic_zone      Seismic zone.
	 * @param array  $analysis_type     Analysis types.
	 * @param array  $context           Execution context.
	 * @return array Analysis results.
	 */
	protected function perform_analysis( $floor_plan, $num_floors, $construction_type, $soil_type, $seismic_zone, $analysis_type, $context ) {
		return array(
			'construction_type'   => $construction_type,
			'num_floors'          => $num_floors,
			'analyses'            => array(
				array(
					'type'            => 'gravity_loads',
					'status'          => 'feasible',
					'findings'        => 'Estimated dead load: 15 PSF, Live load: 40 PSF',
					'recommendations' => 'Standard wood framing adequate for loads',
				),
				array(
					'type'            => 'spans',
					'status'          => 'warning',
					'findings'        => 'Great room has 24-foot clear span',
					'recommendations' => 'Consider engineered beam or intermediate support',
				),
			),
			'overall_feasibility' => 'feasible_with_modifications',
			'critical_issues'     => array(),
			'warnings'            => array(
				'Large span requires engineered beam',
			),
		);
	}
}
