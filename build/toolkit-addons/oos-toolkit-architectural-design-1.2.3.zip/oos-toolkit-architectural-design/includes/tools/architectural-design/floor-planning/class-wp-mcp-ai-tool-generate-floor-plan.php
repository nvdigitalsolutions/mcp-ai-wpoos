<?php
/**
 * Tool for AI-powered floor plan generation.
 *
 * Generates floor plans from natural language requirements using AI.
 * Supports residential, commercial, and custom building types.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @phase Phase 2.10
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-image-response.php';

/**
 * Generate floor plans using AI.
 */
class WP_MCP_AI_Tool_Generate_Floor_Plan implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/* WP_MCP_AI_AVAILABILITY_BLOCK */
	/**
	 * Whether this tool is available for registration.
	 *
	 * @since 1.2.0
	 *
	 * @return bool True when the Architectural Design toolkit is enabled
	 *              and the host plugin is not running in base mode.
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}
		$settings = class_exists( 'WP_MCP_AI_Admin_Settings' ) ? WP_MCP_AI_Admin_Settings::get_settings() : get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_architectural_design_toolkit'] );
	}

	/**
	 * Reason this tool is unavailable, if any.
	 *
	 * @since 1.2.0
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'Architectural Design toolkit is not enabled.', 'mcp-ai-wpoos-pro' );
	}

	use WP_MCP_AI_Tool_Image_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_floor_plan';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate Floor Plan', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Generate floor plans from natural language requirements. Supports residential, commercial, and custom building types with room specifications and dimensions.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Generating a floor plan from natural-language requirements with building type, area, floors, style, and optional furniture placement.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'For sketch conversion or alternative layouts - use convert_sketch_to_floor_plan or create_floor_plan_variations.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'create_floor_plan_variations', 'optimize_space_layout' ),
			'notes'           => __( 'output_format accepts svg, png, dxf, or json; building_type accepts residential, commercial, industrial, or mixed-use.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'requirements'      => array(
					'type'        => 'string',
					'description' => __( 'Natural language description of floor plan requirements (e.g., "3 bedroom house with open kitchen").', 'mcp-ai-wpoos-pro' ),
				),
				'building_type'     => array(
					'type'        => 'string',
					'description' => __( 'Type of building: "residential", "commercial", "industrial", "mixed-use".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'residential', 'commercial', 'industrial', 'mixed-use' ),
					'default'     => 'residential',
				),
				'total_area'        => array(
					'type'        => 'number',
					'description' => __( 'Total floor area in square feet or square meters.', 'mcp-ai-wpoos-pro' ),
					'minimum'     => 100,
				),
				'num_floors'        => array(
					'type'        => 'integer',
					'description' => __( 'Number of floors in the building.', 'mcp-ai-wpoos-pro' ),
					'minimum'     => 1,
					'default'     => 1,
				),
				'style'             => array(
					'type'        => 'string',
					'description' => __( 'Architectural style: "modern", "traditional", "contemporary", "minimalist".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'modern', 'traditional', 'contemporary', 'minimalist' ),
					'default'     => 'modern',
				),
				'include_furniture' => array(
					'type'        => 'boolean',
					'description' => __( 'Include furniture placement in the floor plan.', 'mcp-ai-wpoos-pro' ),
					'default'     => false,
				),
				'output_format'     => array(
					'type'        => 'string',
					'description' => __( 'Output format: "svg", "png", "dxf", "json".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'svg', 'png', 'dxf', 'json' ),
					'default'     => 'svg',
				),
			),
			'required'             => array( 'requirements' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-capability',
			'requires-credentials',
			'write',
			'consumes-tokens',
			'external-api',
			'async',
			'model-dependent',
			'non-deterministic',
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'edit_posts' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to generate floor plans.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Validate requirements.
		if ( empty( $arguments['requirements'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_arguments',
				__( 'Floor plan requirements are required.', 'mcp-ai-wpoos-pro' )
			);
		}

		$requirements      = sanitize_textarea_field( $arguments['requirements'] );
		$building_type     = isset( $arguments['building_type'] ) ? sanitize_text_field( $arguments['building_type'] ) : 'residential';
		$total_area        = isset( $arguments['total_area'] ) ? floatval( $arguments['total_area'] ) : 0;
		$num_floors        = isset( $arguments['num_floors'] ) ? absint( $arguments['num_floors'] ) : 1;
		$style             = isset( $arguments['style'] ) ? sanitize_text_field( $arguments['style'] ) : 'modern';
		$include_furniture = isset( $arguments['include_furniture'] ) ? (bool) $arguments['include_furniture'] : false;
		$output_format     = isset( $arguments['output_format'] ) ? sanitize_text_field( $arguments['output_format'] ) : 'svg';

		// Build AI prompt for floor plan generation.
		$prompt = $this->build_floor_plan_prompt( $requirements, $building_type, $total_area, $num_floors, $style, $include_furniture );

		// Generate floor plan using AI service.
		$floor_plan = $this->generate_with_ai( $prompt, $output_format, $context );

		if ( is_wp_error( $floor_plan ) ) {
			return $floor_plan;
		}

		// Return structured data for LLM.
		$result = array(
			'success'       => true,
			'url'           => isset( $floor_plan['image_url'] ) ? $floor_plan['image_url'] : '',
			'prompt'        => sprintf( '%s floor plan: %s', $building_type, $requirements ),
			'floor_plan'    => $floor_plan,
			'requirements'  => $requirements,
			'building_type' => $building_type,
			'total_area'    => $total_area,
			'num_floors'    => $num_floors,
			'style'         => $style,
			'format'        => $output_format,
			'text'          => sprintf(
				/* translators: %s: building type */
				__( 'Successfully generated %s floor plan.', 'mcp-ai-wpoos-pro' ),
				$building_type
			),
		);

		return $this->add_image_html_to_response( $result );
	}

	/**
	 * Build AI prompt for floor plan generation.
	 *
	 * @param string $requirements      Floor plan requirements.
	 * @param string $building_type     Building type.
	 * @param float  $total_area        Total area.
	 * @param int    $num_floors        Number of floors.
	 * @param string $style             Architectural style.
	 * @param bool   $include_furniture Include furniture.
	 * @return string AI prompt.
	 */
	protected function build_floor_plan_prompt( $requirements, $building_type, $total_area, $num_floors, $style, $include_furniture ) {
		$prompt  = "Generate a detailed floor plan with the following specifications:\n\n";
		$prompt .= "Requirements: {$requirements}\n";
		$prompt .= "Building Type: {$building_type}\n";

		if ( $total_area > 0 ) {
			$prompt .= "Total Area: {$total_area} sq ft\n";
		}

		$prompt .= "Number of Floors: {$num_floors}\n";
		$prompt .= "Architectural Style: {$style}\n";
		$prompt .= 'Include Furniture: ' . ( $include_furniture ? 'Yes' : 'No' ) . "\n\n";
		$prompt .= "Provide:\n";
		$prompt .= "1. Room layout with dimensions\n";
		$prompt .= "2. Door and window placements\n";
		$prompt .= "3. Wall thicknesses\n";
		$prompt .= "4. Traffic flow optimization\n";
		$prompt .= "5. Building code compliance notes\n";

		if ( $include_furniture ) {
			$prompt .= "6. Furniture placement suggestions\n";
		}

		return $prompt;
	}

	/**
	 * Generate floor plan using AI service.
	 *
	 * @param string $prompt        AI prompt.
	 * @param string $output_format Output format.
	 * @param array  $context       Execution context.
	 * @return array|WP_Error Floor plan data or error.
	 */
	protected function generate_with_ai( $prompt, $output_format, $context ) {
		// Get AI service instance.
		$ai_service = $this->get_ai_service( $context );

		if ( is_wp_error( $ai_service ) ) {
			return $ai_service;
		}

		// TODO: Real implementation would use OpenAI client to generate floor plan.
		// Mock response for now - real version would call AI service.
		$response = array(
			'content' => 'Floor plan generated based on requirements',
		);

		// Parse AI response and format as requested.
		$floor_plan_data = $this->parse_ai_response( $response, $output_format );

		return $floor_plan_data;
	}

	/**
	 * Get AI service instance.
	 *
	 * @param array $context Execution context.
	 * @return object|WP_Error AI service or error.
	 */
	protected function get_ai_service( $context ) {
		// Check for OpenAI API key.
		$api_key = WP_MCP_AI_Credential_Resolver::get_api_key( 'openai' ) ?? '';

		if ( empty( $api_key ) ) {
			return new WP_Error(
				'wp_mcp_ai_missing_credentials',
				__( 'OpenAI API key is required for floor plan generation.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Return mock service for now - real implementation would use OpenAI client.
		return (object) array(
			'api_key' => $api_key,
		);
	}

	/**
	 * Parse AI response and format output.
	 *
	 * @param mixed  $response      AI response.
	 * @param string $output_format Output format.
	 * @return array Formatted floor plan data.
	 */
	protected function parse_ai_response( $response, $output_format ) {
		// Mock implementation - real version would parse AI response and convert to requested format.
		return array(
			'format'   => $output_format,
			'data'     => array(
				'rooms'      => array(),
				'dimensions' => array(),
				'walls'      => array(),
				'doors'      => array(),
				'windows'    => array(),
			),
			'metadata' => array(
				'generated_at' => current_time( 'mysql' ),
				'version'      => '1.0',
			),
		);
	}
}
