<?php
/**
 * Tool for generating 3D building models.
 *
 * Creates 3D models from floor plans for visualization and VR.
 * Supports multiple export formats.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @phase Phase 2.10
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-image-response.php';

/**
 * Generate 3D building models.
 */
class WP_MCP_AI_Tool_Generate_3d_Model implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/* WP_MCP_AI_AVAILABILITY_BLOCK */
	/**
	 * Whether this tool is available for registration.
	 *
	 * @since 1.2.0
	 *
	 * @return bool True when the Architectural Design toolkit is enabled
	 *              and the host plugin is not running in base mode.
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_architectural_design_toolkit'] );
	}

	/**
	 * Reason this tool is unavailable, if any.
	 *
	 * @since 1.2.0
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'Architectural Design toolkit is not enabled.', 'mcp-ai-wpoos-pro' );
	}

	use WP_MCP_AI_Tool_Image_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_3d_model';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate 3D Model', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Create 3D building models from floor plans. Supports various export formats for visualization, VR, and CAD software.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Creating a 3D building model from a floor plan with wall height, roof type, materials, and furniture for visualization, VR, or CAD export.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Still renders or videos; use render_architectural_view or create_walkthrough_animation. 2D drafting; use generate_architectural_drawing.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'render_architectural_view', 'create_walkthrough_animation', 'generate_floor_plan' ),
			'notes'           => __( 'Exports obj, fbx, gltf, or stl; async output with large-response and performance impact.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'floor_plan'        => array(
					'type'        => 'object',
					'description' => __( 'Floor plan data to convert to 3D.', 'mcp-ai-wpoos-pro' ),
				),
				'wall_height'       => array(
					'type'        => 'number',
					'description' => __( 'Wall height in feet or meters.', 'mcp-ai-wpoos-pro' ),
					'default'     => 9,
				),
				'include_roof'      => array(
					'type'        => 'boolean',
					'description' => __( 'Include roof structure in model.', 'mcp-ai-wpoos-pro' ),
					'default'     => true,
				),
				'roof_type'         => array(
					'type'        => 'string',
					'description' => __( 'Roof type: "flat", "gable", "hip", "mansard".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'flat', 'gable', 'hip', 'mansard' ),
					'default'     => 'gable',
				),
				'materials'         => array(
					'type'        => 'object',
					'description' => __( 'Material specifications for walls, floors, roof.', 'mcp-ai-wpoos-pro' ),
				),
				'include_furniture' => array(
					'type'        => 'boolean',
					'description' => __( 'Include 3D furniture models.', 'mcp-ai-wpoos-pro' ),
					'default'     => false,
				),
				'output_format'     => array(
					'type'        => 'string',
					'description' => __( 'Output format: "obj", "fbx", "gltf", "stl".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'obj', 'fbx', 'gltf', 'stl' ),
					'default'     => 'obj',
				),
			),
			'required'             => array( 'floor_plan' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-capability',
			'write',
			'async',
			'performance-impact',
			'large-response',
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'edit_posts' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to generate 3D models.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Validate floor plan.
		if ( empty( $arguments['floor_plan'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_arguments',
				__( 'Floor plan data is required.', 'mcp-ai-wpoos-pro' )
			);
		}

		$floor_plan        = $arguments['floor_plan'];
		$wall_height       = isset( $arguments['wall_height'] ) ? floatval( $arguments['wall_height'] ) : 9;
		$include_roof      = isset( $arguments['include_roof'] ) ? (bool) $arguments['include_roof'] : true;
		$roof_type         = isset( $arguments['roof_type'] ) ? sanitize_text_field( $arguments['roof_type'] ) : 'gable';
		$materials         = isset( $arguments['materials'] ) ? (array) $arguments['materials'] : array();
		$include_furniture = isset( $arguments['include_furniture'] ) ? (bool) $arguments['include_furniture'] : false;
		$output_format     = isset( $arguments['output_format'] ) ? sanitize_text_field( $arguments['output_format'] ) : 'obj';

		// Generate 3D model.
		$model_data = $this->generate_3d_model( $floor_plan, $wall_height, $include_roof, $roof_type, $materials, $include_furniture, $output_format );

		if ( is_wp_error( $model_data ) ) {
			return $model_data;
		}

		// Return structured 3D model data.
		$result = array(
			'success'        => true,
			'url'            => isset( $model_data['preview_url'] ) ? $model_data['preview_url'] : '',
			'prompt'         => sprintf( '3D model with %s roof, %s wall height', $roof_type, $wall_height ),
			'model'          => $model_data,
			'format'         => $output_format,
			'specifications' => array(
				'wall_height'   => $wall_height,
				'roof_type'     => $roof_type,
				'has_furniture' => $include_furniture,
			),
			'text'           => __( 'Successfully generated 3D building model.', 'mcp-ai-wpoos-pro' ),
		);

		return $this->add_image_html_to_response( $result );
	}

	/**
	 * Generate 3D model from floor plan.
	 *
	 * @param array  $floor_plan        Floor plan data.
	 * @param float  $wall_height       Wall height.
	 * @param bool   $include_roof      Include roof.
	 * @param string $roof_type         Roof type.
	 * @param array  $materials         Materials.
	 * @param bool   $include_furniture Include furniture.
	 * @param string $output_format     Output format.
	 * @return array 3D model data.
	 */
	protected function generate_3d_model( $floor_plan, $wall_height, $include_roof, $roof_type, $materials, $include_furniture, $output_format ) {
		return array(
			'format'   => $output_format,
			'data'     => array(
				'vertices'  => array(),
				'faces'     => array(),
				'materials' => array(),
				'textures'  => array(),
			),
			'stats'    => array(
				'vertex_count' => 0,
				'face_count'   => 0,
				'file_size'    => 0,
			),
			'metadata' => array(
				'wall_height'  => $wall_height,
				'roof_type'    => $roof_type,
				'generated_at' => current_time( 'mysql' ),
			),
		);
	}
}
