<?php
/**
 * Tool for deleting CRM deals/opportunities.
 *
 * @package WP_MCP_AI_Pro
 * @since   2.3.0
 * @author  NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Delete Deal Tool.
 *
 * Permanently deletes a CRM deal/opportunity with:
 * - Confirmation requirement
 * - Destructive operation classification
 *
 * @since 2.3.0
 */
class WP_MCP_AI_Tool_Delete_Deal implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	use WP_MCP_AI_Tool_Envelope;

	/**
	 * Data store instance.
	 *
	 * @var WP_MCP_AI_Toolkit_Data_Store
	 */
	private $data_store;

	/**
	 * Determine whether the tool is available.
	 *
	 * @since 2.3.0
	 * @return bool
	 */
	public static function is_available() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_crm_toolkit'] );
	}

	/**
	 * Message explaining why the tool is unavailable.
	 *
	 * @since 2.3.0
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'The Delete Deal tool requires the CRM Toolkit to be enabled in plugin settings.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( class_exists( 'WP_MCP_AI_Toolkit_Data_Store_Factory' ) ) {
			$this->data_store = WP_MCP_AI_Toolkit_Data_Store_Factory::get_tenant_store( 'crm', 'deals' );
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'delete_deal';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Delete Deal', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Permanently delete a CRM deal/opportunity. Requires explicit confirmation as this action cannot be undone.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Permanently deleting a deal after explicit confirmation (confirm=true); requires manage_options.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Closing a deal without deleting; use move_deal_stage. Editing a deal; use update_deal.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'move_deal_stage', 'update_deal', 'list_deals' ),
			'notes'           => __( 'Deletion is permanent. Deleting a won deal releases the linked lead back to opportunity when no other win remains.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'deal_id' => array(
					'type'        => 'integer',
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
					'description' => __( 'Deal ID to delete (required)', 'mcp-ai-wpoos-pro' ),
				),
				'confirm' => array(
					'type'        => 'boolean',
					'description' => __( 'Explicit confirmation flag. Must be true to proceed.', 'mcp-ai-wpoos-pro' ),
				),
			),
			'required'   => array( 'deal_id', 'confirm' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function requires_base_pro() {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'manage_options';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'destructive',
			'requires-capability',
		);
	}

	/**
	 * {@inheritdoc}
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! $this->data_store ) {
			return new WP_Error(
				'store_unavailable',
				__( 'CRM data store not available. Please ensure the CRM Toolkit is enabled.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Gateway 1: Sanitize inputs.
		$deal_id = isset( $arguments['deal_id'] ) ? absint( $arguments['deal_id'] ) : 0;

		if ( ! $deal_id ) {
			return new WP_Error(
				'invalid_deal',
				__( 'A valid deal ID is required.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Confirmation guard.
		if ( empty( $arguments['confirm'] ) ) {
			return new WP_Error(
				'confirmation_required',
				__( 'Deletion requires explicit confirmation. Set "confirm" to true to proceed. This action cannot be undone.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Verify deal exists before deletion.
		$existing = $this->data_store->get_item( $deal_id );
		if ( is_wp_error( $existing ) ) {
			return $existing;
		}

		// Capture cascade context before the record is gone.
		$lead_id      = isset( $existing['lead_id'] ) ? absint( $existing['lead_id'] ) : 0;
		$deleted_stage = isset( $existing['pipeline_stage'] ) ? $existing['pipeline_stage'] : '';

		// Perform deletion.
		$result = $this->data_store->delete_item( $deal_id );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// ── Cascade: release the lead when the deleted deal was its only win ──
		// Deleting a won deal must not leave the linked lead stranded as a
		// customer. When no other won deal remains, the lead lifecycle drops
		// back to 'opportunity' (JobNavigator releases the job on app delete).
		$lead_released = false;
		if ( $lead_id && WP_MCP_AI_CRM_Pipeline_Stages::is_won( $deleted_stage ) && 'mcp_ai_lead' === get_post_type( $lead_id ) ) {
			$remaining_won = get_posts(
				array(
					'post_type'      => 'mcp_ai_deal',
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'suppress_filters' => true,
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Intentional won-deal count.
						'relation' => 'AND',
						array(
							'key'   => 'lead_id',
							'value' => $lead_id,
						),
						array(
							'relation' => 'OR',
							array(
								'key'   => 'pipeline_stage',
								'value' => 'closed_won',
							),
							array(
								'key'   => 'deal_stage',
								'value' => 'closed_won',
							),
						),
					),
				)
			);

			if ( empty( $remaining_won ) && 'customer' === sanitize_key( (string) get_post_meta( $lead_id, 'lifecycle_stage', true ) ) ) {
				update_post_meta( $lead_id, 'lifecycle_stage', 'opportunity' );
				$lead_released = true;
			}
		}

		/**
		 * Fires after a deal has been deleted.
		 *
		 * @since 3.2.0
		 *
		 * @param int    $deal_id        Deleted deal ID.
		 * @param int    $lead_id        Linked lead ID (0 when none).
		 * @param bool   $lead_released  Whether the lead lifecycle was released.
		 * @param string $deleted_stage  Stage of the deleted deal.
		 */
		do_action( 'wp_mcp_ai_crm_deal_deleted', $deal_id, $lead_id, $lead_released, $deleted_stage );

		// Record destructive action in audit log.
		if ( class_exists( 'WP_MCP_AI_CRM_Audit' ) ) {
			WP_MCP_AI_CRM_Audit::record(
				'deal_deleted',
				'deal',
				$deal_id,
				array(
					'lead_id'       => $lead_id,
					'lead_released' => $lead_released ? 1 : 0,
					'action'        => 'delete',
				)
			);
		}

		return $this->format_success_response(
			__( 'Deal deleted permanently.', 'mcp-ai-wpoos-pro' ),
			array(
				'deal_id'       => $deal_id,
				'lead_released' => $lead_released,
				'storage_type'  => $this->data_store->get_storage_type(),
			)
		);
	}
}
