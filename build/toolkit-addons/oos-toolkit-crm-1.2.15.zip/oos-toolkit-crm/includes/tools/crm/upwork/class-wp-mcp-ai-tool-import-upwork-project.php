<?php
/**
 * Tool for importing an Upwork job/project into the CRM as a Deal or Project.
 *
 * Pulls job details via the Upwork GraphQL API when a valid OAuth connection
 * is configured, and creates a Deal or Project record in the CRM.
 *
 * @package WP_MCP_AI_Pro
 * @subpackage CRM_Toolkit
 * @since 2.10.0
 * @author  NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Imports an Upwork job as a CRM Deal or Project.
 *
 * @since 2.10.0
 */
class WP_MCP_AI_Tool_Import_Upwork_Project implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * Determine whether CRM toolkit and Upwork client are available.
	 *
	 * @since 2.10.0
	 * @return bool
	 */
	public static function is_available() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_crm_toolkit'] ) && class_exists( 'WP_MCP_AI_Upwork_Client' );
	}

	/**
	 * {@inheritdoc}
	 */
	public static function get_unavailable_reason() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_crm_toolkit'] ) ) {
			return __( 'The Import Upwork Project tool requires the CRM Toolkit to be enabled.', 'mcp-ai-wpoos-pro' );
		}
		return __( 'The Import Upwork Project tool requires the Upwork client integration.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'import_upwork_project';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Import Upwork Project', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Import an Upwork job posting into the CRM as a Deal, Project, or Task for pipeline tracking.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Creating a CRM deal, project, or task record from an Upwork job posting.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Evaluating whether a job is worth pursuing; use score_upwork_job. Writing proposals; use draft_upwork_proposal.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'score_upwork_job', 'draft_upwork_proposal', 'search_upwork_jobs' ),
			'notes'           => __( 'With job_id and an Upwork connection, details are fetched via API. save_as defaults to deal.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'job_id'          => array(
					'type'        => 'string',
					'description' => __( 'Upwork job posting ID to import.', 'mcp-ai-wpoos-pro' ),
				),
				'job_title'       => array(
					'type'        => 'string',
					'description' => __( 'Job title override (used when job_id is unavailable).', 'mcp-ai-wpoos-pro' ),
				),
				'job_description' => array(
					'type'        => 'string',
					'description' => __( 'Job description (used when job_id is unavailable).', 'mcp-ai-wpoos-pro' ),
				),
				'estimated_value' => array(
					'type'        => 'number',
					'description' => __( 'Estimated project value in your default currency.', 'mcp-ai-wpoos-pro' ),
				),
				'save_as'         => array(
					'type'        => 'string',
					'description' => __( 'CRM entity type to create.', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'deal', 'project', 'task' ),
					'default'     => 'deal',
				),
				'connection_id'   => array(
					'type'        => 'string',
					'description' => __( 'Optional Remote Sites Upwork connection ID.', 'mcp-ai-wpoos-pro' ),
				),
			),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * {@inheritdoc}
	 */
	public function requires_base_pro() {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'write',
			'state-changing',
			'requires-capability',
			'external-api',
			'rate-limited',
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or WP_Error on failure.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, $this->get_required_capability() ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to import Upwork projects.', 'mcp-ai-wpoos-pro' )
			);
		}

		$job_title       = ! empty( $arguments['job_title'] ) ? sanitize_text_field( $arguments['job_title'] ) : '';
		$job_description = ! empty( $arguments['job_description'] ) ? sanitize_textarea_field( $arguments['job_description'] ) : '';
		$estimated_value = isset( $arguments['estimated_value'] ) ? (float) $arguments['estimated_value'] : 0;
		$save_as         = ! empty( $arguments['save_as'] ) ? sanitize_text_field( $arguments['save_as'] ) : 'deal';
		$job_id          = ! empty( $arguments['job_id'] ) ? sanitize_text_field( $arguments['job_id'] ) : '';

		// Attempt API fetch when a connection is available and job_id is provided.
		$api_fetched = false;
		$api_data    = array();
		if ( ! empty( $arguments['job_id'] ) ) {
			// Assistant-level restriction: an assistant with a configured Remote
			// Site Connections list may only use connections from that list.
			if ( ! empty( $arguments['connection_id'] ) ) {
				require_once WP_MCP_AI_PRO_PATH . 'includes/class-wp-mcp-ai-upwork-client.php';

				if ( ! WP_MCP_AI_Upwork_Client::is_connection_enabled_for_assistant( $arguments['connection_id'], $context ) ) {
					return new WP_Error(
						'wp_mcp_ai_upwork_connection_not_enabled',
						__( 'This Upwork connection is not enabled for this assistant. Ask the user to enable it in the assistant editor under Remote Site Connections.', 'mcp-ai-wpoos-pro' ),
						array( 'status' => 403 )
					);
				}
			}

			$api_data = $this->fetch_job_details( $arguments );
			if ( ! is_wp_error( $api_data ) && ! empty( $api_data ) ) {
				$job_title       = ! empty( $api_data['title'] ) ? $api_data['title'] : $job_title;
				$job_description = ! empty( $api_data['description'] ) ? $api_data['description'] : $job_description;
				$api_fetched     = true;
				// Resolve budget from API if not explicitly provided.
				if ( empty( $estimated_value ) ) {
					if ( ! empty( $api_data['budget']['amount'] ) ) {
						$estimated_value = (float) $api_data['budget']['amount'];
					} elseif ( ! empty( $api_data['hourlyBudget']['max'] ) ) {
						$estimated_value = (float) $api_data['hourlyBudget']['max'];
					}
				}
			}
		}

		if ( empty( $job_title ) ) {
			return new WP_Error(
				'wp_mcp_ai_missing_title',
				__( 'Please provide a job_id or job_title for the project.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Determine the default pipeline stage.
		$default_stage = 'qualification';
		if ( class_exists( 'WP_MCP_AI_CRM_Engine' ) ) {
			$settings      = WP_MCP_AI_CRM_Engine::get_toolkit_settings();
			$pipeline      = isset( $settings['pipeline']['stages'] ) ? $settings['pipeline']['stages'] : array();
			$stage_keys    = array_keys( $pipeline );
			$default_stage = ! empty( $stage_keys[0] ) ? $stage_keys[0] : 'qualification';
		}

		// Build description with all available metadata.
		$description  = '';
		$description .= $job_description . "\n\n";

		// Include skills from API response.
		$skills_list = array();
		if ( ! empty( $api_data['skills'] ) && is_array( $api_data['skills'] ) ) {
			foreach ( $api_data['skills'] as $skill ) {
				if ( ! empty( $skill['prettyName'] ) ) {
					$skills_list[] = $skill['prettyName'];
				}
			}
		}
		if ( ! empty( $skills_list ) ) {
			$description .= sprintf(
				/* translators: %s: comma-separated skills */
				__( 'Skills: %s', 'mcp-ai-wpoos-pro' ) . "\n",
				implode( ', ', $skills_list )
			);
		}

		// Include client info from API response.
		$client_name = '';
		if ( ! empty( $api_data['client']['location']['country'] ) ) {
			$client_name  = $api_data['client']['location']['country'];
			$spent        = ! empty( $api_data['client']['totalSpent']['amount'] )
				? '$' . number_format( (float) $api_data['client']['totalSpent']['amount'], 0 )
				: '';
			$hires        = isset( $api_data['client']['totalHires'] ) ? (int) $api_data['client']['totalHires'] : 0;
			$description .= sprintf(
				/* translators: 1: country, 2: spend, 3: hires */
				__( 'Client: %1$s | Spent: %2$s | Hires: %3$d', 'mcp-ai-wpoos-pro' ) . "\n",
				$client_name,
				$spent,
				$hires
			);
		}

		// Include Upwork job URL. Upwork resolves by the `~<jobId>` suffix; the
		// title slug is cosmetic, and the bare-id form redirects to the
		// listing, so both a missing slug and a missing `~` prefix are handled
		// defensively to guarantee a resolvable link.
		$upwork_url = '';
		if ( ! empty( $job_id ) ) {
			$job_ref      = 0 === strpos( $job_id, '~' ) ? $job_id : '~' . $job_id;
			$slug         = sanitize_title( $job_title );
			$upwork_url   = 'https://www.upwork.com/jobs/' . ( '' !== $slug ? $slug . '_' : '' ) . $job_ref . '/';
			$description .= sprintf(
				/* translators: %s: Upwork job URL */
				__( 'Upwork URL: %s', 'mcp-ai-wpoos-pro' ) . "\n",
				$upwork_url
			);
		}

		$description .= sprintf(
			/* translators: %s: source platform */
			__( 'Source: Upwork (imported %s)', 'mcp-ai-wpoos-pro' ) . "\n",
			gmdate( 'Y-m-d H:i' )
		);

		// Create the CRM entity.
		if ( 'deal' === $save_as && class_exists( 'WP_MCP_AI_Deal_CPT' ) ) {
			$entity_data = array(
				'name'   => $job_title,
				'value'  => $estimated_value,
				'stage'  => $default_stage,
				'source' => 'upwork',
				'notes'  => $description,
			);

			$entity_data = array_filter(
				$entity_data,
				function ( $v ) {
					return ! empty( $v ) || is_numeric( $v );
				}
			);

			$post_id = WP_MCP_AI_Deal_CPT::create( $entity_data );
		} elseif ( 'project' === $save_as && class_exists( 'WP_MCP_AI_Project_CPT' ) ) {
			$entity_data = array(
				'name'        => $job_title,
				'description' => $description,
				'budget'      => $estimated_value,
				'source'      => 'upwork',
			);

			$entity_data = array_filter(
				$entity_data,
				function ( $v ) {
					return ! empty( $v ) || is_numeric( $v );
				}
			);

			$post_id = WP_MCP_AI_Project_CPT::create( $entity_data );
		} else {
			// Generic post fallback.
			$post_data = array(
				'post_type'    => 'post',
				'post_title'   => $job_title,
				'post_content' => $description,
				'post_status'  => 'publish',
				'meta_input'   => array(
					'_wp_mcp_ai_deal_stage'  => $default_stage,
					'_wp_mcp_ai_deal_value'  => $estimated_value,
					'_wp_mcp_ai_deal_source' => 'upwork',
				),
			);
			$post_id   = wp_insert_post( $post_data, true );
		}

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		// Save Upwork URL as post meta on the created entity.
		if ( ! empty( $upwork_url ) ) {
			update_post_meta( $post_id, '_external_source_url', esc_url_raw( $upwork_url ) );
			update_post_meta( $post_id, '_external_source_id', sanitize_text_field( $job_id ) );
			update_post_meta( $post_id, '_external_source_platform', 'upwork' );
		}

		return array(
			'success'     => true,
			'save_as'     => $save_as,
			'entity_id'   => $post_id,
			'stage'       => $default_stage,
			'api_fetched' => $api_fetched,
			'message'     => $api_fetched
				? sprintf(
					/* translators: 1: entity type, 2: job title */
					__( 'Upwork project imported via API as %1$s: "%2$s".', 'mcp-ai-wpoos-pro' ),
					$save_as,
					$job_title
				)
				: sprintf(
					/* translators: 1: entity type, 2: job title */
					__( 'Upwork project saved as %1$s: "%2$s". Connect an Upwork account for automatic data import.', 'mcp-ai-wpoos-pro' ),
					$save_as,
					$job_title
				),
		);
	}

	/**
	 * Fetch job details from the Upwork API.
	 *
	 * @param array $arguments Tool arguments.
	 * @return array|WP_Error Job data or WP_Error.
	 */
	protected function fetch_job_details( $arguments ) {
		$connection_id = ! empty( $arguments['connection_id'] )
			? sanitize_text_field( $arguments['connection_id'] )
			: '';

		// MCP-mode connections fetch details through the official Upwork MCP
		// gateway (upwork__find_jobs action=get) instead of GraphQL.
		if ( class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
			$connection = WP_MCP_AI_Pro_Remote_Site_Manager::get_connection( $connection_id );
			if ( is_array( $connection ) && 'upwork' === ( isset( $connection['connection_type'] ) ? $connection['connection_type'] : '' )
				&& 'mcp' === ( isset( $connection['upwork_mode'] ) ? $connection['upwork_mode'] : '' ) ) {
				return $this->fetch_job_details_via_mcp( $connection, sanitize_text_field( $arguments['job_id'] ) );
			}
		}

		require_once WP_MCP_AI_PRO_PATH . 'includes/class-wp-mcp-ai-upwork-client.php';
		$client = new WP_MCP_AI_Upwork_Client( $connection_id );

		$job_id = sanitize_text_field( $arguments['job_id'] );

		$query = '
			query GetJobDetails($id: ID!) {
				marketplaceJobPosting(id: $id) {
					id
					title
					description
					createdDateTime
					jobType
					engagement
					duration
					budget { amount currency }
					hourlyBudget { min max currency }
					skills { prettyName }
					client {
						totalFeedback
						totalHires
						location { country }
					}
					category { name }
				}
			}
		';

		return $client->graphql( $query, array( 'id' => $job_id ) );
	}

	/**
	 * Fetch job details via the official Upwork MCP gateway.
	 *
	 * Calls upwork__find_jobs action=get with the job ID and normalizes the
	 * gateway payload into the same shape the GraphQL fetch returns so the
	 * CRM entity builder needs no mode-specific handling.
	 *
	 * @param array  $connection Stored Upwork connection array (MCP mode).
	 * @param string $job_id     Upwork job posting ID.
	 * @return array|WP_Error Normalized job data or WP_Error.
	 */
	protected function fetch_job_details_via_mcp( array $connection, $job_id ) {
		require_once WP_MCP_AI_PRO_PATH . 'includes/tools/crm/upwork/class-wp-mcp-ai-upwork-mcp-bridge.php';

		$client = WP_MCP_AI_Upwork_MCP_Bridge::build_client( $connection );
		if ( is_wp_error( $client ) ) {
			return $client;
		}

		$init = WP_MCP_AI_Upwork_MCP_Bridge::initialize( $client );
		if ( is_wp_error( $init ) ) {
			return $init;
		}

		$org_uid = WP_MCP_AI_Upwork_MCP_Bridge::resolve_org_uid( $client, $connection );
		if ( is_wp_error( $org_uid ) ) {
			return $org_uid;
		}

		$payload = WP_MCP_AI_Upwork_MCP_Bridge::call(
			$client,
			WP_MCP_AI_Upwork_MCP_Bridge::TOOL_FIND_JOBS,
			array(
				'action'  => 'get',
				'org_uid' => $org_uid,
				'params'  => array( 'id' => $job_id ),
			)
		);
		if ( is_wp_error( $payload ) ) {
			return $payload;
		}

		$details = WP_MCP_AI_Upwork_MCP_Bridge::normalize_job_details( $payload );

		// The execute() contract treats an empty fetch as "no API data".
		if ( empty( $details['title'] ) && empty( $details['description'] ) ) {
			return array();
		}

		return $details;
	}
}
