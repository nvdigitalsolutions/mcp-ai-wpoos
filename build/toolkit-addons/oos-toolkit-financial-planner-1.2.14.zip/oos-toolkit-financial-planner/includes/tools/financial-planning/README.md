# Financial Planning Toolkit

This directory contains 44 financial planning tools for the NV oOS WordPress plugin.

## Tools Created:

### Retirement Planning (5 tools)
1. ✓ retirement_calculator - Calculate retirement savings needs and projections
2. ✓ ira_roth_comparison - Compare Traditional IRA vs Roth IRA tax benefits
3. ✓ withdrawal_strategy_planner - Plan retirement withdrawal strategies
4. ✓ social_security_optimizer - Optimize social security claiming age
5. ✓ pension_analyzer - Analyze pension payout options

### Budget & Expense Tracking (5 tools)
6. ✓ budget_planner - Create and track monthly budgets
7. ✓ expense_tracker - Log and categorize expenses with receipts
8. ✓ net_worth_calculator - Track net worth over time
9. ✓ cash_flow_analyzer - Analyze income vs expenses with forecasting
10. ✓ bank_account_sync - Connect bank accounts via Plaid API

### Investment & Portfolio (5 tools)
11. ✓ portfolio_visualizer - Visualize investment portfolio (EDUCATIONAL)
12. ✓ asset_allocation_planner - Plan asset allocation by risk tolerance
13. ✓ investment_return_calculator - Calculate compound returns
14. ✓ rebalancing_analyzer - Analyze portfolio drift (EDUCATIONAL)
15. ✓ tax_loss_harvesting_tracker - Track tax-loss opportunities (EDUCATIONAL)

### Debt & Loan Management (3 tools)
16. ✓ debt_payoff_calculator - Calculate debt payoff strategies
17. ✓ mortgage_calculator - Calculate mortgage payments and refinance
18. ✓ credit_score_tracker - Track credit score over time

### Goal Planning & Savings (2 tools)
19. ✓ savings_goal_planner - Plan and track savings goals
20. ✓ emergency_fund_calculator - Calculate emergency fund needs

### Financial Literacy (4 BONUS tools)
21. ✓ financial_health_score - Assess overall financial health
22. ✓ tax_estimator - Estimate annual tax liability
23. ✓ college_savings_calculator - 529 plan calculator
24. ✓ insurance_needs_analyzer - Calculate insurance coverage needs

### Market Analysis & Research (8 tools)
Inspired by [Awesome-finance-skills](https://github.com/RKiding/Awesome-finance-skills) and industry standards (Gartner, Deloitte, McKinsey).
25. ✓ financial_news_aggregator - Aggregate financial news from multiple RSS/API sources
26. ✓ stock_data_fetcher - Search tickers and fetch OHLCV data via YFinance service
27. ✓ market_sentiment_analyzer - Rule-based financial text sentiment analysis (-1.0 to +1.0)
28. ✓ market_forecast_analyzer - Time-series forecasting (linear regression, moving avg, exp smoothing)
29. ✓ investment_signal_tracker - Track investment signal evolution (strengthen/weaken/falsify)
30. ✓ financial_logic_visualizer - Generate Mermaid diagrams for financial logic chains
31. ✓ financial_report_generator - Generate structured professional financial reports
32. ✓ financial_search - Specialized multi-source financial web search

### Transaction Categorisation (2 tools)
33. ✓ get_uncategorised_transactions - Retrieve uncategorised transactions with filters
34. ✓ categorise_transactions - Assign categories by IDs or rules (merchant_match, amount_range, date_pattern)

### Market Data & Portfolio Ops (8 tools — OpenTerminal lessons, v1.1.80)
Keyless public-endpoint tools with provider fallback chains, stale-while-revalidate caching, and technical indicators.
35. ✓ market_screener - Screen the whole US market (sector, market cap, % change, volume) via TradingView scanner
36. ✓ macro_data_fetcher - FRED keyless CSV: Treasury yields, yield-curve spread, VIX, fed funds, CPI, unemployment, index proxies
37. ✓ economic_calendar_fetcher - Forex Factory public feed: Fed/ECB/CPI/NFP events with forecast + previous
38. ✓ earnings_calendar_fetcher - Nasdaq public API: earnings events with EPS forecast, market cap, timing
39. ✓ options_chain_fetcher - Nasdaq public API: calls/puts with strike, bid/ask, volume, OI, ITM
40. ✓ crypto_market_data - CoinGecko (Binance fallback): crypto board, quotes, OHLC history
41. ✓ portfolio_transaction_log - Buy/sell ledger with average cost + realized/unrealized P&L (mcp_ai_fin_txn CPT)
42. ✓ price_alerts - Price alerts with cron evaluation + wp_mcp_ai_price_alert_triggered delivery hook (mode-aware: hourly in Finnhub realtime mode)

### Watchlist & Market Overview (2 tools — OpenStock parity, proposal 051)
43. ✓ watchlist_sync - Per-user watchlist (user meta) with list/add/remove/bulk_quote
44. ✓ market_overview_widget - TradingView embed URLs (chart/heatmap/tickers/timeline/screener) + top-movers summary

### Finnhub optional primary provider
Configure `finnhub_api_keys` under Financial Planner Settings → Market Data Providers to route quotes, OHLCV history, search, batch quotes, profiles, and news through Finnhub (BYO key, rotation, SWR cache) ahead of the yfinance microservice. `data_mode` cached|realtime controls cache TTL and the price-alert cron interval.

Plus: stock_data_fetcher gains an `indicators` action (SMA/EMA/VWAP/Bollinger/RSI/MACD computed in PHP from cached OHLCV), and financial_news_aggregator de-duplicates headlines across sources.

## Implementation Status:
- 44/44 tools fully implemented (100% complete)

All tools follow WordPress Coding Standards and implement required interfaces.
