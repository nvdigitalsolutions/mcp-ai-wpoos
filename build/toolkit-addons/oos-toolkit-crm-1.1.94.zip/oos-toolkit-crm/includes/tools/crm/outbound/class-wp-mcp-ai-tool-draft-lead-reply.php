<?php
/**
 * Draft Lead Reply — AI-assisted reply draft using the configured AI provider.
 *
 * Previously used hardcoded templates. Now sends a prompt to the configured
 * AI provider (OpenAI / Gemini / Anthropic clients) to generate a contextual
 * reply draft. Falls back to template-based drafts when no AI provider is
 * available.
 *
 * @package WP_MCP_AI_Pro
 * @since 2.3.0
 * @since 2.4.0 Uses the AI provider for real AI drafting; template fallback retained.
 * @since 2.10.0 Provider call routed through the OpenAI/Gemini/Anthropic clients;
 *                the previous wp_mcp_ai_chat_completion() helper never existed.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Draft Lead Reply — AI-assisted reply draft using the configured AI provider.
 *
 * @package WP_MCP_AI_Pro
 * @since 2.3.0
 * @since 2.4.0 Uses the AI provider for real AI drafting.
 */
class WP_MCP_AI_Tool_Draft_Lead_Reply implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * Whether this tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		$s = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $s['enable_crm_toolkit'] ); }

	/**
	 * Reason the tool is unavailable.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'CRM Toolkit required.', 'mcp-ai-wpoos-pro' ); }

	/**
	 * Tool slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'draft_lead_reply'; }

	/**
	 * Tool display name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'Draft Lead Reply', 'mcp-ai-wpoos-pro' ); }

	/**
	 * Tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Generate an AI-assisted reply draft for a lead message using the configured AI provider. Does NOT send — returns the draft for review.', 'mcp-ai-wpoos-pro' ); }

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Generating an AI-assisted reply draft for a lead message to review before sending, with tone templates as fallback.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Actually sending the reply; use send_lead_email, send_lead_sms, or send_lead_whatsapp. Automated rule replies; use auto_reply_inbound.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'send_lead_email', 'send_lead_sms', 'auto_reply_inbound' ),
			'notes'           => __( 'Requires incoming_message; tone must be friendly, professional, concise, or urgent. Returns a draft and never sends.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * Parameters schema.
	 *
	 * @return array
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'lead_id'          => array( 'type' => 'integer' ),
				'incoming_message' => array(
					'type'        => 'string',
					'description' => __( 'The message you are replying to.', 'mcp-ai-wpoos-pro' ),
				),
				'channel'          => array(
					'type'    => 'string',
					'default' => 'email',
				),
				'tone'             => array(
					'type'    => 'string',
					'enum'    => array( 'friendly', 'professional', 'concise', 'urgent' ),
					'default' => 'professional',
				),
				'context_notes'    => array(
					'type'        => 'string',
					'description' => __( 'Additional context about the lead (company, role, previous interactions) to help the AI craft a better reply.', 'mcp-ai-wpoos-pro' ),
				),
			),
			'required'   => array( 'incoming_message' ),
		); }

	/**
	 * Required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'edit_posts'; }

	/**
	 * Whether this tool requires base pro.
	 *
	 * @return bool
	 */
	public function requires_base_pro() {
		return true; }

	/**
	 * Capability flags.
	 *
	 * @return array
	 */
	public function get_capability_flags() {
		return array( 'pro', 'database-read', 'requires-capability', 'ai-call' ); }

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$incoming = sanitize_textarea_field( $arguments['incoming_message'] );
		$tone     = sanitize_key( $arguments['tone'] ?? 'professional' );
		$channel  = sanitize_key( $arguments['channel'] ?? 'email' );

		// Gather lead context if lead_id provided.
		$context_notes = sanitize_textarea_field( $arguments['context_notes'] ?? '' );
		$lead_id       = isset( $arguments['lead_id'] ) ? absint( $arguments['lead_id'] ) : 0;

		if ( $lead_id && empty( $context_notes ) ) {
			$context_notes = $this->build_lead_context( $lead_id );
		}

		// Try AI-powered draft first.
		$ai_draft = $this->generate_ai_draft( $incoming, $tone, $channel, $context_notes );

		if ( ! is_wp_error( $ai_draft ) && ! empty( $ai_draft ) ) {
			return array(
				'success'    => true,
				'draft'      => $ai_draft,
				'tone'       => $tone,
				'channel'    => $channel,
				'message'    => __( 'AI-generated reply draft. Review before sending.', 'mcp-ai-wpoos-pro' ),
				'powered_by' => 'ai',
			);
		}

		// Fall back to template-based draft.
		$template_draft = $this->get_template_draft( $tone, $channel );

		return array(
			'success'    => true,
			'draft'      => $template_draft,
			'tone'       => $tone,
			'channel'    => $channel,
			'message'    => __( 'Template-based reply draft (AI provider unavailable). Review before sending.', 'mcp-ai-wpoos-pro' ),
			'powered_by' => 'template',
		);
	}

	/**
	 * Generate an AI-powered reply draft using the configured AI provider.
	 *
	 * Routes through the OpenAI / Gemini / Anthropic provider clients
	 * (resolved via the credential resolver) instead of a helper function.
	 *
	 * @since 2.4.0
	 * @since 2.10.0 Rewritten around the provider clients; the previous
	 *               implementation called the nonexistent
	 *               wp_mcp_ai_chat_completion() helper and could never
	 *               reach a provider.
	 *
	 * @param string $incoming      The incoming message to reply to.
	 * @param string $tone          Desired tone (friendly, professional, concise, urgent).
	 * @param string $channel       Communication channel (email, sms, whatsapp).
	 * @param string $context_notes Additional lead context.
	 * @return string|WP_Error AI-generated draft or WP_Error.
	 */
	private function generate_ai_draft( $incoming, $tone, $channel, $context_notes ) {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		$provider = $this->get_ai_provider();

		if ( is_wp_error( $provider ) ) {
			return $provider;
		}

		$model  = $this->get_ai_model( $provider, $settings );
		$client = $this->get_ai_client( $provider );

		if ( is_wp_error( $client ) ) {
			return $client;
		}

		// Channel-specific length limits.
		$max_length_map = array(
			'sms'      => 160,
			'whatsapp' => 1000,
			'email'    => 2000,
		);
		$max_length     = $max_length_map[ $channel ] ?? 2000;

		// Tone instructions.
		$tone_instructions = array(
			'friendly'     => 'Be warm, approachable, and conversational. Use casual language.',
			'professional' => 'Be formal, polite, and business-appropriate. Use proper salutations.',
			'concise'      => 'Be very brief and to the point. Maximum 2-3 short sentences.',
			'urgent'       => 'Be prompt and direct. Convey urgency without being pushy.',
		);
		$tone_guide        = $tone_instructions[ $tone ] ?? $tone_instructions['professional'];

		// Build the prompt.
		$prompt = sprintf(
			"You are a CRM assistant drafting a %s reply to a lead via %s channel. %s\n\n"
			. 'Keep the reply under %d characters. Do NOT include a subject line. '
			. "Return ONLY the draft text — no markdown, no explanations, no meta-commentary.\n\n",
			$tone,
			$channel,
			$tone_guide,
			$max_length
		);

		if ( ! empty( $context_notes ) ) {
			$prompt .= "LEAD CONTEXT:\n" . $context_notes . "\n\n";
		}

		$prompt .= "INCOMING MESSAGE:\n" . $incoming . "\n\nDRAFT REPLY:";

		$response = $client->create_chat_completion(
			array(
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			),
			array(
				'model'       => $model,
				'max_tokens'  => max( 100, min( 800, (int) ( $max_length / 2 ) ) ),
				'temperature' => 0.7,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// Some providers (Gemini, and OpenAI-compatible gateways such as vLLM)
		// return message.content as an array of parts; flatten before any
		// string operation to avoid the fatal `trim(): Argument #1 ($value)
		// must be of type string, array given`.
		$content = $this->flatten_response_content(
			isset( $response['choices'][0]['message']['content'] )
				? $response['choices'][0]['message']['content']
				: ( isset( $response['content'] ) ? $response['content'] : '' )
		);

		$content = trim( $content );

		if ( empty( $content ) ) {
			return new WP_Error( 'ai_empty_response', __( 'AI returned an empty draft.', 'mcp-ai-wpoos-pro' ) );
		}

		// Strip any markdown code fences that may wrap the response.
		$content = preg_replace( '/^```[\w]*\s*\n/', '', $content );
		$content = preg_replace( '/\n```\s*$/', '', $content );

		return $content;
	}

	/**
	 * Get the best available AI provider from plugin settings.
	 *
	 * @since 2.10.0
	 *
	 * @return string|WP_Error Provider name or WP_Error.
	 */
	private function get_ai_provider() {
		if ( WP_MCP_AI_Credential_Resolver::has_credentials( 'openai' ) ) {
			return 'openai';
		}
		if ( WP_MCP_AI_Credential_Resolver::has_credentials( 'gemini' ) ) {
			return 'gemini';
		}
		if ( WP_MCP_AI_Credential_Resolver::has_credentials( 'anthropic' ) ) {
			return 'anthropic';
		}
		return new WP_Error(
			'wp_mcp_ai_no_ai_provider',
			__( 'No AI provider configured. Please add an OpenAI, Gemini, or Anthropic API key in plugin settings.', 'mcp-ai-wpoos-pro' )
		);
	}

	/**
	 * Get a suitable AI model identifier for the provider.
	 *
	 * @since 2.10.0
	 *
	 * @param string $provider Provider name.
	 * @param array  $settings Plugin settings.
	 * @return string Model identifier.
	 */
	private function get_ai_model( $provider, $settings ) {
		switch ( $provider ) {
			case 'openai':
				return ! empty( $settings['openai_default_model'] ) ? $settings['openai_default_model'] : 'gpt-4.1';
			case 'gemini':
				return ! empty( $settings['gemini_default_model'] ) ? $settings['gemini_default_model'] : 'gemini-2.5-flash';
			case 'anthropic':
				return 'claude-sonnet-4-5-20250929';
			default:
				return 'gpt-4.1';
		}
	}

	/**
	 * Instantiate the AI client for the given provider.
	 *
	 * @since 2.10.0
	 *
	 * @param string $provider Provider name.
	 * @return object|WP_Error AI client instance or WP_Error.
	 */
	private function get_ai_client( $provider ) {
		switch ( $provider ) {
			case 'openai':
				if ( ! class_exists( 'WP_MCP_AI_OpenAI_Client' ) ) {
					return new WP_Error( 'wp_mcp_ai_client_unavailable', __( 'OpenAI client not available.', 'mcp-ai-wpoos-pro' ) );
				}
				return new WP_MCP_AI_OpenAI_Client();

			case 'gemini':
				if ( ! class_exists( 'WP_MCP_AI_Gemini_Client' ) ) {
					return new WP_Error( 'wp_mcp_ai_client_unavailable', __( 'Gemini client not available.', 'mcp-ai-wpoos-pro' ) );
				}
				return new WP_MCP_AI_Gemini_Client();

			case 'anthropic':
				if ( ! class_exists( 'WP_MCP_AI_Anthropic_Client' ) ) {
					return new WP_Error( 'wp_mcp_ai_client_unavailable', __( 'Anthropic client not available.', 'mcp-ai-wpoos-pro' ) );
				}
				return new WP_MCP_AI_Anthropic_Client();

			default:
				return new WP_Error( 'wp_mcp_ai_unsupported_provider', __( 'Unsupported AI provider.', 'mcp-ai-wpoos-pro' ) );
		}
	}

	/**
	 * Flatten a provider response content value into a string.
	 *
	 * Handles the three shapes seen in the wild: a plain string (OpenAI),
	 * an array of `{type,text}` parts (Gemini `normalize_response()`),
	 * and an array of strings.
	 *
	 * @since 2.10.0
	 *
	 * @param mixed $content Raw message content.
	 * @return string Flattened text.
	 */
	private function flatten_response_content( $content ) {
		if ( is_string( $content ) ) {
			return $content;
		}

		if ( is_array( $content ) ) {
			$text = '';
			foreach ( $content as $part ) {
				if ( is_array( $part ) && isset( $part['text'] ) ) {
					$text .= $part['text'];
				} elseif ( is_string( $part ) ) {
					$text .= $part;
				}
			}
			return $text;
		}

		return '';
	}

	/**
	 * Build a context string from lead post meta for AI prompting.
	 *
	 * @param int $lead_id Lead post ID.
	 * @return string Context text.
	 */
	private function build_lead_context( $lead_id ) {
		$parts = array();

		$name = get_post_meta( $lead_id, 'first_name', true );
		if ( $name ) {
			/* translators: %s: lead name */
			$parts[] = sprintf( __( 'Name: %s', 'mcp-ai-wpoos-pro' ), $name );
		}

		$company = get_post_meta( $lead_id, 'company', true );
		if ( $company ) {
			/* translators: %s: company name */
			$parts[] = sprintf( __( 'Company: %s', 'mcp-ai-wpoos-pro' ), $company );
		}

		$role = get_post_meta( $lead_id, 'role', true );
		if ( $role ) {
			/* translators: %s: job role */
			$parts[] = sprintf( __( 'Role: %s', 'mcp-ai-wpoos-pro' ), $role );
		}

		$lifecycle = get_post_meta( $lead_id, 'lifecycle_stage', true );
		if ( $lifecycle ) {
			/* translators: %s: lifecycle stage */
			$parts[] = sprintf( __( 'Lifecycle: %s', 'mcp-ai-wpoos-pro' ), $lifecycle );
		}

		$score = get_post_meta( $lead_id, 'lead_score', true );
		if ( '' !== $score && null !== $score ) {
			/* translators: %s: lead score value */
			$parts[] = sprintf( __( 'Lead Score: %s', 'mcp-ai-wpoos-pro' ), $score );
		}

		return implode( "\n", $parts );
	}

	/**
	 * Template-based fallback drafts (used when AI is unavailable).
	 *
	 * @param string $tone    Desired tone.
	 * @param string $channel Communication channel.
	 * @return string Draft text.
	 */
	private function get_template_draft( $tone, $channel ) {
		$templates = array(
			'friendly'     => __( "Hi there!\n\nThanks so much for reaching out — we really appreciate it. I'd love to help with what you're looking for.\n\nLet's set up a quick call this week to discuss. What time works best for you?\n\nBest,\n[Your Name]", 'mcp-ai-wpoos-pro' ),
			'professional' => __( "Hello,\n\nThank you for your inquiry. I would be happy to provide more information and address any questions you may have.\n\nWould you be available for a brief call this week to discuss further?\n\nKind regards,\n[Your Name]", 'mcp-ai-wpoos-pro' ),
			'concise'      => __( "Thanks for reaching out. Happy to help — when would be a good time to connect?\n\nBest,\n[Your Name]", 'mcp-ai-wpoos-pro' ),
			'urgent'       => __( "Hi,\n\nI saw your message and want to make sure we respond quickly. Let's connect ASAP — are you available today?\n\nBest,\n[Your Name]", 'mcp-ai-wpoos-pro' ),
		);

		$draft = $templates[ $tone ] ?? $templates['professional'];

		// Truncate for SMS.
		if ( 'sms' === $channel && mb_strlen( $draft ) > 160 ) {
			$draft = mb_substr( $draft, 0, 157 ) . '...';
		}

		return $draft;
	}
}
