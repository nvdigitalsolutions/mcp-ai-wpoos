<?php
/**
 * Generate PDF Tool - Simplified PDF generation.
 *
 * Simplified interface for PDF generation that delegates to the Pro PDF tool.
 * Provides a simpler API for common PDF generation use cases.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.2.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load the chat and document response traits from base plugin.
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-document-response.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php';

// Load the Pro PDF tool.
require_once __DIR__ . '/class-wp-mcp-ai-tool-pro-pdf.php';

/**
 * Simplified PDF generation tool.
 *
 * Provides a simpler interface for PDF generation by delegating
 * to the more powerful Pro PDF tool with sensible defaults.
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Tool_Generate_PDF implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Tool_Document_Response;

	/**
	 * Pro PDF tool instance.
	 *
	 * @var WP_MCP_AI_Tool_Pro_PDF
	 */
	protected $pro_pdf_tool;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->pro_pdf_tool = new WP_MCP_AI_Tool_Pro_PDF();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_pdf';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate PDF', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Generate PDF documents from content. Simplified interface for creating PDFs with basic formatting and structure. For advanced features, use Pro PDF Document tool.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Turning plain content into a simple PDF when basic formatting is all that is needed.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'When you need advanced layout, tables, or provider-based generation; use pro_pdf_document.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'pro_pdf_document', 'html_to_pdf', 'generate_word' ),
			'notes'           => __( 'Delegates to pro_pdf_document with simplified arguments and writes the PDF to the media library.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'content' => array(
					'type'        => 'string',
					'description' => __( 'Content to include in the PDF document.', 'mcp-ai-wpoos-pro' ),
				),
				'title'   => array(
					'type'        => 'string',
					'description' => __( 'Document title.', 'mcp-ai-wpoos-pro' ),
				),
			),
			'required'   => array( 'content' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-capability',
			'requires-model',
			'consumes-tokens',
			'write',
			'state-changing',
		);
	}

	/**
	 * Get required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Delegate to Pro PDF tool with simplified parameters.
		$pro_arguments = array(
			'operation' => 'generate',
			'content'   => $arguments['content'] ?? '',
			'title'     => $arguments['title'] ?? 'Document',
		);

		return $this->pro_pdf_tool->execute( $pro_arguments, $context );
	}
}
