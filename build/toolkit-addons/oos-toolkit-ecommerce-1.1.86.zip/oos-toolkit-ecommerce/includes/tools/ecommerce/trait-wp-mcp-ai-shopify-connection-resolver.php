<?php
/**
 * Shopify Connection Resolver Trait.
 *
 * Provides shared connection resolution logic for all Shopify tools.
 * When a connection_id is not explicitly provided in the tool arguments,
 * this trait automatically resolves it from the assistant's enabled
 * remote connections, eliminating the need for the AI to ask the user
 * for a connection ID.
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trait WP_MCP_AI_Shopify_Connection_Resolver
 *
 * Provides automatic Shopify connection resolution from assistant context.
 *
 * @since 1.0.0
 */
trait WP_MCP_AI_Shopify_Connection_Resolver {

	/**
	 * Resolve a Shopify connection ID from arguments or assistant context.
	 *
	 * If the connection_id is provided in arguments, it is used directly.
	 * Otherwise, the method checks the assistant's enabled remote connections
	 * and automatically selects the appropriate Shopify connection.
	 *
	 * @since 1.0.0
	 *
	 * @param array             $arguments          Tool arguments.
	 * @param array             $context            Execution context (must include assistant_id).
	 * @param string|array|null $required_api_mode  Optional API mode requirement (e.g. 'catalog_api', or an array of allowed modes).
	 * @return string|WP_Error Connection ID or WP_Error if none found.
	 */
	protected function resolve_shopify_connection_id( $arguments, $context, $required_api_mode = null ) {
		// 1. If connection_id is explicitly provided, use it.
		$connection_id = isset( $arguments['connection_id'] ) ? sanitize_key( $arguments['connection_id'] ) : '';

		if ( ! empty( $connection_id ) ) {
			return $connection_id;
		}

		// 2. Try to resolve from assistant context.
		if ( ! class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
			return new WP_Error(
				'wp_mcp_ai_shopify_no_manager',
				__( 'Remote Sites Manager is not available.', 'mcp-ai-wpoos-pro' )
			);
		}

		$shopify_connections = $this->get_available_shopify_connections( $context, $required_api_mode );

		if ( empty( $shopify_connections ) ) {
			return new WP_Error(
				'wp_mcp_ai_shopify_missing_connection',
				__( 'No Shopify connections are configured or enabled for this assistant. Please configure a Shopify connection in NV oOS → Remote Sites and enable it for this assistant.', 'mcp-ai-wpoos-pro' )
			);
		}

		// 3. If exactly one Shopify connection is available, use it automatically.
		if ( 1 === count( $shopify_connections ) ) {
			return $shopify_connections[0]['id'];
		}

		// 4. Multiple Shopify connections found — return an error listing them.
		$connection_list = $this->format_available_connections_message( $shopify_connections );

		return new WP_Error(
			'wp_mcp_ai_shopify_missing_connection',
			sprintf(
				/* translators: %s: list of available connections */
				__( 'Multiple Shopify connections are available. Please specify a connection_id.%s', 'mcp-ai-wpoos-pro' ),
				$connection_list
			)
		);
	}

	/**
	 * Get available Shopify connections for the current assistant.
	 *
	 * Filters connections by:
	 * - Connection type: 'shopify'
	 * - Enabled globally
	 * - Enabled for the assistant (if assistant context is provided)
	 * - Optional API mode filter
	 *
	 * @since 1.0.0
	 *
	 * @param array       $context          Execution context.
	 * @param string|null $required_api_mode Optional API mode filter (e.g., 'catalog_api', 'admin_api').
	 * @return array Array of matching Shopify connections with id, name, url, api_mode keys.
	 */
	protected function get_available_shopify_connections( $context = array(), $required_api_mode = null ) {
		if ( ! class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
			return array();
		}

		$all_connections = WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections();

		$assistant_id = isset( $context['assistant_id'] ) ? absint( $context['assistant_id'] ) : 0;

		$enabled_for_assistant = array();
		if ( $assistant_id ) {
			$enabled_for_assistant = get_post_meta( $assistant_id, '_wp_mcp_ai_pro_remote_connections', true );
			if ( ! is_array( $enabled_for_assistant ) ) {
				$enabled_for_assistant = array();
			}
		}

		$shopify_connections = array();

		foreach ( $all_connections as $connection ) {
			// Must be a Shopify connection.
			if ( empty( $connection['connection_type'] ) || 'shopify' !== $connection['connection_type'] ) {
				continue;
			}

			// Must be enabled globally.
			if ( empty( $connection['enabled'] ) ) {
				continue;
			}

			// If assistant context is provided and connections are configured,
			// only include connections enabled for this assistant.
			if ( $assistant_id && ! empty( $enabled_for_assistant ) && ! in_array( $connection['id'], $enabled_for_assistant, true ) ) {
				continue;
			}

			// If a specific API mode is required, filter by it. A string
			// matches a single mode; an array matches any of the listed
			// modes (used by mode-aware tools such as the catalog tool).
			if ( null !== $required_api_mode ) {
				$allowed_modes = (array) $required_api_mode;
				$api_mode      = isset( $connection['shopify_api_mode'] ) ? $connection['shopify_api_mode'] : 'admin_api';
				if ( ! in_array( $api_mode, $allowed_modes, true ) ) {
					continue;
				}
			}

			$shopify_connections[] = array(
				'id'       => $connection['id'],
				'name'     => isset( $connection['name'] ) ? $connection['name'] : '',
				'url'      => isset( $connection['url'] ) ? $connection['url'] : '',
				'api_mode' => isset( $connection['shopify_api_mode'] ) ? $connection['shopify_api_mode'] : 'admin_api',
			);
		}

		return $shopify_connections;
	}

	/**
	 * Format a list of available Shopify connections for error messages.
	 *
	 * @since 1.0.0
	 *
	 * @param array $connections Array of connection data arrays.
	 * @return string Formatted connection list string.
	 */
	protected function format_available_connections_message( $connections ) {
		if ( empty( $connections ) ) {
			return '';
		}

		$formatted = array();
		foreach ( $connections as $conn ) {
			$label = sprintf( '%s (%s)', $conn['name'], $conn['id'] );
			if ( ! empty( $conn['url'] ) ) {
				$label .= sprintf( ' — %s', $conn['url'] );
			}
			$formatted[] = $label;
		}

		return ' Available Shopify connections: ' . implode( ', ', $formatted ) . '.';
	}

	/**
	 * Check whether an API mode is one of the keyless UCP catalog modes.
	 *
	 * Storefront Catalog MCP and Global Catalog MCP are live agent-query
	 * modes: they only expose the canonical catalog tools (search_catalog,
	 * lookup_catalog, get_product), and UCP usage guidelines prohibit
	 * caching their results or product images.
	 *
	 * @since 1.1.81
	 *
	 * @param string $api_mode Connection API mode.
	 * @return bool True for storefront_catalog / global_catalog modes.
	 */
	protected function is_ucp_catalog_api_mode( $api_mode ) {
		return in_array( $api_mode, array( 'storefront_catalog', 'global_catalog' ), true );
	}

	/**
	 * Human-readable label for a Shopify API mode.
	 *
	 * @since 1.1.81
	 *
	 * @param string $api_mode Connection API mode.
	 * @return string Label for error messages and summaries.
	 */
	protected function get_shopify_api_mode_label( $api_mode ) {
		$labels = array(
			'admin_api'          => __( 'Admin API (store management)', 'mcp-ai-wpoos-pro' ),
			'catalog_api'        => __( 'Catalog API (REST, deprecated by Shopify)', 'mcp-ai-wpoos-pro' ),
			'storefront_catalog' => __( 'Storefront Catalog MCP (single-store UCP, keyless)', 'mcp-ai-wpoos-pro' ),
			'global_catalog'     => __( 'Global Catalog MCP (cross-store UCP, keyless)', 'mcp-ai-wpoos-pro' ),
		);

		return isset( $labels[ $api_mode ] ) ? $labels[ $api_mode ] : (string) $api_mode;
	}

	/**
	 * Build the "admin-only operation on a catalog connection" error.
	 *
	 * Catalog connections (catalog_api, storefront_catalog, global_catalog)
	 * only expose live product search and lookup — admin operations such as
	 * orders, customers, or inventory cannot run against them. UCP catalog
	 * modes are additionally live agent-query modes whose results must not
	 * be cached, so the agent is pointed at the live catalog tools instead
	 * of being left with a confusing API failure.
	 *
	 * @since 1.1.81
	 *
	 * @param string $api_mode  Connection API mode.
	 * @param string $operation Human-readable operation name (e.g. 'Shopify orders').
	 * @return WP_Error
	 */
	protected function get_catalog_mode_admin_only_error( $api_mode, $operation ) {
		if ( $this->is_ucp_catalog_api_mode( $api_mode ) ) {
			$message = sprintf(
				/* translators: 1: operation name, 2: API mode label */
				__( '%1$s are not available for this Shopify connection: it is configured for the %2$s mode, which is a live agent-query catalog mode. UCP catalog modes only expose live catalog tools (search_catalog, lookup_catalog, get_product) and their results must not be cached, so no local copies exist. Use the live catalog tools (shopify_catalog, or shopify_products list/search/get) with this connection, or switch to an admin_api connection for %1$s.', 'mcp-ai-wpoos-pro' ),
				$operation,
				$this->get_shopify_api_mode_label( $api_mode )
			);
		} else {
			$message = sprintf(
				/* translators: 1: operation name, 2: API mode label */
				__( '%1$s are not available for this Shopify connection: it is configured for the %2$s mode, which only exposes catalog search and lookup. Use the catalog tools (shopify_catalog, or shopify_products list/search/get) with this connection, or switch to an admin_api connection for %1$s.', 'mcp-ai-wpoos-pro' ),
				$operation,
				$this->get_shopify_api_mode_label( $api_mode )
			);
		}

		return new WP_Error( 'wp_mcp_ai_shopify_catalog_mode_admin_only', $message );
	}

	/**
	 * Check if a Shopify connection is enabled for the current assistant.
	 *
	 * @since 1.0.0
	 *
	 * @param string $connection_id Connection ID.
	 * @param array  $context       Execution context.
	 * @return bool True if enabled, false otherwise.
	 */
	protected function is_shopify_connection_enabled_for_assistant( $connection_id, $context ) {
		$assistant_id = isset( $context['assistant_id'] ) ? absint( $context['assistant_id'] ) : 0;

		if ( ! $assistant_id ) {
			return true;
		}

		$enabled_connections = get_post_meta( $assistant_id, '_wp_mcp_ai_pro_remote_connections', true );

		if ( ! is_array( $enabled_connections ) ) {
			return true;
		}

		return in_array( $connection_id, $enabled_connections, true );
	}
}
