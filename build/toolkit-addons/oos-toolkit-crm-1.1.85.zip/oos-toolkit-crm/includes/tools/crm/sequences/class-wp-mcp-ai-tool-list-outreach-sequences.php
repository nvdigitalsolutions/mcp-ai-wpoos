<?php
/**
 * List Outreach Sequences — list all outreach sequence definitions.
 *
 * @package WP_MCP_AI_Pro
 * @since 2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * List Outreach Sequences tool.
 *
 * @since 2.3.0
 */
class WP_MCP_AI_Tool_List_Outreach_Sequences implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * {@inheritdoc}
	 */
	public static function is_available() {
		$s = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $s['enable_crm_toolkit'] );
	}

	/**
	 * {@inheritdoc}
	 */
	public static function get_unavailable_reason() {
		return __( 'CRM Toolkit required.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'list_outreach_sequences';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'List Outreach Sequences', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'List all outreach sequence definitions.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Listing outreach sequence definitions with pagination to discover sequence_id values.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Performance for one sequence; use get_sequence_performance. Creating a sequence; use create_outreach_sequence.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'get_sequence_performance', 'create_outreach_sequence', 'update_outreach_sequence' ),
			'notes'           => __( 'Supports per_page and page; each entry includes id, name, step_count, and the full steps array.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'per_page' => array(
					'type'    => 'integer',
					'default' => 20,
				),
				'page'     => array(
					'type'    => 'integer',
					'default' => 1,
				),
			),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * {@inheritdoc}
	 */
	public function requires_base_pro() {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array( 'pro', 'database-read', 'requires-capability' );
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$q    = new WP_Query(
			array(
				'post_type'      => 'mcp_ai_sequence',
				'post_status'    => 'publish',
				'posts_per_page' => min( 100, absint( $arguments['per_page'] ?? 20 ) ),
				'paged'          => max( 1, absint( $arguments['page'] ?? 1 ) ),
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		$seqs = array();
		foreach ( $q->posts as $p ) {
			$seqs[] = array(
				'id'          => $p->ID,
				'name'        => $p->post_title,
				'description' => $p->post_content,
				'step_count'  => (int) get_post_meta( $p->ID, 'step_count', true ),
				'steps'       => get_post_meta( $p->ID, 'steps', true ),
			);
		}
		return array(
			'success'   => true,
			'sequences' => $seqs,
			'total'     => $q->found_posts,
			'per_page'  => min( 100, absint( $arguments['per_page'] ?? 20 ) ),
			'page'      => max( 1, absint( $arguments['page'] ?? 1 ) ),
			'pages'     => max( 1, $q->max_num_pages ),
		);
	}
}
