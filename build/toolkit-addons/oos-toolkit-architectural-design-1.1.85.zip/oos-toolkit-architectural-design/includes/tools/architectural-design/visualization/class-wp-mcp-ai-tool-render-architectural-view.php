<?php
/**
 * Tool for rendering architectural views.
 *
 * Generates photorealistic renderings from 3D models.
 * Supports various viewing angles and lighting conditions.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @phase Phase 2.10
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-image-response.php';

/**
 * Render architectural views.
 */
class WP_MCP_AI_Tool_Render_Architectural_View implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/* WP_MCP_AI_AVAILABILITY_BLOCK */
	/**
	 * Whether this tool is available for registration.
	 *
	 * @since 1.2.0
	 *
	 * @return bool True when the Architectural Design toolkit is enabled
	 *              and the host plugin is not running in base mode.
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_architectural_design_toolkit'] );
	}

	/**
	 * Reason this tool is unavailable, if any.
	 *
	 * @since 1.2.0
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'Architectural Design toolkit is not enabled.', 'mcp-ai-wpoos-pro' );
	}

	use WP_MCP_AI_Tool_Image_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'render_architectural_view';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Render Architectural View', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Generate photorealistic renderings from 3D models. Supports various camera angles, lighting, and environmental conditions.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Generating photorealistic still renderings from a 3D model with camera angle, time of day, weather, quality, and resolution controls.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Animated tours; use create_walkthrough_animation. Building the model; use generate_3d_model. 2D drawings; use generate_architectural_drawing.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'generate_3d_model', 'create_walkthrough_animation', 'generate_architectural_drawing' ),
			'notes'           => __( 'Async output; quality ranges from draft to ultra and resolution from 1080p to 4k.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'model_data'          => array(
					'type'        => 'object',
					'description' => __( '3D model data to render.', 'mcp-ai-wpoos-pro' ),
				),
				'view_angle'          => array(
					'type'        => 'string',
					'description' => __( 'Camera angle: "front", "back", "left", "right", "aerial", "interior".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'front', 'back', 'left', 'right', 'aerial', 'interior' ),
					'default'     => 'front',
				),
				'time_of_day'         => array(
					'type'        => 'string',
					'description' => __( 'Lighting time: "morning", "noon", "afternoon", "sunset", "night".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'morning', 'noon', 'afternoon', 'sunset', 'night' ),
					'default'     => 'noon',
				),
				'weather'             => array(
					'type'        => 'string',
					'description' => __( 'Weather condition: "sunny", "cloudy", "overcast", "rainy".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'sunny', 'cloudy', 'overcast', 'rainy' ),
					'default'     => 'sunny',
				),
				'quality'             => array(
					'type'        => 'string',
					'description' => __( 'Rendering quality: "draft", "medium", "high", "ultra".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'draft', 'medium', 'high', 'ultra' ),
					'default'     => 'medium',
				),
				'resolution'          => array(
					'type'        => 'string',
					'description' => __( 'Image resolution: "1080p", "2k", "4k".', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( '1080p', '2k', '4k' ),
					'default'     => '1080p',
				),
				'include_environment' => array(
					'type'        => 'boolean',
					'description' => __( 'Include surrounding environment (landscaping, sky, etc.).', 'mcp-ai-wpoos-pro' ),
					'default'     => true,
				),
			),
			'required'             => array( 'model_data' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-capability',
			'write',
			'async',
			'long-running',
			'performance-impact',
			'large-response',
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'upload_files' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to render views.', 'mcp-ai-wpoos-pro' )
			);
		}

		// Validate model data.
		if ( empty( $arguments['model_data'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_arguments',
				__( '3D model data is required.', 'mcp-ai-wpoos-pro' )
			);
		}

		$model_data          = $arguments['model_data'];
		$view_angle          = isset( $arguments['view_angle'] ) ? sanitize_text_field( $arguments['view_angle'] ) : 'front';
		$time_of_day         = isset( $arguments['time_of_day'] ) ? sanitize_text_field( $arguments['time_of_day'] ) : 'noon';
		$weather             = isset( $arguments['weather'] ) ? sanitize_text_field( $arguments['weather'] ) : 'sunny';
		$quality             = isset( $arguments['quality'] ) ? sanitize_text_field( $arguments['quality'] ) : 'medium';
		$resolution          = isset( $arguments['resolution'] ) ? sanitize_text_field( $arguments['resolution'] ) : '1080p';
		$include_environment = isset( $arguments['include_environment'] ) ? (bool) $arguments['include_environment'] : true;

		// Render view.
		$rendering = $this->render_view( $model_data, $view_angle, $time_of_day, $weather, $quality, $resolution, $include_environment );

		if ( is_wp_error( $rendering ) ) {
			return $rendering;
		}

		// Return structured rendering data.
		$result = array(
			'success'   => true,
			'url'       => $rendering['image_url'],
			'prompt'    => sprintf( 'Architectural view: %s angle, %s, %s weather', $view_angle, $time_of_day, $weather ),
			'width'     => isset( $rendering['dimensions']['width'] ) ? $rendering['dimensions']['width'] : null,
			'height'    => isset( $rendering['dimensions']['height'] ) ? $rendering['dimensions']['height'] : null,
			'rendering' => $rendering,
			'settings'  => array(
				'view_angle'  => $view_angle,
				'time_of_day' => $time_of_day,
				'weather'     => $weather,
				'quality'     => $quality,
				'resolution'  => $resolution,
			),
			'text'      => __( 'Successfully rendered architectural view.', 'mcp-ai-wpoos-pro' ),
		);

		return $this->add_image_html_to_response( $result );
	}

	/**
	 * Render architectural view.
	 *
	 * @param array  $model_data          Model data.
	 * @param string $view_angle          View angle.
	 * @param string $time_of_day         Time of day.
	 * @param string $weather             Weather condition.
	 * @param string $quality             Rendering quality.
	 * @param string $resolution          Resolution.
	 * @param bool   $include_environment Include environment.
	 * @return array Rendering data.
	 */
	protected function render_view( $model_data, $view_angle, $time_of_day, $weather, $quality, $resolution, $include_environment ) {
		return array(
			'image_url'   => '',
			'format'      => 'png',
			'dimensions'  => array(
				'width'  => 1920,
				'height' => 1080,
			),
			'render_time' => 0,
			'metadata'    => array(
				'view_angle'  => $view_angle,
				'time_of_day' => $time_of_day,
				'weather'     => $weather,
				'rendered_at' => current_time( 'mysql' ),
			),
		);
	}
}
