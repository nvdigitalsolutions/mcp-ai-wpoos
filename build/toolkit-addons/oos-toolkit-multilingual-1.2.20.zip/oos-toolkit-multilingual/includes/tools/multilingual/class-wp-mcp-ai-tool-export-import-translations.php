<?php
/**
 * Export/Import Translations Tool
 *
 * Export and import translations in XLIFF, PO, or JSON formats for professional translation services.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP_MCP_AI_Tool_Export_Import_Translations tool.
 */
class WP_MCP_AI_Tool_Export_Import_Translations implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * Check if tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}

		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_multilingual_toolkit'] );
	}

	/**
	 * Get unavailable reason.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_multilingual_toolkit'] ) ) {
			return __( 'Multi-language Content toolkit is not enabled.', 'mcp-ai-wpoos-pro' );
		}
		return __( 'Export/Import Translations tool is not available.', 'mcp-ai-wpoos-pro' );
	}


	/**

	 * Get the tool slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'export_import_translations';
	}

	/**
	 * Get the tool name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'Export/Import Translations', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get the tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Export and import translations in XLIFF, PO, or JSON formats for professional translation services.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Exchanging translations with a professional translation service in XLIFF, PO, or JSON format.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Translating content on-site; use auto_translate_content for AI translation instead.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'auto_translate_content', 'find_untranslated_strings' ),
			'notes'           => __( 'Pass action export or import with a format of xliff, po, or json and the target language.', 'mcp-ai-wpoos-pro' ),
		);
	}


	/**

	 * Get the parameters schema.
	 *
	 * @return array
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'action'     => array(
					'type'        => 'string',
					'description' => 'Action: export or import',
					'enum'        => array( 'export', 'import' ),
				),
				'format'     => array(
					'type'        => 'string',
					'description' => 'File format: xliff, po, json',
					'enum'        => array( 'xliff', 'po', 'json' ),
				),
				'language'   => array(
					'type'        => 'string',
					'description' => 'Language code',
				),
				'post_types' => array(
					'type'        => 'array',
					'description' => 'Post types to include',
				),
			),
			'required'   => array(),
		);
	}


	/**

	 * Get the required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array(
			'content'     => true,
			'translation' => true,
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// TODO: Implement export_import_translations logic.

		return array(
			'success' => true,
			'message' => __( 'Export/Import Translations executed successfully.', 'mcp-ai-wpoos-pro' ),
		);
	}
}
