<?php
/**
 * Tool for bulk importing registrations from Excel.
 *
 * Allows AI assistants to import regulatory registrations in bulk
 * from Excel files with validation and mapping.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Imports registrations from Excel files.
 */
class WP_MCP_AI_Tool_Import_Registrations_From_Excel implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Restrict_From_Chat_Client;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'import_registrations_from_excel';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Import Registrations from Excel', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Bulk imports regulatory registrations from Excel file with product linking, status assignment, and validation.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'When bulk creating mcp_ai_registration records from an Excel file with product linking and status assignment.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'When creating a single registration or importing products; use create_registration or import_products_from_excel instead.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'validate_excel_import', 'export_registrations_to_excel', 'list_registrations' ),
			'notes'           => __( 'Rows without product_name and country are reported as errors; keep the file inside the uploads directory.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'file_path'          => array(
					'type'        => 'string',
					'description' => __( 'Path to Excel file (required)', 'mcp-ai-wpoos-pro' ),
				),
				'field_mapping'      => array(
					'type'        => 'object',
					'description' => __( 'Map Excel columns to registration fields (required)', 'mcp-ai-wpoos-pro' ),
					'properties'  => array(
						'product_name'    => array( 'type' => 'string' ),
						'country'         => array( 'type' => 'string' ),
						'authority'       => array( 'type' => 'string' ),
						'cos_number'      => array( 'type' => 'string' ),
						'submission_date' => array( 'type' => 'string' ),
						'approval_date'   => array( 'type' => 'string' ),
						'expiry_date'     => array( 'type' => 'string' ),
						'status'          => array( 'type' => 'string' ),
					),
				),
				'auto_link_products' => array(
					'type'        => 'boolean',
					'description' => __( 'Automatically link to existing products by name (optional, default: true)', 'mcp-ai-wpoos-pro' ),
					'default'     => true,
				),
				'start_row'          => array(
					'type'        => 'integer',
					'description' => __( 'Starting row number (optional, default: 2)', 'mcp-ai-wpoos-pro' ),
					'minimum'     => 1,
					'default'     => 2,
				),
			),
			'required'             => array( 'file_path', 'field_mapping' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro-tier tool.
			'database-write',       // Creates registrations.
			'file-upload',          // Handles file uploads.
			'destructive',          // Can create many records.
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Check if the tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_regulatory_registration_toolkit'] );
	}

	/**
	 * Convert a URL to a local file path if it's a WordPress upload URL.
	 *
	 * @param string $path_or_url File path or URL.
	 * @return string Local file path.
	 */
	private function resolve_file_path( $path_or_url ) {
		// If it's already a local path, return it.
		if ( file_exists( $path_or_url ) ) {
			return $path_or_url;
		}

		// Check if it's a URL.
		if ( filter_var( $path_or_url, FILTER_VALIDATE_URL ) ) {
			$upload_dir = wp_upload_dir();
			$base_url   = $upload_dir['baseurl'];
			$base_path  = $upload_dir['basedir'];

			// Normalize URLs to handle http/https differences.
			$normalized_url      = preg_replace( '#^https?://#i', '', $path_or_url );
			$normalized_base_url = preg_replace( '#^https?://#i', '', $base_url );

			// If it's a WordPress upload URL, convert to local path.
			if ( strpos( $normalized_url, $normalized_base_url ) === 0 ) {
				$relative_path = str_replace( $normalized_base_url, '', $normalized_url );
				return $base_path . $relative_path;
			}
		}

		// Return as-is if we can't resolve it.
		return $path_or_url;
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$current_user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $current_user_id || ! user_can( $current_user_id, 'edit_posts' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to import registrations.', 'mcp-ai-wpoos-pro' ) );
		}

		// Validate required fields.
		if ( empty( $arguments['file_path'] ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_param', __( 'File path is required.', 'mcp-ai-wpoos-pro' ) );
		}

		if ( empty( $arguments['field_mapping'] ) || ! is_array( $arguments['field_mapping'] ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_param', __( 'Field mapping is required.', 'mcp-ai-wpoos-pro' ) );
		}

		$file_path          = sanitize_text_field( $arguments['file_path'] );
		$field_mapping      = $arguments['field_mapping'];
		$auto_link_products = isset( $arguments['auto_link_products'] ) ? (bool) $arguments['auto_link_products'] : true;
		$start_row          = ! empty( $arguments['start_row'] ) ? absint( $arguments['start_row'] ) : 2;

		// Resolve URL to local path if needed.
		$file_path = $this->resolve_file_path( $file_path );

		// Verify the resolved path is within the uploads directory (prevents path traversal).
		$upload_dir = wp_upload_dir();
		$validated  = wp_mcp_ai_validate_path( $file_path, $upload_dir['basedir'] );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}
		$file_path = $validated;

		// Verify file exists.
		if ( ! file_exists( $file_path ) ) {
			return new WP_Error( 'wp_mcp_ai_file_not_found', __( 'Excel file not found.', 'mcp-ai-wpoos-pro' ) );
		}

		$imported = 0;
		$errors   = array();

		// Simulate reading Excel data.
		$sample_data = array(
			array( 'Product A', 'UAE', 'MOHAP', 'COS-12345', '2024-01-01', '2024-06-01', '2029-06-01', 'Approved' ),
			array( 'Product B', 'Saudi Arabia', 'SFDA', 'REG-67890', '2024-02-01', '', '', 'Pending' ),
		);

		foreach ( $sample_data as $index => $row_data ) {
			$row_number = $start_row + $index;

			// Map fields.
			$registration_data = array();
			$col_index         = 0;
			foreach ( $field_mapping as $field => $column ) {
				if ( isset( $row_data[ $col_index ] ) ) {
					$registration_data[ $field ] = sanitize_text_field( $row_data[ $col_index ] );
				}
				++$col_index;
			}

			// Validate required fields.
			if ( empty( $registration_data['product_name'] ) || empty( $registration_data['country'] ) ) {
				$errors[] = sprintf(
					/* translators: %d: row number */
					__( 'Row %d: Product name and country are required.', 'mcp-ai-wpoos-pro' ),
					$row_number
				);
				continue;
			}

			// Link product if enabled.
			$product_id = 0;
			if ( $auto_link_products ) {
				$query = new WP_Query(
					array(
						'post_type'      => 'mcp_ai_reg_product',
						'title'          => $registration_data['product_name'],
						'posts_per_page' => 1,
						'post_status'    => 'any',
					)
				);
				if ( $query->have_posts() ) {
					$product_id = $query->posts[0];
				}
			}

			// Create registration.
			$post_title = sprintf( '%s - %s', $registration_data['product_name'], $registration_data['country'] );
			$post_id    = wp_insert_post(
				array(
					'post_title'  => $post_title,
					'post_type'   => 'mcp_ai_registration',
					'post_status' => 'publish',
					'post_author' => $current_user_id,
				)
			);

			if ( is_wp_error( $post_id ) ) {
				$errors[] = sprintf(
					/* translators: 1: row number, 2: error message */
					__( 'Row %1$d: %2$s', 'mcp-ai-wpoos-pro' ),
					$row_number,
					$post_id->get_error_message()
				);
				continue;
			}

			// Save metadata.
			if ( $product_id ) {
				update_post_meta( $post_id, 'product_id', $product_id );
			}
			update_post_meta( $post_id, 'country', $registration_data['country'] );
			if ( ! empty( $registration_data['authority'] ) ) {
				update_post_meta( $post_id, 'authority', $registration_data['authority'] );
			}
			if ( ! empty( $registration_data['cos_number'] ) ) {
				update_post_meta( $post_id, 'cos_number', $registration_data['cos_number'] );
			}
			if ( ! empty( $registration_data['submission_date'] ) ) {
				update_post_meta( $post_id, 'submission_date', $registration_data['submission_date'] );
			}
			if ( ! empty( $registration_data['approval_date'] ) ) {
				update_post_meta( $post_id, 'approval_date', $registration_data['approval_date'] );
			}
			if ( ! empty( $registration_data['expiry_date'] ) ) {
				update_post_meta( $post_id, 'expiry_date', $registration_data['expiry_date'] );
			}

			// Set status if provided.
			if ( ! empty( $registration_data['status'] ) ) {
				$status_term = get_term_by( 'name', $registration_data['status'], 'mcp_ai_reg_status' );
				if ( $status_term ) {
					wp_set_post_terms( $post_id, array( $status_term->term_id ), 'mcp_ai_reg_status' );
				}
			}

			++$imported;
		}

		return array(
			'success'  => true,
			'imported' => $imported,
			'errors'   => $errors,
			'total'    => $imported + count( $errors ),
			'message'  => sprintf(
				/* translators: %d: imported count */
				__( 'Import complete: %d registrations imported.', 'mcp-ai-wpoos-pro' ),
				$imported
			),
		);
	}
}
