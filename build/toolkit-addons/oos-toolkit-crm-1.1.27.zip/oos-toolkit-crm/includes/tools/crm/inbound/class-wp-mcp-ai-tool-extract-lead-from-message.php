<?php
/** Extract Lead from Message — creates or matches a lead from an inbound message. @package WP_MCP_AI_Pro @since 2.3.0 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
class WP_MCP_AI_Tool_Extract_Lead_From_Message implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface {
	public static function is_available() {
		$s = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $s['enable_crm_toolkit'] ); }
	public static function get_unavailable_reason() {
		return __( 'CRM Toolkit required.', 'mcp-ai-wpoos-pro' ); }
	public function get_slug() {
		return 'extract_lead_from_message'; }
	public function get_name() {
		return __( 'Extract Lead from Message', 'mcp-ai-wpoos-pro' ); }
	public function get_description() {
		return __( 'Extract or match a lead/contact from an inbound message. Creates a new lead if no match found.', 'mcp-ai-wpoos-pro' ); }
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'message_body' => array( 'type' => 'string' ),
				'sender_email' => array( 'type' => 'string' ),
				'sender_phone' => array( 'type' => 'string' ),
				'sender_name'  => array( 'type' => 'string' ),
				'channel'      => array(
					'type'    => 'string',
					'default' => 'email',
				),
			),
			'required'   => array( 'message_body' ),
		); }
	public function get_required_capability() {
		return 'edit_posts'; }
	public function requires_base_pro() {
		return true; }
	public function get_capability_flags() {
		return array( 'pro', 'database-write', 'requires-capability' ); }
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! self::is_available() ) {
			return new WP_Error( 'unavailable', self::get_unavailable_reason() ); }
		$uid = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();
		if ( ! $uid || ! user_can( $uid, 'edit_posts' ) ) {
			return new WP_Error( 'forbidden', __( 'Permission denied.', 'mcp-ai-wpoos-pro' ) ); }
		$email   = sanitize_email( $arguments['sender_email'] ?? '' );
		$phone   = sanitize_text_field( $arguments['sender_phone'] ?? '' );
		$name    = sanitize_text_field( $arguments['sender_name'] ?? '' );
		$channel = sanitize_key( $arguments['channel'] ?? 'email' );
		if ( ! $email && ! $phone ) {
			return new WP_Error( 'missing_identifier', __( 'At least sender_email or sender_phone is required to match or create a lead.', 'mcp-ai-wpoos-pro' ) ); }

		$contact_id = 0;
		$is_new     = true;
		if ( $email ) {
			$q = new WP_Query(
				array(
					'post_type'      => array( 'mcp_ai_lead', 'mcp_crm_contacts' ),
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'meta_query'     => array(
						array(
							'key'   => 'email',
							'value' => $email,
						),
					),
					'no_found_rows'  => true,
				)
			);
			if ( $q->have_posts() ) {
				$contact_id = $q->posts[0];
				$is_new     = false; }
		}
		if ( ! $contact_id && $phone ) {
			$q = new WP_Query(
				array(
					'post_type'      => array( 'mcp_ai_lead', 'mcp_crm_contacts' ),
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'meta_query'     => array(
						array(
							'key'   => 'phone',
							'value' => $phone,
						),
					),
					'no_found_rows'  => true,
				)
			);
			if ( $q->have_posts() ) {
				$contact_id = $q->posts[0];
				$is_new     = false; }
		}

		if ( ! $contact_id ) {
			$contact_id = wp_insert_post(
				array(
					'post_type'   => 'mcp_ai_lead',
					'post_title'  => $name ?: __( 'Inbound Lead', 'mcp-ai-wpoos-pro' ),
					'post_status' => 'publish',
				),
				true
			);
			if ( is_wp_error( $contact_id ) ) {
				return $contact_id; }
			if ( $name ) {
				$parts = explode( ' ', $name, 2 );
				update_post_meta( $contact_id, 'first_name', sanitize_text_field( $parts[0] ) );
				if ( isset( $parts[1] ) ) {
					update_post_meta( $contact_id, 'last_name', sanitize_text_field( $parts[1] ) ); }
			}
			update_post_meta( $contact_id, 'email', $email );
			update_post_meta( $contact_id, 'phone', $phone );
			update_post_meta( $contact_id, 'source', $channel );
			update_post_meta( $contact_id, 'lead_status', 'new' );
			update_post_meta( $contact_id, 'lifecycle_stage', 'lead' );
			if ( class_exists( 'WP_MCP_AI_CRM_Engine' ) ) {
				$o = WP_MCP_AI_CRM_Engine::get_next_owner();
				if ( $o ) {
					update_post_meta( $contact_id, 'contact_owner', $o ); }
			}
		}

		if ( class_exists( 'WP_MCP_AI_CRM_Audit' ) ) {
			WP_MCP_AI_CRM_Audit::record(
				'lead_extracted',
				'lead',
				$contact_id,
				array(
					'is_new'  => $is_new,
					'channel' => $channel,
				)
			); }
		return array(
			'success'    => true,
			'contact_id' => $contact_id,
			'is_new'     => $is_new,
			'message'    => $is_new ? __( 'New lead created from inbound message.', 'mcp-ai-wpoos-pro' ) : __( 'Existing contact matched.', 'mcp-ai-wpoos-pro' ),
		);
	}
}
