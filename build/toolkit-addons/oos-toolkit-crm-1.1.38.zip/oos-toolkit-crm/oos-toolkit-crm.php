<?php
/**
 * Plugin Name: oOS Toolkit - CRM & Email Marketing Toolkit
 * Plugin URI: https://nvdigitalsolutions.com/wpoos/toolkits/crm
 * Description: Contact management, email campaigns, lead tracking, CSV import/export, and customer relationship management. Requires NV Digital Open Operator System (oOS) base plugin.
 * Version: 1.1.38
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Tested up to: 6.9
 * Author: NV Digital Solutions
 * Author URI: https://nvdigitalsolutions.com
 * License: Proprietary
 * Text Domain: oos-toolkit-crm
 * Domain Path: /languages
 * Network: true
 *
 * @package WP_MCP_AI_Toolkit_CRM
 *
 * Copyright (c) 2025-2026 NV Digital Solutions (https://nvdigitalsolutions.com)
 * All rights reserved. This is proprietary software.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Detect "vendor-only supplement" toolkits (no tools, no init file).
// These exist solely to ship a Composer vendor library that the combined oOS
// Pro distribution intentionally omits to keep its footprint small (e.g.,
// tcpdf is ~28.7 MB). When Pro is active, a normal toolkit add-on would
// duplicate functionality and should deactivate, but a vendor-only supplement
// must STAY active so its autoloader can register the missing classes for
// Pro's tools to consume.
$wp_mcp_ai_is_vendor_supplement_crm = ( 'crm' === '_none_' && 'crm-toolkit-init.php' === '_none_' );

// Prevent loading if the full Pro add-on is already active — unless this is a
// vendor-only supplement add-on whose purpose is to provide a library that
// Pro is missing.
if ( defined( 'WP_MCP_AI_PRO_VERSION' ) && ! $wp_mcp_ai_is_vendor_supplement_crm ) {
	add_action(
		'admin_notices',
		function () {
			echo '<div class="notice notice-warning is-dismissible"><p>';
			echo esc_html(
				sprintf(
					/* translators: %s: toolkit display name */
					__( 'oOS Toolkit - %s: The full oOS Pro add-on is already active. This individual toolkit add-on is not needed and has been deactivated to avoid conflicts.', 'oos-toolkit-crm' ),
					'CRM & Email Marketing Toolkit'
				)
			);
			echo '</p></div>';
		}
	);

	// Deactivate this plugin since Pro is already handling everything.
	add_action(
		'admin_init',
		function () {
			deactivate_plugins( plugin_basename( __FILE__ ) );
		}
	);
	return;
}

// Check for base oOS plugin dependency.
if ( ! function_exists( 'wp_mcp_ai_core_loaded' ) ) {
	add_action(
		'admin_notices',
		function () {
			echo '<div class="notice notice-error is-dismissible"><p>';
			echo esc_html(
				sprintf(
					/* translators: %s: toolkit display name */
					__( 'oOS Toolkit - %s requires the NV Digital Open Operator System (oOS) base plugin to be installed and activated.', 'oos-toolkit-crm' ),
					'CRM & Email Marketing Toolkit'
				)
			);
			echo '</p></div>';
		}
	);
	return;
}

// Define toolkit add-on constants.
define( 'WP_MCP_AI_TOOLKIT_CRM_VERSION', '1.1.38' );
define( 'WP_MCP_AI_TOOLKIT_CRM_FILE', __FILE__ );
define( 'WP_MCP_AI_TOOLKIT_CRM_PATH', plugin_dir_path( __FILE__ ) );
define( 'WP_MCP_AI_TOOLKIT_CRM_URL', plugin_dir_url( __FILE__ ) );

/**
 * Auto-enable the toolkit setting on plugin activation.
 */
function wp_mcp_ai_toolkit_crm_activate() {
	$settings = get_option( 'wp_mcp_ai_settings', array() );
	if ( empty( $settings['enable_crm_toolkit'] ) ) {
		$settings['enable_crm_toolkit'] = '1';
		update_option( 'wp_mcp_ai_settings', $settings );
	}
}
register_activation_hook( __FILE__, 'wp_mcp_ai_toolkit_crm_activate' );

/**
 * Initialize the toolkit add-on.
 *
 * Hooks into the oOS core to set up path constants that the toolkit init file
 * expects, then loads the original toolkit initialization file.
 */
function wp_mcp_ai_toolkit_crm_init() {
	// Ensure the toolkit setting is enabled.
	$settings = get_option( 'wp_mcp_ai_settings', array() );
	if ( empty( $settings['enable_crm_toolkit'] ) ) {
		return;
	}

	// Set the Pro path constant to point to this add-on's directory so that
	// the original toolkit init file can locate its includes.
	if ( ! defined( 'WP_MCP_AI_PRO_PATH' ) ) {
		define( 'WP_MCP_AI_PRO_PATH', WP_MCP_AI_TOOLKIT_CRM_PATH );
	}
	if ( ! defined( 'WP_MCP_AI_PRO_URL' ) ) {
		define( 'WP_MCP_AI_PRO_URL', WP_MCP_AI_TOOLKIT_CRM_URL );
	}
	if ( ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
		define( 'WP_MCP_AI_PRO_VERSION', WP_MCP_AI_TOOLKIT_CRM_VERSION );
	}

	// Load the toolkit init file.
	$init_file = WP_MCP_AI_TOOLKIT_CRM_PATH . 'includes/crm-toolkit-init.php';
	if ( file_exists( $init_file ) ) {
		require_once $init_file;
	}
}
add_action( 'plugins_loaded', 'wp_mcp_ai_toolkit_crm_init', 20 );

/**
 * Register toolkit-specific tools with the oOS tool registry.
 *
 * @param WP_MCP_AI_Tool_Registry $registry The tool registry instance.
 */
function wp_mcp_ai_toolkit_crm_register_tools( $registry ) {
	// Ensure the toolkit setting is enabled.
	$settings = get_option( 'wp_mcp_ai_settings', array() );
	if ( empty( $settings['enable_crm_toolkit'] ) ) {
		return;
	}

	$toolkit_path = WP_MCP_AI_TOOLKIT_CRM_PATH;
	$tools_dir    = $toolkit_path . 'includes/tools/crm/';

	// Auto-discover and register all tool classes in the tools directory.
	if ( 'crm' !== '_none_' && is_dir( $tools_dir ) ) {
		$tool_files = glob( $tools_dir . 'class-wp-mcp-ai-tool-*.php' );
		if ( $tool_files ) {
			foreach ( $tool_files as $tool_file ) {
				require_once $tool_file;

				// Derive class name from file name.
				$basename   = basename( $tool_file, '.php' );
				$class_name = str_replace( '-', '_', $basename );
				$class_name = implode( '_', array_map( 'ucfirst', explode( '_', $class_name ) ) );
				// Fix the 'Class_' prefix: class-wp-mcp-ai-tool-x -> Class_Wp_Mcp_Ai_Tool_X.
				// We need WP_MCP_AI_Tool_X format.
				$class_name = preg_replace( '/^Class_/', '', $class_name );
				// Normalize common abbreviations.
				$class_name = str_replace(
					array( 'Wp_Mcp_Ai_', '_Pdf', '_Csv', '_Api', '_Ocr', '_Rtl', '_Seo', '_Hs_', '_Inci_', '_Ira_', '_Ml', '_Roi', '_Html_' ),
					array( 'WP_MCP_AI_', '_PDF', '_CSV', '_API', '_OCR', '_RTL', '_SEO', '_HS_', '_INCI_', '_IRA_', '_ML', '_ROI', '_HTML_' ),
					$class_name
				);

				if ( class_exists( $class_name ) ) {
					$should_register = true;
					if ( method_exists( $class_name, 'is_available' ) ) {
						$should_register = (bool) call_user_func( array( $class_name, 'is_available' ) );
					}
					if ( $should_register ) {
						$registry->register_tool( new $class_name() );
					}
				}
			}
		}
	}

	// Also check for tools in the root tools directory that belong to this toolkit.
	$root_tools_dir = $toolkit_path . 'includes/tools/';
	if ( is_dir( $root_tools_dir ) ) {
		$root_tool_files = glob( $root_tools_dir . 'class-wp-mcp-ai-tool-*.php' );
		if ( $root_tool_files ) {
			foreach ( $root_tool_files as $tool_file ) {
				require_once $tool_file;

				$basename   = basename( $tool_file, '.php' );
				$class_name = str_replace( '-', '_', $basename );
				$class_name = implode( '_', array_map( 'ucfirst', explode( '_', $class_name ) ) );
				$class_name = preg_replace( '/^Class_/', '', $class_name );
				$class_name = str_replace(
					array( 'Wp_Mcp_Ai_', '_Pdf', '_Csv', '_Api', '_Ocr' ),
					array( 'WP_MCP_AI_', '_PDF', '_CSV', '_API', '_OCR' ),
					$class_name
				);

				if ( class_exists( $class_name ) ) {
					$should_register = true;
					if ( method_exists( $class_name, 'is_available' ) ) {
						$should_register = (bool) call_user_func( array( $class_name, 'is_available' ) );
					}
					if ( $should_register ) {
						$registry->register_tool( new $class_name() );
					}
				}
			}
		}
	}
}
add_action( 'wp_mcp_ai_register_tools', 'wp_mcp_ai_toolkit_crm_register_tools', 25 );
