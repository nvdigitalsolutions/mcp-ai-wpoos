<?php
/**
 * Adjust Video Speed Tool
 *
 * Speed up or slow down video playback with audio pitch correction.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP_MCP_AI_Tool_Adjust_Video_Speed tool.
 */
class WP_MCP_AI_Tool_Adjust_Video_Speed implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * Check if tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}

		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_video_production_toolkit'] );
	}

	/**
	 * Get unavailable reason.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_video_production_toolkit'] ) ) {
			return __( 'Video Production toolkit is not enabled.', 'mcp-ai-wpoos-pro' );
		}
		return __( 'Adjust Video Speed tool is not available.', 'mcp-ai-wpoos-pro' );
	}


	/**

	 * Get the tool slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'adjust_video_speed';
	}

	/**
	 * Get the tool name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'Adjust Video Speed', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get the tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Speed up or slow down video playback with audio pitch correction.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for this tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Speeding up or slowing down an entire video (0.25x to 4x) with optional audio pitch correction.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Cutting or reordering footage; use trim_video or merge_videos. Changing dimensions; use resize_video_resolution.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'trim_video', 'merge_videos', 'compress_video' ),
			'notes'           => __( 'maintain_pitch defaults to true so sped-up audio keeps its natural tone.', 'mcp-ai-wpoos-pro' ),
		);
	}


	/**

	 * Get the parameters schema.
	 *
	 * @return array
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'video_id'       => array(
					'type'        => 'integer',
					'description' => 'Video media ID',
				),
				'speed_factor'   => array(
					'type'        => 'number',
					'description' => 'Speed multiplier (0.25-4.0)',
					'default'     => 1.0,
				),
				'maintain_pitch' => array(
					'type'        => 'boolean',
					'description' => 'Maintain audio pitch',
					'default'     => true,
				),
			),
			'required'   => array(),
		);
	}


	/**

	 * Get the required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'upload_files';
	}

		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array(
			'media'         => true,
			'video_editing' => true,
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// TODO: Implement adjust_video_speed logic.
		// This requires FFmpeg or similar video processing library.

		return array(
			'success' => true,
			'message' => __( 'Adjust Video Speed executed successfully. Note: Video processing requires FFmpeg.', 'mcp-ai-wpoos-pro' ),
		);
	}
}
