<?php
/**
 * Translation Memory Search Tool
 *
 * Search and reuse previous translations from translation memory database to ensure consistency.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP_MCP_AI_Tool_Translation_Memory_Search tool.
 */
class WP_MCP_AI_Tool_Translation_Memory_Search implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * Check if tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}

		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_multilingual_toolkit'] );
	}

	/**
	 * Get unavailable reason.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_multilingual_toolkit'] ) ) {
			return __( 'Multi-language Content toolkit is not enabled.', 'mcp-ai-wpoos-pro' );
		}
		return __( 'Translation Memory Search tool is not available.', 'mcp-ai-wpoos-pro' );
	}


	/**

	 * Get the tool slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'translation_memory_search';
	}

	/**
	 * Get the tool name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'Translation Memory Search', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get the tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Search and reuse previous translations from translation memory database to ensure consistency.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Looking up previous translations of a phrase to keep wording consistent across the site.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Translating new content; use auto_translate_content or translate_woocommerce_products instead.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'auto_translate_content', 'translate_woocommerce_products' ),
			'notes'           => __( 'Lower min_similarity to widen the match pool; it defaults to 0.8.', 'mcp-ai-wpoos-pro' ),
		);
	}


	/**

	 * Get the parameters schema.
	 *
	 * @return array
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'search_text'     => array(
					'type'        => 'string',
					'description' => 'Text to search in translation memory',
				),
				'source_language' => array(
					'type'        => 'string',
					'description' => 'Source language',
				),
				'target_language' => array(
					'type'        => 'string',
					'description' => 'Target language',
				),
				'min_similarity'  => array(
					'type'        => 'number',
					'description' => 'Minimum similarity score (0-1)',
					'default'     => 0.8,
				),
			),
			'required'   => array(),
		);
	}


	/**

	 * Get the required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array(
			'content'     => true,
			'translation' => true,
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// TODO: Implement translation_memory_search logic.

		return array(
			'success' => true,
			'message' => __( 'Translation Memory Search executed successfully.', 'mcp-ai-wpoos-pro' ),
		);
	}
}
