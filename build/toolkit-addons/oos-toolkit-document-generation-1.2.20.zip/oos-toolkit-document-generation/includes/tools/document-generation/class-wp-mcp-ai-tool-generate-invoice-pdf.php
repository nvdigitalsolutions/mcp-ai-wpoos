<?php
/**
 * Generate Invoice PDF Tool - Create professional invoice PDFs.
 *
 * Template-based invoice generation with itemized billing,
 * calculations, and professional formatting.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.2.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load the document response trait from base plugin.
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-document-response.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php';

/**
 * Generate professional invoice PDFs.
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Tool_Generate_Invoice_PDF implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Tool_Document_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_invoice_pdf';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate Invoice PDF', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Generate professional invoice PDFs with itemized billing, calculations, and branding. Perfect for freelancers, agencies, and businesses. Supports multiple currencies, tax rates, and payment terms.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Creating a single branded, itemized invoice PDF for one client or order.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Invoicing many orders at once; use generate_invoice_batch. Generic PDFs: use generate_pdf.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'generate_invoice_batch', 'generate_pdf', 'html_to_pdf' ),
			'notes'           => __( 'Produces a real financial document; double-check totals and tax before sending it to the customer.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'invoice_number' => array(
					'type'        => 'string',
					'description' => __( 'Invoice number or ID.', 'mcp-ai-wpoos-pro' ),
				),
				'date'           => array(
					'type'        => 'string',
					'description' => __( 'Invoice date (YYYY-MM-DD format).', 'mcp-ai-wpoos-pro' ),
				),
				'due_date'       => array(
					'type'        => 'string',
					'description' => __( 'Payment due date (YYYY-MM-DD format).', 'mcp-ai-wpoos-pro' ),
				),
				'bill_to'        => array(
					'type'        => 'object',
					'description' => __( 'Billing recipient information (name, address, etc.).', 'mcp-ai-wpoos-pro' ),
				),
				'items'          => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'object' ),
					'description' => __( 'Array of invoice items with description, quantity, rate, amount.', 'mcp-ai-wpoos-pro' ),
				),
				'subtotal'       => array(
					'type'        => 'number',
					'description' => __( 'Subtotal amount before tax.', 'mcp-ai-wpoos-pro' ),
				),
				'tax_rate'       => array(
					'type'        => 'number',
					'description' => __( 'Tax rate as percentage (e.g., 10 for 10%).', 'mcp-ai-wpoos-pro' ),
				),
				'total'          => array(
					'type'        => 'number',
					'description' => __( 'Total amount including tax.', 'mcp-ai-wpoos-pro' ),
				),
				'currency'       => array(
					'type'        => 'string',
					'description' => __( 'Currency code (e.g., USD, EUR, GBP). Default: USD', 'mcp-ai-wpoos-pro' ),
				),
			),
			'required'   => array( 'invoice_number', 'items' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-capability', // upload_files.
			'requires-model',
			'consumes-tokens',
			'write',
			'state-changing',
		);
	}

	/**
	 * Get required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Check user capability.
		if ( ! current_user_can( 'upload_files' ) ) {
			return array(
				'error' => __( 'You do not have permission to generate invoices.', 'mcp-ai-wpoos-pro' ),
			);
		}

		// Validate required parameters.
		if ( empty( $arguments['invoice_number'] ) || empty( $arguments['items'] ) ) {
			return array(
				'error' => __( 'invoice_number and items are required.', 'mcp-ai-wpoos-pro' ),
			);
		}

		try {
			// Generate invoice PDF.
			$result = $this->generate_invoice( $arguments );

			if ( is_wp_error( $result ) ) {
				return array(
					'error' => $result->get_error_message(),
				);
			}

			// Add document HTML to response for chat display.
			return $this->add_document_html_to_response( $result );

		} catch ( Exception $e ) {
			return array(
				'error' => sprintf(
					/* translators: %s: error message */
					__( 'Failed to generate invoice: %s', 'mcp-ai-wpoos-pro' ),
					$e->getMessage()
				),
			);
		}
	}

	/**
	 * Generate invoice PDF.
	 *
	 * @param array $data Invoice data.
	 * @return array|WP_Error Result array or error.
	 */
	protected function generate_invoice( $data ) {
		// Extract invoice data with defaults.
		$invoice_number = sanitize_text_field( $data['invoice_number'] );
		$date           = ! empty( $data['date'] ) ? sanitize_text_field( $data['date'] ) : gmdate( 'Y-m-d' );
		$due_date       = ! empty( $data['due_date'] ) ? sanitize_text_field( $data['due_date'] ) : gmdate( 'Y-m-d', strtotime( '+30 days' ) );
		$currency       = ! empty( $data['currency'] ) ? sanitize_text_field( $data['currency'] ) : 'USD';
		$items          = $data['items'];

		// Calculate totals if not provided.
		$subtotal = 0;
		foreach ( $items as $item ) {
			if ( isset( $item['amount'] ) ) {
				$subtotal += floatval( $item['amount'] );
			}
		}

		$tax_rate = ! empty( $data['tax_rate'] ) ? floatval( $data['tax_rate'] ) : 0;
		$tax      = $subtotal * ( $tax_rate / 100 );
		$total    = $subtotal + $tax;

		// Build invoice HTML content.
		$html = $this->build_invoice_html(
			array(
				'invoice_number' => $invoice_number,
				'date'           => $date,
				'due_date'       => $due_date,
				'bill_to'        => $data['bill_to'] ?? array(),
				'items'          => $items,
				'subtotal'       => $subtotal,
				'tax_rate'       => $tax_rate,
				'tax'            => $tax,
				'total'          => $total,
				'currency'       => $currency,
			)
		);

		// Try DomPDF first.
		if ( class_exists( '\Dompdf\Dompdf' ) ) {
			return $this->generate_with_dompdf( $html, $invoice_number, $total, $currency );
		}

		// Fallback: Delegate to pro_pdf_document tool.
		if ( class_exists( 'WP_MCP_AI_Tool_Pro_PDF' ) ) {
			return $this->generate_with_pro_pdf( $html, $invoice_number );
		}

		// No suitable PDF generation method available.
		return new WP_Error(
			'no_pdf_generator',
			__( 'Invoice PDF generation requires DomPDF library (Composer: composer require dompdf/dompdf) or Pro PDF tool.', 'mcp-ai-wpoos-pro' )
		);
	}

	/**
	 * Generate invoice using DomPDF.
	 *
	 * @param string $html           Invoice HTML.
	 * @param string $invoice_number Invoice number.
	 * @param float  $total          Total amount.
	 * @param string $currency       Currency code.
	 * @return array|WP_Error Result array or error.
	 */
	protected function generate_with_dompdf( $html, $invoice_number, $total, $currency ) {
		try {
			$dompdf = new \Dompdf\Dompdf();
			$dompdf->loadHtml( $html );
			$dompdf->setPaper( 'a4', 'portrait' );
			$dompdf->render();

			// Get PDF content.
			$pdf_content = $dompdf->output();

			// Create temp file.
			$temp_file = wp_mcp_ai_tempnam( 'invoice_', '.pdf' );
			if ( is_wp_error( $temp_file ) ) {
				return $temp_file;
			}
			file_put_contents( $temp_file, $pdf_content ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

			// Upload to WordPress media library.
			$file_array = array(
				'name'     => 'invoice-' . $invoice_number . '.pdf',
				'tmp_name' => $temp_file,
			);

			$attachment_id = media_handle_sideload( $file_array, 0 );

			@unlink( $temp_file );

			if ( is_wp_error( $attachment_id ) ) {
				return $attachment_id;
			}

			// Get attachment details.
			$attachment_url = wp_get_attachment_url( $attachment_id );
			$file_path      = get_attached_file( $attachment_id );
			$file_size      = filesize( $file_path );

			return array(
				'attachment_id' => $attachment_id,
				'url'           => $attachment_url,
				'filename'      => basename( $file_path ),
				'mime_type'     => 'application/pdf',
				'size'          => $file_size,
				'text'          => sprintf(
					/* translators: 1: invoice number, 2: total amount, 3: currency */
					__( 'Successfully generated invoice #%1$s for %3$s%2$s.', 'mcp-ai-wpoos-pro' ),
					$invoice_number,
					number_format( $total, 2 ),
					$currency
				),
			);

		} catch ( Exception $e ) {
			return new WP_Error(
				'dompdf_error',
				sprintf(
					/* translators: %s: error message */
					__( 'DomPDF invoice generation failed: %s', 'mcp-ai-wpoos-pro' ),
					$e->getMessage()
				)
			);
		}
	}

	/**
	 * Generate invoice using Pro PDF tool.
	 *
	 * @param string $html           Invoice HTML.
	 * @param string $invoice_number Invoice number.
	 * @return array|WP_Error Result array or error.
	 */
	protected function generate_with_pro_pdf( $html, $invoice_number ) {
		$pro_pdf_tool = new WP_MCP_AI_Tool_Pro_PDF();

		// Convert HTML to plain content for Pro PDF.
		$content = wp_strip_all_tags( $html );

		return $pro_pdf_tool->execute(
			array(
				'operation' => 'generate',
				'content'   => $content,
				'title'     => 'Invoice ' . $invoice_number,
			),
			array()
		);
	}

	/**
	 * Build invoice HTML.
	 *
	 * @param array $data Invoice data.
	 * @return string HTML content.
	 */
	protected function build_invoice_html( $data ) {
		$html  = '<html><body>';
		$html .= '<h1>INVOICE</h1>';
		$html .= '<p><strong>Invoice #:</strong> ' . esc_html( $data['invoice_number'] ) . '</p>';
		$html .= '<p><strong>Date:</strong> ' . esc_html( $data['date'] ) . '</p>';
		$html .= '<p><strong>Due Date:</strong> ' . esc_html( $data['due_date'] ) . '</p>';

		// Items table.
		$html .= '<table border="1" style="width:100%; border-collapse:collapse;"><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th></tr>';
		foreach ( $data['items'] as $item ) {
			$html .= '<tr>';
			$html .= '<td>' . esc_html( $item['description'] ?? '' ) . '</td>';
			$html .= '<td>' . esc_html( $item['quantity'] ?? 1 ) . '</td>';
			$html .= '<td>' . number_format( $item['rate'] ?? 0, 2 ) . '</td>';
			$html .= '<td>' . number_format( $item['amount'] ?? 0, 2 ) . '</td>';
			$html .= '</tr>';
		}
		$html .= '</table>';

		// Totals.
		$html .= '<p style="text-align:right;"><strong>Subtotal:</strong> ' . number_format( $data['subtotal'], 2 ) . '</p>';
		if ( $data['tax_rate'] > 0 ) {
			$html .= '<p style="text-align:right;"><strong>Tax (' . $data['tax_rate'] . '%):</strong> ' . number_format( $data['tax'], 2 ) . '</p>';
		}
		$html .= '<p style="text-align:right;"><strong>Total:</strong> ' . $data['currency'] . ' ' . number_format( $data['total'], 2 ) . '</p>';

		$html .= '</body></html>';
		return $html;
	}
}
