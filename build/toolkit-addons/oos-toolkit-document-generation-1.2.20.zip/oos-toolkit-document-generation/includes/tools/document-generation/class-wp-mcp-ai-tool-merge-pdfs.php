<?php
/**
 * Merge PDFs Tool - Combine multiple PDF documents.
 *
 * Merges multiple PDF files into a single document while maintaining
 * page order, bookmarks, and metadata.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.2.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load the document response trait from base plugin.
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-document-response.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php';
require_once WP_MCP_AI_PATH . 'includes/traits/trait-wp-mcp-ai-media-worker-client.php';

/**
 * Merge multiple PDFs into one.
 *
 * Combines multiple PDF documents without requiring AI processing.
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Tool_Merge_PDFs implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Tool_Document_Response;
	use WP_MCP_AI_Media_Worker_Client;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'merge_pdfs';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Merge PDFs', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Combine multiple PDF documents into a single file. Maintains page order, preserves formatting, and merges bookmarks. Useful for consolidating reports, documents, or file collections.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Combining two or more existing PDF files into one ordered document without changing their page content.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Authoring new content, editing pages, or converting formats; use pro_pdf_document for AI-generated PDFs, html_to_pdf for HTML sources, or add_watermark_to_pdf for stamps.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'pro_pdf_document', 'html_to_pdf', 'add_watermark_to_pdf' ),
			'notes'           => __( 'Pass files in the exact page order wanted. Requires shell tools, a Media Worker sidecar, pdftk, or TCPDF on the host.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'attachment_ids' => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'integer' ),
					'description' => __( 'Array of WordPress attachment IDs for PDF files to merge (in order).', 'mcp-ai-wpoos-pro' ),
				),
				'urls'           => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => __( 'Array of PDF URLs to merge (alternative to attachment_ids, in order).', 'mcp-ai-wpoos-pro' ),
				),
				'title'          => array(
					'type'        => 'string',
					'description' => __( 'Title for the merged PDF document.', 'mcp-ai-wpoos-pro' ),
				),
				'filename'       => array(
					'type'        => 'string',
					'description' => __( 'Output filename (without extension). Defaults to "merged-document".', 'mcp-ai-wpoos-pro' ),
				),
			),
			'required'   => array(),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-capability', // upload_files.
			'write',
			'state-changing',
			'local-only', // No AI required.
		);
	}

	/**
	 * Get required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Shell-tools constant and capability gate (F-EXEC-01 / R-S-02). The
		// Media Worker sidecar path never runs a shell command, so a reachable
		// sidecar satisfies the gate on hosts where shell tools are disabled.
		$shell_tools_allowed = defined( 'WP_MCP_AI_ALLOW_SHELL_TOOLS' ) && WP_MCP_AI_ALLOW_SHELL_TOOLS;
		if ( ! $shell_tools_allowed && ! $this->is_sidecar_upload_supported() ) {
			return array(
				'error' => __( 'Shell tools are disabled. Set define( \'WP_MCP_AI_ALLOW_SHELL_TOOLS\', true ) in wp-config.php to enable them, or connect a Media Worker sidecar.', 'mcp-ai-wpoos-pro' ),
			);
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'error' => __( 'You do not have permission to run shell commands.', 'mcp-ai-wpoos-pro' ),
			);
		}

		// Check user capability.
		if ( ! current_user_can( 'upload_files' ) ) {
			return array(
				'error' => __( 'You do not have permission to merge documents.', 'mcp-ai-wpoos-pro' ),
			);
		}

		// Validate required parameters.
		$has_attachment_ids = ! empty( $arguments['attachment_ids'] ) && is_array( $arguments['attachment_ids'] );
		$has_urls           = ! empty( $arguments['urls'] ) && is_array( $arguments['urls'] );

		if ( ! $has_attachment_ids && ! $has_urls ) {
			return array(
				'error' => __( 'Either attachment_ids or urls array is required.', 'mcp-ai-wpoos-pro' ),
			);
		}

		// Determine the count of files.
		$file_count = $has_attachment_ids ? count( $arguments['attachment_ids'] ) : count( $arguments['urls'] );

		if ( $file_count < 2 ) {
			return array(
				'error' => __( 'At least 2 PDF files are required to merge.', 'mcp-ai-wpoos-pro' ),
			);
		}

		$title    = ! empty( $arguments['title'] ) ? sanitize_text_field( $arguments['title'] ) : 'Merged Document';
		$filename = ! empty( $arguments['filename'] ) ? sanitize_file_name( $arguments['filename'] ) : 'merged-document';

		try {
			// Merge PDFs.
			$result = $this->merge_pdf_files( $arguments, $title, $filename );

			if ( is_wp_error( $result ) ) {
				return array(
					'error' => $result->get_error_message(),
				);
			}

			// Add document HTML to response for chat display.
			return $this->add_document_html_to_response( $result );

		} catch ( Exception $e ) {
			return array(
				'error' => sprintf(
					/* translators: %s: error message */
					__( 'Failed to merge PDFs: %s', 'mcp-ai-wpoos-pro' ),
					$e->getMessage()
				),
			);
		}
	}

	/**
	 * Merge PDF files.
	 *
	 * @param array  $arguments Array of arguments containing attachment_ids or urls.
	 * @param string $title     Document title.
	 * @param string $filename  Output filename.
	 * @return array|WP_Error Result array or error.
	 */
	protected function merge_pdf_files( $arguments, $title, $filename ) {
		$file_paths     = array();
		$temp_files     = array();
		$has_attachment = ! empty( $arguments['attachment_ids'] );

		// Process attachment IDs or URLs.
		if ( $has_attachment ) {
			foreach ( $arguments['attachment_ids'] as $attachment_id ) {
				$file_path = get_attached_file( $attachment_id );

				if ( ! $file_path || ! file_exists( $file_path ) ) {
					return new WP_Error(
						'file_not_found',
						sprintf(
							/* translators: %d: attachment ID */
							__( 'PDF file not found for attachment ID %d.', 'mcp-ai-wpoos-pro' ),
							$attachment_id
						)
					);
				}

				// Validate it's a PDF.
				$mime_type = mime_content_type( $file_path );
				if ( 'application/pdf' !== $mime_type ) {
					return new WP_Error(
						'invalid_file',
						sprintf(
							/* translators: %d: attachment ID */
							__( 'Attachment ID %d is not a valid PDF.', 'mcp-ai-wpoos-pro' ),
							$attachment_id
						)
					);
				}

				$file_paths[] = $file_path;
			}
		} else {
			// Process URLs.
			if ( ! function_exists( 'download_url' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}

			foreach ( $arguments['urls'] as $url ) {
				$temp_file = download_url( $url );

				if ( is_wp_error( $temp_file ) ) {
					// Clean up any previously downloaded files.
					foreach ( $temp_files as $temp ) {
						@unlink( $temp );
					}
					return new WP_Error(
						'download_failed',
						sprintf(
							/* translators: %s: error message */
							__( 'Failed to download PDF from URL: %s', 'mcp-ai-wpoos-pro' ),
							$temp_file->get_error_message()
						)
					);
				}

				// Validate it's a PDF.
				$mime_type = mime_content_type( $temp_file );
				if ( 'application/pdf' !== $mime_type ) {
					// Clean up temp files.
					@unlink( $temp_file );
					foreach ( $temp_files as $temp ) {
						@unlink( $temp );
					}
					return new WP_Error(
						'invalid_file',
						sprintf(
							/* translators: %s: URL */
							__( 'URL is not a valid PDF: %s', 'mcp-ai-wpoos-pro' ),
							$url
						)
					);
				}

				$temp_files[] = $temp_file;
				$file_paths[] = $temp_file;
			}
		}

		// Try the Media Worker sidecar first (opt-in routing — fails fast
		// when no sidecar URL is configured). The worker merges with pdf-lib
		// instead of requiring pdftk/TCPDF on this host.
		if ( $this->is_sidecar_upload_supported() ) {
			$sidecar = $this->sidecar_upload_multi( '/api/pdf/merge', $file_paths, array(), 120 );
			if ( ! is_wp_error( $sidecar ) && ! empty( $sidecar['data_base64'] ) ) {
				$merged_bytes = base64_decode( $sidecar['data_base64'], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decoding the worker's data_base64 payload is the transport contract.
				if ( false !== $merged_bytes && '' !== $merged_bytes ) {
					$temp_file = wp_mcp_ai_tempnam( 'merged_pdf_', '.pdf' );
					if ( ! is_wp_error( $temp_file ) && false !== file_put_contents( $temp_file, $merged_bytes ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Writing the worker-returned bytes into a temp file consumed by media_handle_sideload.
						$file_array = array(
							'name'     => $filename . '.pdf',
							'tmp_name' => $temp_file,
						);

						$attachment_id = media_handle_sideload( $file_array, 0 );
						@unlink( $temp_file );

						if ( ! is_wp_error( $attachment_id ) ) {
							// Clean up downloaded temp files.
							foreach ( $temp_files as $temp ) {
								@unlink( $temp );
							}

							$attachment_url = wp_get_attachment_url( $attachment_id );
							$merged_path    = get_attached_file( $attachment_id );
							$file_size      = filesize( $merged_path );

							return array(
								'attachment_id' => $attachment_id,
								'url'           => $attachment_url,
								'filename'      => basename( $merged_path ),
								'mime_type'     => 'application/pdf',
								'size'          => $file_size,
								'text'          => sprintf(
									/* translators: 1: number of files merged, 2: output size */
									__( 'Successfully merged %1$d PDF files into one document (%2$s).', 'mcp-ai-wpoos-pro' ),
									count( $file_paths ),
									size_format( $file_size )
								),
							);
						}
					}
				}
			}
		}

		// Try pdftk command-line tool.
		if ( wp_mcp_ai_find_binary( 'pdftk' ) ) {
			$result = $this->merge_with_pdftk( $file_paths, $filename );
			// Clean up temp files if we downloaded any.
			foreach ( $temp_files as $temp ) {
				@unlink( $temp );
			}
			return $result;
		}

		// Try TCPDF library.
		if ( class_exists( '\TCPDF' ) ) {
			$result = $this->merge_with_tcpdf( $file_paths, $filename );
			// Clean up temp files if we downloaded any.
			foreach ( $temp_files as $temp ) {
				@unlink( $temp );
			}
			return $result;
		}

		// Clean up temp files if we downloaded any.
		foreach ( $temp_files as $temp ) {
			@unlink( $temp );
		}

		// No suitable merging method available.
		return new WP_Error(
			'no_merger',
			__( 'PDF merging requires pdftk command-line tool (install: apt-get install pdftk or brew install pdftk) or TCPDF library (Composer: composer require tecnickcom/tcpdf). Alternatively, use the pdf-lib Node.js package.', 'mcp-ai-wpoos-pro' )
		);
	}

	/**
	 * Merge PDFs using pdftk.
	 *
	 * @param array  $file_paths Array of PDF file paths.
	 * @param string $filename   Output filename.
	 * @return array|WP_Error Result array or error.
	 */
	protected function merge_with_pdftk( $file_paths, $filename ) {
		$temp_file = wp_mcp_ai_tempnam( 'merged_pdf_', '.pdf' );
		if ( is_wp_error( $temp_file ) ) {
			return $temp_file;
		}

		$cmd = sprintf(
			'pdftk %s cat output %s 2>&1',
			implode( ' ', array_map( 'escapeshellarg', $file_paths ) ),
			escapeshellarg( $temp_file )
		);

		$proc_result = wp_mcp_ai_run_shell( $cmd, dirname( $temp_file ) );
		$return_code = $proc_result['exit_code'];

		if ( 0 !== $return_code ) {
			@unlink( $temp_file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return new WP_Error( 'merge_failed', __( 'Failed to merge PDFs using pdftk.', 'mcp-ai-wpoos-pro' ) );
		}

		// Upload to WordPress media library.
		$file_array = array(
			'name'     => $filename . '.pdf',
			'tmp_name' => $temp_file,
		);

		$attachment_id = media_handle_sideload( $file_array, 0 );

		@unlink( $temp_file );

		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		// Get attachment details.
		$attachment_url = wp_get_attachment_url( $attachment_id );
		$file_path      = get_attached_file( $attachment_id );
		$file_size      = filesize( $file_path );

		return array(
			'attachment_id' => $attachment_id,
			'url'           => $attachment_url,
			'filename'      => basename( $file_path ),
			'mime_type'     => 'application/pdf',
			'size'          => $file_size,
			'text'          => sprintf(
				/* translators: 1: number of files merged, 2: output size */
				__( 'Successfully merged %1$d PDF files into one document (%2$s).', 'mcp-ai-wpoos-pro' ),
				count( $file_paths ),
				size_format( $file_size )
			),
		);
	}

	/**
	 * Merge PDFs using TCPDF (basic concatenation).
	 *
	 * Note: TCPDF concatenation is basic and may not preserve all features.
	 *
	 * @param array  $file_paths Array of PDF file paths.
	 * @param string $filename   Output filename.
	 * @return array|WP_Error Result array or error.
	 */
	protected function merge_with_tcpdf( $file_paths, $filename ) {
		try {
			// TCPDF doesn't have built-in PDF merging, but we can import pages.
			// This is a basic implementation - use pdftk for production.
			$pdf = new \TCPDF();
			$pdf->setPrintHeader( false );
			$pdf->setPrintFooter( false );

			foreach ( $file_paths as $file_path ) {
				// Import pages from each PDF.
				$page_count = $pdf->setSourceFile( $file_path );
				for ( $i = 1; $i <= $page_count; $i++ ) {
					$pdf->AddPage();
					$tpl_id = $pdf->importPage( $i );
					$pdf->useTemplate( $tpl_id );
				}
			}

			// Save to temp file.
			$temp_file = wp_mcp_ai_tempnam( 'merged_pdf_', '.pdf' );
			if ( is_wp_error( $temp_file ) ) {
				return $temp_file;
			}
			$pdf->Output( $temp_file, 'F' );

			// Upload to WordPress media library.
			$file_array = array(
				'name'     => $filename . '.pdf',
				'tmp_name' => $temp_file,
			);

			$attachment_id = media_handle_sideload( $file_array, 0 );

			@unlink( $temp_file );

			if ( is_wp_error( $attachment_id ) ) {
				return $attachment_id;
			}

			// Get attachment details.
			$attachment_url = wp_get_attachment_url( $attachment_id );
			$file_path      = get_attached_file( $attachment_id );
			$file_size      = filesize( $file_path );

			return array(
				'attachment_id' => $attachment_id,
				'url'           => $attachment_url,
				'filename'      => basename( $file_path ),
				'mime_type'     => 'application/pdf',
				'size'          => $file_size,
				'text'          => sprintf(
					/* translators: 1: number of files merged, 2: output size */
					__( 'Successfully merged %1$d PDF files into one document (%2$s).', 'mcp-ai-wpoos-pro' ),
					count( $file_paths ),
					size_format( $file_size )
				),
			);

		} catch ( Exception $e ) {
			return new WP_Error(
				'tcpdf_error',
				sprintf(
					/* translators: %s: error message */
					__( 'TCPDF merge failed: %s', 'mcp-ai-wpoos-pro' ),
					$e->getMessage()
				)
			);
		}
	}
}
