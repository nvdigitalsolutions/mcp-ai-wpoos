<?php
/**
 * Find Untranslated Strings Tool
 *
 * Scan website for missing translations and untranslated strings across all languages.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP_MCP_AI_Tool_Find_Untranslated_Strings tool.
 */
class WP_MCP_AI_Tool_Find_Untranslated_Strings implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * Check if tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}

		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_multilingual_toolkit'] );
	}

	/**
	 * Get unavailable reason.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_multilingual_toolkit'] ) ) {
			return __( 'Multi-language Content toolkit is not enabled.', 'mcp-ai-wpoos-pro' );
		}
		return __( 'Find Untranslated Strings tool is not available.', 'mcp-ai-wpoos-pro' );
	}


	/**

	 * Get the tool slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'find_untranslated_strings';
	}

	/**
	 * Get the tool name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'Find Untranslated Strings', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get the tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Scan website for missing translations and untranslated strings across all languages.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Auditing which content still needs translation for a target language before a translation pass.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Checking the quality of existing translations; use translation_quality_check instead.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'translation_quality_check', 'export_import_translations', 'auto_translate_content' ),
			'notes'           => __( 'Limit the scan with scope (posts, products, theme, plugins, all) and a max string count.', 'mcp-ai-wpoos-pro' ),
		);
	}


	/**

	 * Get the parameters schema.
	 *
	 * @return array
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'language' => array(
					'type'        => 'string',
					'description' => 'Target language to check',
				),
				'scope'    => array(
					'type'        => 'string',
					'description' => 'Scope: posts, products, theme, plugins',
					'enum'        => array( 'posts', 'products', 'theme', 'plugins', 'all' ),
				),
				'limit'    => array(
					'type'        => 'integer',
					'description' => 'Maximum strings to return',
					'default'     => 100,
				),
			),
			'required'   => array(),
		);
	}


	/**

	 * Get the required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array(
			'content'     => true,
			'translation' => true,
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// TODO: Implement find_untranslated_strings logic.

		return array(
			'success' => true,
			'message' => __( 'Find Untranslated Strings executed successfully.', 'mcp-ai-wpoos-pro' ),
		);
	}
}
