<?php
declare(strict_types=1);

namespace NvoosContentGraph\Rest;

use NvoosContentGraph\Graph\Builder;
use NvoosContentGraph\Graph\Db;
use NvoosContentGraph\Graph\Exporter;
use NvoosContentGraph\Plugin;
use NvoosContentGraph\Remote\Crypto;
use NvoosContentGraph\Schema;
use NvoosContentGraph\Settings;
use NvoosContentGraph\Visual\Tokens;
use NvoosContentGraph\Tools\ListRemoteSources;
use NvoosContentGraph\Tools\ResolveExternal;
use NvoosContentGraph\Tools\RetrieveContext;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

use function __;
use function absint;
use function apply_filters;
use function class_exists;
use function count;
use function current_user_can;
use function function_exists;
use function is_user_logged_in;
use function is_wp_error;
use function preg_match;
use function register_rest_route;
use function rest_ensure_response;
use function sanitize_key;
use function sanitize_text_field;
use function trim;

/**
 * REST API controller for the NV oOS Content Graph plugin.
 *
 * Exposes the knowledge graph via the WordPress REST API at
 * /wp-json/nvoos-content-graph/v1/
 *
 * Routes:
 *   GET    /graph              — metadata and stats
 *   GET    /graph/visual-config — explorer display + theme config (headless
 *                                surfaces such as the NV oOS Pro SPA build
 *                                the localized admin config from this)
 *   GET    /nodes              — paginated, filterable node list
 *   GET    /nodes/{node_id}    — single node with neighbor edges
 *   POST   /build              — trigger a graph build (manage_options)
 *   GET    /search             — label search
 *   GET    /export             — export in various formats
 *   POST   /retrieve           — RAG context retrieval
 *   GET    /resolve            — resolve external entity
 *   GET    /sources            — list remote sources
 *   POST   /sources            — create a remote source
 *   DELETE /sources/{slug}     — delete a remote source
 *   POST   /sources/{slug}/sync — trigger manual sync
 *   POST   /sources/{slug}/test — test connection
 *   POST   /webhooks/{slug}    — receive a webhook payload
 *
 * @since 1.0.0
 */
class Controller {

	/**
	 * Register all REST routes.
	 *
	 * Called once on rest_api_init by {@see Plugin::register()}.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function registerRoutes(): void {
		// GET /graph — metadata + stats.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/graph',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'getGraph' ),
				'permission_callback' => array( $this, 'checkReadPermission' ),
			)
		);

		// GET /graph/visual-config — explorer display + theme config.
		// Read-only rendering data (visual tokens, presets, height, node
		// budget) so headless surfaces can render the explorer without the
		// PHP settings page. No settings values that could be considered
		// sensitive are exposed.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/graph/visual-config',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'getVisualConfig' ),
				'permission_callback' => array( $this, 'checkReadPermission' ),
			)
		);

		// GET /nodes — paginated node list.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/nodes',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'getNodes' ),
				'permission_callback' => array( $this, 'checkReadPermission' ),
				'args'                => array(
					'per_page'     => array(
						'type'              => 'integer',
						'default'           => 50,
						'minimum'           => 1,
						'maximum'           => 200,
						'sanitize_callback' => 'absint',
					),
					'page'         => array(
						'type'              => 'integer',
						'default'           => 1,
						'minimum'           => 1,
						'sanitize_callback' => 'absint',
					),
					'type'         => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'community_id' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'search'       => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// GET /nodes/{node_id} — single node.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/nodes/(?P<node_id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'getNode' ),
				'permission_callback' => array( $this, 'checkReadPermission' ),
				'args'                => array(
					'node_id' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'required'          => true,
					),
				),
			)
		);

		// GET /edges — paginated edge list (visual explorer edge set).
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/edges',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'getEdges' ),
				'permission_callback' => array( $this, 'checkReadPermission' ),
				'args'                => array(
					'per_page' => array(
						'type'              => 'integer',
						'default'           => 100,
						'minimum'           => 1,
						'maximum'           => 2000,
						'sanitize_callback' => 'absint',
					),
					'page'     => array(
						'type'              => 'integer',
						'default'           => 1,
						'minimum'           => 1,
						'sanitize_callback' => 'absint',
					),
					'relation' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// POST /build — trigger a build.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/build',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'triggerBuild' ),
				'permission_callback' => array( $this, 'checkAdminPermission' ),
				'args'                => array(
					'incremental' => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'semantic'    => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'reset'       => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		// GET /search — label search.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/search',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'searchNodes' ),
				'permission_callback' => array( $this, 'checkReadPermission' ),
				'args'                => array(
					'q'     => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'type'  => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'limit' => array(
						'type'              => 'integer',
						'default'           => 20,
						'minimum'           => 1,
						'maximum'           => 100,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// GET /export — export in various formats.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/export',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'exportGraph' ),
				'permission_callback' => array( $this, 'checkAdminPermission' ),
				'args'                => array(
					'format'    => array(
						'type'    => 'string',
						'default' => 'json',
						'enum'    => array( 'json', 'html', 'graphml', 'csv', 'neo4j', 'obsidian' ),
					),
					'max_nodes' => array(
						'type'              => 'integer',
						'default'           => 2000,
						'minimum'           => 1,
						'maximum'           => 5000,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// POST /retrieve — RAG context retrieval.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/retrieve',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'retrieveContext' ),
				'permission_callback' => array( $this, 'checkReadPermission' ),
				'args'                => array(
					'question'      => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'k'             => array(
						'type'              => 'integer',
						'default'           => 10,
						'minimum'           => 1,
						'maximum'           => 20,
						'sanitize_callback' => 'absint',
					),
					'hops'          => array(
						'type'              => 'integer',
						'default'           => 2,
						'minimum'           => 1,
						'maximum'           => 3,
						'sanitize_callback' => 'absint',
					),
					'use_vectors'   => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'include_edges' => array(
						'type'    => 'boolean',
						'default' => true,
					),
				),
			)
		);

		// GET /resolve — resolve external entity.
		// Read-only lookups are available to read-capability users, but
		// auto-ingesting new nodes is a state-changing operation, so it is
		// enforced inside resolveExternal() for manage_options users only.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/resolve',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'resolveExternal' ),
				'permission_callback' => array( $this, 'checkReadPermission' ),
				'args'                => array(
					'ref'         => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'auto_ingest' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		// GET /sources — list remote sources.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/sources',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'getSources' ),
				'permission_callback' => array( $this, 'checkAdminPermission' ),
			)
		);

		// POST /sources — create a remote source.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/sources',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'createSource' ),
				'permission_callback' => array( $this, 'checkAdminPermission' ),
				'args'                => array(
					'slug'    => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_key',
					),
					'driver'  => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_key',
					),
					'label'   => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'enabled' => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'config'  => array(
						'type'              => 'object',
						'default'           => array(),
						'sanitize_callback' => array( __CLASS__, 'sanitizeSourceConfig' ),
					),
				),
			)
		);

		// DELETE /sources/{slug} — delete a remote source.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/sources/(?P<slug>[a-z0-9_\-]+)',
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'deleteSource' ),
				'permission_callback' => array( $this, 'checkAdminPermission' ),
				'args'                => array(
					'slug' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
						'required'          => true,
					),
				),
			)
		);

		// POST /sources/{slug}/sync — trigger manual sync.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/sources/(?P<slug>[a-z0-9_\-]+)/sync',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'syncSource' ),
				'permission_callback' => array( $this, 'checkAdminPermission' ),
				'args'                => array(
					'slug'  => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
						'required'          => true,
					),
					'async' => array(
						'type'    => 'boolean',
						'default' => true,
					),
				),
			)
		);

		// POST /sources/{slug}/test — test connection.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/sources/(?P<slug>[a-z0-9_\-]+)/test',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'testSource' ),
				'permission_callback' => array( $this, 'checkAdminPermission' ),
				'args'                => array(
					'slug' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
						'required'          => true,
					),
				),
			)
		);

		// POST /webhooks/{slug} — receive a webhook payload for a configured webhook source.
		// Authentication is via per-source HMAC-SHA256 (X-NVOOS-Signature header), so the
		// permission_callback returns true and verification happens in the handler.
		// Uses a named callback (not __return_true) so automated scanners understand
		// this is an intentionally public route with custom auth.
		register_rest_route(
			Schema::REST_NAMESPACE,
			'/webhooks/(?P<slug>[a-z0-9_\-]+)',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'receiveWebhook' ),
				'permission_callback' => array( $this, 'checkWebhookPermission' ),
				'args'                => array(
					'slug' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
						'required'          => true,
					),
				),
			)
		);
	}

	// -------------------------------------------------------------------------
	// Route callbacks
	// -------------------------------------------------------------------------

	/**
	 * GET /graph — Return metadata and stats.
	 *
	 * @since 1.0.0
	 *
	 * @return WP_REST_Response
	 */
	public function getGraph(): WP_REST_Response {
		$stats     = Db::getStats();
		$lastBuild = Db::getMeta( 'last_build_completed', 'never' );
		$status    = Db::getMeta( 'build_status', 'idle' );

		return rest_ensure_response(
			array(
				'version'      => \NVOOS_CONTENT_GRAPH_VERSION,
				'stats'        => $stats,
				'last_build'   => $lastBuild,
				'build_status' => $status,
			)
		);
	}

	/**
	 * GET /graph/visual-config — Explorer display + theme config.
	 *
	 * Mirrors the `nvoosContentGraphAdmin` localization the settings page
	 * emits for its embedded explorer, minus the WordPress-only fields
	 * (ajax URL/nonce). Headless clients assemble the explorer config from
	 * this payload instead of scraping the admin page.
	 *
	 * @since 1.1.0
	 *
	 * @return WP_REST_Response
	 */
	public function getVisualConfig(): WP_REST_Response {
		$settings = Settings::all();

		return rest_ensure_response(
			array(
				'visual'    => Tokens::visual_config( $settings ),
				'presets'   => Tokens::presets(),
				'height'    => isset( $settings['cytoscape_height'] ) ? (string) $settings['cytoscape_height'] : '600px',
				'max_nodes' => absint( isset( $settings['max_display_nodes'] ) ? $settings['max_display_nodes'] : 2000 ),
			)
		);
	}

	/**
	 * GET /nodes — Paginated, filterable node list.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function getNodes( WP_REST_Request $request ): WP_REST_Response {
		$perPage     = $request->get_param( 'per_page' );
		$page        = $request->get_param( 'page' );
		$offset      = ( $page - 1 ) * $perPage;
		$type        = $request->get_param( 'type' );
		$communityId = $request->get_param( 'community_id' );
		$search      = $request->get_param( 'search' );

		$nodes = Db::listNodes(
			array(
				'limit'        => $perPage,
				'offset'       => $offset,
				'type'         => $type,
				'community_id' => $communityId,
				'search'       => $search,
			)
		);

		$response = rest_ensure_response( $nodes );
		$response->header( 'X-WP-Page', $page );
		$response->header( 'X-WP-PerPage', $perPage );

		return $response;
	}

	/**
	 * GET /nodes/{node_id} — Single node with neighbors.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function getNode( WP_REST_Request $request ) {
		$nodeId = sanitize_text_field( $request->get_param( 'node_id' ) );
		$node   = Db::getNode( $nodeId );

		if ( ! $node ) {
			return new WP_Error( 'nvoos_content_graph_not_found', __( 'Node not found.', 'nvoos-content-graph' ), array( 'status' => 404 ) );
		}

		$edges     = Db::getEdgesForNode( $nodeId );
		$neighbors = array();
		foreach ( $edges as $edge ) {
			$nid         = ( $edge->source_node_id === $nodeId ) ? $edge->target_node_id : $edge->source_node_id;
			$nbr         = Db::getNode( $nid );
			$neighbors[] = array(
				'node_id'   => $nid,
				'label'     => $nbr ? $nbr->label : $nid,
				'type'      => $nbr ? $nbr->type : '',
				'relation'  => $edge->relation,
				'direction' => ( $edge->source_node_id === $nodeId ) ? 'outgoing' : 'incoming',
			);
		}

		return rest_ensure_response(
			array(
				'node'      => $node,
				'neighbors' => $neighbors,
			)
		);
	}

	/**
	 * GET /edges — Paginated edge list.
	 *
	 * @since 1.0.4
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function getEdges( WP_REST_Request $request ): WP_REST_Response {
		$perPage  = $request->get_param( 'per_page' );
		$page     = $request->get_param( 'page' );
		$relation = $request->get_param( 'relation' );
		$offset   = ( $page - 1 ) * $perPage;

		$args = array(
			'limit'  => $perPage,
			'offset' => $offset,
		);
		if ( $relation ) {
			$args['relation'] = $relation;
		}

		$edges    = Db::listEdges( $args );
		$response = rest_ensure_response( $edges );
		$response->header( 'X-WP-Page', $page );
		$response->header( 'X-WP-PerPage', $perPage );

		return $response;
	}

	/**
	 * POST /build — trigger a build.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function triggerBuild( WP_REST_Request $request ): WP_REST_Response {
		$result = Builder::build(
			array(
				'incremental'    => (bool) $request->get_param( 'incremental' ),
				'semantic'       => (bool) $request->get_param( 'semantic' ),
				'async_semantic' => true,
				'reset'          => (bool) $request->get_param( 'reset' ),
			)
		);
		return rest_ensure_response( $result );
	}

	/**
	 * GET /search — Node label search.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function searchNodes( WP_REST_Request $request ): WP_REST_Response {
		$query   = sanitize_text_field( $request->get_param( 'q' ) );
		$type    = sanitize_text_field( $request->get_param( 'type' ) );
		$limit   = absint( $request->get_param( 'limit' ) );
		$results = Db::searchNodes( $query, $type, $limit );

		return rest_ensure_response(
			array(
				'query'   => $query,
				'results' => $results,
				'count'   => count( $results ),
			)
		);
	}

	/**
	 * GET /export — Export graph.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function exportGraph( WP_REST_Request $request ): WP_REST_Response {
		$format   = sanitize_key( $request->get_param( 'format' ) );
		$maxNodes = absint( $request->get_param( 'max_nodes' ) );

		$result = Exporter::export( $format, array( 'max_nodes' => $maxNodes ) );

		return rest_ensure_response(
			array(
				'format' => $format,
				'data'   => $result,
			)
		);
	}

	/**
	 * POST /retrieve — RAG context retrieval.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function retrieveContext( WP_REST_Request $request ): WP_REST_Response {
		$tool   = new RetrieveContext();
		$result = $tool->execute(
			array(
				'question'      => $request->get_param( 'question' ),
				'k'             => $request->get_param( 'k' ),
				'hops'          => $request->get_param( 'hops' ),
				'use_vectors'   => (bool) $request->get_param( 'use_vectors' ),
				'include_edges' => (bool) $request->get_param( 'include_edges' ),
			),
			array()
		);
		return rest_ensure_response( $result );
	}

	/**
	 * GET /resolve — Resolve an external entity ref to a local node.
	 *
	 * Read-only resolution is available to all users with read capability.
	 * Auto-ingesting a new node mutates the graph, so it is restricted to
	 * users with manage_options; non-admin callers receive a 403 when they
	 * explicitly request it.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function resolveExternal( WP_REST_Request $request ) {
		$auto_ingest = (bool) $request->get_param( 'auto_ingest' );
		if ( $auto_ingest && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'nvoos_content_graph_forbidden',
				__( 'Auto-ingesting external entities requires administrator access. Use auto_ingest=false for read-only resolution.', 'nvoos-content-graph' ),
				array( 'status' => 403 )
			);
		}

		$tool   = new ResolveExternal();
		$result = $tool->execute(
			array(
				'ref'         => $request->get_param( 'ref' ),
				'auto_ingest' => $auto_ingest,
			),
			array()
		);
		return rest_ensure_response( $result );
	}

	/**
	 * GET /sources — List configured remote sources.
	 *
	 * @since 1.0.0
	 *
	 * @return WP_REST_Response
	 */
	public function getSources(): WP_REST_Response {
		$tool   = new ListRemoteSources();
		$result = $tool->execute( array(), array() );
		return rest_ensure_response( $result );
	}

	/**
	 * POST /sources — Create a remote source.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function createSource( WP_REST_Request $request ) {
		$driver = sanitize_key( $request->get_param( 'driver' ) );

		// Refuse unknown drivers instead of persisting a source that can
		// never be instantiated.
		if ( ! Plugin::instance()->getRemoteRegistry()->getDriver( $driver ) ) {
			return new WP_Error(
				'unknown_driver',
				__( 'Unknown remote source driver.', 'nvoos-content-graph' ),
				array( 'status' => 400 )
			);
		}

		$config = $request->get_param( 'config' );
		if ( ! is_array( $config ) ) {
			$config = array();
		}
		$result = Db::saveRemoteSource(
			array(
				'slug'    => $request->get_param( 'slug' ),
				'driver'  => $driver,
				'label'   => $request->get_param( 'label' ) ?? '',
				'enabled' => (bool) $request->get_param( 'enabled' ),
				'config'  => $config,
			)
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response(
			array(
				'success' => true,
				'slug'    => $request->get_param( 'slug' ),
			)
		);
	}

	/**
	 * DELETE /sources/{slug} — Delete a remote source.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function deleteSource( WP_REST_Request $request ): WP_REST_Response {
		Db::deleteRemoteSource( sanitize_key( $request->get_param( 'slug' ) ) );
		return rest_ensure_response( array( 'success' => true ) );
	}

	/**
	 * POST /sources/{slug}/sync — Trigger a manual source sync.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function syncSource( WP_REST_Request $request ) {
		$slug     = sanitize_key( $request->get_param( 'slug' ) );
		$async    = (bool) $request->get_param( 'async' );
		$enricher = new \NvoosContentGraph\Remote\Enricher();
		$summary  = $enricher->syncSource( $slug, $async );

		if ( is_wp_error( $summary ) ) {
			return $summary;
		}
		return rest_ensure_response(
			array(
				'success' => true,
				'slug'    => $slug,
				'async'   => $async,
				'summary' => $summary,
			)
		);
	}

	/**
	 * POST /sources/{slug}/test — Test a source connection.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function testSource( WP_REST_Request $request ) {
		$slug     = sanitize_key( $request->get_param( 'slug' ) );
		$dbSource = Db::getRemoteSource( $slug );

		if ( ! $dbSource || empty( $dbSource->enabled ) ) {
			return new WP_Error( 'not_found', __( 'Source not found or not enabled.', 'nvoos-content-graph' ), array( 'status' => 404 ) );
		}

		$registry = Plugin::instance()->getRemoteRegistry();
		$driverId = sanitize_key( $dbSource->driver ?? '' );
		if ( ! $registry->getDriver( $driverId ) ) {
			return new WP_Error( 'no_driver', __( 'Driver not found.', 'nvoos-content-graph' ), array( 'status' => 400 ) );
		}

		// Build a per-source instance with decrypted credentials — testing
		// the shared prototype would run without any configured values.
		$config                = Crypto::decryptConfig( $dbSource->config_json ?? '' );
		$config['_slug']       = $slug;
		$config['_rate_limit'] = absint( $dbSource->rate_limit ?? 0 );

		$driver = $registry->getDriverInstance( $driverId, $config );
		if ( ! $driver ) {
			return new WP_Error( 'no_driver', __( 'Driver not found.', 'nvoos-content-graph' ), array( 'status' => 400 ) );
		}

		$result = $driver->testConnection();

		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response(
			array(
				'success' => true,
				'result'  => $result,
			)
		);
	}

	/**
	 * POST /webhooks/{slug} — Receive a verified webhook payload for a webhook-source.
	 *
	 * The configured per-source `webhook_secret` is used to validate the
	 * `X-NVOOS-Signature` header (HMAC-SHA256 of the raw request body, hex,
	 * optionally prefixed with `sha256=`). On success, ingested nodes are
	 * upserted and entity resolution is attempted for each new node.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request Incoming request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function receiveWebhook( WP_REST_Request $request ) {
		$slug = sanitize_key( $request->get_param( 'slug' ) );
		if ( '' === $slug ) {
			return new WP_Error( 'webhook_invalid_slug', __( 'Invalid source slug.', 'nvoos-content-graph' ), array( 'status' => 400 ) );
		}

		$dbSource = Db::getRemoteSource( $slug );
		if ( ! $dbSource || empty( $dbSource->enabled ) ) {
			return new WP_Error( 'webhook_unknown_source', __( 'Unknown or disabled source.', 'nvoos-content-graph' ), array( 'status' => 404 ) );
		}
		if ( 'webhook' !== sanitize_key( $dbSource->driver ) ) {
			return new WP_Error( 'webhook_wrong_driver', __( 'Source is not configured as a webhook receiver.', 'nvoos-content-graph' ), array( 'status' => 400 ) );
		}

		// Decrypt config so we can read the secret + field map.
		$config          = Crypto::decryptConfig( $dbSource->config_json ?? '' );
		$config['_slug'] = $slug;

		if ( ! class_exists( \NvoosContentGraph\Remote\Drivers\Webhook::class ) ) {
			return new WP_Error( 'webhook_driver_missing', __( 'The webhook driver is not available in this build.', 'nvoos-content-graph' ), array( 'status' => 501 ) );
		}

		$driver = new \NvoosContentGraph\Remote\Drivers\Webhook();
		$driver->setConfig( $config );

		$rawBody   = (string) $request->get_body();
		$signature = (string) $request->get_header( 'x-nvoos-signature' );
		if ( ! $driver->verifySignature( $rawBody, $signature ) ) {
			return new WP_Error( 'webhook_bad_signature', __( 'Invalid or missing signature.', 'nvoos-content-graph' ), array( 'status' => 401 ) );
		}

		$nodes    = $driver->ingestPayload( $rawBody );
		$ingested = 0;
		$resolved = 0;
		foreach ( $nodes as $node ) {
			if ( Db::upsertNode( $node ) ) {
				++$ingested;
				if ( ! empty( $node['node_id'] ) && class_exists( \NvoosContentGraph\Graph\EntityResolver::class ) ) {
					$resolved += \NvoosContentGraph\Graph\EntityResolver::resolveNode( $node, $slug );
				}
			}
		}

		Db::updateRemoteSourceSync( $slug );

		return rest_ensure_response(
			array(
				'success'        => true,
				'received'       => count( $nodes ),
				'ingested'       => $ingested,
				'sameAs_emitted' => $resolved,
			)
		);
	}

	// -------------------------------------------------------------------------
	// Sanitization helpers
	// -------------------------------------------------------------------------

	/**
	 * Recursively sanitize a remote-source config array for the REST API.
	 *
	 * Used as the `sanitize_callback` for the `config` argument on
	 * POST /sources. String values are sanitized, scalar values are kept
	 * as-is, arrays are recursed, and everything else is dropped.
	 *
	 * @since 1.0.3
	 *
	 * @param mixed $config Raw config from the REST request.
	 * @return array<string,mixed>
	 */
	public static function sanitizeSourceConfig( $config ): array {
		if ( ! is_array( $config ) ) {
			return array();
		}

		$clean = array();
		foreach ( $config as $key => $value ) {
			$key = sanitize_key( (string) $key );
			if ( '' === $key ) {
				continue;
			}

			if ( is_array( $value ) ) {
				$clean[ $key ] = self::sanitizeSourceConfig( $value );
			} elseif ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
				$clean[ $key ] = $value;
			} elseif ( is_string( $value ) ) {
				$clean[ $key ] = sanitize_text_field( $value );
			}
			// nulls and objects are dropped.
		}

		return $clean;
	}

	// -------------------------------------------------------------------------
	// Permission callbacks
	// -------------------------------------------------------------------------

	/**
	 * Check read permission: authenticated user with at least 'read' capability,
	 * a valid NV oOS assistant credential (bearer token), or a valid base
	 * plugin guest token.
	 *
	 * Assistant credentials are CSRF-safe header tokens issued by the NV oOS
	 * base plugin (`cred_XXXXX.SECRET`, presented as
	 * `Authorization: Bearer …`). This mirrors the base plugin's REST layer:
	 * a token in credential format that fails validation is a definitive
	 * rejection, while requests without a credential fall through to the
	 * guest-token check.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request|null $request REST request (supplied by WordPress).
	 * @return bool|WP_Error
	 */
	public function checkReadPermission( $request = null ) {
		if ( is_user_logged_in() && current_user_can( 'read' ) ) {
			return true;
		}

		// Assistant credential (bearer) authentication — read-only scope.
		// Write routes keep their separate manage_options check, so a
		// credential can never rebuild, export, or mutate remote sources.
		if ( $request instanceof WP_REST_Request ) {
			$credential = $this->validate_request_credential( $request );
			if ( null !== $credential ) {
				return is_wp_error( $credential ) ? $credential : true;
			}
		}

		// Allow public access if the base plugin guest token is valid.
		if ( function_exists( '\wp_mcp_ai_validate_guest_token' ) && \wp_mcp_ai_validate_guest_token() ) {
			return true;
		}
		return new WP_Error( 'nvoos_content_graph_forbidden', __( 'You must be logged in to access the knowledge graph.', 'nvoos-content-graph' ), array( 'status' => 401 ) );
	}

	/**
	 * Validate an NV oOS assistant credential presented on a REST request.
	 *
	 * Accepts the standard `Authorization: Bearer cred_xxxxx.SECRET` header
	 * and the raw credential form the base plugin tolerates
	 * (`Authorization: cred_xxxxx.SECRET`, gated by the same
	 * `wp_mcp_ai_accept_raw_credential_header` filter). Returns the validated
	 * credential metadata on success, a WP_Error for a rejected credential,
	 * or null when no credential was presented (or the base plugin is not
	 * installed, in which case there is nothing to validate against).
	 *
	 * @since 1.1.0
	 *
	 * @param WP_REST_Request $request REST request instance.
	 * @return array|WP_Error|null Credential metadata, WP_Error, or null when absent.
	 */
	protected function validate_request_credential( WP_REST_Request $request ) {
		if ( ! class_exists( 'WP_MCP_AI_Credentials' ) ) {
			return null;
		}

		$header = $request->get_header( 'Authorization' );
		$token  = '';
		if ( ! empty( $header ) && preg_match( '/^Bearer\s+(.*)$/i', (string) $header, $matches ) ) {
			$token = trim( $matches[1] );
		} elseif ( ! empty( $header ) ) {
			// Raw credential header (no "Bearer" scheme), mirroring the base
			// plugin's compatibility handling.
			$accept_raw_credential = apply_filters( 'wp_mcp_ai_accept_raw_credential_header', true );
			if ( $accept_raw_credential ) {
				$token = trim( (string) $header );
			}
		}

		if ( '' === $token || ! \WP_MCP_AI_Credentials::is_token_format( $token ) ) {
			return null;
		}

		return \WP_MCP_AI_Credentials::validate_token( $token );
	}

	/**
	 * Check admin permission: manage_options capability required.
	 *
	 * @since 1.0.0
	 *
	 * @return bool|WP_Error
	 */
	public function checkAdminPermission() {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		return new WP_Error( 'nvoos_content_graph_forbidden', __( 'Administrator access required.', 'nvoos-content-graph' ), array( 'status' => 403 ) );
	}

	/**
	 * Webhook permission callback — intentionally returns true.
	 *
	 * Webhook endpoints use per-source HMAC-SHA256 signature verification
	 * (X-NVOOS-Signature header) performed inside {@see receiveWebhook()}
	 * rather than WordPress authentication.
	 *
	 * @since 1.0.0
	 *
	 * @return true
	 */
	public function checkWebhookPermission(): bool {
		return true;
	}
}
