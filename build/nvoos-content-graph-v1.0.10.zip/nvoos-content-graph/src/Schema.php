<?php
declare(strict_types=1);

namespace NvoosContentGraph;

use function file_exists;
use function filemtime;
use function ltrim;

/**
 * Centralized constants for the NV oOS Content Graph plugin.
 *
 * Every option key, table name, hook name, nonce action,
 * and capability slug lives here. No magic strings anywhere else.
 *
 * @since 1.0.0
 */
final class Schema {

	// ─── Option keys ───────────────────────────────────────────
	public const OPTION_SETTINGS   = 'nvoos_content_graph_settings';
	public const OPTION_DB_VERSION = 'nvoos_content_graph_db_version';
	public const OPTION_LICENSE    = 'nvoos_content_graph_license';

	// ─── Custom tables ─────────────────────────────────────────
	public const TABLE_NODES          = 'nvoos_content_graph_nodes';
	public const TABLE_EDGES          = 'nvoos_content_graph_edges';
	public const TABLE_META           = 'nvoos_content_graph_meta';
	public const TABLE_REMOTE_SOURCES = 'nvoos_content_graph_remote_sources';
	public const TABLE_EMBEDDINGS     = 'nvoos_content_graph_embeddings';

	// ─── Action hooks ──────────────────────────────────────────
	public const ACTION_REGISTER_TOOLS          = 'nvoos_content_graph/register_tools';
	public const ACTION_REGISTER_REMOTE_SOURCES = 'nvoos_content_graph/register_remote_sources';
	public const ACTION_BEFORE_BUILD            = 'nvoos_content_graph/before_build';
	public const ACTION_AFTER_BUILD             = 'nvoos_content_graph/after_build';
	public const ACTION_SETTINGS_SAVED          = 'nvoos_content_graph/after_settings_saved';
	public const ACTION_MEMORY_STORED           = 'nvoos_content_graph/memory_stored';

	// ─── Filter hooks ───────────────────────────────────────────
	public const FILTER_DEFAULT_SETTINGS   = 'nvoos_content_graph/default_settings';
	public const FILTER_ALLOW_PRIVATE_URLS = 'nvoos_content_graph/allow_private_urls';
	public const FILTER_ENRICH_BUDGET      = 'nvoos_content_graph/enrich_budget';
	public const FILTER_RAG_CANDIDATES     = 'nvoos_content_graph/rag_candidates';
	public const FILTER_PRICE_CENTS        = 'nvoos_content_graph/payments/price_cents';
	public const FILTER_ADDON_VERSION      = 'nvoos_content_graph/payments/addon_version';
	public const FILTER_ADDON_ZIP_URL      = 'nvoos_content_graph/payments/addon_zip_url';
	public const FILTER_BASE_VERSION_URL   = 'nvoos_content_graph/payments/base_version_url';
	public const FILTER_VENDOR_API_URL     = 'nvoos_content_graph/payments/vendor_api_url';
	public const FILTER_FALLBACK_URL       = 'nvoos_content_graph/payments/fallback_url';
	public const FILTER_TERMS_URL          = 'nvoos_content_graph/payments/terms_url';
	public const FILTER_REFUND_POLICY_URL  = 'nvoos_content_graph/payments/refund_policy_url';
	public const FILTER_EU_COUNTRIES       = 'nvoos_content_graph/payments/eu_countries';
	public const FILTER_ROADMAP_URL        = 'nvoos_content_graph/payments/roadmap_url';
	public const FILTER_CHANGELOG_URL      = 'nvoos_content_graph/payments/changelog_url';
	public const FILTER_SUPPORT_EMAIL      = 'nvoos_content_graph/payments/support_email';

	// ─── Visual filters (see NvoosContentGraph\Visual\Tokens) ──
	public const FILTER_TYPE_PALETTE  = 'nvoos_content_graph/type_palette';
	public const FILTER_TYPE_ICONS    = 'nvoos_content_graph/type_icons';
	public const FILTER_VISUAL_CONFIG = 'nvoos_content_graph/visual_config';

	// ─── Commerce ─────────────────────────────────────────────
	public const PRODUCT_AI_ADDON = 'nvoos-content-graph-ai';

	/**
	 * Product id for the NV oOS Complete bundle sold through the checkout.
	 *
	 * The vendor checkout API validates this value (see
	 * addons/checkout-api NVOOS_Checkout_API_Rest_Controller::PRODUCTS).
	 * The legacy AI-addon product id stays listed for purchases made
	 * before the Complete bundle replaced it.
	 *
	 * @since 1.0.6
	 */
	public const PRODUCT_COMPLETE = 'nvoos-oos-complete';

	// ─── Cron hooks ────────────────────────────────────────────
	public const CRON_BUILD  = 'nvoos_content_graph/cron_build';
	public const CRON_ENRICH = 'nvoos_content_graph/cron_enrich';

	// ─── Capabilities ──────────────────────────────────────────
	public const CAP_MANAGE_GRAPH = 'manage_options';

	// ─── Nonce actions ─────────────────────────────────────────
	public const NONCE_BUILD  = 'nvoos_content_graph_build_graph';
	public const NONCE_EXPORT = 'nvoos_content_graph_export';

	// ─── REST namespace ────────────────────────────────────────
	public const REST_NAMESPACE = 'nvoos-content-graph/v1';

	// ─── Transient prefix ──────────────────────────────────────
	public const TRANSIENT_PREFIX = 'nvoos_content_graph_';

	/**
	 * Cache-busting version string for a plugin asset.
	 *
	 * Uses the file's modification time so any change to the asset —
	 * including hotfixes deployed without a version bump — produces a new
	 * enqueue URL and defeats long-lived browser/CDN caches (see the
	 * 1.0.7 purchase-modal incident, where the fixed
	 * `content-graph-commerce.js` stayed cached for up to a year under
	 * `?ver=1.0.7`). Falls back to the plugin version when the file is
	 * missing (e.g. in test harnesses that don't ship assets).
	 *
	 * @since 1.0.7
	 *
	 * @param string $relative Asset path relative to the plugin root
	 *                          (e.g. 'assets/js/content-graph-commerce.js').
	 * @return string Version string for the `$ver` enqueue argument.
	 */
	public static function assetVersion( string $relative ): string {
		$file = NVOOS_CONTENT_GRAPH_PATH . ltrim( $relative, '/' );
		if ( file_exists( $file ) ) {
			$mtime = filemtime( $file );
			if ( false !== $mtime && $mtime > 0 ) {
				return (string) $mtime;
			}
		}

		return NVOOS_CONTENT_GRAPH_VERSION;
	}

	/**
	 * Return the default settings array.
	 *
	 * Note: AI-related settings (API keys, models, providers) are
	 * NOT in core defaults. They are registered by the respective
	 * AI addon plugins via the `nvoos_content_graph/default_settings` filter.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string,mixed>
	 */
	public static function defaultSettings(): array {
		$defaults = array(
			'enabled'                  => true,
			'auto_rebuild'             => true,
			'rebuild_schedule'         => 'weekly',
			'post_types'               => array( 'post', 'page' ),
			'include_terms'            => true,
			'include_users'            => true,
			'schema_injection'         => true,
			'related_content'          => true,
			'semantic_extraction'      => false,
			'incremental_builds'       => false,
			'openai_api_key'           => '',
			'cytoscape_height'         => '600px',
			'max_display_nodes'        => 300,
			'max_related'              => 5,
			'remote_enrich_enabled'    => false,
			'remote_enrich_budget'     => 50,
			'remote_enrich_async'      => false,
			'embeddings_enabled'       => false,
			'embeddings_model'         => 'text-embedding-3-small',
			'excluded_post_types'      => array(),
			'extra_post_types'         => array(),
			'excluded_cct_slugs'       => array(),
			'external_tables'          => array(),
			'disabled_external_tables' => array(),
		);

		// Visual experience settings (see NvoosContentGraph\Visual\Tokens).
		$defaults = array_merge( $defaults, \NvoosContentGraph\Visual\Tokens::visual_defaults() );

		return apply_filters( self::FILTER_DEFAULT_SETTINGS, $defaults );
	}

	/** Private constructor — not instantiable. */
	private function __construct() {}
}
