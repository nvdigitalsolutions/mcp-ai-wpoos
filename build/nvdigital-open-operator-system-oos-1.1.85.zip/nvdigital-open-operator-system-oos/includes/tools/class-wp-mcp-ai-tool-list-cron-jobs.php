<?php
/**
 * Tool for listing WordPress cron jobs.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Cron_Manager' ) ) {
	require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-cron-manager.php';
}

/**
 * Allows users to list all scheduled WordPress cron jobs.
 */
class WP_MCP_AI_Tool_List_Cron_Jobs implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Ability_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'list_cron_jobs';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'List Cron Jobs', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Lists all WordPress cron jobs that have been scheduled through the plugin.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Reviewing plugin-scheduled WordPress cron jobs and their next run times.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Scheduling or removing jobs; use create_cron_job_validated or delete_cron_job.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'create_cron_job_validated', 'get_cron_job', 'delete_cron_job' ),
			'notes'           => __( 'Requires manage_options and cron orchestration enabled in settings.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => (object) array(),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Check if cron orchestration is enabled.
		if ( class_exists( 'WP_MCP_AI_Orchestration_Budget_Enforcement_Service' ) ) {
			if ( ! WP_MCP_AI_Orchestration_Budget_Enforcement_Service::is_cron_orchestration_enabled() ) {
				return new WP_Error( 'wp_mcp_ai_cron_disabled', __( 'Cron-based task orchestration is currently disabled. Enable it in Settings → Orchestration Layer → Settings.', 'nvdigital-open-operator-system-oos' ) );
			}
		}

		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to list cron jobs.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Prune stale jobs before listing.
		WP_MCP_AI_Cron_Manager::maybe_prune_jobs();

		$jobs = WP_MCP_AI_Cron_Manager::get_jobs();

		if ( empty( $jobs ) ) {
			return array(
				'jobs'    => array(),
				'count'   => 0,
				'message' => __( 'No cron jobs are currently scheduled.', 'nvdigital-open-operator-system-oos' ),
			);
		}

		$formatted_jobs = array();

		foreach ( $jobs as $job ) {
			$hook  = isset( $job['hook'] ) ? (string) $job['hook'] : '';
			$args  = isset( $job['args'] ) ? $job['args'] : array();
			$event = wp_get_scheduled_event( $hook, $args );

			$next_run   = $event ? $event->timestamp : null;
			$schedule   = isset( $job['schedule'] ) ? $job['schedule'] : 'single';
			$created_by = isset( $job['created_by'] ) ? (int) $job['created_by'] : 0;

			$creator = '';
			if ( $created_by > 0 ) {
				$user = get_userdata( $created_by );
				if ( $user ) {
					$creator = $user->display_name;
				}
			}

			if ( '' === $creator ) {
				$creator = __( 'System', 'nvdigital-open-operator-system-oos' );
			}

			$formatted_job = array(
				'job_id'   => isset( $job['job_id'] ) ? $job['job_id'] : '',
				'hook'     => $hook,
				'schedule' => $schedule,
				'args'     => $args,
				'creator'  => $creator,
			);

			if ( $next_run ) {
				$formatted_job['next_run']           = $next_run;
				$formatted_job['next_run_formatted'] = wp_date( DATE_ATOM, $next_run );
			} else {
				$formatted_job['next_run']           = null;
				$formatted_job['next_run_formatted'] = __( 'Not scheduled', 'nvdigital-open-operator-system-oos' );
			}

			if ( isset( $job['created_at'] ) && $job['created_at'] ) {
				$formatted_job['created_at']           = (int) $job['created_at'];
				$formatted_job['created_at_formatted'] = wp_date( DATE_ATOM, (int) $job['created_at'] );
			}

			if ( isset( $job['first_timestamp'] ) && $job['first_timestamp'] ) {
				$formatted_job['first_timestamp'] = (int) $job['first_timestamp'];
			}

			$formatted_jobs[] = $formatted_job;
		}

		return array(
			'jobs'    => $formatted_jobs,
			'count'   => count( $formatted_jobs ),
			'message' => sprintf(
				/* translators: %d: number of cron jobs */
				_n( 'Found %d cron job.', 'Found %d cron jobs.', count( $formatted_jobs ), 'nvdigital-open-operator-system-oos' ),
				count( $formatted_jobs )
			),
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'workflow_automation',

			'pattern_compatibility' => array( 'hierarchical' ),

			'profession_tags'       => array( 'systems_administrator' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',            // Only reads data, does not modify state.
			'local-only',           // No external API calls.
			'requires-capability',  // Requires user capabilities.
		);
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function get_ability_identifier() {
		return 'list-cron-jobs';
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function get_ability_category() {
		return 'nvoos-system';
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 2.0.0
	 * @return array
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'jobs'    => array(
					'type'        => 'array',
					'description' => 'Array of scheduled cron jobs.',
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'job_id'               => array(
								'type'        => 'string',
								'description' => 'Unique job identifier.',
							),
							'hook'                 => array(
								'type'        => 'string',
								'description' => 'WordPress hook name.',
							),
							'schedule'             => array(
								'type'        => 'string',
								'description' => 'Schedule type (single, hourly, daily, etc.).',
							),
							'args'                 => array(
								'type'        => 'array',
								'description' => 'Hook arguments.',
							),
							'creator'              => array(
								'type'        => 'string',
								'description' => 'Display name of the job creator.',
							),
							'next_run'             => array(
								'type'        => 'integer',
								'description' => 'Unix timestamp of next run.',
							),
							'next_run_formatted'   => array(
								'type'        => 'string',
								'description' => 'Formatted next run date.',
							),
							'created_at'           => array(
								'type'        => 'integer',
								'description' => 'Unix timestamp of creation.',
							),
							'created_at_formatted' => array(
								'type'        => 'string',
								'description' => 'Formatted creation date.',
							),
							'first_timestamp'      => array(
								'type'        => 'integer',
								'description' => 'First execution timestamp.',
							),
						),
					),
				),
				'count'   => array(
					'type'        => 'integer',
					'description' => 'Number of jobs returned.',
				),
				'message' => array(
					'type'        => 'string',
					'description' => 'Human-readable summary.',
				),
			),
		);
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 2.0.0
	 * @return bool
	 */
	public function is_public_ability() {
		return true;
	}
}
