<?php
/**
 * Tool for web search (Validated version).
 *
 * This is the Symfony Validator version of the web_search tool.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../validators/class-wp-mcp-ai-validated-tool.php';
require_once __DIR__ . '/../validators/arguments/class-web-search-arguments.php';
require_once __DIR__ . '/class-wp-mcp-ai-tool-web-search.php';

/**
 * Performs web search with Symfony Validator.
 *
 * This class extends the original web_search tool to use
 * Symfony Validator for argument validation.
 */
class WP_MCP_AI_Tool_Web_Search_Validated extends WP_MCP_AI_Validated_Tool implements WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_LLM_Sanitizer_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * The original web_search tool instance for delegation.
	 *
	 * @var WP_MCP_AI_Tool_Web_Search
	 */
	protected $original_tool;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
		$this->original_tool = new WP_MCP_AI_Tool_Web_Search();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'web_search_validated';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Web Search (Validated)', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Searches the public web via the configured provider and returns the top results with Symfony Validator for argument validation.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Searching the public web with Symfony Validator enforcement of the query and result-count arguments.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'When strict validation is unnecessary; use web_search directly, or search_content for content on this site.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'web_search', 'semantic_content_search', 'run_crawl4ai_job' ),
			'notes'           => __( 'Validated arguments are converted back to an array and executed by the original web_search tool.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		// Use the same schema as the original tool.
		return $this->original_tool->get_parameters_schema();
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_validation_class() {
		return \WP_MCP_AI\Tools\Arguments\WebSearchArguments::class;
	}

	/**
	 * Execute the tool with validated arguments.
	 *
	 * @param \WP_MCP_AI\Tools\Arguments\WebSearchArguments $validated_args Validated arguments object.
	 * @param array                                         $context        Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	protected function execute_validated( $validated_args, $context ) {
		// Convert validated arguments object back to array format.
		$arguments = array(
			'query' => $validated_args->query,
		);

		// Add optional arguments if provided.
		if ( null !== $validated_args->max_results ) {
			$arguments['max_results'] = $validated_args->max_results;
		}

		// Delegate to the original tool's execute method.
		return $this->original_tool->execute( $arguments, $context );
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'research_discovery',

			'pattern_compatibility' => array( 'orchestrator', 'peer_to_peer' ),

			'profession_tags'       => array( 'researcher', 'journalist', 'analyst', 'writer', 'librarian' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		// Delegate to the original tool.
		return $this->original_tool->get_capability_flags();
	}

	/**
	 * Sanitize result for LLM consumption.
	 *
	 * @param mixed $result The result to sanitize.
	 * @return mixed Sanitized result.
	 */
	public function sanitize_for_llm( $result ) {
		// Delegate to the original tool.
		return $this->original_tool->sanitize_for_llm( $result );
	}
}
