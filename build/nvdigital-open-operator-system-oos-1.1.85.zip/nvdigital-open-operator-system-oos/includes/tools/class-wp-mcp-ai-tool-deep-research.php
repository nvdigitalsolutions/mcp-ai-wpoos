<?php
/**
 * Tool that performs comprehensive deep research on any topic using multi-step AI analysis.
 *
 * This tool is provider-agnostic and works with OpenAI, Gemini, Anthropic, Ollama, and all
 * - All supported AI providers (including DeepSeek). It combines web search with iterative AI analysis to produce
 * comprehensive research reports.
 *
 * Recommended Models for Deep Research (February 2026):
 * - OpenAI: gpt-4o (multimodal, fast, cost-effective) or gpt-4.5/o3 (advanced reasoning)
 * - Gemini: gemini-3.1-pro-preview (flagship, 1M token context, 64K output, agentic capabilities)
 * - Anthropic: claude-opus-4.5 (highest intelligence, 200K context, persistent memory)
 * - Cloudflare: @cf/meta/llama-4-scout-17b-instruct or @cf/deepseek/deepseek-v3.2-thinking
 * - HuggingFace: meta-llama/Llama-3.3-70B-Instruct or deepseek-ai/DeepSeek-V3.2
 * - Ollama: llama3.3 or deepseek-r1 (privacy-focused local research)
 * - DeepSeek: deepseek-flash (V4.1 Flash — thinking + non-thinking, native vision)
 * - OpenRouter: openrouter/auto (access to 200+ models) or any specific model
 * - NVIDIA NIM: meta/llama-3.1-8b-instruct (fast inference)
 * - LM Studio: local models (privacy-focused, no API key needed)
 * - DigitalOcean: llama3.3-70b-instruct (cloud-hosted open models)
 * - Kimi: kimi-k3 (2.8T MoE, 1M context, Moonshot AI)
 * - Baseten: deepseek-ai/DeepSeek-V3 (serverless inference)
 * - Z.AI: GLM models (Chinese/English bilingual)
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Cache_Helper' ) ) {
	require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-cache-helper.php';
}

/**
 * Deep Research Tool
 *
 * Performs comprehensive research by:
 * 1. Using web search to gather relevant information
 * 2. Analyzing and synthesizing findings with AI
 * 3. Generating a detailed research report
 *
 * Works with any configured AI provider (OpenAI, Gemini, Anthropic, Ollama, etc.)
 */
class WP_MCP_AI_Tool_Deep_Research implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * Maximum number of search queries to perform.
	 *
	 * @var int
	 */
	const MAX_SEARCH_QUERIES = 3;

	/**
	 * Maximum results per search query.
	 *
	 * @var int
	 */
	const MAX_RESULTS_PER_QUERY = 5;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'deep_research';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Deep Research', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( '(Pro) Performs comprehensive deep research on any topic using multi-step web search and AI analysis. Works with all supported AI providers (OpenAI, Gemini, Anthropic, Cloudflare, HuggingFace, Ollama). Generates detailed research reports with findings and citations. Configure a dedicated research model in Settings → NV oOS → deep_research_model.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Producing a cited multi-source research report on a topic through iterative web search and AI analysis.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'For a quick single search use web_search; for site-specific knowledge use semantic_content_search.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'web_search', 'semantic_content_search', 'store_agent_context' ),
			'notes'           => __( 'Depth is basic, standard, or comprehensive; run_mode=background uses cron and results are cached for one hour.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'topic'                => array(
					'type'        => 'string',
					'description' => __( 'The research topic or question to investigate.', 'nvdigital-open-operator-system-oos' ),
				),
				'depth'                => array(
					'type'        => 'string',
					'description' => __( 'Research depth level.', 'nvdigital-open-operator-system-oos' ),
					'enum'        => array( 'basic', 'standard', 'comprehensive' ),
					'default'     => 'standard',
				),
				'focus_areas'          => array(
					'type'        => 'array',
					'description' => __( 'Optional specific aspects to focus on (e.g., "technical", "historical", "economic").', 'nvdigital-open-operator-system-oos' ),
					'items'       => array(
						'type' => 'string',
					),
				),
				'include_sources'      => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to include source citations in the research report.', 'nvdigital-open-operator-system-oos' ),
					'default'     => true,
				),
				'run_mode'             => array(
					'type'        => 'string',
					'description' => __( 'Execution mode: "immediate" runs synchronously, "background" schedules via WordPress cron for long-running research.', 'nvdigital-open-operator-system-oos' ),
					'enum'        => array( 'immediate', 'background' ),
					'default'     => 'immediate',
				),
				'include_site_content' => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to search local WordPress content and the assistant\'s configured Vector Store as additional research sources. Combines site knowledge with web search results.', 'nvdigital-open-operator-system-oos' ),
					'default'     => true,
				),
				'memory_agent_id'      => array(
					'type'        => array( 'integer', 'string' ),
					'description' => __( 'Agent or assistant ID used to recall prior research from agent memory before starting. When provided, relevant prior findings are included in the analysis context to avoid duplicate research.', 'nvdigital-open-operator-system-oos' ),
				),
				'store_to_memory'      => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to automatically store the completed research report in agent memory so it can be recalled in future sessions. Requires memory_agent_id.', 'nvdigital-open-operator-system-oos' ),
					'default'     => false,
				),
			),
			'required'             => array( 'topic' ),
			'additionalProperties' => false,
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'research_discovery',

			'pattern_compatibility' => array( 'orchestrator' ),

			'profession_tags'       => array( 'researcher', 'analyst', 'journalist' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                   // Tool is part of the Pro tier/addon.
			'requires-credentials',  // Requires AI provider API keys.
			'consumes-tokens',       // Uses AI model tokens.
			'external-api',          // Makes external API calls (web search + AI).
			'network-dependent',     // Requires internet connectivity.
			'may-timeout',           // Research can take significant time.
			'cacheable',             // Results can be cached.
			'read-only',             // Only retrieves and analyzes data.
			'non-deterministic',     // Results may vary over time.
			'background-capable',    // Supports background execution via cron.
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		// Check permissions - requires read capability.
		if ( ! $user_id || ! user_can( $user_id, 'read' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to perform deep research.', 'nvdigital-open-operator-system-oos' )
			);
		}

		// Validate multisite access.
		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Validate required arguments.
		if ( empty( $arguments['topic'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_missing_topic',
				__( 'A research topic is required.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$topic                = sanitize_text_field( $arguments['topic'] );
		$depth                = isset( $arguments['depth'] ) ? sanitize_key( $arguments['depth'] ) : 'standard';
		$focus_areas          = isset( $arguments['focus_areas'] ) && is_array( $arguments['focus_areas'] ) ? array_map( 'sanitize_text_field', $arguments['focus_areas'] ) : array();
		$include_sources      = isset( $arguments['include_sources'] ) ? (bool) $arguments['include_sources'] : true;
		$run_mode             = isset( $arguments['run_mode'] ) ? sanitize_key( $arguments['run_mode'] ) : 'immediate';
		$include_site_content = isset( $arguments['include_site_content'] ) ? (bool) $arguments['include_site_content'] : true;
		$store_to_memory      = isset( $arguments['store_to_memory'] ) ? (bool) $arguments['store_to_memory'] : false;
		$memory_agent_id      = '';
		if ( ! empty( $arguments['memory_agent_id'] ) ) {
			$memory_agent_id = is_numeric( $arguments['memory_agent_id'] )
				? absint( $arguments['memory_agent_id'] )
				: sanitize_text_field( $arguments['memory_agent_id'] );
		}

		// Validate depth.
		if ( ! in_array( $depth, array( 'basic', 'standard', 'comprehensive' ), true ) ) {
			$depth = 'standard';
		}

		// Validate run mode.
		if ( ! in_array( $run_mode, array( 'immediate', 'background' ), true ) ) {
			$run_mode = 'immediate';
		}

		// Handle background execution mode.
		if ( 'background' === $run_mode ) {
			return $this->schedule_background_research( $topic, $depth, $focus_areas, $include_sources, $user_id, $include_site_content, $memory_agent_id, $store_to_memory );
		}

		// Check cache first.
		if ( WP_MCP_AI_Cache_Helper::is_caching_enabled() ) {
			$cache_key     = $this->get_cache_key( $topic, $depth, $focus_areas );
			$cached_result = WP_MCP_AI_Cache_Helper::get( $cache_key );

			if ( false !== $cached_result && is_array( $cached_result ) ) {
				$cached_result['cached'] = true;
				return $cached_result;
			}
		}

		// Log research start.
		if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
			WP_MCP_AI_Logger::log_event(
				'deep_research_started',
				'Starting deep research',
				array(
					'topic'                => $topic,
					'depth'                => $depth,
					'focus_areas'          => $focus_areas,
					'user_id'              => $user_id,
					'include_site_content' => $include_site_content,
					'memory_agent_id'      => $memory_agent_id ? (string) $memory_agent_id : '',
				)
			);
		}

		// Step 0: Recall prior research from agent memory (if agent ID provided).
		$prior_memory = array();
		if ( $memory_agent_id ) {
			$prior_memory = $this->recall_prior_research( $topic, $memory_agent_id, $context );
		}

		// Step 1: Perform web searches to gather information.
		$search_results = $this->gather_information( $topic, $depth, $focus_areas, $context );

		if ( is_wp_error( $search_results ) ) {
			return $search_results;
		}

		// Step 1b: Optionally search local WordPress content and vector store.
		$site_content = array();
		if ( $include_site_content ) {
			$site_content = $this->gather_site_content( $topic, $focus_areas, $context );
		}

		// Step 2: Analyze findings with AI (now including site content and prior memory).
		$analysis_result = $this->analyze_findings( $topic, $search_results, $depth, $focus_areas, $include_sources, $context, $site_content, $prior_memory );

		if ( is_wp_error( $analysis_result ) ) {
			return $analysis_result;
		}

		// Step 3: Build final research report.
		$research_report = $this->build_research_report( $topic, $analysis_result, $search_results, $include_sources, $site_content );

		// Step 4: Store research in agent memory if requested.
		if ( $store_to_memory && $memory_agent_id ) {
			$this->persist_research( $topic, $depth, $research_report, $memory_agent_id, $context );
		}

		// Cache the results for 1 hour — but never cache an empty report:
		// caching a failed generation would poison the cache for the TTL window.
		if ( WP_MCP_AI_Cache_Helper::is_caching_enabled() ) {
			$report_word_count = isset( $research_report['word_count'] ) ? absint( $research_report['word_count'] ) : 0;

			if ( $report_word_count > 0 ) {
				$cache_key = $this->get_cache_key( $topic, $depth, $focus_areas );
				$cache_ttl = HOUR_IN_SECONDS;

				/**
				 * Filter the cache TTL for deep research results.
				 *
				 * @param int    $cache_ttl  Cache time-to-live in seconds (default: 3600).
				 * @param string $topic      The research topic.
				 * @param string $depth      Research depth level.
				 * @param array  $focus_areas Focus areas.
				 */
				$cache_ttl = apply_filters( 'wp_mcp_ai_deep_research_cache_ttl', $cache_ttl, $topic, $depth, $focus_areas );

				WP_MCP_AI_Cache_Helper::set( $cache_key, $research_report, $cache_ttl );
			} elseif ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event(
					'deep_research_cache_skipped',
					'Deep research report was not cached because it is empty.',
					array(
						'topic' => $topic,
						'depth' => $depth,
					)
				);
			}
		}

		// Log success.
		if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
			WP_MCP_AI_Logger::log_event(
				'deep_research_completed',
				'Deep research completed successfully',
				array(
					'topic'                => $topic,
					'depth'                => $depth,
					'sources_used'         => count( $research_report['sources'] ?? array() ),
					'word_count'           => str_word_count( $research_report['report'] ?? '' ),
					'site_content_matches' => count( $site_content ),
					'prior_memory_items'   => count( $prior_memory ),
					'stored_to_memory'     => $store_to_memory && $memory_agent_id,
				)
			);
		}

		return $research_report;
	}

	/**
	 * Gather information through web searches.
	 *
	 * @param string $topic       Research topic.
	 * @param string $depth       Research depth.
	 * @param array  $focus_areas Focus areas.
	 * @param array  $context     Execution context.
	 * @return array|WP_Error Search results or error.
	 */
	protected function gather_information( $topic, $depth, $focus_areas, $context ) {
		// Check if web search tool is available.
		$registry        = WP_MCP_AI_Tool_Registry::get_instance();
		$web_search_tool = $registry->get_tool( 'web_search' );

		if ( ! $web_search_tool ) {
			return new WP_Error(
				'wp_mcp_ai_web_search_unavailable',
				__( 'Web search tool is not available. Deep research requires web search capability.', 'nvdigital-open-operator-system-oos' )
			);
		}

		// Generate search queries based on depth and focus areas.
		$search_queries = $this->generate_search_queries( $topic, $depth, $focus_areas );

		$all_results = array();
		$all_sources = array();

		foreach ( $search_queries as $query ) {
			// Execute web search.
			$search_result = $web_search_tool->execute(
				array(
					'query'       => $query,
					'max_results' => self::MAX_RESULTS_PER_QUERY,
				),
				$context
			);

			if ( is_wp_error( $search_result ) ) {
				// Log the error but continue with other searches.
				if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
					WP_MCP_AI_Logger::log_error(
						'Deep research web search failed: ' . $search_result->get_error_message(),
						array(
							'query' => $query,
							'topic' => $topic,
						)
					);
				}
				continue;
			}

			// Collect results.
			if ( ! empty( $search_result['results'] ) && is_array( $search_result['results'] ) ) {
				foreach ( $search_result['results'] as $result ) {
					$all_results[] = $result;
					if ( ! empty( $result['url'] ) ) {
						$all_sources[] = array(
							'url'     => $result['url'],
							'title'   => isset( $result['title'] ) ? $result['title'] : '',
							'snippet' => isset( $result['snippet'] ) ? $result['snippet'] : '',
						);
					}
				}
			}
		}

		if ( empty( $all_results ) ) {
			return new WP_Error(
				'wp_mcp_ai_no_search_results',
				__( 'No web search results found for the research topic.', 'nvdigital-open-operator-system-oos' )
			);
		}

		// Deduplicate sources by URL.
		$all_sources = $this->deduplicate_sources( $all_sources );

		return array(
			'results' => $all_results,
			'sources' => $all_sources,
			'queries' => $search_queries,
		);
	}

	/**
	 * Generate search queries based on topic and parameters.
	 *
	 * @param string $topic       Research topic.
	 * @param string $depth       Research depth.
	 * @param array  $focus_areas Focus areas.
	 * @return array Search queries.
	 */
	protected function generate_search_queries( $topic, $depth, $focus_areas ) {
		$queries = array();

		// Main query.
		$queries[] = $topic;

		// Determine number of additional queries based on depth.
		$num_queries = 'basic' === $depth ? 1 : ( 'comprehensive' === $depth ? 3 : 2 );

		// Add focus area queries.
		if ( ! empty( $focus_areas ) ) {
			foreach ( $focus_areas as $area ) {
				if ( count( $queries ) >= $num_queries ) {
					break;
				}
				$queries[] = $topic . ' ' . $area;
			}
		}

		// Add depth-specific queries.
		if ( count( $queries ) < $num_queries ) {
			if ( 'comprehensive' === $depth ) {
				$queries[] = $topic . ' research latest developments';
			} elseif ( 'standard' === $depth ) {
				$queries[] = $topic . ' overview';
			}
		}

		return array_slice( $queries, 0, min( self::MAX_SEARCH_QUERIES, $num_queries ) );
	}

	/**
	 * Analyze findings using AI.
	 *
	 * @param string $topic          Research topic.
	 * @param array  $search_results Search results.
	 * @param string $depth          Research depth.
	 * @param array  $focus_areas    Focus areas.
	 * @param bool   $include_sources Whether to include sources.
	 * @param array  $context        Execution context.
	 * @param array  $site_content   Local site/vector-store content matches.
	 * @param array  $prior_memory   Prior research recalled from agent memory.
	 * @return array|WP_Error Analysis result or error.
	 */
	protected function analyze_findings( $topic, $search_results, $depth, $focus_areas, $include_sources, $context, $site_content = array(), $prior_memory = array() ) {
		/**
		 * Filter the maximum number of provider attempts for report generation.
		 *
		 * Best practice: reject output after a small number of failures instead
		 * of cascading retries. Each attempt walks the configured provider chain
		 * (the failed provider is excluded for the next attempt).
		 *
		 * @since 1.2.0
		 *
		 * @param int $max_attempts Default 2.
		 */
		$max_attempts = (int) apply_filters( 'wp_mcp_ai_deep_research_max_attempts', 2 );
		$max_attempts = max( 1, $max_attempts );

		$excluded_providers  = array();
		$last_error          = null;
		$retry_larger_budget = false;

		for ( $attempt = 0; $attempt < $max_attempts; $attempt++ ) {
			// Get AI client and model, skipping providers that already failed.
			$ai_setup = $this->get_ai_setup( $excluded_providers );

			if ( is_wp_error( $ai_setup ) ) {
				// If at least one provider already failed, the chain is exhausted:
				// surface the exhausted error with the salvageable sources below.
				if ( $last_error instanceof WP_Error ) {
					break;
				}

				// No provider was configured at all.
				return $ai_setup;
			}

			$client   = $ai_setup['client'];
			$provider = $ai_setup['provider'];
			$model    = $ai_setup['model'];

			// Build analysis prompt.
			$prompt = $this->build_analysis_prompt( $topic, $search_results, $depth, $focus_areas, $include_sources, $site_content, $prior_memory );

			// Build messages array.
			$messages = array(
				array(
					'role'    => 'system',
					'content' => __( 'You are an expert research analyst. Synthesize information from multiple sources into comprehensive, well-organized research reports. Always cite your sources and maintain objectivity.', 'nvdigital-open-operator-system-oos' ),
				),
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			);

			// When retrying after finish_reason=length truncation, double the
			// token budget so the model can complete the report.
			$max_tokens = $this->get_max_tokens_for_depth( $depth );
			if ( $retry_larger_budget ) {
				$max_tokens *= 2;
			}

			// Call AI.
			$result = $client->create_chat_completion(
				$messages,
				array(
					'model'       => $model,
					'temperature' => 0.3, // Low temperature for factual research.
					'max_tokens'  => $max_tokens,
				)
			);

			if ( is_wp_error( $result ) ) {
				if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
					WP_MCP_AI_Logger::log_error(
						'Deep research AI analysis failed: ' . $result->get_error_message(),
						array(
							'topic'    => $topic,
							'provider' => $provider,
							'model'    => $model,
							'attempt'  => $attempt + 1,
						)
					);
				}

				$last_error           = $result;
				$excluded_providers[] = $provider;
				continue;
			}

			// Extract content. An empty string passes isset(), so validate
			// non-empty explicitly (reasoning models can return CoT-only output).
			if ( ! isset( $result['choices'][0]['message']['content'] ) ) {
				$last_error           = new WP_Error(
					'wp_mcp_ai_invalid_response',
					__( 'Invalid response from AI provider.', 'nvdigital-open-operator-system-oos' )
				);
				$excluded_providers[] = $provider;
				continue;
			}

			$content = $this->extract_text_content( isset( $result['choices'][0]['message']['content'] ) ? $result['choices'][0]['message']['content'] : '' );

			// Clients differ on where finish_reason lives: DeepSeek normalises it
			// to the top level, OpenAI keeps it inside choices[0].
			$finish_reason = '';
			if ( isset( $result['finish_reason'] ) ) {
				$finish_reason = sanitize_key( (string) $result['finish_reason'] );
			} elseif ( isset( $result['choices'][0]['finish_reason'] ) ) {
				$finish_reason = sanitize_key( (string) $result['choices'][0]['finish_reason'] );
			}

			// Reasoning fallback: DeepSeek-style reasoning models may return the
			// chain of thought in reasoning_content with an empty final content.
			// Use the reasoning as the report when it is all we have.
			if ( '' === $content && ! empty( $result['reasoning_content'] ) && is_string( $result['reasoning_content'] ) ) {
				$content = trim( $result['reasoning_content'] );

				if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
					WP_MCP_AI_Logger::log_event(
						'deep_research_reasoning_fallback',
						'Deep research used reasoning_content because the completion content was empty.',
						array(
							'topic'    => $topic,
							'provider' => $provider,
							'model'    => $model,
						)
					);
				}

				return array(
					'content'                 => $content,
					'provider'                => $provider,
					'model'                   => $model,
					'used_reasoning_fallback' => true,
					'attempts'                => $attempt + 1,
				);
			}

			// Truncation: finish_reason=length means the report was cut off.
			// Retry once with a larger budget before falling back to another provider.
			if ( 'length' === $finish_reason ) {
				if ( ! $retry_larger_budget ) {
					$retry_larger_budget = true;
					// Keep the same provider for the larger-budget retry.
					continue;
				}

				if ( '' !== $content ) {
					// Even after the larger budget the provider truncated: return
					// what we have with an explicit flag instead of a silent cut.
					return array(
						'content'   => $content,
						'provider'  => $provider,
						'model'     => $model,
						'truncated' => true,
						'attempts'  => $attempt + 1,
					);
				}

				$last_error           = new WP_Error(
					'wp_mcp_ai_report_truncated',
					__( 'The AI provider truncated the research report before producing any content. Try a lower research depth or a model with a larger output limit.', 'nvdigital-open-operator-system-oos' )
				);
				$excluded_providers[] = $provider;
				continue;
			}

			// Empty completion without reasoning: treat as a transient failure.
			if ( '' === $content ) {
				$last_error = new WP_Error(
					'wp_mcp_ai_empty_completion',
					sprintf(
						/* translators: %s: provider name */
						__( 'The AI provider (%s) returned an empty completion for the research report.', 'nvdigital-open-operator-system-oos' ),
						$provider
					)
				);
				$excluded_providers[] = $provider;
				continue;
			}

			// Success.
			return array(
				'content'  => $content,
				'provider' => $provider,
				'model'    => $model,
				'attempts' => $attempt + 1,
			);
		}

		// All attempts exhausted: return an actionable error that still carries
		// the gathered sources so callers can salvage the material.
		$error_message = $last_error instanceof WP_Error
			? $last_error->get_error_message()
			: __( 'The AI analysis failed after multiple attempts.', 'nvdigital-open-operator-system-oos' );

		$error_data = array(
			'status' => 502,
		);

		if ( ! empty( $search_results['sources'] ) ) {
			$error_data['sources'] = $search_results['sources'];
		}
		if ( ! empty( $search_results['queries'] ) ) {
			$error_data['queries_used'] = $search_results['queries'];
		}
		$error_data['site_content_count']  = count( $site_content );
		$error_data['attempted_providers'] = array_values( array_unique( $excluded_providers ) );

		return new WP_Error( 'wp_mcp_ai_analysis_exhausted', $error_message, $error_data );
	}

	/**
	 * Extract plain text from a completion content value.
	 *
	 * Provider clients may return `content` as a plain string or as an array
	 * of typed segments (`array( array( 'type' => 'text', 'text' => '...' ) )`).
	 * Normalise both shapes to a trimmed string.
	 *
	 * @param mixed $content Raw content value from a completion message.
	 * @return string Trimmed plain-text content (empty when unparseable).
	 */
	protected function extract_text_content( $content ) {
		if ( is_string( $content ) ) {
			return trim( $content );
		}

		if ( is_array( $content ) ) {
			$text = '';
			foreach ( $content as $segment ) {
				if ( is_string( $segment ) ) {
					$text .= $segment;
				} elseif ( is_array( $segment ) && isset( $segment['text'] ) && is_string( $segment['text'] ) ) {
					$text .= $segment['text'];
				}
			}
			return trim( $text );
		}

		return '';
	}

	/**
	 * Get AI client, provider, and model for research.
	 *
	 * Checks for a dedicated deep research model setting first, then falls back to
	 * provider-specific defaults. This allows users to specify a particular model
	 * optimized for research tasks (e.g., a model with larger context window or
	 * better reasoning capabilities).
	 *
	 * @param array $exclude_providers Optional list of provider ids to skip
	 *                                 (used for retry/fallback walks).
	 * @return array|WP_Error Setup information or error.
	 */
	protected function get_ai_setup( $exclude_providers = array() ) {
		// Use the merged settings (credentials + main) so API keys stored in
		// the separate non-autoload wp_mcp_ai_credentials option are visible.
		$settings = class_exists( 'WP_MCP_AI_Admin_Settings_Base' )
			? WP_MCP_AI_Admin_Settings_Base::get_settings()
			: get_option( 'wp_mcp_ai_settings', array() );

		$exclude_providers = is_array( $exclude_providers ) ? array_map( 'sanitize_key', $exclude_providers ) : array();

		/**
		 * Filter the list of providers skipped during deep-research fallbacks.
		 *
		 * @since 1.2.0
		 *
		 * @param array $exclude_providers Provider ids currently excluded.
		 */
		$exclude_providers = (array) apply_filters( 'wp_mcp_ai_deep_research_excluded_providers', $exclude_providers );

		// Check if there's a dedicated deep research model configured.
		if ( ! empty( $settings['deep_research_model'] ) ) {
			$research_model = sanitize_text_field( $settings['deep_research_model'] );

			// Parse provider from model string (format: "provider:model" or just "model").
			$parts = explode( ':', $research_model, 2 );
			if ( count( $parts ) === 2 ) {
				$provider = $parts[0];
				$model    = $parts[1];
			} else {
				// If no provider prefix, try to infer from configured providers.
				$model    = $research_model;
				$provider = $this->infer_provider_for_model( $model, $settings );
			}

			// Get client for specified provider (unless excluded by a retry walk).
			if ( $provider && ! in_array( $provider, $exclude_providers, true ) ) {
				$client = $this->get_client_for_provider( $provider, $settings );
				if ( ! is_wp_error( $client ) ) {
					return array(
						'client'   => $client,
						'provider' => $provider,
						'model'    => $model,
					);
				}
			}
		}

		// Fall back to trying providers in order of preference: OpenAI > Gemini > Anthropic > Cloudflare > HuggingFace > Ollama > DeepSeek > OpenRouter > NVIDIA > LM Studio > DigitalOcean > Kimi > Baseten > ZAI.
		// Providers in the exclude list are skipped so retry walks advance down the chain.
		if ( ! in_array( 'openai', $exclude_providers, true ) && ! empty( $settings['openai_api_key'] ) && class_exists( 'WP_MCP_AI_OpenAI_Client' ) ) {
			$client = new WP_MCP_AI_OpenAI_Client();
			// Prefer gpt-4o for research (multimodal, fast, cost-effective) or fall back to configured default.
			$model = ! empty( $settings['openai_default_model'] ) ? $settings['openai_default_model'] : 'gpt-4.1';
			return array(
				'client'   => $client,
				'provider' => 'openai',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'gemini', $exclude_providers, true ) && ! empty( $settings['gemini_api_key'] ) && class_exists( 'WP_MCP_AI_Gemini_Client' ) ) {
			$client = new WP_MCP_AI_Gemini_Client();
			// Prefer gemini-3.1-pro-preview for deep research (1M context, 64K output, agentic capabilities) or fall back to configured default.
			$model = ! empty( $settings['gemini_default_model'] ) ? $settings['gemini_default_model'] : 'gemini-3.1-pro-preview';
			return array(
				'client'   => $client,
				'provider' => 'gemini',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'anthropic', $exclude_providers, true ) && ! empty( $settings['anthropic_api_key'] ) && class_exists( 'WP_MCP_AI_Anthropic_Client' ) ) {
			$client = new WP_MCP_AI_Anthropic_Client();
			// Prefer claude-opus-4.5 for comprehensive research (highest intelligence, 200K context, persistent memory).
			$model = 'claude-opus-4.5';
			return array(
				'client'   => $client,
				'provider' => 'anthropic',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'cloudflare', $exclude_providers, true ) && ! empty( $settings['cloudflare_api_token'] ) && ! empty( $settings['cloudflare_account_id'] ) && class_exists( 'WP_MCP_AI_Cloudflare_Client' ) ) {
			$client = new WP_MCP_AI_Cloudflare_Client();
			// Prefer Llama 4 or DeepSeek for research, fall back to configured default.
			$default_model = ! empty( $settings['cloudflare_model'] ) ? $settings['cloudflare_model'] : '@cf/meta/llama-4-scout-17b-instruct';
			return array(
				'client'   => $client,
				'provider' => 'cloudflare',
				'model'    => $default_model,
			);
		}

		if ( ! in_array( 'huggingface', $exclude_providers, true ) && ! empty( $settings['huggingface_api_key'] ) && ! empty( $settings['huggingface_endpoint_url'] ) && class_exists( 'WP_MCP_AI_Huggingface_Client' ) ) {
			$client = new WP_MCP_AI_Huggingface_Client();
			// Prefer Llama 3.3 70B or DeepSeek V3.2 for research, fall back to configured default.
			$default_model = ! empty( $settings['huggingface_model'] ) ? $settings['huggingface_model'] : 'meta-llama/Llama-3.3-70B-Instruct';
			return array(
				'client'   => $client,
				'provider' => 'huggingface',
				'model'    => $default_model,
			);
		}

		if ( ! in_array( 'ollama', $exclude_providers, true ) && ! empty( $settings['ollama_endpoint_url'] ) && class_exists( 'WP_MCP_AI_Ollama_Client' ) ) {
			$client = new WP_MCP_AI_Ollama_Client();
			// Prefer llama3.3 or deepseek-r1 for local research, fall back to configured default.
			$default_model = ! empty( $settings['ollama_model'] ) ? $settings['ollama_model'] : 'llama3.3';
			return array(
				'client'   => $client,
				'provider' => 'ollama',
				'model'    => $default_model,
			);
		}

		if ( ! in_array( 'deepseek', $exclude_providers, true ) && ! empty( $settings['deepseek_api_key'] ) && class_exists( 'WP_MCP_AI_DeepSeek_Client' ) ) {
			$client = new WP_MCP_AI_DeepSeek_Client();
			// Prefer deepseek-flash (V4.1 Flash, thinking mode) or fall back to configured default.
			$model = ! empty( $settings['deepseek_model'] ) ? $settings['deepseek_model'] : 'deepseek-flash';
			return array(
				'client'   => $client,
				'provider' => 'deepseek',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'openrouter', $exclude_providers, true ) && ! empty( $settings['openrouter_api_key'] ) && class_exists( 'WP_MCP_AI_OpenRouter_Client' ) ) {
			$client = new WP_MCP_AI_OpenRouter_Client();
			// OpenRouter auto-routes to best model; user can override with openrouter_model setting.
			$model = ! empty( $settings['openrouter_model'] ) ? $settings['openrouter_model'] : 'openrouter/auto';
			return array(
				'client'   => $client,
				'provider' => 'openrouter',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'nvidia', $exclude_providers, true ) && ! empty( $settings['nvidia_api_key'] ) && class_exists( 'WP_MCP_AI_Nvidia_Client' ) ) {
			$client = new WP_MCP_AI_Nvidia_Client();
			$model  = ! empty( $settings['nvidia_model'] ) ? $settings['nvidia_model'] : 'meta/llama-3.1-8b-instruct';
			return array(
				'client'   => $client,
				'provider' => 'nvidia',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'lm_studio', $exclude_providers, true ) && ! empty( $settings['lm_studio_endpoint_url'] ) && class_exists( 'WP_MCP_AI_LM_Studio_Client' ) ) {
			$client = new WP_MCP_AI_LM_Studio_Client();
			$model  = ! empty( $settings['lm_studio_model'] ) ? $settings['lm_studio_model'] : '';
			return array(
				'client'   => $client,
				'provider' => 'lm_studio',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'digitalocean', $exclude_providers, true ) && ! empty( $settings['digitalocean_api_key'] ) && class_exists( 'WP_MCP_AI_DigitalOcean_Client' ) ) {
			$client = new WP_MCP_AI_DigitalOcean_Client();
			$model  = ! empty( $settings['digitalocean_model'] ) ? $settings['digitalocean_model'] : 'llama3.3-70b-instruct';
			return array(
				'client'   => $client,
				'provider' => 'digitalocean',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'kimi', $exclude_providers, true ) && ! empty( $settings['kimi_api_key'] ) && class_exists( 'WP_MCP_AI_Kimi_Client' ) ) {
			$client = new WP_MCP_AI_Kimi_Client();
			$model  = ! empty( $settings['kimi_model'] ) ? $settings['kimi_model'] : 'kimi-k3';
			return array(
				'client'   => $client,
				'provider' => 'kimi',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'baseten', $exclude_providers, true ) && ! empty( $settings['baseten_api_key'] ) && class_exists( 'WP_MCP_AI_Baseten_Client' ) ) {
			$client = new WP_MCP_AI_Baseten_Client();
			$model  = ! empty( $settings['baseten_model'] ) ? $settings['baseten_model'] : 'deepseek-ai/DeepSeek-V3';
			return array(
				'client'   => $client,
				'provider' => 'baseten',
				'model'    => $model,
			);
		}

		if ( ! in_array( 'zai', $exclude_providers, true ) && ! empty( $settings['zai_api_key'] ) && class_exists( 'WP_MCP_AI_ZAI_Client' ) ) {
			$client = new WP_MCP_AI_ZAI_Client();
			$model  = ! empty( $settings['zai_model'] ) ? $settings['zai_model'] : 'glm-4';
			return array(
				'client'   => $client,
				'provider' => 'zai',
				'model'    => $model,
			);
		}

		return new WP_Error(
			'wp_mcp_ai_no_provider',
			__( 'No AI provider configured. Please configure OpenAI, Gemini, Anthropic, Cloudflare, HuggingFace, Ollama, DeepSeek, OpenRouter, NVIDIA, LM Studio, DigitalOcean, Kimi, Baseten, or Z.AI in plugin settings.', 'nvdigital-open-operator-system-oos' )
		);
	}

	/**
	 * Infer provider from model name when no provider prefix is given.
	 *
	 * @param string $model    Model name.
	 * @param array  $settings Plugin settings.
	 * @return string|null Provider name or null if cannot be inferred.
	 */
	protected function infer_provider_for_model( $model, $settings ) {
		// Check common model name patterns.
		if ( strpos( $model, 'gpt-' ) === 0 || strpos( $model, 'o1-' ) === 0 ) {
			return 'openai';
		}
		if ( strpos( $model, 'gemini-' ) === 0 ) {
			return 'gemini';
		}
		if ( strpos( $model, 'claude-' ) === 0 ) {
			return 'anthropic';
		}
		if ( strpos( $model, '@cf/' ) === 0 ) {
			return 'cloudflare';
		}
		if ( strpos( $model, 'deepseek' ) !== false ) {
			return 'deepseek';
		}
		if ( strpos( $model, 'llama' ) !== false || strpos( $model, 'mistral' ) !== false ) {
			// Could be Ollama or HuggingFace - check which is configured.
			if ( ! empty( $settings['ollama_endpoint_url'] ) ) {
				return 'ollama';
			}
			if ( ! empty( $settings['huggingface_api_key'] ) ) {
				return 'huggingface';
			}
		}

		if ( strpos( $model, 'openrouter/' ) === 0 ) {
			return 'openrouter';
		}
		if ( strpos( $model, 'kimi-' ) === 0 || strpos( $model, 'moonshot' ) !== false ) {
			return 'kimi';
		}

		return null;
	}

	/**
	 * Get AI client instance for a specific provider.
	 *
	 * @param string $provider Provider name.
	 * @param array  $settings Plugin settings.
	 * @return object|WP_Error Client instance or error.
	 */
	protected function get_client_for_provider( $provider, $settings ) {
		switch ( $provider ) {
			case 'openai':
				if ( ! empty( $settings['openai_api_key'] ) && class_exists( 'WP_MCP_AI_OpenAI_Client' ) ) {
					return new WP_MCP_AI_OpenAI_Client();
				}
				break;

			case 'gemini':
				if ( ! empty( $settings['gemini_api_key'] ) && class_exists( 'WP_MCP_AI_Gemini_Client' ) ) {
					return new WP_MCP_AI_Gemini_Client();
				}
				break;

			case 'anthropic':
				if ( ! empty( $settings['anthropic_api_key'] ) && class_exists( 'WP_MCP_AI_Anthropic_Client' ) ) {
					return new WP_MCP_AI_Anthropic_Client();
				}
				break;

			case 'cloudflare':
				if ( ! empty( $settings['cloudflare_api_token'] ) && ! empty( $settings['cloudflare_account_id'] ) && class_exists( 'WP_MCP_AI_Cloudflare_Client' ) ) {
					return new WP_MCP_AI_Cloudflare_Client();
				}
				break;

			case 'huggingface':
				if ( ! empty( $settings['huggingface_api_key'] ) && ! empty( $settings['huggingface_endpoint_url'] ) && class_exists( 'WP_MCP_AI_Huggingface_Client' ) ) {
					return new WP_MCP_AI_Huggingface_Client();
				}
				break;

			case 'ollama':
				if ( ! empty( $settings['ollama_endpoint_url'] ) && class_exists( 'WP_MCP_AI_Ollama_Client' ) ) {
					return new WP_MCP_AI_Ollama_Client();
				}
				break;

			case 'deepseek':
				if ( ! empty( $settings['deepseek_api_key'] ) && class_exists( 'WP_MCP_AI_DeepSeek_Client' ) ) {
					return new WP_MCP_AI_DeepSeek_Client();
				}
				break;

			case 'openrouter':
				if ( ! empty( $settings['openrouter_api_key'] ) && class_exists( 'WP_MCP_AI_OpenRouter_Client' ) ) {
					return new WP_MCP_AI_OpenRouter_Client();
				}
				break;

			case 'nvidia':
				if ( ! empty( $settings['nvidia_api_key'] ) && class_exists( 'WP_MCP_AI_Nvidia_Client' ) ) {
					return new WP_MCP_AI_Nvidia_Client();
				}
				break;

			case 'lm_studio':
				if ( ! empty( $settings['lm_studio_endpoint_url'] ) && class_exists( 'WP_MCP_AI_LM_Studio_Client' ) ) {
					return new WP_MCP_AI_LM_Studio_Client();
				}
				break;

			case 'digitalocean':
				if ( ! empty( $settings['digitalocean_api_key'] ) && class_exists( 'WP_MCP_AI_DigitalOcean_Client' ) ) {
					return new WP_MCP_AI_DigitalOcean_Client();
				}
				break;

			case 'kimi':
				if ( ! empty( $settings['kimi_api_key'] ) && class_exists( 'WP_MCP_AI_Kimi_Client' ) ) {
					return new WP_MCP_AI_Kimi_Client();
				}
				break;

			case 'baseten':
				if ( ! empty( $settings['baseten_api_key'] ) && class_exists( 'WP_MCP_AI_Baseten_Client' ) ) {
					return new WP_MCP_AI_Baseten_Client();
				}
				break;

			case 'zai':
				if ( ! empty( $settings['zai_api_key'] ) && class_exists( 'WP_MCP_AI_ZAI_Client' ) ) {
					return new WP_MCP_AI_ZAI_Client();
				}
				break;
		}

		return new WP_Error(
			'wp_mcp_ai_provider_unavailable',
			sprintf(
				/* translators: %s: provider name */
				__( 'Provider %s is not configured or unavailable.', 'nvdigital-open-operator-system-oos' ),
				$provider
			)
		);
	}

	/**
	 * Build AI analysis prompt.
	 *
	 * @param string $topic          Research topic.
	 * @param array  $search_results Search results.
	 * @param string $depth          Research depth.
	 * @param array  $focus_areas    Focus areas.
	 * @param bool   $include_sources Whether to include sources.
	 * @param array  $site_content   Local site/vector-store content matches.
	 * @param array  $prior_memory   Prior research recalled from agent memory.
	 * @return string Analysis prompt.
	 */
	protected function build_analysis_prompt( $topic, $search_results, $depth, $focus_areas, $include_sources, $site_content = array(), $prior_memory = array() ) {
		$prompt = sprintf(
			/* translators: %s: research topic */
			__( 'Research Topic: %s', 'nvdigital-open-operator-system-oos' ) . "\n\n",
			$topic
		);

		if ( ! empty( $focus_areas ) ) {
			$prompt .= __( 'Focus Areas: ', 'nvdigital-open-operator-system-oos' ) . implode( ', ', $focus_areas ) . "\n\n";
		}

		// Include recalled prior research at the top to guide synthesis.
		if ( ! empty( $prior_memory ) ) {
			$prompt .= __( 'Prior Research (from agent memory — use to avoid repetition and build on existing knowledge):', 'nvdigital-open-operator-system-oos' ) . "\n\n";
			foreach ( $prior_memory as $index => $memory_item ) {
				/* translators: %d: memory item number */
				$title   = isset( $memory_item['title'] ) ? $memory_item['title'] : sprintf( __( 'Prior finding %d', 'nvdigital-open-operator-system-oos' ), $index + 1 );
				$content = isset( $memory_item['content'] ) ? $memory_item['content'] : '';
				if ( empty( $content ) && isset( $memory_item['data']['content'] ) ) {
					$content = $memory_item['data']['content'];
				}
				if ( ! empty( $content ) ) {
					$prompt .= sprintf( '[Memory %d] %s: %s', $index + 1, $title, $content ) . "\n\n";
				}
			}
		}

		$prompt .= __( 'Information gathered from web searches:', 'nvdigital-open-operator-system-oos' ) . "\n\n";

		// Include search results.
		$source_index = 1;
		foreach ( $search_results['results'] as $result ) {
			if ( empty( $result['title'] ) && empty( $result['snippet'] ) ) {
				continue;
			}

			$prompt .= sprintf( '[%d] ', $source_index );
			if ( ! empty( $result['title'] ) ) {
				$prompt .= $result['title'] . "\n";
			}
			if ( ! empty( $result['snippet'] ) ) {
				$prompt .= $result['snippet'] . "\n";
			}
			if ( ! empty( $result['url'] ) && $include_sources ) {
				$prompt .= __( 'Source: ', 'nvdigital-open-operator-system-oos' ) . $result['url'] . "\n";
			}
			$prompt .= "\n";
			++$source_index;
		}

		// Include local site content from semantic search / vector store.
		if ( ! empty( $site_content ) ) {
			$prompt .= "\n" . __( 'Relevant content from this site\'s knowledge base:', 'nvdigital-open-operator-system-oos' ) . "\n\n";
			foreach ( $site_content as $index => $item ) {
				/* translators: %d: site content item number */
				$title   = isset( $item['title'] ) ? $item['title'] : sprintf( __( 'Site content %d', 'nvdigital-open-operator-system-oos' ), $index + 1 );
				$excerpt = isset( $item['excerpt'] ) ? $item['excerpt'] : ( isset( $item['snippet'] ) ? $item['snippet'] : '' );
				$url     = isset( $item['url'] ) ? $item['url'] : ( isset( $item['permalink'] ) ? $item['permalink'] : '' );

				$prompt .= sprintf( '[Site %d] %s', $index + 1, $title ) . "\n";
				if ( $excerpt ) {
					$prompt .= $excerpt . "\n";
				}
				if ( $url && $include_sources ) {
					$prompt .= __( 'Source: ', 'nvdigital-open-operator-system-oos' ) . $url . "\n";
				}
				$prompt .= "\n";
			}
		}

		$prompt .= __( 'Please analyze the above information and create a comprehensive research report with the following structure:', 'nvdigital-open-operator-system-oos' ) . "\n\n";

		if ( 'comprehensive' === $depth ) {
			$prompt .= __( '1. Executive Summary', 'nvdigital-open-operator-system-oos' ) . "\n";
			$prompt .= __( '2. Background and Context', 'nvdigital-open-operator-system-oos' ) . "\n";
			$prompt .= __( '3. Key Findings (organized by themes)', 'nvdigital-open-operator-system-oos' ) . "\n";
			$prompt .= __( '4. Analysis and Insights', 'nvdigital-open-operator-system-oos' ) . "\n";
			$prompt .= __( '5. Implications and Recommendations', 'nvdigital-open-operator-system-oos' ) . "\n";
			$prompt .= __( '6. Conclusion', 'nvdigital-open-operator-system-oos' ) . "\n";
		} elseif ( 'standard' === $depth ) {
			$prompt .= __( '1. Overview', 'nvdigital-open-operator-system-oos' ) . "\n";
			$prompt .= __( '2. Main Findings', 'nvdigital-open-operator-system-oos' ) . "\n";
			$prompt .= __( '3. Analysis', 'nvdigital-open-operator-system-oos' ) . "\n";
			$prompt .= __( '4. Conclusion', 'nvdigital-open-operator-system-oos' ) . "\n";
		} else {
			$prompt .= __( '1. Summary', 'nvdigital-open-operator-system-oos' ) . "\n";
			$prompt .= __( '2. Key Points', 'nvdigital-open-operator-system-oos' ) . "\n";
		}

		if ( $include_sources ) {
			$prompt .= "\n" . __( 'Important: Reference sources using [1], [2], etc. notation when making claims.', 'nvdigital-open-operator-system-oos' ) . "\n";
		}

		return $prompt;
	}

	/**
	 * Build final research report.
	 *
	 * @param string $topic          Research topic.
	 * @param array  $analysis       Analysis result.
	 * @param array  $search_results Search results.
	 * @param bool   $include_sources Whether to include sources.
	 * @param array  $site_content   Local site content matches used in research.
	 * @return array Research report.
	 */
	protected function build_research_report( $topic, $analysis, $search_results, $include_sources, $site_content = array() ) {
		$report = array(
			'topic'      => $topic,
			'report'     => $analysis['content'],
			'provider'   => $analysis['provider'],
			'model'      => $analysis['model'],
			'timestamp'  => time(),
			'cached'     => false,
			'word_count' => str_word_count( $analysis['content'] ),
		);

		// Surface generation metadata so callers can see fallback/retry state.
		if ( ! empty( $analysis['used_reasoning_fallback'] ) ) {
			$report['used_reasoning_fallback'] = true;
		}
		if ( ! empty( $analysis['truncated'] ) ) {
			$report['truncated'] = true;
		}
		if ( isset( $analysis['attempts'] ) ) {
			$report['attempts'] = absint( $analysis['attempts'] );
		}

		// Add sources if requested.
		if ( $include_sources && ! empty( $search_results['sources'] ) ) {
			$report['sources']      = $search_results['sources'];
			$report['source_count'] = count( $search_results['sources'] );
		} else {
			$report['sources']      = array();
			$report['source_count'] = 0;
		}

		// Add metadata.
		$report['queries_used']       = ! empty( $search_results['queries'] ) ? $search_results['queries'] : array();
		$report['site_content_count'] = count( $site_content );

		return $report;
	}

	/**
	 * Get maximum tokens for research depth.
	 *
	 * @param string $depth Research depth.
	 * @return int Maximum tokens.
	 */
	protected function get_max_tokens_for_depth( $depth ) {
		switch ( $depth ) {
			case 'comprehensive':
				return 4000;
			case 'standard':
				return 2000;
			case 'basic':
			default:
				return 1000;
		}
	}

	/**
	 * Generate cache key for research results.
	 *
	 * @param string $topic       Research topic.
	 * @param string $depth       Research depth.
	 * @param array  $focus_areas Focus areas.
	 * @return string Cache key.
	 */
	protected function get_cache_key( $topic, $depth, $focus_areas ) {
		$key_parts = array( $topic, $depth );
		if ( ! empty( $focus_areas ) ) {
			sort( $focus_areas );
			$key_parts[] = implode( ',', $focus_areas );
		}
		return 'deep_research_' . md5( implode( '|', $key_parts ) );
	}

	/**
	 * Search local WordPress content and the assistant's Vector Store for topic-relevant material.
	 *
	 * Uses the `semantic_content_search` tool (when available) to pull in site-specific knowledge
	 * alongside web search results. This improves research quality for topics that the site
	 * has existing authoritative content about (e.g. product info, documentation, policies).
	 *
	 * @param string $topic       Research topic.
	 * @param array  $focus_areas Focus areas.
	 * @param array  $context     Execution context (may carry assistant_config with vector_store_id).
	 * @return array Normalised site content items (each has 'title', 'excerpt'/'snippet', 'url').
	 */
	protected function gather_site_content( $topic, $focus_areas, $context ) {
		$registry         = WP_MCP_AI_Tool_Registry::get_instance();
		$site_search_tool = $registry->get_tool( 'semantic_content_search' );

		if ( ! $site_search_tool ) {
			return array();
		}

		// Build a combined query from topic and first focus area.
		$query = $topic;
		if ( ! empty( $focus_areas ) ) {
			$query .= ' ' . $focus_areas[0];
		}

		$result = $site_search_tool->execute(
			array(
				'query'           => $query,
				'limit'           => 5,
				'post_types'      => array( 'post', 'page' ),
				'vector_store_id' => isset( $context['assistant_config']['vector_store_id'] )
					? sanitize_text_field( $context['assistant_config']['vector_store_id'] )
					: '',
			),
			$context
		);

		if ( is_wp_error( $result ) || empty( $result['results'] ) || ! is_array( $result['results'] ) ) {
			return array();
		}

		// Normalise result shape.
		$items = array();
		foreach ( $result['results'] as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$items[] = array(
				'title'   => isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : '',
				'excerpt' => isset( $item['excerpt'] ) ? wp_strip_all_tags( $item['excerpt'] ) : ( isset( $item['snippet'] ) ? wp_strip_all_tags( $item['snippet'] ) : '' ),
				'url'     => isset( $item['permalink'] ) ? esc_url_raw( $item['permalink'] ) : ( isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '' ),
				'source'  => isset( $item['source'] ) ? $item['source'] : 'site',
			);
		}

		return $items;
	}

	/**
	 * Recall prior research from agent memory relevant to the current topic.
	 *
	 * Uses the `retrieve_agent_memory` tool to search stored contexts tagged
	 * as research findings. This allows the research tool to build on previous
	 * sessions rather than re-discovering the same information.
	 *
	 * @param string     $topic           Research topic.
	 * @param int|string $memory_agent_id Agent ID to retrieve memory for.
	 * @param array      $context         Execution context.
	 * @return array Array of prior memory context items (may be empty).
	 */
	protected function recall_prior_research( $topic, $memory_agent_id, $context ) {
		$registry    = WP_MCP_AI_Tool_Registry::get_instance();
		$memory_tool = $registry->get_tool( 'retrieve_agent_memory' );

		if ( ! $memory_tool ) {
			return array();
		}

		$result = $memory_tool->execute(
			array(
				'agent_id'             => $memory_agent_id,
				'query'                => $topic,
				'limit'                => 3,
				'include_vector_store' => false,
				'filters'              => array(
					'context_types' => array( 'result', 'insight', 'fact', 'learning' ),
				),
			),
			$context
		);

		if ( is_wp_error( $result ) || empty( $result['contexts'] ) || ! is_array( $result['contexts'] ) ) {
			return array();
		}

		return $result['contexts'];
	}

	/**
	 * Persist completed research report to agent memory for future recall.
	 *
	 * Stores the research report summary via `store_agent_context` so that
	 * subsequent research sessions on related topics can leverage this work
	 * without duplicating effort.
	 *
	 * @param string     $topic           Research topic.
	 * @param string     $depth           Research depth level.
	 * @param array      $research_report Completed research report.
	 * @param int|string $memory_agent_id Agent ID to store memory for.
	 * @param array      $context         Execution context.
	 * @return void
	 */
	protected function persist_research( $topic, $depth, $research_report, $memory_agent_id, $context ) {
		$registry   = WP_MCP_AI_Tool_Registry::get_instance();
		$store_tool = $registry->get_tool( 'store_agent_context' );

		if ( ! $store_tool ) {
			return;
		}

		// Truncate report to a manageable excerpt for memory storage.
		// 4 000 characters keeps the stored context within transient size limits
		// while still retaining the executive summary and key findings of most
		// research reports (which typically front-load the most important content).
		$report_text = isset( $research_report['report'] ) ? $research_report['report'] : '';
		if ( mb_strlen( $report_text ) > 4000 ) {
			$report_text = mb_substr( $report_text, 0, 4000 ) . '…';
		}

		$store_tool->execute(
			array(
				'agent_id'     => $memory_agent_id,
				'context_type' => 'result',
				'context_data' => array(
					'title'      => sprintf(
						/* translators: 1: research topic, 2: depth level */
						__( 'Deep Research: %1$s (%2$s)', 'nvdigital-open-operator-system-oos' ),
						$topic,
						$depth
					),
					'content'    => $report_text,
					'importance' => 'comprehensive' === $depth ? 'high' : 'medium',
					'tags'       => array( 'deep-research', sanitize_key( $depth ) ),
					'metadata'   => array(
						'topic'        => $topic,
						'depth'        => $depth,
						'word_count'   => isset( $research_report['word_count'] ) ? $research_report['word_count'] : 0,
						'source_count' => isset( $research_report['source_count'] ) ? $research_report['source_count'] : 0,
						'provider'     => isset( $research_report['provider'] ) ? $research_report['provider'] : '',
						'model'        => isset( $research_report['model'] ) ? $research_report['model'] : '',
					),
				),
				'ttl'          => WEEK_IN_SECONDS * 4, // Store for 4 weeks.
			),
			$context
		);
	}

	/**
	 * Deduplicate sources by URL.
	 *
	 * @param array $sources Array of sources.
	 * @return array Deduplicated sources.
	 */
	protected function deduplicate_sources( array $sources ) {
		$seen_urls = array();
		$unique    = array();

		foreach ( $sources as $source ) {
			if ( empty( $source['url'] ) ) {
				continue;
			}

			$normalized_url = untrailingslashit( $source['url'] );

			if ( in_array( $normalized_url, $seen_urls, true ) ) {
				continue;
			}

			$seen_urls[] = $normalized_url;
			$unique[]    = $source;
		}

		return $unique;
	}

	/**
	 * Schedule background research via WordPress cron.
	 *
	 * @param string     $topic                Research topic.
	 * @param string     $depth                Research depth.
	 * @param array      $focus_areas          Focus areas.
	 * @param bool       $include_sources      Whether to include sources.
	 * @param int        $user_id              User ID.
	 * @param bool       $include_site_content Whether to include local site content.
	 * @param int|string $memory_agent_id      Agent ID for memory recall/storage.
	 * @param bool       $store_to_memory      Whether to store results to memory.
	 * @return array Status information.
	 */
	protected function schedule_background_research( $topic, $depth, $focus_areas, $include_sources, $user_id, $include_site_content = true, $memory_agent_id = '', $store_to_memory = false ) {
		// Generate unique job ID.
		$job_id = 'deep_research_' . md5( $topic . microtime( true ) );

		// Schedule single event.
		$scheduled = wp_schedule_single_event(
			time() + 10, // Run in 10 seconds.
			'wp_mcp_ai_deep_research_background',
			array(
				'job_id'               => $job_id,
				'topic'                => $topic,
				'depth'                => $depth,
				'focus_areas'          => $focus_areas,
				'include_sources'      => $include_sources,
				'user_id'              => $user_id,
				'include_site_content' => $include_site_content,
				'memory_agent_id'      => $memory_agent_id,
				'store_to_memory'      => $store_to_memory,
			)
		);

		if ( false === $scheduled ) {
			return new WP_Error(
				'wp_mcp_ai_schedule_failed',
				__( 'Failed to schedule background research. WordPress cron may not be working.', 'nvdigital-open-operator-system-oos' )
			);
		}

		// Register in Cron Manager so the job is visible and monitorable.
		if ( class_exists( 'WP_MCP_AI_Cron_Manager' ) ) {
			WP_MCP_AI_Cron_Manager::record_job(
				'wp_mcp_ai_deep_research_background',
				array( $job_id ),
				'single',
				time() + 10,
				absint( $user_id )
			);
		}

		// Store job status.
		$job_status = array(
			'job_id'     => $job_id,
			'topic'      => $topic,
			'status'     => 'scheduled',
			'created_at' => time(),
			'user_id'    => $user_id,
		);

		set_transient( 'wp_mcp_ai_research_job_' . $job_id, $job_status, DAY_IN_SECONDS );

		return array(
			'job_id'  => $job_id,
			'status'  => 'scheduled',
			'message' => sprintf(
				/* translators: %s: job ID */
				__( 'Research scheduled in background mode. Job ID: %s. Check back later for results.', 'nvdigital-open-operator-system-oos' ),
				$job_id
			),
			'topic'   => $topic,
		);
	}

	/**
	 * Execute background research job.
	 * Called by WordPress cron.
	 *
	 * @param string     $job_id               Job ID.
	 * @param string     $topic                Research topic.
	 * @param string     $depth                Research depth.
	 * @param array      $focus_areas          Focus areas.
	 * @param bool       $include_sources      Whether to include sources.
	 * @param int        $user_id              User ID.
	 * @param bool       $include_site_content Whether to search local site content.
	 * @param int|string $memory_agent_id      Agent ID for memory recall/storage.
	 * @param bool       $store_to_memory      Whether to store results to memory.
	 */
	public static function execute_background_research( $job_id, $topic, $depth, $focus_areas, $include_sources, $user_id, $include_site_content = true, $memory_agent_id = '', $store_to_memory = false ) {
		// Update job status.
		$job_status = array(
			'job_id'     => $job_id,
			'topic'      => $topic,
			'status'     => 'running',
			'started_at' => time(),
			'user_id'    => $user_id,
		);
		set_transient( 'wp_mcp_ai_research_job_' . $job_id, $job_status, DAY_IN_SECONDS );

		// Create tool instance and execute research.
		$tool   = new self();
		$result = $tool->execute(
			array(
				'topic'                => $topic,
				'depth'                => $depth,
				'focus_areas'          => $focus_areas,
				'include_sources'      => $include_sources,
				'run_mode'             => 'immediate', // Prevent recursive scheduling.
				'include_site_content' => $include_site_content,
				'memory_agent_id'      => $memory_agent_id,
				'store_to_memory'      => $store_to_memory,
			),
			array(
				'user_id' => $user_id,
			)
		);

		// Update job with results.
		$job_status['status']       = is_wp_error( $result ) ? 'failed' : 'completed';
		$job_status['completed_at'] = time();

		if ( is_wp_error( $result ) ) {
			$job_status['error'] = $result->get_error_message();
		} else {
			$job_status['result'] = $result;
		}

		set_transient( 'wp_mcp_ai_research_job_' . $job_id, $job_status, DAY_IN_SECONDS );

		/**
		 * Fires when background research job completes.
		 *
		 * @param string           $job_id Job ID.
		 * @param array|WP_Error   $result Research result or error.
		 * @param array            $job_status Job status information.
		 */
		do_action( 'wp_mcp_ai_deep_research_background_completed', $job_id, $result, $job_status );
	}
}
