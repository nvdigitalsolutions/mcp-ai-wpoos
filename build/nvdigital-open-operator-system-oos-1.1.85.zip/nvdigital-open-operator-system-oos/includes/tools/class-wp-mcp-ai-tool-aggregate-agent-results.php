<?php
/**
 * Tool for aggregating agent results.
 *
 * Allows AI assistants to combine outputs from multiple agents using various strategies.
 * Part of DeepSeek V4-inspired multi-agent orchestration enhancements.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Aggregates results from multiple agents.
 *
 * This tool enables AI models to combine outputs from different specialist agents
 * using various aggregation strategies (consensus, weighted, hierarchical, etc.).
 * Useful for synthesizing multi-agent collaboration results.
 *
 * @since 1.1.0
 */
class WP_MCP_AI_Tool_Aggregate_Agent_Results implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'aggregate_agent_results';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Aggregate Agent Results', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Combines results from multiple agents using various aggregation strategies. Use this after receiving outputs from multiple specialized agents to synthesize a unified result.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Combining outputs from multiple specialized agents into one synthesized result after team execution.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Running the agents themselves; use create_agent_team or delegate_to_agent to produce the results this tool consumes.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'create_agent_team', 'delegate_to_agent', 'check_workflow_health' ),
			'notes'           => __( 'strategy enum: consensus, weighted, hierarchical, first, best. weighted needs weights; hierarchical takes priority_order roles.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'agent_results'  => array(
					'type'        => 'array',
					'description' => __( 'Array of results from different agents', 'nvdigital-open-operator-system-oos' ),
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'agent_id'   => array(
								'type'        => 'integer',
								'description' => __( 'ID of the agent that produced this result', 'nvdigital-open-operator-system-oos' ),
							),
							'agent_role' => array(
								'type'        => 'string',
								'description' => __( 'Role of the agent: planner, executor, critic', 'nvdigital-open-operator-system-oos' ),
							),
							'result'     => array(
								'description' => __( 'The actual result data from the agent', 'nvdigital-open-operator-system-oos' ),
							),
							'confidence' => array(
								'type'        => 'number',
								'description' => __( 'Confidence score (0.0-1.0)', 'nvdigital-open-operator-system-oos' ),
								'minimum'     => 0.0,
								'maximum'     => 1.0,
							),
							'metadata'   => array(
								'type'        => 'object',
								'description' => __( 'Additional metadata about the result', 'nvdigital-open-operator-system-oos' ),
							),
						),
						'required'   => array( 'agent_id', 'result' ),
					),
				),
				'strategy'       => array(
					'type'        => 'string',
					'description' => __( 'Aggregation strategy to use', 'nvdigital-open-operator-system-oos' ),
					'enum'        => array( 'consensus', 'weighted', 'hierarchical', 'first', 'best' ),
					'default'     => 'consensus',
				),
				'weights'        => array(
					'type'        => 'object',
					'description' => __( 'Weight for each agent (for weighted strategy). Keys are agent_ids, values are weights.', 'nvdigital-open-operator-system-oos' ),
				),
				'priority_order' => array(
					'type'        => 'array',
					'description' => __( 'Agent role priority order (for hierarchical strategy)', 'nvdigital-open-operator-system-oos' ),
					'items'       => array(
						'type' => 'string',
						'enum' => array( 'planner', 'executor', 'critic', 'specialist' ),
					),
				),
			),
			'required'             => array( 'agent_results' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array Tool results.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Validate required arguments.
		if ( empty( $arguments['agent_results'] ) || ! is_array( $arguments['agent_results'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'Agent results array is required.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$agent_results  = $arguments['agent_results'];
		$strategy       = isset( $arguments['strategy'] ) ? sanitize_key( $arguments['strategy'] ) : 'consensus';
		$weights        = isset( $arguments['weights'] ) ? $arguments['weights'] : array();
		$priority_order = isset( $arguments['priority_order'] ) ? $arguments['priority_order'] : array( 'critic', 'planner', 'executor' );

		// Get communication service.
		if ( ! class_exists( 'WP_MCP_AI_Agent_Communication_Service' ) ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'Agent communication system not available.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$communication_service = new WP_MCP_AI_Agent_Communication_Service();

		// Prepare results for aggregation.
		$prepared_results = array();
		foreach ( $agent_results as $result_data ) {
			if ( ! isset( $result_data['agent_id'] ) || ! isset( $result_data['result'] ) ) {
				continue; // Skip invalid results.
			}

			$prepared_results[] = array(
				'agent_id'   => absint( $result_data['agent_id'] ),
				'agent_role' => isset( $result_data['agent_role'] ) ? sanitize_key( $result_data['agent_role'] ) : 'executor',
				'result'     => $result_data['result'],
				'confidence' => isset( $result_data['confidence'] ) ? floatval( $result_data['confidence'] ) : 0.85,
				'metadata'   => isset( $result_data['metadata'] ) ? $result_data['metadata'] : array(),
			);
		}

		if ( empty( $prepared_results ) ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'No valid agent results to aggregate.', 'nvdigital-open-operator-system-oos' )
			);
		}

		// Set aggregation options.
		$aggregation_options = array();
		if ( 'weighted' === $strategy && ! empty( $weights ) ) {
			$aggregation_options['weights'] = $weights;
		}
		if ( 'hierarchical' === $strategy && ! empty( $priority_order ) ) {
			$aggregation_options['priority_order'] = $priority_order;
		}

		// Aggregate results.
		$aggregated = $communication_service->aggregate_results( $prepared_results, $strategy, $aggregation_options );

		if ( is_wp_error( $aggregated ) ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				$aggregated->get_error_message(),
				array( 'code' => $aggregated->get_error_code() )
			);
		}

		// Format aggregated result.
		return array(
			'success'     => true,
			'message'     => __( 'Results aggregated successfully.', 'nvdigital-open-operator-system-oos' ),
			'aggregation' => array(
				'strategy'            => $strategy,
				'agent_count'         => count( $prepared_results ),
				'result'              => $aggregated['result'],
				'confidence'          => isset( $aggregated['confidence'] ) ? $aggregated['confidence'] : null,
				'contributing_agents' => array_map(
					function ( $result ) {
						return array(
							'agent_id'   => $result['agent_id'],
							'agent_role' => $result['agent_role'],
						);
					},
					$prepared_results
				),
				'metadata'            => isset( $aggregated['metadata'] ) ? $aggregated['metadata'] : array(),
			),
			'explanation' => $this->get_strategy_explanation( $strategy ),
		);
	}

	/**
	 * Get explanation of aggregation strategy.
	 *
	 * @param string $strategy Strategy name.
	 * @return string Explanation.
	 */
	private function get_strategy_explanation( $strategy ) {
		$explanations = array(
			'consensus'    => __( 'All agent results were considered equally. Common elements were identified and conflicts resolved.', 'nvdigital-open-operator-system-oos' ),
			'weighted'     => __( 'Agent results were weighted based on provided weights. Higher-weighted agents had more influence.', 'nvdigital-open-operator-system-oos' ),
			'hierarchical' => __( 'Agent results were prioritized by role. Higher-priority roles (e.g., critic) had precedence.', 'nvdigital-open-operator-system-oos' ),
			'first'        => __( 'The first agent result was used as the primary output.', 'nvdigital-open-operator-system-oos' ),
			'best'         => __( 'The agent result with the highest confidence score was selected.', 'nvdigital-open-operator-system-oos' ),
		);

		return isset( $explanations[ $strategy ] ) ? $explanations[ $strategy ] : __( 'Results were combined using the specified strategy.', 'nvdigital-open-operator-system-oos' );
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'workflow_automation',

			'pattern_compatibility' => array( 'hierarchical', 'orchestrator' ),

			'profession_tags'       => array( 'project_manager', 'systems_administrator' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',   // Read-only aggregation.
			'local-only',  // No external API calls.
			'idempotent',  // Same inputs = same output.
			'cacheable',   // Results can be cached.
		);
	}
}
