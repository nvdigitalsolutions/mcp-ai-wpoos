<?php
/**
 * Tool that generates embeddings using browser-native Transformers.js
 *
 * @package WP_MCP_AI
 * @since 1.2.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-restrict-from-chat-client.php';

/**
 * Browser-native semantic search tool
 *
 * Uses Transformers.js to generate embeddings for vector search.
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Tool_Client_Semantic_Search implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Restrict_From_Chat_Client;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'client_semantic_search';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Browser Semantic Search', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Generate text embeddings for semantic search using browser-native AI. Processes instantly without server round-trip. Creates 384-dimensional vectors for similarity search.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Generating lightweight embeddings in the browser for similarity search without API costs.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Indexing a whole content library; use batch_embed_content for server-side batch indexing.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'batch_embed_content', 'semantic_content_search', 'client_question_answering' ),
			'notes'           => __( 'Produces 384-dimensional vectors via Transformers.js; client-side only, no tokens consumed.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'text' => array(
					'description' => __( 'The text or array of texts to embed for semantic search.', 'nvdigital-open-operator-system-oos' ),
					'oneOf'       => array(
						array(
							'type' => 'string',
						),
						array(
							'type'  => 'array',
							'items' => array(
								'type' => 'string',
							),
						),
					),
				),
			),
			'required'             => array( 'text' ),
			'additionalProperties' => false,
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'research_discovery',

			'pattern_compatibility' => array( 'orchestrator', 'peer_to_peer' ),

			'profession_tags'       => array( 'researcher', 'data_scientist' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'external-api'    => false,
			'consumes-tokens' => false,
			'read-only'       => true,
			'client-side'     => true,
			'offline'         => true,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array Tool execution result.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! class_exists( 'WP_MCP_AI_Transformers_Enqueue' ) ||
			! WP_MCP_AI_Transformers_Enqueue::is_transformers_enabled() ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'Browser-native AI tasks are not enabled.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$text = isset( $arguments['text'] ) ? $arguments['text'] : '';

		if ( empty( $text ) ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'Text parameter is required.', 'nvdigital-open-operator-system-oos' )
			);
		}

		return array(
			'success'           => true,
			'client_executable' => true,
			'client_method'     => 'embed',
			'client_arguments'  => array( 'text' => $text ),
			'message'           => __( 'Generating embeddings in browser...', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function should_exclude_from_client() {
		return true;
	}
}
