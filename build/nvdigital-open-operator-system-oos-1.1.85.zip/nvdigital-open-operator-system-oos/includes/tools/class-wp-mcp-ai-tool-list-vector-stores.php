<?php
/**
 * Tool that lists OpenAI vector stores.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-openai-client.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-logger.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php';

/**
 * Lists OpenAI vector stores.
 */
class WP_MCP_AI_Tool_List_Vector_Stores implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'list_vector_stores';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'List Vector Stores', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Lists all OpenAI vector stores with optional filtering and pagination. Use this to discover available knowledge bases.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Discovering available OpenAI vector stores and their IDs for RAG setup.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Adding or removing files inside a store; use manage_vector_store_files.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'manage_vector_store_files', 'list_openai_files' ),
			'notes'           => __( 'Paginate with after and before cursors; returns first_id and last_id.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'limit'  => array(
					'type'        => 'integer',
					'description' => __( 'Maximum number of vector stores to return (1-100, default 20).', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 1,
					'maximum'     => 100,
					'default'     => 20,
				),
				'order'  => array(
					'type'        => 'string',
					'description' => __( 'Sort order (asc or desc, default desc).', 'nvdigital-open-operator-system-oos' ),
					'enum'        => array( 'asc', 'desc' ),
					'default'     => 'desc',
				),
				'after'  => array(
					'type'        => 'string',
					'description' => __( 'Cursor for pagination (ID of the last item from previous page).', 'nvdigital-open-operator-system-oos' ),
				),
				'before' => array(
					'type'        => 'string',
					'description' => __( 'Cursor for reverse pagination (ID of the first item from previous page).', 'nvdigital-open-operator-system-oos' ),
				),
			),
			'required'   => array(),
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array Tool execution result.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$options = array();

		if ( ! empty( $arguments['limit'] ) ) {
			$options['limit'] = absint( $arguments['limit'] );
		}

		if ( ! empty( $arguments['order'] ) ) {
			$options['order'] = sanitize_key( $arguments['order'] );
		}

		if ( ! empty( $arguments['after'] ) ) {
			$options['after'] = sanitize_text_field( $arguments['after'] );
		}

		if ( ! empty( $arguments['before'] ) ) {
			$options['before'] = sanitize_text_field( $arguments['before'] );
		}

		$client = new WP_MCP_AI_OpenAI_Client();
		$result = $client->list_vector_stores( $options );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$vector_stores = isset( $result['data'] ) ? $result['data'] : array();
		$count         = count( $vector_stores );
		$has_more      = isset( $result['has_more'] ) ? $result['has_more'] : false;

		$message = $this->format_collection_response(
			$count,
			__( 'vector store', 'nvdigital-open-operator-system-oos' ),
			__( 'vector stores', 'nvdigital-open-operator-system-oos' ),
			$has_more
		);

		return array(
			'success' => true,
			'message' => $message,
			'text'    => $message,
			'data'    => array(
				'vector_stores' => $vector_stores,
				'has_more'      => $has_more,
				'first_id'      => isset( $result['first_id'] ) ? $result['first_id'] : null,
				'last_id'       => isset( $result['last_id'] ) ? $result['last_id'] : null,
			),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'read';
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'data_analytics',

			'pattern_compatibility' => array( 'orchestrator' ),

			'profession_tags'       => array( 'data_scientist' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'external-api',
			'requires-capability',
			'read-only',
			'cacheable',
		);
	}
}
