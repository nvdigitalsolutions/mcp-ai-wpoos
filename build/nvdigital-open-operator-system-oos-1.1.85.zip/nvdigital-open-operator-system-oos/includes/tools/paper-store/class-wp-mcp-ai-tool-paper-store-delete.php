<?php
/**
 * Tool: paper_store_delete — Delete a Paper Store record.
 *
 * @package WP_MCP_AI
 * @since   1.3.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Paper Store — Delete tool.
 */
class WP_MCP_AI_Tool_Paper_Store_Delete implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Paper_Store_Remote;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'paper_store_delete';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Paper Store — Delete Record', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Deletes a record from a Paper Store collection by ID. This permanently removes the file. Use with caution.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Permanently removing a Paper Store record by ID.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Partial changes; use paper_store_update. Keeping the record with an archived status; use paper_store_update.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'paper_store_update', 'paper_store_write', 'paper_store_read' ),
			'notes'           => __( 'Deletion is permanent; connection_id routes the call to a remote WordPress site.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'collection'    => array(
					'type'        => 'string',
					'description' => __( 'Collection name.', 'nvdigital-open-operator-system-oos' ),
				),
				'record_id'     => array(
					'type'        => 'string',
					'description' => __( 'The ID of the record to delete.', 'nvdigital-open-operator-system-oos' ),
				),
				'connection_id' => $this->get_connection_id_schema(),
			),
			'required'   => array( 'collection', 'record_id' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'delete_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Gate 1 — Sanitize at entry.
		$collection    = sanitize_key( $arguments['collection'] );
		$record_id     = sanitize_key( $arguments['record_id'] );
		$connection_id = isset( $arguments['connection_id'] ) ? sanitize_key( $arguments['connection_id'] ) : '';

		// Remote dispatch.
		if ( ! empty( $connection_id ) ) {
			return $this->execute_remote(
				$connection_id,
				'mcp-ai/v1/paper-store/' . $collection . '/' . $record_id,
				'DELETE'
			);
		}

		if ( empty( $collection ) || empty( $record_id ) ) {
			return new WP_Error( 'missing_params', __( 'Collection and record_id are required.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( ! current_user_can( 'delete_posts' ) ) {
			return new WP_Error( 'forbidden', __( 'Permission denied.', 'nvdigital-open-operator-system-oos' ) );
		}

		$manager = WP_MCP_AI_Paper_Store_Manager::get_instance();
		$repo    = $manager->get_repository( $collection );

		$result = $repo->delete( $record_id );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Gate 2 — Escape at exit.
		return $this->format_success_response(
			sprintf(
				/* translators: 1: record ID, 2: collection name */
				__( 'Record "%1$s" deleted from collection "%2$s".', 'nvdigital-open-operator-system-oos' ),
				$record_id,
				$collection
			),
			array(
				'collection' => esc_html( $collection ),
				'record_id'  => esc_html( $record_id ),
			)
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array( 'write', 'state-changing', 'local-only', 'requires-capability' );
	}

	/**
	 * Get extended tool definition.
	 *
	 * @return array
	 */
	public function get_definition() {
		return array(
			'name'                  => $this->get_name(),
			'description'           => $this->get_description(),
			'toolkit'               => 'paper_store',
			'pattern_compatibility' => array( 'orchestrator', 'sequential' ),
			'risk_level'            => 'medium',
		);
	}
}
