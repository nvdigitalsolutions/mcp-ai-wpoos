<?php
/**
 * Tool that scrapes product information from a URL and downloads images.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scrapes product information from URLs and downloads product images to WordPress media library.
 */
class WP_MCP_AI_Tool_Scrape_Product implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'scrape_product';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Scrape Product', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Scrapes product information (title, subtitle, description, images, price, availability) from a product URL or saved HTML file. Supports Schema.org JSON-LD parsing for structured product data. Downloads highest resolution images to WordPress media library.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Extracting title, description, images, price, and availability from a product URL or saved HTML file.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Validated scraping or WooCommerce import; use scrape_product_validated for strict args and create_woo_product to import results.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'scrape_product_validated', 'create_woo_product', 'run_crawl4ai_job' ),
			'notes'           => __( 'Provide url or html_file; JSON-LD is parsed when present and best-resolution images download to the media library.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'url'                     => array(
					'type'        => 'string',
					'description' => __( 'The product page URL to scrape. Either url or html_file is required.', 'nvdigital-open-operator-system-oos' ),
					'format'      => 'uri',
				),
				'html_file'               => array(
					'type'        => 'string',
					'description' => __( 'Path to a saved HTML file to parse instead of fetching from URL. Either url or html_file is required.', 'nvdigital-open-operator-system-oos' ),
				),
				'title_selector'          => array(
					'type'        => 'string',
					'description' => __( 'CSS selector for product title (default: .swa-product-information__title.swa-label-sans--default-strong).', 'nvdigital-open-operator-system-oos' ),
					'default'     => '.swa-product-information__title.swa-label-sans--default-strong',
				),
				'subtitle_selector'       => array(
					'type'        => 'string',
					'description' => __( 'CSS selector for product subtitle (default: .swa-product-information__subtitle.swa-label-sans--default).', 'nvdigital-open-operator-system-oos' ),
					'default'     => '.swa-product-information__subtitle.swa-label-sans--default',
				),
				'description_selector'    => array(
					'type'        => 'string',
					'description' => __( 'CSS selector for product description (default: .swa-cms-copy__body.swa-content-accordion__copy-body.swa-content-accordion__panel-inner.js-swa-content-accordion-panel-inner p).', 'nvdigital-open-operator-system-oos' ),
					'default'     => '.swa-cms-copy__body.swa-content-accordion__copy-body.swa-content-accordion__panel-inner.js-swa-content-accordion-panel-inner p',
				),
				'images_selector'         => array(
					'type'        => 'string',
					'description' => __( 'CSS selector or pattern for product images containers. Use "splide-slides" to match all div[id^="splide"] slide containers (default), or provide a custom selector.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'splide-slides',
				),
				'download_images'         => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to download images to WordPress media library (default: true).', 'nvdigital-open-operator-system-oos' ),
					'default'     => true,
				),
				'price_selector'          => array(
					'type'        => 'string',
					'description' => __( 'CSS selector for product price. If not provided, will attempt to extract from Schema.org JSON-LD or common price patterns.', 'nvdigital-open-operator-system-oos' ),
				),
				'extract_structured_data' => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to extract Schema.org JSON-LD structured data (default: true).', 'nvdigital-open-operator-system-oos' ),
					'default'     => true,
				),
			),
			'required'             => array(),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'upload_files' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to scrape products and upload files.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		$url       = isset( $arguments['url'] ) ? esc_url_raw( trim( $arguments['url'] ) ) : '';
		$html_file = isset( $arguments['html_file'] ) ? sanitize_text_field( trim( $arguments['html_file'] ) ) : '';

		// Validate that at least one input method is provided.
		if ( empty( $url ) && empty( $html_file ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_input', __( 'Either a product URL or HTML file path is required.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Get selectors with defaults.
		$title_selector       = isset( $arguments['title_selector'] ) ? sanitize_text_field( $arguments['title_selector'] ) : '.swa-product-information__title.swa-label-sans--default-strong';
		$subtitle_selector    = isset( $arguments['subtitle_selector'] ) ? sanitize_text_field( $arguments['subtitle_selector'] ) : '.swa-product-information__subtitle.swa-label-sans--default';
		$description_selector = isset( $arguments['description_selector'] ) ? sanitize_text_field( $arguments['description_selector'] ) : '.swa-cms-copy__body.swa-content-accordion__copy-body.swa-content-accordion__panel-inner.js-swa-content-accordion-panel-inner p';
		$images_selector      = isset( $arguments['images_selector'] ) ? sanitize_text_field( $arguments['images_selector'] ) : 'splide-slides';
		$price_selector       = isset( $arguments['price_selector'] ) ? sanitize_text_field( $arguments['price_selector'] ) : '';
		$download_images      = isset( $arguments['download_images'] ) ? (bool) $arguments['download_images'] : true;
		$extract_structured   = isset( $arguments['extract_structured_data'] ) ? (bool) $arguments['extract_structured_data'] : true;

		// Get HTML content from either URL or file.
		if ( ! empty( $html_file ) ) {
			$html = $this->read_html_file( $html_file );
		} else {
			// Validate URL scheme and block SSRF targets (private/link-local IPs, metadata endpoints).
			if ( ! wp_mcp_ai_is_safe_outbound_url( $url ) ) {
				return new WP_Error( 'wp_mcp_ai_invalid_url', __( 'Invalid URL provided. Only public HTTP and HTTPS URLs are supported.', 'nvdigital-open-operator-system-oos' ) );
			}
			$html = $this->fetch_url_content( $url );
		}

		if ( is_wp_error( $html ) ) {
			return $html;
		}

		// Parse the HTML.
		$product_data = $this->parse_product_data(
			$html,
			$title_selector,
			$subtitle_selector,
			$description_selector,
			$images_selector,
			$price_selector,
			$extract_structured,
			! empty( $url ) ? $url : ''
		);

		if ( is_wp_error( $product_data ) ) {
			return $product_data;
		}

		// Download images if requested.
		if ( $download_images && ! empty( $product_data['image_urls'] ) ) {
			$media_result = $this->download_images_to_media( $product_data['image_urls'], $product_data['title'] );

			if ( is_wp_error( $media_result ) ) {
				$product_data['images_download_error'] = $media_result->get_error_message();
				$product_data['media_ids']             = array();
			} else {
				$product_data['media_ids'] = $media_result;
			}
		}

		// Add summary for frontend display.
		$summary = sprintf(
			/* translators: %s: product title */
			__( 'Product scraped: %s', 'nvdigital-open-operator-system-oos' ),
			isset( $product_data['title'] ) ? $product_data['title'] : __( 'Unknown product', 'nvdigital-open-operator-system-oos' )
		);

		$product_data = array_merge(
			array(
				'message' => $summary,
				'summary' => $summary,
			),
			$product_data
		);

		return $product_data;
	}

	/**
	 * Fetch HTML content from a URL.
	 *
	 * @param string $url URL to fetch.
	 * @return string|WP_Error HTML content or error.
	 */
	protected function fetch_url_content( $url ) {
		// Build browser-like headers to avoid bot detection.
		$site_name = get_bloginfo( 'name' );
		$site_url  = home_url( '/' );
		$language  = get_bloginfo( 'language' );

		// Create a more browser-like User-Agent string.
		$user_agent = sprintf( 'WP-MCP-AI-Product-Scraper/1.0 (+%s)', $site_url );
		if ( $site_name ) {
			$user_agent = sprintf( 'WP-MCP-AI-Product-Scraper/1.0 (%s; +%s)', sanitize_text_field( $site_name ), $site_url );
		}

		$headers = array(
			'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => $language ? str_replace( '_', '-', $language ) : 'en-US,en;q=0.9',
			'User-Agent'      => $user_agent,
		);

		$request_args = array(
			'timeout'     => 30,
			'redirection' => 5,
			'headers'     => $headers,
			'sslverify'   => true,
		);

		/**
		 * Filters the HTTP request arguments for product scraping.
		 *
		 * @param array  $request_args HTTP request arguments.
		 * @param string $url          The URL being scraped.
		 */
		$request_args = apply_filters( 'wp_mcp_ai_scrape_product_request_args', $request_args, $url );

		// SSRF-guarded fetch (URL was already validated in execute(); the
		// wrapper re-validates as defence-in-depth).
		$response = wp_mcp_ai_remote_get( $url, $request_args );

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'wp_mcp_ai_fetch_failed',
				__( 'Failed to fetch the product page.', 'nvdigital-open-operator-system-oos' ),
				array( 'error' => $response->get_error_message() )
			);
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		// Accept any 2xx status code (200-299).
		if ( $status_code < 200 || $status_code >= 300 ) {
			return new WP_Error(
				'wp_mcp_ai_http_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'The product page returned an unexpected HTTP status: %d.', 'nvdigital-open-operator-system-oos' ),
					$status_code
				)
			);
		}

		$html = wp_remote_retrieve_body( $response );

		if ( empty( $html ) ) {
			return new WP_Error( 'wp_mcp_ai_empty_response', __( 'The product page returned an empty response.', 'nvdigital-open-operator-system-oos' ) );
		}

		return $html;
	}

	/**
	 * Read HTML content from a local file.
	 *
	 * @param string $file_path Path to HTML file.
	 * @return string|WP_Error HTML content or error.
	 */
	protected function read_html_file( $file_path ) {
		// Security: Validate file path to prevent directory traversal.
		$file_path = realpath( $file_path );

		if ( false === $file_path ) {
			return new WP_Error( 'wp_mcp_ai_file_not_found', __( 'The specified HTML file does not exist.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Security: Restrict file access to safe directories.
		$allowed_in_safe_directory = $this->is_path_in_safe_directory( $file_path );
		if ( is_wp_error( $allowed_in_safe_directory ) ) {
			return $allowed_in_safe_directory;
		}

		// Security: Ensure file is readable.
		if ( ! is_readable( $file_path ) ) {
			return new WP_Error( 'wp_mcp_ai_file_not_readable', __( 'The specified HTML file is not readable.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Security: Validate file extension.
		$allowed_extensions = array( 'html', 'htm' );
		$file_extension     = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );

		if ( ! in_array( $file_extension, $allowed_extensions, true ) ) {
			return new WP_Error( 'wp_mcp_ai_invalid_file_type', __( 'Only HTML files (.html, .htm) are allowed.', 'nvdigital-open-operator-system-oos' ) );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Required for local file reading.
		$html = file_get_contents( $file_path );

		if ( false === $html ) {
			return new WP_Error( 'wp_mcp_ai_file_read_failed', __( 'Failed to read the HTML file.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( empty( $html ) ) {
			return new WP_Error( 'wp_mcp_ai_empty_file', __( 'The HTML file is empty.', 'nvdigital-open-operator-system-oos' ) );
		}

		return $html;
	}

	/**
	 * Check if a file path is within safe directories.
	 *
	 * @param string $file_path Resolved absolute file path.
	 * @return true|WP_Error True if path is safe, WP_Error otherwise.
	 */
	protected function is_path_in_safe_directory( $file_path ) {
		// Normalize the file path for comparison.
		$normalized_path = wp_normalize_path( $file_path );

		// Define safe base directories.
		$safe_directories = array();

		// Allow WordPress uploads directory.
		$upload_dir = wp_upload_dir();
		if ( ! empty( $upload_dir['basedir'] ) ) {
			$safe_directories[] = wp_normalize_path( $upload_dir['basedir'] );
		}

		// Allow WordPress content directory.
		if ( defined( 'WP_CONTENT_DIR' ) && is_dir( WP_CONTENT_DIR ) ) {
			$safe_directories[] = wp_normalize_path( WP_CONTENT_DIR );
		}

		// Allow a filter for custom safe directories.
		$safe_directories = apply_filters( 'wp_mcp_ai_scrape_product_safe_directories', $safe_directories );

		// Check if the file path starts with any safe directory.
		foreach ( $safe_directories as $safe_dir ) {
			if ( 0 === strpos( $normalized_path, $safe_dir ) ) {
				return true;
			}
		}

		// Path is not in any safe directory.
		return new WP_Error(
			'wp_mcp_ai_unsafe_file_path',
			__( 'File path is not within allowed directories. Files must be in the WordPress uploads or content directory.', 'nvdigital-open-operator-system-oos' )
		);
	}

	/**
	 * Parse product data from HTML.
	 *
	 * @param string $html                HTML content.
	 * @param string $title_selector      CSS selector for title.
	 * @param string $subtitle_selector   CSS selector for subtitle.
	 * @param string $description_selector CSS selector for description.
	 * @param string $images_selector     CSS selector for images container.
	 * @param string $price_selector      CSS selector for price.
	 * @param bool   $extract_structured  Whether to extract Schema.org JSON-LD data.
	 * @param string $source_url          Source URL for context.
	 * @return array|WP_Error Parsed product data or error.
	 */
	protected function parse_product_data( $html, $title_selector, $subtitle_selector, $description_selector, $images_selector, $price_selector = '', $extract_structured = true, $source_url = '' ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return new WP_Error( 'wp_mcp_ai_no_dom', __( 'DOMDocument class is not available for HTML parsing.', 'nvdigital-open-operator-system-oos' ) );
		}

		$dom = new DOMDocument();
		libxml_use_internal_errors( true );
		$loaded = $dom->loadHTML( mb_convert_encoding( $html, 'HTML-ENTITIES', 'UTF-8' ) );
		libxml_clear_errors();

		if ( ! $loaded ) {
			return new WP_Error( 'wp_mcp_ai_parse_failed', __( 'Failed to parse the product page HTML.', 'nvdigital-open-operator-system-oos' ) );
		}

		$xpath = new DOMXPath( $dom );

		// Extract Schema.org JSON-LD structured data first if enabled.
		$structured_data = array();
		if ( $extract_structured ) {
			$structured_data = $this->extract_schema_org_data( $xpath, $html );
		}

		// Extract product title (prefer structured data, fall back to selector).
		$title = '';
		if ( ! empty( $structured_data['name'] ) ) {
			$title = $structured_data['name'];
		}
		if ( empty( $title ) ) {
			$title = $this->extract_text_by_selector( $xpath, $title_selector );
		}

		// Extract product subtitle.
		$subtitle = $this->extract_text_by_selector( $xpath, $subtitle_selector );

		// Extract product description (prefer structured data).
		$description = '';
		if ( ! empty( $structured_data['description'] ) ) {
			$description = $structured_data['description'];
		}
		if ( empty( $description ) ) {
			$description = $this->extract_description_by_selector( $xpath, $description_selector );
		}

		// Extract image URLs.
		$image_urls = $this->extract_image_urls( $xpath, $images_selector );

		// Merge with images from structured data if available.
		if ( ! empty( $structured_data['image'] ) ) {
			if ( is_array( $structured_data['image'] ) ) {
				$image_urls = array_merge( $structured_data['image'], $image_urls );
			} elseif ( is_string( $structured_data['image'] ) ) {
				array_unshift( $image_urls, $structured_data['image'] );
			}
			$image_urls = array_unique( $image_urls );
		}

		// Extract pricing information.
		$pricing_data = $this->extract_pricing_data( $xpath, $html, $price_selector, $structured_data );

		$result = array(
			'title'       => $title,
			'subtitle'    => $subtitle,
			'description' => $description,
			'image_urls'  => $image_urls,
		);

		// Add pricing data if found.
		if ( ! empty( $pricing_data ) ) {
			$result = array_merge( $result, $pricing_data );
		}

		// Add structured data if found.
		if ( ! empty( $structured_data ) && $extract_structured ) {
			$result['structured_data'] = $structured_data;
		}

		// Add source URL if provided.
		if ( ! empty( $source_url ) ) {
			$result['source_url'] = $source_url;
		}

		return $result;
	}

	/**
	 * Extract text content by CSS selector.
	 *
	 * @param DOMXPath $xpath    XPath object.
	 * @param string   $selector CSS selector.
	 * @return string Extracted text or empty string.
	 */
	protected function extract_text_by_selector( $xpath, $selector ) {
		$xpath_query = $this->css_to_xpath( $selector );
		$nodes       = $xpath->query( $xpath_query );

		if ( $nodes && $nodes->length > 0 ) {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property.
			return trim( $nodes->item( 0 )->textContent );
		}

		return '';
	}

	/**
	 * Extract description from multiple paragraph elements.
	 *
	 * @param DOMXPath $xpath    XPath object.
	 * @param string   $selector CSS selector.
	 * @return string Extracted description or empty string.
	 */
	protected function extract_description_by_selector( $xpath, $selector ) {
		$xpath_query = $this->css_to_xpath( $selector );
		$nodes       = $xpath->query( $xpath_query );

		if ( ! $nodes || 0 === $nodes->length ) {
			return '';
		}

		$paragraphs = array();
		foreach ( $nodes as $node ) {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property.
			$text = trim( $node->textContent );
			if ( ! empty( $text ) ) {
				$paragraphs[] = $text;
			}
		}

		return implode( "\n\n", $paragraphs );
	}

	/**
	 * Extract image URLs from a container.
	 *
	 * @param DOMXPath $xpath    XPath object.
	 * @param string   $selector CSS selector or pattern for images container.
	 * @return array Array of image URLs (highest resolution preferred).
	 */
	protected function extract_image_urls( $xpath, $selector ) {
		// Handle special pattern for all splide slides.
		if ( 'splide-slides' === $selector ) {
			// Find all div elements with id starting with "splide" and containing "-slide".
			$xpath_query = '//div[starts-with(@id, "splide") and contains(@id, "-slide")]';
		} else {
			$xpath_query = $this->css_to_xpath( $selector );
		}

		$containers = $xpath->query( $xpath_query );

		if ( ! $containers || 0 === $containers->length ) {
			return array();
		}

		$image_urls = array();

		// Find all img tags within the containers.
		foreach ( $containers as $container ) {
			$images = $container->getElementsByTagName( 'img' );

			foreach ( $images as $img ) {
				$candidate_urls = array();

				// Collect all possible image URLs from various attributes.
				$src = $img->getAttribute( 'src' );
				if ( ! empty( $src ) ) {
					$candidate_urls[] = $src;
				}

				// Check data-src for lazy-loaded images.
				$data_src = $img->getAttribute( 'data-src' );
				if ( ! empty( $data_src ) ) {
					$candidate_urls[] = $data_src;
				}

				// Check data-splide-lazy for Splide.js lazy-loaded images.
				$data_splide = $img->getAttribute( 'data-splide-lazy' );
				if ( ! empty( $data_splide ) ) {
					$candidate_urls[] = $data_splide;
				}

				// Check srcset for responsive images.
				$srcset = $img->getAttribute( 'srcset' );
				if ( ! empty( $srcset ) ) {
					// Parse all URLs from srcset.
					$srcset_parts = explode( ',', $srcset );
					foreach ( $srcset_parts as $srcset_entry ) {
						$entry_parts = preg_split( '/\s+/', trim( $srcset_entry ) );
						if ( ! empty( $entry_parts[0] ) ) {
							$candidate_urls[] = $entry_parts[0];
						}
					}
				}

				// Select the highest resolution URL from candidates.
				$selected_url = $this->select_highest_resolution_url( $candidate_urls );

				if ( ! empty( $selected_url ) ) {
					$selected_url = esc_url_raw( $selected_url );
					if ( ! empty( $selected_url ) && ! in_array( $selected_url, $image_urls, true ) ) {
						$image_urls[] = $selected_url;
					}
				}
			}
		}

		return $image_urls;
	}

	/**
	 * Select the highest resolution URL from a list of candidate URLs.
	 *
	 * Prioritizes URLs containing resolution patterns like "1000x1000".
	 *
	 * @param array $urls Array of candidate URLs.
	 * @return string Best URL or empty string.
	 */
	protected function select_highest_resolution_url( $urls ) {
		if ( empty( $urls ) ) {
			return '';
		}

		// Remove empty URLs and normalize.
		$urls = array_filter( array_map( 'trim', $urls ) );

		if ( empty( $urls ) ) {
			return '';
		}

		// If only one URL, return it.
		if ( 1 === count( $urls ) ) {
			return reset( $urls );
		}

		// Score each URL based on resolution indicators.
		$scored_urls = array();

		foreach ( $urls as $url ) {
			$score = 0;

			// Extract resolution from URL patterns like "1000x1000", "800x800", etc.
			if ( preg_match( '/(\d+)x(\d+)/i', $url, $matches ) ) {
				$width  = intval( $matches[1] );
				$height = intval( $matches[2] );
				// Score based on total pixel count.
				$score = $width * $height;

				// Bonus for square images (width == height).
				if ( $width === $height ) {
					$score += 10000;
				}
			}

			// Prefer URLs with "1000x1000" explicitly.
			if ( stripos( $url, '1000x1000' ) !== false ) {
				$score += 1000000; // High priority.
			}

			// Prefer larger dimension indicators in general.
			if ( stripos( $url, 'large' ) !== false || stripos( $url, 'xl' ) !== false ) {
				$score += 50000;
			}

			// Penalize thumbnails.
			if ( stripos( $url, 'thumb' ) !== false || stripos( $url, 'small' ) !== false ) {
				$score -= 100000;
			}

			$scored_urls[ $url ] = $score;
		}

		// Sort by score (highest first).
		arsort( $scored_urls );

		// Return the URL with the highest score.
		return key( $scored_urls );
	}

	/**
	 * Convert a simple CSS selector to XPath.
	 *
	 * This is a basic converter supporting common selectors used for product scraping.
	 *
	 * @param string $selector CSS selector.
	 * @return string XPath query.
	 */
	protected function css_to_xpath( $selector ) {
		// Remove extra spaces.
		$selector = trim( $selector );

		// Replace descendant combinator (space) with XPath descendant axis
		// BEFORE the class/ID replacements below — doing it afterwards would
		// corrupt the spaces inside the generated contains() predicates.
		$selector = preg_replace( '/\s+/', ' ', $selector );
		$selector = str_replace( ' ', '//', $selector );

		// Handle ID selector (#id).
		$selector = preg_replace( '/#([a-zA-Z0-9_-]+)/', '*[@id="$1"]', $selector );

		// Handle class selector (.class).
		// Support multiple classes by converting to contains.
		$selector = preg_replace_callback(
			'/\.([a-zA-Z0-9_-]+)/',
			function ( $matches ) {
				return '[contains(concat(" ", normalize-space(@class), " "), " ' . $matches[1] . ' ")]';
			},
			$selector
		);

		// Convert element.class or element#id patterns.
		$selector = preg_replace( '/([a-zA-Z][a-zA-Z0-9]*)\*/', '$1', $selector );

		// Predicates must follow an element test — insert a wildcard where the
		// start of the path or a descendant axis is followed directly by one.
		$selector = str_replace( '//[', '//*[', $selector );
		if ( 0 === strpos( $selector, '[' ) ) {
			$selector = '*' . $selector;
		}

		// Prepend // if not already present.
		if ( 0 !== strpos( $selector, '//' ) ) {
			$selector = '//' . $selector;
		}

		return $selector;
	}

	/**
	 * Extract Schema.org JSON-LD structured data from HTML.
	 *
	 * @param DOMXPath $xpath XPath object.
	 * @param string   $html  Full HTML content.
	 * @return array Schema.org product data.
	 */
	protected function extract_schema_org_data( $xpath, $html ) {
		$data = array();

		// Find all script tags with type application/ld+json.
		$scripts = $xpath->query( '//script[@type="application/ld+json"]' );

		if ( ! $scripts || 0 === $scripts->length ) {
			return $data;
		}

		foreach ( $scripts as $script ) {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property.
			$json_content = $script->textContent;
			$json_data    = json_decode( $json_content, true );

			if ( ! $json_data ) {
				continue;
			}

			// Handle @graph structure.
			if ( isset( $json_data['@graph'] ) && is_array( $json_data['@graph'] ) ) {
				foreach ( $json_data['@graph'] as $item ) {
					if ( $this->is_product_schema( $item ) ) {
						$data = $this->parse_product_schema( $item );
						break 2; // Found product, exit both loops.
					}
				}
			} elseif ( $this->is_product_schema( $json_data ) ) {
				$data = $this->parse_product_schema( $json_data );
				break;
			}
		}

		return $data;
	}

	/**
	 * Check if schema data represents a product.
	 *
	 * @param array $schema Schema data.
	 * @return bool True if product schema.
	 */
	protected function is_product_schema( $schema ) {
		if ( ! is_array( $schema ) || ! isset( $schema['@type'] ) ) {
			return false;
		}

		$type = $schema['@type'];
		if ( is_array( $type ) ) {
			return in_array( 'Product', $type, true );
		}

		return 'Product' === $type;
	}

	/**
	 * Parse product schema data.
	 *
	 * @param array $schema Schema data.
	 * @return array Parsed product data.
	 */
	protected function parse_product_schema( $schema ) {
		$data = array();

		// Extract name.
		if ( isset( $schema['name'] ) ) {
			$data['name'] = sanitize_text_field( $schema['name'] );
		}

		// Extract description.
		if ( isset( $schema['description'] ) ) {
			$data['description'] = sanitize_textarea_field( $schema['description'] );
		}

		// Extract brand.
		if ( isset( $schema['brand'] ) ) {
			if ( is_array( $schema['brand'] ) && isset( $schema['brand']['name'] ) ) {
				$data['brand'] = sanitize_text_field( $schema['brand']['name'] );
			} elseif ( is_string( $schema['brand'] ) ) {
				$data['brand'] = sanitize_text_field( $schema['brand'] );
			}
		}

		// Extract SKU/model/GTIN.
		if ( isset( $schema['sku'] ) ) {
			$data['sku'] = sanitize_text_field( $schema['sku'] );
		}
		if ( isset( $schema['mpn'] ) ) {
			$data['model'] = sanitize_text_field( $schema['mpn'] );
		}
		if ( isset( $schema['gtin'] ) ) {
			$data['gtin'] = sanitize_text_field( $schema['gtin'] );
		}
		if ( isset( $schema['gtin13'] ) ) {
			$data['gtin'] = sanitize_text_field( $schema['gtin13'] );
		}

		// Extract images.
		if ( isset( $schema['image'] ) ) {
			if ( is_array( $schema['image'] ) ) {
				$images = array();
				foreach ( $schema['image'] as $img ) {
					if ( is_string( $img ) ) {
						$images[] = esc_url_raw( $img );
					} elseif ( is_array( $img ) && isset( $img['url'] ) ) {
						$images[] = esc_url_raw( $img['url'] );
					}
				}
				$data['image'] = $images;
			} elseif ( is_string( $schema['image'] ) ) {
				$data['image'] = esc_url_raw( $schema['image'] );
			}
		}

		// Extract offers/pricing.
		if ( isset( $schema['offers'] ) ) {
			$offers = $schema['offers'];
			// Handle single offer or array of offers.
			if ( isset( $offers['@type'] ) && 'Offer' === $offers['@type'] ) {
				$offers = array( $offers );
			}

			if ( is_array( $offers ) ) {
				foreach ( $offers as $offer ) {
					if ( ! is_array( $offer ) ) {
						continue;
					}

					if ( isset( $offer['price'] ) ) {
						$data['price'] = floatval( $offer['price'] );
					}
					if ( isset( $offer['priceCurrency'] ) ) {
						$data['currency'] = sanitize_text_field( $offer['priceCurrency'] );
					}
					if ( isset( $offer['availability'] ) ) {
						$availability = $offer['availability'];
						// Parse availability URL (e.g., "https://schema.org/InStock").
						if ( is_string( $availability ) ) {
							if ( strpos( $availability, 'InStock' ) !== false ) {
								$data['availability'] = 'in_stock';
							} elseif ( strpos( $availability, 'OutOfStock' ) !== false ) {
								$data['availability'] = 'out_of_stock';
							} elseif ( strpos( $availability, 'PreOrder' ) !== false ) {
								$data['availability'] = 'pre_order';
							} else {
								$data['availability'] = 'unknown';
							}
						}
					}
					if ( isset( $offer['url'] ) ) {
						$data['offer_url'] = esc_url_raw( $offer['url'] );
					}

					// We have pricing info, break.
					if ( isset( $data['price'] ) ) {
						break;
					}
				}
			}
		}

		return $data;
	}

	/**
	 * Extract pricing data from HTML.
	 *
	 * @param DOMXPath $xpath          XPath object.
	 * @param string   $html           Full HTML content.
	 * @param string   $price_selector CSS selector for price.
	 * @param array    $structured_data Schema.org data (already extracted).
	 * @return array Pricing data.
	 */
	protected function extract_pricing_data( $xpath, $html, $price_selector, $structured_data ) {
		$pricing = array();

		// First check structured data.
		if ( ! empty( $structured_data['price'] ) ) {
			$pricing['price'] = $structured_data['price'];
		}
		if ( ! empty( $structured_data['currency'] ) ) {
			$pricing['currency'] = $structured_data['currency'];
		}
		if ( ! empty( $structured_data['availability'] ) ) {
			$pricing['availability'] = $structured_data['availability'];
		}
		if ( ! empty( $structured_data['brand'] ) ) {
			$pricing['brand'] = $structured_data['brand'];
		}
		if ( ! empty( $structured_data['sku'] ) ) {
			$pricing['sku'] = $structured_data['sku'];
		}
		if ( ! empty( $structured_data['model'] ) ) {
			$pricing['model'] = $structured_data['model'];
		}
		if ( ! empty( $structured_data['gtin'] ) ) {
			$pricing['gtin'] = $structured_data['gtin'];
		}

		// If no price from structured data, try selector or patterns.
		if ( empty( $pricing['price'] ) ) {
			// Try selector if provided.
			if ( ! empty( $price_selector ) ) {
				$price_text = $this->extract_text_by_selector( $xpath, $price_selector );
				if ( ! empty( $price_text ) ) {
					$price_data = $this->parse_price_from_text( $price_text );
					if ( $price_data ) {
						$pricing = array_merge( $pricing, $price_data );
					}
				}
			}

			// Fall back to pattern matching in full HTML.
			if ( empty( $pricing['price'] ) ) {
				$price_data = $this->parse_price_from_text( $html );
				if ( $price_data ) {
					$pricing = array_merge( $pricing, $price_data );
				}
			}
		}

		return $pricing;
	}

	/**
	 * Parse price from text using common patterns.
	 *
	 * @param string $text Text to parse.
	 * @return array|null Price data or null.
	 */
	protected function parse_price_from_text( $text ) {
		// Common price patterns.
		$patterns = array(
			'/\$\s*([0-9,]+\.?\d{0,2})\s*(USD)?/i',  // $123.45 USD or $123.45.
			'/([0-9,]+\.?\d{0,2})\s*USD/i',          // 123.45 USD.
			'/€\s*([0-9,]+\.?\d{0,2})/i',            // €123.45.
			'/£\s*([0-9,]+\.?\d{0,2})/i',            // £123.45.
			'/price["\s:]+\$?([0-9,]+\.?\d{0,2})/i', // Price: $123.45 or price="123.45".
		);

		foreach ( $patterns as $pattern ) {
			if ( preg_match( $pattern, $text, $matches ) ) {
				$price_str = str_replace( ',', '', $matches[1] );
				$price     = floatval( $price_str );

				if ( $price <= 0 ) {
					continue;
				}

				// Detect currency from pattern.
				$currency = 'USD'; // Default.
				if ( stripos( $matches[0], 'USD' ) !== false || strpos( $matches[0], '$' ) !== false ) {
					$currency = 'USD';
				} elseif ( strpos( $matches[0], '€' ) !== false ) {
					$currency = 'EUR';
				} elseif ( strpos( $matches[0], '£' ) !== false ) {
					$currency = 'GBP';
				}

				return array(
					'price'    => $price,
					'currency' => $currency,
				);
			}
		}

		return null;
	}

	/**
	 * Download images to WordPress media library.
	 *
	 * @param array  $image_urls Array of image URLs.
	 * @param string $title      Product title for alt text.
	 * @return array|WP_Error Array of attachment IDs or error.
	 */
	protected function download_images_to_media( $image_urls, $title = '' ) {
		if ( empty( $image_urls ) ) {
			return array();
		}

		if ( ! function_exists( 'media_sideload_image' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$attachment_ids = array();
		$errors         = array();

		foreach ( $image_urls as $index => $url ) {
			// Generate a descriptive filename.
			$filename = ! empty( $title ) ? sanitize_file_name( $title ) . '-' . ( $index + 1 ) : 'product-image-' . ( $index + 1 );

			// Try to download the image.
			$attachment_id = media_sideload_image( $url, 0, $title, 'id' );

			if ( is_wp_error( $attachment_id ) ) {
				$errors[] = sprintf(
					/* translators: 1: Image URL, 2: Error message */
					__( 'Failed to download image %1$s: %2$s', 'nvdigital-open-operator-system-oos' ),
					$url,
					$attachment_id->get_error_message()
				);
				continue;
			}

			$attachment_ids[] = $attachment_id;
		}

		if ( empty( $attachment_ids ) && ! empty( $errors ) ) {
			return new WP_Error(
				'wp_mcp_ai_download_failed',
				__( 'Failed to download any images.', 'nvdigital-open-operator-system-oos' ),
				array( 'errors' => $errors )
			);
		}

		return $attachment_ids;
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'ecommerce_business',

			'pattern_compatibility' => array( 'sequential' ),

			'profession_tags'       => array( 'ecommerce_manager', 'market_researcher' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',           // Only reads remote data.
			'write',               // Creates media attachments.
			'state-changing',      // Modifies database (media library).
			'external-api',        // Makes external HTTP requests.
			'requires-capability', // Requires upload_files capability.
			'network-dependent',   // Requires internet connectivity.
		);
	}
}
