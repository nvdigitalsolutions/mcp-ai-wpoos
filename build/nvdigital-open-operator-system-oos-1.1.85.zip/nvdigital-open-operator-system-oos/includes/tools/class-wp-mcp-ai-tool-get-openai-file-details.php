<?php
/**
 * Tool that retrieves detailed metadata about a specific OpenAI file.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Retrieves detailed metadata about a specific OpenAI file.
 */
class WP_MCP_AI_Tool_Get_OpenAI_File_Details implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'get_openai_file_details';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Get OpenAI File Details', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Retrieves detailed metadata about a specific OpenAI file. Use this to verify file upload success, check file processing status, get file size and format info, or debug file-related issues.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Checking upload success, processing status, size, or purpose of one OpenAI file by ID.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Discovering file IDs or batch outputs; use list_openai_files or get_batch_status.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'list_openai_files', 'get_batch_status', 'get_vector_store' ),
			'notes'           => __( 'Requires OpenAI credentials; returns bytes, purpose, status, and status_details.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'file_id' => array(
					'type'        => 'string',
					'description' => __( 'The OpenAI file identifier (e.g., file-abc123).', 'nvdigital-open-operator-system-oos' ),
				),
			),
			'required'             => array( 'file_id' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		// Check permissions.
		if ( ! $user_id || ! user_can( $user_id, 'read' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to retrieve OpenAI file details.', 'nvdigital-open-operator-system-oos' )
			);
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Validate file_id.
		if ( ! isset( $arguments['file_id'] ) || '' === $arguments['file_id'] ) {
			return new WP_Error(
				'wp_mcp_ai_missing_file_id',
				__( 'File ID is required.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$file_id = sanitize_text_field( $arguments['file_id'] );

		// Call OpenAI API.
		$client = new WP_MCP_AI_OpenAI_Client();
		$result = $client->retrieve_file( $file_id );

		// Handle errors.
		if ( is_wp_error( $result ) ) {
			return new WP_Error(
				$result->get_error_code(),
				$result->get_error_message(),
				$result->get_error_data()
			);
		}

		// Format the response.
		$file_details = array(
			'id'             => isset( $result['id'] ) ? $result['id'] : '',
			'object'         => isset( $result['object'] ) ? $result['object'] : '',
			'bytes'          => isset( $result['bytes'] ) ? $result['bytes'] : 0,
			'created_at'     => isset( $result['created_at'] ) ? gmdate( 'Y-m-d H:i:s', $result['created_at'] ) : '',
			'filename'       => isset( $result['filename'] ) ? $result['filename'] : '',
			'purpose'        => isset( $result['purpose'] ) ? $result['purpose'] : '',
			'status'         => isset( $result['status'] ) ? $result['status'] : '',
			'status_details' => isset( $result['status_details'] ) ? $result['status_details'] : null,
		);

		$summary = sprintf(
			/* translators: 1: filename, 2: file size in bytes */
			__( 'Retrieved details for file "%1$s" (%2$d bytes).', 'nvdigital-open-operator-system-oos' ),
			$file_details['filename'],
			$file_details['bytes']
		);

		return array(
			'success' => true,
			'file'    => $file_details,
			'message' => $summary, // Chat client.
			'summary' => $summary, // Backward compatibility.
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'ai_model_management',

			'pattern_compatibility' => array( 'experimentation' ),

			'profession_tags'       => array( 'machine_learning_engineer', 'data_scientist' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',            // Only reads data, does not modify state.
			'external-api',         // Makes external API calls to OpenAI.
			'requires-capability',  // Requires 'read' capability.
		);
	}
}
