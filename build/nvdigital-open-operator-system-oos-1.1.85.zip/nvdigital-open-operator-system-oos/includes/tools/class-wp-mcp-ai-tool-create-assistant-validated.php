<?php
/**
 * Tool for creating AI assistants programmatically (Validated version).
 *
 * This is the Symfony Validator version of the create_assistant tool.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../validators/class-wp-mcp-ai-validated-tool.php';
require_once __DIR__ . '/../validators/arguments/class-create-assistant-arguments.php';
require_once __DIR__ . '/class-wp-mcp-ai-tool-create-assistant.php';

/**
 * Allows users to create AI assistants with Symfony Validator.
 *
 * This class extends the original create_assistant tool to use
 * Symfony Validator for argument validation, delegating the actual
 * creation logic to the parent class.
 */
class WP_MCP_AI_Tool_Create_Assistant_Validated extends WP_MCP_AI_Validated_Tool implements WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface, WP_MCP_AI_Tool_Data_Contract_Interface {

	/**
	 * The original create_assistant tool instance for delegation.
	 *
	 * @var WP_MCP_AI_Tool_Create_Assistant
	 */
	protected $original_tool;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
		$this->original_tool = new WP_MCP_AI_Tool_Create_Assistant();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'create_assistant_validated';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Create AI Assistant (Validated)', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Creates a new AI assistant using Symfony Validator for argument validation. Can be used in two modes: (1) Manual mode - select from predefined professions and regions, or (2) Prompt mode - provide a free-form description and optional custom system prompt. Supports attachment IDs for knowledge base files. The assistant will be saved as a draft.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Creating an AI assistant when strict Symfony Validator argument validation is preferred over manual checks.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'When validation overhead is unneeded use create_assistant; for cloning an existing assistant use duplicate_assistant.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'create_assistant', 'duplicate_assistant' ),
			'notes'           => __( 'Same parameters and creation logic as create_assistant; delegates execution to the original tool.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_data_contract() {
		return array(
			'produces' => 'assistant_id',
			'consumes' => null,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		// Use the same schema as the original tool.
		return $this->original_tool->get_parameters_schema();
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_validation_class() {
		return \WP_MCP_AI\Tools\Arguments\CreateAssistantArguments::class;
	}

	/**
	 * Execute the tool with validated arguments.
	 *
	 * @param \WP_MCP_AI\Tools\Arguments\CreateAssistantArguments $validated_args Validated arguments object.
	 * @param array                                               $context        Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	protected function execute_validated( $validated_args, $context ) {
		// Convert validated arguments object back to array format.
		// for the original tool's execute method.
		$arguments = array(
			'title' => $validated_args->title,
		);

		// Add optional fields only if they have values.
		if ( null !== $validated_args->description && '' !== $validated_args->description ) {
			$arguments['description'] = $validated_args->description;
		}

		if ( null !== $validated_args->system_prompt && '' !== $validated_args->system_prompt ) {
			$arguments['system_prompt'] = $validated_args->system_prompt;
		}

		if ( ! empty( $validated_args->professions ) ) {
			$arguments['professions'] = $validated_args->professions;
		}

		if ( ! empty( $validated_args->regions ) ) {
			$arguments['regions'] = $validated_args->regions;
		}

		if ( null !== $validated_args->industry_focus && '' !== $validated_args->industry_focus ) {
			$arguments['industry_focus'] = $validated_args->industry_focus;
		}

		if ( ! empty( $validated_args->attachment_ids ) ) {
			$arguments['attachment_ids'] = $validated_args->attachment_ids;
		}

		if ( $validated_args->async ) {
			$arguments['async'] = $validated_args->async;
		}

		if ( null !== $validated_args->notification_email && '' !== $validated_args->notification_email ) {
			$arguments['notify_email'] = $validated_args->notification_email;
		}

		// Delegate to the original tool's execute method.
		// The original tool handles all the complex logic.
		return $this->original_tool->execute( $arguments, $context );
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'ai_model_management',

			'pattern_compatibility' => array( 'orchestrator' ),

			'profession_tags'       => array( 'ai_researcher', 'systems_administrator' ),

			'risk_level'            => 'standard',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		// Delegate to the original tool.
		return $this->original_tool->get_capability_flags();
	}
}
