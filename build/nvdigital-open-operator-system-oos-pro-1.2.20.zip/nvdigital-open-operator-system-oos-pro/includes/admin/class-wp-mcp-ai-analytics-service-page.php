<?php
/**
 * Analytics Service Status Admin Page
 *
 * Standalone admin dashboard for the Shared Analytics Service. Shows adapter
 * status, cache health, rate limit consumption, and manual cache invalidation
 * across all 7 platform adapters.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.7.0
 * @author  NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license  Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Analytics Service status page.
 *
 * @since 1.7.0
 */
class WP_MCP_AI_Analytics_Service_Page {

	/**
	 * Admin page slug.
	 *
	 * @since 1.7.0
	 * @var string
	 */
	const PAGE_SLUG = 'nvoos-analytics-service';

	/**
	 * Constructor — registers hooks.
	 *
	 * @since 1.7.0
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_page' ), 30 );
	}

	/**
	 * Register the admin page under NV oOS Pro.
	 *
	 * @since 1.7.0
	 * @return void
	 */
	public function register_page() {
		add_submenu_page(
			'nvoos-pro-dashboard',
			__( 'Analytics Service', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Analytics Service', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Render the analytics service status page.
	 *
	 * @since 1.7.0
	 * @return void
	 */
	public function render_page() {
		$service_loaded = class_exists( 'WP_MCP_AI_Analytics_Service' );

		?>
		<div class="wrap">
			<h1>
				<span class="dashicons dashicons-chart-area" style="font-size:28px;vertical-align:middle;"></span>
				<?php esc_html_e( 'Shared Analytics Service', 'nvdigital-open-operator-system-oos-pro' ); ?>
			</h1>
			<p class="description">
				<?php esc_html_e( 'Status dashboard for the shared analytics infrastructure used by all pro-toolkits.', 'nvdigital-open-operator-system-oos-pro' ); ?>
			</p>

			<?php if ( ! $service_loaded ) : ?>
				<div class="notice notice-error">
					<p><?php esc_html_e( 'The Shared Analytics Service is not loaded. Ensure the Pro addon is active and up to date.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
				</div>
				<?php
				return;
			endif;
			?>

			<?php $this->render_adapter_dashboard(); ?>
			<?php $this->render_cache_dashboard(); ?>
			<?php $this->render_rate_limit_dashboard(); ?>
			<?php $this->render_observability_dashboard(); ?>
			<?php $this->render_cache_actions(); ?>
		</div>

		<style>
			.analytics-service-grid {
				display: grid;
				grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
				gap: 16px;
				margin: 20px 0;
			}
			.analytics-service-card {
				background: #fff;
				border: 1px solid #ccd0d4;
				border-radius: 4px;
				padding: 16px;
				box-shadow: 0 1px 2px rgba(0,0,0,0.04);
			}
			.analytics-service-card h3 {
				margin: 0 0 12px 0;
				font-size: 14px;
			}
			.analytics-service-card table {
				width: 100%;
				border-collapse: collapse;
			}
			.analytics-service-card table th,
			.analytics-service-card table td {
				padding: 6px 8px;
				text-align: left;
				border-bottom: 1px solid #f0f0f1;
				font-size: 13px;
			}
			.analytics-service-card .status-dot {
				display: inline-block;
				width: 10px;
				height: 10px;
				border-radius: 50%;
				margin-right: 6px;
			}
			.status-dot.green { background: #46b450; }
			.status-dot.orange { background: #f0ad4e; }
			.status-dot.red { background: #dc3232; }
			.status-dot.gray { background: #a0a5aa; }
		</style>
		<?php
	}

	/**
	 * Render the adapter status dashboard.
	 *
	 * @since 1.7.0
	 * @return void
	 */
	private function render_adapter_dashboard() {
		$service  = WP_MCP_AI_Analytics_Service::instance();
		$adapters = array(
			'meta'             => __( 'Meta (Facebook + Instagram)', 'nvdigital-open-operator-system-oos-pro' ),
			'twitter'          => __( 'Twitter / X', 'nvdigital-open-operator-system-oos-pro' ),
			'linkedin'         => __( 'LinkedIn', 'nvdigital-open-operator-system-oos-pro' ),
			'tiktok'           => __( 'TikTok', 'nvdigital-open-operator-system-oos-pro' ),
			'woocommerce'      => __( 'WooCommerce', 'nvdigital-open-operator-system-oos-pro' ),
			'google_analytics' => __( 'Google Analytics (GA4)', 'nvdigital-open-operator-system-oos-pro' ),
			'cloudways'        => __( 'Cloudways', 'nvdigital-open-operator-system-oos-pro' ),
		);

		$connected = $service->get_connected_platforms();

		?>
		<h2><?php esc_html_e( 'Adapter Status', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
		<div class="analytics-service-grid">
			<?php foreach ( $adapters as $slug => $label ) : ?>
				<div class="analytics-service-card">
					<h3><?php echo esc_html( $label ); ?></h3>
					<?php
					$adapter    = $service->get_adapter( $slug );
					$configured = $adapter && $adapter->is_configured();
					$dot_class  = $configured ? 'green' : 'gray';
					$status     = $configured ? __( 'Configured', 'nvdigital-open-operator-system-oos-pro' ) : __( 'Not Configured', 'nvdigital-open-operator-system-oos-pro' );
					?>
					<p>
						<span class="status-dot <?php echo esc_attr( $dot_class ); ?>"></span>
						<strong><?php echo esc_html( $status ); ?></strong>
					</p>
					<?php if ( $configured && $adapter ) : ?>
						<?php
						$remaining = $adapter->get_rate_limit_remaining();
						if ( null !== $remaining ) :
							?>
							<p style="font-size:12px;color:#555;">
								<?php
								printf(
									/* translators: %d: remaining API requests */
									esc_html__( '~%d API requests remaining', 'nvdigital-open-operator-system-oos-pro' ),
									absint( $remaining )
								);
								?>
							</p>
						<?php endif; ?>
					<?php else : ?>
						<p style="font-size:12px;color:#888;">
							<?php esc_html_e( 'Configure credentials in NV oOS → Social Media Settings or Pro Integrations.', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</p>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render the cache health dashboard.
	 *
	 * @since 1.7.0
	 * @return void
	 */
	private function render_cache_dashboard() {
		if ( ! class_exists( 'WP_MCP_AI_Analytics_Cache' ) ) {
			return;
		}

		$cache = WP_MCP_AI_Analytics_Cache::instance();
		$stats = $cache->get_stats();

		$hit_rate = isset( $stats['hit_rate'] ) ? $stats['hit_rate'] : 0;
		$hits     = isset( $stats['hits'] ) ? $stats['hits'] : 0;
		$misses   = isset( $stats['misses'] ) ? $stats['misses'] : 0;
		$sets     = isset( $stats['sets'] ) ? $stats['sets'] : 0;

		$rate_color = $hit_rate > 70 ? '#46b450' : ( $hit_rate > 30 ? '#f0ad4e' : '#dc3232' );

		?>
		<h2><?php esc_html_e( 'Cache Health', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
		<div class="analytics-service-grid">
			<div class="analytics-service-card">
				<h3><?php esc_html_e( 'Cache Hit Rate', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<p style="font-size:28px;font-weight:700;color:<?php echo esc_attr( $rate_color ); ?>;">
					<?php echo esc_html( $hit_rate ); ?>%
				</p>
			</div>
			<div class="analytics-service-card">
				<h3><?php esc_html_e( 'Cache Operations', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<table>
					<tr>
						<th><?php esc_html_e( 'Hits', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						<td><?php echo esc_html( $hits ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Misses', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						<td><?php echo esc_html( $misses ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Sets', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						<td><?php echo esc_html( $sets ); ?></td>
					</tr>
				</table>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the rate limit consumption dashboard.
	 *
	 * @since 1.7.0
	 * @return void
	 */
	private function render_rate_limit_dashboard() {
		if ( ! class_exists( 'WP_MCP_AI_Analytics_Rate_Limiter' ) ) {
			return;
		}

		$limiter   = WP_MCP_AI_Analytics_Rate_Limiter::instance();
		$platforms = array( 'meta', 'twitter', 'linkedin', 'tiktok' );

		?>
		<h2><?php esc_html_e( 'Rate Limits', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
		<div class="analytics-service-grid">
			<?php foreach ( $platforms as $p ) : ?>
				<?php
				$pct    = $limiter->get_usage_pct( $p );
				$config = $limiter->get_limit_config( $p );
				$limit  = $config['limit'];
				$window = $config['window'];
				$hours  = round( $window / 3600, 1 );
				$color  = $pct >= 90 ? '#dc3232' : ( $pct >= 70 ? '#f0ad4e' : '#46b450' );

				$labels = array(
					'meta'     => __( 'Meta (FB/IG)', 'nvdigital-open-operator-system-oos-pro' ),
					'twitter'  => __( 'Twitter/X', 'nvdigital-open-operator-system-oos-pro' ),
					'linkedin' => __( 'LinkedIn', 'nvdigital-open-operator-system-oos-pro' ),
					'tiktok'   => __( 'TikTok', 'nvdigital-open-operator-system-oos-pro' ),
				);
				$name   = isset( $labels[ $p ] ) ? $labels[ $p ] : ucfirst( $p );
				?>
				<div class="analytics-service-card">
					<h3><?php echo esc_html( $name ); ?></h3>
					<div style="background:#f0f0f1;border-radius:4px;height:20px;margin:8px 0;overflow:hidden;">
						<div style="background:<?php echo esc_attr( $color ); ?>;height:100%;width:<?php echo esc_attr( min( $pct, 100 ) ); ?>%;transition:width 0.3s;"></div>
					</div>
					<p style="font-size:12px;margin:0;">
						<?php
						printf(
							/* translators: 1: usage percentage, 2: request limit, 3: hours */
							esc_html__( '%1$s%% of %2$d requests per %3$gh', 'nvdigital-open-operator-system-oos-pro' ),
							esc_html( $pct ),
							absint( $limit ),
							esc_html( $hours )
						);
						?>
					</p>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Proposal 091 Track E — read-only observability series (annotation
	 * totals + recent GenAI span counts) shared by this wp-admin page and
	 * the Pro Dashboards REST controller's `observability` dashboard.
	 *
	 * Annotation totals come from the base annotation store (transcript
	 * post meta, decision D5). Span counts scan the audit activity log
	 * (`wp_mcp_ai_recent_activity`, capped at 100 entries), so they are
	 * labelled "recent" — the log is a bounded ring buffer, not a metric
	 * store.
	 *
	 * @since 1.2.13
	 * @return array<string, int|array> Observability series.
	 */
	public static function get_observability_data() {
		$rows = array();
		if ( class_exists( 'WP_MCP_AI_Annotation_Store' ) ) {
			$rows = WP_MCP_AI_Annotation_Store::export_dataset();
		}

		$positive    = 0;
		$negative    = 0;
		$neutral     = 0;
		$transcripts = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || ! isset( $row['transcript_id'] ) ) {
				continue;
			}
			$transcripts[ absint( $row['transcript_id'] ) ] = true;

			$rating = isset( $row['rating'] ) ? (int) $row['rating'] : 0;
			if ( $rating > 0 ) {
				++$positive;
			} elseif ( $rating < 0 ) {
				++$negative;
			} else {
				++$neutral;
			}
		}

		$spans_chat = 0;
		$spans_tool = 0;
		$activity   = get_option( 'wp_mcp_ai_recent_activity', array() );
		if ( is_array( $activity ) ) {
			foreach ( $activity as $entry ) {
				if ( ! is_array( $entry ) || 'genai_span' !== ( isset( $entry['type'] ) ? $entry['type'] : '' ) ) {
					continue;
				}

				$context   = isset( $entry['context'] ) && is_array( $entry['context'] ) ? $entry['context'] : array();
				$operation = isset( $context['gen_ai.operation.name'] ) ? (string) $context['gen_ai.operation.name'] : '';
				if ( 'execute_tool' === $operation ) {
					++$spans_tool;
				} else {
					++$spans_chat;
				}
			}
		}

		return array(
			'annotations_total'     => count( $rows ),
			'annotations_positive'  => $positive,
			'annotations_negative'  => $negative,
			'annotations_neutral'   => $neutral,
			'transcripts_annotated' => count( $transcripts ),
			'spans_chat'            => $spans_chat,
			'spans_tool'            => $spans_tool,
			'by_rating'             => array(
				'positive' => $positive,
				'neutral'  => $neutral,
				'negative' => $negative,
			),
			'spans_by_operation'    => array(
				'chat'         => $spans_chat,
				'execute_tool' => $spans_tool,
			),
		);
	}

	/**
	 * Render the Proposal 091 observability section (read-only).
	 *
	 * @since 1.2.13
	 * @return void
	 */
	private function render_observability_dashboard() {
		$data = self::get_observability_data();

		?>
		<h2><?php esc_html_e( 'AI Observability (Proposal 091)', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
		<div class="analytics-service-grid">
			<div class="analytics-service-card">
				<h3><?php esc_html_e( 'Chat Annotations', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<table>
					<tr>
						<th><?php esc_html_e( 'Total', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						<td><?php echo esc_html( (int) $data['annotations_total'] ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Positive', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						<td><?php echo esc_html( (int) $data['annotations_positive'] ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Negative', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						<td><?php echo esc_html( (int) $data['annotations_negative'] ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Transcripts', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						<td><?php echo esc_html( (int) $data['transcripts_annotated'] ); ?></td>
					</tr>
				</table>
			</div>
			<div class="analytics-service-card">
				<h3><?php esc_html_e( 'GenAI Spans (recent)', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<table>
					<tr>
						<th><?php esc_html_e( 'Chat', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						<td><?php echo esc_html( (int) $data['spans_chat'] ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Tool', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						<td><?php echo esc_html( (int) $data['spans_tool'] ); ?></td>
					</tr>
				</table>
				<p style="font-size:12px;color:#555;">
					<?php esc_html_e( 'Counts scan the audit activity log (last 100 events) and require logging to be enabled.', 'nvdigital-open-operator-system-oos-pro' ); ?>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render manual cache invalidation actions.
	 *
	 * @since 1.7.0
	 * @return void
	 */
	private function render_cache_actions() {
		if ( ! class_exists( 'WP_MCP_AI_Analytics_Cache' ) ) {
			return;
		}

		$cleared = false;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['clear_analytics_cache'] ) && current_user_can( 'manage_options' ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$platform = sanitize_text_field( wp_unslash( $_GET['clear_analytics_cache'] ) );
			$service  = WP_MCP_AI_Analytics_Service::instance();
			$service->invalidate_cache( $platform );
			$cleared = true;
		}

		?>
		<h2><?php esc_html_e( 'Cache Management', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>

		<?php if ( $cleared ) : ?>
			<div class="notice notice-success is-dismissible">
				<p><?php esc_html_e( 'Cache cleared successfully.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
			</div>
		<?php endif; ?>

		<div class="analytics-service-card" style="max-width:600px;">
			<h3><?php esc_html_e( 'Invalidate Cache by Platform', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<p class="description" style="margin-bottom:12px;">
				<?php esc_html_e( 'Clear cached analytics data for a specific platform. New data will be fetched on the next analytics request.', 'nvdigital-open-operator-system-oos-pro' ); ?>
			</p>
			<?php
			$platforms = array( 'meta', 'twitter', 'linkedin', 'tiktok', 'facebook', 'instagram', 'woocommerce', 'google_analytics', 'cloudways' );
			$labels    = array(
				'meta'             => __( 'Meta (All)', 'nvdigital-open-operator-system-oos-pro' ),
				'facebook'         => __( 'Facebook', 'nvdigital-open-operator-system-oos-pro' ),
				'instagram'        => __( 'Instagram', 'nvdigital-open-operator-system-oos-pro' ),
				'twitter'          => __( 'Twitter/X', 'nvdigital-open-operator-system-oos-pro' ),
				'linkedin'         => __( 'LinkedIn', 'nvdigital-open-operator-system-oos-pro' ),
				'tiktok'           => __( 'TikTok', 'nvdigital-open-operator-system-oos-pro' ),
				'woocommerce'      => __( 'WooCommerce', 'nvdigital-open-operator-system-oos-pro' ),
				'google_analytics' => __( 'Google Analytics', 'nvdigital-open-operator-system-oos-pro' ),
				'cloudways'        => __( 'Cloudways', 'nvdigital-open-operator-system-oos-pro' ),
			);

			foreach ( $platforms as $p ) :
				$label = isset( $labels[ $p ] ) ? $labels[ $p ] : ucfirst( $p );
				$url   = add_query_arg(
					array(
						'page'                  => self::PAGE_SLUG,
						'clear_analytics_cache' => $p,
						'_wpnonce'              => wp_create_nonce( 'analytics_clear_cache_' . $p ),
					),
					admin_url( 'admin.php' )
				);
				?>
				<a href="<?php echo esc_url( $url ); ?>" class="button button-small" style="margin:2px 4px 4px 0;">
					<?php
					printf(
						/* translators: %s: platform name */
						esc_html__( 'Clear %s', 'nvdigital-open-operator-system-oos-pro' ),
						esc_html( $label )
					);
					?>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
