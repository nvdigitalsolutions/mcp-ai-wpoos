<?php
/**
 * Media Collection Custom Post Type for managing grouped media items.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and manages the Media Collection custom post type.
 */
class WP_MCP_AI_Media_Collection_CPT {
	/**
	 * Post type slug.
	 *
	 * @var string
	 */
	const POST_TYPE = 'mcp_ai_media_coll';

	/**
	 * Taxonomy for collection categories.
	 *
	 * @var string
	 */
	const TAXONOMY_CATEGORY = 'mcp_ai_coll_category';

	/**
	 * Metabox instances.
	 *
	 * @var array
	 */
	protected static $metaboxes = array();

	/**
	 * Initialize the class.
	 */
	public static function init() {
		// Always register post type and show notices, so admin pages are visible.
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'init', array( __CLASS__, 'register_taxonomy' ) );
		add_action( 'admin_notices', array( __CLASS__, 'show_disabled_notice' ) );

		// Check if feature is available and enabled before initializing full functionality.
		// Only available in Full Version (not Base Version), unless Pro addon is active.
		// When Pro addon is active (WP_MCP_AI_PRO_VERSION defined), features should work even in base mode.
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			// Base version without Pro - only show notices, don't initialize functionality.
			return;
		}

		// Check if media toolkit is enabled in settings.
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_media_toolkit'] ) ) {
			// Feature disabled - only show notices, don't initialize functionality.
			return;
		}

		// Feature is available and enabled - initialize full functionality.
		add_action( 'add_meta_boxes', array( __CLASS__, 'register_meta_boxes' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_collection_meta' ), 5, 2 );
		add_action( 'admin_notices', array( __CLASS__, 'show_info_notice' ) );
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( __CLASS__, 'add_admin_columns' ) );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'render_admin_columns' ), 10, 2 );

		// Phase 4: Bulk actions and admin enhancements.
		add_filter( 'bulk_actions-edit-' . self::POST_TYPE, array( __CLASS__, 'add_bulk_actions' ) );
		add_filter( 'handle_bulk_actions-edit-' . self::POST_TYPE, array( __CLASS__, 'handle_bulk_actions' ), 10, 3 );
		add_filter( 'post_row_actions', array( __CLASS__, 'add_row_actions' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'wp_ajax_mcp_ai_quick_process_collection', array( __CLASS__, 'ajax_quick_process_collection' ) );

		// Load metabox classes.
		self::load_metabox_classes();
	}

	/**
	 * Show admin notice when media toolkit is disabled but user tries to access collection pages.
	 */
	public static function show_disabled_notice() {
		// Only show on media collection-related pages.
		$screen = get_current_screen();
		if ( ! $screen ) {
			return;
		}

		// Check if we're on a media collection post type page.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Just checking URL parameter for display logic.
		$post_type          = isset( $_GET['post_type'] ) ? sanitize_key( $_GET['post_type'] ) : '';
		$is_collection_page = ( self::POST_TYPE === $post_type );
		if ( ! $is_collection_page && self::POST_TYPE !== $screen->post_type ) {
			return;
		}

		// Check if in Base Version without Pro addon.
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			?>
			<div class="notice notice-warning">
				<p>
					<strong><?php esc_html_e( 'Media Collections Not Available', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
				</p>
				<p>
					<?php
					echo wp_kses_post(
						__( 'Media Collections are a <strong>Full Version</strong> feature and not available in Base Version mode.', 'nvdigital-open-operator-system-oos-pro' )
					);
					?>
				</p>
				<p>
					<?php
					echo wp_kses_post(
						sprintf(
							/* translators: %s: Code snippet */
							__( 'To use Media Collections, remove or set to <code>false</code> the following constant in your <code>wp-config.php</code>: %s', 'nvdigital-open-operator-system-oos-pro' ),
							'<code>define( \'WP_MCP_AI_BASE_VERSION\', true );</code>'
						)
					);
					?>
				</p>
			</div>
			<?php
			return;
		}

		// Check if feature is disabled.
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_media_toolkit'] ) ) {
			$settings_url = admin_url( 'admin.php?page=wp_mcp_ai_settings&tab=tools' );
			?>
			<div class="notice notice-warning">
				<p>
					<strong><?php esc_html_e( 'Media Toolkit Disabled', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
				</p>
				<p>
					<?php esc_html_e( 'Media Collections require the Media Toolkit to be enabled.', 'nvdigital-open-operator-system-oos-pro' ); ?>
				</p>
				<p>
					<?php
					echo wp_kses_post(
						sprintf(
							/* translators: %s: Link to settings page */
							__( 'To enable Media Collections, go to <a href="%s">Settings &rarr; NV oOS &rarr; Tools &amp; Features</a>, click the <strong>Features</strong> tab, check <strong>"Enable Media Toolkit"</strong>, and save your changes.', 'nvdigital-open-operator-system-oos-pro' ),
							esc_url( $settings_url )
						)
					);
					?>
				</p>
			</div>
			<?php
		}
	}

	/**
	 * Load metabox classes.
	 */
	protected static function load_metabox_classes() {
		// Load base metabox class (reuse template base).
		require_once WP_MCP_AI_PRO_PATH . 'includes/metaboxes/class-wp-mcp-ai-media-template-metabox-base.php';

		// Load metabox implementations.
		require_once WP_MCP_AI_PRO_PATH . 'includes/metaboxes/class-wp-mcp-ai-media-collection-metabox-items.php';
		require_once WP_MCP_AI_PRO_PATH . 'includes/metaboxes/class-wp-mcp-ai-media-collection-metabox-operations.php';
		require_once WP_MCP_AI_PRO_PATH . 'includes/metaboxes/class-wp-mcp-ai-media-collection-metabox-stats.php';

		// Initialize metabox instances.
		self::$metaboxes['items']      = new WP_MCP_AI_Media_Collection_Metabox_Items();
		self::$metaboxes['operations'] = new WP_MCP_AI_Media_Collection_Metabox_Operations();
		self::$metaboxes['stats']      = new WP_MCP_AI_Media_Collection_Metabox_Stats();
	}

	/**
	 * Register meta boxes for collection editing.
	 */
	public static function register_meta_boxes() {
		$screen = get_current_screen();

		// Only add metaboxes on collection edit screen.
		if ( ! $screen || self::POST_TYPE !== $screen->post_type ) {
			return;
		}

		// Register each metabox.
		foreach ( self::$metaboxes as $metabox ) {
			add_meta_box(
				$metabox->get_id(),
				$metabox->get_title(),
				array( $metabox, 'render' ),
				self::POST_TYPE,
				$metabox->get_context(),
				$metabox->get_priority()
			);
		}
	}

	/**
	 * Save collection meta data from metaboxes.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 */
	public static function save_collection_meta( $post_id, $post ) {
		// Check if this is an autosave.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Check post type.
		if ( self::POST_TYPE !== $post->post_type ) {
			return;
		}

		// Check permissions.
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Call save method on each metabox.
		foreach ( self::$metaboxes as $metabox ) {
			$metabox->save( $post_id, $post );
		}
	}

	/**
	 * Show informational notice on collection edit screen.
	 */
	public static function show_info_notice() {
		$screen = get_current_screen();

		// Only show on collection edit screens.
		if ( ! $screen || ! in_array( $screen->id, array( self::POST_TYPE, 'edit-' . self::POST_TYPE ), true ) ) {
			return;
		}

		// Don't show if feature is disabled (other notice will show).
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_media_toolkit'] ) ) {
			return;
		}
		?>
		<div class="notice notice-info media-collection-info-notice">
			<p>
				<strong><?php esc_html_e( 'Media Collection Management', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
			</p>
			<p>
				<?php esc_html_e( 'Media collections let you group related images together and apply operations or templates to all items at once. Perfect for batch processing social media images, product photos, or blog post graphics.', 'nvdigital-open-operator-system-oos-pro' ); ?>
			</p>
			<p>
				<?php
				echo wp_kses_post(
					__( '<strong>Use Cases:</strong> Social media campaigns, product photo editing, event galleries, seasonal promotions, brand asset management', 'nvdigital-open-operator-system-oos-pro' )
				);
				?>
			</p>
			<p>
				<?php
				echo wp_kses_post(
					__( '<strong>AI Tools:</strong> Use <code>apply_collection_template</code>, <code>process_collection</code>, and <code>list_collections</code> tools to work with collections via chat.', 'nvdigital-open-operator-system-oos-pro' )
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Register Media Collection custom post type.
	 */
	public static function register_post_type() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'             => array(
					'name'               => _x( 'Media Collections', 'post type general name', 'nvdigital-open-operator-system-oos-pro' ),
					'singular_name'      => _x( 'Media Collection', 'post type singular name', 'nvdigital-open-operator-system-oos-pro' ),
					'menu_name'          => _x( 'Collections', 'admin menu', 'nvdigital-open-operator-system-oos-pro' ),
					'name_admin_bar'     => _x( 'Media Collection', 'add new on admin bar', 'nvdigital-open-operator-system-oos-pro' ),
					'add_new'            => _x( 'Add New', 'media collection', 'nvdigital-open-operator-system-oos-pro' ),
					'add_new_item'       => __( 'Add New Collection', 'nvdigital-open-operator-system-oos-pro' ),
					'new_item'           => __( 'New Collection', 'nvdigital-open-operator-system-oos-pro' ),
					'edit_item'          => __( 'Edit Collection', 'nvdigital-open-operator-system-oos-pro' ),
					'view_item'          => __( 'View Collection', 'nvdigital-open-operator-system-oos-pro' ),
					'all_items'          => __( 'All Collections', 'nvdigital-open-operator-system-oos-pro' ),
					'search_items'       => __( 'Search Collections', 'nvdigital-open-operator-system-oos-pro' ),
					'parent_item_colon'  => __( 'Parent Collections:', 'nvdigital-open-operator-system-oos-pro' ),
					'not_found'          => __( 'No collections found.', 'nvdigital-open-operator-system-oos-pro' ),
					'not_found_in_trash' => __( 'No collections found in Trash.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'description'        => __( 'Grouped media items for batch processing with templates.', 'nvdigital-open-operator-system-oos-pro' ),
				'public'             => false,
				'publicly_queryable' => false,
				'show_ui'            => true,
				'show_in_menu'       => 'upload.php',
				'menu_icon'          => 'dashicons-images-alt2',
				'query_var'          => false,
				'rewrite'            => false,
				'capability_type'    => 'post',
				'has_archive'        => false,
				'hierarchical'       => false,
				'menu_position'      => null,
				'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
				'show_in_rest'       => false,
			)
		);
	}

	/**
	 * Register taxonomy for collection categories.
	 */
	public static function register_taxonomy() {
		register_taxonomy(
			self::TAXONOMY_CATEGORY,
			array( self::POST_TYPE ),
			array(
				'labels'            => array(
					'name'              => _x( 'Collection Categories', 'taxonomy general name', 'nvdigital-open-operator-system-oos-pro' ),
					'singular_name'     => _x( 'Category', 'taxonomy singular name', 'nvdigital-open-operator-system-oos-pro' ),
					'search_items'      => __( 'Search Categories', 'nvdigital-open-operator-system-oos-pro' ),
					'all_items'         => __( 'All Categories', 'nvdigital-open-operator-system-oos-pro' ),
					'parent_item'       => __( 'Parent Category', 'nvdigital-open-operator-system-oos-pro' ),
					'parent_item_colon' => __( 'Parent Category:', 'nvdigital-open-operator-system-oos-pro' ),
					'edit_item'         => __( 'Edit Category', 'nvdigital-open-operator-system-oos-pro' ),
					'update_item'       => __( 'Update Category', 'nvdigital-open-operator-system-oos-pro' ),
					'add_new_item'      => __( 'Add New Category', 'nvdigital-open-operator-system-oos-pro' ),
					'new_item_name'     => __( 'New Category Name', 'nvdigital-open-operator-system-oos-pro' ),
					'menu_name'         => __( 'Categories', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'hierarchical'      => true,
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => false,
				'rewrite'           => false,
				'show_in_rest'      => false,
			)
		);
	}

	/**
	 * Add custom admin columns.
	 *
	 * @param array $columns Existing columns.
	 * @return array Modified columns.
	 */
	public static function add_admin_columns( $columns ) {
		$new_columns = array();

		foreach ( $columns as $key => $label ) {
			$new_columns[ $key ] = $label;

			if ( 'title' === $key ) {
				$new_columns['item_count']     = __( 'Items', 'nvdigital-open-operator-system-oos-pro' );
				$new_columns['templates']      = __( 'Templates', 'nvdigital-open-operator-system-oos-pro' );
				$new_columns['last_processed'] = __( 'Last Processed', 'nvdigital-open-operator-system-oos-pro' );
			}
		}

		return $new_columns;
	}

	/**
	 * Render custom admin columns.
	 *
	 * @param string $column  Column name.
	 * @param int    $post_id Post ID.
	 */
	public static function render_admin_columns( $column, $post_id ) {
		switch ( $column ) {
			case 'item_count':
				$items = get_post_meta( $post_id, '_mcp_ai_collection_items', true );
				$count = is_array( $items ) ? count( $items ) : 0;
				echo '<strong>' . esc_html( number_format_i18n( $count ) ) . '</strong>';
				break;

			case 'templates':
				$templates = get_post_meta( $post_id, '_mcp_ai_collection_templates', true );
				if ( is_array( $templates ) && ! empty( $templates ) ) {
					echo '<span class="dashicons dashicons-yes-alt" style="color: #00a32a;"></span> ';
					echo esc_html( number_format_i18n( count( $templates ) ) );
				} else {
					echo '<span style="color: #646970;">—</span>';
				}
				break;

			case 'last_processed':
				$last_processed = get_post_meta( $post_id, '_mcp_ai_collection_last_processed', true );
				if ( ! empty( $last_processed ) ) {
					$timestamp = is_numeric( $last_processed ) ? absint( $last_processed ) : strtotime( $last_processed );
					echo esc_html( human_time_diff( $timestamp, current_time( 'timestamp' ) ) . ' ' . __( 'ago', 'nvdigital-open-operator-system-oos-pro' ) );
				} else {
					echo '<em>' . esc_html__( 'Never', 'nvdigital-open-operator-system-oos-pro' ) . '</em>';
				}
				break;
		}
	}

	/**
	 * Add bulk actions for media collections (Phase 4).
	 *
	 * @param array $actions Existing bulk actions.
	 * @return array Modified bulk actions.
	 */
	public static function add_bulk_actions( $actions ) {
		$actions['process_collections'] = __( 'Process Collections', 'nvdigital-open-operator-system-oos-pro' );
		$actions['export_collections']  = __( 'Export', 'nvdigital-open-operator-system-oos-pro' );
		return $actions;
	}

	/**
	 * Handle bulk actions for media collections (Phase 4).
	 *
	 * @param string $redirect_to Redirect URL.
	 * @param string $doaction    Action being taken.
	 * @param array  $post_ids    Array of post IDs.
	 * @return string Modified redirect URL.
	 */
	public static function handle_bulk_actions( $redirect_to, $doaction, $post_ids ) {
		if ( 'process_collections' === $doaction ) {
			// Process collections using the process_collection tool.
			$processed = 0;
			$errors    = 0;

			// Load tool.
			if ( ! class_exists( 'WP_MCP_AI_Tool_Process_Collection' ) ) {
				require_once WP_MCP_AI_PRO_PATH . 'includes/tools/media/class-wp-mcp-ai-tool-process-collection.php';
			}

			$tool = new WP_MCP_AI_Tool_Process_Collection();

			foreach ( $post_ids as $post_id ) {
				$result = $tool->execute(
					array( 'collection_id' => $post_id ),
					array( 'user_id' => get_current_user_id() )
				);

				if ( is_wp_error( $result ) || empty( $result['success'] ) ) {
					++$errors;
				} else {
					++$processed;
				}
			}

			$redirect_to = add_query_arg( 'processed_collections', $processed, $redirect_to );
			if ( $errors > 0 ) {
				$redirect_to = add_query_arg( 'processing_errors', $errors, $redirect_to );
			}
		} elseif ( 'export_collections' === $doaction ) {
			// Export collections as JSON.
			$collections = array();
			foreach ( $post_ids as $post_id ) {
				$post = get_post( $post_id );
				if ( $post && self::POST_TYPE === $post->post_type ) {
					$collections[] = array(
						'title'       => $post->post_title,
						'description' => $post->post_content,
						'items'       => get_post_meta( $post_id, '_mcp_ai_collection_items', true ),
						'templates'   => get_post_meta( $post_id, '_mcp_ai_collection_templates', true ),
						'categories'  => wp_get_object_terms( $post_id, self::TAXONOMY_CATEGORY, array( 'fields' => 'names' ) ),
					);
				}
			}

			if ( ! empty( $collections ) ) {
				// Store in transient for download.
				$transient_key = 'mcp_ai_collection_export_' . get_current_user_id();
				set_transient( $transient_key, wp_json_encode( $collections, JSON_PRETTY_PRINT ), HOUR_IN_SECONDS );
				$redirect_to = add_query_arg( 'exported_collections', count( $collections ), $redirect_to );
				$redirect_to = add_query_arg( 'export_key', $transient_key, $redirect_to );
			}
		}

		return $redirect_to;
	}

	/**
	 * Add custom row actions (Phase 4).
	 *
	 * @param array   $actions Existing actions.
	 * @param WP_Post $post    Post object.
	 * @return array Modified actions.
	 */
	public static function add_row_actions( $actions, $post ) {
		if ( self::POST_TYPE === $post->post_type ) {
			// Add quick process action.
			$actions['quick_process'] = sprintf(
				'<a href="#" class="quick-process-collection" data-collection-id="%d">%s</a>',
				$post->ID,
				__( 'Quick Process', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		return $actions;
	}

	/**
	 * Enqueue admin assets (Phase 4).
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function enqueue_admin_assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->id, array( self::POST_TYPE, 'edit-' . self::POST_TYPE ), true ) ) {
			return;
		}

		// Enqueue admin CSS (shared with templates).
		wp_enqueue_style(
			'mcp-ai-media-collection-admin',
			WP_MCP_AI_PRO_URL . 'assets/css/media-template-admin.css',
			array(),
			WP_MCP_AI_PRO_VERSION
		);

		// Enqueue admin JS.
		wp_enqueue_script(
			'mcp-ai-media-collection-admin',
			WP_MCP_AI_PRO_URL . 'assets/js/media-collection-admin.js',
			array( 'jquery' ),
			WP_MCP_AI_PRO_VERSION,
			true
		);

		// Localize script.
		wp_localize_script(
			'mcp-ai-media-collection-admin',
			'mcpAiMediaCollection',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'mcp_ai_media_collection_admin' ),
				'i18n'    => array(
					'processSuccess' => __( 'Collection processed successfully!', 'nvdigital-open-operator-system-oos-pro' ),
					'processError'   => __( 'Failed to process collection.', 'nvdigital-open-operator-system-oos-pro' ),
					'processing'     => __( 'Processing collection...', 'nvdigital-open-operator-system-oos-pro' ),
					'confirmProcess' => __( 'Are you sure you want to process this collection? This will apply all assigned templates to all items.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			)
		);
	}

	/**
	 * AJAX handler for quick process collection (Phase 4).
	 */
	public static function ajax_quick_process_collection() {
		// Check nonce.
		check_ajax_referer( 'mcp_ai_media_collection_admin', 'nonce' );

		// Check permissions.
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'nvdigital-open-operator-system-oos-pro' ) ) );
		}

		// Get collection ID.
		$collection_id = isset( $_POST['collection_id'] ) ? absint( $_POST['collection_id'] ) : 0;
		if ( ! $collection_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid collection ID.', 'nvdigital-open-operator-system-oos-pro' ) ) );
		}

		// Use the process_collection tool.
		if ( ! class_exists( 'WP_MCP_AI_Tool_Process_Collection' ) ) {
			require_once WP_MCP_AI_PRO_PATH . 'includes/tools/media/class-wp-mcp-ai-tool-process-collection.php';
		}

		$tool   = new WP_MCP_AI_Tool_Process_Collection();
		$result = $tool->execute(
			array( 'collection_id' => $collection_id ),
			array( 'user_id' => get_current_user_id() )
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		if ( ! empty( $result['success'] ) ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}
}
