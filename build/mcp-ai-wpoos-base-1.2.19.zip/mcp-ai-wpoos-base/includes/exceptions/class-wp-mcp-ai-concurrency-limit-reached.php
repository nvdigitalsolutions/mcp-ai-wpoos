<?php
/**
 * Concurrency Limit Reached Exception
 *
 * Thrown by the ConcurrencyGuard subscriber when a tool execution would
 * exceed the per-operation-type concurrent execution limit. Caught by
 * the REST handler and converted to a WP_Error envelope (HTTP 429).
 *
 * @package WP_MCP_AI
 * @since   1.1.44
 *
 * @license GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Exception for concurrency limit violations.
 */
class WP_MCP_AI_Concurrency_Limit_Reached extends Exception {

	/**
	 * Operation type that reached its limit.
	 *
	 * @var string
	 */
	private $operation_type;

	/**
	 * Constructor.
	 *
	 * @param string $operation_type Concurrency operation type (e.g. 'image_generation').
	 * @param string $message        Human-readable error message.
	 */
	public function __construct( $operation_type, $message ) {
		parent::__construct( $message, 429 );
		$this->operation_type = $operation_type;
	}

	/**
	 * Get the operation type that triggered the limit.
	 *
	 * @return string
	 */
	public function get_operation_type() {
		return $this->operation_type;
	}

	/**
	 * Convert to a WP_Error suitable for REST response envelopes.
	 *
	 * @return WP_Error
	 */
	public function to_wp_error() {
		return new WP_Error(
			'concurrency_limit',
			$this->getMessage(),
			array(
				'status'         => 429,
				'operation_type' => $this->operation_type,
				'retry_after'    => 30,
			)
		);
	}
}
