<?php
/**
 * Tool for analyzing and optimizing long code sequences.
 *
 * Part of Phase 3.3: Reasoning Tools implementation.
 *
 * @package WP_MCP_AI
 * @since 1.1.1
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Analyze Code Sequence Tool
 *
 * Analyzes code for optimization opportunities, validates syntax and security,
 * and provides recommendations. Uses the Code Optimizer service for comprehensive
 * code analysis.
 *
 * @since 1.1.1
 */
class WP_MCP_AI_Tool_Analyze_Code_Sequence implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'analyze_code_sequence';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Analyze Code Sequence', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Analyzes and optimizes long code sequences. Performs syntax validation, WordPress Coding Standards checking, security scanning (eval, SQL injection, XSS, file inclusion), and provides improvement suggestions. Supports PHP and identifies patterns, issues, and optimization opportunities.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Validating and reviewing a code snippet for syntax, style, and security issues before use or deployment.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Running code or auditing the site environment; use check_site_security for site-level hardening checks.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'check_site_security', 'analyze_file_suitability' ),
			'notes'           => __( 'Only PHP gets full validation; other languages are checked heuristically. Input is a code string, not a file path.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'code'         => array(
					'type'        => 'string',
					'description' => __( 'Code to analyze and validate.', 'nvdigital-open-operator-system-oos' ),
				),
				'language'     => array(
					'type'        => 'string',
					'description' => __( 'Programming language of the code (php, javascript, python, etc.). Only php has full validation support.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'php',
				),
				'requirements' => array(
					'type'        => 'array',
					'description' => __( 'Optional list of requirements to verify against the code.', 'nvdigital-open-operator-system-oos' ),
					'items'       => array(
						'type' => 'string',
					),
				),
			),
			'required'   => array( 'code' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'developer_technical',

			'pattern_compatibility' => array( 'sequential' ),

			'profession_tags'       => array( 'software_developer', 'qa_engineer' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',   // Only analyzes code, no mutations.
			'local-only',  // No external API calls.
			'idempotent',  // Same input = same output.
			'cacheable',   // Deterministic results can be cached.
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array Tool execution result.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Validate required parameters.
		if ( empty( $arguments['code'] ) ) {
			return new WP_Error(
				'missing_parameter',
				__( 'Code parameter is required.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 400 )
			);
		}

		$code         = $arguments['code'];
		$language     = sanitize_text_field( $arguments['language'] ?? 'php' );
		$requirements = $arguments['requirements'] ?? array();

		// Get code optimizer instance.
		if ( ! class_exists( 'WP_MCP_AI_Code_Optimizer' ) ) {
			return new WP_Error(
				'service_unavailable',
				__( 'Code Optimizer service is not available.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 503 )
			);
		}

		$code_optimizer = new WP_MCP_AI_Code_Optimizer();

		// Validate the code.
		$validation_result = $code_optimizer->validate_code( $code, $language, $requirements );

		// Build analysis result.
		$result = array(
			'language'           => $language,
			'code_length'        => strlen( $code ),
			'validation'         => $validation_result,
			'analysis_timestamp' => current_time( 'mysql' ),
		);

		// Generate summary message.
		$issues_count      = count( $validation_result['issues'] ?? array() );
		$suggestions_count = count( $validation_result['suggestions'] ?? array() );
		$security_count    = count( $validation_result['security'] ?? array() );

		if ( $validation_result['valid'] ) {
			$message = sprintf(
				/* translators: %d: number of suggestions */
				__( 'Code analysis complete. Code is syntactically valid. Found %d suggestions for improvement.', 'nvdigital-open-operator-system-oos' ),
				$suggestions_count
			);
		} else {
			$total_issues = $issues_count + $security_count;
			$message      = sprintf(
				/* translators: 1: number of issues, 2: number of security issues */
				__( 'Code analysis complete. Found %1$d validation issues (including %2$d security concerns). Review and address these issues before deployment.', 'nvdigital-open-operator-system-oos' ),
				$total_issues,
				$security_count
			);
		}

		$result['message'] = $message;

		// Add detailed breakdown.
		$result['summary'] = array(
			'valid'             => $validation_result['valid'],
			'syntax_errors'     => $issues_count,
			'style_suggestions' => $suggestions_count,
			'security_issues'   => $security_count,
		);

		if ( $security_count > 0 ) {
			$result['security_alert'] = __( 'SECURITY WARNING: Code contains potential vulnerabilities. Review security issues before use.', 'nvdigital-open-operator-system-oos' );
		}

		return $this->format_chat_response( $result, $message );
	}
}
