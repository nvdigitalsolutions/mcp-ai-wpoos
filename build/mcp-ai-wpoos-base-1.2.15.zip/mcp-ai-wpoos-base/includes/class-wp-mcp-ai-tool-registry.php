<?php
/**
 * Tool registry singleton.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

wp_mcp_ai_require_if_exists( WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php' );
wp_mcp_ai_require_if_exists( WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-db-output-guard.php' );
wp_mcp_ai_require_if_exists( WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-envelope.php' );
wp_mcp_ai_require_if_exists( WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php' );
wp_mcp_ai_require_if_exists( WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-product-card.php' );

if ( ! class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
	/**
	 * Maintains a list of available tool providers.
	 */
	class WP_MCP_AI_Tool_Registry {
		/**
		 * Singleton instance.
		 *
		 * @var WP_MCP_AI_Tool_Registry
		 */
		protected static $instance = null;

		/**
		 * Registered tools keyed by slug.
		 *
		 * @var WP_MCP_AI_Tool_Interface[]
		 */
		protected $tools = array();

		/**
		 * Whether the registry has been initialised.
		 *
		 * @var bool
		 */
		protected $bootstrapped = false;

		/**
		 * Whether the default tool suite has been loaded (eagerly at init() or
		 * lazily via ensure_default_tools_loaded()).
		 *
		 * @var bool
		 */
		protected $default_tools_loaded = false;

		/**
		 * Whether defaults are currently being loaded in deferred mode, in
		 * which third-party tools registered via the wp_mcp_ai_register_tools
		 * / wp_mcp_ai_tools_init hooks win slug conflicts over defaults.
		 *
		 * @var bool
		 */
		protected $deferred_loading = false;

		/**
		 * Human readable messages describing tools that were skipped.
		 *
		 * @var string[]
		 */
		protected $unavailable_tool_messages = array();

		/**
		 * Slugs of tools skipped during registration because their
		 * availability check failed (plugin-gated tools, missing credentials).
		 *
		 * Kept separate from the messages so callers (tests, admin UI) can
		 * programmatically distinguish "known but unavailable" from
		 * "never registered".
		 *
		 * @var string[]
		 */
		protected $unavailable_tool_slugs = array();

		/**
		 * Deprecated tool aliases keyed by the old slug.
		 *
		 * Used by Phase P5 Part 2 (tool decomposition) so that splitting a tool
		 * into focused sub-tools does not break assistants that still reference
		 * the old slug. Aliases are *not* exposed to the LLM payload assembler —
		 * the model only sees the new sub-tools — but they resolve transparently
		 * when an old slug is requested via {@see self::get_tool()}.
		 *
		 * Each entry is an array of the shape:
		 *   array(
		 *     'new_slug' => string,  // Required. Slug of the replacement tool.
		 *     'since'    => string,  // Optional. Version where the alias was introduced.
		 *     'remove'   => string,  // Optional. Version where the alias will be removed.
		 *     'message'  => string,  // Optional. Human-readable migration note.
		 *   )
		 *
		 * @since 1.2.2
		 * @var array<string, array{new_slug:string, since:string, remove:string, message:string}>
		 */
		protected $deprecated_aliases = array();

		/**
		 * Set of deprecated slugs whose invocation has already fired the
		 * {@see 'wp_mcp_ai_tool_deprecated_alias_invoked'} action during the
		 * current request, used to throttle the hook to once-per-(request, slug).
		 *
		 * @since 1.2.2
		 * @var array<string, bool>
		 */
		protected $deprecated_alias_invocations = array();

		/**
		 * Retrieve the singleton instance.
		 *
		 * @return WP_MCP_AI_Tool_Registry
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Prevent direct construction.
		 */
		protected function __construct() {}

		/**
		 * Prevent cloning.
		 */
		protected function __clone() {}

		/**
		 * Prevent unserialisation.
		 */
		public function __wakeup() {} // phpcs:ignore PSR2.Methods.MethodDeclaration.Underscore -- Double-underscore magic method (__wakeup/__clone) required by PHP serialization interface; PSR-2 exception for magic methods.

		/**
		 * Initialise the registry by loading default tools and triggering hooks.
		 */
		public function init() {
			if ( $this->bootstrapped ) {
				return;
			}

			$this->bootstrapped = true;

			$eager_load = $this->should_eager_load_default_tools();

			if ( $eager_load ) {
				$this->load_default_tools();
			}

			if ( is_admin() && ! empty( $this->unavailable_tool_messages ) ) {
				// Register admin_notices on init to avoid early translation loading (WordPress 6.7.0+).
				add_action( 'init', array( $this, 'register_admin_notices' ) );
			}

			if ( $eager_load ) {
				/**
				 * Allow third parties to register additional tools.
				 *
				 * @param WP_MCP_AI_Tool_Registry $registry Registry instance.
				 */
				do_action( 'wp_mcp_ai_register_tools', $this );

				/**
				 * Fires after default and third-party tool registration so
				 * side-loaders (e.g. the core orchestration tools registered by
				 * includes/orchestration-init.php) can register their tools.
				 *
				 * @since 1.2.0
				 *
				 * @param WP_MCP_AI_Tool_Registry $registry Registry instance.
				 */
				do_action( 'wp_mcp_ai_tools_init', $this );

				// Auto-disable tools marked with "bug" status.
				$this->auto_disable_bug_tools();

				$this->default_tools_loaded = true;
			}
		}

		/**
		 * Whether the default tool suite should be loaded eagerly at init().
		 *
		 * Defers the ~350 default tool class loads on plain front-end page views
		 * (which render no server-side AI features); the suite is loaded lazily by
		 * {@see self::ensure_default_tools_loaded()} on first actual use. The
		 * wp_mcp_ai_is_plugin_runtime_context filter forces eager loading.
		 *
		 * @since 1.1.96
		 *
		 * @return bool True when the default tool suite should load eagerly.
		 */
		protected function should_eager_load_default_tools() {
			return wp_mcp_ai_is_plugin_runtime_context();
		}

		/**
		 * Load the default tool suite lazily when it was deferred at init().
		 *
		 * Third-party tools register first (both registration hooks fire before
		 * the defaults), so they win slug conflicts against the default suite.
		 *
		 * @since 1.1.96
		 *
		 * @return void
		 */
		protected function ensure_default_tools_loaded() {
			if ( $this->default_tools_loaded ) {
				return;
			}

			$this->default_tools_loaded = true;
			$this->deferred_loading     = true;

			/**
			 * Allow third parties to register additional tools.
			 *
			 * @param WP_MCP_AI_Tool_Registry $registry Registry instance.
			 */
			do_action( 'wp_mcp_ai_register_tools', $this );

			/**
			 * Fires after third-party tool registration so side-loaders (e.g. the
			 * core orchestration tools registered by includes/orchestration-init.php)
			 * can register their tools before the deferred defaults.
			 *
			 * @since 1.2.0
			 *
			 * @param WP_MCP_AI_Tool_Registry $registry Registry instance.
			 */
			do_action( 'wp_mcp_ai_tools_init', $this );

			$this->load_default_tools();
			$this->auto_disable_bug_tools();

			$this->deferred_loading = false;
		}

		/**
		 * Whether the registry has already been initialised.
		 *
		 * Exposed so read-mostly consumers (e.g. the logger) can decide whether a
		 * tool lookup is free or would trigger the full tool-suite bootstrap as a
		 * side effect.
		 *
		 * @since 1.1.64
		 *
		 * @return bool True when init() has completed at least once.
		 */
		public function is_bootstrapped() {
			return $this->bootstrapped;
		}

		/**
		 * Register admin notices on init action.
		 *
		 * WordPress 6.7.0+ requires translations to be loaded at init or later.
		 */
		public function register_admin_notices() {
			add_action( 'admin_notices', array( $this, 'render_unavailable_tool_notices' ) );
		}

		/**
		 * Render admin notices for tools that were skipped during registration.
		 */
		public function render_unavailable_tool_notices() {
			if ( empty( $this->unavailable_tool_messages ) || ! current_user_can( 'manage_options' ) ) {
				return;
			}

			if ( ! function_exists( 'get_current_screen' ) ) {
				return;
			}

			$screen = get_current_screen();
			if ( ! $screen ) {
				return;
			}

			$allowed_screens = array(
				'plugins',
				'plugins-network',
				'plugin-install',
				'plugin-install-network',
			);

			if ( ! in_array( $screen->id, $allowed_screens, true ) ) {
				return;
			}

			foreach ( $this->unavailable_tool_messages as $message ) {
				if ( empty( $message ) ) {
					continue;
				}

				printf( '<div class="notice notice-info is-dismissible"><p>%s</p></div>', esc_html( $message ) );
			}
		}

		/**
		 * Register a tool implementation.
		 *
		 * @param string|WP_MCP_AI_Tool_Interface $tool Tool class name or instance.
		 * @return bool Whether the tool was registered.
		 */
		public function register_tool( $tool ) {
			if ( is_string( $tool ) ) {
				if ( ! class_exists( $tool ) ) {
					return false;
				}

				$tool = new $tool();
			}

			if ( ! $tool instanceof WP_MCP_AI_Tool_Interface ) {
				// Fail loud: classes without the tool contract are dropped here,
				// which historically shipped broken tools (the legacy-format
				// wait_for_user class reached providers with an empty schema).
				// Log the skip so misconfigured classes surface in the admin
				// error log instead of vanishing silently.
				if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
					WP_MCP_AI_Logger::log_event(
						'error',
						'Tool class was not registered: missing WP_MCP_AI_Tool_Interface.',
						array(
							'class' => is_object( $tool ) ? get_class( $tool ) : (string) $tool,
						)
					);
				}

				return false;
			}

			$slug = sanitize_key( $tool->get_slug() );

			if ( empty( $slug ) ) {
				return false;
			}

			$this->tools[ $slug ] = $tool;
			$this->notify_tools_list_changed();

			/**
			 * Fires after a tool is successfully registered.
			 *
			 * Used by the attention router to trigger async embedding
			 * pre-computation so the semantic head can score tools immediately
			 * on the next request.
			 *
			 * @since 1.8.0
			 *
			 * @param string $slug Tool slug.
			 * @param WP_MCP_AI_Tool_Interface $tool Tool instance.
			 */
			do_action( 'wp_mcp_ai_tool_registered', $slug, $tool );

			return true;
		}

		/**
		 * Unregister a tool by slug.
		 *
		 * @param string $slug Tool slug.
		 */
		public function unregister_tool( $slug ) {
			$slug = sanitize_key( $slug );

			if ( ! isset( $this->tools[ $slug ] ) ) {
				return;
			}

			unset( $this->tools[ $slug ] );
			$this->notify_tools_list_changed();
		}

		/**
		 * Clear all registered tools and reset bootstrap state.
		 *
		 * Used primarily in test tear-down to prevent tool leakage between
		 * tests that share the registry singleton. Also clears unavailable-tool
		 * messages and resets the bootstrapped flag so init() can safely be
		 * called again.
		 *
		 * @return void
		 */
		public function clear_tools() {
			$had_tools = ! empty( $this->tools );

			$this->tools                     = array();
			$this->bootstrapped              = false;
			$this->unavailable_tool_messages = array();
			$this->unavailable_tool_slugs    = array();

			if ( $had_tools ) {
				$this->notify_tools_list_changed();
			}
		}

		/**
		 * Register a deprecated tool alias.
		 *
		 * When Phase P5 Part 2 decomposes a multi-action tool into focused
		 * sub-tools, the old slug is registered as an alias pointing at the most
		 * appropriate replacement so any assistant or saved tool-call referencing
		 * the old slug continues to function for one release cycle. Aliases are
		 * invisible to the LLM payload assembler (the model only sees the new
		 * sub-tools), so re-trained assistants will naturally migrate.
		 *
		 * The action {@see 'wp_mcp_ai_tool_deprecated_alias_invoked'} fires the
		 * first time per request that each alias is resolved, allowing OTel /
		 * activity-log subscribers to count and surface usage.
		 *
		 * @since 1.2.2
		 *
		 * @param string $old_slug Slug of the deprecated tool.
		 * @param string $new_slug Slug of the replacement tool.
		 * @param array  $args     Optional metadata.
		 *     @type string $since   Version where the alias was introduced (e.g. '1.3.0').
		 *     @type string $remove  Version where the alias will be removed (e.g. '1.4.0').
		 *     @type string $message Human-readable migration note.
		 * @return bool True on success, false if either slug is empty / identical.
		 */
		public function register_deprecated_alias( $old_slug, $new_slug, $args = array() ) {
			$old = sanitize_key( $old_slug );
			$new = sanitize_key( $new_slug );

			if ( '' === $old || '' === $new || $old === $new ) {
				return false;
			}

			// Refuse to overwrite an existing real tool — aliases must never
			// shadow a registered slug.
			if ( isset( $this->tools[ $old ] ) ) {
				return false;
			}

			$args = is_array( $args ) ? $args : array();

			$this->deprecated_aliases[ $old ] = array(
				'new_slug' => $new,
				'since'    => isset( $args['since'] ) ? (string) $args['since'] : '',
				'remove'   => isset( $args['remove'] ) ? (string) $args['remove'] : '',
				'message'  => isset( $args['message'] ) ? (string) $args['message'] : '',
			);

			return true;
		}

		/**
		 * Retrieve all registered deprecated aliases.
		 *
		 * @since 1.2.2
		 *
		 * @return array<string, array{new_slug:string, since:string, remove:string, message:string}>
		 */
		public function get_deprecated_aliases() {
			return $this->deprecated_aliases;
		}

		/**
		 * Resolve a slug to its replacement if it is a deprecated alias.
		 *
		 * Fires {@see 'wp_mcp_ai_tool_deprecated_alias_invoked'} exactly once per
		 * (request, $slug) pair so OTel and activity-log subscribers can surface
		 * usage without spamming.
		 *
		 * @since 1.2.2
		 *
		 * @param string $slug Tool slug (sanitized by caller).
		 * @return string Replacement slug if `$slug` is a deprecated alias, otherwise `$slug`.
		 */
		public function resolve_deprecated_alias( $slug ) {
			if ( ! isset( $this->deprecated_aliases[ $slug ] ) ) {
				return $slug;
			}

			$entry = $this->deprecated_aliases[ $slug ];
			$new   = $entry['new_slug'];

			if ( empty( $this->deprecated_alias_invocations[ $slug ] ) ) {
				$this->deprecated_alias_invocations[ $slug ] = true;

				/**
				 * Fires the first time per request that a deprecated tool alias
				 * is resolved to its replacement. Subscribers may log usage,
				 * emit OTel spans, or surface admin notices.
				 *
				 * @since 1.2.2
				 *
				 * @param string $old_slug Deprecated slug that was invoked.
				 * @param string $new_slug Replacement slug the call was rerouted to.
				 * @param array  $entry    Alias metadata: { new_slug, since, remove, message }.
				 */
				do_action( 'wp_mcp_ai_tool_deprecated_alias_invoked', $slug, $new, $entry );
			}

			return $new;
		}

		/**
		 * Clear the once-per-request invocation throttle.
		 *
		 * Intended for test isolation only.
		 *
		 * @since 1.2.2
		 *
		 * @return void
		 */
		public function reset_deprecated_alias_invocations() {
			$this->deprecated_alias_invocations = array();
		}

		/**
		 * Retrieve a tool instance.
		 *
		 * Resolves deprecated aliases registered via {@see self::register_deprecated_alias()}:
		 * if `$slug` is a known alias, the call is transparently rerouted to the
		 * replacement tool and the
		 * {@see 'wp_mcp_ai_tool_deprecated_alias_invoked'} action is fired (once
		 * per request per alias).
		 *
		 * @param string $slug Tool slug. May be a deprecated alias.
		 * @return WP_MCP_AI_Tool_Interface|null
		 */
		public function get_tool( $slug ) {
			// Ensure registry is initialized before retrieving tools.
			$this->init();
			$this->ensure_default_tools_loaded();

			$slug = sanitize_key( $slug );

			$resolved = $this->resolve_deprecated_alias( $slug );

			// Auto-upgrade to validated variant when available.
			// If a tool has a `_validated` counterpart (e.g. generate_openai_image
			// → generate_openai_image_validated), the validated variant is always
			// preferred — it provides the same behaviour with Symfony argument
			// validation. Presets and stored configs only need to reference the
			// base slug; the registry transparently resolves to the validated
			// version at runtime.
			$validated_slug = $resolved . '_validated';
			if ( isset( $this->tools[ $validated_slug ] ) ) {
				$resolved = $validated_slug;
			}

			return isset( $this->tools[ $resolved ] ) ? $this->tools[ $resolved ] : null;
		}

		/**
		 * Retrieve all registered tools.
		 *
		 * @return WP_MCP_AI_Tool_Interface[]
		 */
		public function get_tools() {
			// Ensure registry is initialized before retrieving tools.
			$this->init();
			$this->ensure_default_tools_loaded();

			return array_values( $this->tools );
		}

		/**
		 * List all registered tools.
		 *
		 * Alias for get_tools(). Returns an indexed array of tool instances
		 * suitable for iteration in toolkit registry and other consumers.
		 *
		 * @since 1.1.0
		 *
		 * @return WP_MCP_AI_Tool_Interface[] Array of registered tool instances.
		 */
		public function list_tools() {
			return $this->get_tools();
		}

		/**
		 * Signal MCP clients that the advertised tool list changed.
		 *
		 * Fires {@see 'wp_mcp_ai_mcp_tools_list_changed'} at most once per request
		 * when the registry's tool surface mutates (register/unregister/clear), so
		 * bulk bootstrap registrations collapse into a single signal. This action
		 * is the integration point that backs the `listChanged` capability
		 * advertised by the MCP initialize/discover surface: a future SSE
		 * broadcaster can subscribe here to push
		 * `notifications/tools/list_changed` to connected clients; stateless REST
		 * clients instead re-poll tools/list on its own ttlMs schedule.
		 *
		 * @since 1.2.4
		 *
		 * Intended for internal use (and direct unit testing of the throttle).
		 *
		 * @return void
		 */
		public function notify_tools_list_changed() {
			// did_action() doubles as the per-request throttle: bulk bootstrap
			// registrations collapse into one signal per request, and the counter
			// resets naturally between requests (and between PHPUnit tests).
			if ( did_action( 'wp_mcp_ai_mcp_tools_list_changed' ) > 0 ) {
				return;
			}

			/**
			 * Fires when the registry's MCP tool list changed.
			 *
			 * @since 1.2.4
			 */
			do_action( 'wp_mcp_ai_mcp_tools_list_changed' );
		}

		/**
		 * Retrieve all registered tools as an associative array keyed by slug.
		 *
		 * Use this method when you need to:
		 * - Look up tools by slug using array key access
		 * - Iterate over tools with slug keys (foreach $tools as $slug => $tool)
		 * - Get tool slugs using array_keys()
		 *
		 * Use get_tools() instead when you only need to:
		 * - Count the number of tools
		 * - Iterate over tool objects without needing slugs
		 *
		 * @return WP_MCP_AI_Tool_Interface[] Associative array with slugs as keys.
		 */
		public function get_all_tools() {
			// Ensure registry is initialized before retrieving tools.
			$this->init();
			$this->ensure_default_tools_loaded();

			return $this->tools;
		}

		/**
		 * Execute a tool.
		 *
		 * @param string $slug      Tool slug.
		 * @param array  $arguments Tool arguments.
		 * @param array  $context   Execution context.
		 * @return mixed|WP_Error Tool result or error.
		 */
		public function execute_tool( $slug, $arguments = array(), $context = array() ) {
			$slug = sanitize_key( $slug );
			$tool = $this->get_tool( $slug );

			if ( ! $tool ) {
				return new WP_Error(
					'wp_mcp_ai_tool_not_found',
					sprintf(
						/* translators: %s: tool slug */
						__( 'Tool "%s" not found.', 'mcp-ai-wpoos' ),
						$slug
					)
				);
			}

			// Check if tool is globally enabled.
			if ( ! $this->is_tool_enabled( $slug ) ) {
				return new WP_Error(
					'wp_mcp_ai_tool_disabled',
					sprintf(
						/* translators: %s: tool slug */
						__( 'Tool "%s" is disabled and cannot be executed.', 'mcp-ai-wpoos' ),
						$slug
					)
				);
			}

			// Attempt provider compensation if there's a mismatch.
			$compensation_result = $this->compensate_for_provider_mismatch( $slug, $arguments, $context );
			if ( ! is_wp_error( $compensation_result ) && is_array( $compensation_result ) ) {
				// Provider compensation succeeded - update slug and arguments.
				$slug      = $compensation_result['slug'];
				$arguments = $compensation_result['arguments'];
				$tool      = $this->get_tool( $slug );

				if ( ! $tool ) {
					return new WP_Error(
						'wp_mcp_ai_tool_not_found',
						sprintf(
							/* translators: %s: compensated tool slug */
							__( 'Compensated tool "%s" not found.', 'mcp-ai-wpoos' ),
							$slug
						)
					);
				}
			}

			// Validate tool execution requirements (model, parameters, dependencies).
			$validation_result = $this->validate_tool_execution( $slug, $arguments, $context );
			if ( is_wp_error( $validation_result ) ) {
				return $validation_result;
			}

			// Defense-in-depth: centrally enforce the tool's declared capability.
			// Individual tool execute() methods also check (and must continue to),
			// but this gate prevents a future contributor from shipping a tool
			// that forgets its capability check.
			$required_cap = $tool->get_required_capability();
			if ( ! empty( $required_cap ) ) {
				$acting_user_id = isset( $context['user_id'] )
					? absint( $context['user_id'] )
					: get_current_user_id();

				if ( ! user_can( $acting_user_id, $required_cap ) ) {
					return new WP_Error(
						'wp_mcp_ai_forbidden',
						sprintf(
							/* translators: 1: tool slug, 2: required capability */
							__( 'Tool "%1$s" requires the "%2$s" capability.', 'mcp-ai-wpoos' ),
							$slug,
							$required_cap
						)
					);
				}
			}

			// Auto-async dispatch (Phase 2): if the tool implements the
			// bulk-operation interface and the estimated workload exceeds
			// `wp_mcp_ai_bulk_async_threshold`, queue the call via the async
			// job queue instead of executing inline. Gated behind
			// `WP_MCP_AI_BULK_AUTO_ASYNC` so existing behaviour is preserved
			// until the Phase 4 Action Scheduler integration lands.
			$auto_async = $this->maybe_dispatch_async_bulk( $slug, $tool, $arguments, $context );
			if ( null !== $auto_async ) {
				return $auto_async;
			}

			// Execute the tool with `$wpdb` error output suppressed so a failing
			// query inside the tool can never leak HTML into a JSON response
			// surface (REST, admin-ajax, SSE).
			return WP_MCP_AI_Db_Output_Guard::run(
				'tool_registry:' . $slug,
				function () use ( $tool, $arguments, $context ) {
					return $tool->execute( $arguments, $context );
				}
			);
		}

		/**
		 * If the tool is a registered bulk-operation handler and its estimated
		 * workload exceeds the configured threshold, dispatch the call to the
		 * async job queue and return a job-handle envelope to the caller.
		 *
		 * Returns `null` to indicate "no async dispatch — execute inline".
		 *
		 * @since 1.2.0
		 *
		 * @param string $slug      Tool slug.
		 * @param object $tool      Resolved tool instance.
		 * @param array  $arguments Tool arguments.
		 * @param array  $context   Execution context.
		 * @return array|null
		 */
		protected function maybe_dispatch_async_bulk( $slug, $tool, $arguments, $context ) {
			// Phase 4: when the Action Scheduler bridge is available, default
			// auto-async dispatch ON so bulk jobs run on the next AS tick
			// instead of polling WP-Cron once per minute. Sites without AS
			// keep the legacy default (off) until they explicitly opt in via
			// the `WP_MCP_AI_BULK_AUTO_ASYNC` constant or the filter below.
			if ( defined( 'WP_MCP_AI_BULK_AUTO_ASYNC' ) ) {
				$enabled = (bool) WP_MCP_AI_BULK_AUTO_ASYNC;
			} elseif (
				class_exists( 'WP_MCP_AI_Async_Scheduler_Bridge' ) &&
				WP_MCP_AI_Async_Scheduler_Bridge::is_available()
			) {
				$enabled = true;
			} else {
				$enabled = false;
			}

			/**
			 * Filters whether auto-async bulk dispatch is enabled.
			 *
			 * @since 1.2.0
			 *
			 * @param bool   $enabled Whether to attempt async dispatch.
			 * @param string $slug    Tool slug.
			 */
			$enabled = (bool) apply_filters( 'wp_mcp_ai_bulk_auto_async_enabled', $enabled, $slug );

			if ( ! $enabled ) {
				return null;
			}

			if ( ! ( $tool instanceof WP_MCP_AI_Tool_Bulk_Operation_Interface ) ) {
				return null;
			}

			if ( ! class_exists( 'WP_MCP_AI_Async_Job_Queue' ) ) {
				return null;
			}

			// Avoid recursive dispatch when the queue worker re-enters.
			if ( ! empty( $context['async_worker'] ) ) {
				return null;
			}

			$estimate = (int) $tool->estimate_total( $arguments );
			if ( $estimate <= 0 ) {
				return null;
			}

			/**
			 * Filters the row threshold above which bulk tools are auto-dispatched
			 * to the async job queue.
			 *
			 * @since 1.2.0
			 *
			 * @param int    $threshold Default 1000.
			 * @param string $slug      Tool slug.
			 */
			$threshold = (int) apply_filters( 'wp_mcp_ai_bulk_async_threshold', 1000, $slug );

			if ( $estimate < $threshold ) {
				return null;
			}

			$job_id = WP_MCP_AI_Async_Job_Queue::queue_job(
				array(
					'job_type'     => 'tool_execution',
					'job_data'     => array(
						'tool_slug'      => $slug,
						'arguments'      => $arguments,
						'checkpoint_key' => $tool->get_checkpoint_key( $arguments ),
						'estimated_rows' => $estimate,
					),
					'chat_session' => isset( $context['chat_session'] ) ? (string) $context['chat_session'] : '',
					'assistant_id' => isset( $context['assistant_id'] ) ? (int) $context['assistant_id'] : 0,
				)
			);

			if ( is_wp_error( $job_id ) ) {
				// Fall back to inline execution rather than blocking the call.
				return null;
			}

			return array(
				'success'        => true,
				'async'          => true,
				'job_id'         => (int) $job_id,
				'tool_slug'      => $slug,
				'estimated_rows' => $estimate,
				'message'        => sprintf(
					/* translators: 1: tool slug, 2: estimated row count, 3: job ID */
					__( '%1$s call (~%2$d rows) queued as async job #%3$d.', 'mcp-ai-wpoos' ),
					$slug,
					$estimate,
					(int) $job_id
				),
			);
		}

		/**
		 * Compensate for provider mismatch by routing to equivalent provider-specific tool.
		 *
		 * When a tool is requested that requires a different provider than the current one,
		 * this method attempts to route to an equivalent tool for the active provider
		 * and translates parameters as needed.
		 *
		 * @param string $slug Tool slug.
		 * @param array  $arguments Tool arguments.
		 * @param array  $context Execution context.
		 * @return array|WP_Error Array with 'slug' and 'arguments' on success, WP_Error or null if no compensation needed.
		 */
		protected function compensate_for_provider_mismatch( $slug, $arguments, $context ) {
			// Extract current provider from context.
			$current_provider = '';
			if ( ! empty( $context['assistant_config']['provider'] ) ) {
				$current_provider = $context['assistant_config']['provider'];
			} elseif ( ! empty( $context['model'] ) ) {
				$parts            = explode( ':', $context['model'] );
				$current_provider = count( $parts ) > 1 ? $parts[0] : '';
			}

			// If no provider context, can't compensate.
			if ( empty( $current_provider ) ) {
				return null;
			}

			// Get tool's required providers.
			$tool_rules = $this->get_tool_rules( $slug );
			if ( empty( $tool_rules['model_requirements']['providers'] ) ) {
				return null;
			}

			$required_providers = $tool_rules['model_requirements']['providers'];

			// If current provider is acceptable, no compensation needed.
			if ( in_array( $current_provider, $required_providers, true ) ) {
				return null;
			}

			// Define provider-specific tool mappings.
			$tool_mapping = $this->get_provider_tool_mapping();

			// Check if this tool has a mapping.
			if ( ! isset( $tool_mapping[ $slug ] ) ) {
				return null; // No mapping available, will fall through to validation error.
			}

			$mapping = $tool_mapping[ $slug ];

			// Check if there's a tool for the current provider.
			if ( ! isset( $mapping[ $current_provider ] ) ) {
				return null; // No equivalent tool for this provider.
			}

			$target_slug = $mapping[ $current_provider ];

			// Check if the target tool exists and is enabled.
			if ( ! $this->is_tool_registered( $target_slug ) || ! $this->is_tool_enabled( $target_slug ) ) {
				return null;
			}

			// Translate parameters between providers.
			$translated_arguments = $this->translate_tool_parameters( $slug, $target_slug, $arguments, $current_provider );

			// Log the provider compensation for debugging.
			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event(
					'provider_compensation',
					sprintf( 'Provider compensation: routing "%s" to "%s" for provider "%s"', $slug, $target_slug, $current_provider ),
					array(
						'original_tool'   => $slug,
						'target_tool'     => $target_slug,
						'provider'        => $current_provider,
						'original_args'   => $arguments,
						'translated_args' => $translated_arguments,
					)
				);
			}

			return array(
				'slug'      => $target_slug,
				'arguments' => $translated_arguments,
			);
		}

		/**
		 * Get provider-specific tool mappings.
		 *
		 * Defines which tools are equivalent across different providers.
		 *
		 * @return array Tool mapping structure.
		 */
		protected function get_provider_tool_mapping() {
			$mapping = array(
				// Image generation tools.
				'generate_openai_image' => array(
					'gemini'    => 'generate_gemini_image',
					'anthropic' => 'generate_openai_image', // Anthropic doesn't have image generation (fallback).
				),
				'generate_gemini_image' => array(
					'openai'    => 'generate_openai_image',
					'anthropic' => 'generate_openai_image', // Use OpenAI as fallback.
				),
				// Image editing tools.
				'edit_openai_image'     => array(
					'gemini' => 'edit_gemini_image',
				),
				'edit_gemini_image'     => array(
					'openai' => 'edit_openai_image',
				),
			);

			/**
			 * Filter provider tool mapping.
			 *
			 * Allows plugins to add or modify provider-specific tool mappings.
			 *
			 * @param array $mapping Tool mapping structure.
			 */
			return apply_filters( 'wp_mcp_ai_provider_tool_mapping', $mapping );
		}

		/**
		 * Translate tool parameters between providers.
		 *
		 * Converts provider-specific parameters to equivalent parameters for the target provider.
		 *
		 * @param string $source_slug Source tool slug.
		 * @param string $target_slug Target tool slug.
		 * @param array  $arguments Original arguments.
		 * @param string $target_provider Target provider.
		 * @return array Translated arguments.
		 */
		protected function translate_tool_parameters( $source_slug, $target_slug, $arguments, $target_provider ) {
			$translated = array();

			// Common parameters that don't need translation.
			$common_params = array( 'prompt', 'file_name', 'timeout', 'output_format' );
			foreach ( $common_params as $param ) {
				if ( isset( $arguments[ $param ] ) ) {
					$translated[ $param ] = $arguments[ $param ];
				}
			}

			// Translate OpenAI -> Gemini image parameters.
			if ( 'generate_openai_image' === $source_slug && 'generate_gemini_image' === $target_slug ) {
				// Translate size to aspect_ratio.
				if ( ! empty( $arguments['size'] ) ) {
					$translated['aspect_ratio'] = $this->convert_size_to_aspect_ratio( $arguments['size'] );
				}

				// Quality and style are OpenAI-specific, drop them for Gemini.
				// Gemini uses model selection for quality control.

				// Default mime_type for Gemini.
				if ( empty( $translated['mime_type'] ) ) {
					$translated['mime_type'] = 'image/png';
				}
			}

			// Translate Gemini -> OpenAI image parameters.
			if ( 'generate_gemini_image' === $source_slug && 'generate_openai_image' === $target_slug ) {
				// Translate aspect_ratio to size.
				if ( ! empty( $arguments['aspect_ratio'] ) ) {
					$translated['size'] = $this->convert_aspect_ratio_to_size( $arguments['aspect_ratio'] );
				}

				// Default quality for OpenAI.
				if ( empty( $translated['quality'] ) ) {
					$translated['quality'] = 'standard';
				}
			}

			/**
			 * Filter translated tool parameters.
			 *
			 * Allows plugins to customize parameter translation.
			 *
			 * @param array  $translated Translated arguments.
			 * @param string $source_slug Source tool slug.
			 * @param string $target_slug Target tool slug.
			 * @param array  $arguments Original arguments.
			 * @param string $target_provider Target provider.
			 */
			return apply_filters( 'wp_mcp_ai_translate_tool_parameters', $translated, $source_slug, $target_slug, $arguments, $target_provider );
		}

		/**
		 * Convert OpenAI size to Gemini aspect ratio.
		 *
		 * @param string $size OpenAI size (e.g., "1024x1024", "1792x1024").
		 * @return string Gemini aspect ratio (e.g., "1:1", "16:9").
		 */
		protected function convert_size_to_aspect_ratio( $size ) {
			$size_to_aspect = array(
				'1024x1024' => '1:1',
				'1792x1024' => '16:9',
				'1024x1792' => '9:16',
				'1536x1024' => '3:2',
				'1024x1536' => '2:3',
			);

			if ( isset( $size_to_aspect[ $size ] ) ) {
				return $size_to_aspect[ $size ];
			}

			// Try to compute aspect ratio from dimensions.
			if ( preg_match( '/^(\d+)x(\d+)$/', $size, $matches ) ) {
				$width  = (int) $matches[1];
				$height = (int) $matches[2];

				if ( $width === $height ) {
					return '1:1';
				} elseif ( $width > $height ) {
					$ratio = round( $width / $height, 1 );
					if ( abs( $ratio - 1.78 ) < 0.1 ) {
						return '16:9';
					} elseif ( abs( $ratio - 1.5 ) < 0.1 ) {
						return '3:2';
					}
					return '16:9'; // Default to 16:9 for landscape.
				} else {
					return '9:16'; // Default to 9:16 for portrait.
				}
			}

			// Default fallback.
			return '4:3';
		}

		/**
		 * Convert Gemini aspect ratio to OpenAI size.
		 *
		 * @param string $aspect_ratio Gemini aspect ratio (e.g., "1:1", "16:9").
		 * @return string OpenAI size (e.g., "1024x1024", "1792x1024").
		 */
		protected function convert_aspect_ratio_to_size( $aspect_ratio ) {
			$aspect_to_size = array(
				'1:1'  => '1024x1024',
				'16:9' => '1792x1024',
				'9:16' => '1024x1792',
				'4:3'  => '1024x768',
				'3:4'  => '768x1024',
				'3:2'  => '1536x1024',
				'2:3'  => '1024x1536',
			);

			if ( isset( $aspect_to_size[ $aspect_ratio ] ) ) {
				return $aspect_to_size[ $aspect_ratio ];
			}

			// Default fallback.
			return '1024x1024';
		}

				/**
				 * Check if a tool is registered.
				 *
				 * @param string $slug Tool slug.
				 * @return bool Whether the tool is registered.
				 */
		public function is_tool_registered( $slug ) {
			// Ensure registry is initialized before retrieving tools.
			$this->init();

			$slug = sanitize_key( $slug );

			// Resolve deprecated aliases without firing the deprecation hook —
			// callers that only want to test for registration should not pay the
			// log/observability cost of a real invocation.
			if ( isset( $this->deprecated_aliases[ $slug ] ) ) {
				$slug = $this->deprecated_aliases[ $slug ]['new_slug'];
			}

			return isset( $this->tools[ $slug ] );
		}

		/**
		 * Get tool capability requirement.
		 *
		 * @param string $slug Tool slug.
		 * @return string|null Required capability or null.
		 */
		public function get_tool_capability( $slug ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Parameter reserved for future implementation.
			// This method is referenced but not yet implemented.
			// For now, return null to maintain compatibility.
			return null;
		}

		/**
		 * Get tool definition for LLM payload.
		 *
		 * @param string $slug Tool slug.
		 * @return array|null Tool definition or null.
		 */
		public function get_tool_definition( $slug ) {
			$tool = $this->get_tool( $slug );
			if ( ! $tool ) {
				return null;
			}

			$definition = array(
				'name'        => $tool->get_slug(),
				'description' => $this->get_model_facing_description( $tool ),
				'parameters'  => $tool->get_parameters_schema(),
			);

			$data_contract = $this->get_tool_data_contract( $slug );
			if ( ! empty( $data_contract ) ) {
				$definition['data_contract'] = $data_contract;
			}

			return $definition;
		}

		/**
		 * Retrieve the data contract for a specific tool.
		 *
		 * Tools that implement {@see WP_MCP_AI_Tool_Data_Contract_Interface}
		 * may declare named `produces` and/or `consumes` payload contracts so
		 * the orchestrator can hint at chaining opportunities to the model.
		 *
		 * Returns an empty array when the tool does not implement the interface
		 * or when both keys are null/empty.
		 *
		 * @since 1.2.1
		 *
		 * @param string $slug Tool slug.
		 * @return array{produces?: string, consumes?: string|string[]} Normalised contract.
		 */
		public function get_tool_data_contract( $slug ) {
			$tool = $this->get_tool( $slug );
			if ( ! $tool ) {
				return array();
			}

			if ( ! ( $tool instanceof WP_MCP_AI_Tool_Data_Contract_Interface ) ) {
				return array();
			}

			$contract = $tool->get_data_contract();
			if ( ! is_array( $contract ) ) {
				return array();
			}

			$normalised = array();

			if ( isset( $contract['produces'] ) && is_string( $contract['produces'] ) && '' !== $contract['produces'] ) {
				$normalised['produces'] = sanitize_key( $contract['produces'] );
			}

			if ( isset( $contract['consumes'] ) && ! empty( $contract['consumes'] ) ) {
				if ( is_string( $contract['consumes'] ) ) {
					$normalised['consumes'] = sanitize_key( $contract['consumes'] );
				} elseif ( is_array( $contract['consumes'] ) ) {
					$consumes_list = array();
					foreach ( $contract['consumes'] as $value ) {
						if ( is_string( $value ) && '' !== $value ) {
							$consumes_list[] = sanitize_key( $value );
						}
					}
					if ( ! empty( $consumes_list ) ) {
						$normalised['consumes'] = array_values( array_unique( $consumes_list ) );
					}
				}
			}

			return $normalised;
		}

		/**
		 * Retrieve the normalised usage guidance for a specific tool.
		 *
		 * Tools that implement {@see WP_MCP_AI_Tool_Usage_Guidance_Interface}
		 * declare model-facing selection hints (when to use / when NOT to use /
		 * related tools / notes). The registry normalises and sanitises the
		 * declaration so payload builders can append it to the model-facing
		 * description without further handling.
		 *
		 * Returns an empty array when the tool does not implement the interface
		 * or when every declared key is null/empty.
		 *
		 * @since 1.1.83
		 *
		 * @param WP_MCP_AI_Tool_Interface $tool Tool instance.
		 * @return array{when_to_use?: string, when_not_to_use?: string, related_tools?: string[], notes?: string} Normalised guidance.
		 */
		public function get_usage_guidance( $tool ) {
			if ( ! is_object( $tool ) || ! ( $tool instanceof WP_MCP_AI_Tool_Usage_Guidance_Interface ) ) {
				return array();
			}

			$guidance = $tool->get_usage_guidance();
			if ( ! is_array( $guidance ) ) {
				return array();
			}

			$normalised = array();

			// Free-text fields: sanitise as plain text; guidance is model-facing,
			// never rendered as HTML.
			foreach ( array( 'when_to_use', 'when_not_to_use', 'notes' ) as $text_key ) {
				if ( isset( $guidance[ $text_key ] ) && is_string( $guidance[ $text_key ] ) && '' !== trim( $guidance[ $text_key ] ) ) {
					$normalised[ $text_key ] = trim( sanitize_text_field( $guidance[ $text_key ] ) );
				}
			}

			if ( isset( $guidance['related_tools'] ) && is_array( $guidance['related_tools'] ) ) {
				$related = array();
				foreach ( $guidance['related_tools'] as $related_slug ) {
					if ( is_string( $related_slug ) && '' !== $related_slug ) {
						$related[] = sanitize_key( $related_slug );
					}
				}
				if ( ! empty( $related ) ) {
					$normalised['related_tools'] = array_values( array_unique( $related ) );
				}
			}

			return $normalised;
		}

		/**
		 * Assemble the model-facing description for a tool.
		 *
		 * The model-facing description is the short `get_description()` plus,
		 * when the tool declares usage guidance, a compact `[Usage: …]`
		 * suffix. The suffix mirrors the existing data-contract suffix pattern
		 * so OpenAI strict function schemas stay valid (hints live in the
		 * description string, never as extra schema keys).
		 *
		 * Consumers that build provider payloads (`WP_MCP_AI_REST::build_tools_payload()`,
		 * `WP_MCP_AI_Tool_Service::build_tools_payload()` via `get_tool_definition()`,
		 * and the `list_mcp_tools` discovery tool) all route through this method
		 * so the LLM sees one consistent description across surfaces.
		 *
		 * @since 1.1.83
		 *
		 * @param WP_MCP_AI_Tool_Interface $tool Tool instance.
		 * @return string Model-facing description.
		 */
		public function get_model_facing_description( $tool ) {
			$description = is_object( $tool ) && method_exists( $tool, 'get_description' ) ? (string) $tool->get_description() : '';

			$guidance = $this->get_usage_guidance( $tool );
			if ( empty( $guidance ) ) {
				return $description;
			}

			$suffix_parts = array();

			if ( ! empty( $guidance['when_to_use'] ) ) {
				$suffix_parts[] = sprintf( 'use when %s', $guidance['when_to_use'] );
			}

			if ( ! empty( $guidance['when_not_to_use'] ) ) {
				$suffix_parts[] = sprintf( 'do NOT use when %s', $guidance['when_not_to_use'] );
			}

			if ( ! empty( $guidance['related_tools'] ) ) {
				$suffix_parts[] = sprintf( 'related: %s', implode( ', ', $guidance['related_tools'] ) );
			}

			if ( ! empty( $guidance['notes'] ) ) {
				$suffix_parts[] = $guidance['notes'];
			}

			if ( empty( $suffix_parts ) ) {
				return $description;
			}

			$suffix = '[Usage: ' . implode( '. ', $suffix_parts ) . ']';

			/**
			 * Filter the usage-guidance suffix appended to a tool's model-facing
			 * description.
			 *
			 * Return an empty string to suppress the suffix for a specific tool.
			 *
			 * @since 1.1.83
			 *
			 * @param string                  $suffix    Default suffix (e.g. `[Usage: use when …]`).
			 * @param WP_MCP_AI_Tool_Interface $tool      Tool instance.
			 * @param array                   $guidance  Normalised guidance array.
			 */
			$suffix = (string) apply_filters( 'wp_mcp_ai_tool_usage_guidance_description_suffix', $suffix, $tool, $guidance );

			if ( '' === $suffix ) {
				return $description;
			}

			$description = rtrim( $description );
			if ( '' !== $description && ! preg_match( '/[.!?]$/', $description ) ) {
				$description .= '.';
			}

			return $description . ' ' . $suffix;
		}

		/**
		 * Get capability flags for a specific tool.
		 *
		 * Retrieves the capability flags from a tool if it implements
		 * the WP_MCP_AI_Tool_Capability_Flags_Interface.
		 *
		 * @param string $slug Tool slug.
		 * @return array<string> Array of capability flag strings, empty array if tool not found or no flags.
		 */
		public function get_tool_capability_flags( $slug ) {
			$tool = $this->get_tool( $slug );

			if ( ! $tool ) {
				return array();
			}

			// Check if tool implements capability flags interface.
			if ( $tool instanceof WP_MCP_AI_Tool_Capability_Flags_Interface ) {
				$flags = $tool->get_capability_flags();
				if ( ! is_array( $flags ) ) {
					return array();
				}

				// Normalise associative arrays (key => bool) into a list of
				// active flag names. List-format arrays pass through unchanged.
				$first_key = array_key_first( $flags );
				if ( null !== $first_key && is_string( $first_key ) ) {
					return array_values( array_keys( array_filter( $flags ) ) );
				}

				return $flags;
			}

			return array();
		}

		/**
		 * Resolve the toolkit namespace for a tool instance or slug.
		 *
		 * The `toolkit` key declared inside `get_definition()` wins when
		 * present. Tools without one (most Pro addon classes) fall back to a
		 * directory-derived namespace: the folder directly under a `tools/`
		 * directory that declares the class (e.g. `tools/document-generation/`
		 * → `document_generation`). Hyphens are normalised to underscores to
		 * match the declared-toolkit convention. Classes declared directly
		 * inside a flat `tools/` folder resolve to an empty string.
		 *
		 * @since 1.1.95
		 *
		 * @param WP_MCP_AI_Tool_Interface|string $tool_or_slug Tool instance or registered slug.
		 * @return string Toolkit namespace, empty when unknown.
		 */
		public function get_tool_toolkit( $tool_or_slug ) {
			$tool = is_string( $tool_or_slug ) ? $this->get_tool( $tool_or_slug ) : $tool_or_slug;

			if ( ! is_object( $tool ) ) {
				return '';
			}

			$toolkit = '';

			// Explicit declaration wins.
			if ( method_exists( $tool, 'get_definition' ) ) {
				$definition = $tool->get_definition();
				if ( is_array( $definition ) && ! empty( $definition['toolkit'] ) ) {
					$toolkit = trim( (string) $definition['toolkit'] );
				}
			}

			// Directory-derived fallback for tools that never declared one.
			if ( '' === $toolkit ) {
				$toolkit = $this->derive_tool_toolkit_from_declaring_file( $tool );
			}

			$slug = method_exists( $tool, 'get_slug' ) ? (string) $tool->get_slug() : '';

			/**
			 * Filter the toolkit namespace resolved for a tool.
			 *
			 * Lets addons override or annotate namespaces (for example, mapping
			 * a folder-derived slug to the canonical toolkit label) without
			 * editing every tool class.
			 *
			 * @since 1.1.95
			 *
			 * @param string $toolkit Resolved toolkit namespace (declared or directory-derived).
			 * @param string $slug    Tool slug.
			 * @param object $tool    Tool instance.
			 */
			return (string) apply_filters( 'wp_mcp_ai_tool_toolkit', $toolkit, $slug, $tool );
		}

		/**
		 * Derive a toolkit namespace from the declaring class file's location.
		 *
		 * Tool classes bundled under a `tools/<toolkit>/` folder are assumed to belong
		 * to that toolkit. Wrapped legacy tools resolve through the inner class
		 * (`get_inner_class_name()`) so the wrapper's own file location never
		 * masks the real declaring folder.
		 *
		 * @since 1.1.95
		 *
		 * @param object $tool Tool instance.
		 * @return string Toolkit namespace, empty when not derivable.
		 */
		private function derive_tool_toolkit_from_declaring_file( $tool ) {
			$class_name = method_exists( $tool, 'get_inner_class_name' )
				? $tool->get_inner_class_name()
				: get_class( $tool );

			try {
				$file = ( new ReflectionClass( $class_name ) )->getFileName();
			} catch ( ReflectionException $e ) {
				return '';
			}

			if ( ! $file ) {
				return '';
			}

			$dir = dirname( wp_normalize_path( $file ) );

			// Declared directly inside a flat `tools/` folder — no toolkit dir.
			if ( 'tools' === basename( $dir ) ) {
				return '';
			}

			// Walk up to the segment directly below the enclosing `tools/`
			// folder, so nested helper folders still map to the toolkit.
			$guard = 0;
			while ( $guard < 8 ) {
				$parent = dirname( $dir );
				if ( 'tools' === basename( $parent ) ) {
					return str_replace( '-', '_', basename( $dir ) );
				}
				if ( $parent === $dir ) {
					break;
				}
				$dir = $parent;
				++$guard;
			}

			return '';
		}

		/**
		 * Get capability flags for all registered tools.
		 *
		 * Returns a map of tool slugs to their capability flags arrays.
		 * Only includes tools that implement the capability flags interface.
		 *
		 * @return array<string, array<string>> Map of tool slugs to capability flag arrays.
		 */
		public function get_all_tool_capability_flags() {
			// Ensure registry is initialized before retrieving tools.
			$this->init();

			$flags_map = array();

			foreach ( $this->tools as $slug => $tool ) {
				$flags = $this->get_tool_capability_flags( $slug );
				if ( ! empty( $flags ) ) {
					$flags_map[ $slug ] = $flags;
				}
			}

			return $flags_map;
		}

		/**
		 * Get tools that have a specific capability flag.
		 *
		 * Filters all registered tools to find those that declare the specified
		 * capability flag.
		 *
		 * @param string $flag Capability flag to filter by (e.g., 'read-only', 'external-api').
		 * @return array<WP_MCP_AI_Tool_Interface> Array of tool instances that have the flag.
		 */
		public function get_tools_by_capability_flag( $flag ) {
			// Ensure registry is initialized before retrieving tools.
			$this->init();
			$this->ensure_default_tools_loaded();

			$matching_tools = array();

			foreach ( $this->tools as $slug => $tool ) {
				$flags = $this->get_tool_capability_flags( $slug );
				if ( in_array( $flag, $flags, true ) ) {
					$matching_tools[] = $tool;
				}
			}

			return $matching_tools;
		}

		/**
		 * Retrieve the default tool grouping map keyed by tool slug.
		 *
		 * @return array<string, string>
		 */
		public function get_tool_group_map() {
			// Ensure registry is initialized so that filters are applied (including pro tools).
			$this->init();

			$default_map = array(
				// WordPress Core - Tools that work with base WordPress, no external dependencies.
				'submit_document_prompt'             => 'wordpress-core',
				'search_content'                     => 'wordpress-core',
				'search_attachments'                 => 'wordpress-core',
				'get_recent_posts'                   => 'wordpress-core',
				'save_post'                          => 'wordpress-core',
				'create_post'                        => 'wordpress-core',
				'create_term'                        => 'wordpress-core',
				'update_term'                        => 'wordpress-core',
				'list_terms'                         => 'wordpress-core',
				'list_taxonomies'                    => 'wordpress-core',
				'get_user_info'                      => 'wordpress-core',
				'nvoos_get_profile'                  => 'wordpress-core',
				'get_site_summary'                   => 'wordpress-core',
				'get_system_logs'                    => 'wordpress-core',
				'get_update_status'                  => 'wordpress-core',
				'get_site_health'                    => 'wordpress-core',
				'get_environment_status'             => 'wordpress-core',
				'create_cron_job'                    => 'wordpress-core',
				'list_cron_jobs'                     => 'wordpress-core',
				'get_cron_job'                       => 'wordpress-core',
				'delete_cron_job'                    => 'wordpress-core',
				'send_group_email'                   => 'wordpress-core',
				'purge_cache'                        => 'wordpress-core',
				'probe_chat'                         => 'wordpress-core',
				'probe_remote_mcp'                   => 'wordpress-core',
				'query_remote_site'                  => 'wordpress-core',
				'query_mesh_intelligent'             => 'wordpress-core',
				'check_site_security'                => 'wordpress-core',
				'count_tokens'                       => 'wordpress-core',

				// Media and content moderation (AI-powered).
				'generate_image_alt_text'            => 'wordpress-core',
				'generate_image_caption'             => 'wordpress-core',
				'analyze_image'                      => 'wordpress-core',
				'extract_image_text'                 => 'wordpress-core',
				'analyze_video'                      => 'wordpress-core',
				'generate_video_caption'             => 'wordpress-core',
				'analyze_comment_content'            => 'wordpress-core',

				// Image manipulation (Graphic Editor Suite).
				'resize_image'                       => 'wordpress-core',
				'crop_image'                         => 'wordpress-core',
				'rotate_image'                       => 'wordpress-core',
				'convert_image_format'               => 'wordpress-core',
				'vectorize_image'                    => 'wordpress-core',
				'graphic_editor_plus'                => 'wordpress-plugins',

				// Data Visualization.
				'create_chart'                       => 'wordpress-core',
				'create_chart_fence'                 => 'wordpress-core',
				'visualize_workflow_metrics'         => 'wordpress-core',
				'validate_workflow'                  => 'wordpress-core',

				// Excel and Spreadsheet Tools - Pro features.
				'pro_excel'                          => 'external-tools',

				// Assistant management.
				'create_assistant'                   => 'wordpress-core',

				// Profession management.
				'list_professions'                   => 'wordpress-core',
				'get_profession'                     => 'wordpress-core',
				'save_profession'                    => 'wordpress-core',
				'get_profession_stats'               => 'wordpress-core',

				// Multi-agent orchestration (DeepSeek V4 Phase 1 & 5).
				'create_agent_team'                  => 'wordpress-core',
				'delegate_to_agent'                  => 'wordpress-core',
				'aggregate_agent_results'            => 'wordpress-core',
				'store_agent_context'                => 'wordpress-core',
				'retrieve_agent_memory'              => 'wordpress-core',
				'prioritize_context'                 => 'wordpress-core',
				'semantic_context_search'            => 'external-tools',

				// Project Management - Pro feature tools for managing projects, tasks, and events.
				'create_project'                     => 'project-management',
				'update_project'                     => 'project-management',
				'delete_project'                     => 'project-management',
				'list_projects'                      => 'project-management',
				'create_task'                        => 'project-management',
				'update_task'                        => 'project-management',
				'delete_task'                        => 'project-management',
				'list_tasks'                         => 'project-management',
				'create_event'                       => 'project-management',
				'update_event'                       => 'project-management',
				'delete_event'                       => 'project-management',
				'list_events'                        => 'project-management',
				'get_calendar_view'                  => 'project-management',

				// WordPress Plugins - Tools requiring specific WordPress plugins.
				'get_elementor_templates'            => 'wordpress-plugins',
				'get_elementor_form_submissions'     => 'wordpress-plugins',
				'get_all_form_submissions'           => 'wordpress-plugins',
				'get_woo_recent_orders'              => 'wordpress-plugins',
				'get_woo_products'                   => 'wordpress-plugins',
				'create_woo_product'                 => 'wordpress-plugins',
				'get_jetengine_items'                => 'wordpress-plugins',
				'list_jetengine_rest_routes'         => 'wordpress-plugins',
				'invoke_jetengine_route'             => 'wordpress-plugins',
				'get_jetformbuilder_forms'           => 'wordpress-plugins',
				'get_jetformbuilder_submissions'     => 'wordpress-plugins',
				'get_rankmath_seo'                   => 'wordpress-plugins',
				'create_wpcode_snippet'              => 'wordpress-plugins',
				'generate_simple_jwt_token'          => 'wordpress-plugins',
				'newsletter_add_subscriber'          => 'wordpress-plugins',
				'newsletter_get_subscribers'         => 'wordpress-plugins',
				'newsletter_unsubscribe'             => 'wordpress-plugins',
				'newsletter_get_subscriber_stats'    => 'wordpress-plugins',
				'newsletter_create_email'            => 'wordpress-plugins',
				'newsletter_get_emails'              => 'wordpress-plugins',

				// External Tools - Tools requiring external APIs or credentials.
				'generate_openai_image'              => 'external-tools',
				'generate_sora_video'                => 'external-tools',
				'generate_gemini_image'              => 'external-tools',
				'cloudflareai_text_to_image'         => 'external-tools',
				'edit_gemini_image'                  => 'external-tools',
				'generate_veo_video'                 => 'external-tools',
				'check_video_status'                 => 'external-tools',
				'generate_music'                     => 'external-tools',
				'generate_openai_speech'             => 'external-tools',
				'generate_sinhala_speech'            => 'external-tools',
				'transcribe_openai_audio'            => 'external-tools',
				'moderate_content'                   => 'external-tools',
				'open_openai_usage'                  => 'external-tools',
				'open_openai_logs'                   => 'external-tools',
				'run_openai_external_action'         => 'external-tools',
				// OpenAI API Integration - Phase 1 Tools.
				'list_openai_files'                  => 'external-tools',
				'get_openai_file_details'            => 'external-tools',
				'list_available_models'              => 'external-tools',
				'get_model_information'              => 'external-tools',
				'research_model'                     => 'external-tools',
				'add_model_config'                   => 'external-tools',
				'discover_new_models'                => 'external-tools',
				'deep_research'                      => 'external-tools',
				'research_status'                    => 'external-tools',
				'research_result'                    => 'external-tools',
				'research_cancel'                    => 'external-tools',
				'create_text_embeddings'             => 'external-tools',
				// OpenAI API Integration - Phase 2 Tools.
				'semantic_content_search'            => 'external-tools',
				'suggest_best_model'                 => 'external-tools',
				'batch_embed_content'                => 'external-tools',
				// OpenAI API Integration - Phase 3 Tools (Vector Stores).
				'create_vector_store'                => 'external-tools',
				'list_vector_stores'                 => 'external-tools',
				'get_vector_store'                   => 'external-tools',
				'manage_vector_store_files'          => 'external-tools',
				// OpenAI API Integration - Phase 4 Tools.
				'edit_openai_image'                  => 'external-tools',
				'create_image_variation'             => 'external-tools',
				'analyze_file_suitability'           => 'external-tools',
				'openai_usage_analytics'             => 'external-tools',
				'vision_product_search'              => 'external-tools',
				'vision_object_localization'         => 'external-tools',
				'detect_image_content'               => 'external-tools',
				'find_similar_media'                 => 'wordpress-core',
				'get_image_metadata'                 => 'wordpress-core',
				'describe_image_layout'              => 'wordpress-core',
				'identify_image'                     => 'external-tools',
				'schedule_notify_sms'                => 'external-tools',
				'web_search'                         => 'external-tools',
				'web_browser'                        => 'external-tools',
				'capture_webpage_screenshot'         => 'external-tools',
				'search_gmail'                       => 'external-tools',
				'search_drive'                       => 'external-tools',
				'crawl4ai_price_lookup'              => 'external-tools',
				'run_crawl4ai_job'                   => 'external-tools',
				'scrape_product'                     => 'external-tools',
				'get_gdacs_events'                   => 'external-tools',
				'get_open_meteo_forecast'            => 'external-tools',
				'get_nhc_active_storms'              => 'external-tools',
				'reliefweb_reports'                  => 'external-tools',
				'get_import_duty'                    => 'external-tools',
				'generate_auth0_token'               => 'external-tools',
				'purge_cloudflare_cache'             => 'external-tools',
				'purge_varnish_cache'                => 'external-tools',
				'geocode_address'                    => 'external-tools',
				'search_places'                      => 'external-tools',
				'gemini_geospatial_query'            => 'external-tools',
				'payhere_get_payment'                => 'external-tools',
				// Flowhub cannabis dispensary integration.
				'flowhub_get_inventory'              => 'external-tools',
				'flowhub_get_orders'                 => 'external-tools',
				'flowhub_create_order'               => 'external-tools',
				'flowhub_get_customers'              => 'external-tools',
				'flowhub_manage_customer'            => 'external-tools',
				'flowhub_get_products'               => 'external-tools',
				'flowhub_manage_product'             => 'external-tools',
				'list_github_repositories'           => 'external-tools',
				'github_repository_operations'       => 'external-tools',
				'manage_github_codespace'            => 'external-tools',
				'generic_rest'                       => 'external-tools',
				// HuggingFace Datasets API tools.
				'huggingface_dataset_search'         => 'external-tools',
				'huggingface_dataset_get_info'       => 'external-tools',
				'huggingface_dataset_get_size'       => 'external-tools',
				'huggingface_dataset_get_rows'       => 'external-tools',
				'huggingface_dataset_preview_rows'   => 'external-tools',
				'huggingface_dataset_list_splits'    => 'external-tools',
				'huggingface_dataset_get_statistics' => 'external-tools',
				'huggingface_dataset_get_parquet'    => 'external-tools',
				'huggingface_dataset_is_valid'       => 'external-tools',
				'huggingface_dataset_filter'         => 'external-tools',
				'huggingface_recommended_datasets'   => 'external-tools',
				// Erlang C queuing-theory and workforce tools.
				'calculate_erlang_c'                 => 'wordpress-core',
				'erlang_c_concurrency_advisor'       => 'wordpress-core',
				'erlang_c_staffing_advisor'          => 'external-tools',
				'erlang_c_queue_health'              => 'external-tools',
			);

			// Fantasy Football tool mappings are now handled by the Pro addon.
			// Quiz tool mappings are now handled by the Pro addon.

			/**
			 * Filter the tool grouping map used throughout the admin UI.
			 *
			 * @param array<string, string> $default_map Associative array of tool slugs to group identifiers.
			 */
			return apply_filters( 'wp_mcp_ai_tool_group_map', $default_map );
		}

		/**
		 * Retrieve the default labels for tool groups.
		 *
		 * @return array<string, string>
		 */
		public function get_tool_group_labels() {
			// Ensure registry is initialized so that filters are applied.
			$this->init();

			$default_labels = array(
				'wordpress-core'     => __( 'WordPress Core', 'mcp-ai-wpoos' ),
				'wordpress-plugins'  => __( 'WordPress Plugins', 'mcp-ai-wpoos' ),
				'project-management' => __( 'Project Management', 'mcp-ai-wpoos' ),
				'external-tools'     => __( 'External Tools', 'mcp-ai-wpoos' ),
				'other'              => __( 'Other tools', 'mcp-ai-wpoos' ),
			);

			/**
			 * Filter the tool group labels used throughout the admin UI.
			 *
			 * @param array<string, string> $default_labels Associative array of group identifiers to labels.
			 */
			return apply_filters( 'wp_mcp_ai_tool_group_labels', $default_labels );
		}

																		/**
																		 * Determine the current flow stage from execution context.
																		 *
																		 * @param array $context Execution context.
																		 * @return string Current flow stage: 'start', 'middle', 'end', or 'anytime'.
																		 */
		protected function determine_flow_stage( $context ) {
			// Check for explicit flow_stage in context.
			if ( ! empty( $context['flow_stage'] ) ) {
				$stage = sanitize_key( $context['flow_stage'] );
				if ( in_array( $stage, array( 'start', 'middle', 'end', 'anytime' ), true ) ) {
					return $stage;
				}
			}

			// Determine stage from iteration context.
			if ( isset( $context['iteration'] ) && isset( $context['max_iterations'] ) ) {
				$iteration      = absint( $context['iteration'] );
				$max_iterations = absint( $context['max_iterations'] );

				if ( $max_iterations <= 1 ) {
					// Single iteration workflow - consider it both start and end.
					return 'start';
				}

				if ( 0 === $iteration ) {
					return 'start';
				} elseif ( $iteration >= $max_iterations - 1 ) {
					return 'end';
				} else {
					return 'middle';
				}
			}

			// Default to anytime if stage cannot be determined.
			return 'anytime';
		}

		/**
		 * Get tool-specific execution rules.
		 *
		 * Retrieves rules from the tool if it implements the WP_MCP_AI_Tool_Rules_Interface.
		 *
		 * @param string $slug Tool slug.
		 * @return array Tool rules or empty array if tool doesn't define rules.
		 */
		protected function get_tool_rules( $slug ) {
			$tool = $this->get_tool( $slug );

			if ( ! $tool ) {
				return array();
			}

			// Check if tool implements the rules interface.
			if ( $tool instanceof WP_MCP_AI_Tool_Rules_Interface ) {
				$rules = $tool->get_tool_rules();
				return is_array( $rules ) ? $rules : array();
			}

			return array();
		}

		/**
		 * Validate tool execution against its rules.
		 *
		 * Checks if the current environment and parameters meet the tool's requirements.
		 *
		 * @param string $slug Tool slug.
		 * @param array  $arguments Tool arguments.
		 * @param array  $context Execution context.
		 * @return true|WP_Error True if valid, WP_Error if validation fails.
		 */
		public function validate_tool_execution( $slug, $arguments = array(), $context = array() ) {
			$rules = $this->get_tool_rules( $slug );

			if ( empty( $rules ) ) {
				return true; // No rules to validate.
			}

			$errors = array();

			// Validate model requirements.
			if ( ! empty( $rules['model_requirements'] ) ) {
				$model_error = $this->validate_model_requirements( $rules['model_requirements'], $arguments, $context );
				if ( is_wp_error( $model_error ) ) {
					$errors[] = $model_error->get_error_message();
				}
			}

			// Validate parameter constraints.
			if ( ! empty( $rules['parameter_constraints'] ) ) {
				$param_error = $this->validate_parameter_constraints( $rules['parameter_constraints'], $arguments );
				if ( is_wp_error( $param_error ) ) {
					$errors[] = $param_error->get_error_message();
				}
			}

			// Validate dependencies.
			if ( ! empty( $rules['dependencies'] ) ) {
				$dep_error = $this->validate_dependencies( $rules['dependencies'] );
				if ( is_wp_error( $dep_error ) ) {
					$errors[] = $dep_error->get_error_message();
				}
			}

			if ( ! empty( $errors ) ) {
				return new WP_Error(
					'tool_validation_failed',
					implode( '; ', $errors ),
					array(
						'status' => 400,
						'errors' => $errors,
					)
				);
			}

			return true;
		}

		/**
		 * Validate model requirements.
		 *
		 * @param array $requirements Model requirements.
		 * @param array $arguments Tool arguments.
		 * @param array $context Execution context.
		 * @return true|WP_Error
		 */
		protected function validate_model_requirements( $requirements, $arguments, $context ) {
			// Extract model from arguments, context, or assistant_config.
			$model                 = $arguments['model'] ?? $context['model'] ?? '';
			$from_assistant_config = false;

			// If model not directly available, check assistant_config.
			if ( empty( $model ) && ! empty( $context['assistant_config'] ) ) {
				$assistant_config = $context['assistant_config'];

				// Extract provider and model from assistant_config.
				$provider   = $assistant_config['provider'] ?? '';
				$model_name = $assistant_config['model'] ?? '';

				// Construct model in format "provider:model" if both are present.
				if ( ! empty( $provider ) && ! empty( $model_name ) ) {
					$model                 = $provider . ':' . $model_name;
					$from_assistant_config = true;
				}
			}

			// Check if model is specified when required.
			if ( ! empty( $requirements['required'] ) && empty( $model ) ) {
				return new WP_Error( 'model_required', 'This tool requires a model to be specified' );
			}

			// Validate allowed providers.
			if ( ! empty( $requirements['providers'] ) && ! empty( $model ) ) {
				// Extract provider from model string (format: "provider:model" or just "model").
				$parts    = explode( ':', $model );
				$provider = count( $parts ) > 1 ? $parts[0] : '';

				// If provider is explicitly specified, validate it.
				if ( ! empty( $provider ) && ! in_array( $provider, $requirements['providers'], true ) ) {
					return new WP_Error(
						'invalid_provider',
						sprintf( 'Model provider must be one of: %s', implode( ', ', $requirements['providers'] ) )
					);
				}
			}

			// Validate specific models (only if model is explicitly provided, not from assistant_config).
			// Models from assistant_config are already validated by provider check above.
			if ( ! empty( $requirements['models'] ) && ! empty( $model ) && ! $from_assistant_config ) {
				// Extract just the model name without provider prefix.
				$model_name = strpos( $model, ':' ) !== false ? explode( ':', $model )[1] : $model;

				if ( ! in_array( $model_name, $requirements['models'], true ) ) {
					return new WP_Error(
						'invalid_model',
						sprintf( 'Model must be one of: %s', implode( ', ', $requirements['models'] ) )
					);
				}
			}

			return true;
		}

		/**
		 * Validate parameter constraints.
		 *
		 * @param array $constraints Parameter constraints.
		 * @param array $arguments Tool arguments.
		 * @return true|WP_Error
		 */
		protected function validate_parameter_constraints( $constraints, $arguments ) {
			// Check required fields.
			if ( ! empty( $constraints['required_fields'] ) ) {
				foreach ( $constraints['required_fields'] as $field ) {
					if ( ! isset( $arguments[ $field ] ) || '' === $arguments[ $field ] ) {
						return new WP_Error( 'missing_parameter', "Required parameter '{$field}' is missing" );
					}
				}
			}

			// Check max items constraint.
			if ( ! empty( $constraints['max_items'] ) && isset( $arguments['items'] ) ) {
				if ( is_array( $arguments['items'] ) && count( $arguments['items'] ) > $constraints['max_items'] ) {
					return new WP_Error(
						'too_many_items',
						sprintf( 'Maximum %d items allowed, %d provided', $constraints['max_items'], count( $arguments['items'] ) )
					);
				}
			}

			return true;
		}

		/**
		 * Validate dependencies.
		 *
		 * @param array $dependencies Dependency requirements.
		 * @return true|WP_Error
		 */
		public function validate_dependencies( $dependencies ) {
			// Check required plugins.
			if ( ! empty( $dependencies['required_plugins'] ) ) {
				foreach ( $dependencies['required_plugins'] as $plugin ) {
					if ( 'woocommerce' === $plugin && ! class_exists( 'WooCommerce' ) ) {
						return new WP_Error( 'missing_plugin', 'WooCommerce plugin is required' );
					}
					// Add more plugin checks as needed.
				}
			}

			// Check required PHP extensions.
			if ( ! empty( $dependencies['required_extensions'] ) ) {
				foreach ( $dependencies['required_extensions'] as $extension ) {
					if ( ! extension_loaded( $extension ) ) {
						return new WP_Error( 'missing_extension', "PHP extension '{$extension}' is required" );
					}
				}
			}

			// Check required settings.
			if ( ! empty( $dependencies['required_settings'] ) ) {
				$settings = class_exists( 'WP_MCP_AI_Admin_Settings' ) ? WP_MCP_AI_Admin_Settings::get_settings() : array();
				foreach ( $dependencies['required_settings'] as $setting => $setting_key ) {
					// Support both old option names (for backward compatibility) and new settings array keys.
					$value = '';
					if ( strpos( $setting_key, 'wp_mcp_ai_' ) === 0 ) {
						// Old format: wp_mcp_ai_openai_api_key -> check get_option first, then settings array.
						$value = get_option( $setting_key );
						if ( empty( $value ) ) {
							// Try to map old option name to new settings key.
							$mapped_key = str_replace( 'wp_mcp_ai_', '', $setting_key );
							$value      = isset( $settings[ $mapped_key ] ) ? $settings[ $mapped_key ] : '';
						}
					} else {
						// New format: just the key name (e.g., 'openai_api_key').
						$value = isset( $settings[ $setting_key ] ) ? $settings[ $setting_key ] : '';
					}

					// Fall back to the credential resolver so keys configured via
					// WP 7.0 Connectors, environment variables, or PHP constants
					// (which the provider clients honour) also satisfy the gate.
					if ( empty( $value ) && class_exists( 'WP_MCP_AI_Credential_Resolver' ) ) {
						$provider = str_replace( array( 'wp_mcp_ai_', '_api_key' ), '', $setting_key );
						if ( '' !== $provider ) {
							$resolved = WP_MCP_AI_Credential_Resolver::get_api_key( $provider );
							if ( ! empty( $resolved ) ) {
								$value = $resolved;
							}
						}
					}

					if ( empty( $value ) ) {
						return new WP_Error( 'missing_setting', "Required setting '{$setting}' is not configured" );
					}
				}
			}

			return true;
		}

		/**
		 * Check whether the private/custom base-mode entry point is active.
		 *
		 * Returns true only when mcp-ai-wpoos-base.php has been used as the entry
		 * point (which sets WP_MCP_AI_BASE_VERSION = true). That file is excluded
		 * from the WordPress.org distribution ZIP (.distignore).
		 *
		 * This method is NOT used to gate any tools in this registry — all tools
		 * in includes/tools/ are always registered regardless of this flag.
		 * The $is_base_version value is passed to the wp_mcp_ai_default_tools
		 * filter solely for backward compatibility with any third-party code
		 * that reads it.
		 *
		 * @return bool True only when the private base-mode entry point is active.
		 */
		protected function is_base_version() {
			/**
			 * Filter whether to enable base version mode.
			 *
			 * When true, only tools that work with a base WordPress installation are loaded.
			 * Tools requiring WooCommerce, JetEngine, JetFormBuilder, Elementor, RankMath,
			 * WPCode, or external API credentials are still registered but will report
			 * themselves as unavailable via their own is_available() checks.
			 *
			 * @param bool $is_base_version Whether base version mode is enabled.
			 */
			return apply_filters( 'wp_mcp_ai_base_version', function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() );
		}

		/**
		 * Load the plugin's default tool providers.
		 */
		protected function load_default_tools() {
			$is_base_version = $this->is_base_version();

			// Tools that work with base WordPress (no third-party plugins or external APIs).
			$base_tools = array(
				'WP_MCP_AI_Tool_Get_Recent_Posts'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-recent-posts.php',
				'WP_MCP_AI_Tool_Search_Content'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-search-content.php',
				'WP_MCP_AI_Tool_Get_User_Info'             => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-user-info.php',
				'WP_MCP_AI_Tool_Nvoos_Get_Profile'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-nvoos-get-profile.php',
				'WP_MCP_AI_Tool_Get_Site_Summary'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-site-summary.php',
				'WP_MCP_AI_Tool_Count_Tokens'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-count-tokens.php',
				'WP_MCP_AI_Tool_List_MCP_Tools'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-mcp-tools.php',
				'WP_MCP_AI_Tool_MCP_Server_Info'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-mcp-server-info.php',
				'WP_MCP_AI_Tool_Load_Skill'                => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-load-skill.php',
				// OpenAI API Integration - Phase 1 Tools.
				'WP_MCP_AI_Tool_List_OpenAI_Files'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-openai-files.php',
				'WP_MCP_AI_Tool_Get_OpenAI_File_Details'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-openai-file-details.php',
				'WP_MCP_AI_Tool_List_Available_Models'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-available-models.php',
				'WP_MCP_AI_Tool_Get_Model_Information'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-model-information.php',
				'WP_MCP_AI_Tool_Research_Model'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-research-model.php',
				'WP_MCP_AI_Tool_Add_Model_Config'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-add-model-config.php',
				'WP_MCP_AI_Tool_Typesafe_Decide'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-typesafe-decide.php',
				'WP_MCP_AI_Tool_Typesafe_Guardrail'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-typesafe-guardrail.php',
				'WP_MCP_AI_Tool_Run_Assistant_Eval'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-run-assistant-eval.php',
				'WP_MCP_AI_Tool_Scan_Assistant_Security'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-scan-assistant-security.php',
				'WP_MCP_AI_Tool_Discover_New_Models'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-discover-new-models.php',
				'WP_MCP_AI_Tool_Create_Text_Embeddings'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-text-embeddings.php',
				// OpenAI API Integration - Phase 2 Tools.
				'WP_MCP_AI_Tool_Semantic_Content_Search'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-semantic-content-search.php',
				'WP_MCP_AI_Tool_Suggest_Best_Model'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-suggest-best-model.php',
				'WP_MCP_AI_Tool_Batch_Embed_Content'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-batch-embed-content.php',
				// OpenAI API Integration - Phase 3 Tools (Vector Stores).
				'WP_MCP_AI_Tool_Create_Vector_Store'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-vector-store.php',
				'WP_MCP_AI_Tool_List_Vector_Stores'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-vector-stores.php',
				'WP_MCP_AI_Tool_Get_Vector_Store'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-vector-store.php',
				'WP_MCP_AI_Tool_Manage_Vector_Store_Files' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-manage-vector-store-files.php',
				// OpenAI API Integration - Phase 4 Tools.
				'WP_MCP_AI_Tool_Edit_OpenAI_Image'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-edit-openai-image.php',
				'WP_MCP_AI_Tool_Create_Image_Variation'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-image-variation.php',
				'WP_MCP_AI_Tool_Analyze_File_Suitability'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-analyze-file-suitability.php',
				'WP_MCP_AI_Tool_OpenAI_Usage_Analytics'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-openai-usage-analytics.php',
				'WP_MCP_AI_Tool_Get_Site_Health'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-site-health.php',
				'WP_MCP_AI_Tool_Get_Environment_Status'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-environment-status.php',
				'WP_MCP_AI_Tool_Get_Fleet_Status'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-fleet-status.php',
				'WP_MCP_AI_Tool_Get_Site_Uptime'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-site-uptime.php',
				'WP_MCP_AI_Tool_Generate_Auth0_Token'      => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-auth0-token.php',
				'WP_MCP_AI_Tool_Get_NHC_Active_Storms'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-nhc-active-storms.php',
				'WP_MCP_AI_Tool_Search_Attachments'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-search-attachments.php',
				'WP_MCP_AI_Tool_Search_Gmail'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-search-gmail.php',
				'WP_MCP_AI_Tool_Search_Drive'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-search-drive.php',
				'WP_MCP_AI_Tool_Web_Search'                => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-web-search.php',
				'WP_MCP_AI_Tool_Crawl4AI_Price_Lookup'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-crawl4ai-price-lookup.php',
				'WP_MCP_AI_Tool_Get_GDACS_Events'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-gdacs-events.php',
				'WP_MCP_AI_Tool_Get_Open_Meteo_Forecast'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-open-meteo-forecast.php',
				'WP_MCP_AI_Tool_Run_OpenAI_External_Action' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-run-openai-external-action.php',
				'WP_MCP_AI_Tool_Probe_Chat'                => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-probe-chat.php',
				'WP_MCP_AI_Tool_Probe_Remote_MCP'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-probe-remote-mcp.php',
				'WP_MCP_AI_Tool_Generate_OpenAI_Speech'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-openai-speech.php',
				'WP_MCP_AI_Tool_Generate_Sinhala_Speech'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-sinhala-speech.php',
				'WP_MCP_AI_Tool_Transcribe_OpenAI_Audio'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-transcribe-openai-audio.php',
				'WP_MCP_AI_Tool_Moderate_Content'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-moderate-content.php',
				// Browser-Native AI Tools (Phase 2: Transformers.js Integration).
				'WP_MCP_AI_Tool_Client_Summarize_Text'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-client-summarize-text.php',
				'WP_MCP_AI_Tool_Client_Analyze_Sentiment'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-client-analyze-sentiment.php',
				'WP_MCP_AI_Tool_Client_Extract_Entities'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-client-extract-entities.php',
				'WP_MCP_AI_Tool_Client_Translate_Text'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-client-translate-text.php',
				'WP_MCP_AI_Tool_Client_Question_Answering' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-client-question-answering.php',
				'WP_MCP_AI_Tool_Client_Semantic_Search'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-client-semantic-search.php',
				'WP_MCP_AI_Tool_Generate_OpenAI_Image'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-openai-image.php',
				'WP_MCP_AI_Tool_Generate_Sora_Video'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-sora-video.php',
				'WP_MCP_AI_Tool_Generate_Gemini_Image'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-gemini-image.php',
				'WP_MCP_AI_Tool_Generate_CloudflareAI_Image' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-cloudflareai-image.php',
				'WP_MCP_AI_Tool_Generate_Veo_Video'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-veo-video.php',
				'WP_MCP_AI_Tool_Generate_Higgsfield_Video' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-higgsfield-video.php',
				'WP_MCP_AI_Tool_Generate_Higgsfield_Image' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-higgsfield-image.php',
				'WP_MCP_AI_Tool_Check_Higgsfield_Request'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-check-higgsfield-request.php',
				'WP_MCP_AI_Tool_Cancel_Higgsfield_Request' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-cancel-higgsfield-request.php',
				'WP_MCP_AI_Tool_Check_Video_Status'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-check-video-status.php',
				'WP_MCP_AI_Tool_Generate_Music'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-music.php',
				'WP_MCP_AI_Tool_Submit_Document_Prompt'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-submit-document-prompt.php',
				'WP_MCP_AI_Tool_Save_Post'                 => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-save-post.php',
				'WP_MCP_AI_Tool_Create_Post'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-post.php',
				'WP_MCP_AI_Tool_Get_Post'                  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-post.php',
				'WP_MCP_AI_Tool_Delete_Post'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-delete-post.php',
				'WP_MCP_AI_Tool_Get_Post_Type_Schema'      => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-post-type-schema.php',
				'WP_MCP_AI_Tool_Create_Term'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-term.php',
				'WP_MCP_AI_Tool_Update_Term'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-update-term.php',
				'WP_MCP_AI_Tool_List_Terms'                => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-terms.php',
				'WP_MCP_AI_Tool_List_Taxonomies'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-taxonomies.php',
				// Comment management tools (ported from docdyhr/mcp-wordpress, MIT).
				'WP_MCP_AI_Tool_List_Comments'             => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-comments.php',
				'WP_MCP_AI_Tool_Get_Comment'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-comment.php',
				'WP_MCP_AI_Tool_Create_Comment'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-comment.php',
				'WP_MCP_AI_Tool_Update_Comment'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-update-comment.php',
				'WP_MCP_AI_Tool_Delete_Comment'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-delete-comment.php',
				// User management tools (ported from docdyhr/mcp-wordpress, MIT).
				'WP_MCP_AI_Tool_List_Users'                => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-users.php',
				'WP_MCP_AI_Tool_Create_User'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-user.php',
				'WP_MCP_AI_Tool_Update_User'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-update-user.php',
				'WP_MCP_AI_Tool_Delete_User'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-delete-user.php',
				// Content/taxonomy/media tools (ported from docdyhr/mcp-wordpress, MIT).
				'WP_MCP_AI_Tool_Get_Post_Revisions'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-post-revisions.php',
				'WP_MCP_AI_Tool_Get_Term'                  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-term.php',
				'WP_MCP_AI_Tool_Delete_Term'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-delete-term.php',
				'WP_MCP_AI_Tool_Get_Media'                 => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-media.php',
				'WP_MCP_AI_Tool_Upload_Media'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-upload-media.php',
				'WP_MCP_AI_Tool_Update_Media'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-update-media.php',
				'WP_MCP_AI_Tool_Delete_Media'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-delete-media.php',
				// Site settings and application password tools (ported from docdyhr/mcp-wordpress, MIT).
				'WP_MCP_AI_Tool_Get_Site_Settings'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-site-settings.php',
				'WP_MCP_AI_Tool_Update_Site_Settings'      => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-update-site-settings.php',
				'WP_MCP_AI_Tool_List_Application_Passwords' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-application-passwords.php',
				'WP_MCP_AI_Tool_Create_Application_Password' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-application-password.php',
				'WP_MCP_AI_Tool_Delete_Application_Password' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-delete-application-password.php',
				// SEO toolkit (ported from docdyhr/mcp-wordpress, MIT).
				'WP_MCP_AI_Tool_SEO_Analyze_Content'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-analyze-content.php',
				'WP_MCP_AI_Tool_SEO_Generate_Schema'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-generate-schema.php',
				'WP_MCP_AI_Tool_SEO_Validate_Schema'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-validate-schema.php',
				'WP_MCP_AI_Tool_SEO_Bulk_Update_Metadata'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-bulk-update-metadata.php',
				'WP_MCP_AI_Tool_SEO_Site_Audit'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-site-audit.php',
				'WP_MCP_AI_Tool_SEO_Test_Integration'      => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-test-integration.php',
				'WP_MCP_AI_Tool_SEO_Get_Live_Data'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-get-live-data.php',
				'WP_MCP_AI_Tool_SEO_Track_Serp'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-track-serp.php',
				'WP_MCP_AI_Tool_SEO_Keyword_Research'      => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-keyword-research.php',
				'WP_MCP_AI_Tool_Create_Assistant'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-assistant.php',
				'WP_MCP_AI_Tool_Export_Assistant'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-export-assistant.php',
				'WP_MCP_AI_Tool_Import_Assistant'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-import-assistant.php',
				'WP_MCP_AI_Tool_Duplicate_Assistant'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-duplicate-assistant.php',
				'WP_MCP_AI_Tool_Run_Crawl4AI_Job'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-run-crawl4ai-job.php',
				'WP_MCP_AI_Tool_Open_OpenAI_Logs'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-open-openai-logs.php',
				'WP_MCP_AI_Tool_Open_OpenAI_Usage'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-open-openai-usage.php',
				'WP_MCP_AI_Tool_Get_System_Logs'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-system-logs.php',
				'WP_MCP_AI_Tool_Get_Update_Status'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-update-status.php',
				'WP_MCP_AI_Tool_Create_Cron_Job'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-cron-job.php',
				'WP_MCP_AI_Tool_List_Cron_Jobs'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-cron-jobs.php',
				'WP_MCP_AI_Tool_Get_Cron_Job'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-cron-job.php',
				'WP_MCP_AI_Tool_Delete_Cron_Job'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-delete-cron-job.php',
				'WP_MCP_AI_Tool_Send_Group_Email'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-send-group-email.php',
				'WP_MCP_AI_Tool_Purge_Cloudflare_Cache'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-purge-cloudflare-cache.php',
				'WP_MCP_AI_Tool_Purge_Varnish_Cache'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-purge-varnish-cache.php',
				'WP_MCP_AI_Tool_Purge_Cache'               => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-purge-cache.php',
				'WP_MCP_AI_Tool_ReliefWeb_Reports'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-reliefweb-reports.php',
				'WP_MCP_AI_Tool_Query_Remote_Site'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-query-remote-site.php',
				'WP_MCP_AI_Tool_Query_Mesh_Intelligent'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-query-mesh-intelligent.php',
				'WP_MCP_AI_Tool_Check_Site_Security'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-check-site-security.php',
				'WP_MCP_AI_Tool_Generate_Image_Alt_Text'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-image-alt-text.php',
				'WP_MCP_AI_Tool_Generate_Image_Caption'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-image-caption.php',
				'WP_MCP_AI_Tool_Analyze_Image'             => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-analyze-image.php',
				'WP_MCP_AI_Tool_Extract_Image_Text'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-extract-image-text.php',
				'WP_MCP_AI_Tool_Analyze_Video'             => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-analyze-video.php',
				'WP_MCP_AI_Tool_Generate_Video_Caption'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-video-caption.php',
				'WP_MCP_AI_Tool_Analyze_Comment_Content'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-analyze-comment-content.php',
				'WP_MCP_AI_Tool_Create_Chart'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-chart.php',
				'WP_MCP_AI_Tool_Create_Chart_Fence'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-chart-fence.php',
				// Profession management tools.
				'WP_MCP_AI_Tool_List_Professions'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-professions.php',
				'WP_MCP_AI_Tool_Get_Profession'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-profession.php',
				'WP_MCP_AI_Tool_Save_Profession'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-save-profession.php',
				'WP_MCP_AI_Tool_Profession_Stats'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-profession-stats.php',
				// Agent coordination tools (DeepSeek V4 multi-agent orchestration).
				'WP_MCP_AI_Tool_Create_Agent_Team'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-agent-team.php',
				'WP_MCP_AI_Tool_Delegate_To_Agent'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-delegate-to-agent.php',
				'WP_MCP_AI_Tool_Delegate_To_A2A_Agent'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-delegate-to-a2a-agent.php',
				'WP_MCP_AI_Tool_Aggregate_Agent_Results'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-aggregate-agent-results.php',
				// Agent memory tools (DeepSeek V4 Phase 5: State Management & Memory).
				'WP_MCP_AI_Tool_Store_Agent_Context'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-store-agent-context.php',
				'WP_MCP_AI_Tool_Retrieve_Agent_Memory'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-retrieve-agent-memory.php',
				'WP_MCP_AI_Tool_Prioritize_Context'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-prioritize-context.php',
				'WP_MCP_AI_Tool_Semantic_Context_Search'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-semantic-context-search.php',
				'WP_MCP_AI_Tool_Manage_Context_Lifecycle'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-manage-context-lifecycle.php',
				'WP_MCP_AI_Tool_Batch_Manage_Memory'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-batch-manage-memory.php',
				'WP_MCP_AI_Tool_Memory_Audit_Trail'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-memory-audit-trail.php',
				// MemPalace-inspired Phase 2: bulk ingest + session wake-up loader.
				'WP_MCP_AI_Tool_Mine_Agent_Memory'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-mine-agent-memory.php',
				'WP_MCP_AI_Tool_Wake_Up_Context'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-wake-up-context.php',
				// MemPalace Capture Framework Phase A8: hierarchical recall.
				'WP_MCP_AI_Tool_Recall_Memory'             => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-recall-memory.php',
				'WP_MCP_AI_Tool_Execute_Workflow'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-execute-workflow.php',
				'WP_MCP_AI_Tool_Check_Workflow_Health'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-check-workflow-health.php',
				'WP_MCP_AI_Tool_Validate_Workflow'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-validate-workflow.php',
				'WP_MCP_AI_Tool_Visualize_Workflow_Metrics' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-visualize-workflow-metrics.php',
				'WP_MCP_AI_Tool_Evolve_Harness'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-evolve-harness.php',
				'WP_MCP_AI_Tool_Run_Gemini_Managed_Agent'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-run-gemini-managed-agent.php',
				// Previously-orphaned tool files referenced by presets (registered as of 1.2.0).
				'WP_MCP_AI_Tool_2FA_Setup_Assistant'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-2fa-setup-assistant.php',
				'WP_MCP_AI_Tool_Auto_Categorize_Content'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-auto-categorize-content.php',
				'WP_MCP_AI_Tool_Content_Freshness_Checker' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-content-freshness-checker.php',
				'WP_MCP_AI_Tool_Content_Recommendation_Engine' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-content-recommendation-engine.php',
				'WP_MCP_AI_Tool_Create_Batch'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-batch.php',
				'WP_MCP_AI_Tool_Edit_Omni_Video'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-edit-omni-video.php',
				'WP_MCP_AI_Tool_Generate_Chart'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-chart.php',
				'WP_MCP_AI_Tool_Generate_Mermaid'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-mermaid.php',
				'WP_MCP_AI_Tool_Generate_Omni_Video'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-omni-video.php',
				'WP_MCP_AI_Tool_Generate_Post_Excerpt'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-post-excerpt.php',
				'WP_MCP_AI_Tool_Get_Batch_Status'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-batch-status.php',
				'WP_MCP_AI_Tool_Gutenberg_Block_Pattern_Generator' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-gutenberg-block-pattern-generator.php',
				'WP_MCP_AI_Tool_Image_Alt_Text_Optimizer'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-image-alt-text-optimizer.php',
				'WP_MCP_AI_Tool_Image_Format_Batch_Converter' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-image-format-batch-converter.php',
				'WP_MCP_AI_Tool_List_Batches'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-batches.php',
				'WP_MCP_AI_Tool_Login_Security_Monitor'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-login-security-monitor.php',
				'WP_MCP_AI_Tool_Media_Library_Optimizer'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-media-library-optimizer.php',
				'WP_MCP_AI_Tool_Monitor_Batch'             => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-monitor-batch.php',
				'WP_MCP_AI_Tool_Password_Strength_Analyzer' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-password-strength-analyzer.php',
				'WP_MCP_AI_Tool_Performance_Optimizer_Assistant' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-performance-optimizer-assistant.php',
				'WP_MCP_AI_Tool_Responsive_Image_Validator' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-responsive-image-validator.php',
				'WP_MCP_AI_Tool_SEO_Meta_Optimizer'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-seo-meta-optimizer.php',
				'WP_MCP_AI_Tool_Suggest_Internal_Links'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-suggest-internal-links.php',
				'WP_MCP_AI_Tool_User_Activity_Auditor'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-user-activity-auditor.php',
				// Google Site Kit integration tools (orphaned files registered as of 1.2.0).
				'WP_MCP_AI_Tool_SiteKit_AdSense'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-sitekit-adsense.php',
				'WP_MCP_AI_Tool_SiteKit_Analytics'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-sitekit-analytics.php',
				'WP_MCP_AI_Tool_SiteKit_PageSpeed'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-sitekit-pagespeed.php',
				'WP_MCP_AI_Tool_SiteKit_Search_Console'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-sitekit-search-console.php',
				// Advanced reasoning tools (DeepSeek V4 Phase 3: Reasoning Support).
				'WP_MCP_AI_Tool_Enable_Reasoning_Mode'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-enable-reasoning-mode.php',
				'WP_MCP_AI_Tool_Analyze_Code_Sequence'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-analyze-code-sequence.php',
				'WP_MCP_AI_Tool_Validate_Reasoning_Chain'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-validate-reasoning-chain.php',
				// Google Maps Platform tools.
				'WP_MCP_AI_Tool_Geocode_Address'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-geocode-address.php',
				'WP_MCP_AI_Tool_Search_Places'             => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-search-places.php',
				// Gemini Geospatial API tools.
				'WP_MCP_AI_Tool_Gemini_Geospatial_Query'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-gemini-geospatial-query.php',
				// Gemini image editing tool.
				'WP_MCP_AI_Tool_Edit_Gemini_Image'         => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-edit-gemini-image.php',
				// Product scraping tool.
				'WP_MCP_AI_Tool_Scrape_Product'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-scrape-product.php',
				// Image manipulation tools (Graphic Editor Suite).
				'WP_MCP_AI_Tool_Resize_Image'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-resize-image.php',
				'WP_MCP_AI_Tool_Crop_Image'                => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-crop-image.php',
				'WP_MCP_AI_Tool_Rotate_Image'              => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-rotate-image.php',
				'WP_MCP_AI_Tool_Convert_Image_Format'      => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-convert-image-format.php',
				'WP_MCP_AI_Tool_Vectorize_Image'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-vectorize-image.php',
				// HuggingFace Datasets API tools.
				'WP_MCP_AI_Tool_Huggingface_Dataset_Search' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-search.php',
				'WP_MCP_AI_Tool_Huggingface_Dataset_Get_Info' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-get-info.php',
				'WP_MCP_AI_Tool_Huggingface_Dataset_Get_Size' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-get-size.php',
				'WP_MCP_AI_Tool_Huggingface_Dataset_Get_Rows' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-get-rows.php',
				'WP_MCP_AI_Tool_Huggingface_Dataset_Preview_Rows' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-preview-rows.php',
				'WP_MCP_AI_Tool_Huggingface_Dataset_List_Splits' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-list-splits.php',
				'WP_MCP_AI_Tool_Huggingface_Dataset_Get_Statistics' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-get-statistics.php',
				'WP_MCP_AI_Tool_Huggingface_Dataset_Get_Parquet' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-get-parquet.php',
				'WP_MCP_AI_Tool_Huggingface_Dataset_Is_Valid' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-is-valid.php',
				'WP_MCP_AI_Tool_Huggingface_Dataset_Filter' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-dataset-filter.php',
				'WP_MCP_AI_Tool_Huggingface_Recommended_Datasets' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-huggingface-recommended-datasets.php',
				// Deep Research tool.
				'WP_MCP_AI_Tool_Deep_Research'             => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-deep-research.php',
				// Deep Research background job companion tools.
				'WP_MCP_AI_Tool_Research_Status'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-research-status.php',
				'WP_MCP_AI_Tool_Research_Result'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-research-result.php',
				'WP_MCP_AI_Tool_Research_Cancel'           => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-research-cancel.php',
				// Excel and Spreadsheet Tools - AI-powered formula generation.
				'WP_MCP_AI_Tool_Pro_Excel'                 => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-pro-excel.php',
				// Erlang C queuing-theory tools (Base).
				'WP_MCP_AI_Tool_Calculate_Erlang_C'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-calculate-erlang-c.php',
				'WP_MCP_AI_Tool_Erlang_C_Concurrency_Advisor' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-erlang-c-concurrency-advisor.php',
			);

			// Additional tools that require third-party plugins or external API credentials.
			$extended_tools = array(
				// Yahoo Fantasy Football Toolkit: registered by the
				// addons/fantasy-football addon from its own tool paths.
				'WP_MCP_AI_Tool_Get_Elementor_Templates'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-elementor-templates.php',
				'WP_MCP_AI_Tool_Import_Elementor_Template_Kit' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-import-elementor-template-kit.php',
				'WP_MCP_AI_Tool_Get_Elementor_Form_Submissions' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-elementor-form-submissions.php',
				'WP_MCP_AI_Tool_Get_All_Form_Submissions'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-all-form-submissions.php',
				'WP_MCP_AI_Tool_Get_Woo_Orders'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-woo-recent-orders.php',
				'WP_MCP_AI_Tool_Get_Woo_Products'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-woo-products.php',
				'WP_MCP_AI_Tool_Create_Woo_Product'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-create-woo-product.php',
				// PayHere payment gateway integration.
				'WP_MCP_AI_Tool_PayHere_Get_Payment'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-payhere-get-payment.php',
				// Flowhub cannabis dispensary integration.
				'WP_MCP_AI_Tool_Flowhub_Get_Inventory'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-flowhub-get-inventory.php',
				'WP_MCP_AI_Tool_Flowhub_Get_Orders'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-flowhub-get-orders.php',
				'WP_MCP_AI_Tool_Flowhub_Create_Order'      => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-flowhub-create-order.php',
				'WP_MCP_AI_Tool_Flowhub_Get_Customers'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-flowhub-get-customers.php',
				'WP_MCP_AI_Tool_Flowhub_Manage_Customer'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-flowhub-manage-customer.php',
				'WP_MCP_AI_Tool_Flowhub_Get_Products'      => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-flowhub-get-products.php',
				'WP_MCP_AI_Tool_Flowhub_Manage_Product'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-flowhub-manage-product.php',
				'WP_MCP_AI_Tool_Get_JetEngine_Items'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-jetengine-items.php',
				'WP_MCP_AI_Tool_Get_JetFormBuilder_Forms'  => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-jetformbuilder-forms.php',
				'WP_MCP_AI_Tool_Get_JetFormBuilder_Submissions' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-jetformbuilder-submissions.php',
				'WP_MCP_AI_Tool_List_JetEngine_Routes'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-jetengine-routes.php',
				'WP_MCP_AI_Tool_Invoke_JetEngine_Route'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-invoke-jetengine-route.php',
				// Conversation import (JetEngine CCT) tools.
				'WP_MCP_AI_Tool_Conversation_Import_Detect' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-conversation-import-detect.php',
				'WP_MCP_AI_Tool_Conversation_Import_Run'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-conversation-import-run.php',
				'WP_MCP_AI_Tool_Conversation_Import_Status' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-conversation-import-status.php',
				'WP_MCP_AI_Tool_Conversation_Import_Delete' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-conversation-import-delete.php',
				'WP_MCP_AI_Tool_Get_RankMath_SEO'          => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-rankmath-seo.php',
				'WP_MCP_AI_Tool_Generate_Simple_JWT_Token' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-generate-simple-jwt-token.php',
				'WP_MCP_AI_Tool_Vision_Product_Search'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-vision-product-search.php',
				'WP_MCP_AI_Tool_Vision_Object_Localization' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-vision-object-localization.php',
				'WP_MCP_AI_Tool_Detect_Image_Content'      => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-detect-image-content.php',
				'WP_MCP_AI_Tool_Find_Similar_Media'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-find-similar-media.php',
				'WP_MCP_AI_Tool_Get_Image_Metadata'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-image-metadata.php',
				'WP_MCP_AI_Tool_Describe_Image_Layout'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-describe-image-layout.php',
				'WP_MCP_AI_Tool_Identify_Image'            => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-identify-image.php',
				// Newsletter plugin tools.
				'WP_MCP_AI_Tool_Newsletter_Add_Subscriber' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-newsletter-add-subscriber.php',
				'WP_MCP_AI_Tool_Newsletter_Get_Subscribers' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-newsletter-get-subscribers.php',
				'WP_MCP_AI_Tool_Newsletter_Unsubscribe'    => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-newsletter-unsubscribe.php',
				'WP_MCP_AI_Tool_Newsletter_Get_Subscriber_Stats' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-newsletter-get-subscriber-stats.php',
				'WP_MCP_AI_Tool_Newsletter_Create_Email'   => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-newsletter-create-email.php',
				'WP_MCP_AI_Tool_Newsletter_Get_Emails'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-newsletter-get-emails.php',
				// WP All Import/Export plugin tools.
				'WP_MCP_AI_Tool_List_All_Export_Templates' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-all-export-templates.php',
				'WP_MCP_AI_Tool_Trigger_All_Export'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-trigger-all-export.php',
				'WP_MCP_AI_Tool_List_All_Import_Templates' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-list-all-import-templates.php',
				'WP_MCP_AI_Tool_Trigger_All_Import'        => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-trigger-all-import.php',
				'WP_MCP_AI_Tool_Get_All_Import_Status'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-get-all-import-status.php',
				// Advanced graphic editing tool.
				'WP_MCP_AI_Tool_Graphic_Editor_Plus'       => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-graphic-editor-plus.php',
				// Erlang C contact-centre tools (Extended — optional WFM endpoint integration).
				'WP_MCP_AI_Tool_Erlang_C_Staffing_Advisor' => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-erlang-c-staffing-advisor.php',
				'WP_MCP_AI_Tool_Erlang_C_Queue_Health'     => WP_MCP_AI_PATH . 'includes/tools/class-wp-mcp-ai-tool-erlang-c-queue-health.php',
				// Project Management tools moved to Pro addon.
			);

			// Pro addon tools are loaded exclusively by the Pro addon (addons/pro/).
			// The Pro addon adds genuinely new tools that require PHP 8.1+ features.
			$pro_tools = array();

			// All tools shipped in this plugin are always attempted.
			// Extended tools self-report unavailability via is_available() when their
			// required third-party plugins (WooCommerce, JetEngine, etc.) are not active.
			// The Pro addon (addons/pro/) contributes entirely NEW tools — it does not
			// gate or unlock any tool already present in includes/tools/.
			$default_tools = array_merge( $base_tools, $extended_tools, $pro_tools );

			/**
			 * Filter the list of default tools to load.
			 *
			 * @param array $default_tools    Array of tool class names and file paths.
			 * @param bool  $is_base_version  Whether the private base-mode entry point is
			 *                                active (always false on WordPress.org installs).
			 */
			$default_tools = apply_filters( 'wp_mcp_ai_default_tools', $default_tools, $is_base_version );

			// Quiz tools are now loaded by the Pro addon.

			// Preload shared tool traits so legacy tool classes that use them
			// without requiring the trait file are registration-order independent.
			$this->load_shared_tool_traits();

			foreach ( $default_tools as $class => $file ) {
				if ( file_exists( $file ) ) {
					require_once $file;
				} else {
					wp_mcp_ai_record_missing_file( $file );
				}

				if ( class_exists( $class ) ) {
					$should_register = true;

					if ( method_exists( $class, 'is_available' ) ) {
						$should_register = (bool) call_user_func( array( $class, 'is_available' ) );

						if ( ! $should_register && method_exists( $class, 'get_unavailable_reason' ) ) {
							$message = (string) call_user_func( array( $class, 'get_unavailable_reason' ) );
							if ( $message && ! in_array( $message, $this->unavailable_tool_messages, true ) ) {
								$this->unavailable_tool_messages[] = $message;
							}
						}
					}

					if ( $should_register ) {
						$tool = new $class();

						// Legacy-format classes (pre-interface) are transparently
						// wrapped so they still register with the canonical tool
						// interface. Wrap BEFORE the first register attempt so the
						// registry's fail-loud "missing interface" log is not
						// emitted for a class that is about to register
						// successfully via the wrapper.
						if ( ! $tool instanceof WP_MCP_AI_Tool_Interface && class_exists( 'WP_MCP_AI_Legacy_Tool_Wrapper' ) ) {
							$tool = new WP_MCP_AI_Legacy_Tool_Wrapper( $tool );
						}

						// In deferred mode third-party tools registered via the
						// wp_mcp_ai_register_tools / wp_mcp_ai_tools_init hooks
						// win slug conflicts over the default suite.
						if ( $this->deferred_loading && method_exists( $tool, 'get_slug' ) && isset( $this->tools[ sanitize_key( (string) $tool->get_slug() ) ] ) ) {
							continue;
						}

						$registered = $this->register_tool( $tool );

						if ( ! $registered ) {
							$skipped = new $class();
							if ( method_exists( $skipped, 'get_slug' ) ) {
								$this->mark_tool_unavailable( $skipped->get_slug() );
							}
						}
					} else {
						// Track the slug of plugin-gated/unavailable tools so callers
						// can distinguish them from tools that never existed.
						$skipped = new $class();
						if ( method_exists( $skipped, 'get_slug' ) ) {
							$this->mark_tool_unavailable( $skipped->get_slug() );
						}
					}
				}
			}
		}

		/**
		 * Load shared tool traits before any tool class file is required.
		 *
		 * Several legacy tool classes use traits such as
		 * {@see WP_MCP_AI_Tool_WordPress_Native} without requiring the trait
		 * file themselves. They previously survived on load-order luck (some
		 * other tool file requiring the trait first) — which broke during
		 * plugin activation where the registry is the first loader of those
		 * files. Preloading the trait files makes registration
		 * order-independent.
		 *
		 * @return void
		 */
		protected function load_shared_tool_traits() {
			$base_traits = glob( WP_MCP_AI_PATH . 'includes/traits/trait-wp-mcp-ai-tool-*.php' );
			$tool_traits = glob( WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-*.php' );

			$trait_files = array_merge(
				is_array( $base_traits ) ? $base_traits : array(),
				is_array( $tool_traits ) ? $tool_traits : array()
			);

			foreach ( $trait_files as $trait_file ) {
				if ( file_exists( $trait_file ) ) {
					require_once $trait_file;
				}
			}
		}

		/**
		 * Get the list of globally disabled tools.
		 *
		 * @return array Array of disabled tool slugs.
		 */
		public function get_disabled_tools() {
			$disabled = get_option( 'wp_mcp_ai_disabled_tools', array() );
			return is_array( $disabled ) ? $disabled : array();
		}

		/**
		 * Get slugs of tools skipped during registration because their
		 * availability check failed (plugin-gated tools, missing credentials).
		 *
		 * Distinct from {@see self::get_disabled_tools()} — these are tools the
		 * registry declined to load, not tools an admin disabled afterwards.
		 *
		 * @return string[] Array of unavailable tool slugs.
		 */
		public function get_unavailable_tool_slugs() {
			return $this->unavailable_tool_slugs;
		}

		/**
		 * Record a tool slug as known-but-unavailable.
		 *
		 * Callers that gate registration themselves (e.g. the Pro addon's
		 * toolkit toggles) can use this to keep the unavailable-slug list
		 * complete, so consumers can distinguish "known but gated" from
		 * "never existed".
		 *
		 * @param string|object $tool_or_slug Tool slug string or tool instance.
		 * @return void
		 */
		public function mark_tool_unavailable( $tool_or_slug ) {
			$slug = is_string( $tool_or_slug ) ? $tool_or_slug : '';

			if ( is_object( $tool_or_slug ) && method_exists( $tool_or_slug, 'get_slug' ) ) {
				$slug = (string) $tool_or_slug->get_slug();
			}

			$slug = sanitize_key( $slug );

			if ( '' !== $slug && ! in_array( $slug, $this->unavailable_tool_slugs, true ) ) {
				$this->unavailable_tool_slugs[] = $slug;
			}
		}

		/**
		 * Automatically disable tools marked with "bug" status.
		 *
		 * Reads the docs/tool-status.txt file and disables any tools with "bug" status
		 * to prevent them from being used until the bugs are resolved.
		 */
		protected function auto_disable_bug_tools() {
			$status_labels = $this->load_tool_status_labels();

			foreach ( $status_labels as $tool_slug => $status ) {
				if ( 'bug' === $status ) {
					// Check if the tool is registered.
					if ( isset( $this->tools[ $tool_slug ] ) ) {
						// Disable the tool if it's currently enabled.
						if ( $this->is_tool_enabled( $tool_slug ) ) {
							$this->disable_tool( $tool_slug );
						}
					}
				}
			}
		}

		/**
		 * Load tool status labels from docs/tool-status.txt file.
		 *
		 * @return array Associative array of tool slug => status label.
		 */
		protected function load_tool_status_labels() {
			static $status_labels = null;

			// Use static cache to avoid reading file multiple times.
			if ( null !== $status_labels ) {
				return $status_labels;
			}

			$status_labels = array();
			$status_file   = WP_MCP_AI_PATH . 'docs/tool-status.txt';

			// Check if file exists and is readable.
			if ( ! is_readable( $status_file ) ) {
				return $status_labels;
			}

			// Read file content. Use an explicit error handler instead of @
			// because the @ operator is not reliable across all PHP 8
			// configurations (e.g. xdebug.scream, custom error handlers).
			// A leaked warning corrupts MCP JSON-RPC HTTP responses when
			// this runs during a tools/list or tools/call request.
			set_error_handler( '__return_true' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_set_error_handler -- Deliberate suppression for local file read, not debug code.
			$content = file_get_contents( $status_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; failure handled below.
			restore_error_handler();
			if ( false === $content ) {
				return $status_labels;
			}

			// Parse file line by line.
			$lines = explode( "\n", $content );
			foreach ( $lines as $line ) {
				// Trim whitespace.
				$line = trim( $line );

				// Skip empty lines and comments.
				if ( empty( $line ) || '#' === substr( $line, 0, 1 ) ) {
					continue;
				}

				// Parse line format: tool_slug = status_label.
				$parts = explode( '=', $line, 2 );
				if ( 2 !== count( $parts ) ) {
					continue;
				}

				$tool_slug    = trim( $parts[0] );
				$status_label = trim( $parts[1] );

				// Validate status label (only allow alphanumeric, hyphens, underscores).
				if ( ! preg_match( '/^[a-zA-Z0-9_-]+$/', $status_label ) ) {
					continue;
				}

				$status_labels[ $tool_slug ] = $status_label;
			}

			return $status_labels;
		}

		/**
		 * Check if a tool is globally enabled.
		 *
		 * @param string $slug Tool slug.
		 * @return bool True if enabled, false if disabled.
		 */
		public function is_tool_enabled( $slug ) {
			$disabled_tools = $this->get_disabled_tools();
			return ! in_array( $slug, $disabled_tools, true );
		}

		/**
		 * Enable a tool globally.
		 *
		 * @param string $slug Tool slug.
		 * @return bool True on success, false on failure.
		 */
		public function enable_tool( $slug ) {
			$slug           = sanitize_key( $slug );
			$disabled_tools = $this->get_disabled_tools();

			$key = array_search( $slug, $disabled_tools, true );
			if ( false !== $key ) {
				unset( $disabled_tools[ $key ] );
				$disabled_tools = array_values( $disabled_tools ); // Re-index array.
				return update_option( 'wp_mcp_ai_disabled_tools', $disabled_tools );
			}

			return true; // Already enabled.
		}

		/**
		 * Disable a tool globally.
		 *
		 * @param string $slug Tool slug.
		 * @return bool True on success, false on failure.
		 */
		public function disable_tool( $slug ) {
			$slug           = sanitize_key( $slug );
			$disabled_tools = $this->get_disabled_tools();

			if ( ! in_array( $slug, $disabled_tools, true ) ) {
				$disabled_tools[] = $slug;
				return update_option( 'wp_mcp_ai_disabled_tools', $disabled_tools );
			}

			return true; // Already disabled.
		}

		/**
		 * Register a tool with execution context metadata.
		 *
		 * Enhanced registration that stores additional metadata about
		 * tool execution capabilities and requirements.
		 *
		 * @since 1.2.0
		 *
		 * @param string|WP_MCP_AI_Tool_Interface $tool     Tool class name or instance.
		 * @param array                           $contexts Execution contexts (e.g., 'client', 'server', 'worker').
		 * @return bool Whether the tool was registered.
		 */
		public function register_tool_with_context( $tool, $contexts = array( 'server' ) ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found,Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Parameter reserved for future context-aware registration.
			// For now, use legacy registration.
			return $this->register_tool( $tool );
		}

		/**
		 * Get tools that can execute in a specific context.
		 *
		 * @since 1.2.0
		 *
		 * @param string $context Execution context ('client', 'server', 'worker').
		 * @return array Array of tools that can execute in the specified context.
		 */
		public function get_tools_by_context( $context ) {
			$this->init();
			$this->ensure_default_tools_loaded();

			if ( 'client' === $context ) {
				return $this->get_client_executable_tools();
			}

			return $this->tools;
		}

		/**
		 * Get client-executable tools.
		 *
		 * Returns tools that are safe and capable of running client-side.
		 *
		 * @since 1.2.0
		 *
		 * @return array Array of client-executable tools.
		 */
		public function get_client_executable_tools() {
			$this->init();

			$client_safe_names = array(
				'client_summarize',
				'client_sentiment',
				'client_translate',
				'client_embed',
				'client_describe_image',
				'client_detect_objects',
				'client_transcribe_audio',
				'generate_chart',
				'generate_mermaid',
			);

			$client_tools = array();

			foreach ( $this->tools as $slug => $tool ) {
				if ( in_array( $slug, $client_safe_names, true ) ) {
					$client_tools[ $slug ] = $tool;
				}
			}

			return $client_tools;
		}

		/**
		 * Get tool metadata.
		 *
		 * Returns enhanced metadata for a tool if available.
		 *
		 * @since 1.2.0
		 *
		 * @param string $slug Tool slug.
		 * @return array|null Tool metadata or null if not found.
		 */
		public function get_tool_metadata( $slug ) {
			$this->init();
			$this->ensure_default_tools_loaded();

			$slug = sanitize_key( $slug );

			if ( ! isset( $this->tools[ $slug ] ) ) {
				return null;
			}

			return array(
				'contexts'   => array( 'server' ),
				'complexity' => 'medium',
				'cacheable'  => false,
				'parallel'   => true,
			);
		}
	}
}
