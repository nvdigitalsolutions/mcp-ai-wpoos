<?php
/**
 * Tool that probes a remote MCP REST namespace.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Wraps the WP_MCP_AI_Remote_Tester inside a callable assistant tool.
 */
class WP_MCP_AI_Tool_Probe_Remote_MCP implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Shortcuts_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'probe_remote_mcp';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Probe Remote MCP REST', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Runs the remote MCP connectivity tester against a live REST namespace to validate authentication and chat access.', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'base_url'     => array(
					'type'        => 'string',
					'description' => __( 'Base URL to the remote MCP REST namespace (for example https://example.com/wp-json/mcp-ai/v1).', 'mcp-ai-wpoos' ),
				),
				'token'        => array(
					'type'        => 'string',
					'description' => __( 'Optional bearer token sent via the Authorization header.', 'mcp-ai-wpoos' ),
				),
				'guest_token'  => array(
					'type'        => 'string',
					'description' => __( 'Optional guest token forwarded via the X-WP-MCP-AI-Guest header.', 'mcp-ai-wpoos' ),
				),
				'nonce'        => array(
					'type'        => 'string',
					'description' => __( 'Optional WordPress REST nonce passed through the X-WP-Nonce header.', 'mcp-ai-wpoos' ),
				),
				'assistant_id' => array(
					'type'        => 'integer',
					'minimum'     => 0,
					'description' => __( 'Assistant ID hint appended to the /assistants probe.', 'mcp-ai-wpoos' ),
				),
				'timeout'      => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => __( 'Request timeout in seconds.', 'mcp-ai-wpoos' ),
				),
				'verify_ssl'   => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to verify the remote SSL certificate.', 'mcp-ai-wpoos' ),
				),
				'user_agent'   => array(
					'type'        => 'string',
					'description' => __( 'Override the default user agent string.', 'mcp-ai-wpoos' ),
				),
			),
			'required'             => array( 'base_url' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_shortcut_tasks() {
		return array(
			array(
				'title'       => __( 'Probe a remote MCP deployment', 'mcp-ai-wpoos' ),
				'description' => __( 'Validate the /assistants and /chat endpoints for a live MCP REST namespace.', 'mcp-ai-wpoos' ),
				'arguments'   => new stdClass(),
			),
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Remote tester may not be available in production builds.
		if ( ! class_exists( 'WP_MCP_AI_Remote_Tester' ) ) {
			return new WP_Error( 'wp_mcp_ai_remote_tester_unavailable', __( 'Remote tester utility is not available in this build.', 'mcp-ai-wpoos' ) );
		}

		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to run remote MCP probes.', 'mcp-ai-wpoos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'mcp-ai-wpoos' ) );
		}
		$base_url = isset( $arguments['base_url'] ) ? trim( (string) $arguments['base_url'] ) : '';

		if ( '' === $base_url ) {
			return new WP_Error( 'wp_mcp_ai_remote_missing_url', __( 'Provide the base REST URL for the remote MCP deployment.', 'mcp-ai-wpoos' ) );
		}

		$probe_args = array();

		if ( isset( $arguments['token'] ) ) {
			$probe_args['token'] = (string) $arguments['token'];
		}

		if ( isset( $arguments['guest_token'] ) ) {
			$probe_args['guest_token'] = (string) $arguments['guest_token'];
		}

		if ( isset( $arguments['nonce'] ) ) {
			$probe_args['nonce'] = (string) $arguments['nonce'];
		}

		if ( isset( $arguments['assistant_id'] ) ) {
			$probe_args['assistant_id'] = absint( $arguments['assistant_id'] );
		}

		if ( isset( $arguments['timeout'] ) ) {
			$probe_args['timeout'] = absint( $arguments['timeout'] );
		}

		if ( array_key_exists( 'verify_ssl', $arguments ) ) {
			$probe_args['verify_ssl'] = (bool) $arguments['verify_ssl'];
		}

		if ( isset( $arguments['user_agent'] ) ) {
			$probe_args['user_agent'] = (string) $arguments['user_agent'];
		}

		$tester = new WP_MCP_AI_Remote_Tester();
		$result = $tester->probe( $base_url, $probe_args );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$result['checked_at'] = gmdate( 'c' );
		$result['summary']    = $this->build_summary( $result );
		$result['message']    = $result['summary'];

		return $result;
	}

	/**
	 * Build a short textual summary for successful probes.
	 *
	 * @param array $result Probe result payload.
	 * @return string
	 */
	protected function build_summary( array $result ) {
		$status = ! empty( $result['success'] ) ? __( 'success', 'mcp-ai-wpoos' ) : __( 'failure', 'mcp-ai-wpoos' );

		if ( empty( $result['checks'] ) || ! is_array( $result['checks'] ) ) {
			/* translators: %s: Overall probe status word. */
			return sprintf( __( 'Probe completed with %s.', 'mcp-ai-wpoos' ), $status );
		}

		$messages = array();

		foreach ( $result['checks'] as $check ) {
			if ( empty( $check['step'] ) ) {
				continue;
			}

			$step_status = isset( $check['status'] ) ? $check['status'] : $status;
			$messages[]  = sprintf( '%s: %s', $check['step'], $step_status );
		}

		if ( empty( $messages ) ) {
			/* translators: %s: Overall probe status word. */
			return sprintf( __( 'Probe completed with %s.', 'mcp-ai-wpoos' ), $status );
		}

		$step_summary = implode( '; ', $messages );

		/* translators: 1: Overall probe status word, 2: List of per-step status summaries. */
		return sprintf( __( 'Probe completed with %1$s (%2$s).', 'mcp-ai-wpoos' ), $status, $step_summary );
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'integration_external',

			'pattern_compatibility' => array( 'skill_router' ),

			'profession_tags'       => array( 'integration_specialist', 'api_developer' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',            // Only reads data, does not modify state.
			'external-api',         // Probes remote MCP servers.
			'requires-capability',  // Requires user capabilities.
		);
	}
}
