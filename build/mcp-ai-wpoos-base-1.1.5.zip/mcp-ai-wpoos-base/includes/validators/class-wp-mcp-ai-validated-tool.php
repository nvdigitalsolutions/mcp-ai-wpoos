<?php
/**
 * Validated Tool Base Class
 *
 * Base class for tools using Symfony Validator.
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../interfaces/interface-wp-mcp-ai-tool.php';
require_once __DIR__ . '/class-wp-mcp-ai-validator-service.php';

/**
 * Class WP_MCP_AI_Validated_Tool
 *
 * Abstract base class for tools that use Symfony Validator for argument validation.
 */
abstract class WP_MCP_AI_Validated_Tool implements WP_MCP_AI_Tool_Interface {

	/**
	 * Validator service instance.
	 *
	 * @var WP_MCP_AI\Validators\WP_MCP_AI_Validator_Service
	 */
	protected $validator_service;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->validator_service = \WP_MCP_AI\Validators\WP_MCP_AI_Validator_Service::get_instance();

		// If validator service is not available, this tool cannot function.
		if ( null === $this->validator_service ) {
			// This should be caught by the registration check, but we add defense in depth.
			return;
		}
	}

	/**
	 * Get the validation class name for this tool's arguments.
	 *
	 * Must return a fully qualified class name that defines
	 * validation constraints using Symfony Validator attributes.
	 *
	 * @return string Fully qualified class name.
	 */
	abstract protected function get_validation_class();

	/**
	 * Execute the tool with validated arguments.
	 *
	 * This method receives an object of the validation class type
	 * instead of a raw array, providing type safety and validation.
	 *
	 * @param object $validated_args Validated arguments object.
	 * @param array  $context        Execution context including user_id.
	 * @return array|\WP_Error Tool results or error.
	 */
	abstract protected function execute_validated( $validated_args, $context );

	/**
	 * Execute the tool (implements parent interface).
	 *
	 * Validates arguments before calling execute_validated().
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|\WP_Error Tool results or error.
	 */
	final public function execute( array $arguments = array(), array $context = array() ) {
		// Check if validator service is available.
		if ( null === $this->validator_service ) {
			return new \WP_Error(
				'validator_unavailable',
				__( 'Symfony Validator dependencies are not available. Please ensure the plugin is properly installed with all required dependencies, or use the non-validated version of this tool.', 'mcp-ai-wpoos' ),
				array(
					'tool_slug'   => $this->get_slug(),
					'php_version' => PHP_VERSION,
				)
			);
		}

		// Check PHP version - attributes require PHP 8.0+.
		if ( version_compare( PHP_VERSION, '8.0.0', '<' ) ) {
			return new \WP_Error(
				'php_version_too_old',
				sprintf(
					/* translators: %s: current PHP version */
					__( 'This tool uses Symfony Validator which requires PHP 8.0 or higher for attribute support. You are running PHP %s. Please upgrade PHP or use the non-validated version of this tool.', 'mcp-ai-wpoos' ),
					PHP_VERSION
				),
				array(
					'required_php' => '8.0.0',
					'current_php'  => PHP_VERSION,
					'tool_slug'    => $this->get_slug(),
				)
			);
		}

		// Get validation class.
		$class_name = $this->get_validation_class();

		if ( ! class_exists( $class_name ) ) {
			return new \WP_Error(
				'invalid_validation_class',
				sprintf(
					/* translators: %s: class name */
					__( 'Validation class not found: %s', 'mcp-ai-wpoos' ),
					$class_name
				)
			);
		}

		// Create validation object.
		$validated = new $class_name();

		// Map arguments to validation object properties.
		foreach ( $arguments as $key => $value ) {
			if ( property_exists( $validated, $key ) ) {
				$validated->$key = $value;
			}
		}

		// Validate.
		$violations = $this->validator_service->validate( $validated );

		if ( ! $this->validator_service->is_valid( $violations ) ) {
			return $this->validator_service->format_errors( $violations );
		}

		// Execute with validated arguments.
		return $this->execute_validated( $validated, $context );
	}
}
