<?php
/**
 * OCR Service
 *
 * Handles Optical Character Recognition (OCR) for scanned images and PDFs.
 * Supports multiple OCR providers with intelligent fallback.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.3.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OCR Service class
 *
 * Provides OCR functionality using multiple providers:
 * - OpenAI GPT-4 Vision (primary)
 * - Google Gemini Vision (secondary)
 * - Ollama Vision Models (local fallback)
 * - Tesseract OCR (system fallback)
 * - Unlimited-OCR (Baidu, self-hosted)
 * - DeepSeek-OCR (DeepSeek, self-hosted)
 *
 * @since 1.3.0
 */
class WP_MCP_AI_OCR_Service {
	use WP_MCP_AI_Media_Worker_Client;

	/**
	 * Minimum characters to consider PDF as having readable text.
	 *
	 * @var int
	 */
	const MIN_TEXT_THRESHOLD = 50;

	/**
	 * Maximum image dimension for OCR processing.
	 *
	 * @var int
	 */
	const MAX_IMAGE_DIMENSION = 2048;

	/**
	 * Maximum file size for OCR processing (50MB).
	 *
	 * @var int
	 */
	const MAX_FILE_SIZE = 52428800;

	/**
	 * Default timeout for OCR operations (seconds).
	 *
	 * @var int
	 */
	const DEFAULT_TIMEOUT = 300;

	/**
	 * Default maximum PDF pages to render when no explicit cap is supplied.
	 *
	 * @var int
	 */
	const DEFAULT_MAX_PAGES = 50;

	/**
	 * Maximum retry attempts for transient failures.
	 *
	 * @var int
	 */
	const MAX_RETRIES = 3;

	/**
	 * Circuit breaker cooldown period (seconds).
	 *
	 * @var int
	 */
	const CIRCUIT_BREAKER_COOLDOWN = 300;

	/**
	 * Singleton instance of OpenAI client.
	 *
	 * @var WP_MCP_AI_OpenAI_Client|null
	 */
	private static $openai_client = null;

	/**
	 * Singleton instance of Gemini client.
	 *
	 * @var WP_MCP_AI_Gemini_Client|null
	 */
	private static $gemini_client = null;

	/**
	 * Circuit breaker state for providers.
	 *
	 * @var array
	 */
	private static $circuit_breaker = array();

	/**
	 * Extract text from image using OCR.
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    OCR options.
	 * @return string|WP_Error Extracted text or error.
	 */
	public function extract_text_from_image( $image_path, $options = array() ) {
		// Validate input.
		$validation = $this->validate_image_input( $image_path );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		// Get defaults from settings - check image production settings first, then fall back to document generation.
		$image_settings = get_option( 'wp_mcp_ai_image_production_settings', array() );
		$doc_settings   = get_option( 'wp_mcp_ai_document_generation_settings', array() );

		// Merge settings with image production taking priority.
		$ocr_settings = array_merge( $doc_settings, array_filter( $image_settings ) );

		$defaults = array(
			'provider'   => 'auto', // auto, openai, gemini, ollama, tesseract.
			'preprocess' => isset( $ocr_settings['ocr_preprocessing'] ) ? (bool) $ocr_settings['ocr_preprocessing'] : true,
			'language'   => 'eng',  // OCR language.
			'enhance'    => true,   // Enhance image quality.
			'timeout'    => isset( $ocr_settings['ocr_timeout'] ) ? absint( $ocr_settings['ocr_timeout'] ) : self::DEFAULT_TIMEOUT,
		);
		$options  = wp_parse_args( $options, $defaults );

		// Preprocess image if enabled.
		if ( $options['preprocess'] ) {
			$processed_image = $this->preprocess_image( $image_path, $options );
			if ( is_wp_error( $processed_image ) ) {
				// Continue with original if preprocessing fails.
				WP_MCP_AI_Logger::log_event(
					'ocr_preprocessing_failed',
					'Image preprocessing failed, using original',
					array( 'error' => $processed_image->get_error_message() )
				);
			} else {
				$image_path = $processed_image;
			}
		}

		// Try the Media Worker sidecar first (opt-in routing — fails fast
		// when no sidecar URL is configured or the health check fails). The
		// worker OCRs the uploaded file itself, so the image must be sent
		// as a multipart upload — never as a local path.
		if ( $this->is_sidecar_upload_supported() ) {
			$sidecar = $this->sidecar_upload(
				'/api/ocr/recognize',
				$image_path,
				array(
					'language' => isset( $options['language'] ) ? $options['language'] : 'eng',
				),
				120
			);
			if ( ! is_wp_error( $sidecar ) && isset( $sidecar['text'] ) ) {
				// Clean up preprocessed temp file if created.
				if ( isset( $processed_image ) && ! is_wp_error( $processed_image ) && $processed_image !== $image_path ) {
					if ( file_exists( $processed_image ) ) {
						wp_delete_file( $processed_image );
					}
				}
				return $sidecar['text'];
			}
		}

		// Allow custom OCR implementation via filter.
		/**
		 * Filter to allow custom OCR text extraction.
		 *
		 * Runs after the sidecar attempt: legacy local-Node handlers only
		 * execute when a local Node.js is installed.
		 *
		 * @param string|false $result Extracted text or false.
		 * @param array        $params Extraction parameters (image_path, options).
		 */
		$filter_result = apply_filters(
			'wp_mcp_ai_ocr_extract_text',
			false,
			array(
				'image_path' => $image_path,
				'options'    => $options,
			)
		);
		if ( false !== $filter_result ) {
			// Clean up preprocessed temp file if created.
			if ( isset( $processed_image ) && ! is_wp_error( $processed_image ) && $processed_image !== $image_path ) {
				if ( file_exists( $processed_image ) ) {
					wp_delete_file( $processed_image );
				}
			}
			return $filter_result;
		}

		// Determine provider.
		$provider = $options['provider'];
		if ( 'auto' === $provider ) {
			$provider = $this->determine_best_provider();
		}

		// Try extraction with selected provider.
		$result = $this->extract_with_provider( $image_path, $provider, $options );

		// If failed and auto mode, try fallback providers.
		if ( is_wp_error( $result ) && 'auto' === $options['provider'] ) {
			$primary_error = $result->get_error_message();
			WP_MCP_AI_Logger::log_event(
				'ocr_fallback_triggered',
				sprintf( 'Primary OCR provider (%s) failed, trying fallbacks', $provider ),
				array(
					'primary_provider' => $provider,
					'error'            => $primary_error,
				)
			);

			$fallback_providers = $this->get_fallback_providers( $provider );
			foreach ( $fallback_providers as $fallback ) {
				WP_MCP_AI_Logger::log_event(
					'ocr_trying_fallback',
					sprintf( 'Trying fallback provider: %s', $fallback ),
					array( 'provider' => $fallback )
				);

				$result = $this->extract_with_provider( $image_path, $fallback, $options );
				if ( ! is_wp_error( $result ) ) {
					WP_MCP_AI_Logger::log_event(
						'ocr_fallback_success',
						sprintf( 'Fallback provider succeeded: %s', $fallback ),
						array( 'provider' => $fallback )
					);
					break;
				}
			}
		}

		// Clean up preprocessed temp file if created.
		if ( isset( $processed_image ) && ! is_wp_error( $processed_image ) && $processed_image !== $image_path ) {
			if ( file_exists( $processed_image ) ) {
				wp_delete_file( $processed_image );
			}
		}

		return $result;
	}

	/**
	 * Extract text from PDF using OCR.
	 *
	 * Converts PDF pages to images and applies OCR to each page.
	 *
	 * @param string $pdf_path Path to PDF file.
	 * @param array  $options  OCR options.
	 * @return string|WP_Error Extracted text or error.
	 */
	public function extract_text_from_pdf( $pdf_path, $options = array() ) {
		// Validate input.
		$validation = $this->validate_pdf_input( $pdf_path );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		// Default options.
		$defaults = array(
			'max_pages' => 0,       // 0 = all pages.
			'provider'  => 'auto',
			'dpi'       => 300,     // DPI for PDF to image conversion.
		);
		$options  = wp_parse_args( $options, $defaults );

		// Sidecar-first scanned-PDF chain (Proposal 079, Appendix B): the
		// worker's ingest route extracts the text layer and, when empty,
		// rasterises + OCRs the pages in one call - no local Ghostscript or
		// per-page round trips. Only when the caller has not pinned a vision
		// provider (the worker chain is tesseract) and the sidecar is
		// reachable; every failure falls through to the local pipeline.
		$provider_opt = isset( $options['provider'] ) ? $options['provider'] : 'auto';
		if ( in_array( $provider_opt, array( 'auto', 'tesseract' ), true ) && $this->is_sidecar_upload_supported() ) {
			$fields = array();
			if ( $options['max_pages'] > 0 ) {
				$fields['maxPages'] = (int) $options['max_pages'];
			}
			$sidecar = $this->sidecar_upload( '/api/ingest/parse', $pdf_path, $fields, 300 );
			if ( ! is_wp_error( $sidecar ) && isset( $sidecar['format'] ) && 'pdf' === $sidecar['format'] && ! empty( $sidecar['text'] ) ) {
				WP_MCP_AI_Logger::log_event(
					'ocr_pdf_sidecar',
					'Scanned-PDF OCR handled by the Media Worker',
					array(
						'pages' => isset( $sidecar['meta']['pages'] ) ? $sidecar['meta']['pages'] : 0,
						'ocr'   => isset( $sidecar['meta']['ocr'] ) ? (bool) $sidecar['meta']['ocr'] : false,
					)
				);

				return (string) $sidecar['text'];
			}
		}

		// Convert PDF pages to images.
		$images = $this->convert_pdf_to_images( $pdf_path, $options );
		if ( is_wp_error( $images ) ) {
			return $images;
		}

		// Extract text from each image.
		$all_text     = array();
		$failed_pages = array();
		foreach ( $images as $page_num => $image_path ) {
			$text = $this->extract_text_from_image( $image_path, $options );

			// Clean up temp image.
			if ( file_exists( $image_path ) ) {
				wp_delete_file( $image_path );
			}

			if ( is_wp_error( $text ) ) {
				$error_message  = $text->get_error_message();
				$failed_pages[] = array(
					'page'  => $page_num + 1,
					'error' => $error_message,
				);

				WP_MCP_AI_Logger::log_event(
					'ocr_page_failed',
					sprintf( 'OCR failed for page %d: %s', $page_num + 1, $error_message ),
					array(
						'page'  => $page_num + 1,
						'error' => $error_message,
					)
				);
				continue;
			}

			$all_text[] = sprintf( "--- Page %d ---\n%s", $page_num + 1, $text );
		}

		if ( empty( $all_text ) ) {
			$error_details = '';
			if ( ! empty( $failed_pages ) ) {
				$error_details = ' Failed pages: ' . wp_json_encode( $failed_pages );
			}
			return new WP_Error(
				'ocr_failed',
				__( 'Failed to extract text from any pages.', 'mcp-ai-wpoos-pro' ) . $error_details
			);
		}

		// Add summary if some pages failed.
		if ( ! empty( $failed_pages ) ) {
			$summary    = sprintf(
				"\n\n--- OCR Summary ---\nSuccessfully processed: %d page(s)\nFailed: %d page(s)",
				count( $all_text ),
				count( $failed_pages )
			);
			$all_text[] = $summary;
		}

		return implode( "\n\n", $all_text );
	}

	/**
	 * Check if PDF appears to be scanned (image-only, no readable text).
	 *
	 * @param string $pdf_path Path to PDF file.
	 * @return bool True if PDF appears to be scanned.
	 */
	public function is_scanned_pdf( $pdf_path ) {
		// Try to extract text using standard method.
		$text = $this->extract_standard_text( $pdf_path );

		if ( is_wp_error( $text ) ) {
			// If extraction failed, assume it's scanned.
			return true;
		}

		// Remove whitespace and count characters.
		$clean_text = trim( preg_replace( '/\s+/', '', $text ) );

		// If less than threshold characters, consider it scanned.
		return strlen( $clean_text ) < self::MIN_TEXT_THRESHOLD;
	}

	/**
	 * Preprocess image for better OCR results.
	 *
	 * Applies: resizing, grayscale, contrast enhancement, noise reduction.
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Processing options.
	 * @return string|WP_Error Path to processed image or error.
	 */
	protected function preprocess_image( $image_path, $options = array() ) {
		// Check if Sharp is available via Node.js.
		$sharp_available = $this->is_sharp_available();

		if ( $sharp_available ) {
			return $this->preprocess_with_sharp( $image_path );
		}

		// Fallback to Imagick if available.
		if ( extension_loaded( 'imagick' ) ) {
			return $this->preprocess_with_imagick( $image_path, $options );
		}

		// No preprocessing available.
		return new WP_Error( 'no_preprocessor', __( 'No image preprocessing tools available.', 'mcp-ai-wpoos-pro' ) );
	}

	/**
	 * Preprocess image using Sharp (Node.js).
	 *
	 * @param string $image_path Path to image file.
	 * @return string|WP_Error Path to processed image or error.
	 */
	protected function preprocess_with_sharp( $image_path ) {
		$service_path = WP_MCP_AI_PRO_PATH . 'node-services/image-preprocess-service.js';

		if ( ! file_exists( $service_path ) ) {
			return new WP_Error( 'service_not_found', __( 'Image preprocessing service not found.', 'mcp-ai-wpoos-pro' ) );
		}

		$temp_output = tempnam( sys_get_temp_dir(), 'ocr_preprocessed_' ) . '.png';

		$args = wp_json_encode(
			array(
				'input'     => $image_path,
				'output'    => $temp_output,
				'maxWidth'  => self::MAX_IMAGE_DIMENSION,
				'maxHeight' => self::MAX_IMAGE_DIMENSION,
				'grayscale' => true,
				'normalize' => true,
				'sharpen'   => true,
			)
		);

		// Run via the Process Service (array command, bounded timeout) —
		// the same invocation the rest of the codebase uses instead of
		// raw exec().
		$process_service = \WP_MCP_AI\Services\WP_MCP_AI_Process_Service::get_instance();
		$process_result  = $process_service->run_silent(
			array( 'node', $service_path, 'preprocess', $args ),
			array( 'timeout' => 120 )
		);

		if ( isset( $process_result['disabled'] ) && $process_result['disabled'] ) {
			if ( file_exists( $temp_output ) ) {
				wp_delete_file( $temp_output );
			}
			return $this->log_and_return_error(
				'preprocessing_failed',
				'ocr_sharp_failed',
				'Sharp preprocessing failed: process execution is disabled on this server',
				array()
			);
		}

		if ( isset( $process_result['timeout'] ) && $process_result['timeout'] ) {
			if ( file_exists( $temp_output ) ) {
				wp_delete_file( $temp_output );
			}
			return $this->log_and_return_error(
				'preprocessing_failed',
				'ocr_sharp_timeout',
				'Sharp preprocessing command timed out',
				array()
			);
		}

		$return_code = $process_result['exit_code'];
		$output      = explode( "\n", $process_result['output'] . $process_result['error'] );

		if ( 0 !== $return_code ) {
			if ( file_exists( $temp_output ) ) {
				wp_delete_file( $temp_output );
			}
			return $this->log_and_return_error(
				'preprocessing_failed',
				'ocr_sharp_failed',
				'Sharp preprocessing command failed',
				array(
					'output' => implode( "\n", $output ),
					'code'   => $return_code,
				)
			);
		}

		return $temp_output;
	}

	/**
	 * Preprocess image using Imagick (PHP extension).
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Processing options.
	 * @return string|WP_Error Path to processed image or error.
	 */
	protected function preprocess_with_imagick( $image_path, $options = array() ) {
		try {
			$image = new Imagick( $image_path );

			// Resize if too large.
			$width  = $image->getImageWidth();
			$height = $image->getImageHeight();
			if ( $width > self::MAX_IMAGE_DIMENSION || $height > self::MAX_IMAGE_DIMENSION ) {
				$image->thumbnailImage( self::MAX_IMAGE_DIMENSION, self::MAX_IMAGE_DIMENSION, true );
			}

			// Convert to grayscale.
			$image->setImageType( Imagick::IMGTYPE_GRAYSCALE );

			// Enhance contrast.
			$image->normalizeImage();
			$image->enhanceImage();

			// Sharpen slightly.
			$image->sharpenImage( 0, 1 );

			// Reduce noise.
			$image->despeckleImage();

			// Save to temp file.
			$temp_output = tempnam( sys_get_temp_dir(), 'ocr_preprocessed_' ) . '.png';
			$image->setImageFormat( 'png' );
			$image->writeImage( $temp_output );
			$image->clear();
			$image->destroy();

			return $temp_output;
		} catch ( Exception $e ) {
			return $this->log_and_return_error(
				'imagick_failed',
				'ocr_imagick_failed',
				'Imagick preprocessing failed',
				array( 'error' => $e->getMessage() )
			);
		}
	}

	/**
	 * Convert PDF pages to images.
	 *
	 * @param string $pdf_path Path to PDF file.
	 * @param array  $options  Conversion options.
	 * @return array|WP_Error Array of image paths or error.
	 */
	protected function convert_pdf_to_images( $pdf_path, $options = array() ) {
		$dpi       = isset( $options['dpi'] ) ? absint( $options['dpi'] ) : 300;
		$max_pages = isset( $options['max_pages'] ) ? absint( $options['max_pages'] ) : 0;

		// Try Imagick first (preferred for PDF to image).
		if ( extension_loaded( 'imagick' ) ) {
			return $this->convert_pdf_with_imagick( $pdf_path, $dpi, $max_pages );
		}

		// Fallback: try pdftoppm command-line tool (safe probe — never fatals
		// when exec()/proc_open are disabled).
		if ( $this->is_cli_tool_available( 'pdftoppm' ) ) {
			return $this->convert_pdf_with_pdftoppm( $pdf_path, $dpi, $max_pages );
		}

		return new WP_Error( 'no_converter', __( 'No PDF to image converter available. Install Imagick extension or poppler-utils.', 'mcp-ai-wpoos-pro' ) );
	}

	/**
	 * Convert PDF to images using Imagick.
	 *
	 * @param string $pdf_path  Path to PDF file.
	 * @param int    $dpi       DPI for conversion.
	 * @param int    $max_pages Maximum pages to convert (0 = all).
	 * @return array|WP_Error Array of image paths or error.
	 */
	protected function convert_pdf_with_imagick( $pdf_path, $dpi = 300, $max_pages = 0 ) {
		$images = array();
		$pdf    = null;

		// Bound the render pass: an uncapped PDF could produce thousands of
		// temp PNGs held in memory until the whole document is converted.
		if ( $max_pages <= 0 ) {
			$max_pages = self::DEFAULT_MAX_PAGES;
		}

		try {
			$pdf = new Imagick();
			$pdf->setResolution( $dpi, $dpi );
			$pdf->readImage( $pdf_path );

			$num_pages        = $pdf->getNumberImages();
			$pages_to_process = ( $max_pages > 0 && $max_pages < $num_pages ) ? $max_pages : $num_pages;

			for ( $i = 0; $i < $pages_to_process; $i++ ) {
				$pdf->setIteratorIndex( $i );
				$pdf->setImageFormat( 'png' );
				$pdf->setImageBackgroundColor( 'white' );
				$pdf->setImageAlphaChannel( Imagick::ALPHACHANNEL_REMOVE );
				$pdf->mergeImageLayers( Imagick::LAYERMETHOD_FLATTEN );

				$temp_image = tempnam( sys_get_temp_dir(), 'pdf_page_' . $i . '_' ) . '.png';
				$pdf->writeImage( $temp_image );
				$images[ $i ] = $temp_image;
			}

			$pdf->clear();
			$pdf->destroy();

			return $images;
		} catch ( Exception $e ) {
			// Clean up any temp files created before the error.
			foreach ( $images as $temp_file ) {
				if ( file_exists( $temp_file ) ) {
					wp_delete_file( $temp_file );
				}
			}

			// Clean up Imagick object if it exists.
			if ( $pdf instanceof Imagick ) {
				$pdf->clear();
				$pdf->destroy();
			}

			return $this->log_and_return_error(
				'imagick_conversion_failed',
				'ocr_imagick_pdf_failed',
				'Imagick PDF-to-image conversion failed',
				array( 'error' => $e->getMessage() )
			);
		}
	}

	/**
	 * Convert PDF to images using pdftoppm command-line tool.
	 *
	 * @param string $pdf_path  Path to PDF file.
	 * @param int    $dpi       DPI for conversion.
	 * @param int    $max_pages Maximum pages to convert (0 = all).
	 * @return array|WP_Error Array of image paths or error.
	 */
	protected function convert_pdf_with_pdftoppm( $pdf_path, $dpi = 300, $max_pages = 0 ) {
		$temp_prefix = tempnam( sys_get_temp_dir(), 'pdf_page_' );
		$cmd         = sprintf(
			'pdftoppm -png -r %d %s %s %s 2>&1',
			(int) $dpi,
			$max_pages > 0 ? '-l ' . (int) $max_pages : '',
			escapeshellarg( $pdf_path ),
			escapeshellarg( $temp_prefix )
		);

		$result = $this->run_cli_command( $cmd );

		if ( $result['disabled'] ) {
			return $this->log_and_return_error(
				'pdftoppm_failed',
				'ocr_pdftoppm_failed',
				'pdftoppm conversion failed: process execution (exec/proc_open) is disabled on this server',
				array()
			);
		}

		if ( 0 !== $result['return_code'] ) {
			return $this->log_and_return_error(
				'pdftoppm_failed',
				'ocr_pdftoppm_failed',
				'pdftoppm conversion failed',
				array(
					'output' => $result['output'],
					'code'   => $result['return_code'],
				)
			);
		}

		// Find generated images.
		$images = glob( $temp_prefix . '-*.png' );
		if ( empty( $images ) ) {
			return new WP_Error( 'no_images_generated', __( 'No images were generated from PDF.', 'mcp-ai-wpoos-pro' ) );
		}

		// Reindex array starting from 0.
		return array_values( $images );
	}

	/**
	 * Extract text using specified OCR provider.
	 *
	 * @param string $image_path Path to image file.
	 * @param string $provider   Provider name (openai, gemini, ollama, tesseract).
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_provider( $image_path, $provider, $options = array() ) {
		// Check circuit breaker.
		if ( $this->is_circuit_open( $provider ) ) {
			WP_MCP_AI_Logger::log_event(
				'ocr_provider_skipped',
				sprintf( 'Provider %s skipped due to open circuit breaker', $provider ),
				array( 'provider' => $provider )
			);
			return new WP_Error(
				'provider_unavailable',
				/* translators: %s: provider name */
				sprintf( __( 'Provider %s is temporarily unavailable', 'mcp-ai-wpoos-pro' ), $provider )
			);
		}

		// Execute with retry logic.
		$result = $this->execute_with_retry(
			function () use ( $image_path, $provider, $options ) {
				switch ( $provider ) {
					case 'openai':
						return $this->extract_with_openai( $image_path, $options );
					case 'gemini':
						return $this->extract_with_gemini( $image_path, $options );
					case 'anthropic':
						return $this->extract_with_anthropic( $image_path, $options );
					case 'ollama':
						return $this->extract_with_ollama( $image_path, $options );
					case 'tesseract':
						return $this->extract_with_tesseract( $image_path, $options );
					case 'unlimited_ocr':
						return $this->extract_with_unlimited_ocr( $image_path, $options );
					case 'deepseek_ocr':
						return $this->extract_with_deepseek_ocr( $image_path, $options );
					default:
						return new WP_Error( 'unknown_provider', sprintf( 'Unknown OCR provider: %s', $provider ) );
				}
			}
		);

		// Update circuit breaker based on result.
		if ( is_wp_error( $result ) ) {
			$error_code = $result->get_error_code();
			// Open circuit for persistent failures (not validation errors).
			$validation_errors = array( 'no_api_key', 'no_endpoint', 'file_not_found' );
			if ( ! in_array( $error_code, $validation_errors, true ) ) {
				$this->open_circuit( $provider, $result->get_error_message() );
			}
		} else {
			// Success - close circuit if it was open.
			$this->close_circuit( $provider );
		}

		return $result;
	}

	/**
	 * Extract text using OpenAI Vision API.
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_openai( $image_path, $options = array() ) {
		if ( ! WP_MCP_AI_Credential_Resolver::has_credentials( 'openai' ) ) {
			return new WP_Error( 'no_api_key', __( 'OpenAI API key not configured.', 'mcp-ai-wpoos-pro' ) );
		}

		// Encode image to base64.
		$image_data = file_get_contents( $image_path );
		$base64     = base64_encode( $image_data );
		$mime_type  = $this->get_mime_type( $image_path );

		// Get singleton client instance.
		if ( null === self::$openai_client ) {
			self::$openai_client = new WP_MCP_AI_OpenAI_Client();
		}
		$client = self::$openai_client;

		$messages = array(
			array(
				'role'    => 'user',
				'content' => array(
					array(
						'type' => 'text',
						'text' => 'Extract all text from this image. Return only the extracted text, maintaining the original layout and structure as much as possible. Do not add any commentary or explanation.',
					),
					array(
						'type'      => 'image_url',
						'image_url' => array(
							'url'    => "data:{$mime_type};base64,{$base64}",
							'detail' => 'high',
						),
					),
				),
			),
		);

		$response = $client->create_chat_completion(
			$messages,
			array(
				'model'      => 'gpt-4.1',
				'max_tokens' => 4096,
			)
		);

		if ( is_wp_error( $response ) ) {
			WP_MCP_AI_Logger::log_event(
				'ocr_openai_failed',
				'OpenAI Vision OCR failed',
				array( 'error' => $response->get_error_message() )
			);
			return new WP_Error(
				'ocr_openai_failed',
				sprintf(
					/* translators: %s: error message from API */
					__( 'OpenAI Vision OCR failed: %s. Will try fallback provider.', 'mcp-ai-wpoos-pro' ),
					$response->get_error_message()
				)
			);
		}

		// Some OpenAI-compatible gateways return message.content as an array of
		// parts — use the shared shape-tolerant extractor.
		$text = $this->extract_text_from_response( $response );

		if ( '' !== $text ) {
			return $text;
		}

		return new WP_Error( 'invalid_response', __( 'Invalid response from OpenAI API. Will try fallback provider.', 'mcp-ai-wpoos-pro' ) );
	}

	/**
	 * Extract text using Google Gemini Vision.
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_gemini( $image_path, $options = array() ) {
		if ( ! WP_MCP_AI_Credential_Resolver::has_credentials( 'gemini' ) ) {
			return new WP_Error( 'no_api_key', __( 'Gemini API key not configured.', 'mcp-ai-wpoos-pro' ) );
		}

		$settings = get_option( 'wp_mcp_ai_settings', array() );

		// Encode image to base64.
		$image_data = file_get_contents( $image_path );
		$base64     = base64_encode( $image_data );
		$mime_type  = $this->get_mime_type( $image_path );

		// Get singleton client instance.
		if ( null === self::$gemini_client ) {
			self::$gemini_client = new WP_MCP_AI_Gemini_Client();
		}
		$client = self::$gemini_client;

		$model = isset( $settings['default_gemini_model'] ) && '' !== $settings['default_gemini_model'] ? $settings['default_gemini_model'] : 'gemini-2.5-flash';

		// The client's public API is create_chat_completion() — pass the
		// image as an inline-base64 segment (format_image_part turns the
		// 'data' key into a Gemini inlineData part).
		$messages = array(
			array(
				'role'    => 'user',
				'content' => array(
					array(
						'type' => 'text',
						'text' => 'Extract all text from this image. Return only the extracted text, maintaining the original layout and structure as much as possible.',
					),
					array(
						'type'      => 'image_url',
						'data'      => $base64,
						'mime_type' => $mime_type,
					),
				),
			),
		);

		$response = $client->create_chat_completion(
			$messages,
			array(
				'model' => $model,
			)
		);

		if ( is_wp_error( $response ) ) {
			WP_MCP_AI_Logger::log_event(
				'ocr_gemini_failed',
				'Gemini Vision OCR failed',
				array( 'error' => $response->get_error_message() )
			);
			return new WP_Error(
				'ocr_gemini_failed',
				sprintf(
					/* translators: %s: error message from API */
					__( 'Gemini Vision OCR failed: %s. Will try fallback provider.', 'mcp-ai-wpoos-pro' ),
					$response->get_error_message()
				)
			);
		}

		// create_chat_completion() normalises the Gemini response to the
		// OpenAI shape (message.content may be a segments array); keep a raw-
		// candidates fallback for custom base URLs returning the native
		// Gemini envelope.
		$text = $this->extract_text_from_response( $response );

		if ( '' !== $text ) {
			return $text;
		}

		return new WP_Error( 'invalid_response', __( 'Invalid response from Gemini API. Will try fallback provider.', 'mcp-ai-wpoos-pro' ) );
	}

	/**
	 * Extract plain text from a normalized provider response message.
	 *
	 * Providers normalize to an OpenAI-style shape, but some clients return
	 * message.content as an array of parts instead of a string.
	 *
	 * @param array $response Provider response payload.
	 * @return string Extracted text (may be empty).
	 */
	protected function extract_text_from_response( $response ) {
		$message = isset( $response['choices'][0]['message'] ) ? $response['choices'][0]['message'] : array();

		if ( isset( $message['content'] ) ) {
			if ( is_string( $message['content'] ) ) {
				return trim( $message['content'] );
			}

			if ( is_array( $message['content'] ) ) {
				$text = '';
				foreach ( $message['content'] as $part ) {
					if ( is_array( $part ) && isset( $part['text'] ) ) {
						$text .= $part['text'];
					} elseif ( is_string( $part ) ) {
						$text .= $part;
					}
				}
				return trim( $text );
			}
		}

		// Raw candidates shape (custom base URLs).
		if ( isset( $response['candidates'][0]['content']['parts'] ) && is_array( $response['candidates'][0]['content']['parts'] ) ) {
			$text = '';
			foreach ( $response['candidates'][0]['content']['parts'] as $part ) {
				if ( isset( $part['text'] ) ) {
					$text .= $part['text'];
				}
			}
			return trim( $text );
		}

		return '';
	}

	/**
	 * Extract text using Anthropic Claude Vision.
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_anthropic( $image_path, $options = array() ) {
		if ( ! WP_MCP_AI_Credential_Resolver::has_credentials( 'anthropic' ) ) {
			return new WP_Error( 'no_api_key', __( 'Anthropic API key not configured.', 'mcp-ai-wpoos-pro' ) );
		}

		if ( ! class_exists( 'WP_MCP_AI_Anthropic_Client' ) ) {
			return new WP_Error( 'missing_client', __( 'Anthropic client class not found.', 'mcp-ai-wpoos-pro' ) );
		}

		$settings = get_option( 'wp_mcp_ai_settings', array() );

		// Encode image to base64 and build a data URL — the Anthropic
		// client already knows how to turn that into a base64 image block.
		$image_data = file_get_contents( $image_path );
		if ( false === $image_data ) {
			return new WP_Error( 'read_failed', __( 'Failed to read image file for OCR.', 'mcp-ai-wpoos-pro' ) );
		}
		$mime_type = $this->get_mime_type( $image_path );
		$data_url  = 'data:' . $mime_type . ';base64,' . base64_encode( $image_data );

		$model = isset( $settings['anthropic_vision_model'] ) && '' !== $settings['anthropic_vision_model']
			? $settings['anthropic_vision_model']
			: ( isset( $settings['anthropic_model'] ) && '' !== $settings['anthropic_model'] ? $settings['anthropic_model'] : 'claude-sonnet-4-6' );

		$client = new WP_MCP_AI_Anthropic_Client();

		$messages = array(
			array(
				'role'    => 'user',
				'content' => array(
					array(
						'type'      => 'image_url',
						'image_url' => array( 'url' => $data_url ),
					),
					array(
						'type' => 'text',
						'text' => 'Extract all text from this image. Return only the extracted text, maintaining the original layout and structure as much as possible.',
					),
				),
			),
		);

		$response = $client->create_chat_completion(
			$messages,
			array(
				'model'      => $model,
				'max_tokens' => 4096,
			)
		);

		if ( is_wp_error( $response ) ) {
			WP_MCP_AI_Logger::log_event(
				'ocr_anthropic_failed',
				'Anthropic Vision OCR failed',
				array( 'error' => $response->get_error_message() )
			);
			return new WP_Error(
				'ocr_anthropic_failed',
				sprintf(
					/* translators: %s: error message from API */
					__( 'Anthropic Vision OCR failed: %s. Will try fallback provider.', 'mcp-ai-wpoos-pro' ),
					$response->get_error_message()
				)
			);
		}

		// Anthropic normalizes content blocks into message.content (may be an
		// array of parts) — use the shared shape-tolerant extractor.
		$text = $this->extract_text_from_response( $response );

		if ( '' !== $text ) {
			return $text;
		}

		return new WP_Error( 'invalid_response', __( 'Invalid response from Anthropic API. Will try fallback provider.', 'mcp-ai-wpoos-pro' ) );
	}

	/**
	 * Extract text using Ollama Vision model.
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_ollama( $image_path, $options = array() ) {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['ollama_endpoint'] ) ) {
			return new WP_Error( 'no_endpoint', __( 'Ollama endpoint not configured.', 'mcp-ai-wpoos-pro' ) );
		}

		// Encode image to base64.
		$image_data = file_get_contents( $image_path );
		$base64     = base64_encode( $image_data );

		// Use llava or similar vision model.
		$model = 'llava';

		$endpoint = trailingslashit( $settings['ollama_endpoint'] ) . 'api/generate';

		$body = wp_json_encode(
			array(
				'model'  => $model,
				'prompt' => 'Extract all text from this image. Return only the extracted text, maintaining the original layout.',
				'images' => array( $base64 ),
				'stream' => false,
			)
		);

		$response = wp_remote_post(
			$endpoint,
			array(
				'body'    => $body,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'timeout' => self::DEFAULT_TIMEOUT,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $body['response'] ) && ! empty( trim( $body['response'] ) ) ) {
			return trim( $body['response'] );
		}

		return new WP_Error( 'invalid_response', __( 'Invalid or empty response from Ollama.', 'mcp-ai-wpoos-pro' ) );
	}

	/**
	 * Extract text using Tesseract OCR.
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_tesseract( $image_path, $options = array() ) {
		$language = isset( $options['language'] ) ? $options['language'] : 'eng';

		// Try Node.js service first (best performance).
		$node_result = $this->extract_with_node_ocr( $image_path, $options );
		if ( ! is_wp_error( $node_result ) ) {
			return $node_result;
		}

		// Try PHP wrapper if available.
		if ( class_exists( '\thiagoalessio\TesseractOCR\TesseractOCR' ) ) {
			try {
				$ocr = new \thiagoalessio\TesseractOCR\TesseractOCR( $image_path );
				$ocr->lang( $language );

				// Set optimal PSM for document OCR.
				$ocr->psm( 3 ); // Fully automatic page segmentation.

				$text = $ocr->run();
				return trim( $text );
			} catch ( \Exception $e ) {
				// Fall through to command-line method.
				WP_MCP_AI_Logger::log_event(
					'tesseract_wrapper_failed',
					'Tesseract PHP wrapper failed, trying command-line',
					array( 'error' => $e->getMessage() )
				);
			}
		}

		// Fallback to command-line tesseract (safe probe — never fatals when
		// exec()/proc_open are disabled).
		if ( ! $this->is_cli_tool_available( 'tesseract' ) ) {
			return new WP_Error(
				'tesseract_not_found',
				__( 'Tesseract OCR is not installed on the system. The plugin includes pre-bundled Node.js OCR service, but it appears unavailable. Please ensure Node.js is installed or install system Tesseract with: apt-get install tesseract-ocr (Linux) or brew install tesseract (macOS).', 'mcp-ai-wpoos-pro' ),
				array(
					'bundled_service' => 'Node.js OCR service (included)',
					'system_install'  => 'apt-get install tesseract-ocr',
				)
			);
		}

		$output_file = tempnam( sys_get_temp_dir(), 'ocr_' );

		$cmd = sprintf(
			'tesseract %s %s -l %s 2>&1',
			escapeshellarg( $image_path ),
			escapeshellarg( $output_file ),
			escapeshellarg( $language )
		);

		$result = $this->run_cli_command( $cmd );

		$text_file = $output_file . '.txt';

		if ( ! $result['disabled'] && 0 === $result['return_code'] && file_exists( $text_file ) ) {
			$text = file_get_contents( $text_file );
			if ( file_exists( $text_file ) ) {
				wp_delete_file( $text_file );
			}
			if ( file_exists( $output_file ) ) {
				wp_delete_file( $output_file );
			}
			return trim( $text );
		}

		if ( file_exists( $text_file ) ) {
			wp_delete_file( $text_file );
		}
		if ( file_exists( $output_file ) ) {
			wp_delete_file( $output_file );
		}

		$error_message = $result['disabled']
			? 'Tesseract OCR failed: process execution (exec/proc_open) is disabled on this server'
			: 'Tesseract OCR failed';

		return $this->log_and_return_error(
			'tesseract_failed',
			'ocr_tesseract_failed',
			$error_message,
			array(
				'output' => $result['output'],
				'code'   => $result['return_code'],
			)
		);
	}

	/**
	 * Extract text using self-hosted Unlimited-OCR.
	 *
	 * @since 1.5.0
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_unlimited_ocr( $image_path, $options = array() ) {
		return $this->extract_with_self_hosted_ocr( $image_path, 'unlimited_ocr', $options );
	}

	/**
	 * Extract text using self-hosted DeepSeek-OCR.
	 *
	 * @since 1.5.0
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_deepseek_ocr( $image_path, $options = array() ) {
		return $this->extract_with_self_hosted_ocr( $image_path, 'deepseek_ocr', $options );
	}

	/**
	 * Extract text using a self-hosted OCR model (Unlimited-OCR or DeepSeek-OCR).
	 *
	 * @since 1.5.0
	 *
	 * @param string $image_path Path to image file.
	 * @param string $model_type Model type ('unlimited_ocr' or 'deepseek_ocr').
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_self_hosted_ocr( $image_path, $model_type, $options = array() ) {
		if ( ! class_exists( 'WP_MCP_AI_Self_Hosted_OCR_Client' ) ) {
			return new WP_Error(
				'client_not_available',
				__( 'Self-hosted OCR client is not available.', 'mcp-ai-wpoos-pro' )
			);
		}

		$client = new WP_MCP_AI_Self_Hosted_OCR_Client();

		// Validate model type.
		if ( ! $client->is_valid_model_type( $model_type ) ) {
			return new WP_Error(
				'invalid_model_type',
				sprintf(
					/* translators: %s: model type */
					__( 'Invalid self-hosted OCR model type: %s.', 'mcp-ai-wpoos-pro' ),
					esc_html( $model_type )
				)
			);
		}

		// Test connection.
		$connection = $client->test_connection( $model_type );
		if ( is_wp_error( $connection ) ) {
			return $connection;
		}

		// Encode the image.
		$image_data = $client->encode_image_file( $image_path );
		if ( is_wp_error( $image_data ) ) {
			return $image_data;
		}

		// Build prompt from options.
		$prompt = '';
		if ( ! empty( $options['preserve_layout'] ) && 'unlimited_ocr' === $model_type ) {
			$prompt = '<image>document parsing. Preserve the original layout and formatting.';
		}

		// Perform OCR.
		$result = $client->ocr_image( $image_data, $prompt, $model_type );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $result['text'];
	}

	/**
	 * Extract text using standard PDF parsing (non-OCR).
	 *
	 * @param string $pdf_path Path to PDF file.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_standard_text( $pdf_path ) {
		if ( class_exists( '\Smalot\PdfParser\Parser' ) ) {
			try {
				$parser = new \Smalot\PdfParser\Parser();
				$pdf    = $parser->parseFile( $pdf_path );
				return $pdf->getText();
			} catch ( \Exception $e ) {
				return $this->log_and_return_error(
					'parse_failed',
					'ocr_pdf_parse_failed',
					'PDF text extraction failed',
					array( 'error' => $e->getMessage() )
				);
			}
		}

		return new WP_Error( 'no_parser', __( 'PDF parser not available.', 'mcp-ai-wpoos-pro' ) );
	}

	/**
	 * Determine the best OCR provider based on availability.
	 *
	 * Checks image production settings first, then document generation settings,
	 * then falls back to detecting available providers from main settings.
	 *
	 * @return string Provider name.
	 */
	protected function determine_best_provider() {
		// Check image production settings first.
		$image_settings = get_option( 'wp_mcp_ai_image_production_settings', array() );
		if ( ! empty( $image_settings['ocr_provider'] ) && 'auto' !== $image_settings['ocr_provider'] ) {
			return $image_settings['ocr_provider'];
		}

		// Check document generation settings.
		$doc_settings = get_option( 'wp_mcp_ai_document_generation_settings', array() );
		if ( ! empty( $doc_settings['ocr_provider'] ) && 'auto' !== $doc_settings['ocr_provider'] ) {
			return $doc_settings['ocr_provider'];
		}

		// Auto mode or not configured - detect best available provider.
		$settings = get_option( 'wp_mcp_ai_settings', array() );

		// Prefer OpenAI if API key is configured.
		if ( WP_MCP_AI_Credential_Resolver::has_credentials( 'openai' ) ) {
			return 'openai';
		}

		// Next try Gemini.
		if ( WP_MCP_AI_Credential_Resolver::has_credentials( 'gemini' ) ) {
			return 'gemini';
		}

		// Then try Ollama if configured.
		if ( ! empty( $settings['ollama_endpoint'] ) ) {
			return 'ollama';
		}

		// Try Unlimited-OCR if endpoint configured.
		if ( ! empty( $settings['unlimited_ocr_endpoint_url'] ) ) {
			return 'unlimited_ocr';
		}

		// Try DeepSeek-OCR if endpoint configured.
		if ( ! empty( $settings['deepseek_ocr_endpoint_url'] ) ) {
			return 'deepseek_ocr';
		}

		// Finally, fall back to Tesseract if available (safe probe — never
		// fatals when exec()/proc_open are disabled).
		if ( $this->is_cli_tool_available( 'tesseract' ) ) {
			return 'tesseract';
		}

		// Default to OpenAI (will fail if not configured).
		return 'openai';
	}

	/**
	 * Get fallback providers for a given primary provider.
	 *
	 * @param string $primary Primary provider.
	 * @return array Fallback providers in order.
	 */
	protected function get_fallback_providers( $primary ) {
		// Check if a specific fallback is configured - check image production settings first.
		$image_settings = get_option( 'wp_mcp_ai_image_production_settings', array() );
		$doc_settings   = get_option( 'wp_mcp_ai_document_generation_settings', array() );

		// Image production settings take priority.
		$fallback = null;
		if ( ! empty( $image_settings['ocr_fallback_provider'] ) ) {
			$fallback = $image_settings['ocr_fallback_provider'];
		} elseif ( ! empty( $doc_settings['ocr_fallback_provider'] ) ) {
			$fallback = $doc_settings['ocr_fallback_provider'];
		}

		if ( ! empty( $fallback ) ) {
			// No fallback configured - return empty array.
			if ( 'none' === $fallback ) {
				return array();
			}

			if ( 'auto' === $fallback ) {
				// Auto mode - try all providers except primary.
				$all_providers = array( 'openai', 'gemini', 'ollama', 'tesseract', 'unlimited_ocr', 'deepseek_ocr' );
				$fallbacks     = array_diff( $all_providers, array( $primary ) );
				return array_values( $fallbacks );
			}

			// Specific fallback configured - use it if different from primary.
			if ( $fallback !== $primary ) {
				return array( $fallback );
			}
			// If same as primary, return empty (no fallback).
			return array();
		}

		// Default behavior - try all available providers except primary.
		$all_providers = array( 'openai', 'gemini', 'ollama', 'tesseract' );
		$fallbacks     = array_diff( $all_providers, array( $primary ) );

		return array_values( $fallbacks );
	}

	/**
	 * Check if Sharp (Node.js) is available.
	 *
	 * @return bool True if Sharp is available.
	 */
	protected function is_sharp_available() {
		$service_path = WP_MCP_AI_PRO_PATH . 'node-services/image-preprocess-service.js';
		return file_exists( $service_path );
	}

	/**
	 * Extract text using Node.js OCR service (Tesseract.js).
	 *
	 * Offers better performance than PHP-based OCR.
	 *
	 * @param string $image_path Path to image file.
	 * @param array  $options    Extraction options.
	 * @return string|WP_Error Extracted text or error.
	 */
	protected function extract_with_node_ocr( $image_path, $options = array() ) {
		// Check if tesseract.js package is available.
		if ( function_exists( 'wp_mcp_ai_is_npm_package_available' ) && ! wp_mcp_ai_is_npm_package_available( 'tesseract.js' ) ) {
			return new WP_Error(
				'wp_mcp_ai_package_not_available',
				__( 'Tesseract.js package is not available. Please ensure Node.js and Tesseract.js are properly installed. Visit the Pro Packages settings page for installation instructions.', 'mcp-ai-wpoos-pro' ),
				array(
					'package'      => 'tesseract.js',
					'settings_url' => admin_url( 'admin.php?page=wp-mcp-ai-pro-packages-settings' ),
				)
			);
		}

		// Check if Node.js OCR service exists.
		$service_path = WP_MCP_AI_PRO_PATH . 'node-services/ocr-service.js';
		if ( ! file_exists( $service_path ) ) {
			return new WP_Error(
				'service_not_found',
				__( 'Pre-bundled Node.js OCR service not found. This is a plugin installation issue.', 'mcp-ai-wpoos-pro' ),
				array( 'expected_path' => $service_path )
			);
		}

		$language = isset( $options['language'] ) ? $options['language'] : 'eng';

		// Prepare service arguments.
		$args = wp_json_encode(
			array(
				'path'       => $image_path,
				'language'   => $language,
				'preprocess' => true,
			)
		);

		// Execute Node.js service with timeout protection.
		// Pass NVOOS_CANVAS_PATH if the Canvas Addon is active so the Node.js
		// process can load the platform-specific canvas native binary for PDF OCR.
		// Security note: $canvas_dir is sourced from nvoos_canvas_get_dir() which
		// returns plugin_dir_path() — a server-controlled constant, not user input.
		// escapeshellarg() is applied as an additional defence-in-depth measure.
		$canvas_env = '';
		if ( function_exists( 'nvoos_canvas_get_dir' ) ) {
			$canvas_dir = nvoos_canvas_get_dir();
			// Verify the path is within the WordPress plugins directory before use.
			if ( '' !== $canvas_dir && false !== realpath( $canvas_dir ) &&
				defined( 'WP_PLUGIN_DIR' ) &&
				0 === strpos( realpath( $canvas_dir ), realpath( WP_PLUGIN_DIR ) ) ) {
				$canvas_env = 'NVOOS_CANVAS_PATH=' . escapeshellarg( $canvas_dir ) . ' ';
			}
		}

		$cmd = sprintf(
			'%snode %s image %s 2>&1',
			$canvas_env,
			escapeshellarg( $service_path ),
			escapeshellarg( $args )
		);

		$result      = $this->execute_node_service_with_timeout( $cmd, 120 ); // 2 minute timeout for OCR
		$output      = $result['output'];
		$return_code = $result['return_code'];

		// Check for timeout.
		if ( $result['timed_out'] ) {
			return new WP_Error(
				'node_ocr_timeout',
				__( 'Node.js OCR service timed out after 120 seconds. Try processing fewer pages or a smaller image.', 'mcp-ai-wpoos-pro' ),
				array( 'timeout' => 120 )
			);
		}

		// Check for execution errors.
		if ( 0 !== $return_code ) {
			$output_text = implode( "\n", $output );

			// Try to parse as JSON error.
			$json_output   = json_decode( $output_text, true );
			$error_message = isset( $json_output['error'] )
				? $json_output['error']
				: $output_text;

			// Surface the process-disabled diagnostic when no output was captured.
			if ( empty( $error_message ) && ! empty( $result['error'] ) ) {
				$error_message = $result['error'];
			}

			return new WP_Error(
				'node_ocr_failed',
				sprintf(
					/* translators: %s: error message from Node.js OCR */
					__( 'Pre-bundled Node.js OCR service failed. Ensure Node.js is installed. Error: %s', 'mcp-ai-wpoos-pro' ),
					$error_message
				),
				array(
					'return_code' => $return_code,
					'output'      => $output,
					'raw_error'   => $output_text,
				)
			);
		}

		// Parse JSON response.
		$output_text = implode( "\n", $output );
		$result      = json_decode( $output_text, true );

		if ( null === $result ) {
			return new WP_Error(
				'invalid_json_response',
				sprintf(
					/* translators: %s: raw output from OCR service */
					__( 'Node.js OCR service returned invalid JSON. Raw output: %s', 'mcp-ai-wpoos-pro' ),
					substr( $output_text, 0, 200 )
				),
				array( 'raw_output' => $output_text )
			);
		}

		if ( isset( $result['error'] ) ) {
			return new WP_Error( 'ocr_error', $result['error'], $result );
		}

		if ( ! isset( $result['text'] ) ) {
			return new WP_Error(
				'invalid_response',
				__( 'Invalid response from Node.js OCR service. Missing "text" field.', 'mcp-ai-wpoos-pro' ),
				array( 'result' => $result )
			);
		}

		// Log confidence if available.
		if ( isset( $result['confidence'] ) ) {
			WP_MCP_AI_Logger::log_event(
				'node_ocr_success',
				'Node.js OCR completed',
				array(
					'confidence' => $result['confidence'],
					'words'      => isset( $result['words'] ) ? $result['words'] : 0,
				)
			);
		}

		return $result['text'];
	}

	/**
	 * Validate image input before processing.
	 *
	 * @param string $image_path Path to image file.
	 * @return true|WP_Error True if valid, WP_Error otherwise.
	 */
	protected function validate_image_input( $image_path ) {
		// Check file exists.
		if ( ! file_exists( $image_path ) ) {
			return new WP_Error(
				'file_not_found',
				__( 'Image file not found.', 'mcp-ai-wpoos-pro' ),
				array( 'status' => 404 )
			);
		}

		// Check file size.
		$file_size = filesize( $image_path );
		if ( $file_size > self::MAX_FILE_SIZE ) {
			return new WP_Error(
				'file_too_large',
				sprintf(
						/* translators: 1: file size, 2: maximum allowed size */
					__( 'Image file is too large (%1$s). Maximum size is %2$s.', 'mcp-ai-wpoos-pro' ),
					size_format( $file_size ),
					size_format( self::MAX_FILE_SIZE )
				),
				array( 'status' => 413 )
			);
		}

		// Check MIME type.
		$mime_type     = $this->get_mime_type( $image_path );
		$allowed_types = array( 'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'image/tiff' );
		if ( ! in_array( $mime_type, $allowed_types, true ) ) {
			return new WP_Error(
				'invalid_file_type',
				sprintf(
						/* translators: 1: detected MIME type, 2: list of allowed types */
					__( 'Invalid image file type: %1$s. Allowed types: %2$s', 'mcp-ai-wpoos-pro' ),
					$mime_type,
					implode( ', ', $allowed_types )
				),
				array( 'status' => 415 )
			);
		}

		// Check file is readable.
		if ( ! is_readable( $image_path ) ) {
			return new WP_Error(
				'file_not_readable',
				__( 'Image file is not readable. Check file permissions.', 'mcp-ai-wpoos-pro' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Validate PDF input before processing.
	 *
	 * @param string $pdf_path Path to PDF file.
	 * @return true|WP_Error True if valid, WP_Error otherwise.
	 */
	protected function validate_pdf_input( $pdf_path ) {
		// Check file exists.
		if ( ! file_exists( $pdf_path ) ) {
			return new WP_Error(
				'file_not_found',
				__( 'PDF file not found.', 'mcp-ai-wpoos-pro' ),
				array( 'status' => 404 )
			);
		}

		// Check file size.
		$file_size = filesize( $pdf_path );
		if ( $file_size > self::MAX_FILE_SIZE ) {
			return new WP_Error(
				'file_too_large',
				sprintf(
						/* translators: 1: file size, 2: maximum allowed size */
					__( 'PDF file is too large (%1$s). Maximum size is %2$s.', 'mcp-ai-wpoos-pro' ),
					size_format( $file_size ),
					size_format( self::MAX_FILE_SIZE )
				),
				array( 'status' => 413 )
			);
		}

		// Check MIME type.
		$mime_type = $this->get_mime_type( $pdf_path );
		if ( 'application/pdf' !== $mime_type ) {
			return new WP_Error(
				'invalid_file_type',
				sprintf(
					/* translators: %s: detected MIME type */
					__( 'Invalid file type: %s. Expected application/pdf', 'mcp-ai-wpoos-pro' ),
					$mime_type
				),
				array( 'status' => 415 )
			);
		}

		// Check file is readable.
		if ( ! is_readable( $pdf_path ) ) {
			return new WP_Error(
				'file_not_readable',
				__( 'PDF file is not readable. Check file permissions.', 'mcp-ai-wpoos-pro' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Check circuit breaker state for a provider.
	 *
	 * Implements circuit breaker pattern to prevent cascading failures.
	 *
	 * @param string $provider Provider name.
	 * @return bool True if circuit is open (provider should be skipped).
	 */
	protected function is_circuit_open( $provider ) {
		if ( ! isset( self::$circuit_breaker[ $provider ] ) ) {
			return false;
		}

		$state = self::$circuit_breaker[ $provider ];

		// If circuit is closed, provider is available.
		if ( 'closed' === $state['status'] ) {
			return false;
		}

		// Check if cooldown period has passed.
		if ( time() - $state['opened_at'] > self::CIRCUIT_BREAKER_COOLDOWN ) {
			// Reset circuit to half-open state for testing.
			self::$circuit_breaker[ $provider ]['status'] = 'half-open';
			WP_MCP_AI_Logger::log_event(
				'ocr_circuit_half_open',
				sprintf( 'Circuit breaker entering half-open state for provider: %s', $provider ),
				array( 'provider' => $provider )
			);
			return false;
		}

		return true;
	}

	/**
	 * Open circuit breaker for a provider.
	 *
	 * @param string $provider Provider name.
	 * @param string $reason   Reason for opening circuit.
	 */
	protected function open_circuit( $provider, $reason = '' ) {
		self::$circuit_breaker[ $provider ] = array(
			'status'    => 'open',
			'opened_at' => time(),
			'reason'    => $reason,
		);

		WP_MCP_AI_Logger::log_event(
			'ocr_circuit_opened',
			sprintf( 'Circuit breaker opened for provider: %s', $provider ),
			array(
				'provider' => $provider,
				'reason'   => $reason,
			)
		);
	}

	/**
	 * Close circuit breaker for a provider.
	 *
	 * @param string $provider Provider name.
	 */
	protected function close_circuit( $provider ) {
		// Only reset if circuit exists and was open/half-open.
		$was_open = isset( self::$circuit_breaker[ $provider ] ) &&
					in_array( self::$circuit_breaker[ $provider ]['status'], array( 'open', 'half-open' ), true );

		self::$circuit_breaker[ $provider ] = array(
			'status'    => 'closed',
			'opened_at' => 0,
			'reason'    => '',
		);

		if ( $was_open ) {
			WP_MCP_AI_Logger::log_event(
				'ocr_circuit_closed',
				sprintf( 'Circuit breaker closed for provider: %s (recovered from failure)', $provider ),
				array( 'provider' => $provider )
			);
		}
	}

	/**
	 * Execute operation with retry logic.
	 *
	 * Implements exponential backoff for transient failures.
	 *
	 * @param callable $operation Operation to execute.
	 * @param int      $max_retries Maximum retry attempts.
	 * @return mixed Operation result.
	 */
	protected function execute_with_retry( $operation, $max_retries = self::MAX_RETRIES ) {
		$attempt    = 0;
		$last_error = null;

		while ( $attempt < $max_retries ) {
			$result = $operation();

			// Success - return result.
			if ( ! is_wp_error( $result ) ) {
				return $result;
			}

			$last_error = $result;
			$error_code = $result->get_error_code();

			// Don't retry on non-transient errors.
			$non_retryable = array(
				'no_api_key',
				'invalid_file_type',
				'file_not_found',
				'file_too_large',
			);

			if ( in_array( $error_code, $non_retryable, true ) ) {
				return $result;
			}

			++$attempt;

			// Exponential backoff: 1s, 2s, 4s, etc.
			// Only sleep if we have retries remaining.
			if ( $attempt < $max_retries ) {
				$wait_time = pow( 2, $attempt - 1 );
				WP_MCP_AI_Logger::log_event(
					'ocr_retry_attempt',
					sprintf( 'Retrying OCR operation (attempt %d/%d) after %ds', $attempt + 1, $max_retries, $wait_time ),
					array(
						'attempt'     => $attempt + 1,
						'max_retries' => $max_retries,
						'wait_time'   => $wait_time,
						'error'       => $result->get_error_message(),
					)
				);
				sleep( $wait_time );
			}
		}

		// All retries exhausted.
		return $last_error;
	}

	/**
	 * Execute Node.js command with timeout protection.
	 *
	 * Uses proc_open() instead of exec() to prevent infinite hangs.
	 *
	 * @param string $command Command to execute.
	 * @param int    $timeout Timeout in seconds.
	 * @return array Array with 'output', 'return_code', and 'timed_out' keys.
	 */
	protected function execute_node_service_with_timeout( $command, $timeout = 60 ) {
		// Bail safely when process functions are disabled (disable_functions) —
		// on PHP 8+ calling a disabled function throws a fatal Error.
		if ( ! function_exists( 'proc_open' ) || ! function_exists( 'proc_close' ) || ! function_exists( 'proc_terminate' ) ) {
			return array(
				'output'      => array(),
				'return_code' => -1,
				'timed_out'   => false,
				'error'       => 'Process control functions (proc_open, proc_close) are disabled on this server.',
			);
		}

		$descriptors = array(
			0 => array( 'pipe', 'r' ), // stdin.
			1 => array( 'pipe', 'w' ), // stdout.
			2 => array( 'pipe', 'w' ), // stderr.
		);

		$process = proc_open( $command, $descriptors, $pipes );

		if ( ! is_resource( $process ) ) {
			return array(
				'output'      => array(),
				'return_code' => -1,
				'timed_out'   => false,
				'error'       => 'Failed to start process',
			);
		}

		// Close stdin channel.
		fclose( $pipes[0] );

		// Set non-blocking mode for reading data.
		stream_set_blocking( $pipes[1], false );
		stream_set_blocking( $pipes[2], false );

		$output       = '';
		$error_output = '';
		$start_time   = time();
		$timed_out    = false;

		// Read output with timeout period.
		while ( true ) {
			$elapsed = time() - $start_time;
			if ( $elapsed >= $timeout ) {
				$timed_out = true;
				// Kill the process.
				proc_terminate( $process, 9 ); // SIGKILL.
				WP_MCP_AI_Logger::log_event(
					'node_service_timeout',
					sprintf( 'Node.js service timed out after %d seconds', $timeout ),
					array( 'command' => substr( $command, 0, 200 ) )
				);
				break;
			}

			// Check if process is still running.
			$status = proc_get_status( $process );
			if ( ! $status['running'] ) {
				// Process finished, read any remaining output.
				$output       .= stream_get_contents( $pipes[1] );
				$error_output .= stream_get_contents( $pipes[2] );
				break;
			}

			// Read available data.
			$read_output = fread( $pipes[1], 8192 );
			if ( false !== $read_output ) {
				$output .= $read_output;
			}

			$read_error = fread( $pipes[2], 8192 );
			if ( false !== $read_error ) {
				$error_output .= $read_error;
			}

			// Small sleep to prevent busy waiting.
			usleep( 100000 ); // 100ms
		}

		// Close pipes.
		fclose( $pipes[1] );
		fclose( $pipes[2] );

		// Get return code.
		$return_code = proc_close( $process );

		// If timed out, return specific error.
		if ( $timed_out ) {
			$return_code = -1;
		}

		// Combine output.
		$combined_output = trim( $output );
		if ( ! empty( $error_output ) && empty( $combined_output ) ) {
			$combined_output = trim( $error_output );
		}

		return array(
			'output'      => explode( "\n", $combined_output ),
			'return_code' => $return_code,
			'timed_out'   => $timed_out,
			'error'       => trim( $error_output ),
		);
	}

	/**
	 * Safely probe whether a command-line tool is available.
	 *
	 * Never calls exec() when it is disabled (disable_functions) — on PHP 8+
	 * that throws a fatal Error. Falls back to the Process Service
	 * (proc_open), which reports unavailable instead of throwing.
	 *
	 * @param string $command Command name (e.g. 'pdftoppm', 'tesseract').
	 * @return bool True when the command is available.
	 */
	private function is_cli_tool_available( $command ) {
		if ( function_exists( 'exec' ) ) {
			$output = array();
			$return = null;
			$which  = stripos( PHP_OS, 'WIN' ) === 0 ? 'where' : 'which';
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec,WordPress.PHP.NoSilencedErrors.Discouraged
			@exec( $which . ' ' . escapeshellarg( $command ) . ' 2>&1', $output, $return );

			return 0 === $return && ! empty( $output );
		}

		if ( class_exists( '\WP_MCP_AI\Services\WP_MCP_AI_Process_Service' ) ) {
			$process_service = \WP_MCP_AI\Services\WP_MCP_AI_Process_Service::get_instance();
			return $process_service->is_command_available( $command );
		}

		return false;
	}

	/**
	 * Safely run a command-line tool, capturing output and exit code.
	 *
	 * Uses exec() when available (legacy behaviour) and falls back to the
	 * Process Service (proc_open) when exec() is disabled — on PHP 8+ calling
	 * a disabled function throws a fatal Error.
	 *
	 * @param string $command Full shell command (arguments must be escaped by the caller).
	 * @param int    $timeout Timeout in seconds for the Process Service fallback.
	 * @return array {
	 *     @type string $output      Combined stdout/stderr output.
	 *     @type int    $return_code Exit code (-1 when unavailable).
	 *     @type bool   $disabled    Whether process execution is disabled on this server.
	 * }
	 */
	private function run_cli_command( $command, $timeout = self::DEFAULT_TIMEOUT ) {
		if ( function_exists( 'exec' ) ) {
			$output      = array();
			$return_code = null;
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec,WordPress.PHP.NoSilencedErrors.Discouraged
			@exec( $command, $output, $return_code );

			return array(
				'output'      => implode( "\n", $output ),
				'return_code' => null === $return_code ? -1 : (int) $return_code,
				'disabled'    => false,
			);
		}

		if ( class_exists( '\WP_MCP_AI\Services\WP_MCP_AI_Process_Service' ) ) {
			$process_service = \WP_MCP_AI\Services\WP_MCP_AI_Process_Service::get_instance();
			$result          = $process_service->run_silent( $command, array( 'timeout' => $timeout ) );

			if ( ! empty( $result['disabled'] ) ) {
				return array(
					'output'      => '',
					'return_code' => -1,
					'disabled'    => true,
				);
			}

			$output = trim( $result['output'] );
			if ( ! empty( $result['error'] ) ) {
				$output = trim( $output . "\n" . $result['error'] );
			}

			return array(
				'output'      => $output,
				'return_code' => isset( $result['exit_code'] ) ? (int) $result['exit_code'] : -1,
				'disabled'    => false,
			);
		}

		return array(
			'output'      => '',
			'return_code' => -1,
			'disabled'    => true,
		);
	}

	/**
	 * Get MIME type of file using modern finfo API.
	 *
	 * Replaces deprecated mime_content_type() for PHP 9.0 compatibility.
	 *
	 * @param string $file_path Path to file.
	 * @return string|false MIME type or false on failure.
	 */
	protected function get_mime_type( $file_path ) {
		if ( ! file_exists( $file_path ) ) {
			return false;
		}

		// Use WordPress function if available.
		if ( function_exists( 'wp_check_filetype' ) ) {
			$filetype = wp_check_filetype( $file_path );
			if ( ! empty( $filetype['type'] ) ) {
				return $filetype['type'];
			}
		}

		// Fallback to finfo (PHP 8.1+ preferred method).
		if ( class_exists( 'finfo' ) ) {
			$finfo = new \finfo( FILEINFO_MIME_TYPE );
			$mime  = $finfo->file( $file_path );
			if ( false !== $mime ) {
				return $mime;
			}
		}

		// Last resort: try deprecated function if still available.
		if ( function_exists( 'mime_content_type' ) ) {
			return mime_content_type( $file_path );
		}

		return false;
	}

	/**
	 * Log an OCR error event privately and return a generic WP_Error.
	 *
	 * Ensures raw command output, exception messages, and other potentially
	 * sensitive system details are logged internally rather than exposed to
	 * callers. All error paths that involve external command output or
	 * exception messages should go through this helper.
	 *
	 * @param string $error_code WP_Error code for the returned error.
	 * @param string $event_type Logger event type slug.
	 * @param string $message    Human-readable description for the log entry.
	 * @param array  $context    Additional context to include in the log entry.
	 * @return WP_Error Generic WP_Error without sensitive details.
	 */
	protected function log_and_return_error( $error_code, $event_type, $message, $context = array() ) {
		if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
			WP_MCP_AI_Logger::log_event( $event_type, $message, $context );
		}
		/* translators: %s: plugin log location hint */
		return new WP_Error( $error_code, __( 'An OCR processing error occurred. See plugin logs for details.', 'mcp-ai-wpoos-pro' ) );
	}
}
