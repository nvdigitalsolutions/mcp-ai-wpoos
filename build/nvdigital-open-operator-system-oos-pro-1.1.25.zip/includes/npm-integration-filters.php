<?php
/**
 * NPM Package Integration Filter Handlers
 *
 * This file provides WordPress filter implementations that connect PHP services
 * to Node.js microservices for NPM package functionality.
 *
 * Usage:
 * Include this file in your theme's functions.php or a custom plugin:
 * require_once WP_MCP_AI_PRO_PATH . 'includes/npm-integration-filters.php';
 *
 * Or selectively enable specific integrations using the individual functions.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get the map of document generation packages to their pre-packed bundle files.
 *
 * @return array Map of package name => relative path to bundle within WP_MCP_AI_PRO_PATH.
 */
function wp_mcp_ai_doc_gen_bundle_map() {
	return array(
		'pdfkit'  => 'bin/generate-pdf.bundle.js',
		'docx'    => 'bin/generate-word.bundle.js',
		'exceljs' => 'bin/generate-excel.bundle.js',
	);
}

/**
 * Get the list of Cornerstone3D package names.
 *
 * These are loaded at runtime by imaging-viewer.js — from local vendor bundles
 * when available (built by bin/vendor-cornerstone.js), otherwise from the
 * esm.sh CDN.
 *
 * @return array List of @cornerstonejs/* package names.
 */
function wp_mcp_ai_cornerstone_package_names() {
	return array(
		'@cornerstonejs/core',
		'@cornerstonejs/tools',
		'@cornerstonejs/dicom-image-loader',
	);
}

/**
 * Check whether vendored Cornerstone3D ESM bundles are available on disk.
 *
 * These are built by `bin/vendor-cornerstone.js` and placed in
 * `assets/vendor/cornerstone/`.  When present, the imaging viewer loads
 * Cornerstone3D entirely from local files with no CDN dependency.
 *
 * Also checks the standalone nvoos-cornerstone3d addon which provides
 * the same bundles as a separate WordPress plugin.
 *
 * Delegates to the admin page class when loaded; otherwise performs a
 * standalone filesystem check.
 *
 * @since 2.1.0
 * @return bool
 */
function wp_mcp_ai_has_vendored_cornerstone() {
	// Check standalone addon first (installed as a separate plugin).
	if ( function_exists( 'nvoos_cornerstone3d_is_available' ) && nvoos_cornerstone3d_is_available() ) {
		return true;
	}

	if ( ! defined( 'WP_MCP_AI_PRO_PATH' ) ) {
		return false;
	}
	// Delegate to the admin class when it is loaded (single source of truth).
	if ( class_exists( 'WP_MCP_AI_Imaging_Admin_Page' ) && method_exists( 'WP_MCP_AI_Imaging_Admin_Page', 'has_vendored_cornerstone' ) ) {
		return WP_MCP_AI_Imaging_Admin_Page::has_vendored_cornerstone();
	}
	// Standalone fallback — the admin class may not be loaded in REST/CLI contexts.
	$base = WP_MCP_AI_PRO_PATH . 'assets/vendor/cornerstone/';
	return file_exists( $base . 'cornerstone-core.esm.js' )
		&& file_exists( $base . 'cornerstone-tools.esm.js' )
		&& file_exists( $base . 'cornerstone-dicom-loader.esm.js' )
		&& file_exists( $base . 'dicom-parser.esm.js' )
		&& file_exists( $base . 'xmlbuilder2.esm.js' );
}

/**
 * Check if an NPM package is available
 *
 * Checks for package availability in CDN (via CDN Loader), vendor directory,
 * bundle files, or node_modules.
 *
 * @since 1.1.1
 * @param string $package_name Package name (e.g., 'katex', 'chart.js', 'pdfkit').
 * @return bool True if package is available.
 */
function wp_mcp_ai_is_npm_package_available( $package_name ) {
	// Check if CDN Loader is available and handles this package.
	if ( class_exists( 'WP_MCP_AI_Pro_CDN_Loader' ) ) {
		if ( WP_MCP_AI_Pro_CDN_Loader::is_package_available( $package_name ) ) {
			return true;
		}
	}

	// Check vendor directory (pre-packaged distribution).
	$vendor_path = WP_MCP_AI_PRO_PATH . 'assets/vendor/' . $package_name;
	if ( is_dir( $vendor_path ) || file_exists( $vendor_path . '/package.json' ) ) {
		return true;
	}

	// Check node_modules (development environment).
	$node_modules_path = WP_MCP_AI_PRO_PATH . 'node_modules/' . $package_name;
	if ( is_dir( $node_modules_path ) || file_exists( $node_modules_path . '/package.json' ) ) {
		return true;
	}

	// Check for document generation packages bundled into Node.js scripts.
	$doc_gen_bundles = wp_mcp_ai_doc_gen_bundle_map();
	if ( isset( $doc_gen_bundles[ $package_name ] ) ) {
		if ( file_exists( WP_MCP_AI_PRO_PATH . $doc_gen_bundles[ $package_name ] ) ) {
			return true;
		}
	}

	// Check for Cornerstone3D packages — prefer vendored ESM bundles, fall back to CDN.
	if ( in_array( $package_name, wp_mcp_ai_cornerstone_package_names(), true ) ) {
		if ( wp_mcp_ai_has_vendored_cornerstone() ) {
			return true;
		}
		if ( file_exists( WP_MCP_AI_PRO_PATH . 'assets/js/imaging-viewer.js' ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Get NPM package status information
 *
 * Returns detailed status about how a package is available (CDN, vendor, node_modules, etc.).
 *
 * @since 1.1.1
 * @param string $package_name Package name.
 * @return array Status array with 'available', 'source', and 'message' keys.
 */
function wp_mcp_ai_get_npm_package_status( $package_name ) {
	// Check if CDN Loader is available and handles this package.
	if ( class_exists( 'WP_MCP_AI_Pro_CDN_Loader' ) ) {
		$status = WP_MCP_AI_Pro_CDN_Loader::get_package_status( $package_name );
		if ( $status['available'] ) {
			return $status;
		}
	}

	// Check vendor directory (pre-packaged distribution).
	$vendor_path = WP_MCP_AI_PRO_PATH . 'assets/vendor/' . $package_name;
	if ( is_dir( $vendor_path ) || file_exists( $vendor_path . '/package.json' ) ) {
		return array(
			'available' => true,
			'source'    => 'vendor',
			'message'   => sprintf(
				/* translators: %s: package name */
				__( '%s (Bundled)', 'nvdigital-open-operator-system-oos-pro' ),
				$package_name
			),
		);
	}

	// Check node_modules (development environment).
	$node_modules_path = WP_MCP_AI_PRO_PATH . 'node_modules/' . $package_name;
	if ( is_dir( $node_modules_path ) || file_exists( $node_modules_path . '/package.json' ) ) {
		return array(
			'available' => true,
			'source'    => 'node_modules',
			'message'   => sprintf(
				/* translators: %s: package name */
				__( '%s (Development)', 'nvdigital-open-operator-system-oos-pro' ),
				$package_name
			),
		);
	}

	// Check for document generation packages bundled into Node.js scripts.
	$doc_gen_bundles = wp_mcp_ai_doc_gen_bundle_map();
	if ( isset( $doc_gen_bundles[ $package_name ] ) ) {
		if ( file_exists( WP_MCP_AI_PRO_PATH . $doc_gen_bundles[ $package_name ] ) ) {
			return array(
				'available' => true,
				'source'    => 'bundled',
				'message'   => sprintf(
					/* translators: %s: package name */
					__( '%s (Pre-packed)', 'nvdigital-open-operator-system-oos-pro' ),
					$package_name
				),
			);
		}
	}

	// Check for Cornerstone3D packages — prefer vendored ESM bundles, fall back to CDN.
	if ( in_array( $package_name, wp_mcp_ai_cornerstone_package_names(), true ) ) {
		if ( wp_mcp_ai_has_vendored_cornerstone() ) {
			return array(
				'available' => true,
				'source'    => 'vendor',
				'message'   => sprintf(
					/* translators: %s: package name */
					__( '%s (Vendored)', 'nvdigital-open-operator-system-oos-pro' ),
					$package_name
				),
			);
		}
		if ( file_exists( WP_MCP_AI_PRO_PATH . 'assets/js/imaging-viewer.js' ) ) {
			return array(
				'available' => true,
				'source'    => 'cdn',
				'message'   => sprintf(
					/* translators: %s: package name */
					__( '%s (CDN)', 'nvdigital-open-operator-system-oos-pro' ),
					$package_name
				),
			);
		}
	}

	// Check for canvas: prefer the NV oOS Canvas Addon plugin (pre-compiled
	// binaries), then fall back to canvas-service.js + node_modules.
	if ( 'canvas' === $package_name ) {
		// Priority 1: NV oOS Canvas Addon plugin provides pre-compiled binaries.
		if ( function_exists( 'nvoos_canvas_is_available' ) && nvoos_canvas_is_available() ) {
			return array(
				'available' => true,
				'source'    => 'canvas-addon',
				'message'   => __( 'canvas (NV oOS Canvas Addon)', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		// Priority 2: canvas-service.js present AND canvas in node_modules.
		$canvas_service_path = WP_MCP_AI_PRO_PATH . 'node-services/canvas-service.js';
		$canvas_npm_path     = WP_MCP_AI_PRO_PATH . 'node_modules/canvas';
		if ( file_exists( $canvas_service_path ) && is_dir( $canvas_npm_path ) ) {
			return array(
				'available' => true,
				'source'    => 'node_modules',
				'message'   => __( 'canvas (Installed)', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}
	}

	// Not available.
	return array(
		'available' => false,
		'source'    => 'none',
		'message'   => sprintf(
			/* translators: %s: package name */
			__( '%s (Not installed)', 'nvdigital-open-operator-system-oos-pro' ),
			$package_name
		),
	);
}

/**
 * Check if Node.js is available
 *
 * @return bool True if Node.js is available.
 */
function wp_mcp_ai_is_nodejs_available() {
	static $available = null;

	if ( null === $available ) {
		// Use Process Service to check for Node.js availability.
		$process_service = \WP_MCP_AI\Services\WP_MCP_AI_Process_Service::get_instance();
		$available       = $process_service->is_command_available( 'node' );
	}

	return $available;
}

/**
 * Execute Node.js service script
 *
 * @param string $service_file Service file path.
 * @param string $action       Action to perform.
 * @param array  $params       Parameters to pass.
 * @param int    $timeout      Timeout in seconds (default: 30).
 * @return string|WP_Error Result or error.
 */
function wp_mcp_ai_exec_node_service( $service_file, $action, $params, $timeout = 30 ) {
	if ( ! wp_mcp_ai_is_nodejs_available() ) {
		return new WP_Error(
			'nodejs_not_available',
			__( 'Node.js is not available on this server.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	if ( ! file_exists( $service_file ) ) {
		return new WP_Error(
			'service_not_found',
			sprintf(
				/* translators: %s: service file path */
				__( 'Node.js service not found: %s', 'nvdigital-open-operator-system-oos-pro' ),
				$service_file
			)
		);
	}

	// Get Process Service.
	$process_service = \WP_MCP_AI\Services\WP_MCP_AI_Process_Service::get_instance();

	// Build command as array for better security.
	$command = array(
		'node',
		$service_file,
		$action,
		wp_json_encode( $params ),
	);

	// Execute command using Process Service.
	$result = $process_service->run_silent( $command, array( 'timeout' => $timeout ) );

	// Check for timeout.
	if ( isset( $result['timeout'] ) && $result['timeout'] ) {
		return new WP_Error(
			'node_timeout',
			sprintf(
				/* translators: %d: timeout in seconds */
				__( 'Node.js service timed out after %d seconds.', 'nvdigital-open-operator-system-oos-pro' ),
				$timeout
			)
		);
	}

	// Handle errors.
	if ( ! $result['success'] ) {
		$output_text = $result['output'] . $result['error'];
		$error_data  = json_decode( $output_text, true );

		if ( isset( $error_data['error'] ) ) {
			return new WP_Error(
				'node_execution_failed',
				$error_data['error']
			);
		}

		return new WP_Error(
			'node_execution_failed',
			sprintf(
				/* translators: %s: error output */
				__( 'Node.js service failed: %s', 'nvdigital-open-operator-system-oos-pro' ),
				$output_text
			)
		);
	}

	return $result['output'];
}

/**
 * ============================================================================
 * PRETTIER FILTER HANDLERS
 * ============================================================================
 */

/**
 * Format code using Prettier Node.js service
 *
 * @param string|false $result Result from previous filters.
 * @param array        $params Formatting parameters.
 * @return string|WP_Error Formatted code or error.
 */
function wp_mcp_ai_prettier_format_code_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/prettier-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'format', $params, 30 );

	return $output;
}

/**
 * Check code syntax using Prettier Node.js service
 *
 * @param bool|WP_Error|false $result Result from previous filters.
 * @param array               $params Check parameters.
 * @return bool|WP_Error Check result or error.
 */
function wp_mcp_ai_prettier_check_syntax_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/prettier-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'check', $params, 10 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$result_data = json_decode( $output, true );
	return isset( $result_data['valid'] ) ? $result_data['valid'] : true;
}

/**
 * ============================================================================
 * MJML FILTER HANDLERS
 * ============================================================================
 */

/**
 * Compile MJML to HTML using Node.js service
 *
 * @param string|false $result Result from previous filters.
 * @param array        $params Compilation parameters.
 * @return string|WP_Error HTML output or error.
 */
function wp_mcp_ai_mjml_compile_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/mjml-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'compile', $params, 30 );

	return $output;
}

/**
 * Validate MJML markup using Node.js service
 *
 * @param bool|WP_Error|false $result Result from previous filters.
 * @param array               $params Validation parameters.
 * @return bool|WP_Error Validation result or error.
 */
function wp_mcp_ai_mjml_validate_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/mjml-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'validate', $params, 10 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$result_data = json_decode( $output, true );

	if ( isset( $result_data['valid'] ) && ! $result_data['valid'] ) {
		$errors = array();
		if ( isset( $result_data['errors'] ) ) {
			foreach ( $result_data['errors'] as $error ) {
				$errors[] = isset( $error['message'] ) ? $error['message'] : 'Unknown error';
			}
		}
		return new WP_Error( 'mjml_validation_failed', implode( '; ', $errors ) );
	}

	return true;
}

/**
 * ============================================================================
 * FLUENT-FFMPEG FILTER HANDLERS
 * ============================================================================
 */

/**
 * Get video metadata using fluent-ffmpeg Node.js service
 *
 * @param array|false $result Result from previous filters.
 * @param array       $params Metadata parameters.
 * @return array|WP_Error Video metadata or error.
 */
function wp_mcp_ai_fluent_ffmpeg_get_metadata_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/ffmpeg-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'metadata', $params, 60 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$metadata = json_decode( $output, true );

	if ( null === $metadata ) {
		return new WP_Error(
			'invalid_metadata',
			__( 'Failed to parse video metadata.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	return $metadata;
}

/**
 * Transcode video using fluent-ffmpeg Node.js service
 *
 * @param string|false $result Result from previous filters.
 * @param array        $params Transcoding parameters.
 * @return string|WP_Error Output path or error.
 */
function wp_mcp_ai_fluent_ffmpeg_transcode_video_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/ffmpeg-service.js';

	// Transcoding can take a long time, set appropriate timeout based on file size.
	$timeout = 300; // 5 minutes default.

	/**
	 * Filter the timeout for video transcoding.
	 *
	 * @param int   $timeout Timeout in seconds.
	 * @param array $params  Transcoding parameters.
	 */
	$timeout = apply_filters( 'wp_mcp_ai_ffmpeg_transcode_timeout', $timeout, $params );

	$output = wp_mcp_ai_exec_node_service( $service_file, 'transcode', $params, $timeout );

	return $output;
}

/**
 * ============================================================================
 * YFINANCE FILTER HANDLERS
 * ============================================================================
 */

/**
 * Get ticker information from yfinance service
 *
 * @param array|false $result Result from previous filters.
 * @param array       $params Request parameters.
 * @return array|WP_Error Ticker information or error.
 */
function wp_mcp_ai_yfinance_ticker_info_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/yfinance-client.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'ticker_info', $params, 15 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$result_data = json_decode( $output, true );

	if ( ! $result_data || ! isset( $result_data['success'] ) || ! $result_data['success'] ) {
		return new WP_Error(
			'yfinance_ticker_info_failed',
			$result_data['error'] ?? __( 'Failed to fetch ticker information.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	return $result_data['data'] ?? array();
}

/**
 * Get current price from yfinance service
 *
 * @param array|false $result Result from previous filters.
 * @param array       $params Request parameters.
 * @return array|WP_Error Price data or error.
 */
function wp_mcp_ai_yfinance_current_price_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/yfinance-client.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'current_price', $params, 15 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$result_data = json_decode( $output, true );

	if ( ! $result_data || ! isset( $result_data['success'] ) || ! $result_data['success'] ) {
		return new WP_Error(
			'yfinance_price_failed',
			$result_data['error'] ?? __( 'Failed to fetch current price.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	return $result_data['data'] ?? array();
}

/**
 * Get batch prices from yfinance service
 *
 * @param array|false $result Result from previous filters.
 * @param array       $params Request parameters.
 * @return array|WP_Error Batch price data or error.
 */
function wp_mcp_ai_yfinance_batch_prices_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/yfinance-client.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'batch_prices', $params, 20 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$result_data = json_decode( $output, true );

	if ( ! $result_data || ! isset( $result_data['success'] ) || ! $result_data['success'] ) {
		return new WP_Error(
			'yfinance_batch_prices_failed',
			$result_data['error'] ?? __( 'Failed to fetch batch prices.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	return $result_data['data'] ?? array();
}

/**
 * Get price history from yfinance service
 *
 * @param array|false $result Result from previous filters.
 * @param array       $params Request parameters.
 * @return array|WP_Error Historical price data or error.
 */
function wp_mcp_ai_yfinance_price_history_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/yfinance-client.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'price_history', $params, 20 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$result_data = json_decode( $output, true );

	if ( ! $result_data || ! isset( $result_data['success'] ) || ! $result_data['success'] ) {
		return new WP_Error(
			'yfinance_history_failed',
			$result_data['error'] ?? __( 'Failed to fetch price history.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	return $result_data;
}

/**
 * Search ticker symbols using yfinance service
 *
 * @param array|false $result Result from previous filters.
 * @param array       $params Request parameters.
 * @return array|WP_Error Search results or error.
 */
function wp_mcp_ai_yfinance_search_ticker_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/yfinance-client.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'search', $params, 10 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$result_data = json_decode( $output, true );

	if ( ! $result_data || ! isset( $result_data['success'] ) || ! $result_data['success'] ) {
		return new WP_Error(
			'yfinance_search_failed',
			$result_data['error'] ?? __( 'Failed to search ticker symbols.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	return $result_data['results'] ?? array();
}

/**
 * Check health of yfinance service
 *
 * @param array|false $result Result from previous filters.
 * @param array       $params Request parameters.
 * @return array Health status.
 */
function wp_mcp_ai_yfinance_health_check_handler( $result, $params ) {
	// If already handled by another filter, return it.
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/yfinance-client.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'health', $params, 5 );

	if ( is_wp_error( $output ) ) {
		return array(
			'success' => false,
			'error'   => $output->get_error_message(),
		);
	}

	$result_data = json_decode( $output, true );

	return $result_data ?? array( 'success' => false );
}

/**
 * ============================================================================
 * CANVAS FILTER HANDLERS
 * ============================================================================
 */

/**
 * Generate an image using the canvas npm package (server-side).
 *
 * Handles the `wp_mcp_ai_canvas_generate_image` filter. Requires the
 * NV oOS Canvas Addon plugin, or canvas installed via npm install canvas@2.
 *
 * @param array|false $result Result from a previous filter handler (pass-through).
 * @param array       $params {
 *     Image generation parameters.
 *
 *     @type string $output     Absolute path for the output PNG file (required).
 *     @type int    $width      Canvas width in pixels (default 800).
 *     @type int    $height     Canvas height in pixels (default 600).
 *     @type string $background CSS background colour (default #ffffff).
 *     @type array  $commands   Drawing commands array (optional).
 * }
 * @return array|WP_Error Result array with 'output_path', 'width', 'height' on success.
 */
function wp_mcp_ai_canvas_generate_image_handler( $result, $params ) {
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/canvas-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'generate', $params, 30 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$result_data = json_decode( $output, true );

	if ( ! $result_data || empty( $result_data['success'] ) ) {
		return new WP_Error(
			'canvas_generate_failed',
			isset( $result_data['error'] ) ? $result_data['error'] : __( 'Canvas image generation failed.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	return array(
		'output_path' => $result_data['output_path'],
		'width'       => $result_data['width'],
		'height'      => $result_data['height'],
	);
}

/**
 * Render a Chart.js configuration to a PNG image using canvas.
 *
 * Handles the `wp_mcp_ai_chartjs_generate_image` filter. Both the canvas
 * and chart.js npm packages must be available.
 *
 * @param array|false $result Result from a previous filter handler (pass-through).
 * @param array       $config Chart.js configuration array with 'type', 'data', and 'options' keys.
 * @return array|WP_Error Result array with 'url', 'path', 'width', 'height' on success.
 */
function wp_mcp_ai_chartjs_generate_image_handler( $result, $config ) {
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/canvas-service.js';

	// Canvas service file must exist.
	if ( ! file_exists( $service_file ) ) {
		return false;
	}

	// Canvas npm package must be installed.
	$canvas_npm_path = WP_MCP_AI_PRO_PATH . 'node_modules/canvas';
	if ( ! is_dir( $canvas_npm_path ) ) {
		return false;
	}

	// Build a temporary output path inside the WordPress uploads directory.
	$upload_dir = wp_upload_dir();
	if ( ! empty( $upload_dir['error'] ) ) {
		return new WP_Error( 'canvas_upload_dir', $upload_dir['error'] );
	}
	$output_dir = trailingslashit( $upload_dir['basedir'] ) . 'mcp-ai-wpoos/charts/';
	if ( ! wp_mkdir_p( $output_dir ) ) {
		return new WP_Error( 'canvas_dir_failed', __( 'Failed to create chart output directory.', 'nvdigital-open-operator-system-oos-pro' ) );
	}

	$filename    = 'chart-' . wp_generate_uuid4() . '.png';
	$output_path = $output_dir . $filename;
	$output_url  = trailingslashit( $upload_dir['baseurl'] ) . 'mcp-ai-wpoos/charts/' . $filename;

	$params = array(
		'output' => $output_path,
		'width'  => 800,
		'height' => 400,
		'config' => $config,
	);

	$output = wp_mcp_ai_exec_node_service( $service_file, 'render_chart', $params, 30 );

	if ( is_wp_error( $output ) ) {
		return $output;
	}

	$result_data = json_decode( $output, true );

	if ( ! $result_data || empty( $result_data['success'] ) ) {
		return new WP_Error(
			'chartjs_render_failed',
			isset( $result_data['error'] ) ? $result_data['error'] : __( 'Chart image rendering failed.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	return array(
		'url'    => $output_url,
		'path'   => $output_path,
		'width'  => $result_data['width'],
		'height' => $result_data['height'],
	);
}

/**
 * ============================================================================
 * REGISTRATION FUNCTIONS
 * ============================================================================
 */

/**
 * Register Prettier filter handlers
 */
function wp_mcp_ai_register_prettier_filters() {
	add_filter( 'wp_mcp_ai_prettier_format_code', 'wp_mcp_ai_prettier_format_code_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_prettier_check_syntax', 'wp_mcp_ai_prettier_check_syntax_handler', 10, 2 );
}

/**
 * Register MJML filter handlers
 */
function wp_mcp_ai_register_mjml_filters() {
	add_filter( 'wp_mcp_ai_mjml_compile', 'wp_mcp_ai_mjml_compile_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_mjml_validate', 'wp_mcp_ai_mjml_validate_handler', 10, 2 );
}

/**
 * Register fluent-ffmpeg filter handlers
 */
function wp_mcp_ai_register_ffmpeg_filters() {
	add_filter( 'wp_mcp_ai_fluent_ffmpeg_get_metadata', 'wp_mcp_ai_fluent_ffmpeg_get_metadata_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_fluent_ffmpeg_transcode_video', 'wp_mcp_ai_fluent_ffmpeg_transcode_video_handler', 10, 2 );
}

/**
 * Register yfinance filter handlers
 */
function wp_mcp_ai_register_yfinance_filters() {
	add_filter( 'wp_mcp_ai_yfinance_ticker_info', 'wp_mcp_ai_yfinance_ticker_info_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_yfinance_current_price', 'wp_mcp_ai_yfinance_current_price_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_yfinance_batch_prices', 'wp_mcp_ai_yfinance_batch_prices_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_yfinance_price_history', 'wp_mcp_ai_yfinance_price_history_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_yfinance_search_ticker', 'wp_mcp_ai_yfinance_search_ticker_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_yfinance_health_check', 'wp_mcp_ai_yfinance_health_check_handler', 10, 2 );
}

/**
 * Register canvas filter handlers
 */
function wp_mcp_ai_register_canvas_filters() {
	add_filter( 'wp_mcp_ai_canvas_generate_image', 'wp_mcp_ai_canvas_generate_image_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_chartjs_generate_image', 'wp_mcp_ai_chartjs_generate_image_handler', 10, 2 );
}

/**
 * Register all NPM package filter handlers
 *
 * Call this function to enable all NPM package integrations at once.
 */
function wp_mcp_ai_register_all_npm_filters() {
	wp_mcp_ai_register_prettier_filters();
	wp_mcp_ai_register_mjml_filters();
	wp_mcp_ai_register_ffmpeg_filters();
	wp_mcp_ai_register_yfinance_filters();
	wp_mcp_ai_register_canvas_filters();
	wp_mcp_ai_register_language_filters();
}

/**
 * ============================================================================
 * AUTO-REGISTRATION
 * ============================================================================
 */

/**
 * Auto-register NPM filters on init hook
 *
 * Deferred to init hook to avoid instantiating Process Service during plugin activation.
 * This prevents fatal errors when proc_open is not available on the server.
 */
function wp_mcp_ai_auto_register_npm_filters() {
	/**
	 * Check if auto-registration is enabled
	 *
	 * Auto-registration can be controlled via constant or filter.
	 * Default is enabled if Node.js is available.
	 */
	$auto_register = defined( 'WP_MCP_AI_AUTO_REGISTER_NPM_FILTERS' )
		? WP_MCP_AI_AUTO_REGISTER_NPM_FILTERS
		: true;

	/**
	 * Filter to control auto-registration of NPM filters.
	 *
	 * @param bool $auto_register Whether to auto-register filters.
	 */
	$auto_register = apply_filters( 'wp_mcp_ai_auto_register_npm_filters', $auto_register );

	// Auto-register if enabled and Node.js is available.
	if ( $auto_register && wp_mcp_ai_is_nodejs_available() ) {
		wp_mcp_ai_register_all_npm_filters();
	}
}
add_action( 'init', 'wp_mcp_ai_auto_register_npm_filters', 20 );

/**
 * ============================================================================
 * ADMIN NOTICES
 * ============================================================================
 */

/**
 * Check if vendor packages are available
 *
 * @return array Array with 'available' boolean and 'missing' array of package names.
 */
function wp_mcp_ai_check_vendor_packages() {
	// Get CDN-loaded packages from the CDN Loader class (single source of truth).
	$cdn_packages = array();
	if ( class_exists( 'WP_MCP_AI_Pro_CDN_Loader' ) ) {
		$cdn_packages = WP_MCP_AI_Pro_CDN_Loader::get_cdn_packages();
	}

	$packages = array(
		'prettier'      => 'assets/vendor/prettier/standalone.js',
		'mjml'          => 'assets/vendor/mjml/lib/index.js',
		'fluent-ffmpeg' => 'assets/vendor/fluent-ffmpeg/index.js',
		'sharp'         => 'assets/vendor/sharp/lib/index.js',
		'katex'         => 'assets/vendor/katex/dist/katex.min.js',
		'ics'           => 'assets/vendor/ics/index.js',
		'turf'          => 'assets/vendor/turf/dist/cjs/index.cjs',
		'qrcode'        => 'assets/vendor/qrcode/lib/index.js',
	);

	$missing = array();
	foreach ( $packages as $name => $path ) {
		// Skip CDN packages - they're loaded from CDN, not vendor directory.
		if ( in_array( $name, $cdn_packages, true ) ) {
			continue;
		}

		$full_path = WP_MCP_AI_PRO_PATH . $path;
		// Also check for alternate paths that might exist.
		$alt_path = WP_MCP_AI_PRO_PATH . 'node_modules/' . $name;

		if ( ! file_exists( $full_path ) && ! is_dir( $alt_path ) ) {
			$missing[] = $name;
		}
	}

	return array(
		'available' => empty( $missing ),
		'missing'   => $missing,
	);
}

/**
 * Show admin notice if Node.js is not available but tools require it
 */
function wp_mcp_ai_npm_integration_admin_notice() {
	// Only show in admin.
	if ( ! is_admin() ) {
		return;
	}

	// Check if any Pro NPM tools are enabled.
	$settings             = get_option( 'wp_mcp_ai_settings', array() );
	$npm_features_enabled = false;

	// List of settings that require NPM packages.
	$npm_dependent_settings = array(
		'enable_media_toolkit',     // Uses sharp (already has service).
		'enable_quiz_system',       // Uses katex (already has service).
		'enable_project_management', // Uses ics (already has service).
		'enable_health_wellness_management', // Uses chart.js (already has service).
		'enable_places_management',  // Uses turf (already has service).
	);

	foreach ( $npm_dependent_settings as $setting ) {
		if ( ! empty( $settings[ $setting ] ) ) {
			$npm_features_enabled = true;
			break;
		}
	}

	// If no NPM features are enabled, don't show notice.
	if ( ! $npm_features_enabled ) {
		return;
	}

	// Check if vendor packages are available.
	$package_check = wp_mcp_ai_check_vendor_packages();

	// Check if Node.js is available.
	$nodejs_available = wp_mcp_ai_is_nodejs_available();

	// Show notice if either packages are missing or Node.js is unavailable.
	if ( ! $package_check['available'] || ! $nodejs_available ) {
		?>
		<div class="notice notice-warning is-dismissible">
			<p>
				<strong><?php esc_html_e( 'NV oOS Pro: Node.js Integration Required', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
			</p>
			<?php if ( ! $package_check['available'] ) : ?>
			<p>
				<?php
				echo wp_kses_post(
					sprintf(
						/* translators: %s: link to documentation */
						__( 'Some required NPM packages are missing from the vendor directory. This may indicate an incomplete installation. Please download the complete Pro addon package or contact support. See <a href="%s" target="_blank">integration guide</a> for details.', 'nvdigital-open-operator-system-oos-pro' ),
						admin_url( 'admin.php?page=wp-mcp-ai-settings#npm-integration' )
					)
				);
				?>
			</p>
				<?php if ( ! empty( $package_check['missing'] ) ) : ?>
			<p>
				<strong><?php esc_html_e( 'Missing packages:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
					<?php echo esc_html( implode( ', ', $package_check['missing'] ) ); ?>
			</p>
			<?php endif; ?>
			<?php endif; ?>
			
			<?php if ( ! $nodejs_available ) : ?>
			<p>
				<?php
				echo wp_kses_post(
					sprintf(
						/* translators: %s: link to Node.js download */
						__( 'Node.js is not installed on your server. Some Pro features require Node.js to execute. Please install <a href="%s" target="_blank">Node.js</a> on your server.', 'nvdigital-open-operator-system-oos-pro' ),
						'https://nodejs.org/'
					)
				);
				?>
			</p>
			<?php endif; ?>
			
			<p>
				<strong><?php esc_html_e( 'Features requiring Node.js:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
			</p>
			<ul style="list-style-type: disc; margin-left: 2em;">
				<li><?php esc_html_e( 'Code formatting (format_code_prettier tool)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Email template generation (generate_email_template tool)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Video transcoding (transcode_video tool)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Advanced image processing (optimize_image_sharp tool)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Math equation rendering (render_math_equation tool)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Calendar export (export_calendar_ics tool)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Health charts (generate_health_chart tool)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Geospatial analysis (analyze_geospatial tool)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>
		</div>
		<?php
	}
}
add_action( 'admin_notices', 'wp_mcp_ai_npm_integration_admin_notice' );

/**
 * Generate QR code via external API service.
 *
 * Falls back to api.qrserver.com when Node.js is unavailable.
 *
 * @since 1.3.1
 *
 * @param string $data    Data to encode.
 * @param string $format  Output format: 'base64', 'svg', or 'data-url'.
 * @param array  $options QR code options (width).
 * @return string|WP_Error QR code string or WP_Error on failure.
 */
function wp_mcp_ai_generate_qr_code_via_api( $data, $format, $options ) {
	$width = isset( $options['width'] ) ? absint( $options['width'] ) : 200;
	$size  = $width . 'x' . $width;

	$query_args = array(
		'size' => $size,
		'data' => $data,
	);

	if ( 'svg' === $format ) {
		$query_args['format'] = 'svg';
	}

	$url = add_query_arg( $query_args, 'https://api.qrserver.com/v1/create-qr-code/' );

	$response = wp_remote_get(
		$url,
		array(
			'timeout'    => 10,
			'user-agent' => 'WordPress/' . get_bloginfo( 'version' ),
		)
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$code = wp_remote_retrieve_response_code( $response );
	if ( 200 !== (int) $code ) {
		return new WP_Error(
			'qr_api_error',
			sprintf(
				/* translators: %d: HTTP response code */
				__( 'External QR code API returned HTTP %d.', 'nvdigital-open-operator-system-oos-pro' ),
				$code
			)
		);
	}

	$body = wp_remote_retrieve_body( $response );
	if ( empty( $body ) ) {
		return new WP_Error(
			'qr_api_empty',
			__( 'External QR code API returned an empty response.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	switch ( $format ) {
		case 'base64':
			return base64_encode( $body ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		case 'svg':
			return $body;
		case 'data-url':
		default:
			return 'data:image/png;base64,' . base64_encode( $body ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}
}

/**
 * Generate QR code for TOTP authentication
 *
 * Uses qrcode NPM package to generate QR codes for authenticator apps.
 * Falls back to an external API service when Node.js is not available.
 *
 * @since 1.3.0
 *
 * @param string $data    Data to encode (typically otpauth:// URI).
 * @param string $format  Output format: 'base64' (default), 'svg', or 'data-url'.
 * @param array  $options QR code options (size, margin, error correction level).
 * @return string|WP_Error QR code string or WP_Error on failure.
 */
function wp_mcp_ai_generate_qr_code( $data, $format = 'data-url', $options = array() ) {
	// Default options.
	$defaults = array(
		'width'                => 200,
		'margin'               => 2,
		'errorCorrectionLevel' => 'M', // L, M, Q, H.
		'color'                => array(
			'dark'  => '#000000',
			'light' => '#ffffff',
		),
	);

	$options = wp_parse_args( $options, $defaults );

	// Use the pre-packaged service file (qrcode and its deps are vendored under
	// assets/vendor/qrcode/ so no npm install is required on the server).
	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/qrcode-service.js';

	if ( wp_mcp_ai_is_nodejs_available() && file_exists( $service_file ) ) {
		$params = array(
			'data'    => $data,
			'format'  => $format,
			'options' => $options,
		);

		$result = wp_mcp_ai_exec_node_service( $service_file, 'generate', $params, 10 );

		if ( ! is_wp_error( $result ) ) {
			$result_data = json_decode( $result, true );

			if ( $result_data && ! empty( $result_data['success'] ) && isset( $result_data['result'] ) ) {
				return $result_data['result'];
			}
		}
	}

	// Fallback: generate via external API (works even without Node.js).
	return wp_mcp_ai_generate_qr_code_via_api( $data, $format, $options );
}

/**
 * Add QR code generation filter for vault TOTP
 *
 * @since 1.3.0
 */
add_filter( 'wp_mcp_ai_generate_qr_code', 'wp_mcp_ai_generate_qr_code', 10, 3 );

// =============================================================================
// LANGUAGE DETECTION FILTER HANDLERS (franc + iso-639-1)
// =============================================================================

/**
 * Detect language of text using the franc Node.js service.
 *
 * @since 1.4.0
 *
 * @param false|array $result Existing result (false = not yet handled).
 * @param array       $params Parameters including 'text'.
 * @return false|array Detection result or false on failure.
 */
function wp_mcp_ai_lang_detect_handler( $result, $params ) {
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/lang-detect-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'detect', $params, 10 );

	if ( is_wp_error( $output ) ) {
		return false;
	}

	$data = json_decode( $output, true );
	if ( $data && ! empty( $data['success'] ) && isset( $data['result'] ) ) {
		return $data['result'];
	}

	return false;
}

/**
 * Look up ISO 639-1 language code info using the lang-detect Node.js service.
 *
 * @since 1.4.0
 *
 * @param false|array $result Existing result.
 * @param array       $params Parameters including 'code'.
 * @return false|array Language info or false on failure.
 */
function wp_mcp_ai_lang_code_info_handler( $result, $params ) {
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/lang-detect-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'validate_code', $params, 10 );

	if ( is_wp_error( $output ) ) {
		return false;
	}

	$data = json_decode( $output, true );
	if ( $data && ! empty( $data['success'] ) && isset( $data['result'] ) ) {
		return $data['result'];
	}

	return false;
}

/**
 * Format / validate a phone number using the phone-format Node.js service.
 *
 * @since 1.4.0
 *
 * @param false|array $result Existing result.
 * @param array       $params Parameters including 'phone' and 'country_code'.
 * @return false|array Formatted phone data or false on failure.
 */
function wp_mcp_ai_phone_format_handler( $result, $params ) {
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/phone-format-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'format', $params, 10 );

	if ( is_wp_error( $output ) ) {
		return false;
	}

	$data = json_decode( $output, true );
	if ( $data && ! empty( $data['success'] ) && isset( $data['result'] ) ) {
		return $data['result'];
	}

	return false;
}

/**
 * Validate a phone number using libphonenumber-js via Node.js service.
 *
 * @since 1.4.0
 *
 * @param false|bool|WP_Error $result Existing result.
 * @param array               $params Parameters including 'phone' and 'country'.
 * @return false|bool|WP_Error Validation result or false if Node.js unavailable.
 */
function wp_mcp_ai_validator_phone_handler( $result, $params ) {
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/phone-format-service.js';
	$output       = wp_mcp_ai_exec_node_service(
		$service_file,
		'validate',
		array(
			'phone'        => isset( $params['phone'] ) ? $params['phone'] : '',
			'country_code' => isset( $params['country'] ) ? $params['country'] : 'US',
		),
		10
	);

	if ( is_wp_error( $output ) ) {
		return false;
	}

	$data = json_decode( $output, true );
	if ( $data && ! empty( $data['success'] ) && isset( $data['result']['valid'] ) ) {
		if ( ! $data['result']['valid'] ) {
			return new WP_Error(
				'invalid_phone',
				__( 'Invalid phone number.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}
		return true;
	}

	return false;
}

/**
 * Translate text using the google-translate-api-x Node.js service.
 *
 * @since 1.4.0
 *
 * @param false|array $result Existing result.
 * @param array       $params Parameters including 'text', 'target_language', 'source_language'.
 * @return false|array Translation result or false on failure.
 */
function wp_mcp_ai_translate_text_handler( $result, $params ) {
	if ( false !== $result ) {
		return $result;
	}

	$service_file = WP_MCP_AI_PRO_PATH . 'node-services/translate-service.js';
	$output       = wp_mcp_ai_exec_node_service( $service_file, 'translate', $params, 30 );

	if ( is_wp_error( $output ) ) {
		return false;
	}

	$data = json_decode( $output, true );
	if ( $data && ! empty( $data['success'] ) && isset( $data['result'] ) ) {
		return $data['result'];
	}

	return false;
}

/**
 * Register language detection filter handlers.
 *
 * @since 1.4.0
 */
function wp_mcp_ai_register_language_filters() {
	add_filter( 'wp_mcp_ai_lang_detect', 'wp_mcp_ai_lang_detect_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_lang_code_info', 'wp_mcp_ai_lang_code_info_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_phone_format', 'wp_mcp_ai_phone_format_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_validator_phone', 'wp_mcp_ai_validator_phone_handler', 10, 2 );
	add_filter( 'wp_mcp_ai_translate_text', 'wp_mcp_ai_translate_text_handler', 10, 2 );
}
