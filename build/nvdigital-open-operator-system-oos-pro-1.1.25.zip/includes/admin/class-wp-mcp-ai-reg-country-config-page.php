<?php
/**
 * Country Configuration Page for Regulatory Registration Toolkit.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Country Configuration Page class.
 */
class WP_MCP_AI_Reg_Country_Config_Page {
	/**
	 * Initialize the class.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu_page' ), 24 );
	}

	/**
	 * Add menu page.
	 */
	public static function add_menu_page() {
		add_submenu_page(
			'edit.php?post_type=mcp_ai_reg_product',
			__( 'Country Requirements', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Country Requirements', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_options',
			'wp-mcp-ai-reg-country-config',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Render the country config page.
	 */
	public static function render_page() {
		// Get all countries.
		$countries = self::get_countries();
		?>
		<div class="wrap wp-mcp-ai-country-config">
			<h1><?php echo esc_html__( 'Country Requirements Configuration', 'nvdigital-open-operator-system-oos-pro' ); ?></h1>
			<p><?php echo esc_html__( 'Configure regulatory requirements for different countries and authorities.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

			<div class="country-config-section">
				<h2><?php esc_html_e( 'Supported Countries', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p><?php esc_html_e( 'Manage countries and their regulatory authorities for product registration tracking.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

				<?php if ( ! empty( $countries ) ) : ?>
					<table class="wp-list-table widefat fixed striped">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Country', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<th><?php esc_html_e( 'Code', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<th><?php esc_html_e( 'Regulatory Authority', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<th><?php esc_html_e( 'Registrations', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<th><?php esc_html_e( 'Actions', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $countries as $country ) : ?>
								<tr>
									<td>
										<strong><?php echo esc_html( $country['name'] ); ?></strong>
									</td>
									<td>
										<span class="country-code"><?php echo esc_html( $country['code'] ); ?></span>
									</td>
									<td>
										<?php echo esc_html( $country['authority'] ); ?>
									</td>
									<td>
										<?php echo esc_html( $country['reg_count'] ); ?>
									</td>
									<td>
										<a href="<?php echo esc_url( get_edit_post_link( $country['id'] ) ); ?>" class="button button-small" title="<?php esc_attr_e( 'Edit', 'nvdigital-open-operator-system-oos-pro' ); ?>">
											<span class="dashicons dashicons-edit" aria-hidden="true"></span>
											<span class="screen-reader-text"><?php esc_html_e( 'Edit', 'nvdigital-open-operator-system-oos-pro' ); ?></span>
										</a>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else : ?>
					<div class="notice notice-warning inline">
						<p><?php esc_html_e( 'No countries configured yet.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</div>
				<?php endif; ?>

				<p>
					<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=mcp_ai_reg_country' ) ); ?>" class="button button-primary">
						<span class="dashicons dashicons-plus-alt"></span>
						<?php esc_html_e( 'Add New Country', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</a>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_reg_country' ) ); ?>" class="button">
						<?php esc_html_e( 'View All Countries', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</a>
				</p>
			</div>

			<div class="country-config-section">
				<h2><?php esc_html_e( 'Pre-configured Countries', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p><?php esc_html_e( 'The following countries are pre-configured with default regulatory requirements:', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

				<div class="preconfigured-countries">
					<div class="country-info-card">
						<h3><span class="country-flag">🇱🇰</span> Sri Lanka</h3>
						<p><strong><?php esc_html_e( 'Authority:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> NMRA (National Medicines Regulatory Authority)</p>
						<ul>
							<li><?php esc_html_e( 'Registration Certificate required', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Certificate of Analysis (CoA)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'INCI ingredient list', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Product artwork approval', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						</ul>
					</div>

					<div class="country-info-card">
						<h3><span class="country-flag">🇦🇪</span> United Arab Emirates</h3>
						<p><strong><?php esc_html_e( 'Authority:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> MOHAP / Dubai Municipality</p>
						<ul>
							<li><?php esc_html_e( 'Product registration certificate', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'GMP certificate', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Certificate of Free Sale', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'MSDS (Material Safety Data Sheet)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						</ul>
					</div>

					<div class="country-info-card">
						<h3><span class="country-flag">🇸🇦</span> Saudi Arabia</h3>
						<p><strong><?php esc_html_e( 'Authority:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> SFDA (Saudi Food and Drug Authority)</p>
						<ul>
							<li><?php esc_html_e( 'SFDA product registration', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Certificate of Free Sale', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Product formula certificate', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Authorized distributor letter', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						</ul>
					</div>

					<div class="country-info-card">
						<h3><span class="country-flag">🇶🇦</span> Qatar</h3>
						<p><strong><?php esc_html_e( 'Authority:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> Ministry of Public Health</p>
						<ul>
							<li><?php esc_html_e( 'Product registration certificate', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Certificate of Origin', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'GMP certificate', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						</ul>
					</div>

					<div class="country-info-card">
						<h3><span class="country-flag">🇰🇼</span> Kuwait</h3>
						<p><strong><?php esc_html_e( 'Authority:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> Ministry of Health</p>
						<ul>
							<li><?php esc_html_e( 'Product registration approval', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Certificate of Free Sale', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Product specifications', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						</ul>
					</div>

					<div class="country-info-card">
						<h3><span class="country-flag">🇴🇲</span> Oman</h3>
						<p><strong><?php esc_html_e( 'Authority:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> Ministry of Health</p>
						<ul>
							<li><?php esc_html_e( 'Product registration', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Certificate of Analysis', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Manufacturing license', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						</ul>
					</div>

					<div class="country-info-card">
						<h3><span class="country-flag">🇮🇳</span> India</h3>
						<p><strong><?php esc_html_e( 'Authority:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> CDSCO (Central Drugs Standard Control Organisation)</p>
						<ul>
							<li><?php esc_html_e( 'Import license', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Product registration certificate', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Certificate of Free Sale', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'GMP certificate from manufacturer', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						</ul>
					</div>
				</div>
			</div>

			<div class="country-config-section">
				<h2><?php esc_html_e( 'Document Requirements', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p><?php esc_html_e( 'Common document types required across countries:', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Document Type', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
							<th><?php esc_html_e( 'Description', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						$doc_types = self::get_document_types();
						foreach ( $doc_types as $doc_type ) :
							?>
							<tr>
								<td><strong><?php echo esc_html( $doc_type['name'] ); ?></strong></td>
								<td><?php echo esc_html( $doc_type['description'] ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<p>
					<a href="<?php echo esc_url( admin_url( 'edit-tags.php?taxonomy=mcp_ai_doc_type&post_type=mcp_ai_reg_document' ) ); ?>" class="button">
						<?php esc_html_e( 'Manage Document Types', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</a>
				</p>
			</div>
		</div>

		<style>
			.wp-mcp-ai-country-config .country-config-section {
				background: #fff;
				border: 1px solid #ccd0d4;
				border-radius: 4px;
				padding: 20px;
				margin: 20px 0;
			}
			.wp-mcp-ai-country-config .country-config-section h2 {
				margin-top: 0;
			}
			.wp-mcp-ai-country-config .country-code {
				display: inline-block;
				background: #f0f0f1;
				padding: 2px 8px;
				border-radius: 3px;
				font-family: monospace;
				font-weight: bold;
			}
			.wp-mcp-ai-country-config .button .dashicons {
				vertical-align: middle;
				margin-right: 5px;
			}
			.wp-mcp-ai-country-config .preconfigured-countries {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
				gap: 20px;
				margin: 20px 0;
			}
			.wp-mcp-ai-country-config .country-info-card {
				border: 1px solid #ccd0d4;
				border-radius: 4px;
				padding: 15px;
				background: #f9f9f9;
			}
			.wp-mcp-ai-country-config .country-info-card h3 {
				margin-top: 0;
				color: #1d2327;
			}
			.wp-mcp-ai-country-config .country-flag {
				font-size: 24px;
				margin-right: 8px;
			}
			.wp-mcp-ai-country-config .country-info-card ul {
				list-style: disc;
				margin-left: 20px;
			}
			.wp-mcp-ai-country-config .country-info-card ul li {
				margin: 5px 0;
			}
		</style>
		<?php
	}

	/**
	 * Get all countries with registration counts.
	 *
	 * @return array Countries data.
	 */
	private static function get_countries() {
		$countries = array();

		$query = new WP_Query(
			array(
				'post_type'      => 'mcp_ai_reg_country',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		if ( ! $query->have_posts() ) {
			wp_reset_postdata();
			return $countries;
		}

		// Get all country IDs first.
		$country_ids = array();
		while ( $query->have_posts() ) {
			$query->the_post();
			$country_ids[] = get_the_ID();
		}
		wp_reset_postdata();

		// Fetch all registration counts in a single query grouped by country_id.
		global $wpdb;
		if ( ! empty( $country_ids ) ) {
			$placeholders        = implode( ',', array_fill( 0, count( $country_ids ), '%d' ) );
			$registration_counts = $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- result of $wpdb->prepare() below.
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
					// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders built from array_fill with %d only.
					"SELECT pm.meta_value as country_id, COUNT(*) as total
					FROM {$wpdb->posts} p
					INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
					WHERE p.post_type = 'mcp_ai_registration'
					AND pm.meta_key = 'country_id'
					AND pm.meta_value IN ($placeholders)
					GROUP BY pm.meta_value",
					// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					...$country_ids
				),
				ARRAY_A
			);
		} else {
			$registration_counts = array();
		}

		// Convert to associative array for quick lookup.
		$counts_by_country = array();
		foreach ( $registration_counts as $row ) {
			$counts_by_country[ $row['country_id'] ] = (int) $row['total'];
		}

		// Build countries array with fetched data.
		$query->rewind_posts();
		while ( $query->have_posts() ) {
			$query->the_post();
			$country_id = get_the_ID();

			$countries[] = array(
				'id'        => $country_id,
				'name'      => get_the_title(),
				'code'      => get_post_meta( $country_id, 'country_code', true ),
				'authority' => get_post_meta( $country_id, 'regulatory_authority', true ),
				'reg_count' => isset( $counts_by_country[ $country_id ] ) ? $counts_by_country[ $country_id ] : 0,
			);
		}
		wp_reset_postdata();

		return $countries;
	}

	/**
	 * Get common document types.
	 *
	 * @return array Document types.
	 */
	private static function get_document_types() {
		return array(
			array(
				'name'        => 'LOA',
				'description' => __( 'Letter of Authorization from manufacturer', 'nvdigital-open-operator-system-oos-pro' ),
			),
			array(
				'name'        => 'Certificate of Analysis',
				'description' => __( 'Laboratory analysis certificate for product composition', 'nvdigital-open-operator-system-oos-pro' ),
			),
			array(
				'name'        => 'Certificate of Free Sale',
				'description' => __( 'Document confirming product is legally sold in country of origin', 'nvdigital-open-operator-system-oos-pro' ),
			),
			array(
				'name'        => 'GMP Certificate',
				'description' => __( 'Good Manufacturing Practice certification', 'nvdigital-open-operator-system-oos-pro' ),
			),
			array(
				'name'        => 'MSDS',
				'description' => __( 'Material Safety Data Sheet for product safety information', 'nvdigital-open-operator-system-oos-pro' ),
			),
			array(
				'name'        => 'Product Artwork',
				'description' => __( 'Product labeling and packaging artwork for regulatory approval', 'nvdigital-open-operator-system-oos-pro' ),
			),
			array(
				'name'        => 'INCI List',
				'description' => __( 'International Nomenclature Cosmetic Ingredient list', 'nvdigital-open-operator-system-oos-pro' ),
			),
			array(
				'name'        => 'Formula Certificate',
				'description' => __( 'Product formula certification document', 'nvdigital-open-operator-system-oos-pro' ),
			),
			array(
				'name'        => 'ISO Certificate',
				'description' => __( 'ISO quality management certification', 'nvdigital-open-operator-system-oos-pro' ),
			),
			array(
				'name'        => 'Payment Receipt',
				'description' => __( 'Proof of payment for registration fees', 'nvdigital-open-operator-system-oos-pro' ),
			),
		);
	}
}

WP_MCP_AI_Reg_Country_Config_Page::init();
