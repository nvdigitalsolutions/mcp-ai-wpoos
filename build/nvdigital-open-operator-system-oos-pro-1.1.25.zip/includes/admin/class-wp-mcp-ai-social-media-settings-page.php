<?php
/**
 * Social Media Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * Social Media Toolkit Settings Page Class
 */
class WP_MCP_AI_Social_Media_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'social_media';
		$this->toolkit_name     = __( 'Social Media Toolkit', 'nvdigital-open-operator-system-oos-pro' );
		$this->option_name      = 'wp_mcp_ai_social_media_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-social-media-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-share';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'Social Media Toolkit Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Comprehensive social media management toolkit with 15 tools for scheduling posts, analytics, content creation, and engagement tracking across multiple platforms.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Content Scheduling: Schedule posts, bulk scheduling, and content calendars', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Analytics: Cross-platform analytics, hashtag performance, and engagement metrics', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Content Creation: Generate post ideas, create videos, and optimize images', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Engagement: Monitor mentions, moderate comments, and auto-respond to messages', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Competitive Intelligence: Competitor analysis and influencer identification', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Trend Monitoring: Social listening and trending topics discovery', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Supported Platforms', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Facebook', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Twitter/X', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Instagram', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'LinkedIn', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'TikTok', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'Social Media Toolkit Configuration', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Posting Schedule', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<select name="default_schedule">
							<option value="immediate"><?php esc_html_e( 'Immediate', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
							<option value="optimal"><?php esc_html_e( 'Optimal Time (AI-determined)', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
							<option value="custom"><?php esc_html_e( 'Custom Time', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Default timing for scheduled posts', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Auto-Optimize Images', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="auto_optimize_images" value="1" checked />
							<?php esc_html_e( 'Automatically optimize images for each platform', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Social Listening', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_social_listening" value="1" />
							<?php esc_html_e( 'Monitor brand mentions and industry trends', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'schedule_social_post'         => __( 'Schedule Social Post', 'nvdigital-open-operator-system-oos-pro' ),
			'bulk_schedule_posts'          => __( 'Bulk Schedule Posts', 'nvdigital-open-operator-system-oos-pro' ),
			'post_to_multiple_platforms'   => __( 'Post to Multiple Platforms', 'nvdigital-open-operator-system-oos-pro' ),
			'create_content_calendar'      => __( 'Create Content Calendar', 'nvdigital-open-operator-system-oos-pro' ),
			'get_cross_platform_analytics' => __( 'Get Cross-Platform Analytics', 'nvdigital-open-operator-system-oos-pro' ),
			'track_hashtag_performance'    => __( 'Track Hashtag Performance', 'nvdigital-open-operator-system-oos-pro' ),
			'generate_post_ideas'          => __( 'Generate Post Ideas', 'nvdigital-open-operator-system-oos-pro' ),
			'create_social_video'          => __( 'Create Social Video', 'nvdigital-open-operator-system-oos-pro' ),
			'auto_optimize_images'         => __( 'Auto-Optimize Images', 'nvdigital-open-operator-system-oos-pro' ),
			'monitor_mentions_replies'     => __( 'Monitor Mentions & Replies', 'nvdigital-open-operator-system-oos-pro' ),
			'moderate_comments'            => __( 'Moderate Comments', 'nvdigital-open-operator-system-oos-pro' ),
			'auto_respond_messages'        => __( 'Auto-Respond to Messages', 'nvdigital-open-operator-system-oos-pro' ),
			'competitor_analysis'          => __( 'Competitor Analysis', 'nvdigital-open-operator-system-oos-pro' ),
			'influencer_identification'    => __( 'Influencer Identification', 'nvdigital-open-operator-system-oos-pro' ),
			'social_listening_trends'      => __( 'Social Listening & Trends', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_Social_Media_Settings_Page();
}
