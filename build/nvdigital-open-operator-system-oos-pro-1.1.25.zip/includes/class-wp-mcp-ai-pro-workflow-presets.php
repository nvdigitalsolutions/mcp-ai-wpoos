<?php
/**
 * Pro Workflow Builder Presets
 *
 * Provides pre-built workflow DAG (Directed Acyclic Graph) presets for the
 * Pro Workflow Builder. Each preset is a complete workflow template that can
 * be loaded into the React-based builder UI, giving users a head start with
 * common automation patterns.
 *
 * Preset categories:
 * - content:       Content creation and publishing workflows.
 * - seo:           Search engine optimisation workflows.
 * - ecommerce:     E-commerce and product management workflows.
 * - marketing:     Marketing automation workflows.
 * - data:          Data processing and analysis workflows.
 * - communication: Messaging and notification workflows.
 * - maintenance:   Site maintenance workflows.
 * - onboarding:    User and content onboarding workflows.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Workflow_Presets
 * @since      1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Pro_Workflow_Presets' ) ) {

	/**
	 * Class WP_MCP_AI_Pro_Workflow_Presets
	 *
	 * Registry of pre-built workflow DAG presets for the Pro Workflow Builder.
	 * All methods are static so the class can be used without instantiation.
	 *
	 * @since 1.0.0
	 */
	class WP_MCP_AI_Pro_Workflow_Presets {

		// ------------------------------------------------------------------
		// Preset retrieval
		// ------------------------------------------------------------------

		/**
		 * Get every available workflow preset.
		 *
		 * Presets are grouped internally by category but returned as a flat
		 * associative array keyed by preset ID.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Associative array of preset definitions.
		 */
		public static function get_presets() {
			$presets = array_merge(
				self::get_content_presets(),
				self::get_seo_presets(),
				self::get_ecommerce_presets(),
				self::get_marketing_presets(),
				self::get_data_presets(),
				self::get_communication_presets(),
				self::get_maintenance_presets(),
				self::get_onboarding_presets()
			);

			return $presets;
		}

		/**
		 * Get a single preset by its ID.
		 *
		 * @since  1.0.0
		 * @param  string $preset_id The unique preset identifier.
		 * @return array|null Preset definition array, or null if not found.
		 */
		public static function get_preset( $preset_id ) {
			$preset_id = sanitize_key( $preset_id );

			if ( '' === $preset_id ) {
				return null;
			}

			$presets = self::get_presets();

			return isset( $presets[ $preset_id ] ) ? $presets[ $preset_id ] : null;
		}

		/**
		 * Get all presets belonging to a specific category.
		 *
		 * @since  1.0.0
		 * @param  string $category Category slug (e.g. 'content', 'seo').
		 * @return array<string, array> Filtered preset definitions.
		 */
		public static function get_presets_by_category( $category ) {
			$category = sanitize_key( $category );

			return array_filter(
				self::get_presets(),
				function ( $preset ) use ( $category ) {
					return isset( $preset['category'] ) && $preset['category'] === $category;
				}
			);
		}

		/**
		 * Get the list of available preset categories.
		 *
		 * @since  1.0.0
		 * @return array<string, string> Slug => label pairs.
		 */
		public static function get_categories() {
			return array(
				'content'       => __( 'Content Creation & Publishing', 'nvdigital-open-operator-system-oos-pro' ),
				'seo'           => __( 'Search Engine Optimisation', 'nvdigital-open-operator-system-oos-pro' ),
				'ecommerce'     => __( 'E-Commerce & Product Management', 'nvdigital-open-operator-system-oos-pro' ),
				'marketing'     => __( 'Marketing Automation', 'nvdigital-open-operator-system-oos-pro' ),
				'data'          => __( 'Data Processing & Analysis', 'nvdigital-open-operator-system-oos-pro' ),
				'communication' => __( 'Messaging & Notifications', 'nvdigital-open-operator-system-oos-pro' ),
				'maintenance'   => __( 'Site Maintenance', 'nvdigital-open-operator-system-oos-pro' ),
				'onboarding'    => __( 'User & Content Onboarding', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		// ------------------------------------------------------------------
		// Preset installation
		// ------------------------------------------------------------------

		/**
		 * Prepare a preset for loading into the Workflow Builder.
		 *
		 * Returns the nodes and edges arrays ready to be consumed by the
		 * ReactFlow-based builder UI.
		 *
		 * @since  1.0.0
		 * @param  string $preset_id The unique preset identifier.
		 * @return array|\WP_Error Workflow data on success, WP_Error on failure.
		 */
		public static function install_preset( $preset_id ) {
			$preset = self::get_preset( $preset_id );

			if ( null === $preset ) {
				return new \WP_Error(
					'invalid_preset',
					/* translators: %s: preset identifier */
					sprintf( __( 'Workflow preset "%s" does not exist.', 'nvdigital-open-operator-system-oos-pro' ), sanitize_key( $preset_id ) )
				);
			}

			return array(
				'name'        => $preset['name'],
				'description' => $preset['description'],
				'category'    => $preset['category'],
				'icon'        => $preset['icon'],
				'tags'        => $preset['tags'],
				'nodes'       => $preset['nodes'],
				'edges'       => $preset['edges'],
			);
		}

		// ------------------------------------------------------------------
		// Content presets
		// ------------------------------------------------------------------

		/**
		 * Get content creation and publishing workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Content preset definitions.
		 */
		private static function get_content_presets() {
			return array(
				'content_pipeline'         => array(
					'name'        => __( 'Blog Post Pipeline', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Research a topic, generate an outline, write a draft, optimise for SEO, and publish.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'content',
					'icon'        => 'dashicons-admin-page',
					'tags'        => array( 'content', 'seo', 'publishing' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Topic Input', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Enter the blog topic to research.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Research Topic', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'web_search',
								'arguments'   => array( 'query' => '{{input.topic}}' ),
								'description' => __( 'Research the topic using web search.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Outline', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'outline' ),
								'description' => __( 'Generate a structured outline from research.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Write Draft', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_status' => 'draft',
									'post_type'   => 'post',
								),
								'description' => __( 'Create a draft post from the outline.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Optimise SEO', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'seo_meta_optimizer',
								'arguments'   => array( 'post_id' => '{{node_4.post_id}}' ),
								'description' => __( 'Optimise post meta for search engines.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Publish Post', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array(
									'post_id'     => '{{node_4.post_id}}',
									'post_status' => 'publish',
								),
								'description' => __( 'Publish the finished post.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 900,
							),
							'data'     => array(
								'label'       => __( 'Pipeline Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Blog post published successfully.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
				'content_refresh'          => array(
					'name'        => __( 'Content Refresh', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Find old posts, analyse performance, update content, and regenerate images.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'content',
					'icon'        => 'dashicons-update',
					'tags'        => array( 'content', 'maintenance', 'images' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Find Old Posts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'content_freshness_checker',
								'arguments'   => array( 'max_age_days' => 180 ),
								'description' => __( 'Identify posts older than 180 days.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Analyse Performance', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_analytics',
								'arguments'   => array( 'metric' => 'pageviews' ),
								'description' => __( 'Pull analytics data for identified posts.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Needs Update?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.pageviews < 100',
								'description' => __( 'Check if post performance is below threshold.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Update Content', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array( 'post_status' => 'draft' ),
								'description' => __( 'Refresh the post content with updated information.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Regenerate Images', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'generate_openai_image',
								'arguments'   => array( 'size' => '1024x1024' ),
								'description' => __( 'Generate fresh featured images for the post.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Refresh Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Content refresh workflow finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_6',
							'source'       => 'node_3',
							'target'       => 'node_6',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
				'social_content_repurpose' => array(
					'name'        => __( 'Repurpose for Social', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Take an existing post, generate social media snippets, and schedule them.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'content',
					'icon'        => 'dashicons-share',
					'tags'        => array( 'content', 'social', 'scheduling' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Select Post', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Choose the post to repurpose for social media.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Get Post Content', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_post',
								'arguments'   => array( 'post_id' => '{{input.post_id}}' ),
								'description' => __( 'Retrieve the full post content.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Social Snippets', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'social_snippets' ),
								'description' => __( 'Create platform-specific social media snippets.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Generate Social Image', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'generate_openai_image',
								'arguments'   => array( 'size' => '1200x630' ),
								'description' => __( 'Create an optimised image for social sharing.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Schedule Posts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'post',
									'post_status' => 'future',
								),
								'description' => __( 'Schedule the social media posts for publishing.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Repurpose Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Social media content scheduled.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
				'newsletter_workflow'      => array(
					'name'        => __( 'Newsletter Builder', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Collect top posts, generate a summary, format the email, and send the newsletter.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'content',
					'icon'        => 'dashicons-email-alt',
					'tags'        => array( 'content', 'email', 'newsletter' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Collect Top Posts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_recent_posts',
								'arguments'   => array(
									'count'   => 5,
									'orderby' => 'comment_count',
								),
								'description' => __( 'Get the top-performing recent posts.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Generate Summary', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'newsletter_digest' ),
								'description' => __( 'Summarise each post into a newsletter-ready digest.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Format Email', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'email_html' ),
								'description' => __( 'Format the digest into an email-friendly layout.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Send Newsletter', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'newsletter' ),
								'description' => __( 'Broadcast the newsletter to subscribers.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Newsletter Sent', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Newsletter has been sent to all subscribers.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// SEO presets
		// ------------------------------------------------------------------

		/**
		 * Get search engine optimisation workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> SEO preset definitions.
		 */
		private static function get_seo_presets() {
			return array(
				'seo_audit'                 => array(
					'name'        => __( 'SEO Audit', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Crawl pages, check meta tags, analyse keywords, and generate an audit report.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'seo',
					'icon'        => 'dashicons-search',
					'tags'        => array( 'seo', 'audit', 'meta' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Crawl Pages', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'run_crawl4ai_job',
								'arguments'   => array( 'depth' => 2 ),
								'description' => __( 'Crawl the site to discover all pages.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Check Meta Tags', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_rankmath_seo',
								'arguments'   => array( 'check' => 'meta_tags' ),
								'description' => __( 'Analyse meta tags for each discovered page.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Analyse Keywords', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_search_console',
								'arguments'   => array( 'metric' => 'keywords' ),
								'description' => __( 'Pull keyword performance from Search Console.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Generate Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'seo_audit_report' ),
								'description' => __( 'Compile findings into a visual SEO audit report.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Audit Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'SEO audit report generated.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
				'broken_link_repair'        => array(
					'name'        => __( 'Link Repair', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Scan for broken links, suggest replacements, and update posts automatically.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'seo',
					'icon'        => 'dashicons-admin-links',
					'tags'        => array( 'seo', 'links', 'maintenance' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Scan Links', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'run_crawl4ai_job',
								'arguments'   => array( 'mode' => 'link_scan' ),
								'description' => __( 'Crawl the site to identify all outbound and internal links.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Broken Links Found?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_1.broken_count > 0',
								'description' => __( 'Check if any broken links were detected.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Suggest Replacements', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'suggest_internal_links',
								'arguments'   => array( 'post_id' => '{{node_1.post_id}}' ),
								'description' => __( 'Find replacement URLs for broken links.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Update Posts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array(
									'post_id' => '{{node_3.post_id}}',
									'content' => '{{node_3.updated_content}}',
								),
								'description' => __( 'Replace broken links with suggested alternatives.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Repair Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Broken links have been repaired.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_2_5',
							'source'       => 'node_2',
							'target'       => 'node_5',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
				'keyword_research_pipeline' => array(
					'name'        => __( 'Keyword Pipeline', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Research keywords, analyse competition, prioritise opportunities, and create content briefs.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'seo',
					'icon'        => 'dashicons-chart-bar',
					'tags'        => array( 'seo', 'keywords', 'research' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Seed Keywords', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Enter seed keywords to begin research.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Research Keywords', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'web_search',
								'arguments'   => array( 'query' => '{{input.keywords}} keyword ideas' ),
								'description' => __( 'Expand seed keywords into a keyword list.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Analyse Competition', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_search_console',
								'arguments'   => array( 'metric' => 'impressions' ),
								'description' => __( 'Evaluate competition levels for each keyword.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Prioritise Keywords', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'content_recommendation_engine',
								'arguments'   => array( 'mode' => 'ranking_potential' ),
								'description' => __( 'Rank keywords by opportunity score.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Create Content Briefs', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'post',
									'post_status' => 'draft',
								),
								'description' => __( 'Generate content briefs for prioritised keywords.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Pipeline Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Keyword research pipeline finished. Content briefs ready.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// E-commerce presets
		// ------------------------------------------------------------------

		/**
		 * Get e-commerce and product management workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> E-commerce preset definitions.
		 */
		private static function get_ecommerce_presets() {
			return array(
				'product_launch'          => array(
					'name'        => __( 'Product Launch', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Create a product, generate description, set pricing, publish, and announce.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'ecommerce',
					'icon'        => 'dashicons-cart',
					'tags'        => array( 'ecommerce', 'product', 'launch' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Product Details', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Enter basic product information.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Create Product', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_woo_product',
								'arguments'   => array( 'status' => 'draft' ),
								'description' => __( 'Create the WooCommerce product in draft mode.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Description', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'product_description' ),
								'description' => __( 'Generate an SEO-optimised product description.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Generate Product Image', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'generate_openai_image',
								'arguments'   => array( 'size' => '1024x1024' ),
								'description' => __( 'Create a product image using AI.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Publish Product', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array( 'post_status' => 'publish' ),
								'description' => __( 'Set the product to published status.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Announce Launch', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'announcements' ),
								'description' => __( 'Broadcast the product launch announcement.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 900,
							),
							'data'     => array(
								'label'       => __( 'Launch Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Product launched and announced successfully.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
				'order_fulfillment_check' => array(
					'name'        => __( 'Order Fulfillment Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Get pending orders, check inventory, flag issues, and notify the team.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'ecommerce',
					'icon'        => 'dashicons-clipboard',
					'tags'        => array( 'ecommerce', 'orders', 'inventory' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Get Pending Orders', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_woo_recent_orders',
								'arguments'   => array( 'status' => 'pending' ),
								'description' => __( 'Retrieve all orders awaiting fulfillment.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Check Inventory', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_woo_products',
								'arguments'   => array( 'check' => 'stock_status' ),
								'description' => __( 'Verify stock levels for ordered products.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Stock Issues?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.out_of_stock_count > 0',
								'description' => __( 'Check if any ordered items are out of stock.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Flag Issues', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'mcp_ai_task',
									'post_status' => 'publish',
								),
								'description' => __( 'Create a task for stock issues requiring attention.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Notify Team', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'operations' ),
								'description' => __( 'Alert the operations team about stock issues.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Check Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Order fulfillment check completed.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_6',
							'source'       => 'node_3',
							'target'       => 'node_6',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
				'review_response'         => array(
					'name'        => __( 'Review Response', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Get new product reviews, analyse sentiment, and draft responses.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'ecommerce',
					'icon'        => 'dashicons-star-filled',
					'tags'        => array( 'ecommerce', 'reviews', 'sentiment' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Get New Reviews', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array(
									'post_type' => 'product',
									'meta_key'  => 'rating',
								),
								'description' => __( 'Fetch recent product reviews.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Analyse Sentiment', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_analyze_sentiment',
								'arguments'   => array( 'text' => '{{node_1.reviews}}' ),
								'description' => __( 'Determine the sentiment of each review.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Negative Review?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.sentiment === "negative"',
								'description' => __( 'Route based on review sentiment.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Draft Apology Response', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'tone' => 'empathetic' ),
								'description' => __( 'Draft a thoughtful response to the negative review.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 400,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Draft Thank-You Response', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'tone' => 'grateful' ),
								'description' => __( 'Draft a thank-you response for the positive review.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Responses Ready', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Review responses drafted and ready for approval.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_5',
							'source'       => 'node_3',
							'target'       => 'node_5',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_6',
							'source'       => 'node_4',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Marketing presets
		// ------------------------------------------------------------------

		/**
		 * Get marketing automation workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Marketing preset definitions.
		 */
		private static function get_marketing_presets() {
			return array(
				'lead_nurture_sequence' => array(
					'name'        => __( 'Lead Nurture', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Identify cold leads, segment them, generate personalised messages, and send.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'marketing',
					'icon'        => 'dashicons-groups',
					'tags'        => array( 'marketing', 'leads', 'email' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Identify Cold Leads', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array(
									'post_type' => 'mcp_ai_contact',
									'status'    => 'cold',
								),
								'description' => __( 'Find leads that have gone cold.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Segment Leads', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'auto_categorize_content',
								'arguments'   => array( 'taxonomy' => 'lead_segment' ),
								'description' => __( 'Segment leads by industry and engagement level.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Personalised Message', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'personalised_email' ),
								'description' => __( 'Create a personalised nurture message for each segment.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Send Messages', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'email' ),
								'description' => __( 'Deliver the personalised messages to leads.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Nurture Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Lead nurture sequence dispatched.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
				'campaign_performance'  => array(
					'name'        => __( 'Campaign Review', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Collect campaign metrics, analyse ROI, generate a report, and broadcast a summary.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'marketing',
					'icon'        => 'dashicons-chart-area',
					'tags'        => array( 'marketing', 'analytics', 'reporting' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Collect Metrics', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_analytics',
								'arguments'   => array( 'metric' => 'conversions' ),
								'description' => __( 'Pull campaign conversion and traffic metrics.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Analyse ROI', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'visualize_workflow_metrics',
								'arguments'   => array( 'mode' => 'roi_analysis' ),
								'description' => __( 'Calculate return on investment for each campaign.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'campaign_report' ),
								'description' => __( 'Compile a visual campaign performance report.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Broadcast Summary', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'marketing' ),
								'description' => __( 'Share the campaign summary with the marketing team.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Review Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Campaign performance review completed.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
				'competitor_analysis'   => array(
					'name'        => __( 'Competitor Watch', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Monitor competitors, compare metrics, summarise findings, and alert the team.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'marketing',
					'icon'        => 'dashicons-visibility',
					'tags'        => array( 'marketing', 'competitors', 'research' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Competitor URLs', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Enter competitor website URLs to monitor.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Monitor Competitors', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'run_crawl4ai_job',
								'arguments'   => array( 'mode' => 'competitor_scan' ),
								'description' => __( 'Crawl competitor sites for changes.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Compare Metrics', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_pagespeed',
								'arguments'   => array(
									'url'      => '{{input.urls}}',
									'strategy' => 'both',
								),
								'description' => __( 'Compare performance metrics against competitors.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Summarise Findings', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'competitive_analysis' ),
								'description' => __( 'Compile a summary of competitive insights.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Alert Team', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'strategy' ),
								'description' => __( 'Notify the strategy team of key findings.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Analysis Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Competitor analysis finished and team notified.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Data presets
		// ------------------------------------------------------------------

		/**
		 * Get data processing and analysis workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Data preset definitions.
		 */
		private static function get_data_presets() {
			return array(
				'data_cleanup_pipeline' => array(
					'name'        => __( 'Data Cleanup', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Audit records, find duplicates, merge them, validate, and generate a report.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'data',
					'icon'        => 'dashicons-database',
					'tags'        => array( 'data', 'cleanup', 'duplicates' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Audit Records', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array( 'post_type' => 'any' ),
								'description' => __( 'Scan all content records for data quality issues.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Find Duplicates', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'semantic_content_search',
								'arguments'   => array( 'threshold' => 0.9 ),
								'description' => __( 'Use semantic search to identify duplicate content.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Duplicates Found?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.duplicate_count > 0',
								'description' => __( 'Check if duplicate records were detected.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Merge Records', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array(
									'post_id'    => '{{node_2.canonical_id}}',
									'merge_from' => '{{node_2.duplicate_ids}}',
								),
								'description' => __( 'Merge duplicate records into canonical entries.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Validate Data', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'validate_reasoning_chain',
								'arguments'   => array( 'data_set' => '{{node_4.result}}' ),
								'description' => __( 'Run validation checks on the cleaned data set.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Generate Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'cleanup_report' ),
								'description' => __( 'Create a cleanup summary report.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 900,
							),
							'data'     => array(
								'label'       => __( 'Cleanup Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Data cleanup pipeline finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_5',
							'source'       => 'node_3',
							'target'       => 'node_5',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
				'analytics_digest'      => array(
					'name'        => __( 'Analytics Digest', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Pull metrics, calculate trends, generate charts, and email a report.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'data',
					'icon'        => 'dashicons-chart-line',
					'tags'        => array( 'data', 'analytics', 'reporting' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Pull Metrics', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_analytics',
								'arguments'   => array( 'metric' => 'all' ),
								'description' => __( 'Retrieve site analytics data.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Calculate Trends', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'openai_usage_analytics',
								'arguments'   => array( 'mode' => 'trend_analysis' ),
								'description' => __( 'Identify trends and patterns in the data.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Charts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'line' ),
								'description' => __( 'Visualise the metrics as charts.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Email Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'email_digest' ),
								'description' => __( 'Send the analytics digest via email.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Digest Sent', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Analytics digest emailed to stakeholders.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Communication presets
		// ------------------------------------------------------------------

		/**
		 * Get messaging and notification workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Communication preset definitions.
		 */
		private static function get_communication_presets() {
			return array(
				'support_escalation' => array(
					'name'        => __( 'Support Escalation', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Check the support queue, identify urgent tickets, assign agents, and notify.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'communication',
					'icon'        => 'dashicons-sos',
					'tags'        => array( 'communication', 'support', 'escalation' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Check Support Queue', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array(
									'post_type' => 'mcp_ai_task',
									'status'    => 'open',
								),
								'description' => __( 'Retrieve open support tickets from the queue.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Identify Urgent Tickets', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_analyze_sentiment',
								'arguments'   => array( 'mode' => 'urgency_detection' ),
								'description' => __( 'Analyse tickets to identify urgent issues.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Urgent Tickets Found?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.urgency_level === "high"',
								'description' => __( 'Check if any tickets require immediate attention.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Assign Agents', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'delegate_to_agent',
								'arguments'   => array( 'priority' => 'high' ),
								'description' => __( 'Assign urgent tickets to available support agents.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Notify Team', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'support' ),
								'description' => __( 'Alert the support team about escalated tickets.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Escalation Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Support escalation workflow finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_6',
							'source'       => 'node_3',
							'target'       => 'node_6',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
				'team_standup'       => array(
					'name'        => __( 'Daily Standup', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Collect status updates from the team, summarise progress, and broadcast to channels.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'communication',
					'icon'        => 'dashicons-megaphone',
					'tags'        => array( 'communication', 'standup', 'team' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Collect Status Updates', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array(
									'post_type'  => 'mcp_ai_task',
									'date_query' => 'today',
								),
								'description' => __( 'Gather recent task updates from team members.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Summarise Progress', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'standup_summary' ),
								'description' => __( 'Create a concise standup summary from updates.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Broadcast to Channels', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'general' ),
								'description' => __( 'Post the standup summary to team channels.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Standup Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Daily standup summary has been shared.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Maintenance presets
		// ------------------------------------------------------------------

		/**
		 * Get site maintenance workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Maintenance preset definitions.
		 */
		private static function get_maintenance_presets() {
			return array(
				'health_check'  => array(
					'name'        => __( 'Site Health Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Check site performance, scan for security issues, audit plugins, and generate a report.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'maintenance',
					'icon'        => 'dashicons-heart',
					'tags'        => array( 'maintenance', 'health', 'security' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Check Performance', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_pagespeed',
								'arguments'   => array( 'strategy' => 'both' ),
								'description' => __( 'Run a PageSpeed performance check.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Scan Security', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'run_crawl4ai_job',
								'arguments'   => array( 'mode' => 'security_scan' ),
								'description' => __( 'Scan for common security vulnerabilities.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Audit Plugins', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array( 'type' => 'plugin_audit' ),
								'description' => __( 'Check installed plugins for updates and compatibility.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Issues Found?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_3.issues_count > 0',
								'description' => __( 'Determine if any health issues need attention.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Generate Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'health_report' ),
								'description' => __( 'Create a detailed site health report.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Notify Admin', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'admin' ),
								'description' => __( 'Alert the site administrator about issues.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 900,
							),
							'data'     => array(
								'label'       => __( 'Health Check Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Site health check finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_4_7',
							'source'       => 'node_4',
							'target'       => 'node_7',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
				'backup_verify' => array(
					'name'        => __( 'Backup Verify', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Trigger a backup, verify its integrity, log the result, and notify the admin.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'maintenance',
					'icon'        => 'dashicons-backup',
					'tags'        => array( 'maintenance', 'backup', 'verification' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Trigger Backup', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'execute_workflow',
								'arguments'   => array( 'action' => 'backup_database' ),
								'description' => __( 'Initiate a full site backup.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Verify Integrity', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'validate_workflow',
								'arguments'   => array( 'check' => 'backup_integrity' ),
								'description' => __( 'Validate the backup file integrity.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Backup Valid?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.is_valid === true',
								'description' => __( 'Check if the backup passed integrity verification.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Log Success', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'mcp_ai_task',
									'post_status' => 'publish',
								),
								'description' => __( 'Record the successful backup in the log.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 400,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Log Failure', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'mcp_ai_task',
									'post_status' => 'publish',
									'priority'    => 'high',
								),
								'description' => __( 'Record the backup failure for investigation.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Notify Admin', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'admin' ),
								'description' => __( 'Send backup status notification to the admin.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Backup Workflow Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Backup verification process finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_5',
							'source'       => 'node_3',
							'target'       => 'node_5',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_6',
							'source'       => 'node_4',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Onboarding presets
		// ------------------------------------------------------------------

		/**
		 * Get user and content onboarding workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Onboarding preset definitions.
		 */
		private static function get_onboarding_presets() {
			return array(
				'user_onboarding' => array(
					'name'        => __( 'User Onboarding', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Detect a new user, create welcome content, assign resources, and send a welcome message.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'onboarding',
					'icon'        => 'dashicons-admin-users',
					'tags'        => array( 'onboarding', 'users', 'welcome' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'New User Detected', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Triggered when a new user registers.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Create Welcome Content', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'page',
									'post_status' => 'publish',
								),
								'description' => __( 'Generate a personalised welcome page for the user.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Assign Resources', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'delegate_to_agent',
								'arguments'   => array( 'task' => 'resource_assignment' ),
								'description' => __( 'Assign onboarding resources and tutorials to the user.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Generate Welcome Image', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'generate_openai_image',
								'arguments'   => array( 'prompt' => 'welcome banner' ),
								'description' => __( 'Create a personalised welcome banner.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Send Welcome Message', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'welcome' ),
								'description' => __( 'Send the welcome message to the new user.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Onboarding Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'User onboarding workflow finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}
	}
}
