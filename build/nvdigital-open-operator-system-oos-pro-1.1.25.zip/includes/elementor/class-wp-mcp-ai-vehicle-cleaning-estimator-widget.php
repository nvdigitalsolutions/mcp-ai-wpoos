<?php
/**
 * Vehicle Cleaning Estimator Elementor Widget
 *
 * PWA-style interactive car-wash / detailing quote widget.
 * Accepts vehicle photos, a package selection, optional add-ons,
 * and a freeform message, then returns a full line-item AI estimate.
 *
 * @package WP_MCP_AI_Pro
 * @since   1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Vehicle Cleaning Estimator Widget Class.
 *
 * @since 1.1.0
 */
class WP_MCP_AI_Vehicle_Cleaning_Estimator_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * @since 1.1.0
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'wp_mcp_ai_vehicle_cleaning_estimator';
	}

	/**
	 * Get widget title.
	 *
	 * @since 1.1.0
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Vehicle Cleaning Estimator', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get widget icon.
	 *
	 * @since 1.1.0
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-list';
	}

	/**
	 * Get widget categories.
	 *
	 * @since 1.1.0
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( 'mcp-ai-toolkits' );
	}

	/**
	 * Get widget keywords.
	 *
	 * @since 1.1.0
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return array( 'vehicle', 'car wash', 'cleaning', 'estimate', 'quote', 'detailing', 'ai', 'mcp' );
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.1.0
	 */
	protected function register_controls() {

		// ── Content Section ──────────────────────────────────────────────────
		$this->start_controls_section(
			'content_section',
			array(
				'label' => __( 'Content', 'nvdigital-open-operator-system-oos-pro' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'assistant_id',
			array(
				'label'       => __( 'Assistant', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => $this->get_assistant_options(),
				'default'     => '',
				'label_block' => true,
				'description' => __( 'Select the NV oOS assistant configured for vehicle cleaning estimates. Leave empty to use the site default.', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		$this->add_control(
			'show_package_selector',
			array(
				'label'        => __( 'Show Package Selector', 'nvdigital-open-operator-system-oos-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'nvdigital-open-operator-system-oos-pro' ),
				'label_off'    => __( 'No', 'nvdigital-open-operator-system-oos-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_addon_selector',
			array(
				'label'        => __( 'Show Add-ons Selector', 'nvdigital-open-operator-system-oos-pro' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'nvdigital-open-operator-system-oos-pro' ),
				'label_off'    => __( 'No', 'nvdigital-open-operator-system-oos-pro' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array( 'show_package_selector' => 'yes' ),
			)
		);

		$this->add_control(
			'cta_label',
			array(
				'label'       => __( 'CTA Button Label', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Get My Estimate', 'nvdigital-open-operator-system-oos-pro' ),
				'description' => __( 'Label for the submit / estimate button.', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		$this->add_control(
			'placeholder_text',
			array(
				'label'       => __( 'Drop-zone Tip Text', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 3,
				'placeholder' => __( 'Drag vehicle photos here or tap to upload', 'nvdigital-open-operator-system-oos-pro' ),
				'description' => __( 'Helper text shown beneath the image drop zone.', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		$this->end_controls_section();

		// ── Pricing Section ──────────────────────────────────────────────────
		$this->start_controls_section(
			'pricing_section',
			array(
				'label' => __( 'Pricing', 'nvdigital-open-operator-system-oos-pro' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'currency',
			array(
				'label'   => __( 'Currency', 'nvdigital-open-operator-system-oos-pro' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'CAD',
				'options' => array(
					'CAD' => __( 'Canadian Dollar (CAD)', 'nvdigital-open-operator-system-oos-pro' ),
					'USD' => __( 'US Dollar (USD)', 'nvdigital-open-operator-system-oos-pro' ),
					'GBP' => __( 'British Pound (GBP)', 'nvdigital-open-operator-system-oos-pro' ),
					'EUR' => __( 'Euro (EUR)', 'nvdigital-open-operator-system-oos-pro' ),
					'AUD' => __( 'Australian Dollar (AUD)', 'nvdigital-open-operator-system-oos-pro' ),
				),
			)
		);

		$this->add_control(
			'tax_rate',
			array(
				'label'       => __( 'Tax Rate (%)', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 0,
				'min'         => 0,
				'max'         => 50,
				'step'        => 0.5,
				'description' => __( 'Enter the tax percentage to apply to the estimate total (e.g. 13 for 13% HST).', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		$this->end_controls_section();

		// ── Style Section ────────────────────────────────────────────────────
		$this->start_controls_section(
			'style_section',
			array(
				'label' => __( 'Style', 'nvdigital-open-operator-system-oos-pro' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'primary_color',
			array(
				'label'       => __( 'Primary / Accent Colour', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => \Elementor\Controls_Manager::COLOR,
				'description' => __( 'Used for the header, buttons, selected states, and total price.', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * Delegates to the [mcp_vehicle_cleaning_estimator] shortcode so that
	 * the Gutenberg block, Elementor widget, and plain shortcode all share
	 * the same rendering logic.
	 *
	 * @since 1.1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$attributes = array();

		if ( ! empty( $settings['assistant_id'] ) ) {
			$attributes[] = 'assistant_id="' . esc_attr( $settings['assistant_id'] ) . '"';
		}

		if ( ! empty( $settings['primary_color'] ) ) {
			$attributes[] = 'primary_color="' . esc_attr( $settings['primary_color'] ) . '"';
		}

		if ( isset( $settings['show_package_selector'] ) && 'yes' !== $settings['show_package_selector'] ) {
			$attributes[] = 'show_package_selector="no"';
		}

		if ( isset( $settings['show_addon_selector'] ) && 'yes' !== $settings['show_addon_selector'] ) {
			$attributes[] = 'show_addon_selector="no"';
		}

		if ( ! empty( $settings['currency'] ) ) {
			$attributes[] = 'currency="' . esc_attr( $settings['currency'] ) . '"';
		}

		if ( ! empty( $settings['tax_rate'] ) ) {
			$attributes[] = 'tax_rate="' . floatval( $settings['tax_rate'] ) . '"';
		}

		if ( ! empty( $settings['placeholder_text'] ) ) {
			$attributes[] = 'placeholder_text="' . esc_attr( $settings['placeholder_text'] ) . '"';
		}

		if ( ! empty( $settings['cta_label'] ) ) {
			$attributes[] = 'cta_label="' . esc_attr( $settings['cta_label'] ) . '"';
		}

		$shortcode = '[mcp_vehicle_cleaning_estimator ' . implode( ' ', $attributes ) . ']';
		echo do_shortcode( $shortcode ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaping is handled within render_vehicle_cleaning_estimator() in class-wp-mcp-ai-pro-toolkit-shortcodes.php.
	}

	/**
	 * Retrieve assistant options for the assistant dropdown control.
	 *
	 * @return array Associative array of assistant ID => title.
	 */
	protected function get_assistant_options() {
		if ( class_exists( 'WP_MCP_AI_Cache_Helper' ) && WP_MCP_AI_Cache_Helper::is_caching_enabled() ) {
			return WP_MCP_AI_Cache_Helper::get_elementor_options( array( $this, 'build_assistant_options' ) );
		}

		return $this->build_assistant_options();
	}

	/**
	 * Build assistant options array (extracted for caching).
	 *
	 * @return array Assistant options for dropdown.
	 */
	public function build_assistant_options() {
		$options = array( '' => __( 'Default Assistant', 'nvdigital-open-operator-system-oos-pro' ) );

		if ( ! class_exists( 'WP_MCP_AI_Assistant_CPT' ) ) {
			return $options;
		}

		// Check if the post type is registered before querying.
		// During Elementor AJAX requests, the post type may not be registered yet.
		if ( ! post_type_exists( WP_MCP_AI_Assistant_CPT::POST_TYPE ) ) {
			return $options;
		}

		$assistants = get_posts(
			array(
				'post_type'              => WP_MCP_AI_Assistant_CPT::POST_TYPE,
				'post_status'            => 'publish',
				'numberposts'            => -1,
				'orderby'                => 'title',
				'order'                  => 'ASC',
				'suppress_filters'       => true,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
			)
		);

		if ( ! is_array( $assistants ) || empty( $assistants ) ) {
			return $options;
		}

		foreach ( $assistants as $assistant_id ) {
			$title = get_the_title( $assistant_id );
			if ( $title && ! is_wp_error( $title ) ) {
				$options[ (string) $assistant_id ] = $title;
			}
		}

		return $options;
	}
}
