<?php
/**
 * Financial Planner Toolkit Research & Add
 *
 * Research & Add implementation for Financial Planner toolkit.
 * Manages Budget Categories and Goal Templates entities.
 *
 * @package WP_MCP_AI_Pro
 * @since 2.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-research-add-base.php';

/**
 * Financial Planner Research & Add implementation.
 */
class WP_MCP_AI_Financial_Planner_Research_Add extends WP_MCP_AI_Research_Add_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct( 'financial_planner' );

		// Register field schemas.
		add_filter( 'wp_mcp_ai_toolkit_cpt_field_schema', array( $this, 'filter_cpt_field_schema' ), 10, 3 );
		add_filter( 'wp_mcp_ai_toolkit_cct_field_schema', array( $this, 'filter_cct_field_schema' ), 10, 3 );
	}

	/**
	 * Get entity types for financial planner toolkit.
	 *
	 * @return array Entity types.
	 */
	protected function get_entity_types() {
		return array(
			'budget_categories' => __( 'Budget Categories', 'nvdigital-open-operator-system-oos-pro' ),
			'goal_templates'    => __( 'Goal Templates', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Filter CPT field schema.
	 *
	 * @param array  $schema       Field schema.
	 * @param string $toolkit_slug Toolkit slug.
	 * @param string $entity_type  Entity type.
	 * @return array Filtered schema.
	 */
	public function filter_cpt_field_schema( $schema, $toolkit_slug, $entity_type ) {
		if ( 'financial_planner' !== $toolkit_slug ) {
			return $schema;
		}

		switch ( $entity_type ) {
			case 'budget_categories':
				return $this->get_budget_categories_schema();
			case 'goal_templates':
				return $this->get_goal_templates_schema();
		}

		return $schema;
	}

	/**
	 * Filter CCT field schema.
	 *
	 * @param array  $schema       Field schema.
	 * @param string $toolkit_slug Toolkit slug.
	 * @param string $entity_type  Entity type.
	 * @return array Filtered schema.
	 */
	public function filter_cct_field_schema( $schema, $toolkit_slug, $entity_type ) {
		return $this->filter_cpt_field_schema( $schema, $toolkit_slug, $entity_type );
	}

	/**
	 * Get budget categories field schema.
	 *
	 * @return array Field definitions.
	 */
	private function get_budget_categories_schema() {
		return array(
			'category_name'        => array(
				'title'       => __( 'Category Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '100%',
				'is_required' => true,
			),
			'category_type'        => array(
				'title'       => __( 'Type', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'select',
				'width'       => '50%',
				'is_required' => true,
			),
			'amount'               => array(
				'title' => __( 'Amount', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'frequency'            => array(
				'title' => __( 'Frequency', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'select',
				'width' => '50%',
			),
			'description'          => array(
				'title' => __( 'Description', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'is_fixed'             => array(
				'title' => __( 'Fixed Expense', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'checkbox',
				'width' => '50%',
			),
			'notes'                => array(
				'title' => __( 'Notes', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'created_by_assistant' => array(
				'title' => __( 'Created by Assistant', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
		);
	}

	/**
	 * Get goal templates field schema.
	 *
	 * @return array Field definitions.
	 */
	private function get_goal_templates_schema() {
		return array(
			'goal_name'            => array(
				'title'       => __( 'Goal Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '100%',
				'is_required' => true,
			),
			'goal_type'            => array(
				'title' => __( 'Goal Type', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'select',
				'width' => '50%',
			),
			'target_amount'        => array(
				'title' => __( 'Target Amount', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'deadline'             => array(
				'title' => __( 'Deadline', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'strategy'             => array(
				'title' => __( 'Strategy', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'priority'             => array(
				'title' => __( 'Priority', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'select',
				'width' => '50%',
			),
			'notes'                => array(
				'title' => __( 'Notes', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'created_by_assistant' => array(
				'title' => __( 'Created by Assistant', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
		);
	}

	/**
	 * Render form fields for current entity.
	 *
	 * @param array $item Optional. Item data for edit form.
	 */
	protected function render_form_fields( $item = array() ) {
		$store  = $this->get_current_data_store();
		$schema = $store ? $store->get_field_schema() : array();

		if ( empty( $schema ) ) {
			parent::render_form_fields( $item );
			return;
		}

		?>
<table class="form-table">
		<?php foreach ( $schema as $field_name => $field_def ) : ?>
<tr>
<th scope="row">
<label for="item_<?php echo esc_attr( $field_name ); ?>">
			<?php echo esc_html( $field_def['title'] ); ?>
			<?php if ( ! empty( $field_def['is_required'] ) ) : ?>
<span class="required">*</span>
<?php endif; ?>
</label>
</th>
<td>
			<?php $this->render_field_input( $field_name, $field_def, $item ); ?>
</td>
</tr>
<?php endforeach; ?>
</table>
		<?php
	}

	/**
	 * Render field input based on type.
	 *
	 * @param string $field_name Field name.
	 * @param array  $field_def  Field definition.
	 * @param array  $item       Item data.
	 */
	private function render_field_input( $field_name, $field_def, $item = array() ) {
		$value    = isset( $item[ $field_name ] ) ? $item[ $field_name ] : '';
		$type     = isset( $field_def['type'] ) ? $field_def['type'] : 'text';
		$required = ! empty( $field_def['is_required'] ) ? 'required' : '';

		switch ( $type ) {
			case 'textarea':
				?>
<textarea 
id="item_<?php echo esc_attr( $field_name ); ?>"
name="item_data[<?php echo esc_attr( $field_name ); ?>]"
rows="5"
class="large-text"
				<?php echo esc_attr( $required ); ?>
><?php echo esc_textarea( $value ); ?></textarea>
				<?php
				break;

			case 'number':
				?>
<input 
type="number"
id="item_<?php echo esc_attr( $field_name ); ?>"
name="item_data[<?php echo esc_attr( $field_name ); ?>]"
value="<?php echo esc_attr( $value ); ?>"
class="regular-text"
step="0.01"
				<?php echo esc_attr( $required ); ?>
>
				<?php
				break;

			case 'checkbox':
				?>
<label>
<input 
type="checkbox"
id="item_<?php echo esc_attr( $field_name ); ?>"
name="item_data[<?php echo esc_attr( $field_name ); ?>]"
value="1"
				<?php checked( $value, 1 ); ?>
>
				<?php esc_html_e( 'Yes', 'nvdigital-open-operator-system-oos-pro' ); ?>
</label>
				<?php
				break;

			case 'select':
				$options = array();
				if ( 'category_type' === $field_name ) {
					$options = array(
						''        => __( 'Select Type', 'nvdigital-open-operator-system-oos-pro' ),
						'income'  => __( 'Income', 'nvdigital-open-operator-system-oos-pro' ),
						'expense' => __( 'Expense', 'nvdigital-open-operator-system-oos-pro' ),
						'savings' => __( 'Savings', 'nvdigital-open-operator-system-oos-pro' ),
						'debt'    => __( 'Debt', 'nvdigital-open-operator-system-oos-pro' ),
					);
				} elseif ( 'frequency' === $field_name ) {
					$options = array(
						''          => __( 'Select Frequency', 'nvdigital-open-operator-system-oos-pro' ),
						'daily'     => __( 'Daily', 'nvdigital-open-operator-system-oos-pro' ),
						'weekly'    => __( 'Weekly', 'nvdigital-open-operator-system-oos-pro' ),
						'biweekly'  => __( 'Bi-weekly', 'nvdigital-open-operator-system-oos-pro' ),
						'monthly'   => __( 'Monthly', 'nvdigital-open-operator-system-oos-pro' ),
						'quarterly' => __( 'Quarterly', 'nvdigital-open-operator-system-oos-pro' ),
						'yearly'    => __( 'Yearly', 'nvdigital-open-operator-system-oos-pro' ),
					);
				} elseif ( 'goal_type' === $field_name ) {
					$options = array(
						''           => __( 'Select Goal Type', 'nvdigital-open-operator-system-oos-pro' ),
						'retirement' => __( 'Retirement', 'nvdigital-open-operator-system-oos-pro' ),
						'emergency'  => __( 'Emergency Fund', 'nvdigital-open-operator-system-oos-pro' ),
						'home'       => __( 'Home Purchase', 'nvdigital-open-operator-system-oos-pro' ),
						'education'  => __( 'Education', 'nvdigital-open-operator-system-oos-pro' ),
						'debt'       => __( 'Debt Payoff', 'nvdigital-open-operator-system-oos-pro' ),
						'investment' => __( 'Investment', 'nvdigital-open-operator-system-oos-pro' ),
						'other'      => __( 'Other', 'nvdigital-open-operator-system-oos-pro' ),
					);
				} elseif ( 'priority' === $field_name ) {
					$options = array(
						''       => __( 'Select Priority', 'nvdigital-open-operator-system-oos-pro' ),
						'high'   => __( 'High', 'nvdigital-open-operator-system-oos-pro' ),
						'medium' => __( 'Medium', 'nvdigital-open-operator-system-oos-pro' ),
						'low'    => __( 'Low', 'nvdigital-open-operator-system-oos-pro' ),
					);
				}

				?>
<select 
id="item_<?php echo esc_attr( $field_name ); ?>"
name="item_data[<?php echo esc_attr( $field_name ); ?>]"
class="regular-text"
				<?php echo esc_attr( $required ); ?>
>
				<?php foreach ( $options as $opt_value => $opt_label ) : ?>
<option value="<?php echo esc_attr( $opt_value ); ?>" <?php selected( $value, $opt_value ); ?>>
					<?php echo esc_html( $opt_label ); ?>
</option>
<?php endforeach; ?>
</select>
				<?php
				break;

			default: // text.
				?>
<input 
type="text"
id="item_<?php echo esc_attr( $field_name ); ?>"
name="item_data[<?php echo esc_attr( $field_name ); ?>]"
value="<?php echo esc_attr( $value ); ?>"
class="regular-text"
				<?php echo esc_attr( $required ); ?>
>
				<?php
				break;
		}
	}

	/**
	 * Render table headers for current entity.
	 */
	protected function render_table_headers() {
		switch ( $this->current_entity ) {
			case 'budget_categories':
				?>
<th><?php esc_html_e( 'ID', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Category Name', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Type', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Amount', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Frequency', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Actions', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<?php
				break;

			case 'goal_templates':
				?>
<th><?php esc_html_e( 'ID', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Goal Name', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Type', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Target Amount', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Priority', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
<th><?php esc_html_e( 'Actions', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<?php
				break;

			default:
				parent::render_table_headers();
		}
	}

	/**
	 * Render table row for current entity.
	 *
	 * @param array $item Item data.
	 */
	protected function render_table_row( $item ) {
		$edit_url   = add_query_arg(
			array(
				'action' => 'edit',
				'id'     => $item['id'],
			)
		);
		$delete_url = wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'delete',
					'id'     => $item['id'],
				)
			),
			'delete_item_' . $item['id']
		);

		switch ( $this->current_entity ) {
			case 'budget_categories':
				?>
<td><?php echo esc_html( $item['id'] ); ?></td>
<td><?php echo esc_html( $item['category_name'] ?? __( '(No name)', 'nvdigital-open-operator-system-oos-pro' ) ); ?></td>
<td><?php echo esc_html( ucfirst( $item['category_type'] ?? '-' ) ); ?></td>
<td><?php echo esc_html( isset( $item['amount'] ) ? '$' . number_format( (float) $item['amount'], 2 ) : '-' ); ?></td>
<td><?php echo esc_html( ucfirst( $item['frequency'] ?? '-' ) ); ?></td>
<td class="item-actions">
<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
<a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure?', 'nvdigital-open-operator-system-oos-pro' ); ?>');"><?php esc_html_e( 'Delete', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
</td>
				<?php
				break;

			case 'goal_templates':
				?>
<td><?php echo esc_html( $item['id'] ); ?></td>
<td><?php echo esc_html( $item['goal_name'] ?? __( '(No name)', 'nvdigital-open-operator-system-oos-pro' ) ); ?></td>
<td><?php echo esc_html( ucfirst( $item['goal_type'] ?? '-' ) ); ?></td>
<td><?php echo esc_html( isset( $item['target_amount'] ) ? '$' . number_format( (float) $item['target_amount'], 2 ) : '-' ); ?></td>
<td><?php echo esc_html( ucfirst( $item['priority'] ?? '-' ) ); ?></td>
<td class="item-actions">
<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
<a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure?', 'nvdigital-open-operator-system-oos-pro' ); ?>');"><?php esc_html_e( 'Delete', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
</td>
				<?php
				break;

			default:
				parent::render_table_row( $item );
		}
	}
}
