<?php
/**
 * Project Management Toolkit Research & Add
 *
 * Research & Add implementation for Project Management toolkit.
 * Manages Projects, Tasks, and Milestones entities.
 *
 * @package WP_MCP_AI_Pro
 * @since 2.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-research-add-base.php';

/**
 * Project Management Research & Add implementation.
 */
class WP_MCP_AI_Project_Management_Research_Add extends WP_MCP_AI_Research_Add_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct( 'project_management' );

		// Register field schemas.
		add_filter( 'wp_mcp_ai_toolkit_cpt_field_schema', array( $this, 'filter_cpt_field_schema' ), 10, 3 );
		add_filter( 'wp_mcp_ai_toolkit_cct_field_schema', array( $this, 'filter_cct_field_schema' ), 10, 3 );
	}

	/**
	 * Get entity types for project management toolkit.
	 *
	 * @return array Entity types.
	 */
	protected function get_entity_types() {
		return array(
			'projects'   => __( 'Projects', 'nvdigital-open-operator-system-oos-pro' ),
			'tasks'      => __( 'Tasks', 'nvdigital-open-operator-system-oos-pro' ),
			'milestones' => __( 'Milestones', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Filter CPT field schema.
	 *
	 * @param array  $schema       Field schema.
	 * @param string $toolkit_slug Toolkit slug.
	 * @param string $entity_type  Entity type.
	 * @return array Filtered schema.
	 */
	public function filter_cpt_field_schema( $schema, $toolkit_slug, $entity_type ) {
		if ( 'project_management' !== $toolkit_slug ) {
			return $schema;
		}

		switch ( $entity_type ) {
			case 'projects':
				return $this->get_projects_schema();
			case 'tasks':
				return $this->get_tasks_schema();
			case 'milestones':
				return $this->get_milestones_schema();
		}

		return $schema;
	}

	/**
	 * Filter CCT field schema.
	 *
	 * @param array  $schema       Field schema.
	 * @param string $toolkit_slug Toolkit slug.
	 * @param string $entity_type  Entity type.
	 * @return array Filtered schema.
	 */
	public function filter_cct_field_schema( $schema, $toolkit_slug, $entity_type ) {
		// Use same schema for both CPT and CCT.
		return $this->filter_cpt_field_schema( $schema, $toolkit_slug, $entity_type );
	}

	/**
	 * Get projects field schema.
	 *
	 * @return array Field definitions.
	 */
	private function get_projects_schema() {
		return array(
			'project_name'         => array(
				'title'       => __( 'Project Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '100%',
				'is_required' => true,
			),
			'description'          => array(
				'title' => __( 'Description', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'client_name'          => array(
				'title' => __( 'Client Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'project_manager'      => array(
				'title' => __( 'Project Manager', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'start_date'           => array(
				'title' => __( 'Start Date', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'end_date'             => array(
				'title' => __( 'End Date', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'budget'               => array(
				'title' => __( 'Budget', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'priority'             => array(
				'title' => __( 'Priority', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'select',
				'width' => '50%',
			),
			'status'               => array(
				'title' => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'select',
				'width' => '50%',
			),
			'progress'             => array(
				'title' => __( 'Progress (%)', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'created_by_assistant' => array(
				'title' => __( 'Created by Assistant', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
		);
	}

	/**
	 * Get tasks field schema.
	 *
	 * @return array Field definitions.
	 */
	private function get_tasks_schema() {
		return array(
			'task_name'            => array(
				'title'       => __( 'Task Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '100%',
				'is_required' => true,
			),
			'description'          => array(
				'title' => __( 'Description', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'project_id'           => array(
				'title' => __( 'Project ID', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'assigned_to'          => array(
				'title' => __( 'Assigned To', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'priority'             => array(
				'title' => __( 'Priority', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'select',
				'width' => '50%',
			),
			'status'               => array(
				'title' => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'select',
				'width' => '50%',
			),
			'due_date'             => array(
				'title' => __( 'Due Date', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'estimated_hours'      => array(
				'title' => __( 'Estimated Hours', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'actual_hours'         => array(
				'title' => __( 'Actual Hours', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'dependencies'         => array(
				'title' => __( 'Dependencies (Task IDs)', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '100%',
			),
			'created_by_assistant' => array(
				'title' => __( 'Created by Assistant', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
		);
	}

	/**
	 * Get milestones field schema.
	 *
	 * @return array Field definitions.
	 */
	private function get_milestones_schema() {
		return array(
			'milestone_name'       => array(
				'title'       => __( 'Milestone Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '100%',
				'is_required' => true,
			),
			'description'          => array(
				'title' => __( 'Description', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'project_id'           => array(
				'title' => __( 'Project ID', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'due_date'             => array(
				'title' => __( 'Due Date', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'status'               => array(
				'title' => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'select',
				'width' => '50%',
			),
			'completion_date'      => array(
				'title' => __( 'Completion Date', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'deliverables'         => array(
				'title' => __( 'Deliverables', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'created_by_assistant' => array(
				'title' => __( 'Created by Assistant', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
		);
	}

	/**
	 * Render table headers for current entity.
	 */
	protected function render_table_headers() {
		switch ( $this->current_entity ) {
			case 'projects':
				?>
				<th><?php esc_html_e( 'ID', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Project Name', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Client', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Progress', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<?php
				break;

			case 'tasks':
				?>
				<th><?php esc_html_e( 'ID', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Task Name', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Assigned To', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Priority', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<?php
				break;

			case 'milestones':
				?>
				<th><?php esc_html_e( 'ID', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Milestone Name', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Due Date', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Status', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
				<?php
				break;

			default:
				parent::render_table_headers();
		}
	}

	/**
	 * Render table row for current entity.
	 *
	 * @param array $item Item data.
	 */
	protected function render_table_row( $item ) {
		$edit_url   = add_query_arg(
			array(
				'action' => 'edit',
				'id'     => $item['id'],
			)
		);
		$delete_url = wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'delete',
					'id'     => $item['id'],
				)
			),
			'delete_item_' . $item['id']
		);

		switch ( $this->current_entity ) {
			case 'projects':
				?>
				<td><?php echo esc_html( $item['id'] ); ?></td>
				<td><?php echo esc_html( $item['project_name'] ?? __( '(No name)', 'nvdigital-open-operator-system-oos-pro' ) ); ?></td>
				<td><?php echo esc_html( $item['client_name'] ?? '-' ); ?></td>
				<td><?php echo esc_html( $item['status'] ?? 'Planning' ); ?></td>
				<td><?php echo esc_html( ( $item['progress'] ?? 0 ) . '%' ); ?></td>
				<td class="item-actions">
					<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
					<a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure?', 'nvdigital-open-operator-system-oos-pro' ); ?>');"><?php esc_html_e( 'Delete', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
				</td>
				<?php
				break;

			case 'tasks':
				?>
				<td><?php echo esc_html( $item['id'] ); ?></td>
				<td><?php echo esc_html( $item['task_name'] ?? __( '(No name)', 'nvdigital-open-operator-system-oos-pro' ) ); ?></td>
				<td><?php echo esc_html( $item['assigned_to'] ?? 'Unassigned' ); ?></td>
				<td><?php echo esc_html( $item['priority'] ?? 'Medium' ); ?></td>
				<td><?php echo esc_html( $item['status'] ?? 'To Do' ); ?></td>
				<td class="item-actions">
					<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
					<a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure?', 'nvdigital-open-operator-system-oos-pro' ); ?>');"><?php esc_html_e( 'Delete', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
				</td>
				<?php
				break;

			case 'milestones':
				?>
				<td><?php echo esc_html( $item['id'] ); ?></td>
				<td><?php echo esc_html( $item['milestone_name'] ?? __( '(No name)', 'nvdigital-open-operator-system-oos-pro' ) ); ?></td>
				<td><?php echo esc_html( $item['due_date'] ?? '-' ); ?></td>
				<td><?php echo esc_html( $item['status'] ?? 'Pending' ); ?></td>
				<td class="item-actions">
					<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
					<a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure?', 'nvdigital-open-operator-system-oos-pro' ); ?>');"><?php esc_html_e( 'Delete', 'nvdigital-open-operator-system-oos-pro' ); ?></a>
				</td>
				<?php
				break;

			default:
				parent::render_table_row( $item );
		}
	}
}
