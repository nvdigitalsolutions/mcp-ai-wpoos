<?php
/**
 * CRM & Email Marketing Toolkit Research & Add
 *
 * Research & Add implementation for CRM toolkit.
 * Manages Contacts, Campaigns, and Leads entities with CCT/CPT storage.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-research-add-base.php';

/**
 * CRM Research & Add implementation.
 */
class WP_MCP_AI_CRM_Research_Add extends WP_MCP_AI_Research_Add_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct( 'crm' );

		// Register field schemas.
		add_filter( 'wp_mcp_ai_toolkit_cpt_field_schema', array( $this, 'filter_cpt_field_schema' ), 10, 3 );
		add_filter( 'wp_mcp_ai_toolkit_cct_field_schema', array( $this, 'filter_cct_field_schema' ), 10, 3 );
	}

	/**
	 * Get entity types for CRM toolkit.
	 *
	 * @return array Entity types.
	 */
	protected function get_entity_types() {
		return array(
			'contacts'  => __( 'Contacts', 'nvdigital-open-operator-system-oos-pro' ),
			'companies' => __( 'Companies', 'nvdigital-open-operator-system-oos-pro' ),
			'campaigns' => __( 'Email Campaigns', 'nvdigital-open-operator-system-oos-pro' ),
			'leads'     => __( 'Leads', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Filter CPT field schema.
	 *
	 * @param array  $schema       Field schema.
	 * @param string $toolkit_slug Toolkit slug.
	 * @param string $entity_type  Entity type.
	 * @return array Filtered schema.
	 */
	public function filter_cpt_field_schema( $schema, $toolkit_slug, $entity_type ) {
		if ( 'crm' !== $toolkit_slug ) {
			return $schema;
		}

		switch ( $entity_type ) {
			case 'contacts':
				return $this->get_contacts_schema();
			case 'companies':
				return $this->get_companies_schema();
			case 'campaigns':
				return $this->get_campaigns_schema();
			case 'leads':
				return $this->get_leads_schema();
		}

		return $schema;
	}

	/**
	 * Filter CCT field schema.
	 *
	 * @param array  $schema       Field schema.
	 * @param string $toolkit_slug Toolkit slug.
	 * @param string $entity_type  Entity type.
	 * @return array Filtered schema.
	 */
	public function filter_cct_field_schema( $schema, $toolkit_slug, $entity_type ) {
		// Use same schema for both CPT and CCT.
		return $this->filter_cpt_field_schema( $schema, $toolkit_slug, $entity_type );
	}

	/**
	 * Get contacts field schema.
	 *
	 * @return array Field definitions.
	 */
	private function get_contacts_schema() {
		return array(
			'first_name'       => array(
				'title'       => __( 'First Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '50%',
				'is_required' => true,
			),
			'last_name'        => array(
				'title'       => __( 'Last Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '50%',
				'is_required' => true,
			),
			'email'            => array(
				'title'       => __( 'Email Address', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '50%',
				'is_required' => true,
			),
			'phone'            => array(
				'title' => __( 'Phone Number', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'company'          => array(
				'title' => __( 'Company', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'job_title'        => array(
				'title' => __( 'Job Title', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'address'          => array(
				'title' => __( 'Address', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'city'             => array(
				'title' => __( 'City', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '33%',
			),
			'state'            => array(
				'title' => __( 'State/Province', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '33%',
			),
			'zip'              => array(
				'title' => __( 'ZIP/Postal Code', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '34%',
			),
			'country'          => array(
				'title' => __( 'Country', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'website'          => array(
				'title' => __( 'Website', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'lead_score'       => array(
				'title' => __( 'Lead Score', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'lead_status'      => array(
				'title'   => __( 'Lead Status', 'nvdigital-open-operator-system-oos-pro' ),
				'type'    => 'select',
				'width'   => '50%',
				'options' => array(
					array(
						'key'   => 'new',
						'value' => __( 'New', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'contacted',
						'value' => __( 'Contacted', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'qualified',
						'value' => __( 'Qualified', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'converted',
						'value' => __( 'Converted', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'lost',
						'value' => __( 'Lost', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
			),
			'email_subscribed' => array(
				'title' => __( 'Email Subscribed', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'switcher',
				'width' => '50%',
			),
			'tags'             => array(
				'title' => __( 'Tags', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '100%',
			),
			'notes'            => array(
				'title' => __( 'Notes', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
		);
	}

	/**
	 * Get companies field schema.
	 *
	 * @return array Field definitions.
	 */
	private function get_companies_schema() {
		return array(
			'company_name'  => array(
				'title'       => __( 'Company Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '100%',
				'is_required' => true,
			),
			'industry'      => array(
				'title'       => __( 'Industry', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '50%',
				'is_required' => true,
			),
			'company_size'  => array(
				'title'   => __( 'Company Size', 'nvdigital-open-operator-system-oos-pro' ),
				'type'    => 'select',
				'width'   => '50%',
				'options' => array(
					array(
						'key'   => '1-10',
						'value' => __( '1-10 employees', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => '11-50',
						'value' => __( '11-50 employees', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => '51-200',
						'value' => __( '51-200 employees', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => '201-500',
						'value' => __( '201-500 employees', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => '501-1000',
						'value' => __( '501-1,000 employees', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => '1001-5000',
						'value' => __( '1,001-5,000 employees', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => '5001+',
						'value' => __( '5,001+ employees', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
			),
			'website'       => array(
				'title' => __( 'Website', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '100%',
			),
			'address'       => array(
				'title' => __( 'Address', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'city'          => array(
				'title' => __( 'City', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '33%',
			),
			'state'         => array(
				'title' => __( 'State/Province', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '33%',
			),
			'zip'           => array(
				'title' => __( 'ZIP/Postal Code', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '34%',
			),
			'country'       => array(
				'title' => __( 'Country', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'phone'         => array(
				'title' => __( 'Phone Number', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'revenue'       => array(
				'title' => __( 'Annual Revenue', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '50%',
			),
			'target_status' => array(
				'title'   => __( 'Target Status', 'nvdigital-open-operator-system-oos-pro' ),
				'type'    => 'select',
				'width'   => '50%',
				'options' => array(
					array(
						'key'   => 'prospect',
						'value' => __( 'Prospect', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'target',
						'value' => __( 'Target', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'in_discussion',
						'value' => __( 'In Discussion', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'client',
						'value' => __( 'Client', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'not_interested',
						'value' => __( 'Not Interested', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
			),
			'linkedin'      => array(
				'title' => __( 'LinkedIn URL', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'twitter'       => array(
				'title' => __( 'Twitter/X Handle', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'description'   => array(
				'title' => __( 'Company Description', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
			'tags'          => array(
				'title' => __( 'Tags', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '100%',
			),
			'notes'         => array(
				'title' => __( 'Research Notes', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
		);
	}

	/**
	 * Get campaigns field schema.
	 *
	 * @return array Field definitions.
	 */
	private function get_campaigns_schema() {
		return array(
			'campaign_name'    => array(
				'title'       => __( 'Campaign Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '100%',
				'is_required' => true,
			),
			'subject_line'     => array(
				'title'       => __( 'Subject Line', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '100%',
				'is_required' => true,
			),
			'preview_text'     => array(
				'title' => __( 'Preview Text', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '100%',
			),
			'campaign_type'    => array(
				'title'   => __( 'Campaign Type', 'nvdigital-open-operator-system-oos-pro' ),
				'type'    => 'select',
				'width'   => '50%',
				'options' => array(
					array(
						'key'   => 'newsletter',
						'value' => __( 'Newsletter', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'promotional',
						'value' => __( 'Promotional', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'transactional',
						'value' => __( 'Transactional', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'drip',
						'value' => __( 'Drip Campaign', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
			),
			'status'           => array(
				'title'   => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
				'type'    => 'select',
				'width'   => '50%',
				'options' => array(
					array(
						'key'   => 'draft',
						'value' => __( 'Draft', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'scheduled',
						'value' => __( 'Scheduled', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'sending',
						'value' => __( 'Sending', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'sent',
						'value' => __( 'Sent', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'paused',
						'value' => __( 'Paused', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
			),
			'send_date'        => array(
				'title' => __( 'Send Date', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'datetime-local',
				'width' => '50%',
			),
			'total_sent'       => array(
				'title' => __( 'Total Sent', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '25%',
			),
			'open_rate'        => array(
				'title' => __( 'Open Rate (%)', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '25%',
			),
			'click_rate'       => array(
				'title' => __( 'Click Rate (%)', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '25%',
			),
			'unsubscribe_rate' => array(
				'title' => __( 'Unsubscribe Rate (%)', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '25%',
			),
			'segment'          => array(
				'title' => __( 'Target Segment', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '100%',
			),
		);
	}

	/**
	 * Get leads field schema.
	 *
	 * @return array Field definitions.
	 */
	private function get_leads_schema() {
		return array(
			'lead_name'   => array(
				'title'       => __( 'Lead Name', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '100%',
				'is_required' => true,
			),
			'email'       => array(
				'title'       => __( 'Email Address', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'text',
				'width'       => '50%',
				'is_required' => true,
			),
			'phone'       => array(
				'title' => __( 'Phone Number', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'company'     => array(
				'title' => __( 'Company', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'source'      => array(
				'title'   => __( 'Lead Source', 'nvdigital-open-operator-system-oos-pro' ),
				'type'    => 'select',
				'width'   => '50%',
				'options' => array(
					array(
						'key'   => 'website',
						'value' => __( 'Website', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'referral',
						'value' => __( 'Referral', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'social_media',
						'value' => __( 'Social Media', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'email_campaign',
						'value' => __( 'Email Campaign', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'paid_ad',
						'value' => __( 'Paid Ad', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'other',
						'value' => __( 'Other', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
			),
			'score'       => array(
				'title' => __( 'Lead Score', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '33%',
			),
			'status'      => array(
				'title'   => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
				'type'    => 'select',
				'width'   => '34%',
				'options' => array(
					array(
						'key'   => 'new',
						'value' => __( 'New', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'contacted',
						'value' => __( 'Contacted', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'qualified',
						'value' => __( 'Qualified', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'nurturing',
						'value' => __( 'Nurturing', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'converted',
						'value' => __( 'Converted', 'nvdigital-open-operator-system-oos-pro' ),
					),
					array(
						'key'   => 'lost',
						'value' => __( 'Lost', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
			),
			'value'       => array(
				'title' => __( 'Estimated Value', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'number',
				'width' => '33%',
			),
			'assigned_to' => array(
				'title' => __( 'Assigned To', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'next_action' => array(
				'title' => __( 'Next Action', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'text',
				'width' => '50%',
			),
			'notes'       => array(
				'title' => __( 'Notes', 'nvdigital-open-operator-system-oos-pro' ),
				'type'  => 'textarea',
				'width' => '100%',
			),
		);
	}
}
