<?php
/**
 * Trait for WordPress-native AI tools with enhanced WordPress integration.
 *
 * Provides common functionality for tools that deeply integrate with
 * WordPress core features like hooks, caching, privacy, and performance.
 *
 * @package WP_MCP_AI
 * @since 1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WordPress Native Tool Trait
 *
 * Adds WordPress-specific helper methods to tools for:
 * - Hook integration and registration
 * - Intelligent caching with cache groups
 * - Privacy compliance (GDPR)
 * - Performance tracking
 * - Background processing
 *
 * @since 1.0.0
 */
trait WP_MCP_AI_Tool_WordPress_Native {

	/**
	 * Register WordPress hooks for this tool.
	 *
	 * Override this method to register action/filter hooks
	 * that enable automatic tool execution on WordPress events.
	 *
	 * Example: Register save_post hook for auto-categorization.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function register_hooks() {
		// Override in child class to register hooks.
	}

	/**
	 * Get cached result with tool-specific cache key.
	 *
	 * Uses WordPress transient API with automatic cache key generation
	 * based on tool slug and arguments.
	 *
	 * @since 1.0.0
	 *
	 * @param array $arguments Tool arguments used to generate cache key.
	 * @return mixed|false Cached value or false if not found.
	 */
	protected function get_cached_result( $arguments ) {
		$cache_key = $this->generate_cache_key( $arguments );
		return WP_MCP_AI_Cache_Helper::get( $cache_key );
	}

	/**
	 * Set cached result with tool-specific cache key.
	 *
	 * @since 1.0.0
	 *
	 * @param array $arguments  Tool arguments used to generate cache key.
	 * @param mixed $value      Value to cache.
	 * @param int   $expiration Cache expiration in seconds (default: 1 hour).
	 * @return bool True on success, false on failure.
	 */
	protected function set_cached_result( $arguments, $value, $expiration = HOUR_IN_SECONDS ) {
		$cache_key = $this->generate_cache_key( $arguments );
		return WP_MCP_AI_Cache_Helper::set( $cache_key, $value, $expiration );
	}

	/**
	 * Invalidate cached results for this tool.
	 *
	 * @since 1.0.0
	 *
	 * @param array|null $arguments Optional. Specific arguments to invalidate.
	 *                              If null, invalidates all caches for this tool.
	 * @return bool True on success, false on failure.
	 */
	protected function invalidate_cache( $arguments = null ) {
		if ( null === $arguments ) {
			// Invalidate all caches for this tool.
			return WP_MCP_AI_Cache_Helper::delete_group( 'tool_' . $this->get_slug() );
		}

		$cache_key = $this->generate_cache_key( $arguments );
		return WP_MCP_AI_Cache_Helper::delete( $cache_key );
	}

	/**
	 * Generate cache key from tool slug and arguments.
	 *
	 * @since 1.0.0
	 *
	 * @param array $arguments Tool arguments.
	 * @return string Cache key.
	 */
	protected function generate_cache_key( $arguments ) {
		$args_hash = md5( wp_json_encode( $arguments ) );
		return 'tool_' . $this->get_slug() . '_' . $args_hash;
	}

	/**
	 * Check if this tool should be cached.
	 *
	 * Override this method to control caching behavior.
	 * Default: cache if tool has 'cacheable' capability flag.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if results should be cached.
	 */
	protected function should_cache() {
		if ( ! $this instanceof WP_MCP_AI_Tool_Capability_Flags_Interface ) {
			return false;
		}

		$flags = $this->get_capability_flags();
		return in_array( 'cacheable', $flags, true );
	}

	/**
	 * Apply WordPress filters to tool result.
	 *
	 * Allows developers to modify tool results via filter hooks.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $result    Tool execution result.
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return mixed Filtered result.
	 */
	protected function apply_result_filter( $result, $arguments, $context ) {
		/**
		 * Filter tool execution result.
		 *
		 * Allows developers to modify the result of any tool execution.
		 *
		 * @since 1.0.0
		 *
		 * @param mixed  $result    Tool execution result.
		 * @param array  $arguments Tool arguments.
		 * @param array  $context   Execution context.
		 * @param string $tool_slug Tool slug identifier.
		 */
		$result = apply_filters( 'wp_mcp_ai_tool_result', $result, $arguments, $context, $this->get_slug() );

		/**
		 * Filter specific tool execution result.
		 *
		 * Dynamic hook name includes the tool slug for targeted filtering.
		 *
		 * @since 1.0.0
		 *
		 * @param mixed $result    Tool execution result.
		 * @param array $arguments Tool arguments.
		 * @param array $context   Execution context.
		 */
		return apply_filters( "wp_mcp_ai_tool_result_{$this->get_slug()}", $result, $arguments, $context );
	}

	/**
	 * Fire WordPress action before tool execution.
	 *
	 * Allows developers to hook into tool execution lifecycle. Filter callbacks
	 * may return a non-null value to intercept and replace the tool's normal
	 * execution. The dynamic per-tool action is preserved for side-effect
	 * listeners (logging, metrics) that do not need to intercept.
	 *
	 * @since 1.0.0
	 * @since 1.2.0 Returns intercepted result when a filter callback short-circuits execution.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return mixed|null Null to continue normal execution, or an intercepted result.
	 */
	protected function do_before_execute( $arguments, $context ) {
		/**
		 * Filter before any tool execution.
		 *
		 * Return a non-null value to intercept and skip the normal execute()
		 * call. The returned value is passed directly to the caller as the
		 * tool result.
		 *
		 * @since 1.0.0
		 * @since 1.2.0 First parameter changed to `$pre` (was `$arguments`);
		 *              `$tool_slug` moved to second position; `$arguments`
		 *              moved to third; `$context` added as fourth.
		 *
		 * @param mixed  $pre       Null to continue, or an intercepted result.
		 * @param string $tool_slug Tool slug identifier.
		 * @param array  $arguments Tool arguments.
		 * @param array  $context   Execution context.
		 */
		$pre = apply_filters(
			'wp_mcp_ai_before_tool_execute',
			null,
			$this->get_slug(),
			$arguments,
			$context
		);

		if ( null !== $pre ) {
			return $pre;
		}

		/**
		 * Fires before specific tool execution.
		 *
		 * Dynamic hook name includes the tool slug. Use this for side-effect
		 * listeners (logging, metrics, caching) that do not need to intercept
		 * execution. For interception, use the filter above.
		 *
		 * @since 1.0.0
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Execution context.
		 */
		do_action( "wp_mcp_ai_before_tool_execute_{$this->get_slug()}", $arguments, $context );

		return null;
	}

	/**
	 * Fire WordPress action after tool execution.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $result    Tool execution result.
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return void
	 */
	protected function do_after_execute( $result, $arguments, $context ) {
		/**
		 * Fires after any tool execution.
		 *
		 * @since 1.0.0
		 *
		 * @param mixed  $result    Tool execution result.
		 * @param array  $arguments Tool arguments.
		 * @param array  $context   Execution context.
		 * @param string $tool_slug Tool slug identifier.
		 */
		do_action( 'wp_mcp_ai_after_tool_execute', $result, $arguments, $context, $this->get_slug() );

		/**
		 * Fires after specific tool execution.
		 *
		 * @since 1.0.0
		 *
		 * @param mixed $result    Tool execution result.
		 * @param array $arguments Tool arguments.
		 * @param array $context   Execution context.
		 */
		do_action( "wp_mcp_ai_after_tool_execute_{$this->get_slug()}", $result, $arguments, $context );
	}

	/**
	 * Check if tool should export data for privacy request.
	 *
	 * Override this method to indicate whether the tool stores
	 * user-specific data that should be included in privacy exports.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if tool handles exportable user data.
	 */
	protected function has_privacy_data() {
		return false;
	}

	/**
	 * Export privacy data for user.
	 *
	 * Override this method to provide data for GDPR export requests.
	 * The base implementation returns empty data as child classes
	 * should override this to export their specific user data.
	 *
	 * @since 1.0.0
	 *
	 * @param int $user_id User ID for data export - used by child class implementations.
	 * @return array Privacy export data.
	 */
	protected function export_privacy_data( $user_id ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Base template method; child classes use this parameter for filtering.
		return array();
	}

	/**
	 * Erase privacy data for user.
	 *
	 * Override this method to handle GDPR erasure requests.
	 * The base implementation returns no items removed as child classes
	 * should override this to erase their specific user data.
	 *
	 * @since 1.0.0
	 *
	 * @param int $user_id User ID for data erasure - used by child class implementations.
	 * @return array Erasure result with 'items_removed', 'items_retained', 'messages'.
	 */
	protected function erase_privacy_data( $user_id ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Base template method; child classes use this parameter for filtering.
		return array(
			'items_removed'  => 0,
			'items_retained' => 0,
			'messages'       => array(),
		);
	}

	/**
	 * Schedule background task for tool execution.
	 *
	 * Uses WordPress cron system for long-running operations.
	 *
	 * @since 1.0.0
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	protected function schedule_background_task( $arguments, $context ) {
		if ( ! function_exists( 'as_schedule_single_action' ) && ! class_exists( 'WP_MCP_AI_Cron_Manager' ) ) {
			return new WP_Error(
				'background_task_unavailable',
				__( 'Background task scheduling is not available.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$hook = 'wp_mcp_ai_background_tool_' . $this->get_slug();

		// Try Action Scheduler first (if available).
		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action(
				time(),
				$hook,
				array(
					'arguments' => $arguments,
					'context'   => $context,
				)
			);
			return true;
		}

		// Fallback to WordPress cron.
		if ( ! wp_next_scheduled( $hook, array( $arguments, $context ) ) ) {
			wp_schedule_single_event(
				time(),
				$hook,
				array(
					'arguments' => $arguments,
					'context'   => $context,
				)
			);

			// Register in Cron Manager so the job is visible and monitorable.
			// user_id may be 0 for unattributed/system-initiated jobs; record_job
			// accepts 0 (shows the job without user attribution in the UI).
			if ( class_exists( 'WP_MCP_AI_Cron_Manager' ) ) {
				$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();
				WP_MCP_AI_Cron_Manager::record_job(
					$hook,
					array( $this->get_slug() ),
					'single',
					time(),
					$user_id
				);
			}
		}

		return true;
	}

	/**
	 * Log tool execution for monitoring.
	 *
	 * @since 1.0.0
	 *
	 * @param string $level   Log level (info, warning, error).
	 * @param string $message Log message.
	 * @param array  $context Additional context data.
	 * @return void
	 */
	protected function log( $level, $message, $context = array() ) {
		if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
			$context['tool'] = $this->get_slug();
			WP_MCP_AI_Logger::log( $level, $message, $context );
		}
	}

	/**
	 * Track tool performance metrics.
	 *
	 * @since 1.0.0
	 *
	 * @param float $start_time Execution start timestamp.
	 * @param array $arguments  Tool arguments.
	 * @return void
	 */
	protected function track_performance( $start_time, $arguments ) {
		$execution_time = microtime( true ) - $start_time;

		/**
		 * Fires when tool execution completes with performance metrics.
		 *
		 * @since 1.0.0
		 *
		 * @param string $tool_slug      Tool slug identifier.
		 * @param float  $execution_time Execution time in seconds.
		 * @param array  $arguments      Tool arguments.
		 */
		do_action( 'wp_mcp_ai_tool_performance', $this->get_slug(), $execution_time, $arguments );

		// Log slow executions.
		if ( $execution_time > 5.0 ) {
			$this->log(
				'warning',
				sprintf(
					/* translators: %1$s: tool slug, %2$s: execution time */
					__( 'Slow tool execution: %1$s took %2$s seconds', 'nvdigital-open-operator-system-oos' ),
					$this->get_slug(),
					number_format( $execution_time, 2 )
				),
				array(
					'execution_time' => $execution_time,
					'arguments'      => $arguments,
				)
			);
		}
	}
}
