<?php
/**
 * Document Generation Toolkit Initialization
 *
 * Loads the Document Generation Toolkit system for PDF, Word, and Excel
 * document generation with professional styling and branding.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Check if Document Generation toolkit is enabled.
$settings   = get_option( 'wp_mcp_ai_settings', array() );
$is_enabled = ! empty( $settings['enable_document_generation_toolkit'] );
$is_base    = function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version();

// Only load if enabled and not in base version.
if ( $is_enabled && ! $is_base ) {

	// Load Document Generation admin pages.
	if ( is_admin() ) {
		require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-document-generation-settings-page.php';
	}

	// Register tools will be loaded automatically via the tools directory structure.
	// Tools are located in: addons/pro/includes/tools/document-generation/.
}

/**
 * Enqueue document generation toolkit admin styles.
 *
 * @param string $hook Current admin page hook.
 */
function wp_mcp_ai_enqueue_document_generation_toolkit_admin_styles( $hook ) {
	// Only load if toolkit is enabled.
	$settings = get_option( 'wp_mcp_ai_settings', array() );
	if ( empty( $settings['enable_document_generation_toolkit'] ) ) {
		return;
	}

	// Check if we're on the toolkit settings page.
	$screen = get_current_screen();
	if ( ! $screen || 'nvoos-pro-dashboard_page_wp-mcp-ai-document-generation-toolkit-settings' !== $screen->id ) {
		return;
	}

	// Enqueue admin styles if available.
	$css_file = WP_MCP_AI_PRO_PATH . 'assets/css/admin-document-generation-toolkit.css';
	if ( file_exists( $css_file ) ) {
		wp_enqueue_style(
			'wp-mcp-ai-document-generation-toolkit-admin',
			WP_MCP_AI_PRO_URL . 'assets/css/admin-document-generation-toolkit.css',
			array(),
			WP_MCP_AI_PRO_VERSION
		);
	}
}
add_action( 'admin_enqueue_scripts', 'wp_mcp_ai_enqueue_document_generation_toolkit_admin_styles' );
