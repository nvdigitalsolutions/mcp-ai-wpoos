<?php
/**
 * Multilingual Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * Multilingual Toolkit Settings Page Class
 */
class WP_MCP_AI_Multilingual_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * {@inheritdoc}
	 */
	protected function setting_schema() {
		return array(
			'default_target_language'    => 'select',
			'translation_provider'       => 'select',
			'enable_translation_memory'  => 'boolean',
		);
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'multilingual';
		$this->toolkit_name     = __( 'Multilingual Toolkit', 'nvdigital-open-operator-system-oos-pro' );
		$this->option_name      = 'wp_mcp_ai_multilingual_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-multilingual-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-translation';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'Multilingual Toolkit Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Comprehensive multilingual management toolkit with 10 tools for translation, localization, and global content management.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'AI Translation: Translate content using AI with context preservation', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Translation Memory: Build and leverage translation databases', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Glossary Management: Maintain terminology consistency across languages', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Bulk Operations: Translate multiple posts and detect languages automatically', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Quality Assurance: Validate translations and check localization', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'WPML Integration: Seamless integration with WPML plugin', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Supported Languages', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<p><?php esc_html_e( '100+ languages supported including:', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
			<ul>
				<li><?php esc_html_e( 'European: Spanish, French, German, Italian, Portuguese, Russian', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Asian: Chinese (Simplified & Traditional), Japanese, Korean, Hindi', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Middle Eastern: Arabic, Hebrew, Persian', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		$options = $this->stored_options();
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'Multilingual Toolkit Configuration', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Target Language', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<select name="<?php echo esc_attr( $this->option_name ); ?>[default_target_language]">
							<option value="es" <?php selected( $options['default_target_language'] ?? 'es', 'es' ); ?>><?php esc_html_e( 'Spanish', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
							<option value="fr" <?php selected( $options['default_target_language'] ?? 'es', 'fr' ); ?>><?php esc_html_e( 'French', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
							<option value="de" <?php selected( $options['default_target_language'] ?? 'es', 'de' ); ?>><?php esc_html_e( 'German', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
							<option value="zh" <?php selected( $options['default_target_language'] ?? 'es', 'zh' ); ?>><?php esc_html_e( 'Chinese', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Default language for translations', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Translation Provider', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<select name="<?php echo esc_attr( $this->option_name ); ?>[translation_provider]">
							<option value="openai" <?php selected( $options['translation_provider'] ?? 'openai', 'openai' ); ?>><?php esc_html_e( 'OpenAI GPT-4', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
							<option value="google" <?php selected( $options['translation_provider'] ?? 'openai', 'google' ); ?>><?php esc_html_e( 'Google Translate', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
							<option value="deepl" <?php selected( $options['translation_provider'] ?? 'openai', 'deepl' ); ?>><?php esc_html_e( 'DeepL', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Translation Memory', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( $this->option_name ); ?>[enable_translation_memory]" value="1" <?php checked( $options['enable_translation_memory'] ?? true, 1 ); ?> />
							<?php esc_html_e( 'Store and reuse previous translations', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'translate_content_ai'       => __( 'Translate Content (AI)', 'nvdigital-open-operator-system-oos-pro' ),
			'bulk_translate_posts'       => __( 'Bulk Translate Posts', 'nvdigital-open-operator-system-oos-pro' ),
			'detect_content_language'    => __( 'Detect Content Language', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_translation_memory'  => __( 'Manage Translation Memory', 'nvdigital-open-operator-system-oos-pro' ),
			'sync_language_versions'     => __( 'Sync Language Versions', 'nvdigital-open-operator-system-oos-pro' ),
			'validate_translations'      => __( 'Validate Translations', 'nvdigital-open-operator-system-oos-pro' ),
			'export_translation_package' => __( 'Export Translation Package', 'nvdigital-open-operator-system-oos-pro' ),
			'glossary_management'        => __( 'Glossary Management', 'nvdigital-open-operator-system-oos-pro' ),
			'wpml_integration'           => __( 'WPML Integration', 'nvdigital-open-operator-system-oos-pro' ),
			'localization_checker'       => __( 'Localization Checker', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_Multilingual_Settings_Page();
}
