<?php
/**
 * E-commerce Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * E-commerce Toolkit Settings Page Class
 */
class WP_MCP_AI_Ecommerce_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * {@inheritdoc}
	 */
	protected function setting_schema() {
		return array(
			'default_currency'    => 'text',
			'low_stock_threshold' => 'number',
			'enable_multistore'   => 'boolean',
		);
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'ecommerce';
		$this->toolkit_name     = __( 'E-commerce Toolkit', 'nvdigital-open-operator-system-oos-pro' );
		$this->option_name      = 'wp_mcp_ai_ecommerce_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-ecommerce-toolkit-settings';
		$this->parent_slug      = 'wp-mcp-ai-ecommerce-toolkit'; // Separate E-Commerce Toolkit menu.
		$this->has_research     = false; // Research & Add has dedicated submenu page.
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-cart';

		// Add top-level menu at priority 25 to register before submenu pages.
		// This ensures the parent menu exists when submenu pages are added at priorities 26+.
		add_action( 'admin_menu', array( $this, 'add_top_level_menu' ), 25 );

		parent::__construct();
	}

	/**
	 * Add top-level E-Commerce Toolkit menu.
	 */
	public function add_top_level_menu() {
		// Check if WooCommerce is active.
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		/**
		 * Kill-switch for the wp-admin E-Commerce Toolkit surface
		 * (Proposal 089 Phase 2b). The Complete Console renders the same
		 * toolkit settings through the schema-driven settings surface; flip
		 * this filter off per cohort once console parity is verified.
		 */
		if ( ! apply_filters( 'wp_mcp_ai_admin_page_enabled_ecommerce_toolkit', true ) ) {
			return;
		}

		add_menu_page(
			__( 'E-Commerce Toolkit', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'E-Commerce Toolkit', 'nvdigital-open-operator-system-oos-pro' ),
			'edit_products',
			$this->parent_slug,
			array( $this, 'redirect_to_first_submenu' ),
			$this->icon,
			56 // Position after WooCommerce (55).
		);
	}

	/**
	 * Redirect to first submenu page.
	 *
	 * This prevents the parent menu from showing an empty page.
	 */
	public function redirect_to_first_submenu() {
		// Redirect to settings page (first submenu).
		wp_safe_redirect( admin_url( 'admin.php?page=' . $this->page_slug ) );
		exit;
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'E-commerce Toolkit Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Advanced WooCommerce integration toolkit providing 22 powerful tools for managing products, orders, inventory, and customers.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Product Management: Create, update, import, and export products in bulk', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Order Processing: Process orders, generate invoices, and manage workflows', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Inventory Tracking: Monitor stock levels, forecast demand, and automate alerts', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Customer Management: Segment customers, analyze lifetime value, and export data', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Analytics & Reporting: Sales performance dashboards and order analytics', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Marketing: Abandoned cart recovery, discount campaigns, and upsell recommendations', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Requirements', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<ul>
				<li><strong><?php esc_html_e( 'WooCommerce:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php echo class_exists( 'WooCommerce' ) ? '<span style="color: green;">✓ Active</span>' : '<span style="color: red;">✗ Not Installed</span>'; ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		$options = $this->stored_options();
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'E-commerce Toolkit Configuration', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Currency', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<input type="text" name="<?php echo esc_attr( $this->option_name ); ?>[default_currency]" value="<?php echo esc_attr( $options['default_currency'] ?? 'USD' ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Default currency for pricing and reports', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Low Stock Threshold', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<input type="number" name="<?php echo esc_attr( $this->option_name ); ?>[low_stock_threshold]" value="<?php echo esc_attr( $options['low_stock_threshold'] ?? '5' ); ?>" min="0" class="small-text" />
						<p class="description"><?php esc_html_e( 'Trigger alerts when inventory falls below this level', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Multi-Store Sync', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( $this->option_name ); ?>[enable_multistore]" value="1" <?php checked( $options['enable_multistore'] ?? false, 1 ); ?> />
							<?php esc_html_e( 'Synchronize inventory across multiple stores (requires Remote Sites)', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'create_product_advanced'     => __( 'Create Product (Advanced)', 'nvdigital-open-operator-system-oos-pro' ),
			'bulk_update_products'        => __( 'Bulk Update Products', 'nvdigital-open-operator-system-oos-pro' ),
			'update_woo_product_price'    => __( 'Update Product Price (All Types)', 'nvdigital-open-operator-system-oos-pro' ),
			'update_woo_product_qty'      => __( 'Update Product Quantity (All Types)', 'nvdigital-open-operator-system-oos-pro' ),
			'import_products_csv'         => __( 'Import Products from CSV', 'nvdigital-open-operator-system-oos-pro' ),
			'export_products_report'      => __( 'Export Products Report', 'nvdigital-open-operator-system-oos-pro' ),
			'sync_product_inventory'      => __( 'Sync Product Inventory', 'nvdigital-open-operator-system-oos-pro' ),
			'process_order_workflow'      => __( 'Process Order Workflow', 'nvdigital-open-operator-system-oos-pro' ),
			'bulk_order_status_update'    => __( 'Bulk Order Status Update', 'nvdigital-open-operator-system-oos-pro' ),
			'refund_order_advanced'       => __( 'Refund Order (Advanced)', 'nvdigital-open-operator-system-oos-pro' ),
			'generate_invoice_pdf'        => __( 'Generate Invoice PDF', 'nvdigital-open-operator-system-oos-pro' ),
			'get_order_analytics'         => __( 'Get Order Analytics', 'nvdigital-open-operator-system-oos-pro' ),
			'track_inventory_movement'    => __( 'Track Inventory Movement', 'nvdigital-open-operator-system-oos-pro' ),
			'low_stock_alert_automation'  => __( 'Low Stock Alert Automation', 'nvdigital-open-operator-system-oos-pro' ),
			'inventory_forecast'          => __( 'Inventory Forecast', 'nvdigital-open-operator-system-oos-pro' ),
			'segment_customers'           => __( 'Segment Customers', 'nvdigital-open-operator-system-oos-pro' ),
			'customer_lifetime_value'     => __( 'Customer Lifetime Value', 'nvdigital-open-operator-system-oos-pro' ),
			'export_customer_data'        => __( 'Export Customer Data', 'nvdigital-open-operator-system-oos-pro' ),
			'sales_performance_dashboard' => __( 'Sales Performance Dashboard', 'nvdigital-open-operator-system-oos-pro' ),
			'abandoned_cart_recovery'     => __( 'Abandoned Cart Recovery', 'nvdigital-open-operator-system-oos-pro' ),
			'create_discount_campaign'    => __( 'Create Discount Campaign', 'nvdigital-open-operator-system-oos-pro' ),
			'upsell_recommendations'      => __( 'Upsell Recommendations', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}
}
