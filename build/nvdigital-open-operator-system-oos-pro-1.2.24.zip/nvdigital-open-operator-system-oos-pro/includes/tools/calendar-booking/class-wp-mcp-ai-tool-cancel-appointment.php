<?php
/**
 * Cancel Appointment Tool
 *
 * Cancels appointments with automatic notifications to clients.
 * Supports cancellation reasons and refund processing.
 *
 * @package WP_MCP_AI_Pro
 * @subpackage Calendar_Booking_Toolkit
 * @since 2.6.0
 * @phase Phase 2.6 - Calendar Booking Toolkit
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tool for cancelling appointments.
 *
 * Features:
 * - Cancellation with reason tracking
 * - Automatic client notifications
 * - Refund integration support
 * - Cancellation policy enforcement
 * - Calendar sync updates
 *
 * @since 2.6.0
 */
class WP_MCP_AI_Tool_Cancel_Appointment implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Check if this tool is available.
	 *
	 * @since 2.6.0
	 *
	 * @return bool True if calendar booking toolkit is enabled.
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}

		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_calendar_booking_toolkit'] );
	}

	/**
	 * Get the reason why this tool is unavailable.
	 *
	 * @since 2.6.0
	 *
	 * @return string Reason message.
	 */
	public static function get_unavailable_reason() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_calendar_booking_toolkit'] ) ) {
			return __( 'Calendar Booking toolkit is not enabled. Please enable it in plugin settings.', 'nvdigital-open-operator-system-oos-pro' );
		}

		return __( 'Cancel appointment tool is not available.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get the tool slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'cancel_appointment';
	}

	/**
	 * Get the tool name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'Cancel Appointment', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get the tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Cancel appointments with automatic notifications to clients. Supports cancellation reasons and refund processing.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for this tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Cancelling a real booked appointment by appointment_id, with optional reason, refund, and client notification.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Moving an appointment to a new time; use reschedule_appointment. Blocking future slots; use block_time_slot.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'get_appointment_details', 'reschedule_appointment', 'create_appointment' ),
			'notes'           => __( 'Cancellation is permanent and notifies the client by default; set send_notification=false to cancel silently.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Get the parameters schema.
	 *
	 * @return array
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'appointment_id'    => array(
					'type'        => 'integer',
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
					'description' => __( 'Appointment ID to cancel (required)', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'reason'            => array(
					'type'        => 'string',
					'description' => __( 'Reason for cancellation', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'cancelled_by'      => array(
					'type'        => 'string',
					'description' => __( 'Who initiated the cancellation (client, staff, system)', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'client', 'staff', 'system' ),
					'default'     => 'staff',
				),
				'send_notification' => array(
					'type'        => 'boolean',
					'description' => __( 'Send cancellation notification to client', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => true,
				),
				'offer_reschedule'  => array(
					'type'        => 'boolean',
					'description' => __( 'Include reschedule link in notification', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => false,
				),
				'process_refund'    => array(
					'type'        => 'boolean',
					'description' => __( 'Automatically process refund if applicable', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => false,
				),
			),
			'required'   => array( 'appointment_id' ),
		);
	}

	/**
	 * Get capability flags.
	 *
	 * @return array<string>
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'database-write',
			'phase-2.6',
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Check permissions.
		$current_user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $current_user_id || ! user_can( $current_user_id, 'manage_options' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to cancel appointments.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		if ( ! self::is_available() ) {
			return new WP_Error(
				'toolkit_not_available',
				self::get_unavailable_reason()
			);
		}

		// Validate appointment ID.
		if ( empty( $arguments['appointment_id'] ) ) {
			return new WP_Error(
				'missing_appointment_id',
				__( 'Appointment ID is required.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		$appointment_id = absint( $arguments['appointment_id'] );
		$appointment    = get_post( $appointment_id );

		if ( ! $appointment || 'mcp_appointment' !== $appointment->post_type ) {
			return new WP_Error(
				'invalid_appointment',
				__( 'Invalid appointment ID.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		// Check current status.
		$current_status = get_post_meta( $appointment_id, '_status', true );
		if ( 'cancelled' === $current_status ) {
			return new WP_Error(
				'already_cancelled',
				__( 'This appointment has already been cancelled.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		// Sanitize inputs.
		$reason       = ! empty( $arguments['reason'] ) ? sanitize_textarea_field( $arguments['reason'] ) : '';
		$cancelled_by = ! empty( $arguments['cancelled_by'] ) ? sanitize_text_field( $arguments['cancelled_by'] ) : 'staff';

		// Update appointment status.
		update_post_meta( $appointment_id, '_status', 'cancelled' );
		update_post_meta( $appointment_id, '_cancelled_at', current_time( 'mysql' ) );
		update_post_meta( $appointment_id, '_cancelled_by', $cancelled_by );
		update_post_meta( $appointment_id, '_cancelled_by_user_id', $current_user_id );
		update_post_meta( $appointment_id, '_cancellation_reason', $reason );

		// Get client details.
		$client_name  = get_post_meta( $appointment_id, '_client_name', true );
		$client_email = get_post_meta( $appointment_id, '_client_email', true );
		$start_time   = get_post_meta( $appointment_id, '_start_time', true );

		// Process refund if requested and applicable.
		$refund_processed = false;
		if ( ! empty( $arguments['process_refund'] ) ) {
			$refund_processed = $this->process_refund( $appointment_id );
		}

		// Send notification if requested.
		$notification_sent = false;
		if ( ! empty( $arguments['send_notification'] ) && $client_email ) {
			$offer_reschedule  = ! empty( $arguments['offer_reschedule'] );
			$notification_sent = $this->send_cancellation_email(
				$appointment_id,
				$client_email,
				$client_name,
				$start_time,
				$reason,
				$offer_reschedule
			);
		}

		// Log cancellation.
		$this->log_cancellation( $appointment_id, $current_user_id, $reason, $cancelled_by );

		return array(
			'success'           => true,
			'appointment_id'    => $appointment_id,
			'status'            => 'cancelled',
			'cancelled_at'      => current_time( 'mysql' ),
			'cancelled_by'      => $cancelled_by,
			'reason'            => $reason,
			'notification_sent' => $notification_sent,
			'refund_processed'  => $refund_processed,
			'message'           => __( 'Appointment cancelled successfully.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Process refund for cancelled appointment.
	 *
	 * @param int $appointment_id Appointment ID.
	 * @return bool Whether refund was processed.
	 */
	private function process_refund( $appointment_id ) {
		// Check if appointment has associated payment.
		$payment_id = get_post_meta( $appointment_id, '_payment_id', true );
		if ( ! $payment_id ) {
			return false;
		}

		// Hook for payment gateway integration.
		$refund_result = apply_filters(
			'wp_mcp_ai_process_appointment_refund',
			false,
			$appointment_id,
			$payment_id
		);

		if ( $refund_result ) {
			update_post_meta( $appointment_id, '_refund_processed', 'yes' );
			update_post_meta( $appointment_id, '_refund_processed_at', current_time( 'mysql' ) );
		}

		return (bool) $refund_result;
	}

	/**
	 * Send cancellation email.
	 *
	 * @param int    $appointment_id  Appointment ID.
	 * @param string $email           Client email.
	 * @param string $name            Client name.
	 * @param string $start_time      Original start time.
	 * @param string $reason          Cancellation reason.
	 * @param bool   $offer_reschedule Whether to offer rescheduling.
	 * @return bool Whether email was sent successfully.
	 */
	private function send_cancellation_email( $appointment_id, $email, $name, $start_time, $reason, $offer_reschedule ) {
		$subject = sprintf(
			/* translators: %d: Appointment ID */
			__( 'Appointment Cancelled #%d', 'nvdigital-open-operator-system-oos-pro' ),
			$appointment_id
		);

		$message = sprintf(
			/* translators: 1: Client name, 2: Start time */
			__( "Hello %1\$s,\n\nYour appointment scheduled for %2\$s has been cancelled.\n\n", 'nvdigital-open-operator-system-oos-pro' ),
			$name,
			$start_time
		);

		if ( $reason ) {
			$message .= sprintf(
				/* translators: %s: Cancellation reason */
				__( "Reason: %s\n\n", 'nvdigital-open-operator-system-oos-pro' ),
				$reason
			);
		}

		if ( $offer_reschedule ) {
			$reschedule_link = home_url( '/book-appointment/' );
			$message        .= sprintf(
				/* translators: %s: Reschedule link */
				__( "You can reschedule your appointment here: %s\n\n", 'nvdigital-open-operator-system-oos-pro' ),
				$reschedule_link
			);
		}

		$message .= __( "We apologize for any inconvenience.\n\nThank you!", 'nvdigital-open-operator-system-oos-pro' );

		return wp_mail( $email, $subject, $message );
	}

	/**
	 * Log cancellation details.
	 *
	 * @param int    $appointment_id Appointment ID.
	 * @param int    $user_id        User who cancelled.
	 * @param string $reason         Cancellation reason.
	 * @param string $cancelled_by   Who cancelled (client/staff/system).
	 */
	private function log_cancellation( $appointment_id, $user_id, $reason, $cancelled_by ) {
		$log_entry = array(
			'action'       => 'cancelled',
			'timestamp'    => current_time( 'mysql' ),
			'user_id'      => $user_id,
			'cancelled_by' => $cancelled_by,
			'reason'       => $reason,
		);

		$activity_log = get_post_meta( $appointment_id, '_activity_log', true );
		if ( ! is_array( $activity_log ) ) {
			$activity_log = array();
		}

		$activity_log[] = $log_entry;
		update_post_meta( $appointment_id, '_activity_log', $activity_log );
	}
}
