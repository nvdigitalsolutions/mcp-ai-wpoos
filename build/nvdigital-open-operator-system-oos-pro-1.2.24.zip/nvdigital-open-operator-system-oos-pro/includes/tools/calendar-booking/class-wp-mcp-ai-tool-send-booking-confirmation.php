<?php
/**
 * Send Booking Confirmation Tool - Phase 2.6
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * WP_MCP_AI_Tool_Send_Booking_Confirmation tool.
 */
class WP_MCP_AI_Tool_Send_Booking_Confirmation implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	/**
	 * Check if tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false; }
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_calendar_booking_toolkit'] );
	}
	/**
	 * Get unavailable reason.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'Calendar Booking toolkit is not enabled.', 'nvdigital-open-operator-system-oos-pro' ); }
		/**
		 * Get the tool slug.
		 *
		 * @return string
		 */
	public function get_slug() {
		return 'send_booking_confirmation'; }
	/**
	 * Get the tool name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'Send Booking Confirmation', 'nvdigital-open-operator-system-oos-pro' ); }
	/**
	 * Get the tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Send confirmation emails to clients for their appointments.', 'nvdigital-open-operator-system-oos-pro' ); }
	/**
	 * Get the usage guidance for this tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Emailing a single client to confirm their appointment, with an optional iCal attachment and custom message.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Confirming several bookings in one batch; use send_booking_confirmations instead.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'send_booking_confirmations', 'send_appointment_reminder', 'create_appointment' ),
			'notes'           => __( 'Sends real email via wp_mail and stamps the appointment with a confirmation timestamp.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}
		/**
		 * Get the parameters schema.
		 *
		 * @return array
		 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'appointment_id' => array(
					'type'        => 'integer',
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
					'description' => __( 'Appointment ID', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'include_ical'   => array(
					'type'        => 'boolean',
					'description' => __( 'Include iCal attachment', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => true,
				),
				'custom_message' => array(
					'type'        => 'string',
					'description' => __( 'Additional custom message', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),
			'required'   => array( 'appointment_id' ),
		);
	}
		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array( 'pro', 'email', 'phase-2.6' ); }
	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$current_user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();
		if ( ! $current_user_id || ! user_can( $current_user_id, 'manage_options' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'Permission denied.', 'nvdigital-open-operator-system-oos-pro' ) );
		}
		if ( ! self::is_available() ) {
			return new WP_Error( 'toolkit_not_available', self::get_unavailable_reason() ); }
		$appointment_id = ! empty( $arguments['appointment_id'] ) ? absint( $arguments['appointment_id'] ) : 0;
		if ( ! $appointment_id ) {
			return new WP_Error( 'missing_id', __( 'Appointment ID is required.', 'nvdigital-open-operator-system-oos-pro' ) ); }
		$appointment = get_post( $appointment_id );
		if ( ! $appointment || 'mcp_appointment' !== $appointment->post_type ) {
			return new WP_Error( 'invalid_appointment', __( 'Invalid appointment.', 'nvdigital-open-operator-system-oos-pro' ) );
		}
		$client_email = get_post_meta( $appointment_id, '_client_email', true );
		$client_name  = get_post_meta( $appointment_id, '_client_name', true );
		$start_time   = get_post_meta( $appointment_id, '_start_time', true );
		$end_time     = get_post_meta( $appointment_id, '_end_time', true );
		/* translators: %d: appointment ID */
		$subject = sprintf( __( 'Appointment Confirmation #%d', 'nvdigital-open-operator-system-oos-pro' ), $appointment_id );
		/* translators: %1$s: client name, %2$s: start time, %3$s: end time */
		$message = sprintf( __( "Hello %1\$s,\n\nYour appointment is confirmed.\nTime: %2\$s to %3\$s\n\n", 'nvdigital-open-operator-system-oos-pro' ), $client_name, $start_time, $end_time );
		if ( ! empty( $arguments['custom_message'] ) ) {
			$message .= sanitize_textarea_field( $arguments['custom_message'] ) . "\n\n";
		}
		$message .= __( 'Thank you!', 'nvdigital-open-operator-system-oos-pro' );
		$sent     = wp_mail( $client_email, $subject, $message );
		if ( $sent ) {
			update_post_meta( $appointment_id, '_confirmation_sent_at', current_time( 'mysql' ) );
		}
		return array(
			'success'        => true,
			'appointment_id' => $appointment_id,
			'email_sent'     => $sent,
			'recipient'      => $client_email,
			'message'        => $sent ? __( 'Confirmation sent successfully.', 'nvdigital-open-operator-system-oos-pro' ) : __( 'Failed to send confirmation.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}
}
