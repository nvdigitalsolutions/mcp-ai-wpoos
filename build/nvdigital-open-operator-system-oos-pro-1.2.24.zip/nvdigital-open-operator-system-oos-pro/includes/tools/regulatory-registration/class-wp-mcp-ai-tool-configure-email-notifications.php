<?php
/**
 * Tool for configuring email notification rules.
 *
 * Allows AI assistants to configure automated email notifications
 * for registration events and milestones.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Configures email notification rules.
 */
class WP_MCP_AI_Tool_Configure_Email_Notifications implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Restrict_From_Chat_Client;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'configure_email_notifications';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Configure Email Notifications', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Configures automated email notification rules for registration events, expiry alerts, and status changes with recipient management.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Enabling, disabling, or changing recipients and trigger conditions for automated registration emails.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Sending a one-off email or reviewing what was already sent; use send_status_change_notification or get_notification_history.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'get_notification_history', 'send_status_change_notification', 'send_expiry_alerts' ),
			'notes'           => __( 'Requires manage_options; choose notification_type from expiry_alert, status_change, submission_confirmation, or approval_notice.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'notification_type' => array(
					'type'        => 'string',
					'description' => __( 'Type of notification to configure (required)', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'expiry_alert', 'status_change', 'submission_confirmation', 'approval_notice' ),
				),
				'enabled'           => array(
					'type'        => 'boolean',
					'description' => __( 'Enable or disable notification (required)', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'recipients'        => array(
					'type'        => 'array',
					'description' => __( 'Email addresses to notify (optional)', 'nvdigital-open-operator-system-oos-pro' ),
					'items'       => array(
						'type'   => 'string',
						'format' => 'email',
					),
				),
				'conditions'        => array(
					'type'        => 'object',
					'description' => __( 'Notification trigger conditions (optional)', 'nvdigital-open-operator-system-oos-pro' ),
					'properties'  => array(
						'days_before_expiry' => array(
							'type'    => 'integer',
							'minimum' => 1,
						),
						'countries'          => array(
							'type'  => 'array',
							'items' => array( 'type' => 'string' ),
						),
						'status_from'        => array( 'type' => 'string' ),
						'status_to'          => array( 'type' => 'string' ),
					),
				),
			),
			'required'             => array( 'notification_type', 'enabled' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro-tier tool.
			'database-write',       // Saves configuration.
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Check if the tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_regulatory_registration_toolkit'] );
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$current_user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $current_user_id || ! user_can( $current_user_id, 'manage_options' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to configure email notifications.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		// Validate required fields.
		if ( empty( $arguments['notification_type'] ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_param', __( 'Notification type is required.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		if ( ! isset( $arguments['enabled'] ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_param', __( 'Enabled status is required.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$notification_type = sanitize_text_field( $arguments['notification_type'] );
		$enabled           = (bool) $arguments['enabled'];
		$recipients        = ! empty( $arguments['recipients'] ) && is_array( $arguments['recipients'] ) ? array_map( 'sanitize_email', $arguments['recipients'] ) : array();
		$conditions        = ! empty( $arguments['conditions'] ) && is_array( $arguments['conditions'] ) ? $arguments['conditions'] : array();

		// Get current notification settings.
		$notification_settings = get_option( 'wp_mcp_ai_notification_settings', array() );

		// Update configuration for this notification type.
		$notification_settings[ $notification_type ] = array(
			'enabled'    => $enabled,
			'recipients' => $recipients,
			'conditions' => $conditions,
			'updated_at' => current_time( 'mysql' ),
			'updated_by' => $current_user_id,
		);

		// Save settings.
		update_option( 'wp_mcp_ai_notification_settings', $notification_settings );

		// Log configuration change.
		$log_entry = array(
			'timestamp'         => current_time( 'mysql' ),
			'user_id'           => $current_user_id,
			'notification_type' => $notification_type,
			'action'            => $enabled ? 'enabled' : 'disabled',
		);

		$notification_log   = get_option( 'wp_mcp_ai_notification_log', array() );
		$notification_log[] = $log_entry;
		update_option( 'wp_mcp_ai_notification_log', array_slice( $notification_log, -100 ), false ); // Keep last 100 entries.

		return array(
			'success'           => true,
			'notification_type' => $notification_type,
			'enabled'           => $enabled,
			'recipients_count'  => count( $recipients ),
			'has_conditions'    => ! empty( $conditions ),
			'configured_at'     => current_time( 'mysql' ),
			'message'           => sprintf(
				/* translators: 1: notification type, 2: enabled/disabled */
				__( 'Email notification "%1$s" has been %2$s.', 'nvdigital-open-operator-system-oos-pro' ),
				$notification_type,
				$enabled ? __( 'enabled', 'nvdigital-open-operator-system-oos-pro' ) : __( 'disabled', 'nvdigital-open-operator-system-oos-pro' )
			),
		);
	}
}
