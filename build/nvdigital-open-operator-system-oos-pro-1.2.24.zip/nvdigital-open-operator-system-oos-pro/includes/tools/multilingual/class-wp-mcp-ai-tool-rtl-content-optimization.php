<?php
/**
 * RTL Content Optimization Tool
 *
 * Optimize content and layouts for RTL (right-to-left) languages like Arabic and Hebrew.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP_MCP_AI_Tool_RTL_Content_Optimization tool.
 */
class WP_MCP_AI_Tool_RTL_Content_Optimization implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * Check if tool is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}

		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_multilingual_toolkit'] );
	}

	/**
	 * Get unavailable reason.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_multilingual_toolkit'] ) ) {
			return __( 'Multi-language Content toolkit is not enabled.', 'nvdigital-open-operator-system-oos-pro' );
		}
		return __( 'RTL Content Optimization tool is not available.', 'nvdigital-open-operator-system-oos-pro' );
	}


	/**

	 * Get the tool slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'rtl_content_optimization';
	}

	/**
	 * Get the tool name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'RTL Content Optimization', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get the tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Optimize content and layouts for RTL (right-to-left) languages like Arabic and Hebrew.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Preparing posts for RTL languages like Arabic or Hebrew, including image flipping.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'LTR locales or date and currency formatting; use localize_dates_currencies for locale formats.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'localize_dates_currencies', 'auto_translate_content' ),
			'notes'           => __( 'Set optimize_images=true to flip images; otherwise content direction and layout are adjusted only.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}


	/**

	 * Get the parameters schema.
	 *
	 * @return array
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'post_id'         => array(
					'type'        => 'integer',
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
					'description' => 'Post ID to optimize for RTL',
				),
				'language'        => array(
					'type'        => 'string',
					'description' => 'RTL language code (ar, he, etc.)',
				),
				'optimize_images' => array(
					'type'        => 'boolean',
					'description' => 'Flip images for RTL',
					'default'     => false,
				),
			),
			'required'   => array(),
		);
	}


	/**

	 * Get the required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array(
			'content'     => true,
			'translation' => true,
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// TODO: Implement rtl_content_optimization logic.

		return array(
			'success' => true,
			'message' => __( 'RTL Content Optimization executed successfully.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}
}
