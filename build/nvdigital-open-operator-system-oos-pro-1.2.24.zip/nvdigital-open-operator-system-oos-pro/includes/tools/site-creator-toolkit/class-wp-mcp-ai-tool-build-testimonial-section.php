<?php
/**
 * Build Testimonial Section Tool
 *
 * Creates customer testimonial sections with quotes, ratings, author info,
 * and various display layouts (slider, grid, masonry).
 *
 * @package WP_MCP_AI
 * @subpackage Site_Creator_Toolkit
 * @since 1.2.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build Testimonial Section Tool
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Tool_Build_Testimonial_Section implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * Check if this tool is available.
	 *
	 * @since 1.2.0
	 *
	 * @return bool True if tool is available.
	 */
	public static function is_available() {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'build_testimonial_section';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Build Testimonial Section', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Creates customer testimonial sections with quotes, ratings, and author info. Supports slider, grid, and masonry layouts for social proof.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Generating a social-proof testimonial section with quotes, ratings, and slider, grid, or masonry layout.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Other section types; use create_hero_section, create_cta_section, or build_contact_section.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'create_hero_section', 'create_cta_section', 'build_contact_section' ),
			'notes'           => __( 'Returns placeholder testimonial data for assembly; it does not create the page.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'title'             => array(
					'type'        => 'string',
					'description' => __( 'Section title', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => 'What Our Customers Say',
				),
				'testimonial_count' => array(
					'type'        => 'integer',
					'description' => __( 'Number of testimonials to generate (2-6)', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => 3,
					'minimum'     => 2,
					'maximum'     => 6,
				),
				'layout'            => array(
					'type'        => 'string',
					'description' => __( 'Layout style', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'slider', 'grid', 'masonry' ),
					'default'     => 'slider',
				),
				'show_ratings'      => array(
					'type'        => 'boolean',
					'description' => __( 'Include star ratings', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => true,
				),
			),
			'required'             => array(),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @since 1.2.0
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Testimonial section data or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Check if site creator toolkit is enabled.
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_site_creator_toolkit'] ) ) {
			return new WP_Error( 'wp_mcp_ai_feature_disabled', __( 'The Site Creator Toolkit is disabled.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		// Check permissions.
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();
		if ( ! $user_id || ! user_can( $user_id, 'edit_pages' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		// Sanitize arguments.
		$title       = isset( $arguments['title'] ) ? sanitize_text_field( $arguments['title'] ) : 'What Our Customers Say';
		$count       = isset( $arguments['testimonial_count'] ) ? min( 6, max( 2, absint( $arguments['testimonial_count'] ) ) ) : 3;
		$layout      = isset( $arguments['layout'] ) ? sanitize_text_field( $arguments['layout'] ) : 'slider';
		$show_rating = isset( $arguments['show_ratings'] ) ? (bool) $arguments['show_ratings'] : true;

		// Generate testimonials.
		$testimonials = array();
		for ( $i = 1; $i <= $count; $i++ ) {
			$testimonial = array(
				'quote'  => 'Outstanding service and exceptional results. Highly recommended!',
				'author' => 'Customer Name ' . $i,
				'role'   => 'Position Title',
			);

			if ( $show_rating ) {
				$testimonial['rating'] = 5;
			}

			$testimonials[] = $testimonial;
		}

		$testimonial_section = array(
			'type'         => 'testimonials',
			'title'        => $title,
			'layout'       => $layout,
			'show_ratings' => $show_rating,
			'testimonials' => $testimonials,
		);

		return array(
			'success'             => true,
			'testimonial_section' => $testimonial_section,
			/* translators: 1: number of testimonials, 2: layout type */
			'summary'             => sprintf( __( 'Generated testimonial section with %1$d testimonials in %2$s layout.', 'nvdigital-open-operator-system-oos-pro' ), $count, $layout ),
			'timestamp'           => current_time( 'mysql' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array( 'pro', 'write', 'requires-capability', 'non-deterministic' );
	}
}
