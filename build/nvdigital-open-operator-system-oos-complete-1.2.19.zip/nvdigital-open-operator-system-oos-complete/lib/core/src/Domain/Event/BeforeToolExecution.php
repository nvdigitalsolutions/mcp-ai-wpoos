<?php
/**
 * Fired before a tool is executed.
 *
 * Replaces: do_action('wp_mcp_ai_before_tool_execution', ...)
 *
 * @package Nvoos\Core
 * @since   1.0.0
 * @license MIT
 *
 * SPDX-License-Identifier: MIT
 */

declare(strict_types=1);

namespace Nvoos\Core\Domain\Event;

final class BeforeToolExecution {

	/**
	 * @param ToolArgs $arguments
	 * @param ToolContext $context
	 */
	public function __construct(
		public readonly string $toolSlug,
		public readonly array $arguments,
		public readonly array $context,
		public readonly float $startedAtMicros,
	) {}
}
