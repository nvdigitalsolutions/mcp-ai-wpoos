<?php
/**
 * DietPi Add Sonarr Series Tool
 *
 * Add a new TV series to Sonarr with lookup by TVDb ID, IMDb ID, or title.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage DietPi_Toolkit
 * @since      1.3.0
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_DietPi_Add_Sonarr_Series' ) ) {

	/**
	 * Add Sonarr series tool.
	 */
	class WP_MCP_AI_Tool_DietPi_Add_Sonarr_Series extends WP_MCP_AI_Tool_DietPi_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */
		public function get_slug() {
			return 'dietpi_add_sonarr_series';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Add Sonarr Series', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Add a new TV series to Sonarr. Supports lookup by TVDb ID, IMDb ID, or title search. Also supports setting quality profile, root folder, and monitoring options.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Adding a TV series to Sonarr so it is monitored and downloaded, identified by TVDb ID, IMDb ID, or title.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Reviewing or changing series already in Sonarr; use dietpi_list_sonarr_series or dietpi_manage_sonarr.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'dietpi_list_sonarr_series', 'dietpi_manage_sonarr', 'dietpi_media_request_flow' ),
				'notes'           => __( 'This queues real episode downloads; pass a TVDb ID when possible for an unambiguous match.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'lookup_type'                 => array(
						'type'        => 'string',
						'description' => __( 'How to identify the series.', 'nvdigital-open-operator-system-oos-pro' ),
						'enum'        => array( 'tvdb', 'imdb', 'title' ),
						'default'     => 'title',
					),
					'tvdb_id'                     => array(
						'type'        => 'integer',
						'description' => __( 'TheTVDB ID (for tvdb lookup).', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'imdb_id'                     => array(
						'type'        => 'string',
						'description' => __( 'IMDb ID (for imdb lookup, e.g. tt1234567).', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'title'                       => array(
						'type'        => 'string',
						'description' => __( 'Series title to search for (for title lookup). Use "Breaking Bad" not "Breaking Bad S01".', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'quality_profile_id'          => array(
						'type'        => 'integer',
						'description' => __( 'Quality profile ID. Use 1 if unsure (first/default profile).', 'nvdigital-open-operator-system-oos-pro' ),
						'default'     => 1,
					),
					'root_folder_path'            => array(
						'type'        => 'string',
						'description' => __( 'Root folder path (e.g. /mnt/dietpi_userdata/downloads/tv).', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'monitored'                   => array(
						'type'        => 'boolean',
						'description' => __( 'Monitor the series for new episodes. Default: true.', 'nvdigital-open-operator-system-oos-pro' ),
						'default'     => true,
					),
					'search_for_missing_episodes' => array(
						'type'        => 'boolean',
						'description' => __( 'Immediately search for missing episodes after adding. Default: true.', 'nvdigital-open-operator-system-oos-pro' ),
						'default'     => true,
					),
				),
				'required'   => array(),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge(
				parent::get_capability_flags(),
				array( 'write', 'state-changing', 'reversible' )
			);
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Execution context.
		 * @return array|WP_Error Success array or WP_Error on failure.
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			if ( ! $this->app_client()->is_app_configured( 'sonarr' ) ) {
				return new WP_Error(
					'wp_mcp_ai_sonarr_not_configured',
					__( 'Sonarr is not configured.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}
			$lookup_type = $this->sanitize_string( $arguments, 'lookup_type', 'title' );
			// Do lookup based on type.
			$lookup_result = null;
			$term          = '';
			switch ( $lookup_type ) {
				case 'tvdb':
					$id = $this->sanitize_int( $arguments, 'tvdb_id' );
					if ( $id <= 0 ) {
						return new WP_Error(
							'wp_mcp_ai_missing_tvdb',
							__( 'tvdb_id is required for TVDb lookup.', 'nvdigital-open-operator-system-oos-pro' )
						);
					}
					$lookup_result = $this->app_client()->get( 'sonarr', '/api/v3/series/lookup', array( 'term' => 'tvdb:' . $id ), 15 );
					$term          = 'tvdb:' . $id;
					break;
				case 'imdb':
					$imdb = $this->sanitize_string( $arguments, 'imdb_id' );
					if ( '' === $imdb ) {
						return new WP_Error(
							'wp_mcp_ai_missing_imdb',
							__( 'imdb_id is required for IMDb lookup.', 'nvdigital-open-operator-system-oos-pro' )
						);
					}
					$lookup_result = $this->app_client()->get( 'sonarr', '/api/v3/series/lookup', array( 'term' => 'imdb:' . $imdb ), 15 );
					$term          = 'imdb:' . $imdb;
					break;
				default:
					$title = $this->sanitize_string( $arguments, 'title' );
					if ( '' === $title ) {
						return new WP_Error(
							'wp_mcp_ai_missing_title',
							__( 'title is required for title lookup.', 'nvdigital-open-operator-system-oos-pro' )
						);
					}
					$lookup_result = $this->app_client()->get( 'sonarr', '/api/v3/series/lookup', array( 'term' => $title ), 15 );
					$term          = $title;
					break;
			}
			if ( is_wp_error( $lookup_result ) ) {
				return $lookup_result;
			}
			if ( ! is_array( $lookup_result ) || empty( $lookup_result ) ) {
				return new WP_Error(
					'wp_mcp_ai_not_found',
					sprintf(
						/* translators: %s: search term */
						__( 'No series found for "%s".', 'nvdigital-open-operator-system-oos-pro' ),
						$term
					)
				);
			}
			$selected = $lookup_result[0];
			// Get root folder.
			$root_path = $this->sanitize_string( $arguments, 'root_folder_path' );
			if ( '' === $root_path ) {
				$folders = $this->app_client()->get( 'sonarr', '/api/v3/rootfolder', array(), 10 );
				if ( is_wp_error( $folders ) ) {
					return $folders;
				}
				if ( ! empty( $folders ) && isset( $folders[0]['path'] ) ) {
					$root_path = $folders[0]['path'];
				}
			}
			if ( '' === $root_path ) {
				return new WP_Error(
					'wp_mcp_ai_no_root_folder',
					__( 'Could not determine root folder. Please specify root_folder_path.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}
			// Build add payload.
			$payload    = array(
				'tvdbId'           => isset( $selected['tvdbId'] ) ? (int) $selected['tvdbId'] : 0,
				'title'            => isset( $selected['title'] ) ? $selected['title'] : '',
				'qualityProfileId' => $this->sanitize_int( $arguments, 'quality_profile_id', 1 ),
				'rootFolderPath'   => $root_path,
				'monitored'        => $this->sanitize_bool( $arguments, 'monitored', true ),
				'addOptions'       => array(
					'searchForMissingEpisodes' => $this->sanitize_bool( $arguments, 'search_for_missing_episodes', true ),
				),
			);
			$add_result = $this->app_client()->post( 'sonarr', '/api/v3/series', $payload, 15 );
			if ( is_wp_error( $add_result ) ) {
				return $add_result;
			}
			return $this->success(
				sprintf(
					/* translators: %s: series title */
					__( 'Series "%s" added to Sonarr.', 'nvdigital-open-operator-system-oos-pro' ),
					$selected['title']
				),
				array( 'series' => $add_result )
			);
		}
	}
}
