<?php
/**
 * DietPi Add Transmission Torrent Tool
 *
 * Add a new torrent to Transmission by URL, magnet link, or base64-encoded
 * .torrent file.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage DietPi_Toolkit
 * @since      1.3.0
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_DietPi_Add_Transmission' ) ) {

	/**
	 * Add Transmission torrent tool.
	 */
	class WP_MCP_AI_Tool_DietPi_Add_Transmission extends WP_MCP_AI_Tool_DietPi_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */
		public function get_slug() {
			return 'dietpi_add_transmission';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Add Transmission Torrent', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Add a new torrent to Transmission by URL, magnet link, or base64-encoded .torrent file. Optionally specify a download directory, whether to start paused, and a label.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Adding one specific torrent to Transmission by URL, magnet link, or base64-encoded .torrent file.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Managing torrents already in Transmission; use dietpi_control_transmission. Finding releases to add; use dietpi_search_jackett.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'dietpi_control_transmission', 'dietpi_list_transmission', 'dietpi_search_jackett' ),
				'notes'           => __( 'The torrent starts downloading immediately unless paused=true.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'source'       => array(
						'type'        => 'string',
						'description' => __( 'URL, magnet link, or base64-encoded .torrent file content.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'download_dir' => array(
						'type'        => 'string',
						'description' => __( 'Custom download directory. Uses Transmission default if omitted.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'paused'       => array(
						'type'        => 'boolean',
						'description' => __( 'Add torrent in paused state. Default: false.', 'nvdigital-open-operator-system-oos-pro' ),
						'default'     => false,
					),
					'label'        => array(
						'type'        => 'string',
						'description' => __( 'Label/tag to assign to the torrent.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'source' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge(
				parent::get_capability_flags(),
				array( 'write', 'state-changing', 'reversible' )
			);
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Execution context.
		 * @return array|WP_Error Success array or WP_Error on failure.
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$source = $this->sanitize_string( $arguments, 'source' );
			if ( '' === $source ) {
				return new WP_Error(
					'wp_mcp_ai_missing_source',
					__( 'A torrent source (URL, magnet, or base64 .torrent) is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}
			$args = array();
			if ( 0 === strpos( $source, 'magnet:' ) ) {
				$args['filename'] = $source;
			} elseif ( 0 === strpos( $source, 'http' ) ) {
				$args['filename'] = $source;
			} else {
				$args['metainfo'] = $source;
			}
			$dir = $this->sanitize_string( $arguments, 'download_dir' );
			if ( '' !== $dir ) {
				$args['download-dir'] = $dir;
			}
			$args['paused'] = $this->sanitize_bool( $arguments, 'paused', false );
			$label          = $this->sanitize_string( $arguments, 'label' );
			if ( '' !== $label ) {
				$args['labels'] = array( $label );
			}
			$result = $this->app_client()->transmission_rpc( 'torrent-add', $args );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$added = isset( $result['torrent-added'] )
				? $result['torrent-added']
				: ( isset( $result['torrent-duplicate'] ) ? $result['torrent-duplicate'] : null );
			return $this->success(
				__( 'Torrent added successfully.', 'nvdigital-open-operator-system-oos-pro' ),
				array(
					'torrent' => $added,
					'paused'  => $args['paused'],
				)
			);
		}
	}
}
