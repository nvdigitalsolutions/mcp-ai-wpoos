<?php
/**
 * Tool for generating material schedules.
 *
 * Creates detailed bill of materials from floor plans and specifications.
 * Includes quantities, specifications, and ordering information.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @phase Phase 2.10
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';

/**
 * Generate material schedules.
 */
class WP_MCP_AI_Tool_Generate_Material_Schedule implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/* WP_MCP_AI_AVAILABILITY_BLOCK */
	/**
	 * Whether this tool is available for registration.
	 *
	 * @since 1.2.0
	 *
	 * @return bool True when the Architectural Design toolkit is enabled
	 *              and the host plugin is not running in base mode.
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_architectural_design_toolkit'] );
	}

	/**
	 * Reason this tool is unavailable, if any.
	 *
	 * @since 1.2.0
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'Architectural Design toolkit is not enabled.', 'nvdigital-open-operator-system-oos-pro' );
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_material_schedule';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate Material Schedule', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Create detailed bill of materials from floor plans. Includes quantities, specifications, and ordering information.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Extracting a bill of materials from a floor plan for framing, roofing, siding, interior, mechanical, electrical, or plumbing categories.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'For priced BoQ documents or cost totals - use generate_bill_of_quantities or estimate_construction_cost.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'generate_bill_of_quantities', 'estimate_construction_cost' ),
			'notes'           => __( 'include_waste_factor adds a 10 percent overage to quantities; output_format accepts detailed, summary, csv, or excel.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'floor_plan'           => array(
					'type'        => 'object',
					'description' => __( 'Floor plan data to extract materials from.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'specifications'       => array(
					'type'        => 'object',
					'description' => __( 'Material specifications and preferences.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'material_categories'  => array(
					'type'        => 'array',
					'description' => __( 'Categories to include: "framing", "roofing", "siding", "interior", "mechanical", "electrical", "plumbing".', 'nvdigital-open-operator-system-oos-pro' ),
					'items'       => array(
						'type' => 'string',
						'enum' => array( 'framing', 'roofing', 'siding', 'interior', 'mechanical', 'electrical', 'plumbing', 'foundation' ),
					),
					'default'     => array( 'framing', 'roofing', 'interior' ),
				),
				'include_waste_factor' => array(
					'type'        => 'boolean',
					'description' => __( 'Include waste/overage factor in quantities.', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => true,
				),
				'output_format'        => array(
					'type'        => 'string',
					'description' => __( 'Output format: "detailed", "summary", "csv", "excel".', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'detailed', 'summary', 'csv', 'excel' ),
					'default'     => 'detailed',
				),
			),
			'required'             => array( 'floor_plan' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-capability',
			'requires-credentials',
			'write',
			'consumes-tokens',
			'external-api',
			'model-dependent',
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'edit_posts' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to generate material schedules.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		// Validate floor plan.
		if ( empty( $arguments['floor_plan'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_arguments',
				__( 'Floor plan data is required.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		$floor_plan           = $arguments['floor_plan'];
		$specifications       = isset( $arguments['specifications'] ) ? (array) $arguments['specifications'] : array();
		$material_categories  = isset( $arguments['material_categories'] ) ? (array) $arguments['material_categories'] : array( 'framing', 'roofing', 'interior' );
		$include_waste_factor = isset( $arguments['include_waste_factor'] ) ? (bool) $arguments['include_waste_factor'] : true;
		$output_format        = isset( $arguments['output_format'] ) ? sanitize_text_field( $arguments['output_format'] ) : 'detailed';

		// Generate material schedule.
		$schedule = $this->generate_schedule( $floor_plan, $specifications, $material_categories, $include_waste_factor, $output_format, $context );

		if ( is_wp_error( $schedule ) ) {
			return $schedule;
		}

		// Return structured schedule data.
		return array(
			'success'  => true,
			'schedule' => $schedule,
			'summary'  => $this->generate_schedule_summary( $schedule ),
			'message'  => __( 'Material schedule generated successfully.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Generate material schedule.
	 *
	 * @param array  $floor_plan           Floor plan data.
	 * @param array  $specifications       Specifications.
	 * @param array  $material_categories  Material categories.
	 * @param bool   $include_waste_factor Include waste factor.
	 * @param string $output_format        Output format.
	 * @param array  $context              Execution context.
	 * @return array Material schedule.
	 */
	protected function generate_schedule( $floor_plan, $specifications, $material_categories, $include_waste_factor, $output_format, $context ) {
		return array(
			'format'     => $output_format,
			'categories' => array(
				array(
					'category' => 'framing',
					'items'    => array(
						array(
							'item'          => '2x4x8 Studs',
							'quantity'      => 120,
							'unit'          => 'ea',
							'waste_factor'  => $include_waste_factor ? 0.1 : 0,
							'total'         => $include_waste_factor ? 132 : 120,
							'specification' => 'Kiln-dried, Grade 2 or better',
						),
						array(
							'item'          => '2x6x12 Headers',
							'quantity'      => 15,
							'unit'          => 'ea',
							'waste_factor'  => $include_waste_factor ? 0.1 : 0,
							'total'         => $include_waste_factor ? 17 : 15,
							'specification' => 'Kiln-dried, Grade 1',
						),
					),
				),
			),
			'metadata'   => array(
				'waste_factor_applied' => $include_waste_factor,
				'generated_at'         => current_time( 'mysql' ),
			),
		);
	}

	/**
	 * Generate schedule summary.
	 *
	 * @param array $schedule Material schedule.
	 * @return array Summary data.
	 */
	protected function generate_schedule_summary( $schedule ) {
		return array(
			'total_categories' => count( isset( $schedule['categories'] ) ? $schedule['categories'] : array() ),
			'total_items'      => 0,
			'estimated_weight' => 'TBD',
			'estimated_volume' => 'TBD',
		);
	}
}
