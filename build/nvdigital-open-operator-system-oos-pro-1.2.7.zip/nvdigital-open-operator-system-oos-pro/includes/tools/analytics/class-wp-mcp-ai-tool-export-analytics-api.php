<?php
/**
 * Export Analytics API Tool
 *
 * Exports analytics data via REST API with various formats
 * and filtering options.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tool for exporting analytics via API.
 *
 * @since 1.1.0
 */
class WP_MCP_AI_Tool_Export_Analytics_API implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * Check if this tool is available.
	 *
	 * @since 1.1.0
	 *
	 * @return bool True if analytics toolkit is enabled.
	 */
	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
			return false;
		}

		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_analytics_toolkit'] );
	}

	/**
	 * Get the reason why this tool is unavailable.
	 *
	 * @since 1.1.0
	 *
	 * @return string Reason message.
	 */
	public static function get_unavailable_reason() {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_analytics_toolkit'] ) ) {
			return __( 'Advanced Analytics toolkit is not enabled.', 'nvdigital-open-operator-system-oos-pro' );
		}
		return __( 'Export analytics API tool is not available.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get the tool slug.
	 *
	 * @since 1.1.0
	 *
	 * @return string Tool slug.
	 */
	public function get_slug() {
		return 'export_analytics_api';
	}

	/**
	 * Get the tool name.
	 *
	 * @since 1.1.0
	 *
	 * @return string Tool name.
	 */
	public function get_name() {
		return __( 'Export Analytics API', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get the tool description.
	 *
	 * @since 1.1.0
	 *
	 * @return string Tool description.
	 */
	public function get_description() {
		return __( 'Export analytics data via REST API in JSON, CSV, or XML format with filtering and pagination.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Pulling a dated snapshot of sales, customers, products, or traffic data as JSON, CSV, or XML.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Streaming data directly into an external warehouse; use data_warehouse_sync instead.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'data_warehouse_sync', 'create_custom_report', 'generate_executive_dashboard' ),
			'notes'           => __( 'Format defaults to JSON over the last 30 days; limit caps records at 10000 per export.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Get the parameters schema.
	 *
	 * @since 1.1.0
	 *
	 * @return array Parameters schema.
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'data_type'  => array(
					'type'        => 'string',
					'description' => 'Type of analytics: sales, customers, products, traffic',
					'enum'        => array( 'sales', 'customers', 'products', 'traffic' ),
					'default'     => 'sales',
				),
				'format'     => array(
					'type'        => 'string',
					'description' => 'Export format: json, csv, xml',
					'enum'        => array( 'json', 'csv', 'xml' ),
					'default'     => 'json',
				),
				'start_date' => array(
					'type'        => 'string',
					'description' => 'Start date (YYYY-MM-DD)',
				),
				'end_date'   => array(
					'type'        => 'string',
					'description' => 'End date (YYYY-MM-DD)',
				),
				'limit'      => array(
					'type'        => 'integer',
					'description' => 'Maximum records to export',
					'minimum'     => 1,
					'maximum'     => 10000,
					'default'     => 1000,
				),
			),
			'required'   => array( 'data_type' ),
		);
	}

	/**
	 * Get the required capability.
	 *
	 * @since 1.1.0
	 *
	 * @return string Required capability.
	 */
	public function get_required_capability() {
		return 'manage_options';
	}

	/**
	 * Get capability flags.
	 *
	 * @since 1.1.0
	 *
	 * @return array Capability flags.
	 */
	public function get_capability_flags() {
		return array(
			'analytics' => true,
			'export'    => true,
			'read_only' => true,
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @since 1.1.0
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error Export data or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$data_type  = sanitize_text_field( $arguments['data_type'] );
		$format     = ! empty( $arguments['format'] ) ? sanitize_text_field( $arguments['format'] ) : 'json';
		$start_date = ! empty( $arguments['start_date'] ) ? sanitize_text_field( $arguments['start_date'] ) : gmdate( 'Y-m-d', strtotime( '-30 days' ) );
		$end_date   = ! empty( $arguments['end_date'] ) ? sanitize_text_field( $arguments['end_date'] ) : current_time( 'Y-m-d' );
		$limit      = isset( $arguments['limit'] ) ? absint( $arguments['limit'] ) : 1000;

		// Collect data based on type.
		$data = $this->collect_analytics_data( $data_type, $start_date, $end_date, $limit );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		// Format data.
		$formatted_data = $this->format_data( $data, $format );

		// Generate API endpoint URL.
		$api_url = rest_url( 'mcp-ai-pro/v1/analytics/export' );

		return array(
			'success'     => true,
			'data'        => $formatted_data,
			'metadata'    => array(
				'data_type'    => $data_type,
				'format'       => $format,
				'start_date'   => $start_date,
				'end_date'     => $end_date,
				'record_count' => is_array( $data ) ? count( $data ) : 0,
				'api_url'      => $api_url,
			),
			'exported_at' => current_time( 'mysql' ),
			'message'     => __( 'Analytics data exported successfully.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Collect analytics data based on type.
	 *
	 * @since 1.1.0
	 *
	 * @param string $data_type  Data type to collect.
	 * @param string $start_date Start date.
	 * @param string $end_date   End date.
	 * @param int    $limit      Maximum records.
	 * @return array|WP_Error Analytics data or error.
	 */
	private function collect_analytics_data( $data_type, $start_date, $end_date, $limit ) {
		switch ( $data_type ) {
			case 'sales':
				return $this->get_sales_data( $start_date, $end_date, $limit );
			case 'customers':
				return $this->get_customers_data( $start_date, $end_date, $limit );
			case 'products':
				return $this->get_products_data( $start_date, $end_date, $limit );
			case 'traffic':
				return $this->get_traffic_data( $start_date, $end_date, $limit );
			default:
				return new WP_Error( 'invalid_data_type', __( 'Invalid data type.', 'nvdigital-open-operator-system-oos-pro' ) );
		}
	}

	/**
	 * Get sales data from database.
	 *
	 * @since 1.1.0
	 *
	 * @param string $start_date Start date.
	 * @param string $end_date   End date.
	 * @param int    $limit      Maximum records.
	 * @return array Sales data.
	 */
	private function get_sales_data( $start_date, $end_date, $limit ) {
		global $wpdb;

		$query = "
			SELECT 
				p.ID as order_id,
				p.post_date as order_date,
				pm_total.meta_value as total,
				pm_status.meta_value as status
			FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} pm_total ON p.ID = pm_total.post_id AND pm_total.meta_key = '_order_total'
			LEFT JOIN {$wpdb->postmeta} pm_status ON p.ID = pm_status.post_id AND pm_status.meta_key = '_order_status'
			WHERE p.post_type = 'shop_order'
				AND p.post_date BETWEEN %s AND %s
			ORDER BY p.post_date DESC
			LIMIT %d
		";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $wpdb->get_results( $wpdb->prepare( $query, $start_date, $end_date, $limit ), ARRAY_A );
	}

	/**
	 * Get customer data from database.
	 *
	 * @since 1.1.0
	 *
	 * @param string $start_date Start date.
	 * @param string $end_date   End date.
	 * @param int    $limit      Maximum records.
	 * @return array Customer data.
	 */
	private function get_customers_data( $start_date, $end_date, $limit ) {
		global $wpdb;

		$query = "
			SELECT DISTINCT
				u.ID as customer_id,
				u.user_email,
				u.display_name,
				u.user_registered,
				COUNT(DISTINCT p.ID) as order_count,
				SUM(CAST(pm.meta_value AS DECIMAL(10,2))) as total_spent
			FROM {$wpdb->users} u
			INNER JOIN {$wpdb->posts} p ON u.ID = p.post_author
			INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
			WHERE p.post_type = 'shop_order'
				AND p.post_status IN ('wc-completed', 'wc-processing')
				AND pm.meta_key = '_order_total'
				AND p.post_date BETWEEN %s AND %s
			GROUP BY u.ID
			ORDER BY total_spent DESC
			LIMIT %d
		";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $wpdb->get_results( $wpdb->prepare( $query, $start_date, $end_date, $limit ), ARRAY_A );
	}

	/**
	 * Get product data from database.
	 *
	 * @since 1.1.0
	 *
	 * @param string $start_date Start date.
	 * @param string $end_date   End date.
	 * @param int    $limit      Maximum records.
	 * @return array Product data.
	 */
	private function get_products_data( $start_date, $end_date, $limit ) {
		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => $limit,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'date_query'     => array(
				array(
					'after'     => $start_date,
					'before'    => $end_date,
					'inclusive' => true,
				),
			),
		);

		$products = get_posts( $args );
		$data     = array();

		foreach ( $products as $product ) {
			$product_obj = wc_get_product( $product->ID );
			if ( ! $product_obj ) {
				continue;
			}

			$data[] = array(
				'product_id'     => $product->ID,
				'name'           => $product->post_title,
				'sku'            => $product_obj->get_sku(),
				'price'          => $product_obj->get_price(),
				'stock_status'   => $product_obj->get_stock_status(),
				'stock_quantity' => $product_obj->get_stock_quantity(),
			);
		}

		return $data;
	}

	/**
	 * Get traffic data placeholder.
	 *
	 * @since 1.1.0
	 *
	 * @param string $start_date Start date.
	 * @param string $end_date   End date.
	 * @param int    $limit      Maximum records.
	 * @return array Traffic data placeholder.
	 */
	private function get_traffic_data( $start_date, $end_date, $limit ) {
		// Placeholder for traffic data - would integrate with analytics plugin.
		return array(
			array(
				'date'        => $start_date,
				'pageviews'   => 0,
				'visits'      => 0,
				'bounce_rate' => 0,
				'note'        => 'Traffic data requires Google Analytics or similar integration',
			),
		);
	}

	/**
	 * Format data based on export format.
	 *
	 * @since 1.1.0
	 *
	 * @param array  $data   Data to format.
	 * @param string $format Export format (json, csv, xml).
	 * @return mixed Formatted data.
	 */
	private function format_data( $data, $format ) {
		switch ( $format ) {
			case 'csv':
				return $this->convert_to_csv( $data );
			case 'xml':
				return $this->convert_to_xml( $data );
			case 'json':
			default:
				return $data;
		}
	}

	/**
	 * Convert data to CSV format.
	 *
	 * @since 1.1.0
	 *
	 * @param array $data Data array.
	 * @return string CSV formatted data.
	 */
	private function convert_to_csv( $data ) {
		if ( empty( $data ) ) {
			return '';
		}

		$output = fopen( 'php://temp', 'r+' );

		// Headers.
		fputcsv( $output, array_keys( $data[0] ) );

		// Rows.
		foreach ( $data as $row ) {
			fputcsv( $output, $row );
		}

		rewind( $output );
		$csv = stream_get_contents( $output );
		fclose( $output );

		return $csv;
	}

	/**
	 * Convert data to XML format.
	 *
	 * @since 1.1.0
	 *
	 * @param array $data Data array.
	 * @return string XML formatted data.
	 */
	private function convert_to_xml( $data ) {
		$xml = new SimpleXMLElement( '<analytics/>' );

		foreach ( $data as $item ) {
			$record = $xml->addChild( 'record' );
			foreach ( $item as $key => $value ) {
				$record->addChild( $key, htmlspecialchars( $value ) );
			}
		}

		return $xml->asXML();
	}
}
