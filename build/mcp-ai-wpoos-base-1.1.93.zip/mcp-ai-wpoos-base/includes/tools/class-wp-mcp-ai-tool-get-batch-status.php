<?php
/**
 * Tool for retrieving OpenAI batch processing job status.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-openai-client.php';

/**
 * Retrieves the status and details of a batch processing job.
 *
 * Use this tool to monitor batch job progress, check completion status,
 * and retrieve output file IDs when jobs are complete.
 *
 * @since 1.0.0
 */
class WP_MCP_AI_Tool_Get_Batch_Status implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Model_Requirements_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface, WP_MCP_AI_Tool_Data_Contract_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'get_batch_status';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Get Batch Status', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Retrieves the status and details of a batch processing job. Use to monitor progress, check completion, get output file IDs, or troubleshoot failed jobs.', 'mcp-ai-wpoos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Polling an OpenAI batch job by ID to check progress, completion, or output file IDs.', 'mcp-ai-wpoos' ),
			'when_not_to_use' => __( 'Creating batches, listing all jobs, or live progress; use create_batch, list_batches, or monitor_batch.', 'mcp-ai-wpoos' ),
			'related_tools'   => array( 'create_batch', 'list_batches', 'monitor_batch' ),
			'notes'           => __( 'Requires manage_options plus OpenAI credentials; output_file_id appears only when completed.', 'mcp-ai-wpoos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'batch_id' => array(
					'type'        => 'string',
					'description' => __( 'The ID of the batch job to retrieve.', 'mcp-ai-wpoos' ),
				),
			),
			'required'             => array( 'batch_id' ),
			'additionalProperties' => false,
		);
	}

		/**
		 * {@inheritdoc}
		 */
	public function get_data_contract() {
		return array(
			'produces' => null,
			'consumes' => array( 'batch_id' ),
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'ai_model_management',

			'pattern_compatibility' => array( 'experimentation' ),

			'profession_tags'       => array( 'machine_learning_engineer' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'external-api',         // Makes external API calls.
			'read-only',            // Only reads data, doesn't modify.
			'requires-capability',  // Checks the user's capability before running.
			'requires-credentials', // Requires OpenAI API key.
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_model_requirements() {
		return array(); // Batch status retrieval doesn't require specific model capabilities.
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array Tool execution result.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		// Check permissions - requires manage_options capability.
		if ( ! $user_id || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to retrieve batch job status.', 'mcp-ai-wpoos' ),
				array( 'status' => 403 )
			);
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error(
				'wp_mcp_ai_wrong_site',
				__( 'You do not have access to this site.', 'mcp-ai-wpoos' ),
				array( 'status' => 403 )
			);
		}

		// Validate required parameters.
		if ( ! isset( $arguments['batch_id'] ) || '' === trim( $arguments['batch_id'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_missing_batch_id',
				__( 'Batch ID is required.', 'mcp-ai-wpoos' ),
				array( 'status' => 400 )
			);
		}

		// Call the OpenAI client.
		$client = new WP_MCP_AI_OpenAI_Client();
		$result = $client->retrieve_batch( sanitize_text_field( $arguments['batch_id'] ) );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Format the response.
		$response = array(
			'success'        => true,
			'batch_id'       => isset( $result['id'] ) ? $result['id'] : '',
			'status'         => isset( $result['status'] ) ? $result['status'] : '',
			'endpoint'       => isset( $result['endpoint'] ) ? $result['endpoint'] : '',
			'created_at'     => isset( $result['created_at'] ) ? gmdate( 'Y-m-d H:i:s', $result['created_at'] ) : '',
			'completed_at'   => isset( $result['completed_at'] ) && null !== $result['completed_at'] ? gmdate( 'Y-m-d H:i:s', $result['completed_at'] ) : null,
			'failed_at'      => isset( $result['failed_at'] ) && null !== $result['failed_at'] ? gmdate( 'Y-m-d H:i:s', $result['failed_at'] ) : null,
			'expired_at'     => isset( $result['expired_at'] ) && null !== $result['expired_at'] ? gmdate( 'Y-m-d H:i:s', $result['expired_at'] ) : null,
			'output_file_id' => isset( $result['output_file_id'] ) ? $result['output_file_id'] : null,
			'error_file_id'  => isset( $result['error_file_id'] ) ? $result['error_file_id'] : null,
			'request_counts' => isset( $result['request_counts'] ) ? $result['request_counts'] : array(),
			'metadata'       => isset( $result['metadata'] ) ? $result['metadata'] : array(),
			'summary'        => $this->generate_summary( $result ),
			'message'        => $this->generate_summary( $result ), // Chat client display.
			'raw_result'     => $result,
		);

		return $response;
	}

	/**
	 * Generate a human-readable summary of the batch job status.
	 *
	 * @param array $result Batch status result from OpenAI.
	 * @return string Summary message.
	 */
	protected function generate_summary( array $result ) {
		$batch_id = isset( $result['id'] ) ? $result['id'] : '';
		$status   = isset( $result['status'] ) ? $result['status'] : '';

		$summary = sprintf(
			/* translators: 1: batch ID, 2: status */
			__( 'Batch Job ID: %1$s, Status: %2$s', 'mcp-ai-wpoos' ),
			$batch_id,
			ucfirst( $status )
		);

		// Add status-specific details.
		switch ( $status ) {
			case 'validating':
				$summary .= "\n" . __( 'The batch is currently being validated. This usually takes a few moments.', 'mcp-ai-wpoos' );
				break;

			case 'in_progress':
				$summary .= "\n" . __( 'The batch is being processed. Check back later for completion.', 'mcp-ai-wpoos' );
				if ( isset( $result['request_counts'] ) && is_array( $result['request_counts'] ) ) {
					$total     = isset( $result['request_counts']['total'] ) ? $result['request_counts']['total'] : 0;
					$completed = isset( $result['request_counts']['completed'] ) ? $result['request_counts']['completed'] : 0;
					if ( $total > 0 ) {
						$progress = round( ( $completed / $total ) * 100 );
						$summary .= "\n" . sprintf(
							/* translators: 1: completed count, 2: total count, 3: percentage */
							__( 'Progress: %1$d of %2$d requests completed (%3$d%%)', 'mcp-ai-wpoos' ),
							$completed,
							$total,
							$progress
						);
					}
				}
				break;

			case 'completed':
				$summary .= "\n" . __( 'The batch has been completed successfully!', 'mcp-ai-wpoos' );
				if ( isset( $result['output_file_id'] ) && $result['output_file_id'] ) {
					$summary .= "\n" . sprintf(
						/* translators: %s: output file ID */
						__( 'Output File ID: %s', 'mcp-ai-wpoos' ),
						$result['output_file_id']
					);
					$summary .= "\n" . __( 'Download the output file to retrieve your results.', 'mcp-ai-wpoos' );
				}
				if ( isset( $result['request_counts'] ) && is_array( $result['request_counts'] ) ) {
					$total    = isset( $result['request_counts']['total'] ) ? $result['request_counts']['total'] : 0;
					$failed   = isset( $result['request_counts']['failed'] ) ? $result['request_counts']['failed'] : 0;
					$summary .= "\n" . sprintf(
						/* translators: 1: completed count, 2: failed count */
						__( 'Successfully completed: %1$d requests, Failed: %2$d requests', 'mcp-ai-wpoos' ),
						$total - $failed,
						$failed
					);
				}
				break;

			case 'failed':
				$summary .= "\n" . __( 'The batch has failed. Check the error file for details.', 'mcp-ai-wpoos' );
				if ( isset( $result['error_file_id'] ) && $result['error_file_id'] ) {
					$summary .= "\n" . sprintf(
						/* translators: %s: error file ID */
						__( 'Error File ID: %s', 'mcp-ai-wpoos' ),
						$result['error_file_id']
					);
				}
				break;

			case 'expired':
				$summary .= "\n" . __( 'The batch has expired before completion. You may need to recreate it.', 'mcp-ai-wpoos' );
				break;

			case 'cancelled':
			case 'cancelling':
				$summary .= "\n" . __( 'The batch has been cancelled or is being cancelled.', 'mcp-ai-wpoos' );
				break;

			default:
				$summary .= "\n" . __( 'Status is unknown. Check raw result for details.', 'mcp-ai-wpoos' );
				break;
		}

		return $summary;
	}
}
