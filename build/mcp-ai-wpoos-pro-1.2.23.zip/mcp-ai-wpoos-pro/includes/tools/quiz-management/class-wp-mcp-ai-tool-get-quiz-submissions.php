<?php
/**
 * Tool for retrieving quiz submissions.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Retrieves quiz submissions.
 */
class WP_MCP_AI_Tool_Get_Quiz_Submissions implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'get_quiz_submissions';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Get Quiz Submissions', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Retrieves submissions for a specific quiz.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Listing submissions for a quiz, optionally filtered to pending or graded, with pagination.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'A single submission; use get_quiz_results by submission_id for full detail.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'get_quiz_results', 'get_quiz_analytics', 'grade_quiz' ),
			'notes'           => __( 'Only the quiz author or users with edit_others_posts can list submissions; filter by status to find ungraded work.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'quiz_id'  => array(
					'type'        => 'integer',
					'description' => __( 'The ID of the quiz.', 'mcp-ai-wpoos-pro' ),
					'minimum'     => 1,
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
				),
				'status'   => array(
					'type'        => 'string',
					'description' => __( 'Filter by submission status: pending, graded, or all.', 'mcp-ai-wpoos-pro' ),
					'enum'        => array( 'pending', 'graded', 'all' ),
					'default'     => 'all',
				),
				'per_page' => array(
					'type'        => 'integer',
					'description' => __( 'Number of submissions to retrieve per page.', 'mcp-ai-wpoos-pro' ),
					'default'     => 10,
					'minimum'     => 1,
					'maximum'     => 100,
				),
				'page'     => array(
					'type'        => 'integer',
					'description' => __( 'Page number for pagination.', 'mcp-ai-wpoos-pro' ),
					'default'     => 1,
					'minimum'     => 1,
				),
			),
			'required'             => array( 'quiz_id' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$current_user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $current_user_id || ! user_can( $current_user_id, 'read' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to view submissions.', 'mcp-ai-wpoos-pro' ) );
		}

		$quiz_id  = isset( $arguments['quiz_id'] ) ? absint( $arguments['quiz_id'] ) : 0;
		$status   = isset( $arguments['status'] ) ? sanitize_key( $arguments['status'] ) : 'all';
		$per_page = isset( $arguments['per_page'] ) ? absint( $arguments['per_page'] ) : 10;
		$page     = isset( $arguments['page'] ) ? absint( $arguments['page'] ) : 1;

		if ( ! $quiz_id ) {
			return new WP_Error( 'wp_mcp_ai_missing_quiz_id', __( 'Quiz ID is required.', 'mcp-ai-wpoos-pro' ) );
		}

		$quiz = get_post( $quiz_id );

		if ( ! $quiz || 'mcp_ai_quiz' !== $quiz->post_type ) {
			return new WP_Error( 'wp_mcp_ai_quiz_not_found', __( 'Quiz not found.', 'mcp-ai-wpoos-pro' ) );
		}

		// Check if user can view submissions (must be author or have edit_others_posts).
		$quiz_author = absint( $quiz->post_author );
		if ( $quiz_author !== $current_user_id && ! user_can( $current_user_id, 'edit_others_posts' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to view submissions for this quiz.', 'mcp-ai-wpoos-pro' ) );
		}

		$query_args = array(
			'post_type'      => 'mcp_ai_submission',
			'post_status'    => array( 'publish', 'pending' ),
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'meta_query'     => array(
				array(
					'key'   => '_mcp_ai_submission_quiz_id',
					'value' => $quiz_id,
				),
			),
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		// Filter by status if specified.
		if ( 'pending' === $status ) {
			$query_args['meta_query'][] = array(
				'key'   => '_mcp_ai_submission_status',
				'value' => 'pending',
			);
		} elseif ( 'graded' === $status ) {
			$query_args['meta_query'][] = array(
				'key'   => '_mcp_ai_submission_status',
				'value' => 'graded',
			);
		}

		$query = new WP_Query( $query_args );

		$submissions = array();

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$submission_id = get_the_ID();

				$submission_status = get_post_meta( $submission_id, '_mcp_ai_submission_status', true );
				$submission_data   = array(
					'submission_id' => $submission_id,
					'student_id'    => absint( get_the_author_meta( 'ID' ) ),
					'student_name'  => get_the_author_meta( 'display_name' ),
					'status'        => $submission_status,
					'submitted_at'  => get_the_date( 'c' ),
				);

				// Add time tracking information.
				$completion_time = get_post_meta( $submission_id, '_mcp_ai_submission_completion_time', true );
				if ( $completion_time ) {
					$submission_data['completion_time_minutes'] = floatval( $completion_time );
				}

				// Add grading info if graded.
				if ( 'graded' === $submission_status ) {
					$submission_data['earned_points'] = floatval( get_post_meta( $submission_id, '_mcp_ai_submission_earned_points', true ) );
					$submission_data['percentage']    = floatval( get_post_meta( $submission_id, '_mcp_ai_submission_percentage', true ) );
					$submission_data['passed']        = (bool) get_post_meta( $submission_id, '_mcp_ai_submission_passed', true );
					$submission_data['graded_by']     = absint( get_post_meta( $submission_id, '_mcp_ai_submission_graded_by', true ) );
					$submission_data['graded_at']     = get_post_meta( $submission_id, '_mcp_ai_submission_graded_at', true );
				}

				$submissions[] = $submission_data;
			}
			wp_reset_postdata();
		}

		// Generate Chart.js visualizations for submissions overview.
		$chart_data = $this->generate_submissions_charts( $submissions, $quiz_id );

		return array(
			'summary'     => sprintf(
				/* translators: %d: number of submissions */
				_n( 'Found %d submission', 'Found %d submissions', count( $submissions ), 'mcp-ai-wpoos-pro' ),
				count( $submissions )
			),
			'quiz_id'     => $quiz_id,
			'quiz_title'  => get_the_title( $quiz ),
			'submissions' => $submissions,
			'total'       => $query->found_posts,
			'page'        => $page,
			'per_page'    => $per_page,
			'total_pages' => $query->max_num_pages,
			'charts'      => $chart_data,
		);
	}

	/**
	 * Generate Chart.js configurations for submissions overview.
	 *
	 * @param array $submissions Submissions data.
	 * @param int   $quiz_id     Quiz ID.
	 * @return array Chart.js configurations.
	 */
	private function generate_submissions_charts( $submissions, $quiz_id ) {
		$passing_score = get_post_meta( $quiz_id, '_mcp_ai_quiz_passing_score', true );

		// Count by status.
		$graded_count  = 0;
		$pending_count = 0;
		$passed_count  = 0;
		$failed_count  = 0;
		$scores        = array();

		foreach ( $submissions as $submission ) {
			if ( 'graded' === $submission['status'] ) {
				++$graded_count;
				if ( isset( $submission['passed'] ) ) {
					if ( $submission['passed'] ) {
						++$passed_count;
					} else {
						++$failed_count;
					}
				}
				if ( isset( $submission['percentage'] ) ) {
					$scores[] = $submission['percentage'];
				}
			} else {
				++$pending_count;
			}
		}

		$charts = array();

		// Status overview chart.
		$charts['status_overview'] = array(
			'type'    => 'doughnut',
			'data'    => array(
				'labels'   => array(
					__( 'Graded', 'mcp-ai-wpoos-pro' ),
					__( 'Pending', 'mcp-ai-wpoos-pro' ),
				),
				'datasets' => array(
					array(
						'data'            => array( $graded_count, $pending_count ),
						'backgroundColor' => array(
							'rgba(75, 192, 192, 0.6)',
							'rgba(255, 206, 86, 0.6)',
						),
						'borderColor'     => array(
							'rgba(75, 192, 192, 1)',
							'rgba(255, 206, 86, 1)',
						),
						'borderWidth'     => 1,
					),
				),
			),
			'options' => array(
				'responsive' => true,
				'plugins'    => array(
					'title'  => array(
						'display' => true,
						'text'    => __( 'Submission Status', 'mcp-ai-wpoos-pro' ),
					),
					'legend' => array(
						'display'  => true,
						'position' => 'bottom',
					),
				),
			),
		);

		// Pass/fail chart (only if there are graded submissions).
		if ( $graded_count > 0 ) {
			$charts['pass_fail'] = array(
				'type'    => 'doughnut',
				'data'    => array(
					'labels'   => array(
						__( 'Passed', 'mcp-ai-wpoos-pro' ),
						__( 'Failed', 'mcp-ai-wpoos-pro' ),
					),
					'datasets' => array(
						array(
							'data'            => array( $passed_count, $failed_count ),
							'backgroundColor' => array(
								'rgba(75, 192, 192, 0.6)',
								'rgba(255, 99, 132, 0.6)',
							),
							'borderColor'     => array(
								'rgba(75, 192, 192, 1)',
								'rgba(255, 99, 132, 1)',
							),
							'borderWidth'     => 1,
						),
					),
				),
				'options' => array(
					'responsive' => true,
					'plugins'    => array(
						'title'  => array(
							'display' => true,
							'text'    => sprintf(
								/* translators: %d: passing score */
								__( 'Pass/Fail Rate (Passing: %d%%)', 'mcp-ai-wpoos-pro' ),
								$passing_score
							),
						),
						'legend' => array(
							'display'  => true,
							'position' => 'bottom',
						),
					),
				),
			);

			// Score distribution (if scores available).
			if ( ! empty( $scores ) ) {
				$bins = array_fill( 0, 10, 0 );
				foreach ( $scores as $score ) {
					$bin_index = min( floor( $score / 10 ), 9 );
					++$bins[ $bin_index ];
				}

				$labels = array();
				for ( $i = 0; $i < 10; $i++ ) {
					$start    = $i * 10;
					$end      = $start + 10;
					$labels[] = "{$start}-{$end}%";
				}

				$charts['score_distribution'] = array(
					'type'    => 'bar',
					'data'    => array(
						'labels'   => $labels,
						'datasets' => array(
							array(
								'label'           => __( 'Number of Students', 'mcp-ai-wpoos-pro' ),
								'data'            => $bins,
								'backgroundColor' => 'rgba(54, 162, 235, 0.6)',
								'borderColor'     => 'rgba(54, 162, 235, 1)',
								'borderWidth'     => 1,
							),
						),
					),
					'options' => array(
						'responsive' => true,
						'plugins'    => array(
							'title' => array(
								'display' => true,
								'text'    => __( 'Score Distribution', 'mcp-ai-wpoos-pro' ),
							),
						),
						'scales'     => array(
							'y' => array(
								'beginAtZero' => true,
								'title'       => array(
									'display' => true,
									'text'    => __( 'Number of Students', 'mcp-ai-wpoos-pro' ),
								),
							),
							'x' => array(
								'title' => array(
									'display' => true,
									'text'    => __( 'Score Range', 'mcp-ai-wpoos-pro' ),
								),
							),
						),
					),
				);
			}
		}

		return $charts;
	}

	/**
	 * {@inheritdoc}
	 */

	/**
	 * Get extended tool definition including toolkit metadata.
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {
		return array(
			'name'                  => $this->get_name(),
			'description'           => $this->get_description(),
			'toolkit'               => 'education',
			'post_type'             => 'mcp_ai_quiz',
			'pattern_compatibility' => array( 'orchestrator', 'sequential' ),
			'profession_tags'       => array( 'educator', 'trainer' ),
			'risk_level'            => 'info',
		);
	}

		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array(
			'pro',
			'read-only',
			'local-only',
			'requires-capability',
			'paginated',
		);
	}
}
