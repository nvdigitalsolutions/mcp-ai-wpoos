<?php
/**
 * Tool for submitting quiz answers.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Submits answers for a quiz.
 */
class WP_MCP_AI_Tool_Submit_Quiz_Answer implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'submit_quiz_answer';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Submit Quiz Answer', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Submits answers for a quiz. Creates a submission record for grading.', 'mcp-ai-wpoos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Recording a student answer set for a quiz so it can be graded.', 'mcp-ai-wpoos-pro' ),
			'when_not_to_use' => __( 'Scoring; use grade_quiz after submission, and get_quiz_results to read outcomes.', 'mcp-ai-wpoos-pro' ),
			'related_tools'   => array( 'grade_quiz', 'get_quiz', 'get_quiz_results' ),
			'notes'           => __( 'Rate-limited to 5 submissions per 5 minutes per user; pass started_at to enforce time limits.', 'mcp-ai-wpoos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'quiz_id'    => array(
					'type'        => 'integer',
					'description' => __( 'The ID of the quiz being answered.', 'mcp-ai-wpoos-pro' ),
					'minimum'     => 1,
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
				),
				'answers'    => array(
					'type'        => 'array',
					'description' => __( 'Array of answers to quiz questions.', 'mcp-ai-wpoos-pro' ),
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'question_index' => array(
								'type'        => 'integer',
								'description' => __( 'Zero-based index of the question.', 'mcp-ai-wpoos-pro' ),
								'minimum'     => 0,
							),
							'answer'         => array(
								'type'        => 'string',
								'description' => __( 'The submitted answer.', 'mcp-ai-wpoos-pro' ),
							),
						),
						'required'   => array( 'question_index', 'answer' ),
					),
				),
				'user_id'    => array(
					'type'        => 'integer',
					'description' => __( 'User ID submitting the answers. Defaults to current user.', 'mcp-ai-wpoos-pro' ),
					'minimum'     => 1,
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
				),
				'started_at' => array(
					'type'        => 'string',
					'description' => __( 'ISO 8601 timestamp when the quiz was started. Used to validate time limits.', 'mcp-ai-wpoos-pro' ),
					'format'      => 'date-time',
				),
			),
			'required'             => array( 'quiz_id', 'answers' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$current_user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $current_user_id || ! user_can( $current_user_id, 'read' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to submit quiz answers.', 'mcp-ai-wpoos-pro' ) );
		}

		// Rate limiting: Check for too many submissions in a short time.
		$rate_limit_key     = 'wp_mcp_ai_quiz_submit_' . $current_user_id;
		$recent_submissions = get_transient( $rate_limit_key );

		if ( false === $recent_submissions ) {
			$recent_submissions = 0;
		}

		// Allow max 5 submissions per 5 minutes per user.
		if ( $recent_submissions >= 5 ) {
			return new WP_Error(
				'wp_mcp_ai_rate_limit_exceeded',
				__( 'Too many submission attempts. Please wait a few minutes before trying again.', 'mcp-ai-wpoos-pro' )
			);
		}

		$quiz_id    = isset( $arguments['quiz_id'] ) ? absint( $arguments['quiz_id'] ) : 0;
		$answers    = isset( $arguments['answers'] ) && is_array( $arguments['answers'] ) ? $arguments['answers'] : array();
		$user_id    = isset( $arguments['user_id'] ) ? absint( $arguments['user_id'] ) : $current_user_id;
		$started_at = isset( $arguments['started_at'] ) ? sanitize_text_field( $arguments['started_at'] ) : '';

		if ( ! $quiz_id ) {
			return new WP_Error( 'wp_mcp_ai_missing_quiz_id', __( 'Quiz ID is required.', 'mcp-ai-wpoos-pro' ) );
		}

		if ( empty( $answers ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_answers', __( 'At least one answer is required.', 'mcp-ai-wpoos-pro' ) );
		}

		$quiz = get_post( $quiz_id );

		if ( ! $quiz || 'mcp_ai_quiz' !== $quiz->post_type ) {
			return new WP_Error( 'wp_mcp_ai_quiz_not_found', __( 'Quiz not found.', 'mcp-ai-wpoos-pro' ) );
		}

		// Get quiz time limit.
		$time_limit = get_post_meta( $quiz_id, '_mcp_ai_quiz_time_limit', true );
		$time_limit = absint( $time_limit );

		// Validate time limit if quiz has one and started_at is provided.
		if ( $time_limit > 0 && $started_at ) {
			$started_timestamp = strtotime( $started_at );
			$current_timestamp = current_time( 'timestamp' );

			if ( false === $started_timestamp ) {
				return new WP_Error( 'wp_mcp_ai_invalid_timestamp', __( 'Invalid started_at timestamp format.', 'mcp-ai-wpoos-pro' ) );
			}

			// Calculate elapsed time in minutes.
			$elapsed_minutes = ( $current_timestamp - $started_timestamp ) / 60;

			// Allow 1 minute grace period for submission processing.
			if ( $elapsed_minutes > ( $time_limit + 1 ) ) {
				return new WP_Error(
					'wp_mcp_ai_time_limit_exceeded',
					sprintf(
						/* translators: 1: time limit, 2: elapsed time */
						__( 'Time limit exceeded. Quiz time limit: %1$d minutes. Time taken: %2$.1f minutes.', 'mcp-ai-wpoos-pro' ),
						$time_limit,
						$elapsed_minutes
					)
				);
			}
		} elseif ( $time_limit > 0 && ! $started_at ) {
			// Warn if time limit exists but no start time provided.
			return new WP_Error(
				'wp_mcp_ai_missing_start_time',
				sprintf(
					/* translators: %d: time limit in minutes */
					__( 'This quiz has a %d minute time limit. Please provide started_at timestamp.', 'mcp-ai-wpoos-pro' ),
					$time_limit
				)
			);
		}

		// Check if submitting for another user.
		if ( $user_id !== $current_user_id && ! user_can( $current_user_id, 'edit_users' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to submit on behalf of other users.', 'mcp-ai-wpoos-pro' ) );
		}

		// Validate submitted user exists.
		if ( ! get_userdata( $user_id ) ) {
			return new WP_Error( 'wp_mcp_ai_invalid_user', __( 'The specified user does not exist.', 'mcp-ai-wpoos-pro' ) );
		}

		// Check if submission already exists.
		$existing = get_posts(
			array(
				'post_type'   => 'mcp_ai_submission',
				'author'      => $user_id,
				'meta_key'    => '_mcp_ai_submission_quiz_id',
				'meta_value'  => $quiz_id,
				'post_status' => array( 'publish', 'pending' ),
				'numberposts' => 1,
			)
		);

		if ( ! empty( $existing ) ) {
			return new WP_Error( 'wp_mcp_ai_duplicate_submission', __( 'A submission for this quiz already exists.', 'mcp-ai-wpoos-pro' ) );
		}

		// Get quiz questions for validation.
		$questions = get_post_meta( $quiz_id, '_mcp_ai_quiz_questions', true );
		if ( ! is_array( $questions ) ) {
			$questions = array();
		}

		// Validate and sanitize answers.
		$sanitized_answers = array();
		foreach ( $answers as $answer_data ) {
			if ( ! isset( $answer_data['question_index'] ) || ! isset( $answer_data['answer'] ) ) {
				continue;
			}

			$question_index = absint( $answer_data['question_index'] );
			$answer_text    = sanitize_text_field( $answer_data['answer'] );

			// Validate question index exists.
			if ( ! isset( $questions[ $question_index ] ) ) {
				return new WP_Error(
					'wp_mcp_ai_invalid_question_index',
					sprintf(
						/* translators: %d: question index */
						__( 'Invalid question index: %d', 'mcp-ai-wpoos-pro' ),
						$question_index
					)
				);
			}

			$question = $questions[ $question_index ];

			// Validate answer based on question type.
			if ( isset( $question['type'] ) ) {
				switch ( $question['type'] ) {
					case 'true_false':
						// Validate true/false answer.
						$answer_lower = strtolower( trim( $answer_text ) );
						if ( ! in_array( $answer_lower, array( 'true', 'false', '1', '0', 'yes', 'no' ), true ) ) {
							return new WP_Error(
								'wp_mcp_ai_invalid_true_false_answer',
								sprintf(
									/* translators: %d: question index */
									__( 'Invalid true/false answer for question %d. Use: true, false, yes, no, 1, or 0.', 'mcp-ai-wpoos-pro' ),
									$question_index + 1
								)
							);
						}
						// Normalize to true/false.
						if ( in_array( $answer_lower, array( 'true', '1', 'yes' ), true ) ) {
							$answer_text = 'true';
						} else {
							$answer_text = 'false';
						}
						break;

					case 'multiple_choice':
						// Validate answer is one of the options.
						if ( isset( $question['options'] ) && is_array( $question['options'] ) ) {
							$valid_option = false;
							foreach ( $question['options'] as $option ) {
								if ( sanitize_text_field( $option ) === $answer_text ) {
									$valid_option = true;
									break;
								}
							}
							if ( ! $valid_option ) {
								return new WP_Error(
									'wp_mcp_ai_invalid_multiple_choice_answer',
									sprintf(
										/* translators: %d: question index */
										__( 'Answer for question %d is not one of the valid options.', 'mcp-ai-wpoos-pro' ),
										$question_index + 1
									)
								);
							}
						}
						break;

					case 'short_answer':
						// Short answer validation - just ensure not empty.
						if ( empty( trim( $answer_text ) ) ) {
							return new WP_Error(
								'wp_mcp_ai_empty_answer',
								sprintf(
									/* translators: %d: question index */
									__( 'Answer for question %d cannot be empty.', 'mcp-ai-wpoos-pro' ),
									$question_index + 1
								)
							);
						}
						break;
				}
			}

			$sanitized_answers[] = array(
				'question_index' => $question_index,
				'answer'         => $answer_text,
			);
		}

		// Ensure we have at least one valid answer.
		if ( empty( $sanitized_answers ) ) {
			return new WP_Error( 'wp_mcp_ai_no_valid_answers', __( 'No valid answers were provided.', 'mcp-ai-wpoos-pro' ) );
		}

		// Create submission post.
		$submission_data = array(
			'post_type'   => 'mcp_ai_submission',
			'post_title'  => sprintf(
				/* translators: 1: quiz title, 2: user display name */
				__( '%1$s - %2$s', 'mcp-ai-wpoos-pro' ),
				get_the_title( $quiz ),
				get_userdata( $user_id )->display_name
			),
			'post_status' => 'pending',
			'post_author' => $user_id,
		);

		$submission_id = wp_insert_post( $submission_data, true );

		if ( is_wp_error( $submission_id ) ) {
			return $submission_id;
		}

		// Get quiz total points for grading context.
		$total_points = get_post_meta( $quiz_id, '_mcp_ai_quiz_total_points', true );

		// Calculate completion time if started_at was provided.
		$completion_time_minutes = null;
		if ( $started_at ) {
			$started_timestamp       = strtotime( $started_at );
			$current_timestamp       = current_time( 'timestamp' );
			$completion_time_minutes = round( ( $current_timestamp - $started_timestamp ) / 60, 2 );
		}

		// Store submission metadata.
		update_post_meta( $submission_id, '_mcp_ai_submission_quiz_id', $quiz_id );
		update_post_meta( $submission_id, '_mcp_ai_submission_answers', $sanitized_answers );
		update_post_meta( $submission_id, '_mcp_ai_submission_status', 'pending' );
		update_post_meta( $submission_id, '_mcp_ai_submission_total_points', absint( $total_points ) );
		update_post_meta( $submission_id, '_mcp_ai_submission_submitted_at', current_time( 'mysql' ) );

		// Store time tracking data.
		if ( $started_at ) {
			update_post_meta( $submission_id, '_mcp_ai_submission_started_at', $started_at );
		}
		if ( null !== $completion_time_minutes ) {
			update_post_meta( $submission_id, '_mcp_ai_submission_completion_time', $completion_time_minutes );
		}

		// Store IP address for anti-cheating measures.
		$ip_address = $this->get_client_ip();
		if ( $ip_address ) {
			update_post_meta( $submission_id, '_mcp_ai_submission_ip_address', $ip_address );
		}

		$submission = get_post( $submission_id );

		$result = array(
			'summary'       => sprintf(
				/* translators: %s: quiz title */
				__( 'Quiz submission created for: %s', 'mcp-ai-wpoos-pro' ),
				get_the_title( $quiz )
			),
			'submission_id' => $submission_id,
			'quiz_id'       => $quiz_id,
			'user_id'       => $user_id,
			'answer_count'  => count( $sanitized_answers ),
			'status'        => 'pending',
			'submitted_at'  => $submission->post_date,
		);

		// Add time tracking information if available.
		if ( $time_limit > 0 ) {
			$result['time_limit'] = $time_limit;
		}
		if ( $started_at ) {
			$result['started_at'] = $started_at;
		}
		if ( null !== $completion_time_minutes ) {
			$result['completion_time_minutes'] = $completion_time_minutes;
		}

		// Increment rate limit counter (5 minutes window).
		set_transient( $rate_limit_key, $recent_submissions + 1, 5 * MINUTE_IN_SECONDS );

		return $result;
	}

	/**
	 * Get client IP address for anti-cheating measures.
	 *
	 * @return string Client IP address.
	 */
	private function get_client_ip() {
		return wp_mcp_ai_get_client_ip();
	}

	/**
	 * {@inheritdoc}
	 */

	/**
	 * Get extended tool definition including toolkit metadata.
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {
		return array(
			'name'                  => $this->get_name(),
			'description'           => $this->get_description(),
			'toolkit'               => 'education',
			'post_type'             => 'mcp_ai_quiz',
			'pattern_compatibility' => array( 'orchestrator', 'sequential' ),
			'profession_tags'       => array( 'student', 'learner' ),
			'risk_level'            => 'standard',
		);
	}

		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array(
			'pro',
			'write',
			'local-only',
			'requires-capability',
			'state-changing',
		);
	}
}
