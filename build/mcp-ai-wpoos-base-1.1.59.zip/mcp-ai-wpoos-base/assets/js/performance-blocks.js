/**
 * Gutenberg blocks for NV oOS Performance Monitoring.
 *
 * Registers performance monitoring blocks in the block editor.
 *
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

( function( blocks, element, editor, components ) {
	const el = element.createElement;
	const registerBlockType = blocks.registerBlockType;
	const _InspectorControls = editor.InspectorControls;
	const _TextControl = components.TextControl;
	const _SelectControl = components.SelectControl;
	const _ToggleControl = components.ToggleControl;
	const _PanelBody = components.PanelBody;

	/**
	 * Register Performance Test Runner Block.
	 */
	registerBlockType( 'mcp-ai-wpoos/performance-test-runner', {
		apiVersion: 3,
		title: 'Performance Test Runner',
		icon: 'performance',
		category: 'widgets',
		attributes: {
			title: {
				type: 'string',
				default: 'Performance Test Runner'
			},
			enabledTests: {
				type: 'array',
				default: [ 'stress', 'security', 'speed', 'optimization' ]
			}
		},
		edit: function( props ) {
			return el(
				'div',
				{ className: props.className },
				el( 'h3', {}, props.attributes.title ),
				el( 'p', {}, 'Performance test runner will be displayed here.' )
			);
		},
		save: function() {
			return null; // Rendered server-side
		}
	} );

	/**
	 * Register Performance Metrics Block.
	 */
	registerBlockType( 'mcp-ai-wpoos/performance-metrics', {
		apiVersion: 3,
		title: 'Performance Metrics',
		icon: 'dashboard',
		category: 'widgets',
		attributes: {
			title: {
				type: 'string',
				default: 'Performance Metrics'
			},
			component: {
				type: 'string',
				default: ''
			},
			timePeriod: {
				type: 'string',
				default: '-24 hours'
			}
		},
		edit: function( props ) {
			return el(
				'div',
				{ className: props.className },
				el( 'h3', {}, props.attributes.title ),
				el( 'p', {}, 'Performance metrics will be displayed here.' )
			);
		},
		save: function() {
			return null; // Rendered server-side
		}
	} );

	/**
	 * Register System Health Status Block.
	 */
	registerBlockType( 'mcp-ai-wpoos/system-health-status', {
		apiVersion: 3,
		title: 'System Health Status',
		icon: 'heart',
		category: 'widgets',
		attributes: {
			title: {
				type: 'string',
				default: 'System Health Status'
			},
			showBreakdown: {
				type: 'boolean',
				default: true
			}
		},
		edit: function( props ) {
			return el(
				'div',
				{ className: props.className },
				el( 'h3', {}, props.attributes.title ),
				el( 'p', {}, 'System health status will be displayed here.' )
			);
		},
		save: function() {
			return null; // Rendered server-side
		}
	} );

	/**
	 * Register Test Results Table Block.
	 */
	registerBlockType( 'mcp-ai-wpoos/test-results-table', {
		apiVersion: 3,
		title: 'Test Results Table',
		icon: 'list-view',
		category: 'widgets',
		attributes: {
			title: {
				type: 'string',
				default: 'Test Results'
			},
			testType: {
				type: 'string',
				default: ''
			},
			limit: {
				type: 'number',
				default: 10
			}
		},
		edit: function( props ) {
			return el(
				'div',
				{ className: props.className },
				el( 'h3', {}, props.attributes.title ),
				el( 'p', {}, 'Test results table will be displayed here.' )
			);
		},
		save: function() {
			return null; // Rendered server-side
		}
	} );

	/**
	 * Register Performance Recommendations Block.
	 */
	registerBlockType( 'mcp-ai-wpoos/performance-recommendations', {
		apiVersion: 3,
		title: 'Performance Recommendations',
		icon: 'lightbulb',
		category: 'widgets',
		attributes: {
			title: {
				type: 'string',
				default: 'Performance Recommendations'
			},
			severity: {
				type: 'string',
				default: 'all'
			},
			limit: {
				type: 'number',
				default: 5
			}
		},
		edit: function( props ) {
			return el(
				'div',
				{ className: props.className },
				el( 'h3', {}, props.attributes.title ),
				el( 'p', {}, 'AI recommendations will be displayed here.' )
			);
		},
		save: function() {
			return null; // Rendered server-side
		}
	} );

	/**
	 * Register Performance Trends Block.
	 */
	registerBlockType( 'mcp-ai-wpoos/performance-trends', {
		apiVersion: 3,
		title: 'Performance Trends',
		icon: 'chart-line',
		category: 'widgets',
		attributes: {
			title: {
				type: 'string',
				default: 'Performance Trends'
			},
			component: {
				type: 'string',
				default: 'rest_api'
			},
			timePeriod: {
				type: 'string',
				default: '-7 days'
			}
		},
		edit: function( props ) {
			return el(
				'div',
				{ className: props.className },
				el( 'h3', {}, props.attributes.title ),
				el( 'p', {}, 'Performance trends chart will be displayed here.' )
			);
		},
		save: function() {
			return null; // Rendered server-side
		}
	} );

} )( window.wp.blocks, window.wp.element, window.wp.editor, window.wp.components );
