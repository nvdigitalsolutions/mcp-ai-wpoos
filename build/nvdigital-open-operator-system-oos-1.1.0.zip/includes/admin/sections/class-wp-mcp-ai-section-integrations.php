<?php
/**
 * Integrations Settings Section
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Section_Integrations' ) ) {
	/**
	 * Integrations settings section - External Tools.
	 */
	class WP_MCP_AI_Section_Integrations extends WP_MCP_AI_Settings_Section {
		/**
		 * Get section ID.
		 *
		 * @return string
		 */
		public function get_id() {
			return 'integrations_gmail_crawl4ai';
		}

		/**
		 * Get section title.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'External Tools', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * Get tab ID.
		 *
		 * This section is integrated within the Tools tab under the Connections subtab.
		 *
		 * @return string
		 */
		public function get_tab() {
			return 'tools';
		}

		/**
		 * Get section description.
		 *
		 * @return string
		 */
		public function get_description() {
			return __( 'Configure third-party service integrations including search APIs, email services, cloud platforms, web crawlers, and social media.', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * Get documentation URL for this section.
		 *
		 * @return string
		 */
		public function get_documentation_url() {
			return 'https://github.com/nvdigitalsolutions/mcp-ai-wpoos/blob/main/docs/architecture/integrations/oauth-settings-architecture.md';
		}

		/**
		 * Get section priority.
		 *
		 * @return int
		 */
		public function get_priority() {
			return 20;
		}

		/**
		 * Get field definitions.
		 *
		 * @return array
		 */
		public function get_fields() {
			$is_pro_active = defined( 'WP_MCP_AI_PRO_VERSION' );
			$gmail_notice  = $is_pro_active ? ' <em>' . __( '(Pro also supports multiple connections via Remote Sites.)', 'nvdigital-open-operator-system-oos' ) . '</em>' : ' <em>' . __( '(Base supports 1 connection. Pro enables multiple via Remote Sites.)', 'nvdigital-open-operator-system-oos' ) . '</em>';
			$drive_notice  = $is_pro_active ? ' <em>' . __( '(Pro also supports multiple connections via Remote Sites.)', 'nvdigital-open-operator-system-oos' ) . '</em>' : ' <em>' . __( '(Base supports 1 connection. Pro enables multiple via Remote Sites.)', 'nvdigital-open-operator-system-oos' ) . '</em>';
			$pro_notice    = $is_pro_active ? '' : ' <em>' . __( '(Pro Version required)', 'nvdigital-open-operator-system-oos' ) . '</em>';

			return array(
				// Gmail OAuth.
				'gmail_client_id'                   => array(
					'type'         => 'text',
					'label'        => __( 'Gmail OAuth Client ID', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client ID from Google Cloud Console for Gmail integration.', 'nvdigital-open-operator-system-oos' ) . $gmail_notice,
					'placeholder'  => '',
					'autocomplete' => 'off',
				),
				'gmail_client_secret'               => array(
					'type'         => 'password',
					'label'        => __( 'Gmail OAuth Client Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client Secret from Google Cloud Console.', 'nvdigital-open-operator-system-oos' ) . $gmail_notice,
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Google Drive OAuth.
				'google_drive_client_id'            => array(
					'type'         => 'text',
					'label'        => __( 'Google Drive OAuth Client ID', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client ID from Google Cloud Console for Google Drive integration.', 'nvdigital-open-operator-system-oos' ) . $drive_notice,
					'placeholder'  => '',
					'autocomplete' => 'off',
				),
				'google_drive_client_secret'        => array(
					'type'         => 'password',
					'label'        => __( 'Google Drive OAuth Client Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client Secret from Google Cloud Console.', 'nvdigital-open-operator-system-oos' ) . $drive_notice,
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Crawl4AI.
				'crawl4ai_base_url'                 => array(
					'type'         => 'url',
					'label'        => __( 'Crawl4AI Base URL', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Base URL for Crawl4AI service (if using external crawler).', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => 'http://localhost:8000',
					'autocomplete' => 'url',
				),
				'crawl4ai_api_key'                  => array(
					'type'         => 'password',
					'label'        => __( 'Crawl4AI API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'API key for Crawl4AI service (if required).', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Brave Search.
				'brave_search_api_key'              => array(
					'type'         => 'password',
					'label'        => __( 'Brave Search API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to Brave Search API */
						__( 'API key for Brave Search integration. Get your API key from %s.', 'nvdigital-open-operator-system-oos' ),
						'<a href="https://brave.com/search/api/" target="_blank">Brave Search API</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Mubert Music API.
				'mubert_api_key'                    => array(
					'type'         => 'password',
					'label'        => __( 'Mubert API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to Mubert contact */
						__( 'API key for Mubert music generation service. Request an API key from %s.', 'nvdigital-open-operator-system-oos' ),
						'<a href="mailto:business@mubert.com">business@mubert.com</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Cloudflare.
				'cloudflare_api_token'              => array(
					'type'         => 'password',
					'label'        => __( 'Cloudflare API Token', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'API token for Cloudflare integration. Create a token in your Cloudflare dashboard.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'cloudflare_zone_id'                => array(
					'type'        => 'text',
					'label'       => __( 'Cloudflare Zone ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Cloudflare zone ID for cache management.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'enable_cloudflare_pro_toolkit'     => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Cloudflare Pro Toolkit', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable Cloudflare advanced features and integrations (Pro Version only)', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Enables AI-powered Cloudflare integration toolkit including cache purging, zone management, DNS operations, and advanced CDN features. Provides additional tools for managing Cloudflare services through AI assistants. Requires Cloudflare API Token and Zone ID to be configured. This feature is only available in the Pro addon.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),

				// Cloudways.
				'cloudways_api_key'                 => array(
					'type'         => 'password',
					'label'        => __( 'Cloudways API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'API key for Cloudways hosting integration.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'cloudways_email'                   => array(
					'type'        => 'email',
					'label'       => __( 'Cloudways Account Email', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Email address associated with your Cloudways account.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => 'you@example.com',
				),
				'cloudways_server_id'               => array(
					'type'        => 'text',
					'label'       => __( 'Cloudways Server ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Cloudways server identifier for server management operations. Find this in your Cloudways dashboard under Servers.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'cloudways_app_id'                  => array(
					'type'        => 'text',
					'label'       => __( 'Cloudways Application ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Cloudways application identifier for app-specific operations. Find this in your Cloudways dashboard under Applications.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),

				// Mailjet.
				'mailjet_api_key'                   => array(
					'type'         => 'password',
					'label'        => __( 'Mailjet API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Get this from your Mailjet account under API Keys.', 'nvdigital-open-operator-system-oos' ) . $pro_notice,
					'placeholder'  => '',
					'autocomplete' => 'new-password',
					'disabled'     => ! $is_pro_active,
				),
				'mailjet_api_secret'                => array(
					'type'         => 'password',
					'label'        => __( 'Mailjet Secret Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Mailjet uses Basic Authentication (API Key + Secret Key), not OAuth.', 'nvdigital-open-operator-system-oos' ) . $pro_notice,
					'placeholder'  => '',
					'autocomplete' => 'new-password',
					'disabled'     => ! $is_pro_active,
				),
				'mailjet_from_email'                => array(
					'type'        => 'email',
					'label'       => __( 'Mailjet From Email', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Default "from" email address for Mailjet messages. Must be a verified sender in your Mailjet account.', 'nvdigital-open-operator-system-oos' ) . $pro_notice,
					'placeholder' => 'noreply@example.com',
					'disabled'    => ! $is_pro_active,
				),
				'mailjet_from_name'                 => array(
					'type'        => 'text',
					'label'       => __( 'Mailjet From Name', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Default "from" name for Mailjet messages.', 'nvdigital-open-operator-system-oos' ) . $pro_notice,
					'placeholder' => 'My Site',
					'disabled'    => ! $is_pro_active,
				),
				'mailjet_webhook_secret'            => array(
					'type'         => 'password',
					'label'        => __( 'Mailjet Webhook Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Optional secret for verifying webhook requests from Mailjet.', 'nvdigital-open-operator-system-oos' ) . $pro_notice,
					'placeholder'  => '',
					'autocomplete' => 'new-password',
					'disabled'     => ! $is_pro_active,
				),

				// remove.bg API.
				'removebg_api_key'                  => array(
					'type'         => 'password',
					'label'        => __( 'remove.bg API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to remove.bg API */
						__( 'API key for remove.bg background removal service. Get your API key from %s. Note: A free tier with Python rembg is also available without an API key.', 'nvdigital-open-operator-system-oos' ),
						'<a href="https://www.remove.bg/api" target="_blank">remove.bg API</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// PayHere, Flowhub, iSAMS, and QuickBooks connections have been moved to Remote Sites.
				// These settings have been removed. Please use Remote Sites page to manage these connections.

				// Google Analytics.
				'google_analytics_property_id'      => array(
					'type'        => 'text',
					'label'       => __( 'Google Analytics Property ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Google Analytics 4 Property ID (e.g., 123456789).', 'nvdigital-open-operator-system-oos' ) . $pro_notice,
					'placeholder' => '123456789',
					'disabled'    => ! $is_pro_active,
				),
				'google_analytics_credentials'      => array(
					'type'        => 'textarea',
					'label'       => __( 'Google Analytics Service Account JSON (Legacy)', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Service account credentials in JSON format from Google Cloud Console. This field is being phased out in favor of google_analytics_credentials_json.', 'nvdigital-open-operator-system-oos' ) . $pro_notice,
					'placeholder' => '{"type": "service_account", ...}',
					'disabled'    => ! $is_pro_active,
					'rows'        => 5,
				),
				'google_analytics_credentials_json' => array(
					'type'        => 'textarea',
					'label'       => __( 'Google Analytics 4 Credentials JSON', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Service account JSON credentials file for Google Analytics 4 API access. Download from Google Cloud Console → IAM & Admin → Service Accounts. The JSON must be valid and contain type, project_id, private_key, and client_email fields.', 'nvdigital-open-operator-system-oos' ) . $pro_notice,
					'placeholder' => '{"type": "service_account", "project_id": "your-project", ...}',
					'disabled'    => ! $is_pro_active,
					'rows'        => 8,
				),

				// ITA Tariff Rate API.
				'ita_tariff_api_key'                => array(
					'type'         => 'password',
					'label'        => __( 'ITA Tariff Rate API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to ITA API */
						__( 'API key for International Trade Administration Tariff Rate API. Get your API key from %s. Used for import/export tariff information and trade compliance.', 'nvdigital-open-operator-system-oos' ),
						'<a href="https://developer.trade.gov/" target="_blank">Trade.gov Developer Portal</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Meta.
				'meta_access_token'                 => array(
					'type'         => 'password',
					'label'        => __( 'Meta Access Token', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Long-lived access token for Meta Graph API. Used for Facebook, Instagram, and WhatsApp integrations.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'meta_app_id'                       => array(
					'type'        => 'text',
					'label'       => __( 'Meta App ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Meta (Facebook) App ID.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'meta_app_secret'                   => array(
					'type'         => 'password',
					'label'        => __( 'Meta App Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Your Meta (Facebook) App Secret.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'meta_business_account_id'          => array(
					'type'        => 'text',
					'label'       => __( 'Meta Business Account ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Meta Business Account ID (for WhatsApp Business API).', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'meta_connected_user_name'          => array(
					'type'        => 'hidden',
					'label'       => '',
					'description' => '',
				),
				'meta_connected_user_id'            => array(
					'type'        => 'hidden',
					'label'       => '',
					'description' => '',
				),

				// TikTok.
				'tiktok_access_token'               => array(
					'type'         => 'password',
					'label'        => __( 'TikTok Access Token', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Access token for TikTok Open API with video.share scope.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'tiktok_client_key'                 => array(
					'type'        => 'text',
					'label'       => __( 'TikTok Client Key', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Client Key from TikTok developer portal.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'tiktok_client_secret'              => array(
					'type'         => 'password',
					'label'        => __( 'TikTok Client Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Client Secret from TikTok developer portal.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Yahoo Fantasy Sports.
				'yahoo_client_id'                   => array(
					'type'         => 'text',
					'label'        => __( 'Yahoo Client ID', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to Yahoo Developer */
						__( 'OAuth 2.0 Client ID (Consumer Key) from Yahoo Developer Network for Yahoo Fantasy Sports API. Get your credentials from %s. Used for fantasy football league management, roster analysis, and player statistics.', 'nvdigital-open-operator-system-oos' ),
						'<a href="https://developer.yahoo.com/apps/" target="_blank">Yahoo Developer Network</a>'
					) . $pro_notice,
					'placeholder'  => '',
					'autocomplete' => 'off',
					'disabled'     => ! $is_pro_active,
				),
				'yahoo_client_secret'               => array(
					'type'         => 'password',
					'label'        => __( 'Yahoo Client Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client Secret (Consumer Secret) from Yahoo Developer Network.', 'nvdigital-open-operator-system-oos' ) . $pro_notice,
					'placeholder'  => '',
					'autocomplete' => 'new-password',
					'disabled'     => ! $is_pro_active,
				),

				// iSAMS, PayHere, Flowhub, and QuickBooks have been moved to Remote Sites.
				// Use admin.php?page=wp-mcp-ai-remote-sites to manage these connections.
			);
		}

		/**
		 * Get sub-tab groups configuration.
		 *
		 * @return array
		 */
		protected function get_subtab_groups() {
			$is_pro_active = defined( 'WP_MCP_AI_PRO_VERSION' );

			return array(
				'gmail'            => array(
					'id'     => 'gmail',
					'label'  => $is_pro_active ? __( 'Gmail', 'nvdigital-open-operator-system-oos' ) : __( 'Gmail (Pro)', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-email',
					'fields' => array( 'gmail_client_id', 'gmail_client_secret' ),
					'pro'    => true,
				),
				'google_drive'     => array(
					'id'     => 'google_drive',
					'label'  => $is_pro_active ? __( 'Google Drive', 'nvdigital-open-operator-system-oos' ) : __( 'Google Drive (Pro)', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-cloud',
					'fields' => array( 'google_drive_client_id', 'google_drive_client_secret' ),
					'pro'    => true,
				),
				'crawl4ai'         => array(
					'id'     => 'crawl4ai',
					'label'  => __( 'Crawl4AI', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-search',
					'fields' => array( 'crawl4ai_base_url', 'crawl4ai_api_key' ),
				),
				'brave_search'     => array(
					'id'     => 'brave_search',
					'label'  => __( 'Brave Search', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-search',
					'fields' => array( 'brave_search_api_key' ),
				),
				'mubert'           => array(
					'id'     => 'mubert',
					'label'  => __( 'Mubert', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-format-audio',
					'fields' => array( 'mubert_api_key' ),
				),
				// PayHere, Flowhub, iSAMS, and QuickBooks have been moved to Remote Sites.
				'removebg'         => array(
					'id'     => 'removebg',
					'label'  => __( 'remove.bg', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-format-image',
					'fields' => array( 'removebg_api_key' ),
				),
				'cloudflare'       => array(
					'id'     => 'cloudflare',
					'label'  => __( 'Cloudflare', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-cloud',
					'fields' => array( 'cloudflare_api_token', 'cloudflare_zone_id', 'enable_cloudflare_pro_toolkit' ),
				),
				'cloudways'        => array(
					'id'     => 'cloudways',
					'label'  => __( 'Cloudways', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-cloud-upload',
					'fields' => array( 'cloudways_api_key', 'cloudways_email', 'cloudways_server_id', 'cloudways_app_id' ),
				),
				'mailjet'          => array(
					'id'     => 'mailjet',
					'label'  => $is_pro_active ? __( 'Mailjet', 'nvdigital-open-operator-system-oos' ) : __( 'Mailjet (Pro)', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-email-alt',
					'fields' => array( 'mailjet_api_key', 'mailjet_api_secret', 'mailjet_from_email', 'mailjet_from_name', 'mailjet_webhook_secret' ),
					'pro'    => true,
				),
				// QuickBooks and iSAMS moved to Remote Sites.
				'google_analytics' => array(
					'id'     => 'google_analytics',
					'label'  => $is_pro_active ? __( 'Google Analytics', 'nvdigital-open-operator-system-oos' ) : __( 'Google Analytics (Pro)', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-chart-bar',
					'fields' => array( 'google_analytics_property_id', 'google_analytics_credentials', 'google_analytics_credentials_json' ),
					'pro'    => true,
				),
				'ita_tariff'       => array(
					'id'     => 'ita_tariff',
					'label'  => $is_pro_active ? __( 'Trade.gov Tariff Rates', 'nvdigital-open-operator-system-oos' ) : __( 'Trade.gov Tariff Rates (Pro)', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-admin-site',
					'fields' => array( 'ita_tariff_api_key' ),
					'pro'    => true,
				),
				'meta'             => array(
					'id'     => 'meta',
					'label'  => __( 'Meta', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-share',
					'fields' => array( 'meta_access_token', 'meta_app_id', 'meta_app_secret', 'meta_business_account_id', 'meta_connected_user_name', 'meta_connected_user_id' ),
				),
				'tiktok'           => array(
					'id'     => 'tiktok',
					'label'  => __( 'TikTok', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-video-alt3',
					'fields' => array( 'tiktok_access_token', 'tiktok_client_key', 'tiktok_client_secret' ),
				),
				'yahoo_sports'     => array(
					'id'     => 'yahoo_sports',
					'label'  => $is_pro_active ? __( 'Yahoo Sports', 'nvdigital-open-operator-system-oos' ) : __( 'Yahoo Sports (Pro)', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-awards',
					'fields' => array( 'yahoo_client_id', 'yahoo_client_secret' ),
					'pro'    => true,
				),
				// iSAMS moved to Remote Sites.
			);
		}

		/**
		 * Get active sub-tab.
		 *
		 * @return string
		 */
		protected function get_active_subtab() {
			$subtab        = '';
			$subtab_groups = $this->get_subtab_groups();

			// Check POST data first (when form is being submitted), then fall back to GET.
			// Use section-specific field name to avoid conflicts with other sections.
			// phpcs:disable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only parameter check for UI state.
			$subtab_field_name = 'subtab_' . $this->get_id();
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
			if ( isset( $_POST[ $subtab_field_name ] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
				$subtab = sanitize_key( $_POST[ $subtab_field_name ] );
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
			} elseif ( isset( $_POST['connection'] ) ) {
				// Legacy parameter for backwards compatibility.
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
				$subtab = sanitize_key( $_POST['connection'] );
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			} elseif ( isset( $_GET['connection'] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
				$subtab = sanitize_key( $_GET['connection'] );
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
			} elseif ( isset( $_POST['subtab'] ) ) {
				// Fallback to legacy field name for backward compatibility.
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
				$subtab = sanitize_key( $_POST['subtab'] );
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			} elseif ( isset( $_GET['subtab'] ) ) {
				// Only use 'subtab' if it's one of our integration subtabs.

				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
				$potential_subtab = sanitize_key( $_GET['subtab'] );
				if ( isset( $subtab_groups[ $potential_subtab ] ) ) {
					$subtab = $potential_subtab;
				}
			}
			// phpcs:enable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended

			// Default to 'gmail' if not set or invalid.
			if ( empty( $subtab ) || ! isset( $subtab_groups[ $subtab ] ) ) {
				$subtab = 'gmail';
			}

			return $subtab;
		}

		/**
		 * Render section fields.
		 */
		public function render() {
			$fields        = $this->get_fields();
			$subtab_groups = $this->get_subtab_groups();
			$active_subtab = $this->get_active_subtab();

			// Get the active group.
			if ( ! isset( $subtab_groups[ $active_subtab ] ) ) {
				return;
			}

			$active_group = $subtab_groups[ $active_subtab ];

			// Render fields for the active sub-tab.
			foreach ( $active_group['fields'] as $key ) {
				if ( isset( $fields[ $key ] ) ) {
					$this->render_field( $key, $fields[ $key ] );
				}
			}

			// Render additional content based on active sub-tab.
			$this->render_subtab_footer( $active_subtab );
		}

		/**
		 * Render footer content for specific sub-tabs.
		 *
		 * @param string $subtab Active sub-tab ID.
		 */
		private function render_subtab_footer( $subtab ) {
			switch ( $subtab ) {
				case 'gmail':
					$this->render_gmail_footer();
					break;
				case 'google_drive':
					$this->render_google_drive_footer();
					break;
				case 'brave_search':
					$this->render_brave_search_footer();
					break;
				case 'mubert':
					$this->render_mubert_footer();
					break;
				// PayHere, Flowhub, QuickBooks, and iSAMS moved to Remote Sites.
				case 'meta':
					$this->render_meta_footer();
					break;
				case 'tiktok':
					$this->render_tiktok_footer();
					break;
				// QuickBooks and iSAMS moved to Remote Sites.
				case 'cloudways':
					$this->render_cloudways_footer();
					break;
				case 'cloudflare':
					$this->render_cloudflare_footer();
					break;
				case 'mailjet':
					$this->render_mailjet_footer();
					break;
				// iSAMS moved to Remote Sites.
			}
		}

		/**
		 * Render Gmail footer content.
		 */
		/**
		 * Render Gmail footer content.
		 */
		private function render_gmail_footer() {
			$settings          = WP_MCP_AI_Admin_Settings::get_settings();
			$gmail_connected   = ! empty( $settings['gmail_refresh_token'] );
			$gmail_email       = isset( $settings['gmail_user_email'] ) ? $settings['gmail_user_email'] : '';
			$has_credentials   = ! empty( $settings['gmail_client_id'] ) && ! empty( $settings['gmail_client_secret'] );
			$is_pro_active     = defined( 'WP_MCP_AI_PRO_VERSION' );
			$oauth_connect_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_gmail_oauth_start' ),
				'wp_mcp_ai_gmail_oauth_start'
			);

			// Check for success or error messages.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$gmail_success = isset( $_GET['gmail_success'] ) ? sanitize_text_field( wp_unslash( $_GET['gmail_success'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$gmail_error = isset( $_GET['gmail_error'] ) ? sanitize_text_field( wp_unslash( $_GET['gmail_error'] ) ) : '';
			?>
			<?php if ( $gmail_success ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-success inline" style="margin: 0 0 15px;">
						<p><?php echo esc_html( $gmail_success ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
			<?php if ( $gmail_error ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-error inline" style="margin: 0 0 15px;">
						<p><?php echo esc_html( $gmail_error ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
		<tr>
			<th scope="row"><?php esc_html_e( 'Gmail Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td>
				<?php if ( $gmail_connected ) : ?>
					<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #155724;">
							<span class="dashicons dashicons-yes" style="color: #155724;"></span>
							<strong><?php esc_html_e( 'Connected to Gmail', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<?php if ( $gmail_email ) : ?>
								<?php
								printf(
									/* translators: %s: Gmail email address */
									esc_html__( 'as %s', 'nvdigital-open-operator-system-oos' ),
									'<code>' . esc_html( $gmail_email ) . '</code>'
								);
								?>
							<?php endif; ?>
						</p>
					</div>
					<p>
						<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button">
							<?php esc_html_e( 'Reconnect Gmail Account', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</p>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'Your Gmail account is connected. You can now use Gmail integration tools to search and read emails.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
				<?php elseif ( $has_credentials ) : ?>
					<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #856404;">
							<span class="dashicons dashicons-warning" style="color: #856404;"></span>
							<strong><?php esc_html_e( 'Gmail Not Connected', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
					</div>
					<p>
						<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button button-primary">
							<?php esc_html_e( 'Connect Gmail Account', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</p>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'Click the button above to authorize WP MCP AI to access your Gmail account. You will be redirected to Google to grant permissions.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
					<p class="description">
						<strong><?php esc_html_e( 'Required Permissions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><code>gmail.readonly</code>: <?php esc_html_e( 'Read access to Gmail messages and settings', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				<?php else : ?>
					<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #721c24;">
							<span class="dashicons dashicons-info" style="color: #721c24;"></span>
							<strong><?php esc_html_e( 'Gmail OAuth Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
					</div>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'To connect your Gmail account, first configure your Gmail OAuth Client ID and Client Secret in the fields above, then save your settings.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
					<p class="description">
						<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li>
							<?php
							printf(
								/* translators: %s: URL to Google Cloud Console */
								wp_kses_post( __( 'Go to <a href="%s" target="_blank">Google Cloud Console</a>', 'nvdigital-open-operator-system-oos' ) ),
								esc_url( 'https://console.cloud.google.com/' )
							);
							?>
						</li>
						<li><?php esc_html_e( 'Create a new project or select an existing one', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Enable the Gmail API for your project', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Create OAuth 2.0 credentials (Web application type)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li>
							<?php
							$gmail_redirect_uri = add_query_arg(
								array( 'wp_mcp_ai_oauth' => 'gmail_callback' ),
								admin_url( 'admin.php' )
							);
							printf(
								/* translators: %s: Callback URL */
								esc_html__( 'Set Authorized redirect URI to: %s', 'nvdigital-open-operator-system-oos' ),
								'<br><code>' . esc_html( $gmail_redirect_uri ) . '</code>'
							);
							?>
						</li>
						<li><?php esc_html_e( 'Copy the Client ID and Client Secret to the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Click the "Connect Gmail Account" button that will appear', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<th scope="row"></th>
			<td>
				<p class="description">
					<strong><?php esc_html_e( 'About Gmail Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				</p>
				<ul style="list-style: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'OAuth 2.0 credentials are obtained from Google Cloud Console', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Access tokens are automatically refreshed when expired', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Supports searching and reading Gmail messages', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Requires gmail.readonly scope for read access', 'nvdigital-open-operator-system-oos' ); ?></li>
				</ul>
			</td>
		</tr>
			<?php
		}

		/**
		 * Render Google Drive footer content.
		 */
		private function render_google_drive_footer() {
			$settings          = WP_MCP_AI_Admin_Settings::get_settings();
			$drive_connected   = ! empty( $settings['google_drive_refresh_token'] );
			$drive_email       = isset( $settings['google_drive_user_email'] ) ? $settings['google_drive_user_email'] : '';
			$has_credentials   = ! empty( $settings['google_drive_client_id'] ) && ! empty( $settings['google_drive_client_secret'] );
			$is_pro_active     = defined( 'WP_MCP_AI_PRO_VERSION' );
			$oauth_connect_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_google_drive_oauth_start' ),
				'wp_mcp_ai_google_drive_oauth_start'
			);

			// Check for success or error messages.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$drive_success = isset( $_GET['drive_success'] ) ? sanitize_text_field( wp_unslash( $_GET['drive_success'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$drive_error = isset( $_GET['drive_error'] ) ? sanitize_text_field( wp_unslash( $_GET['drive_error'] ) ) : '';
			?>
			<?php if ( $drive_success ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-success inline" style="margin: 0 0 15px;">
						<p><?php echo esc_html( $drive_success ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
			<?php if ( $drive_error ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-error inline" style="margin: 0 0 15px;">
						<p><?php echo esc_html( $drive_error ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
		<tr>
			<th scope="row"><?php esc_html_e( 'Google Drive Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td>
				<?php if ( $drive_connected ) : ?>
					<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #155724;">
							<span class="dashicons dashicons-yes" style="color: #155724;"></span>
							<strong><?php esc_html_e( 'Connected to Google Drive', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<?php if ( $drive_email ) : ?>
								<?php
								printf(
									/* translators: %s: Google account email address */
									esc_html__( 'as %s', 'nvdigital-open-operator-system-oos' ),
									'<code>' . esc_html( $drive_email ) . '</code>'
								);
								?>
							<?php endif; ?>
						</p>
					</div>
					<p>
						<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button">
							<?php esc_html_e( 'Reconnect Google Drive Account', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</p>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'Your Google Drive account is connected. You can now use Google Drive integration tools to search and read files.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
				<?php elseif ( $has_credentials ) : ?>
					<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #856404;">
							<span class="dashicons dashicons-warning" style="color: #856404;"></span>
							<strong><?php esc_html_e( 'Google Drive Not Connected', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
					</div>
					<p>
						<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button button-primary">
							<?php esc_html_e( 'Connect Google Drive Account', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</p>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'Click the button above to authorize WP MCP AI to access your Google Drive account. You will be redirected to Google to grant permissions.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
					<p class="description">
						<strong><?php esc_html_e( 'Required Permissions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><code>drive.readonly</code>: <?php esc_html_e( 'Read access to Drive files', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><code>drive.metadata.readonly</code>: <?php esc_html_e( 'Read access to Drive file metadata', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				<?php else : ?>
					<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #721c24;">
							<span class="dashicons dashicons-info" style="color: #721c24;"></span>
							<strong><?php esc_html_e( 'Google Drive OAuth Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
					</div>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'To connect your Google Drive account, first configure your Google Drive OAuth Client ID and Client Secret in the fields above, then save your settings.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
					<p class="description">
						<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li>
							<?php
							printf(
								/* translators: %s: URL to Google Cloud Console */
								wp_kses_post( __( 'Go to <a href="%s" target="_blank">Google Cloud Console</a>', 'nvdigital-open-operator-system-oos' ) ),
								esc_url( 'https://console.cloud.google.com/' )
							);
							?>
						</li>
						<li><?php esc_html_e( 'Create a new project or select an existing one', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Enable the Google Drive API for your project', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Create OAuth 2.0 credentials (Web application type)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li>
							<?php
							$drive_redirect_uri = add_query_arg(
								array( 'wp_mcp_ai_oauth' => 'google_drive_callback' ),
								admin_url( 'admin.php' )
							);
							printf(
								/* translators: %s: Callback URL */
								esc_html__( 'Set Authorized redirect URI to: %s', 'nvdigital-open-operator-system-oos' ),
								'<br><code>' . esc_html( $drive_redirect_uri ) . '</code>'
							);
							?>
						</li>
						<li><?php esc_html_e( 'Copy the Client ID and Client Secret to the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Click the "Connect Google Drive Account" button that will appear', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<th scope="row"></th>
			<td>
				<p class="description">
					<strong><?php esc_html_e( 'About Google Drive Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				</p>
				<ul style="list-style: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'OAuth 2.0 credentials are obtained from Google Cloud Console', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Access tokens are automatically refreshed when expired', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Supports searching and reading Drive files', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Requires drive.readonly and drive.metadata.readonly scopes for read access', 'nvdigital-open-operator-system-oos' ); ?></li>
						<?php if ( $is_pro_active ) : ?>
						<li><?php esc_html_e( 'Pro users can configure multiple Google Drive connections via Remote Sites', 'nvdigital-open-operator-system-oos' ); ?></li>
					<?php else : ?>
						<li><?php esc_html_e( 'Base version supports 1 connection. Upgrade to Pro for multiple connections', 'nvdigital-open-operator-system-oos' ); ?></li>
					<?php endif; ?>
				</ul>
			</td>
		</tr>
			<?php
		}

		/**
		 * Render Brave Search footer content.
		 */
		private function render_brave_search_footer() {
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Brave Search Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-brave-search-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-brave-search-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your Brave Search API key in the field above, then click "Test Connection" to verify it works. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Mubert footer content.
		 */
		private function render_mubert_footer() {
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Mubert Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-mubert-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-mubert-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your Mubert API key in the field above, then click "Test Connection" to verify it works. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'About Mubert Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Generate royalty-free background music with 150+ genres and 50+ moods', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Request an API key from business@mubert.com', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Used by the generate_music tool for AI-powered music creation', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Supports track durations from 15 seconds to 25 minutes', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render PayHere footer content.
		 */
		private function render_payhere_footer() {
			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$has_credentials = ! empty( $settings['payhere_app_id'] ) && ! empty( $settings['payhere_app_secret'] );
			$is_sandbox      = ! empty( $settings['payhere_sandbox_mode'] );
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'PayHere Configuration', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $has_credentials ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'PayHere Credentials Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
								<?php if ( $is_sandbox ) : ?>
									<span style="margin-left: 10px; padding: 2px 8px; background: #fff3cd; color: #856404; border-radius: 3px; font-size: 12px;">
										<?php esc_html_e( 'Sandbox Mode', 'nvdigital-open-operator-system-oos' ); ?>
									</span>
								<?php else : ?>
									<span style="margin-left: 10px; padding: 2px 8px; background: #d1ecf1; color: #0c5460; border-radius: 3px; font-size: 12px;">
										<?php esc_html_e( 'Live Mode', 'nvdigital-open-operator-system-oos' ); ?>
									</span>
								<?php endif; ?>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Your PayHere credentials are configured. AI assistants can now retrieve payment information using the PayHere API.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php else : ?>
						<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #721c24;">
								<span class="dashicons dashicons-info" style="color: #721c24;"></span>
								<strong><?php esc_html_e( 'PayHere Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'To enable PayHere payment retrieval tools, configure your PayHere App ID and App Secret in the fields above, then save your settings.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'About PayHere Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'API credentials are obtained from PayHere Merchant Dashboard', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Supports retrieving payment information by order ID or transaction ID', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Sandbox mode allows testing without affecting live transactions', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Always disable sandbox mode before going to production', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
					<p class="description">
						<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li>
							<?php
							printf(
								/* translators: %s: URL to PayHere Settings */
								wp_kses_post( __( 'Go to <a href="%s" target="_blank">PayHere Merchant Settings</a>', 'nvdigital-open-operator-system-oos' ) ),
								esc_url( 'https://www.payhere.lk/merchant/settings/api-keys' )
							);
							?>
						</li>
						<li><?php esc_html_e( 'Navigate to "API Keys" section', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Copy your App ID and App Secret', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Paste them into the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Enable sandbox mode for testing (optional)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Flowhub footer content.
		 */
		private function render_flowhub_footer() {
			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$has_credentials = ! empty( $settings['flowhub_api_key'] ) && ! empty( $settings['flowhub_client_id'] );
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Flowhub Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-flowhub-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-flowhub-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your Flowhub credentials in the fields above, then click "Test Connection" to verify they work. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Flowhub Configuration', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $has_credentials ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'Flowhub Credentials Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Your Flowhub credentials are configured. AI assistants can now access inventory, orders, customers, and products using the Flowhub API.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php else : ?>
						<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #721c24;">
								<span class="dashicons dashicons-info" style="color: #721c24;"></span>
								<strong><?php esc_html_e( 'Flowhub Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'To enable Flowhub cannabis dispensary integration tools, configure your Flowhub API credentials in the fields above, then save your settings.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'About Flowhub Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Flowhub is a cannabis dispensary POS and inventory management system', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Supports retrieving inventory, orders, customers, and products', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Supports creating orders and managing customer/product data', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Each dispensary location requires separate credentials', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Uses OAuth2 authentication for secure API access', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
					<p class="description">
						<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li>
							<?php
							printf(
								/* translators: %s: URL to Flowhub API Request Form */
								wp_kses_post( __( 'Fill out the <a href="%s" target="_blank">Flowhub API Integration Request Form</a>', 'nvdigital-open-operator-system-oos' ) ),
								esc_url( 'https://flowhub.com/api-integration-request' )
							);
							?>
						</li>
						<li><?php esc_html_e( 'Wait for Flowhub support to provide your API credentials', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Copy your API Key, Client ID, Client Secret, and Location ID', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Paste them into the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'If you manage multiple locations, repeat the process for each location', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
					<p class="description">
						<strong><?php esc_html_e( 'Available Flowhub Tools:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><strong>flowhub_get_inventory</strong> - <?php esc_html_e( 'Retrieve inventory data with filtering and pagination', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_get_orders</strong> - <?php esc_html_e( 'Retrieve orders and transactions', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_create_order</strong> - <?php esc_html_e( 'Create new dispensary orders', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_get_customers</strong> - <?php esc_html_e( 'Retrieve customer profiles', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_manage_customer</strong> - <?php esc_html_e( 'Create or update customer information', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_get_products</strong> - <?php esc_html_e( 'Retrieve product catalog', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_manage_product</strong> - <?php esc_html_e( 'Create or update product details', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Meta footer content.
		 */
		private function render_meta_footer() {
			$settings          = WP_MCP_AI_Admin_Settings::get_settings();
			$meta_connected    = ! empty( $settings['meta_access_token'] );
			$meta_user_name    = isset( $settings['meta_connected_user_name'] ) ? $settings['meta_connected_user_name'] : '';
			$has_credentials   = ! empty( $settings['meta_app_id'] ) && ! empty( $settings['meta_app_secret'] );
			$oauth_connect_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_meta_oauth_start' ),
				'wp_mcp_ai_meta_oauth_start'
			);
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Meta Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $meta_connected ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'Connected to Meta', 'nvdigital-open-operator-system-oos' ); ?></strong>
								<?php if ( $meta_user_name ) : ?>
									<?php
									printf(
										/* translators: %s: Meta user name */
										esc_html__( 'as %s', 'nvdigital-open-operator-system-oos' ),
										'<code>' . esc_html( $meta_user_name ) . '</code>'
									);
									?>
								<?php endif; ?>
							</p>
						</div>
						<p>
							<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button">
								<?php esc_html_e( 'Reconnect Meta Account', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						</p>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Your Meta account is connected. You can now use Meta integration tools to manage Facebook Pages, Instagram posts, and WhatsApp Business messaging.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php elseif ( $has_credentials ) : ?>
						<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #856404;">
								<span class="dashicons dashicons-warning" style="color: #856404;"></span>
								<strong><?php esc_html_e( 'Meta Not Connected', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p>
							<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button button-primary">
								<?php esc_html_e( 'Connect Meta Account', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						</p>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Click the button above to authorize WP MCP AI to access your Meta account. You will be redirected to Facebook to grant permissions.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
						<p class="description">
							<strong><?php esc_html_e( 'Required Permissions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ul style="list-style: disc; margin-left: 20px;">
							<?php
							// Get scopes from OAuth handler constant.
							$scopes             = WP_MCP_AI_Meta_OAuth_Handler::META_OAUTH_SCOPES;
							$scope_descriptions = array(
								'pages_manage_posts' => __( 'Manage Facebook Page posts', 'nvdigital-open-operator-system-oos' ),
								'instagram_basic'    => __( 'Access Instagram account information', 'nvdigital-open-operator-system-oos' ),
								'instagram_content_publish' => __( 'Publish Instagram content', 'nvdigital-open-operator-system-oos' ),
								'whatsapp_business_management' => __( 'Manage WhatsApp Business account', 'nvdigital-open-operator-system-oos' ),
								'whatsapp_business_messaging' => __( 'Send WhatsApp Business messages', 'nvdigital-open-operator-system-oos' ),
							);
							foreach ( explode( ',', $scopes ) as $scope ) {
								$scope       = trim( $scope );
								$description = isset( $scope_descriptions[ $scope ] ) ? $scope_descriptions[ $scope ] : $scope;
								echo '<li>' . esc_html( $description ) . '</li>';
							}
							?>
						</ul>
					<?php else : ?>
						<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #721c24;">
								<span class="dashicons dashicons-info" style="color: #721c24;"></span>
								<strong><?php esc_html_e( 'Meta App Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php esc_html_e( 'Enter your Meta App ID and App Secret in the fields above, then save settings. After that, you can connect your Meta account using the button that will appear here.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'Meta Platform Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Access Token is used for Facebook Page posts and Instagram business posts', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Business Account ID is required for WhatsApp Business API', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Create a Meta App at developers.facebook.com to get credentials', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Request appropriate permissions for posting and messaging', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render TikTok footer content.
		 */
		private function render_tiktok_footer() {
			?>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'TikTok Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Register your app at developers.tiktok.com', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Request video.share scope for posting videos', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Access tokens expire and need to be refreshed periodically', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render QuickBooks footer content.
		 */
		private function render_quickbooks_footer() {
			$settings             = WP_MCP_AI_Admin_Settings::get_settings();
			$quickbooks_connected = ! empty( $settings['quickbooks_connected'] );
			$company_id           = isset( $settings['quickbooks_company_id'] ) ? $settings['quickbooks_company_id'] : '';
			$has_credentials      = ! empty( $settings['quickbooks_client_id'] ) && ! empty( $settings['quickbooks_client_secret'] );
			$oauth_connect_url    = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_quickbooks_oauth_start' ),
				'wp_mcp_ai_quickbooks_oauth_start'
			);
			$disconnect_url       = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_quickbooks_disconnect' ),
				'wp_mcp_ai_quickbooks_disconnect'
			);
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'QuickBooks Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $quickbooks_connected ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'Connected to QuickBooks', 'nvdigital-open-operator-system-oos' ); ?></strong>
								<?php if ( $company_id ) : ?>
									<?php
									printf(
										/* translators: %s: Company ID */
										esc_html__( '(Company: %s)', 'nvdigital-open-operator-system-oos' ),
										'<code>' . esc_html( $company_id ) . '</code>'
									);
									?>
								<?php endif; ?>
							</p>
						</div>
						<p>
							<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button">
								<?php esc_html_e( 'Reconnect QuickBooks Account', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
							<a href="<?php echo esc_url( $disconnect_url ); ?>" class="button" style="margin-left: 5px;">
								<?php esc_html_e( 'Disconnect', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						</p>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Your QuickBooks account is connected. You can now use financial reporting and accounting tools.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php elseif ( $has_credentials ) : ?>
						<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #856404;">
								<span class="dashicons dashicons-warning" style="color: #856404;"></span>
								<strong><?php esc_html_e( 'QuickBooks Not Connected', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p>
							<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button button-primary">
								<?php esc_html_e( 'Connect QuickBooks Account', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						</p>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Click the button above to authorize WP MCP AI to access your QuickBooks account. You will be redirected to Intuit to grant permissions and select your company.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php else : ?>
						<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #721c24;">
								<span class="dashicons dashicons-info" style="color: #721c24;"></span>
								<strong><?php esc_html_e( 'QuickBooks OAuth Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php esc_html_e( 'Enter your QuickBooks OAuth Client ID and Client Secret in the fields above, then save settings. After that, you can connect using the button that will appear here.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'QuickBooks Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Company ID is also known as Realm ID in QuickBooks', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'OAuth credentials are obtained from developer.intuit.com', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Access tokens are automatically refreshed when expired', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Supports accounting, invoicing, and financial reporting', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Mailjet footer content.
		 */
	private function render_mailjet_footer() {
		$settings        = WP_MCP_AI_Admin_Settings::get_settings();
		$has_credentials = ! empty( $settings['mailjet_api_key'] ) && ! empty( $settings['mailjet_api_secret'] );
		$webhook_url     = rest_url( 'mcp-ai/v1/webhooks/mailjet' );
		?>
		<tr>
			<th scope="row"><?php esc_html_e( 'Mailjet Status', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td>
				<?php if ( $has_credentials ) : ?>
					<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
					<p style="margin: 0; color: #155724;">
					<span class="dashicons dashicons-yes" style="color: #155724;"></span>
					<strong><?php esc_html_e( 'Mailjet API Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					</div>
					<p class="description">
					<?php
						echo wp_kses_post(
							__(
								'Your Mailjet API credentials are configured. You can now use email sending and campaign management tools.',
								'nvdigital-open-operator-system-oos'
							)
							);
					?>
</p>
				<?php else : ?>
					<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
					<p style="margin: 0; color: #721c24;">
					<span class="dashicons dashicons-info" style="color: #721c24;"></span>
					<strong><?php esc_html_e( 'Mailjet Not Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					</div>
<p class="description">
					<?php esc_html_e( 'Enter your Mailjet API Key and Secret Key in the fields above, then save settings.', 'nvdigital-open-operator-system-oos' ); ?>
</p>
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Webhook URL', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td>
				<input type="text" readonly value="<?php echo esc_url( $webhook_url ); ?>" style="width: 100%; max-width: 500px;" id="mailjet_webhook_url" />
				<button type="button" class="button" onclick="(function(btn){try{var input=document.getElementById('mailjet_webhook_url');if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(input.value).then(function(){btn.textContent='<?php esc_attr_e( 'Copied!', 'nvdigital-open-operator-system-oos' ); ?>';setTimeout(function(){btn.textContent='<?php esc_attr_e( 'Copy', 'nvdigital-open-operator-system-oos' ); ?>';},2000);}).catch(function(){input.select();document.execCommand('copy');btn.textContent='<?php esc_attr_e( 'Copied!', 'nvdigital-open-operator-system-oos' ); ?>';setTimeout(function(){btn.textContent='<?php esc_attr_e( 'Copy', 'nvdigital-open-operator-system-oos' ); ?>';},2000);});}else{input.select();document.execCommand('copy');btn.textContent='<?php esc_attr_e( 'Copied!', 'nvdigital-open-operator-system-oos' ); ?>';setTimeout(function(){btn.textContent='<?php esc_attr_e( 'Copy', 'nvdigital-open-operator-system-oos' ); ?>';},2000);}}catch(e){console.error('Copy failed:',e);alert('<?php esc_attr_e( 'Failed to copy. Please copy manually.', 'nvdigital-open-operator-system-oos' ); ?>');}})(this);">
					<?php esc_html_e( 'Copy', 'nvdigital-open-operator-system-oos' ); ?>
</button>
				<p class="description">
					<?php esc_html_e( 'Use this URL to configure webhooks in your Mailjet account for receiving event notifications (opens, clicks, bounces, etc.).', 'nvdigital-open-operator-system-oos' ); ?>
</p>
			</td>
		</tr>
		<tr>
			<th scope="row"></th>
			<td>
				<p class="description">
					<strong><?php esc_html_e( 'Mailjet Integration Setup:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				</p>
				<ul style="list-style: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'Mailjet uses Basic Authentication (API Key + Secret Key) - no OAuth required', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Get your API credentials from Mailjet account under Account Settings → REST API → API Key Management', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Verify your "From Email" address in Mailjet before sending emails', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Configure webhooks in Mailjet to receive real-time event notifications', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Supports transactional emails, campaigns, and contact management', 'nvdigital-open-operator-system-oos' ); ?></li>
				</ul>
</td>
			</td>
		<?php
	}

		/**
		 * Render Cloudways footer content.
		 */
		private function render_cloudways_footer() {
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Cloudways Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-cloudways-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-cloudways-test-result" style="margin-left: 10px;"></span>
					</p>
					<div id="wp-mcp-ai-cloudways-account-info" style="margin-top: 10px;"></div>
					<p class="description">
						<?php esc_html_e( 'Enter your Cloudways email and API key in the fields above, then click "Test Connection" to verify they work. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'Cloudways Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Get your API key from your Cloudways account settings', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Server ID and App ID can be found in your Cloudways dashboard', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'OAuth tokens are automatically refreshed when expired', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Cloudflare footer content.
		 */
		private function render_cloudflare_footer() {
			$settings             = WP_MCP_AI_Admin_Settings::get_settings();
			$has_api_token        = ! empty( $settings['cloudflare_api_token'] );
			$has_zone_id          = ! empty( $settings['cloudflare_zone_id'] );
			$cloudflare_connected = ! empty( $settings['cloudflare_connected'] );
			$pro_toolkit_enabled  = ! empty( $settings['enable_cloudflare_pro_toolkit'] );
			$is_pro_active        = defined( 'WP_MCP_AI_PRO_VERSION' );
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Cloudflare Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $cloudflare_connected && $has_api_token && $has_zone_id ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'Connected to Cloudflare', 'nvdigital-open-operator-system-oos' ); ?></strong>
								<?php if ( ! empty( $settings['cloudflare_zone_name'] ) ) : ?>
									<?php
									printf(
										/* translators: %s: Cloudflare zone name */
										esc_html__( '- Zone: %s', 'nvdigital-open-operator-system-oos' ),
										'<code>' . esc_html( $settings['cloudflare_zone_name'] ) . '</code>'
									);
									?>
								<?php endif; ?>
							</p>
						</div>
					<?php endif; ?>
					<p>
						<button type="button" id="wp-mcp-ai-test-cloudflare-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-cloudflare-test-result" style="margin-left: 10px;"></span>
					</p>
					<div id="wp-mcp-ai-cloudflare-zone-info" style="margin-top: 10px;"></div>
					<p class="description">
						<?php esc_html_e( 'Enter your Cloudflare API token and Zone ID in the fields above, then click "Test Connection" to verify they work. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<?php if ( $pro_toolkit_enabled ) : ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'Pro Toolkit Status', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<?php if ( $is_pro_active ) : ?>
							<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
								<p style="margin: 0; color: #155724;">
									<span class="dashicons dashicons-yes" style="color: #155724;"></span>
									<strong><?php esc_html_e( 'Cloudflare Pro Toolkit Active', 'nvdigital-open-operator-system-oos' ); ?></strong>
								</p>
							</div>
							<p class="description">
								<?php
								echo wp_kses_post(
									__(
										'The Cloudflare Pro Toolkit is enabled. AI assistants can now use advanced Cloudflare features including cache purging, zone management, and DNS operations.',
										'nvdigital-open-operator-system-oos'
									)
								);
								?>
							</p>
						<?php else : ?>
							<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
								<p style="margin: 0; color: #856404;">
									<span class="dashicons dashicons-warning" style="color: #856404;"></span>
									<strong><?php esc_html_e( 'Pro Addon Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
								</p>
							</div>
							<p class="description">
								<?php
								echo wp_kses_post(
									__(
										'The Cloudflare Pro Toolkit setting is enabled but requires the Pro addon to be installed and active. Install the Pro addon to unlock advanced Cloudflare features.',
										'nvdigital-open-operator-system-oos'
									)
								);
								?>
							</p>
							<p>
								<a href="https://link.nvdigital.solutions/wpoos-pro-buy" target="_blank" class="button button-primary">
									<?php esc_html_e( 'Get NV oOS Pro', 'nvdigital-open-operator-system-oos' ); ?>
								</a>
							</p>
						<?php endif; ?>
					</td>
				</tr>
			<?php endif; ?>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'Cloudflare Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Create an API token in your Cloudflare dashboard under "My Profile" > "API Tokens"', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Token needs "Zone.Cache Purge" permission for cache management', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Find your Zone ID in the Overview page of your domain', 'nvdigital-open-operator-system-oos' ); ?></li>
						<?php if ( $is_pro_active || $pro_toolkit_enabled ) : ?>
							<li><?php esc_html_e( 'Pro Toolkit enables additional permissions: DNS edit, Zone settings, and Analytics read', 'nvdigital-open-operator-system-oos' ); ?></li>
						<?php endif; ?>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Override render_wrapper to include sub-tab navigation.
		 * Only renders when the 'connections' subtab is active in the Tools tab.
		 */
		public function render_wrapper() {
			// Only render this section when the 'connections' subtab is active in Tools.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$current_subtab = isset( $_GET['subtab'] ) ? sanitize_key( $_GET['subtab'] ) : '';

			// This section is embedded within Tools > Connections subtab.
			// Don't render if we're not in the connections subtab.
			if ( 'connections' !== $current_subtab ) {
				return;
			}

			$description       = $this->get_description();
			$documentation_url = $this->get_documentation_url();
			$subtab_groups     = $this->get_subtab_groups();
			$active_subtab     = $this->get_active_subtab();
			?>
			<div class="settings-section" id="section-<?php echo esc_attr( $this->get_id() ); ?>">
				<h2><?php echo esc_html( $this->get_title() ); ?></h2>
				<?php if ( $description ) : ?>
					<p class="section-description"><?php echo wp_kses_post( $description ); ?></p>
				<?php endif; ?>
				<?php if ( $documentation_url ) : ?>
					<p class="section-documentation">
						<span class="dashicons dashicons-book-alt" style="color: #2271b1;"></span>
						<a href="<?php echo esc_url( $documentation_url ); ?>" target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'View Documentation', 'nvdigital-open-operator-system-oos' ); ?>
							<span class="dashicons dashicons-external" style="font-size: 14px; text-decoration: none;"></span>
						</a>
					</p>
				<?php endif; ?>

				<div class="wp-mcp-ai-provider-subtabs">
					<nav class="wp-mcp-ai-subtab-nav" aria-label="<?php esc_attr_e( 'External tools settings sub-tabs', 'nvdigital-open-operator-system-oos' ); ?>">
						<?php foreach ( $subtab_groups as $group ) : ?>
							<?php
							// When rendered within Tools > Connections, preserve the connections subtab.

							// Otherwise link directly to the integration subtab.

							// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter for URL construction.
							$current_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'tools';
							// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter for URL construction.
							$current_parent_subtab = isset( $_GET['subtab'] ) ? sanitize_key( $_GET['subtab'] ) : '';

							$url_args = array(
								'page' => 'wp-mcp-ai-dashboard',
								'tab'  => $current_tab,
							);

							// If we're in the connections subtab, add it to maintain context.

							if ( 'connections' === $current_parent_subtab ) {
								$url_args['subtab']     = 'connections';
								$url_args['connection'] = $group['id'];
							} else {
								$url_args['subtab'] = $group['id'];
							}

							$subtab_url = add_query_arg( $url_args, admin_url( 'admin.php' ) );
							$is_active  = ( $group['id'] === $active_subtab );
							?>
							<a href="<?php echo esc_url( $subtab_url ); ?>"
								class="wp-mcp-ai-subtab <?php echo esc_attr( $is_active ? 'wp-mcp-ai-subtab-active' : '' ); ?>"
								data-subtab="<?php echo esc_attr( $group['id'] ); ?>">
								<span class="dashicons <?php echo esc_attr( $group['icon'] ); ?>"></span>
								<?php echo esc_html( $group['label'] ); ?>
							</a>
						<?php endforeach; ?>
					</nav>

					<!-- Hidden field to preserve subtab during form submission -->
					<input type="hidden" name="subtab_<?php echo esc_attr( $this->get_id() ); ?>" value="<?php echo esc_attr( $active_subtab ); ?>" />
					
					<?php
					// If accessed via connection parameter (e.g., from Tools > Connections),
					// preserve it for redirect after save.
					// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter for UI state.
					if ( isset( $_GET['connection'] ) ) :
						?>
						<input type="hidden" name="connection" value="<?php echo esc_attr( sanitize_key( $_GET['connection'] ) ); ?>" />
						<?php
					endif;
					?>

					<div class="wp-mcp-ai-subtab-content">
						<table class="form-table" role="presentation">
							<?php $this->render(); ?>
						</table>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Render iSAMS footer content.
		 */
		private function render_isams_footer() {
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'iSAMS Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-isams-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-isams-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your iSAMS API credentials in the fields above, then click "Test Connection" to verify they work. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<div style="margin: 1rem 0;">
						<h4><?php esc_html_e( 'Available iSAMS Tools', 'nvdigital-open-operator-system-oos' ); ?></h4>
						<p class="description" style="margin-bottom: 10px;">
							<?php esc_html_e( 'The following AI tools are available when iSAMS is properly configured:', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
						<ul style="margin-left: 1.5rem;">
							<li><strong>isams_query</strong> - <?php esc_html_e( 'Query iSAMS for pupils, employees, departments, houses, terms, subjects, year groups, and admission applicants', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
						<p class="description" style="margin-top: 1rem;">
							<strong><?php esc_html_e( 'About iSAMS Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ul style="list-style: disc; margin-left: 20px;">
							<li><?php esc_html_e( 'API credentials are obtained from your iSAMS administrator', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Supports read-only access to school management data', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Access tokens are automatically cached for 55 minutes', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Requires Pro addon to be active', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
						<p class="description" style="margin-top: 1rem;">
							<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ol style="margin-left: 20px;">
							<li><?php esc_html_e( 'Contact your iSAMS administrator to obtain API credentials', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Enter the iSAMS instance URL (e.g., https://yourschool.isams.cloud/)', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Enter your API Key and API Secret in the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Click "Test Connection" to verify credentials work', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ol>
					</div>
				</td>
			</tr>
			<?php
		}

		/**
		 * Validate section input.
		 *
		 * @param array $input Raw input.
		 * @return array|WP_Error Validated input or error.
		 */
		public function validate( $input ) {
			$errors = array();

			// Validate Crawl4AI URL.
			if ( isset( $input['crawl4ai_base_url'] ) && ! empty( $input['crawl4ai_base_url'] ) ) {
				$result = WP_MCP_AI_Settings_Validator::validate_url( $input['crawl4ai_base_url'] );
				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Crawl4AI Base URL: ', 'nvdigital-open-operator-system-oos' ) . $result->get_error_message();
				}
			}

			if ( ! empty( $errors ) ) {
				return new WP_Error( 'validation_error', implode( ' ', $errors ) );
			}

			return $input;
		}
	}
}
