<?php
/**
 * Base class for Admin Test Pages
 *
 * Provides shared functionality for test pages (Assistant, Profession, Team).
 * Follows SoC by centralizing common logic and reducing code duplication.
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abstract base class for admin test pages.
 */
abstract class WP_MCP_AI_Admin_Test_Page_Base {

	/**
	 * Page hook suffix.
	 *
	 * @var string|false
	 */
	protected $page_hook;

	/**
	 * Get the post type for this test page.
	 *
	 * @return string
	 */
	abstract protected function get_post_type();

	/**
	 * Get the page slug.
	 *
	 * @return string
	 */
	abstract protected function get_page_slug();

	/**
	 * Get the page title.
	 *
	 * @return string
	 */
	abstract protected function get_page_title();

	/**
	 * Get the menu title.
	 *
	 * @return string
	 */
	abstract protected function get_menu_title();

	/**
	 * Render the page content.
	 */
	abstract public function render_page();

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_submenu_page' ), 20 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Register the submenu page.
	 */
	public function register_submenu_page() {
		$post_type = $this->get_post_type();

		$this->page_hook = add_submenu_page(
			'edit.php?post_type=' . $post_type,
			$this->get_page_title(),
			$this->get_menu_title(),
			'manage_options',
			$this->get_page_slug(),
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue assets for the test page.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_assets( $hook ) {
		if ( $hook !== $this->page_hook ) {
			return;
		}

		// Check if any assistant on this page uses embedded provider.
		// If so, we need to enqueue embedded LLM scripts before the chat scripts.
		$this->enqueue_embedded_provider_if_needed();

		// Enqueue shared chat assets.
		$this->enqueue_chat_assets();

		// Enqueue page-specific assets.
		$this->enqueue_page_assets();
	}

	/**
	 * Enqueue page-specific assets.
	 * Override in child classes to add page-specific JS/CSS.
	 */
	protected function enqueue_page_assets() {
		// Override in child classes if needed.
	}

	/**
	 * Check if any assistant uses embedded provider and enqueue scripts if needed.
	 * This is required for admin test pages where assistants are loaded dynamically.
	 */
	protected function enqueue_embedded_provider_if_needed() {
		// Skip if WP_MCP_AI_BASE_VERSION is true (embedded provider not available in base version).
		if ( defined( 'WP_MCP_AI_BASE_VERSION' ) && WP_MCP_AI_BASE_VERSION ) {
			return;
		}

		// Check if Assistant CPT class is available.
		if ( ! class_exists( 'WP_MCP_AI_Assistant_CPT' ) ) {
			return;
		}

		// Get all published assistants to check if any use embedded provider.
		$assistants = get_posts(
			array(
				'post_type'      => $this->get_post_type(),
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids', // Only need IDs for efficiency.
			)
		);

		if ( empty( $assistants ) ) {
			return;
		}

		// Check if any assistant uses embedded provider.
		$needs_embedded = false;
		foreach ( $assistants as $assistant_id ) {
			$config = WP_MCP_AI_Assistant_CPT::get_assistant_configuration( $assistant_id );
			if ( isset( $config['provider'] ) && 'embedded' === $config['provider'] ) {
				$needs_embedded = true;
				break;
			}
		}

		// If no assistant uses embedded provider, we're done.
		if ( ! $needs_embedded ) {
			return;
		}

		// Enqueue embedded LLM client scripts.
		$embedded_script_path    = WP_MCP_AI_URL . 'assets/js/embedded-llm-client.js';
		$embedded_script_version = $this->get_asset_version( 'assets/js/embedded-llm-client.js' );
		$webllm_loader_path      = WP_MCP_AI_URL . 'assets/js/webllm-loader.js';
		$webllm_loader_version   = $this->get_asset_version( 'assets/js/webllm-loader.js' );

		// Register WebLLM loader script.
		if ( ! wp_script_is( 'webllm-loader', 'registered' ) ) {
			wp_register_script(
				'webllm-loader',
				$webllm_loader_path,
				array(),
				$webllm_loader_version,
				true
			);
		}

		// Register embedded LLM client.
		if ( ! wp_script_is( 'wp-mcp-ai-embedded-llm-client', 'registered' ) ) {
			wp_register_script(
				'wp-mcp-ai-embedded-llm-client',
				$embedded_script_path,
				array( 'webllm-loader' ),
				$embedded_script_version,
				true
			);
		}

		// Enqueue the scripts.
		wp_enqueue_script( 'webllm-loader' );
		wp_enqueue_script( 'wp-mcp-ai-embedded-llm-client' );
	}

	/**
	 * Enqueue chat interface assets.
	 * Shared across all test pages.
	 *
	 * Uses the bundled chat-bundle.js which combines all chat-related services
	 * into a single optimized file, reducing HTTP requests from 9 files to 1 file.
	 */
	protected function enqueue_chat_assets() {
		// Use bundled JavaScript file that combines all chat services.
		// The chat-bundle.js is an entry point for esbuild with ES6 imports,.

		// so we must load the bundled output (chat-bundle.min.js) which is browser-compatible.
		$script_relative            = 'assets/js/chat-bundle.min.js';
		$style_relative             = 'assets/css/chat.css';
		$cron_status_style_relative = 'assets/css/cron-status.css';

		$script_path            = WP_MCP_AI_URL . $script_relative;
		$style_path             = WP_MCP_AI_URL . $style_relative;
		$cron_status_style_path = WP_MCP_AI_URL . $cron_status_style_relative;

		$script_version            = $this->get_asset_version( $script_relative );
		$style_version             = $this->get_asset_version( $style_relative );
		$cron_status_style_version = $this->get_asset_version( $cron_status_style_relative );

		// Enqueue cron status styles (CSS only - JS is bundled).

		wp_enqueue_style(
			'wp-mcp-ai-cron-status',
			$cron_status_style_path,
			array(),
			$cron_status_style_version
		);

		wp_enqueue_style(
			'wp-mcp-ai-chat',
			$style_path,
			array( 'wp-mcp-ai-cron-status' ),
			$style_version
		);

		// Register bundled chat script (includes all services in a single file).

		wp_enqueue_script(
			'wp-mcp-ai-chat',
			$script_path,
			array(), // No dependencies - all services are bundled together.
			$script_version,
			true
		);

		// Safety check: Ensure REST constants exist.
		$rest_namespace = defined( 'WP_MCP_AI_REST::REST_NAMESPACE' ) ? WP_MCP_AI_REST::REST_NAMESPACE : 'mcp-ai/v1';

		// Use the shortcode helper method for consistent async tool timeout calculation.
		// Default to 5 minutes (300000ms) if shortcode class is not available.
		$async_timeout_ms = class_exists( 'WP_MCP_AI_Shortcode' )
			? WP_MCP_AI_Shortcode::get_async_tool_timeout_ms()
			: 300000;

		// Get plugin settings for cost display and capability flags configuration.
		$settings         = WP_MCP_AI_Admin_Settings::get_settings();
		$show_usage_costs = isset( $settings['show_usage_costs'] ) ? (bool) $settings['show_usage_costs'] : false;

		// Allow filtering of cost display setting.
		$show_usage_costs = apply_filters( 'wp_mcp_ai_show_usage_costs', $show_usage_costs, get_current_user_id() );

		// Get capability flags display setting.
		$show_capability_flags = isset( $settings['show_capability_flags'] ) ? (bool) $settings['show_capability_flags'] : false;

		// Allow filtering of capability flags display setting.
		$show_capability_flags = apply_filters( 'wp_mcp_ai_show_capability_flags', $show_capability_flags, get_current_user_id() );

		wp_localize_script(
			'wp-mcp-ai-chat',
			'wpMcpAiChat',
			array(
				'restUrl'             => esc_url_raw( trailingslashit( $this->normalise_rest_url( rest_url( $rest_namespace ) ) ) ),
				'uploadEndpoint'      => esc_url_raw( $this->normalise_rest_url( rest_url( 'wp/v2/media' ) ) ),
				'filesEndpoint'       => esc_url_raw( trailingslashit( $this->normalise_rest_url( rest_url( $rest_namespace . '/files' ) ) ) ),
				'toolsEndpoint'       => esc_url_raw( $this->normalise_rest_url( rest_url( $rest_namespace . '/tools' ) ) ),
				'transcriptsEndpoint' => esc_url_raw( $this->normalise_rest_url( rest_url( $rest_namespace . '/chat-transcripts' ) ) ),
				'historyPerPage'      => 20,
				'currentUserId'       => get_current_user_id(),
				'nonce'               => wp_create_nonce( 'wp_rest' ),
				'showUsageCosts'      => $show_usage_costs,
				'showCapabilityFlags' => $show_capability_flags,
				'asyncToolTimeout'    => $async_timeout_ms,
				'strings'             => $this->get_chat_strings(),
			)
		);
	}

	/**
	 * Get chat interface strings for localization.
	 * Can be overridden in child classes for customization.
	 *
	 * @return array
	 */
	protected function get_chat_strings() {
		return array(
			'placeholder'                   => __( 'Ask something…', 'nvdigital-open-operator-system-oos' ),
			'send'                          => __( 'Send', 'nvdigital-open-operator-system-oos' ),
			'bundlingMessages'              => __( 'Preparing to send…', 'nvdigital-open-operator-system-oos' ),
			'sending'                       => __( 'Sending message…', 'nvdigital-open-operator-system-oos' ),
			'waiting'                       => __( 'Waiting for the assistant…', 'nvdigital-open-operator-system-oos' ),
			'error'                         => __( 'Something went wrong. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'missingAssistant'              => __( 'Configuration was not found.', 'nvdigital-open-operator-system-oos' ),
			'notAuthorized'                 => __( 'You do not have permission to chat.', 'nvdigital-open-operator-system-oos' ),
			'toolExecuting'                 => __( 'Running tool: %s', 'nvdigital-open-operator-system-oos' ),
			'toolSuccess'                   => __( 'Tool completed successfully.', 'nvdigital-open-operator-system-oos' ),
			'toolError'                     => __( 'The tool request failed.', 'nvdigital-open-operator-system-oos' ),
			'toolQueued'                    => __( 'Tool queued. Results will appear shortly.', 'nvdigital-open-operator-system-oos' ),
			'toolPolling'                   => __( 'Tool is processing…', 'nvdigital-open-operator-system-oos' ),
			'toolTimeout'                   => __( 'Tool timed out before completing.', 'nvdigital-open-operator-system-oos' ),
			'toolFailed'                    => __( 'Tool failed: %s', 'nvdigital-open-operator-system-oos' ),
			'speechToolSuccess'             => __( 'Speech audio saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'imageToolSuccess'              => __( 'Image saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'toolShortcutLabel'             => __( 'Insert task: %s', 'nvdigital-open-operator-system-oos' ),
			'emptyMessage'                  => __( 'Enter a message before sending.', 'nvdigital-open-operator-system-oos' ),
			'attachFile'                    => __( 'Attach file', 'nvdigital-open-operator-system-oos' ),
			'transcribe'                    => __( 'Transcribe', 'nvdigital-open-operator-system-oos' ),
			'transcribeAudio'               => __( 'Transcribe audio', 'nvdigital-open-operator-system-oos' ),
			'transcribing'                  => __( 'Transcribing audio…', 'nvdigital-open-operator-system-oos' ),
			'recording'                     => __( 'Recording… tap to stop.', 'nvdigital-open-operator-system-oos' ),
			'stopRecording'                 => __( 'Stop recording', 'nvdigital-open-operator-system-oos' ),
			'recordingError'                => __( 'Could not access your microphone. Please allow access or upload an audio file instead.', 'nvdigital-open-operator-system-oos' ),
			'transcriptionError'            => __( 'The transcription request failed. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'transcriptionSuccess'          => __( 'Inserted transcription from "%s".', 'nvdigital-open-operator-system-oos' ),
			'transcriptionFileTooLarge'     => __( 'The selected audio file is too large. Please choose a file under 25MB.', 'nvdigital-open-operator-system-oos' ),
			'transcribeChooseSource'        => __( 'Press OK to record with your microphone, or Cancel to choose an audio file.', 'nvdigital-open-operator-system-oos' ),
			'attachmentsLabel'              => __( 'Attachments', 'nvdigital-open-operator-system-oos' ),
			'removeAttachment'              => __( 'Remove', 'nvdigital-open-operator-system-oos' ),
			'uploadingFile'                 => __( 'Uploading "%s"…', 'nvdigital-open-operator-system-oos' ),
			'uploadError'                   => __( 'The file could not be uploaded. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'uploadInProgress'              => __( 'Please wait for uploads to finish before sending.', 'nvdigital-open-operator-system-oos' ),
			'downloadAttachment'            => __( 'Download attachment', 'nvdigital-open-operator-system-oos' ),
			'unsupportedFileType'           => __( '"%s" is not a supported file type. Please choose a different file.', 'nvdigital-open-operator-system-oos' ),
			'unsupportedMultipleFiles'      => __( 'Some selected files are not supported. Please try different files.', 'nvdigital-open-operator-system-oos' ),
			'unsupportedFileLabel'          => __( 'This file', 'nvdigital-open-operator-system-oos' ),
			'expandTranscript'              => __( 'Expand conversation', 'nvdigital-open-operator-system-oos' ),
			'collapseTranscript'            => __( 'Collapse conversation', 'nvdigital-open-operator-system-oos' ),
			'newConversation'               => __( 'Start new conversation', 'nvdigital-open-operator-system-oos' ),
			'loadConversation'              => __( 'Load conversation', 'nvdigital-open-operator-system-oos' ),
			'jsonResponse'                  => __( 'JSON response', 'nvdigital-open-operator-system-oos' ),
			'historyToggleShow'             => __( 'Show previous conversations', 'nvdigital-open-operator-system-oos' ),
			'historyToggleHide'             => __( 'Hide previous conversations', 'nvdigital-open-operator-system-oos' ),
			'historyLoading'                => __( 'Loading conversations…', 'nvdigital-open-operator-system-oos' ),
			'historyEmpty'                  => __( 'No previous conversations yet.', 'nvdigital-open-operator-system-oos' ),
			'historyError'                  => __( 'Unable to load conversation history.', 'nvdigital-open-operator-system-oos' ),
			'historyMessageCount'           => __( '%d messages', 'nvdigital-open-operator-system-oos' ),
			'historySingleMessage'          => __( '1 message', 'nvdigital-open-operator-system-oos' ),
			'historyPreviewFallback'        => __( 'Conversation %s', 'nvdigital-open-operator-system-oos' ),
			'historySessionLoading'         => __( 'Loading conversation…', 'nvdigital-open-operator-system-oos' ),
			'historySessionError'           => __( 'Unable to load this conversation. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'historyNoMessages'             => __( 'No messages were saved for this conversation.', 'nvdigital-open-operator-system-oos' ),
			'saveConversation'              => __( 'Save conversation', 'nvdigital-open-operator-system-oos' ),
			'savingConversation'            => __( 'Saving current conversation...', 'nvdigital-open-operator-system-oos' ),
			'conversationSaved'             => __( 'Conversation saved successfully.', 'nvdigital-open-operator-system-oos' ),
			'saveFailed'                    => __( 'Failed to save conversation. See console for details.', 'nvdigital-open-operator-system-oos' ),
			'saveFailedProceed'             => __( 'Failed to save conversation: ', 'nvdigital-open-operator-system-oos' ),
			'proceedAnyway'                 => __( 'Do you want to proceed anyway? Your current conversation will be lost.', 'nvdigital-open-operator-system-oos' ),
			'saveFailedKeepingConversation' => __( 'Conversation not cleared. You can try again later.', 'nvdigital-open-operator-system-oos' ),
			'noConversationToSave'          => __( 'No conversation to save. Start chatting first!', 'nvdigital-open-operator-system-oos' ),
			'saveSkipped'                   => __( 'Save not available for this conversation.', 'nvdigital-open-operator-system-oos' ),
			'confirmClearConversation'      => __( 'Start a new conversation? Your current conversation will be saved automatically.', 'nvdigital-open-operator-system-oos' ),
			'noConversationToExport'        => __( 'No conversation to export. Start chatting first!', 'nvdigital-open-operator-system-oos' ),
			'exportFormatPrompt'            => __( 'Choose export format:\n- json\n- markdown\n- text', 'nvdigital-open-operator-system-oos' ),
			'invalidExportFormat'           => __( 'Invalid format. Please choose json, markdown, or text.', 'nvdigital-open-operator-system-oos' ),
			'exportFailed'                  => __( 'Export failed: ', 'nvdigital-open-operator-system-oos' ),
			'exportSuccess'                 => __( 'Conversation exported successfully as ', 'nvdigital-open-operator-system-oos' ),
			'deleteConversation'            => __( 'Delete this conversation', 'nvdigital-open-operator-system-oos' ),
			'confirmDeleteConversation'     => __( 'Are you sure you want to delete this conversation? This action cannot be undone.', 'nvdigital-open-operator-system-oos' ),
			'veoVideoToolSuccess'           => __( 'Video generated successfully and saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'videoNotSupported'             => __( 'Your browser does not support video playback.', 'nvdigital-open-operator-system-oos' ),
			'downloadVideo'                 => __( 'Download video', 'nvdigital-open-operator-system-oos' ),
			'geminiImageToolSuccess'        => __( 'Gemini image saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'editGeminiImageToolSuccess'    => __( 'Gemini image edited and saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'roleLabels'                    => array(
				'assistant' => __( 'Assistant', 'nvdigital-open-operator-system-oos' ),
				'user'      => __( 'You', 'nvdigital-open-operator-system-oos' ),
				'system'    => __( 'System', 'nvdigital-open-operator-system-oos' ),
				'tool'      => __( 'Tool', 'nvdigital-open-operator-system-oos' ),
			),
		);
	}

	/**
	 * Normalize REST URL.
	 *
	 * @param string $url REST URL to normalize.
	 * @return string Normalized URL.
	 */
	protected function normalise_rest_url( $url ) {
		if ( class_exists( 'WP_MCP_AI_Request_Context' ) && method_exists( 'WP_MCP_AI_Request_Context', 'normalise_rest_url' ) ) {
			return WP_MCP_AI_Request_Context::normalise_rest_url( $url );
		}
		return $url;
	}

	/**
	 * Get asset version based on file modification time.
	 *
	 * @param string $relative_path Asset path relative to plugin root.
	 * @return string
	 */
	protected function get_asset_version( $relative_path ) {
		$relative_path = ltrim( $relative_path, '/' );
		$absolute_path = WP_MCP_AI_PATH . $relative_path;

		if ( file_exists( $absolute_path ) ) {
			$modified = filemtime( $absolute_path );

			if ( $modified ) {
				return WP_MCP_AI_VERSION . '.' . $modified;
			}
		}

		return WP_MCP_AI_VERSION;
	}

	/**
	 * Check if current user has permission to view this page.
	 *
	 * @return bool
	 */
	protected function check_permission() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'nvdigital-open-operator-system-oos' ) );
		}
		return true;
	}
}
