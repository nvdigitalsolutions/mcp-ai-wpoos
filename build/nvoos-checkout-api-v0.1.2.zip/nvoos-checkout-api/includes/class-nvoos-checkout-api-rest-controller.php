<?php
/**
 * REST controller: session, verify, and Stripe webhook.
 *
 * @package NV_oOS_Checkout_API
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checkout REST endpoints under /wp-json/nvoos-checkout/v1/.
 *
 * `/session` and `/verify` are called server-to-server by customer sites
 * running the free base plugin. They are public (no WP auth) because no
 * shared secret can be shipped in a public plugin; they are protected by
 * per-IP rate limiting, input validation, and — decisively — by Stripe:
 * a license is only ever issued for a real, paid PaymentIntent whose
 * metadata matches the requested product and site URL.
 *
 * `/webhooks/stripe` is public but signature-gated with Stripe's official
 * HMAC algorithm.
 *
 * `/license/check` and `/license/activate` are the read side of the same
 * store: the WordPress Pro plugin and the Laravel runtime ask them whether an
 * issued key is still valid for this site. They are public for the same reason
 * as `/verify` — a public plugin cannot ship a shared secret — and are
 * protected by per-IP rate limiting, strict input validation, uniform
 * `{status:invalid}` answers for every failure mode, and instance binding
 * inside `NVOOS_Checkout_API_License_Resolver`.
 *
 * @since 0.1.0
 */
class NVOOS_Checkout_API_Rest_Controller {

	public const REST_NAMESPACE = 'nvoos-checkout/v1';

	/**
	 * Products this checkout sells.
	 *
	 * `nvoos-oos-complete` is the current product (the NV oOS Complete
	 * bundle); `nvoos-content-graph-ai` stays accepted for legacy
	 * purchases issued before the Complete bundle replaced the AI addon.
	 *
	 * @var string[]
	 */
	public const PRODUCTS = array( 'nvoos-oos-complete', 'nvoos-content-graph-ai' );

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/session',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'create_session' ),
				'permission_callback' => '__return_true', // Public by design — see class docblock.
				'args'                => array(
					'product'       => array(
						'required'          => true,
						'type'              => 'string',
						'validate_callback' => function ( $value ) {
							return is_string( $value ) && in_array( $value, self::PRODUCTS, true );
						},
						'sanitize_callback' => 'sanitize_text_field',
					),
					'site_url'      => array(
						'required'          => true,
						'type'              => 'string',
						'validate_callback' => array( $this, 'validate_site_url' ),
						'sanitize_callback' => array( $this, 'sanitize_site_url' ),
					),
					'addon_version' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/verify',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'verify_payment' ),
				'permission_callback' => '__return_true', // Public by design — see class docblock.
				'args'                => array(
					'product'         => array(
						'required'          => true,
						'type'              => 'string',
						'validate_callback' => function ( $value ) {
							return is_string( $value ) && in_array( $value, self::PRODUCTS, true );
						},
						'sanitize_callback' => 'sanitize_text_field',
					),
					'site_url'        => array(
						'required'          => true,
						'type'              => 'string',
						'validate_callback' => array( $this, 'validate_site_url' ),
						'sanitize_callback' => array( $this, 'sanitize_site_url' ),
					),
					'payment_intent'  => array(
						'required'          => true,
						'type'              => 'string',
						'validate_callback' => function ( $value ) {
							return is_string( $value ) && 1 === preg_match( '/^pi_[A-Za-z0-9]{8,}$/', $value );
						},
						'sanitize_callback' => 'sanitize_text_field',
					),
					'terms_agreed_at' => array(
						'type'              => 'integer',
						'validate_callback' => array( $this, 'validate_terms_agreed_at' ),
						'sanitize_callback' => 'absint',
					),
					'buyer_email'     => array(
						'type'              => 'string',
						'validate_callback' => function ( $value ) {
							return is_string( $value ) && ( '' === $value || false !== is_email( $value ) );
						},
						'sanitize_callback' => 'sanitize_email',
					),
					'buyer_country'   => array(
						'type'              => 'string',
						'validate_callback' => function ( $value ) {
							return is_string( $value ) && ( '' === $value || 1 === preg_match( '/^[A-Z]{2}$/', $value ) );
						},
						'sanitize_callback' => function ( $value ) {
							return strtoupper( sanitize_text_field( $value ) );
						},
					),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/webhooks/stripe',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_webhook' ),
				'permission_callback' => '__return_true', // Signature-gated inside the handler.
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/health',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'health' ),
				'permission_callback' => '__return_true', // Public status probe — no secrets, no Stripe, no writes.
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/license/check',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'check_license' ),
				'permission_callback' => '__return_true', // Public by design — see class docblock.
				'args'                => $this->license_args(),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/license/activate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'activate_license' ),
				'permission_callback' => '__return_true', // Public by design — see class docblock.
				'args'                => $this->license_args(),
			)
		);
	}

	/**
	 * Shared argument schema for the license endpoints.
	 *
	 * `site_url` accepts a URL **or** a stable instance id: the Laravel runtime
	 * sends an instance id (`estate-nvoos-cloud`), not a wp URL, so the strict
	 * URL validator used by `/session` would reject a legitimate client.
	 *
	 * @since 0.2.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private function license_args(): array {
		return array(
			'license_key' => array(
				'required'          => true,
				'type'              => 'string',
				'validate_callback' => function ( $value ) {
					return is_string( $value ) && 1 === preg_match( '/^[A-Za-z0-9_-]{16,64}$/', $value );
				},
				'sanitize_callback' => 'sanitize_text_field',
			),
			'site_url'    => array(
				'required'          => true,
				'type'              => 'string',
				'validate_callback' => function ( $value ) {
					return is_string( $value ) && '' !== trim( $value ) && strlen( $value ) <= 255;
				},
				'sanitize_callback' => 'sanitize_text_field',
			),
			'product'     => array(
				'required'          => true,
				'type'              => 'string',
				'validate_callback' => function ( $value ) {
					return is_string( $value ) && '' !== trim( $value ) && strlen( $value ) <= 64;
				},
				'sanitize_callback' => 'sanitize_text_field',
			),
		);
	}

	/**
	 * POST /license/check — is this key valid for this site?
	 *
	 * Every failure mode (unknown key, revoked, wrong product, wrong site)
	 * returns the same body with HTTP 200: a distinguishing status code or
	 * message would make the endpoint a key oracle. A 429 is reserved for the
	 * rate limiter, which clients treat as transient and retry.
	 *
	 * @since 0.2.0
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function check_license( WP_REST_Request $request ) {
		if ( ! NVOOS_Checkout_API_Rate_Limiter::check( 'license_check', 60, 10 * MINUTE_IN_SECONDS ) ) {
			return new WP_Error( 'nvoos_checkout_rate_limited', __( 'Too many requests. Please slow down.', 'nvoos-checkout-api' ), array( 'status' => 429 ) );
		}

		return new WP_REST_Response(
			NVOOS_Checkout_API_License_Resolver::resolve(
				(string) $request['license_key'],
				(string) $request['site_url'],
				(string) $request['product']
			),
			200
		);
	}

	/**
	 * POST /license/activate — bind-verify a key at activation time.
	 *
	 * Same resolution as `/check`; the WordPress client additionally reads
	 * `success`. The stored site is never rewritten here: a mismatch means the
	 * key belongs to another installation, and silently re-binding would let one
	 * key serve unlimited sites.
	 *
	 * @since 0.2.0
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function activate_license( WP_REST_Request $request ) {
		if ( ! NVOOS_Checkout_API_Rate_Limiter::check( 'license_activate', 20, 10 * MINUTE_IN_SECONDS ) ) {
			return new WP_Error( 'nvoos_checkout_rate_limited', __( 'Too many requests. Please slow down.', 'nvoos-checkout-api' ), array( 'status' => 429 ) );
		}

		$result = NVOOS_Checkout_API_License_Resolver::resolve(
			(string) $request['license_key'],
			(string) $request['site_url'],
			(string) $request['product']
		);

		return new WP_REST_Response(
			array_merge( array( 'success' => 'valid' === $result['status'] ), $result ),
			200
		);
	}

	/**
	 * GET /health — cheap public status probe.
	 *
	 * Lets customer sites (the free Content Graph plugin) verify that the
	 * checkout endpoint is reachable and serving before they start a
	 * payment session — without spending a rate-limit token or touching
	 * Stripe. The response is deliberately small and stable so the client
	 * can rely on it as a connectivity contract.
	 *
	 * @since 0.1.1
	 *
	 * @return WP_REST_Response
	 */
	public function health() {
		return rest_ensure_response(
			array(
				'status'      => 'ok',
				'service'     => 'nvoos-checkout',
				'version'     => defined( 'NVOOS_CHECKOUT_API_VERSION' ) ? (string) NVOOS_CHECKOUT_API_VERSION : '0.1.0',
				'configured'  => NVOOS_Checkout_API_Settings::is_configured(),
				'server_time' => time(),
			)
		);
	}

	/**
	 * POST /session — create a Stripe PaymentIntent for a product.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_session( WP_REST_Request $request ) {
		if ( ! NVOOS_Checkout_API_Rate_Limiter::check( 'session', 20, 10 * MINUTE_IN_SECONDS ) ) {
			return new WP_Error( 'nvoos_checkout_rate_limited', __( 'Too many requests. Please slow down.', 'nvoos-checkout-api' ), array( 'status' => 429 ) );
		}

		if ( ! NVOOS_Checkout_API_Settings::is_configured() ) {
			return new WP_Error( 'nvoos_checkout_unconfigured', __( 'Checkout is not configured on this store.', 'nvoos-checkout-api' ), array( 'status' => 424 ) );
		}

		$client = new NVOOS_Checkout_API_Stripe_Client( NVOOS_Checkout_API_Settings::stripe_secret_key() );

		$intent_params = array(
			'amount'                    => NVOOS_Checkout_API_Settings::price_cents(),
			'currency'                  => NVOOS_Checkout_API_Settings::currency(),
			'description'               => 'NV oOS ' . $request['product'] . ' license',
			'automatic_payment_methods' => array( 'enabled' => true ),
			'metadata'                  => array(
				'product'       => (string) $request['product'],
				'site_url'      => (string) $request['site_url'],
				'addon_version' => (string) ( $request['addon_version'] ?? '' ),
			),
		);

		// Reporting/tax metadata — the Stripe Product/Price are created from
		// the storefront admin and never change how the charge works.
		if ( '' !== NVOOS_Checkout_API_Settings::product_id() ) {
			$intent_params['metadata']['stripe_product_id'] = NVOOS_Checkout_API_Settings::product_id();
		}
		if ( '' !== NVOOS_Checkout_API_Settings::price_id() ) {
			$intent_params['metadata']['stripe_price_id'] = NVOOS_Checkout_API_Settings::price_id();
		}

		// Card statement descriptor suffix (omitted when unset/invalid so
		// Stripe's default applies). Stripe rejects the full
		// `statement_descriptor` parameter for card charges created with
		// automatic payment methods; the suffix is appended to the
		// account's statement descriptor prefix instead.
		if ( '' !== NVOOS_Checkout_API_Settings::statement_descriptor() ) {
			$intent_params['statement_descriptor_suffix'] = NVOOS_Checkout_API_Settings::statement_descriptor();
		}

		$intent = $client->create_payment_intent( $intent_params );

		if ( is_wp_error( $intent ) ) {
			return $intent;
		}

		if ( empty( $intent['client_secret'] ) ) {
			return new WP_Error( 'nvoos_checkout_session_failed', __( 'Stripe did not return a payment session.', 'nvoos-checkout-api' ), array( 'status' => 502 ) );
		}

		return rest_ensure_response(
			array(
				'client_secret'     => sanitize_text_field( (string) $intent['client_secret'] ),
				'publishable_key'   => NVOOS_Checkout_API_Settings::stripe_publishable_key(),
				'amount'            => NVOOS_Checkout_API_Settings::price_cents(),
				'currency'          => NVOOS_Checkout_API_Settings::currency(),
				'test_mode'         => NVOOS_Checkout_API_Settings::is_test_mode(),
				'terms_url'         => NVOOS_Checkout_API_Settings::terms_url(),
				'refund_policy_url' => NVOOS_Checkout_API_Settings::refund_policy_url(),
			)
		);
	}

	/**
	 * POST /verify — verify a paid intent and issue a license.
	 *
	 * Idempotent per payment intent: re-verification returns the existing
	 * license with a fresh signed download URL instead of issuing twice.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function verify_payment( WP_REST_Request $request ) {
		if ( ! NVOOS_Checkout_API_Rate_Limiter::check( 'verify', 30, 10 * MINUTE_IN_SECONDS ) ) {
			return new WP_Error( 'nvoos_checkout_rate_limited', __( 'Too many requests. Please slow down.', 'nvoos-checkout-api' ), array( 'status' => 429 ) );
		}

		if ( ! NVOOS_Checkout_API_Settings::is_configured() ) {
			return new WP_Error( 'nvoos_checkout_unconfigured', __( 'Checkout is not configured on this store.', 'nvoos-checkout-api' ), array( 'status' => 424 ) );
		}

		$client = new NVOOS_Checkout_API_Stripe_Client( NVOOS_Checkout_API_Settings::stripe_secret_key() );
		$intent = $client->retrieve_payment_intent( (string) $request['payment_intent'] );

		if ( is_wp_error( $intent ) ) {
			return $intent;
		}

		// ─── Server-side verification — the only gate that matters ───
		if ( 'succeeded' !== ( $intent['status'] ?? '' ) ) {
			return new WP_Error( 'nvoos_checkout_not_completed', __( 'This payment has not completed yet.', 'nvoos-checkout-api' ), array( 'status' => 402 ) );
		}

		$price_cents     = NVOOS_Checkout_API_Settings::price_cents();
		$store_currency  = NVOOS_Checkout_API_Settings::currency();
		$amount_received = (int) ( $intent['amount_received'] ?? 0 );
		$intent_currency = (string) ( $intent['currency'] ?? '' );

		if ( $amount_received < $price_cents ) {
			return new WP_Error( 'nvoos_checkout_amount_mismatch', __( 'The amount paid does not match the current price.', 'nvoos-checkout-api' ), array( 'status' => 402 ) );
		}

		if ( $intent_currency !== $store_currency ) {
			return new WP_Error( 'nvoos_checkout_currency_mismatch', __( 'The payment currency does not match the store currency.', 'nvoos-checkout-api' ), array( 'status' => 400 ) );
		}

		$metadata        = $intent['metadata'] ?? array();
		$request_product = (string) $request['product'];
		$request_site    = (string) $request['site_url'];
		$intent_product  = (string) ( $metadata['product'] ?? '' );
		$intent_site     = (string) ( $metadata['site_url'] ?? '' );

		if ( $request_product !== $intent_product ) {
			return new WP_Error( 'nvoos_checkout_product_mismatch', __( 'This payment was not made for the requested product.', 'nvoos-checkout-api' ), array( 'status' => 400 ) );
		}

		if ( $request_site !== $intent_site ) {
			return new WP_Error( 'nvoos_checkout_site_mismatch', __( 'This payment was created for a different site.', 'nvoos-checkout-api' ), array( 'status' => 400 ) );
		}

		// ─── Idempotent license issuance ────────────────────────────
		$terms_agreed_at = $this->terms_agreed_mysql( $request );
		// The intent's receipt_email (set by Stripe from the modal's
		// confirmParams.receipt_email) is authoritative; the request param
		// is the fallback for clients whose intent has no email.
		$buyer_email = sanitize_email( (string) ( $intent['receipt_email'] ?? $request['buyer_email'] ?? '' ) );
		// VAT records: the buyer-declared country code from the purchase
		// modal (EU buyers are required to provide an address there).
		$buyer_country = strtoupper( sanitize_text_field( (string) $request['buyer_country'] ) );

		$existing = NVOOS_Checkout_API_License_Store::get_by_payment_intent( (string) $request['payment_intent'] );
		if ( null !== $existing ) {
			if ( NVOOS_Checkout_API_License_Store::STATUS_ACTIVE !== ( $existing['status'] ?? '' ) ) {
				return new WP_Error( 'nvoos_checkout_license_revoked', __( 'This license has been revoked. Please contact support.', 'nvoos-checkout-api' ), array( 'status' => 402 ) );
			}

			// The webhook usually issues the license before the browser's
			// /verify arrives — attach the buyer's consent timestamp, email,
			// and country to that existing row (never overwrites).
			if ( '' !== $terms_agreed_at && empty( $existing['terms_agreed_at'] ) ) {
				NVOOS_Checkout_API_License_Store::set_terms_agreed( (string) $existing['license_key'], $terms_agreed_at );
				$existing['terms_agreed_at'] = $terms_agreed_at;
			}
			if ( '' !== $buyer_email && empty( $existing['buyer_email'] ) ) {
				NVOOS_Checkout_API_License_Store::set_buyer_email( (string) $existing['license_key'], $buyer_email );
				$existing['buyer_email'] = $buyer_email;
			}
			if ( '' !== $buyer_country && empty( $existing['buyer_country'] ) ) {
				NVOOS_Checkout_API_License_Store::set_buyer_country( (string) $existing['license_key'], $buyer_country );
				$existing['buyer_country'] = $buyer_country;
			}

			// Email the license record once (no-op when already sent or when
			// the row has no buyer email yet).
			NVOOS_Checkout_API_Mailer::maybe_send( $existing );

			return rest_ensure_response( $this->license_response( $existing ) );
		}

		$license = NVOOS_Checkout_API_License_Store::create(
			array(
				'license_key'           => bin2hex( random_bytes( 20 ) ),
				'product'               => (string) $request['product'],
				'site_url'              => (string) $request['site_url'],
				'stripe_payment_intent' => (string) $request['payment_intent'],
				'stripe_customer'       => isset( $intent['customer'] ) ? sanitize_text_field( (string) $intent['customer'] ) : '',
				'amount'                => (int) $intent['amount_received'],
				'currency'              => NVOOS_Checkout_API_Settings::currency(),
				'addon_version'         => NVOOS_Checkout_API_Settings::addon_version(),
				'buyer_email'           => $buyer_email,
				'buyer_country'         => $buyer_country,
				'terms_agreed_at'       => $terms_agreed_at,
			)
		);

		if ( is_wp_error( $license ) ) {
			return new WP_Error( 'nvoos_checkout_license_failed', __( 'Could not issue a license. Please contact support.', 'nvoos-checkout-api' ), array( 'status' => 500 ) );
		}

		// Email the license record once (silently skipped when disabled or
		// when the row has no buyer email).
		NVOOS_Checkout_API_Mailer::maybe_send( $license );

		return rest_ensure_response( $this->license_response( $license ) );
	}

	/**
	 * POST /webhooks/stripe — signature-gated, idempotent webhook receiver.
	 *
	 * `payment_intent.succeeded` issues the license server-side, so a buyer
	 * whose browser died right after paying still gets their license (their
	 * site's /verify call finds it later — idempotent per intent).
	 * `charge.refunded` / `charge.dispute.created` revoke the matching
	 * license. First delivery of an event returns 200 quickly; Stripe
	 * retries are acknowledged (200) without reprocessing.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_webhook( WP_REST_Request $request ) {
		$payload = $request->get_body();
		$sig     = (string) ( $request->get_header( 'stripe_signature' ) ?? '' );

		$verdict = NVOOS_Checkout_API_Stripe_Client::verify_webhook_signature(
			$payload,
			$sig,
			NVOOS_Checkout_API_Settings::stripe_webhook_secret()
		);

		if ( ! $verdict['ok'] ) {
			return new WP_Error( 'nvoos_checkout_webhook_invalid', __( 'Invalid webhook signature.', 'nvoos-checkout-api' ), array( 'status' => 401 ) );
		}

		$event = json_decode( $payload, true );
		if ( ! is_array( $event ) || empty( $event['id'] ) ) {
			return new WP_Error( 'nvoos_checkout_webhook_malformed', __( 'Malformed webhook payload.', 'nvoos-checkout-api' ), array( 'status' => 400 ) );
		}

		if ( self::is_event_processed( (string) $event['id'] ) ) {
			return rest_ensure_response(
				array(
					'received'  => true,
					'duplicate' => true,
				)
			);
		}

		self::record_event( (string) $event['id'] );

		$type = (string) ( $event['type'] ?? '' );

		// A payment succeeded — issue the license server-side so an
		// interrupted browser flow never strands a paid buyer.
		if ( 'payment_intent.succeeded' === $type ) {
			$intent = $event['data']['object'] ?? array();
			if ( is_array( $intent ) ) {
				$this->issue_license_for_intent( $intent );
			}
			return rest_ensure_response( array( 'received' => true ) );
		}

		if ( in_array( $type, array( 'charge.refunded', 'charge.dispute.created' ), true ) ) {
			$charge = $event['data']['object'] ?? array();
			if ( is_array( $charge ) && ! empty( $charge['payment_intent'] ) ) {
				$license = NVOOS_Checkout_API_License_Store::get_by_payment_intent( (string) $charge['payment_intent'] );
				if ( null !== $license ) {
					NVOOS_Checkout_API_License_Store::revoke( (string) $license['license_key'] );
				}
			}
		}

		return rest_ensure_response( array( 'received' => true ) );
	}

	/**
	 * Issue a license from a webhook-delivered PaymentIntent.
	 *
	 * Idempotent per payment intent and gated by the same server-side
	 * checks as the verify endpoint: succeeded status, amount, product
	 * and site binding from the intent metadata.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $intent PaymentIntent object from the event.
	 * @return string Outcome: 'issued', 'exists', 'not_succeeded', 'invalid_metadata', 'amount_mismatch', or 'insert_failed'.
	 */
	private function issue_license_for_intent( array $intent ): string {
		if ( 'succeeded' !== ( $intent['status'] ?? '' ) ) {
			return 'not_succeeded';
		}

		$metadata  = $intent['metadata'] ?? array();
		$product   = (string) ( $metadata['product'] ?? '' );
		$site_url  = (string) ( $metadata['site_url'] ?? '' );
		$intent_id = (string) ( $intent['id'] ?? '' );

		if ( '' === $intent_id || ! in_array( $product, self::PRODUCTS, true ) || '' === $site_url ) {
			return 'invalid_metadata';
		}

		if ( (int) ( $intent['amount_received'] ?? 0 ) < NVOOS_Checkout_API_Settings::price_cents() ) {
			return 'amount_mismatch';
		}

		if ( null !== NVOOS_Checkout_API_License_Store::get_by_payment_intent( $intent_id ) ) {
			return 'exists';
		}

		$created = NVOOS_Checkout_API_License_Store::create(
			array(
				'license_key'           => bin2hex( random_bytes( 20 ) ),
				'product'               => $product,
				'site_url'              => $site_url,
				'stripe_payment_intent' => $intent_id,
				'stripe_customer'       => isset( $intent['customer'] ) ? sanitize_text_field( (string) $intent['customer'] ) : '',
				'amount'                => (int) $intent['amount_received'],
				'currency'              => NVOOS_Checkout_API_Settings::currency(),
				'addon_version'         => NVOOS_Checkout_API_Settings::addon_version(),
				'buyer_email'           => sanitize_email( (string) ( $intent['receipt_email'] ?? '' ) ),
			)
		);

		if ( is_wp_error( $created ) ) {
			return 'insert_failed';
		}

		// Email the license record once — the webhook path is the fastest
		// reliable trigger (fires the moment Stripe confirms the payment).
		NVOOS_Checkout_API_Mailer::maybe_send( $created );

		return 'issued';
	}

	/**
	 * Shape the verify/license response payload.
	 *
	 * @param array<string,mixed> $license License row.
	 * @return array<string,mixed>
	 */
	private function license_response( array $license ): array {
		return array(
			'license_key'   => (string) $license['license_key'],
			'download_url'  => NVOOS_Checkout_API_Token::download_url( (string) $license['license_key'] ),
			'addon_version' => (string) $license['addon_version'],
			'amount'        => (int) $license['amount'],
			'currency'      => (string) $license['currency'],
		);
	}

	/**
	 * Validate a site URL (http/https with a host).
	 *
	 * @param mixed $value Candidate URL.
	 * @return bool
	 */
	public function validate_site_url( $value ): bool {
		if ( ! is_string( $value ) || '' === $value ) {
			return false;
		}
		$parts = wp_parse_url( $value );
		if ( ! is_array( $parts ) || ! in_array( $parts['scheme'] ?? '', array( 'http', 'https' ), true ) || empty( $parts['host'] ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Validate a Terms-of-Service consent timestamp.
	 *
	 * Must be a plausible Unix timestamp: no older than seven days (covers
	 * the checkout flow plus browser clock drift) and no more than ten
	 * minutes in the future.
	 *
	 * @param mixed $value Candidate Unix timestamp.
	 * @return bool
	 */
	public function validate_terms_agreed_at( $value ): bool {
		if ( ! is_numeric( $value ) ) {
			return false;
		}

		$ts = (int) $value;
		return $ts > 0
			&& $ts >= time() - 7 * DAY_IN_SECONDS
			&& $ts <= time() + 10 * MINUTE_IN_SECONDS;
	}

	/**
	 * The request's consent timestamp as a GMT MySQL datetime ('' when absent).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return string
	 */
	private function terms_agreed_mysql( WP_REST_Request $request ): string {
		$ts = (int) $request->get_param( 'terms_agreed_at' );
		return $ts > 0 ? gmdate( 'Y-m-d H:i:s', $ts ) : '';
	}

	/**
	 * Normalize a site URL to scheme + host (drops credentials/paths).
	 *
	 * @param mixed $value Raw URL.
	 * @return string
	 */
	public function sanitize_site_url( $value ): string {
		$value  = (string) $value;
		$parts  = wp_parse_url( $value );
		$scheme = ( 'https' === ( $parts['scheme'] ?? '' ) ) ? 'https' : 'http';
		return $scheme . '://' . (string) ( $parts['host'] ?? '' );
	}

	/**
	 * Whether a webhook event was already processed.
	 *
	 * @param string $event_id Stripe event ID.
	 * @return bool
	 */
	private static function is_event_processed( string $event_id ): bool {
		$seen = get_option( 'nvoos_checkout_processed_events', array() );
		return is_array( $seen ) && in_array( $event_id, $seen, true );
	}

	/**
	 * Record a processed webhook event (ring buffer of 200).
	 *
	 * @param string $event_id Stripe event ID.
	 * @return void
	 */
	private static function record_event( string $event_id ): void {
		$seen   = get_option( 'nvoos_checkout_processed_events', array() );
		$seen   = is_array( $seen ) ? $seen : array();
		$seen[] = $event_id;
		if ( count( $seen ) > 200 ) {
			$seen = array_slice( $seen, -200 );
		}
		update_option( 'nvoos_checkout_processed_events', $seen, false );
	}
}
