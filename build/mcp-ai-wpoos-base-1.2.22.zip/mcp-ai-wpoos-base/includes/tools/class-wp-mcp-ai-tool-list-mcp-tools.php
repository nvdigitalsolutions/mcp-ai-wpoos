<?php
/**
 * Tool: list_mcp_tools — Discover all MCP tools available to the current assistant.
 *
 * @package WP_MCP_AI
 * @since   1.4.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * List MCP Tools — Discovery tool.
 *
 * Returns every MCP tool available to the current assistant context,
 * including name, description, and full JSON Schema for each tool.
 * Useful for self-discovery when an AI agent needs to know what
 * capabilities are available before calling other tools.
 */
class WP_MCP_AI_Tool_List_MCP_Tools implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'list_mcp_tools';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'List MCP Tools', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Returns a list of all available MCP tools and their schemas. Useful for agent self-discovery — call this first to learn what tools are available before invoking them. Optionally filter by toolkit (e.g. "paper_store", "ecommerce") or search by name/description.', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'The model needs to discover available tools, or fetch a single tool schema on demand instead of carrying it in context.', 'mcp-ai-wpoos' ),
			'when_not_to_use' => __( 'Performing an operation — call the discovered tool itself. Avoid in long-running sessions where the catalogue is already known.', 'mcp-ai-wpoos' ),
			'related_tools'   => array( 'load_skill', 'get_tool_definition' ),
			'notes'           => __( 'Use include_schemas=false for a lean name+description catalogue, then tool_slug=<slug> to lazy-load one full schema. Set include_meta=false to omit the server-identity _meta block. Related tools may not exist on every site.', 'mcp-ai-wpoos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'toolkit'         => array(
					'type'        => 'string',
					'description' => __( 'Optional. Filter tools by toolkit namespace (e.g. "paper_store", "wordpress_core", "ecommerce").', 'mcp-ai-wpoos' ),
				),
				'search'          => array(
					'type'        => 'string',
					'description' => __( 'Optional. Search tools by name or description (case-insensitive).', 'mcp-ai-wpoos' ),
				),
				'limit'           => array(
					'type'        => 'integer',
					'description' => __( 'Maximum number of tools to return. Default 50. Max 200.', 'mcp-ai-wpoos' ),
					'minimum'     => 1,
					'maximum'     => 200,
					'default'     => 50,
				),
				'offset'          => array(
					'type'        => 'integer',
					'description' => __( 'Offset for pagination. Default 0.', 'mcp-ai-wpoos' ),
					'minimum'     => 0,
					'default'     => 0,
				),
				'tool_slug'       => array(
					'type'        => 'string',
					'description' => __( 'Optional. Return the full schema of a single tool by slug (lazy loading). When set, other list filters are ignored.', 'mcp-ai-wpoos' ),
				),
				'include_schemas' => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to include full parameter schemas in the list. Default true. Set false for a lean name/description catalogue (fetch schemas later with tool_slug).', 'mcp-ai-wpoos' ),
					'default'     => true,
				),
				'include_meta'    => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to include the _meta block with MCP server identity (server name/version/mode, site, optional bridge name). Default true.', 'mcp-ai-wpoos' ),
					'default'     => true,
				),
			),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'read';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context (may include assistant_id).
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Gate 1 — Sanitize at entry.
		$toolkit         = isset( $arguments['toolkit'] ) ? sanitize_key( $arguments['toolkit'] ) : '';
		$search          = isset( $arguments['search'] ) ? sanitize_text_field( $arguments['search'] ) : '';
		$limit           = isset( $arguments['limit'] ) ? min( absint( $arguments['limit'] ), 200 ) : 50;
		$offset          = isset( $arguments['offset'] ) ? absint( $arguments['offset'] ) : 0;
		$tool_slug       = isset( $arguments['tool_slug'] ) ? sanitize_key( $arguments['tool_slug'] ) : '';
		$include_schemas = isset( $arguments['include_schemas'] ) ? rest_sanitize_boolean( $arguments['include_schemas'] ) : true;
		$include_meta    = isset( $arguments['include_meta'] ) ? rest_sanitize_boolean( $arguments['include_meta'] ) : true;

		if ( ! current_user_can( 'read' ) ) {
			return new WP_Error( 'forbidden', __( 'Permission denied.', 'mcp-ai-wpoos' ) );
		}

		$registry     = WP_MCP_AI_Tool_Registry::get_instance();
		$assistant_id = isset( $context['assistant_id'] ) ? absint( $context['assistant_id'] ) : 0;

		// Lazy-loading mode: return a single tool's full definition on demand
		// (the Anthropic tool-search pattern). List filters are ignored.
		if ( '' !== $tool_slug && 'list_mcp_tools' !== $tool_slug ) {
			$tool = $registry->get_tool( $tool_slug );
			if ( ! $tool ) {
				return new WP_Error(
					'tool_not_found',
					sprintf(
						/* translators: %s: tool slug */
						__( 'Tool "%s" is not registered or not available in this context.', 'mcp-ai-wpoos' ),
						$tool_slug
					)
				);
			}

			$schema = $tool->get_parameters_schema();

			$payload = array(
				'name'        => $tool->get_slug(),
				'description' => $registry->get_model_facing_description( $tool ),
				'inputSchema' => is_array( $schema ) ? $schema : array(),
			);

			if ( $include_meta ) {
				$meta = $this->build_discovery_meta( $context );
				if ( ! empty( $meta ) ) {
					$payload['_meta'] = $meta;
				}
			}

			return $this->format_success_response(
				__( 'Tool schema retrieved.', 'mcp-ai-wpoos' ),
				$payload
			);
		}

		$all_tool_objects = $registry->get_tools();

		// If assistant context is available, filter to allowed tools only.
		if ( $assistant_id && class_exists( 'WP_MCP_AI_Assistant_CPT' ) ) {
			$assistant_config = WP_MCP_AI_Assistant_CPT::get_assistant_configuration( $assistant_id );
			$allowed_slugs    = isset( $assistant_config['tools'] ) ? $assistant_config['tools'] : array();

			// Include dynamically registered tools (e.g. MCP App bridges) in
			// the per-assistant catalogue filter so the listing matches the
			// tools actually sent to the LLM for this assistant.
			$allowed_slugs = apply_filters( 'wp_mcp_ai_chat_effective_tools', $allowed_slugs, $assistant_config, $assistant_id );
			if ( ! is_array( $allowed_slugs ) ) {
				$allowed_slugs = array();
			}

			if ( ! empty( $allowed_slugs ) ) {
				$filtered = array();
				foreach ( $all_tool_objects as $tool ) {
					if ( in_array( $tool->get_slug(), $allowed_slugs, true ) ) {
						$filtered[] = $tool;
					}
				}
				$all_tool_objects = $filtered;
			}
		}

		// Build result list.
		$result     = array();
		$capability = array( 'read-only', 'write', 'state-changing', 'destructive' );
		$total      = 0;

		foreach ( $all_tool_objects as $tool ) {
			try {
				$slug        = $tool->get_slug();
				$description = $tool->get_description();
				$schema      = $tool->get_parameters_schema();

				// Skip self to avoid infinite recursion in tool listing.
				if ( 'list_mcp_tools' === $slug ) {
					continue;
				}

				// Determine risk level from capability flags.
				$risk = 'info';
				if ( method_exists( $tool, 'get_capability_flags' ) ) {
					$flags = $tool->get_capability_flags();
					if ( in_array( 'destructive', $flags, true ) ) {
						$risk = 'high';
					} elseif ( in_array( 'state-changing', $flags, true ) || in_array( 'write', $flags, true ) ) {
						$risk = 'medium';
					} elseif ( in_array( 'read-only', $flags, true ) ) {
						$risk = 'low';
					}
				}

				// Determine toolkit via the registry (declared definition key,
				// falling back to the declaring folder under `*/tools/`).
				$tool_toolkit = $registry->get_tool_toolkit( $tool );

				// Apply toolkit filter.
				if ( ! empty( $toolkit ) && $toolkit !== $tool_toolkit ) {
					continue;
				}

				// Apply search filter.
				if ( ! empty( $search ) ) {
					if ( false === stripos( $slug, $search )
						&& false === stripos( $description, $search )
					) {
						continue;
					}
				}

				// Lean-catalogue mode omits schemas to save context; the model
				// lazy-loads one schema with tool_slug=<slug> when needed.
				$entry = array(
					'name'        => $slug,
					'description' => $registry->get_model_facing_description( $tool ),
					'toolkit'     => $tool_toolkit,
					'risk_level'  => $risk,
				);

				if ( $include_schemas ) {
					$entry['inputSchema'] = is_array( $schema ) ? $schema : array();
				}

				$result[] = $entry;
				++$total;
			} catch ( Exception $e ) {
				continue;
			} catch ( Error $e ) {
				continue;
			}
		}

		$total_matching = $total;
		$result         = array_slice( $result, $offset, $limit );

		// Gate 2 — Escape at exit.
		$summary = sprintf(
			/* translators: 1: displayed count, 2: total matching count */
			__( 'Found %1$d tool(s) (total matching: %2$d).', 'mcp-ai-wpoos' ),
			count( $result ),
			$total_matching
		);

		$payload = array(
			'total'  => $total_matching,
			'count'  => count( $result ),
			'limit'  => $limit,
			'offset' => $offset,
			'tools'  => $result,
		);

		if ( $include_meta ) {
			$meta = $this->build_discovery_meta( $context );
			if ( ! empty( $meta ) ) {
				$payload['_meta'] = $meta;
			}
		}

		return $this->format_success_response( $summary, $payload );
	}

	/**
	 * Build the discovery-metadata block appended when include_meta is true.
	 *
	 * Reuses the mcp_server_info identity payload (single source of truth) so
	 * the listing and the dedicated identity tool can never drift. The bridge
	 * name surfaces only when the fronting bridge declared itself.
	 *
	 * @param array $context Execution context.
	 * @return array Metadata block (empty when the identity tool is unavailable).
	 */
	private function build_discovery_meta( array $context ) {
		if ( ! class_exists( 'WP_MCP_AI_Tool_MCP_Server_Info' ) ) {
			return array();
		}

		return WP_MCP_AI_Tool_MCP_Server_Info::build_server_identity( $context );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array( 'read-only', 'local-only', 'cacheable', 'requires-capability' );
	}

	/**
	 * Get extended tool definition.
	 *
	 * @return array
	 */
	public function get_definition() {
		return array(
			'name'                  => $this->get_name(),
			'description'           => $this->get_description(),
			'toolkit'               => 'discovery',
			'pattern_compatibility' => array( 'orchestrator', 'sequential' ),
			'risk_level'            => 'info',
		);
	}
}
