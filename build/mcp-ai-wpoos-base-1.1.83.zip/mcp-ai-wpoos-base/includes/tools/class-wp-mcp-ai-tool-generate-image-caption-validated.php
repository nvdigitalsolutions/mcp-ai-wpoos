<?php
/**
 * Tool for generating image captions (Validated version).
 *
 * This is the Symfony Validator version of the generate_image_caption tool.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../validators/class-wp-mcp-ai-validated-tool.php';
require_once __DIR__ . '/../validators/arguments/class-generate-image-caption-arguments.php';
require_once __DIR__ . '/class-wp-mcp-ai-tool-generate-image-caption.php';

/**
 * Generates image captions using Symfony Validator.
 *
 * This class extends the original generate_image_caption tool to use
 * Symfony Validator for argument validation.
 */
class WP_MCP_AI_Tool_Generate_Image_Caption_Validated extends WP_MCP_AI_Validated_Tool implements WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Model_Requirements_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * The original generate_image_caption tool instance for delegation.
	 *
	 * @var WP_MCP_AI_Tool_Generate_Image_Caption
	 */
	protected $original_tool;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
		$this->original_tool = new WP_MCP_AI_Tool_Generate_Image_Caption();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_image_caption_validated';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate Image Caption (Validated)', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Generates detailed captions for images to provide context and enhance content using AI vision capabilities with Symfony Validator for argument validation.', 'mcp-ai-wpoos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Generating image captions with Symfony Validator enforcement of the image source arguments.', 'mcp-ai-wpoos' ),
			'when_not_to_use' => __( 'When validation is unneeded or unavailable; use generate_image_caption.', 'mcp-ai-wpoos' ),
			'related_tools'   => array( 'generate_image_caption', 'generate_image_alt_text_validated' ),
			'notes'           => __( 'Delegates to generate_image_caption after validation and shares its schema.', 'mcp-ai-wpoos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		// Use the same schema as the original tool.
		return $this->original_tool->get_parameters_schema();
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_validation_class() {
		return \WP_MCP_AI\Tools\Arguments\GenerateImageCaptionArguments::class;
	}

	/**
	 * Execute the tool with validated arguments.
	 *
	 * @param \WP_MCP_AI\Tools\Arguments\GenerateImageCaptionArguments $validated_args Validated arguments object.
	 * @param array                                                    $context        Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	protected function execute_validated( $validated_args, $context ) {
		// Convert validated arguments object back to array format.
		$arguments = array();

		// Add optional arguments if provided.
		if ( null !== $validated_args->image_url ) {
			$arguments['image_url'] = $validated_args->image_url;
		}

		if ( null !== $validated_args->url ) {
			$arguments['url'] = $validated_args->url;
		}

		if ( null !== $validated_args->image_content ) {
			$arguments['image_content'] = $validated_args->image_content;
		}

		if ( null !== $validated_args->attachment_id ) {
			$arguments['attachment_id'] = $validated_args->attachment_id;
		}

		if ( null !== $validated_args->file_id ) {
			$arguments['file_id'] = $validated_args->file_id;
		}

		if ( null !== $validated_args->context ) {
			$arguments['context'] = $validated_args->context;
		}

		if ( null !== $validated_args->timeout ) {
			$arguments['timeout'] = $validated_args->timeout;
		}

		// Delegate to the original tool's execute method.
		return $this->original_tool->execute( $arguments, $context );
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'content_publishing',

			'pattern_compatibility' => array( 'sequential' ),

			'profession_tags'       => array( 'content_creator', 'social_media_manager' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		// Delegate to the original tool.
		return $this->original_tool->get_capability_flags();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_model_requirements() {
		// Delegate to the original tool.
		return $this->original_tool->get_model_requirements();
	}
}
