<?php
/**
 * Tool for getting profession details.
 *
 * Retrieves detailed information about a specific profession.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gets detailed information about a profession.
 */
class WP_MCP_AI_Tool_Get_Profession implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'get_profession';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Get Profession Details', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Retrieves detailed information about a specific profession including expertise areas, role description, warnings, knowledge base content, and default tools.', 'mcp-ai-wpoos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Reading one profession profile by slug: role, expertise, warnings, and default tools.', 'mcp-ai-wpoos' ),
			'when_not_to_use' => __( 'Browsing professions, writing profiles, or stats; use list_professions, save_profession, or get_profession_stats.', 'mcp-ai-wpoos' ),
			'related_tools'   => array( 'list_professions', 'get_profession_stats', 'save_profession' ),
			'notes'           => __( 'Returns profession data from the profession service; slug examples: graphic_designer, data_scientist.', 'mcp-ai-wpoos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'profession_slug' => array(
					'type'        => 'string',
					'description' => __( 'The slug of the profession to retrieve (e.g., "graphic_designer", "data_scientist", "marine_biologist")', 'mcp-ai-wpoos' ),
					'minLength'   => 1,
				),
			),
			'required'             => array( 'profession_slug' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$profession_slug = isset( $arguments['profession_slug'] ) ? sanitize_key( $arguments['profession_slug'] ) : '';

		if ( empty( $profession_slug ) ) {
			return new WP_Error( 'missing_profession', __( 'Profession slug is required.', 'mcp-ai-wpoos' ) );
		}

		// Get profession service.
		if ( ! function_exists( 'wp_mcp_ai_get_profession_service' ) ) {
			return new WP_Error( 'system_unavailable', __( 'Profession system not available.', 'mcp-ai-wpoos' ) );
		}

		$profession_service = wp_mcp_ai_get_profession_service();
		$profession         = $profession_service->get_profession( $profession_slug );

		if ( ! $profession ) {
			return new WP_Error(
				'profession_not_found',
				sprintf(
					/* translators: %s: profession slug */
					__( 'Profession "%s" not found.', 'mcp-ai-wpoos' ),
					$profession_slug
				)
			);
		}

		$summary_text = sprintf(
			/* translators: %s: profession name */
			__( 'Profession: %s', 'mcp-ai-wpoos' ),
			isset( $profession['name'] ) ? $profession['name'] : $profession_slug
		);

		return array(
			'message'    => $summary_text,
			'summary'    => $summary_text,
			'success'    => true,
			'profession' => $profession,
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'ai_model_management',

			'pattern_compatibility' => array( 'orchestrator' ),

			'profession_tags'       => array( 'systems_administrator', 'ai_researcher' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read',         // Reads profession data.
			'local-only',   // No external API calls.
			'safe',         // Read-only operation.
		);
	}
}
