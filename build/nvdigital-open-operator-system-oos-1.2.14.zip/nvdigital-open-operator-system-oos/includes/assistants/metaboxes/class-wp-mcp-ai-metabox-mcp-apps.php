<?php
/**
 * MCP Apps Metabox for Assistants.
 *
 * Provides the admin UI for configuring MCP App connections
 * per assistant, following the MCP Apps extension (SEP-1865).
 *
 * @package WP_MCP_AI
 * @since   1.8.0
 * @see     https://modelcontextprotocol.io/extensions/apps/overview
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles the MCP Apps metabox on the assistant editor.
 *
 * Allows administrators to connect remote MCP servers to an assistant,
 * enabling tool discovery and UI resource integration per the MCP
 * specification and SEP-1865 Apps extension.
 *
 * @since 1.8.0
 */
class WP_MCP_AI_Metabox_MCP_Apps extends WP_MCP_AI_Metabox_Base {

	/**
	 * Reference to the Assistant CPT class.
	 *
	 * @var WP_MCP_AI_Assistant_CPT
	 */
	protected $cpt;

	/**
	 * Constructor.
	 *
	 * @since 1.8.0
	 * @param WP_MCP_AI_Assistant_CPT $cpt Assistant CPT instance.
	 */
	public function __construct( $cpt ) {
		$this->cpt = $cpt;
	}

	/**
	 * Get the metabox ID.
	 *
	 * @since 1.8.0
	 * @return string
	 */
	public function get_id() {
		return 'wp_mcp_ai_mcp_apps';
	}

	/**
	 * Get the metabox title.
	 *
	 * @since 1.8.0
	 * @return string
	 */
	public function get_title() {
		return __( 'MCP Apps', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get documentation URL for this metabox.
	 *
	 * @since 1.8.0
	 * @return string
	 */
	public function get_documentation_url() {
		return 'https://modelcontextprotocol.io/extensions/apps/overview';
	}

	/**
	 * Check if current user has permission to view this metabox.
	 *
	 * @since 1.8.0
	 * @return bool
	 */
	protected function can_view() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Render the metabox content.
	 *
	 * @since 1.8.0
	 * @param WP_Post $post The post object.
	 * @return void
	 */
	public function render( $post ) {
		if ( ! $this->can_view() ) {
			$this->render_permission_denied( __( 'You do not have permission to manage MCP Apps.', 'nvdigital-open-operator-system-oos' ) );
			return;
		}

		wp_nonce_field( 'wp_mcp_ai_mcp_apps_meta', 'wp_mcp_ai_mcp_apps_meta_nonce' );

		$apps     = array();
		$statuses = array();
		if ( class_exists( 'WP_MCP_AI_MCP_App_Registry' ) ) {
			$registry = WP_MCP_AI_MCP_App_Registry::get_instance();
			$apps     = $registry->get_apps( $post->ID );
			$statuses = $registry->get_app_status( $post->ID );
		}

		?>
		<div class="wp-mcp-ai-mcp-apps">
			<p class="description">
				<?php
				printf(
					/* translators: %s: URL to the MCP Apps specification */
					esc_html__( 'Connect remote MCP servers as apps to extend this assistant with external tools and interactive UIs. Apps follow the %s specification.', 'nvdigital-open-operator-system-oos' ),
					'<a href="https://modelcontextprotocol.io/extensions/apps/overview" target="_blank" rel="noopener noreferrer">' . esc_html__( 'MCP Apps (SEP-1865)', 'nvdigital-open-operator-system-oos' ) . '</a>'
				);
				?>
			</p>

			<div id="wp-mcp-ai-mcp-apps-list">
				<?php
				if ( empty( $apps ) ) {
					$this->render_empty_state();
				} else {
					foreach ( $apps as $index => $app ) {
						$status = isset( $statuses[ $registry->get_app_status_key( $app ) ] ) ? $statuses[ $registry->get_app_status_key( $app ) ] : array();
						$this->render_app_row( $index, $app, $status );
					}
				}
				?>
			</div>

			<p style="margin-top: 15px;">
				<button type="button" class="button button-secondary" id="wp-mcp-ai-add-mcp-app">
					<span class="dashicons dashicons-plus-alt2" style="vertical-align: text-bottom;"></span>
					<?php esc_html_e( 'Add MCP App', 'nvdigital-open-operator-system-oos' ); ?>
				</button>
				<?php
				// Remote Sites integration (Pro): offer centrally managed MCP Server
				// connections plus Upwork/FlowHub MCP connections as one-click reference entries.
				$remote_mcp_connections = array();
				if ( class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
					if ( method_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager', 'get_mcp_app_connections' ) ) {
						$remote_mcp_connections = WP_MCP_AI_Pro_Remote_Site_Manager::get_mcp_app_connections();
					} else {
						$remote_mcp_connections = WP_MCP_AI_Pro_Remote_Site_Manager::get_mcp_server_connections();
					}
				}
				if ( ! empty( $remote_mcp_connections ) ) :
					?>
					<select id="wp-mcp-ai-add-from-remote" style="vertical-align: middle; margin-left: 6px;">
						<?php
						foreach ( $remote_mcp_connections as $remote_mcp ) :
							$remote_type        = isset( $remote_mcp['connection_type'] ) ? $remote_mcp['connection_type'] : 'mcp_server';
							$remote_name        = isset( $remote_mcp['name'] ) ? $remote_mcp['name'] : '';
							$remote_url         = isset( $remote_mcp['url'] ) ? $remote_mcp['url'] : '';
							$remote_server_url  = '';
							$remote_option_text = $remote_name . ' (' . $remote_url . ')';

							if ( 'upwork' === $remote_type && method_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager', 'build_upwork_mcp_app_config' ) ) {
								$remote_config      = WP_MCP_AI_Pro_Remote_Site_Manager::build_upwork_mcp_app_config( $remote_mcp );
								$remote_server_url  = isset( $remote_config['server_url'] ) ? $remote_config['server_url'] : '';
								$remote_option_text = $remote_name . ' (' . __( 'Upwork MCP', 'nvdigital-open-operator-system-oos' ) . ' — ' . $remote_server_url . ')';
							} elseif ( 'flowhub' === $remote_type && method_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager', 'build_flowhub_mcp_app_config' ) ) {
								$remote_config      = WP_MCP_AI_Pro_Remote_Site_Manager::build_flowhub_mcp_app_config( $remote_mcp );
								$remote_server_url  = isset( $remote_config['server_url'] ) ? $remote_config['server_url'] : '';
								$remote_option_text = $remote_name . ' (' . __( 'FlowHub MCP', 'nvdigital-open-operator-system-oos' ) . ' — ' . $remote_server_url . ')';
							}
							?>
							<option
								value="<?php echo esc_attr( isset( $remote_mcp['id'] ) ? $remote_mcp['id'] : '' ); ?>"
								data-name="<?php echo esc_attr( $remote_name ); ?>"
								data-type="<?php echo esc_attr( $remote_type ); ?>"
								data-server-url="<?php echo esc_url( $remote_server_url ); ?>">
								<?php echo esc_html( $remote_option_text ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<button type="button" class="button button-secondary" id="wp-mcp-ai-add-from-remote-btn">
						<span class="dashicons dashicons-networking" style="vertical-align: text-bottom;"></span>
						<?php esc_html_e( 'Add from Remote Sites', 'nvdigital-open-operator-system-oos' ); ?>
					</button>
				<?php endif; ?>
				<button type="button" class="button button-secondary" id="wp-mcp-ai-test-all-mcp-apps">
					<span class="dashicons dashicons-update-alt" style="vertical-align: text-bottom;"></span>
					<?php esc_html_e( 'Test All', 'nvdigital-open-operator-system-oos' ); ?>
				</button>
				<button type="button" class="button button-link" id="wp-mcp-ai-import-mcp-apps">
					<span class="dashicons dashicons-upload" style="vertical-align: text-bottom;"></span>
					<?php esc_html_e( 'Import from JSON', 'nvdigital-open-operator-system-oos' ); ?>
				</button>
			</p>

			<div id="wp-mcp-ai-import-mcp-apps-panel" style="display:none; margin: 10px 0;">
				<label for="wp-mcp-ai-import-mcp-apps-json"><?php esc_html_e( 'Paste a generated mcpServers JSON block (e.g. from Claude Desktop, Cursor, or an NV oOS site):', 'nvdigital-open-operator-system-oos' ); ?></label>
				<textarea id="wp-mcp-ai-import-mcp-apps-json" rows="6" class="large-text code" placeholder='{"mcpServers":{"my-server":{"type":"http","url":"https://example.com/mcp","headers":{"Authorization":"Basic …"}}}}'></textarea>
				<p>
					<button type="button" class="button button-primary" id="wp-mcp-ai-import-mcp-apps-apply"><?php esc_html_e( 'Apply Import', 'nvdigital-open-operator-system-oos' ); ?></button>
					<button type="button" class="button button-link" id="wp-mcp-ai-import-mcp-apps-cancel"><?php esc_html_e( 'Cancel', 'nvdigital-open-operator-system-oos' ); ?></button>
				</p>
			</div>

			<p class="description" style="margin-top: 10px;">
				<?php
				printf(
					/* translators: %d: Maximum number of apps allowed. */
					esc_html__( 'Maximum %d MCP Apps per assistant. Each app connects to a remote MCP server via Streamable HTTP transport.', 'nvdigital-open-operator-system-oos' ),
					10
				);
				?>
			</p>
		</div>

		<?php
		$this->render_app_template();
		$this->render_script();
		$this->render_documentation_link();

		wp_register_style( 'wp-mcp-ai-metabox-mcp-apps', false, array(), WP_MCP_AI_VERSION );
		wp_enqueue_style( 'wp-mcp-ai-metabox-mcp-apps' );
		wp_add_inline_style(
			'wp-mcp-ai-metabox-mcp-apps',
			'.wp-mcp-ai-mcp-app-status-badge{display:inline-flex;align-items:center;gap:6px;margin-left:10px;padding:3px 10px;border-radius:10px;font-size:11px;font-weight:600;vertical-align:middle}'
			. '.wp-mcp-ai-mcp-app-status-dot{width:8px;height:8px;border-radius:50%;display:inline-block}'
			. '.wp-mcp-ai-mcp-app-status-ok{background:#e8f5e9;color:#1e7a1e}'
			. '.wp-mcp-ai-mcp-app-status-ok .wp-mcp-ai-mcp-app-status-dot{background:#00a32a}'
			. '.wp-mcp-ai-mcp-app-status-error{background:#ffebee;color:#b3261e}'
			. '.wp-mcp-ai-mcp-app-status-error .wp-mcp-ai-mcp-app-status-dot{background:#d63638}'
			. '.wp-mcp-ai-mcp-app-status-unknown{background:#f0f0f1;color:#646970}'
			. '.wp-mcp-ai-mcp-app-status-unknown .wp-mcp-ai-mcp-app-status-dot{background:#8c8f94}'
			. '.wp-mcp-ai-mcp-app-tool-count{margin-left:8px;padding:2px 8px;border-radius:8px;background:#eef3fa;color:#1d4ed8;font-size:11px;font-weight:600}'
			. '.wp-mcp-ai-mcp-app-managed-badge{margin-left:8px;padding:2px 8px;border-radius:8px;background:#eef3fa;color:#1d4ed8;font-size:11px;font-weight:600}'
		);
	}

	/**
	 * Save metabox data.
	 *
	 * @since 1.8.0
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public function save( $post_id, $post ) {
		if ( ! isset( $_POST['wp_mcp_ai_mcp_apps_meta_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wp_mcp_ai_mcp_apps_meta_nonce'] ) ), 'wp_mcp_ai_mcp_apps_meta' ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$apps = array();

		if ( isset( $_POST['wp_mcp_ai_mcp_apps'] ) && is_array( $_POST['wp_mcp_ai_mcp_apps'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via sanitize_app_config.
			$raw_apps = wp_unslash( $_POST['wp_mcp_ai_mcp_apps'] );

			// Preserve existing tokens when the masked token field was left
			// empty (see render_app_row — stored tokens are not echoed back).
			$existing_apps = array();
			if ( class_exists( 'WP_MCP_AI_MCP_App_Registry' ) ) {
				$existing_apps = WP_MCP_AI_MCP_App_Registry::get_instance()->get_apps( $post_id );
			}

			foreach ( $raw_apps as $index => $raw_app ) {
				if ( ! is_array( $raw_app ) ) {
					continue;
				}

				if ( empty( $raw_app['token'] ) && ! empty( $existing_apps[ $index ]['token'] ) ) {
					$raw_app['token'] = $existing_apps[ $index ]['token'];
				}

				// OAuth credentials are never echoed back into the form (they
				// are stored encrypted at rest). Restore the stored blob when
				// the submitted fields are blank so saving the page cannot
				// wipe an authenticated app.
				if (
					'oauth' === ( isset( $raw_app['auth_type'] ) ? $raw_app['auth_type'] : '' ) &&
					empty( $raw_app['oauth_data']['access_token'] ) &&
					! empty( $existing_apps[ $index ]['oauth_data']['access_token'] )
				) {
					$raw_app['oauth_data'] = $existing_apps[ $index ]['oauth_data'];
				}

				$sanitized = WP_MCP_AI_MCP_App_Registry::sanitize_app_config( $raw_app );
				if ( ! empty( $sanitized['server_url'] ) || ! empty( $sanitized['connection_ref'] ) ) {
					$apps[] = $sanitized;
				}
			}
		}

		if ( class_exists( 'WP_MCP_AI_MCP_App_Registry' ) ) {
			$registry = WP_MCP_AI_MCP_App_Registry::get_instance();
			$registry->save_apps( $post_id, $apps );
		} elseif ( empty( $apps ) ) {
			delete_post_meta( $post_id, WP_MCP_AI_MCP_App_Registry::META_KEY );
		} else {
			$sanitized_apps = array();
			foreach ( $apps as $app ) {
				$sanitized_apps[] = WP_MCP_AI_MCP_App_Registry::sanitize_app_config( $app );
			}
			update_post_meta( $post_id, WP_MCP_AI_MCP_App_Registry::META_KEY, array_slice( $sanitized_apps, 0, 10 ) );
		}
	}

	/**
	 * Render the empty state when no apps are configured.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	protected function render_empty_state() {
		?>
		<div class="wp-mcp-ai-mcp-apps-empty" id="wp-mcp-ai-mcp-apps-empty" style="padding: 20px; text-align: center; background: #f9f9f9; border: 1px solid #ddd; border-radius: 3px; margin: 15px 0;">
			<span class="dashicons dashicons-cloud" style="font-size: 32px; color: #999; display: block; margin-bottom: 10px;"></span>
			<p><?php esc_html_e( 'No MCP Apps connected yet.', 'nvdigital-open-operator-system-oos' ); ?></p>
			<p class="description"><?php esc_html_e( 'Add a remote MCP server to extend this assistant with external tools and interactive UI resources.', 'nvdigital-open-operator-system-oos' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Render a single MCP App configuration row.
	 *
	 * @since 1.8.0
	 * @since 1.9.1 Added $status parameter for the connection badge.
	 * @param int   $index  App index.
	 * @param array $app    App configuration.
	 * @param array $status Optional connection status snapshot.
	 * @return void
	 */
	protected function render_app_row( $index, $app, $status = array() ) {
		$app = wp_parse_args(
			$app,
			array(
				'label'          => '',
				'server_url'     => '',
				'auth_type'      => 'none',
				'token'          => '',
				'header_name'    => '',
				'connection_ref' => '',
				'enabled'        => true,
				'timeout'        => 30,
				'verify_ssl'     => true,
				'oauth_data'     => array(),
			)
		);

		$prefix       = 'wp_mcp_ai_mcp_apps[' . $index . ']';
		$has_status   = ! empty( $status['last_status'] );
		$status_class = $has_status && 'ok' === $status['last_status'] ? 'ok' : ( $has_status ? 'error' : 'unknown' );
		$status_text  = $has_status && 'ok' === $status['last_status'] ? __( 'Connected', 'nvdigital-open-operator-system-oos' ) : ( $has_status ? __( 'Error', 'nvdigital-open-operator-system-oos' ) : __( 'Not tested', 'nvdigital-open-operator-system-oos' ) );
		$tool_count   = $has_status && isset( $status['tool_count'] ) && null !== $status['tool_count'] ? (int) $status['tool_count'] : null;
		$last_error   = $has_status && ! empty( $status['last_error'] ) ? $status['last_error'] : '';

		// Reference rows: the connection lives in Remote Sites (Pro) and the
		// credentials/URL are managed centrally. Render a read-only row.
		if ( ! empty( $app['connection_ref'] ) ) :
			// Upwork/FlowHub MCP references carry an OAuth login (loopback
			// paste-back) so the account can be connected from the assistant
			// page itself.
			$ref_kind       = ''; // Empty string, the upwork slug, or the flowhub slug.
			$ref_server_url = '';
			$ref_authed     = false;
			if ( class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
				$ref_connection = WP_MCP_AI_Pro_Remote_Site_Manager::get_connection( $app['connection_ref'] );
				if ( is_array( $ref_connection ) && method_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager', 'is_mcp_app_connection' ) ) {
					$ref_type = isset( $ref_connection['connection_type'] ) ? $ref_connection['connection_type'] : '';
					if ( 'upwork' === $ref_type && 'mcp' === ( isset( $ref_connection['upwork_mode'] ) ? $ref_connection['upwork_mode'] : '' ) && method_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager', 'build_upwork_mcp_app_config' ) ) {
						$ref_kind       = 'upwork';
						$ref_config     = WP_MCP_AI_Pro_Remote_Site_Manager::build_upwork_mcp_app_config( $ref_connection );
						$ref_server_url = isset( $ref_config['server_url'] ) ? $ref_config['server_url'] : '';
						$ref_authed     = ! empty( $ref_connection['mcp_oauth'] );
					} elseif ( 'flowhub' === $ref_type && 'mcp' === ( isset( $ref_connection['flowhub_mode'] ) ? $ref_connection['flowhub_mode'] : '' ) && method_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager', 'build_flowhub_mcp_app_config' ) ) {
						$ref_kind       = 'flowhub';
						$ref_config     = WP_MCP_AI_Pro_Remote_Site_Manager::build_flowhub_mcp_app_config( $ref_connection );
						$ref_server_url = isset( $ref_config['server_url'] ) ? $ref_config['server_url'] : '';
						$ref_authed     = ! empty( $ref_connection['mcp_oauth'] );
					}
				}
			}
			?>
			<div class="wp-mcp-ai-mcp-app-row" style="border: 1px solid #dcdcde; border-radius: 3px; padding: 15px; margin: 10px 0; background: #fff;">
				<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
					<span>
						<strong class="wp-mcp-ai-mcp-app-title">
							<?php echo esc_html( ! empty( $app['label'] ) ? $app['label'] : __( 'MCP App', 'nvdigital-open-operator-system-oos' ) ); ?>
						</strong>
						<span class="wp-mcp-ai-mcp-app-status-badge wp-mcp-ai-mcp-app-status-<?php echo esc_attr( $status_class ); ?>" <?php echo $last_error ? 'title="' . esc_attr( $last_error ) . '"' : ''; ?>>
							<span class="wp-mcp-ai-mcp-app-status-dot"></span>
							<span class="wp-mcp-ai-mcp-app-status-text"><?php echo esc_html( $status_text ); ?></span>
						</span>
						<?php if ( null !== $tool_count ) : ?>
							<span class="wp-mcp-ai-mcp-app-tool-count">
								<?php
								printf(
									/* translators: %d: number of tools. */
									esc_html( _n( '%d tool', '%d tools', $tool_count, 'nvdigital-open-operator-system-oos' ) ),
									(int) $tool_count
								);
								?>
							</span>
						<?php endif; ?>
						<span class="wp-mcp-ai-mcp-app-managed-badge"><?php esc_html_e( 'Managed in Remote Sites', 'nvdigital-open-operator-system-oos' ); ?></span>
					</span>
					<div>
						<label style="margin-right: 10px;">
							<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[enabled]" value="0" />
							<input type="checkbox" name="<?php echo esc_attr( $prefix ); ?>[enabled]" value="1" <?php checked( $app['enabled'] ); ?> />
							<?php esc_html_e( 'Enabled', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
						<button type="button" class="button button-link-delete wp-mcp-ai-remove-mcp-app"><?php esc_html_e( 'Remove', 'nvdigital-open-operator-system-oos' ); ?></button>
					</div>
				</div>
				<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[connection_ref]" value="<?php echo esc_attr( $app['connection_ref'] ); ?>" />
				<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[label]" value="<?php echo esc_attr( $app['label'] ); ?>" />
				<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[auth_type]" value="none" />
				<p class="description" style="margin: 0;">
					<?php
					if ( 'upwork' === $ref_kind ) {
						esc_html_e( 'This app connects to the official Upwork MCP gateway through a centrally managed Remote Sites connection. Complete the OAuth login below to finish setup.', 'nvdigital-open-operator-system-oos' );
					} elseif ( 'flowhub' === $ref_kind ) {
						esc_html_e( 'This app connects to the official FlowHub MCP gateway through a centrally managed Remote Sites connection. Complete the OAuth login below to finish setup.', 'nvdigital-open-operator-system-oos' );
					} else {
						printf(
							/* translators: %s: Remote Sites admin URL. */
							esc_html__( 'This app connects through a centrally managed MCP Server connection. Credentials and endpoint are managed on the %s page.', 'nvdigital-open-operator-system-oos' ),
							'<a href="' . esc_url( admin_url( 'admin.php?page=wp-mcp-ai-remote-sites' ) ) . '" target="_blank">' . esc_html__( 'Remote Sites', 'nvdigital-open-operator-system-oos' ) . '</a>'
						);
					}
					?>
				</p>
				<?php if ( '' !== $ref_kind ) : ?>
				<div class="wp-mcp-ai-ref-oauth-row" style="margin-top: 10px;">
					<?php if ( $ref_authed ) : ?>
						<p>
							<span class="dashicons dashicons-yes-alt" style="color: #00a32a;"></span>
							<?php
							if ( 'upwork' === $ref_kind ) {
								esc_html_e( 'Authenticated via Upwork OAuth login. Tokens are stored centrally and refreshed automatically.', 'nvdigital-open-operator-system-oos' );
							} else {
								esc_html_e( 'Authenticated via FlowHub OAuth login. Tokens are stored centrally and refreshed automatically.', 'nvdigital-open-operator-system-oos' );
							}
							?>
						</p>
					<?php else : ?>
						<p class="description">
							<?php esc_html_e( 'Click the button below to connect via browser-based OAuth 2.1 login.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
					<?php endif; ?>
					<button type="button" class="button wp-mcp-ai-connect-oauth"
						data-server-url="<?php echo esc_url( $ref_server_url ); ?>"
						<?php echo $ref_authed ? 'style="display:none;"' : ''; ?>>
						<?php esc_html_e( 'Connect via Web Login', 'nvdigital-open-operator-system-oos' ); ?>
					</button>
					<button type="button" class="button wp-mcp-ai-reconnect-oauth"
						data-server-url="<?php echo esc_url( $ref_server_url ); ?>"
						<?php echo ! $ref_authed ? 'style="display:none;"' : ''; ?>>
						<?php esc_html_e( 'Re-authenticate', 'nvdigital-open-operator-system-oos' ); ?>
					</button>
					<div class="wp-mcp-ai-oauth-manual" style="display:none; margin-top: 10px;">
						<p class="description">
							<?php
							if ( 'upwork' === $ref_kind ) {
								esc_html_e( 'Upwork only allows "localhost" callback URLs, so the login tab ends on a localhost address that does not load. If that happens: copy the full address from the login tab\'s address bar, paste it below, and click Complete Login.', 'nvdigital-open-operator-system-oos' );
							} else {
								esc_html_e( 'If the login tab ends on a "localhost" address that does not load: copy the full address from the login tab\'s address bar, paste it below, and click Complete Login.', 'nvdigital-open-operator-system-oos' );
							}
							?>
						</p>
						<a href="#" class="wp-mcp-ai-oauth-open-link" target="_blank" rel="noopener noreferrer" style="display: block; margin-bottom: 6px;"><?php esc_html_e( 'Open the login page', 'nvdigital-open-operator-system-oos' ); ?></a>
						<input type="text" class="regular-text wp-mcp-ai-oauth-callback-url" placeholder="http://localhost:PORT/callback?code=...&state=..." />
						<button type="button" class="button button-primary wp-mcp-ai-complete-oauth"><?php esc_html_e( 'Complete Login', 'nvdigital-open-operator-system-oos' ); ?></button>
						<span class="spinner wp-mcp-ai-oauth-complete-spinner" style="display:none; float:none; margin: 0 0 0 6px;"></span>
					</div>
				</div>
				<?php endif; ?>
			</div>
			<?php
			return;
		endif;
		?>
		<div class="wp-mcp-ai-mcp-app-row" style="border: 1px solid #dcdcde; border-radius: 3px; padding: 15px; margin: 10px 0; background: #fff;">
			<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
				<span>
					<strong class="wp-mcp-ai-mcp-app-title">
						<?php echo esc_html( ! empty( $app['label'] ) ? $app['label'] : __( 'MCP App', 'nvdigital-open-operator-system-oos' ) ); ?>
					</strong>
					<span class="wp-mcp-ai-mcp-app-status-badge wp-mcp-ai-mcp-app-status-<?php echo esc_attr( $status_class ); ?>" <?php echo $last_error ? 'title="' . esc_attr( $last_error ) . '"' : ''; ?>>
						<span class="wp-mcp-ai-mcp-app-status-dot"></span>
						<span class="wp-mcp-ai-mcp-app-status-text"><?php echo esc_html( $status_text ); ?></span>
					</span>
					<?php if ( null !== $tool_count ) : ?>
						<span class="wp-mcp-ai-mcp-app-tool-count">
							<?php
							printf(
								/* translators: %d: number of tools. */
								esc_html( _n( '%d tool', '%d tools', $tool_count, 'nvdigital-open-operator-system-oos' ) ),
								(int) $tool_count
							);
							?>
						</span>
					<?php endif; ?>
				</span>
				<div>
					<label style="margin-right: 10px;">
						<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[enabled]" value="0" />
						<input type="checkbox" name="<?php echo esc_attr( $prefix ); ?>[enabled]" value="1" <?php checked( $app['enabled'] ); ?> />
						<?php esc_html_e( 'Enabled', 'nvdigital-open-operator-system-oos' ); ?>
					</label>
					<button type="button" class="button button-link-delete wp-mcp-ai-remove-mcp-app"><?php esc_html_e( 'Remove', 'nvdigital-open-operator-system-oos' ); ?></button>
				</div>
			</div>

			<table class="form-table" style="margin: 0;">
				<tr>
					<th scope="row"><label><?php esc_html_e( 'Label', 'nvdigital-open-operator-system-oos' ); ?></label></th>
					<td>
						<input type="text" name="<?php echo esc_attr( $prefix ); ?>[label]" value="<?php echo esc_attr( $app['label'] ); ?>" class="regular-text wp-mcp-ai-mcp-app-label" placeholder="<?php esc_attr_e( 'My MCP App', 'nvdigital-open-operator-system-oos' ); ?>" />
						<p class="description"><?php esc_html_e( 'A friendly name for this MCP App connection.', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label><?php esc_html_e( 'Server URL', 'nvdigital-open-operator-system-oos' ); ?></label></th>
					<td>
						<input type="url" name="<?php echo esc_attr( $prefix ); ?>[server_url]" value="<?php echo esc_attr( $app['server_url'] ); ?>" class="regular-text" placeholder="https://example.com/mcp" required />
						<p class="description"><?php esc_html_e( 'The remote MCP server endpoint URL (Streamable HTTP transport).', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label><?php esc_html_e( 'Authentication', 'nvdigital-open-operator-system-oos' ); ?></label></th>
					<td>
						<select name="<?php echo esc_attr( $prefix ); ?>[auth_type]" class="wp-mcp-ai-mcp-app-auth-type">
							<option value="none" <?php selected( $app['auth_type'], 'none' ); ?>><?php esc_html_e( 'None', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="bearer" <?php selected( $app['auth_type'], 'bearer' ); ?>><?php esc_html_e( 'Bearer Token', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="basic" <?php selected( $app['auth_type'], 'basic' ); ?>><?php esc_html_e( 'Basic Auth (User:Password)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="header" <?php selected( $app['auth_type'], 'header' ); ?>><?php esc_html_e( 'Custom Header', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="oauth" <?php selected( $app['auth_type'], 'oauth' ); ?>><?php esc_html_e( 'OAuth 2.0 Web Login', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
					</td>
				</tr>
				<tr class="wp-mcp-ai-mcp-app-token-row" <?php echo in_array( $app['auth_type'], array( 'none', 'oauth' ), true ) ? 'style="display:none;"' : ''; ?>>
						<th scope="row"><label><?php esc_html_e( 'Token / API Key', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<input type="password" name="<?php echo esc_attr( $prefix ); ?>[token]" value="" class="regular-text wp-mcp-ai-mcp-app-token-input" autocomplete="off" placeholder="<?php echo ! empty( $app['token'] ) ? esc_attr__( '•••••••• (unchanged)', 'nvdigital-open-operator-system-oos' ) : ''; ?>" />
							<p class="description">
								<?php
								if ( ! empty( $app['token'] ) ) {
									esc_html_e( 'A credential is stored. Leave blank to keep it, or type a new one to replace it.', 'nvdigital-open-operator-system-oos' );
								} else {
									esc_html_e( 'For Basic Auth, enter user:password or a pre-encoded base64 credential.', 'nvdigital-open-operator-system-oos' );
								}
								?>
							</p>
						</td>
					</tr>
					<tr class="wp-mcp-ai-mcp-app-header-row" <?php echo 'header' !== $app['auth_type'] ? 'style="display:none;"' : ''; ?>>
						<th scope="row"><label><?php esc_html_e( 'Header Name', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<input type="text" name="<?php echo esc_attr( $prefix ); ?>[header_name]" value="<?php echo esc_attr( $app['header_name'] ); ?>" class="regular-text" placeholder="X-API-Key" />
						</td>
					</tr>
					<tr class="wp-mcp-ai-mcp-app-oauth-row" <?php echo 'oauth' !== $app['auth_type'] ? 'style="display:none;"' : ''; ?>>
						<th scope="row"><label><?php esc_html_e( 'OAuth Login', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<?php
							$has_oauth = ! empty( $app['oauth_data']['access_token'] );
							if ( $has_oauth ) :
								$scope      = ! empty( $app['oauth_data']['scope'] ) ? $app['oauth_data']['scope'] : __( 'default', 'nvdigital-open-operator-system-oos' );
								$issued_at  = ! empty( $app['oauth_data']['issued_at'] ) ? (int) $app['oauth_data']['issued_at'] : 0;
								$expires_in = ! empty( $app['oauth_data']['expires_in'] ) ? (int) $app['oauth_data']['expires_in'] : 3600;
								$expires_at = $issued_at + $expires_in;
								?>
								<p>
									<span class="dashicons dashicons-yes-alt" style="color: #00a32a;"></span>
									<?php esc_html_e( 'Authenticated via OAuth 2.0.', 'nvdigital-open-operator-system-oos' ); ?>
									<?php if ( $scope ) : ?>
										(<?php esc_html_e( 'Scope', 'nvdigital-open-operator-system-oos' ); ?>: <?php echo esc_html( $scope ); ?>)
									<?php endif; ?>
								</p>
								<p class="description">
									<?php esc_html_e( 'Tokens are stored securely and automatically refreshed.', 'nvdigital-open-operator-system-oos' ); ?>
								</p>
								<?php
							else :
								?>
								<p class="description">
									<?php esc_html_e( 'Click the button below to connect via browser-based OAuth 2.0 login.', 'nvdigital-open-operator-system-oos' ); ?>
								</p>
								<?php
							endif;
							?>
							<button type="button" class="button wp-mcp-ai-connect-oauth"
								data-server-url="<?php echo esc_url( $app['server_url'] ); ?>"
								<?php echo $has_oauth ? 'style="display:none;"' : ''; ?>>
								<?php esc_html_e( 'Connect via Web Login', 'nvdigital-open-operator-system-oos' ); ?>
							</button>
							<button type="button" class="button wp-mcp-ai-reconnect-oauth"
								data-server-url="<?php echo esc_url( $app['server_url'] ); ?>"
								<?php echo ! $has_oauth ? 'style="display:none;"' : ''; ?>>
								<?php esc_html_e( 'Re-authenticate', 'nvdigital-open-operator-system-oos' ); ?>
							</button>
							<div class="wp-mcp-ai-oauth-manual" style="<?php echo $has_oauth ? 'display:none;' : ''; ?>margin-top: 10px;">
								<p class="description">
									<?php esc_html_e( 'Some servers (e.g. Upwork) only allow "localhost" callback URLs, so the login tab ends on a localhost address that does not load. If that happens: copy the full address from the login tab\'s address bar, paste it below, and click Complete Login.', 'nvdigital-open-operator-system-oos' ); ?>
								</p>
								<a href="#" class="wp-mcp-ai-oauth-open-link" target="_blank" rel="noopener noreferrer" style="display: block; margin-bottom: 6px;"><?php esc_html_e( 'Open the login page', 'nvdigital-open-operator-system-oos' ); ?></a>
								<input type="text" class="regular-text wp-mcp-ai-oauth-callback-url" placeholder="http://localhost:PORT/callback?code=...&state=..." />
								<button type="button" class="button button-primary wp-mcp-ai-complete-oauth"><?php esc_html_e( 'Complete Login', 'nvdigital-open-operator-system-oos' ); ?></button>
								<span class="spinner wp-mcp-ai-oauth-complete-spinner" style="display:none; float:none; margin: 0 0 0 6px;"></span>
							</div>
							<?php
							// Secrets are stored encrypted and never echoed back into the page.
							// Blank submissions preserve the stored credentials (see save()).
							foreach ( array( 'access_token', 'refresh_token', 'token_type', 'expires_in', 'scope', 'issued_at', 'client_id' ) as $field ) {
								?>
								<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[oauth_data][<?php echo esc_attr( $field ); ?>]" value="" />
								<?php
							}
							?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Timeout', 'nvdigital-open-operator-system-oos' ); ?></label></th>
					<td>
						<input type="number" name="<?php echo esc_attr( $prefix ); ?>[timeout]" value="<?php echo esc_attr( $app['timeout'] ); ?>" min="1" max="120" style="width: 80px;" />
						<span class="description"><?php esc_html_e( 'seconds', 'nvdigital-open-operator-system-oos' ); ?></span>
					</td>
				</tr>
				<tr>
					<th scope="row"><label><?php esc_html_e( 'Verify SSL', 'nvdigital-open-operator-system-oos' ); ?></label></th>
					<td>
						<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[verify_ssl]" value="0" />
						<label>
							<input type="checkbox" name="<?php echo esc_attr( $prefix ); ?>[verify_ssl]" value="1" <?php checked( $app['verify_ssl'] ); ?> />
							<?php esc_html_e( 'Verify SSL certificate on the remote server.', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
			</table>

			<div class="wp-mcp-ai-mcp-app-actions" style="margin-top: 12px;">
				<button type="button" class="button wp-mcp-ai-test-mcp-app">
					<span class="dashicons dashicons-admin-links" style="vertical-align: text-bottom;"></span>
					<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
				</button>
				<button type="button" class="button wp-mcp-ai-discover-mcp-app">
					<span class="dashicons dashicons-search" style="vertical-align: text-bottom;"></span>
					<?php esc_html_e( 'Discover Tools', 'nvdigital-open-operator-system-oos' ); ?>
				</button>
				<span class="spinner wp-mcp-ai-mcp-app-spinner" style="display:none; float:none; margin-top:0;"></span>
			</div>

			<div class="wp-mcp-ai-mcp-app-result" style="display:none; margin-top: 10px;"></div>
		</div>
		<?php
	}

	/**
	 * Render the JavaScript template for adding new app rows.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	protected function render_app_template() {
		?>
		<script type="text/html" id="tmpl-wp-mcp-ai-mcp-app-row">
			<div class="wp-mcp-ai-mcp-app-row" style="border: 1px solid #dcdcde; border-radius: 3px; padding: 15px; margin: 10px 0; background: #fff;">
				<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
					<span>
						<strong class="wp-mcp-ai-mcp-app-title"><?php esc_html_e( 'New MCP App', 'nvdigital-open-operator-system-oos' ); ?></strong>
						<span class="wp-mcp-ai-mcp-app-status-badge wp-mcp-ai-mcp-app-status-unknown">
							<span class="wp-mcp-ai-mcp-app-status-dot"></span>
							<span class="wp-mcp-ai-mcp-app-status-text"><?php esc_html_e( 'Not tested', 'nvdigital-open-operator-system-oos' ); ?></span>
						</span>
					</span>
					<div>
						<label style="margin-right: 10px;">
							<input type="hidden" name="wp_mcp_ai_mcp_apps[{{data.index}}][enabled]" value="0" />
							<input type="checkbox" name="wp_mcp_ai_mcp_apps[{{data.index}}][enabled]" value="1" checked />
							<?php esc_html_e( 'Enabled', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
						<button type="button" class="button button-link-delete wp-mcp-ai-remove-mcp-app"><?php esc_html_e( 'Remove', 'nvdigital-open-operator-system-oos' ); ?></button>
					</div>
				</div>

				<table class="form-table" style="margin: 0;">
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Label', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<input type="text" name="wp_mcp_ai_mcp_apps[{{data.index}}][label]" value="" class="regular-text wp-mcp-ai-mcp-app-label" placeholder="<?php esc_attr_e( 'My MCP App', 'nvdigital-open-operator-system-oos' ); ?>" />
							<p class="description"><?php esc_html_e( 'A friendly name for this MCP App connection.', 'nvdigital-open-operator-system-oos' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Server URL', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<input type="url" name="wp_mcp_ai_mcp_apps[{{data.index}}][server_url]" value="" class="regular-text" placeholder="https://example.com/mcp" required />
							<p class="description"><?php esc_html_e( 'The remote MCP server endpoint URL (Streamable HTTP transport).', 'nvdigital-open-operator-system-oos' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Authentication', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<select name="wp_mcp_ai_mcp_apps[{{data.index}}][auth_type]" class="wp-mcp-ai-mcp-app-auth-type">
								<option value="none"><?php esc_html_e( 'None', 'nvdigital-open-operator-system-oos' ); ?></option>
								<option value="bearer"><?php esc_html_e( 'Bearer Token', 'nvdigital-open-operator-system-oos' ); ?></option>
								<option value="basic"><?php esc_html_e( 'Basic Auth (User:Password)', 'nvdigital-open-operator-system-oos' ); ?></option>
								<option value="header"><?php esc_html_e( 'Custom Header', 'nvdigital-open-operator-system-oos' ); ?></option>
								<option value="oauth"><?php esc_html_e( 'OAuth 2.0 Web Login', 'nvdigital-open-operator-system-oos' ); ?></option>
							</select>
						</td>
					</tr>
					<tr class="wp-mcp-ai-mcp-app-token-row" style="display:none;">
						<th scope="row"><label><?php esc_html_e( 'Token / API Key', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<input type="password" name="wp_mcp_ai_mcp_apps[{{data.index}}][token]" value="" class="regular-text wp-mcp-ai-mcp-app-token-input" autocomplete="off" />
							<p class="description"><?php esc_html_e( 'For Basic Auth, enter user:password or a pre-encoded base64 credential.', 'nvdigital-open-operator-system-oos' ); ?></p>
						</td>
					</tr>
					<tr class="wp-mcp-ai-mcp-app-header-row" style="display:none;">
						<th scope="row"><label><?php esc_html_e( 'Header Name', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<input type="text" name="wp_mcp_ai_mcp_apps[{{data.index}}][header_name]" value="" class="regular-text" placeholder="X-API-Key" />
						</td>
					</tr>
					<tr class="wp-mcp-ai-mcp-app-oauth-row" style="display:none;">
						<th scope="row"><label><?php esc_html_e( 'OAuth Login', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<p class="description">
								<?php esc_html_e( 'Click the button below to connect via browser-based OAuth 2.0 login.', 'nvdigital-open-operator-system-oos' ); ?>
							</p>
							<button type="button" class="button wp-mcp-ai-connect-oauth">
								<?php esc_html_e( 'Connect via Web Login', 'nvdigital-open-operator-system-oos' ); ?>
							</button>
							<button type="button" class="button wp-mcp-ai-reconnect-oauth" style="display:none;">
								<?php esc_html_e( 'Re-authenticate', 'nvdigital-open-operator-system-oos' ); ?>
							</button>
							<div class="wp-mcp-ai-oauth-manual" style="margin-top: 10px;">
								<p class="description">
									<?php esc_html_e( 'Some servers (e.g. Upwork) only allow "localhost" callback URLs, so the login tab ends on a localhost address that does not load. If that happens: copy the full address from the login tab\'s address bar, paste it below, and click Complete Login.', 'nvdigital-open-operator-system-oos' ); ?>
								</p>
								<a href="#" class="wp-mcp-ai-oauth-open-link" target="_blank" rel="noopener noreferrer" style="display: block; margin-bottom: 6px;"><?php esc_html_e( 'Open the login page', 'nvdigital-open-operator-system-oos' ); ?></a>
								<input type="text" class="regular-text wp-mcp-ai-oauth-callback-url" placeholder="http://localhost:PORT/callback?code=...&state=..." />
								<button type="button" class="button button-primary wp-mcp-ai-complete-oauth"><?php esc_html_e( 'Complete Login', 'nvdigital-open-operator-system-oos' ); ?></button>
								<span class="spinner wp-mcp-ai-oauth-complete-spinner" style="display:none; float:none; margin: 0 0 0 6px;"></span>
							</div>
							<?php
							foreach ( array( 'access_token', 'refresh_token', 'token_type', 'expires_in', 'scope', 'issued_at', 'client_id' ) as $field ) {
								?>
								<input type="hidden" name="wp_mcp_ai_mcp_apps[{{data.index}}][oauth_data][<?php echo esc_attr( $field ); ?>]" value="" />
								<?php
							}
							?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Timeout', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<input type="number" name="wp_mcp_ai_mcp_apps[{{data.index}}][timeout]" value="30" min="1" max="120" style="width: 80px;" />
							<span class="description"><?php esc_html_e( 'seconds', 'nvdigital-open-operator-system-oos' ); ?></span>
						</td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Verify SSL', 'nvdigital-open-operator-system-oos' ); ?></label></th>
						<td>
							<input type="hidden" name="wp_mcp_ai_mcp_apps[{{data.index}}][verify_ssl]" value="0" />
							<label>
								<input type="checkbox" name="wp_mcp_ai_mcp_apps[{{data.index}}][verify_ssl]" value="1" checked />
								<?php esc_html_e( 'Verify SSL certificate on the remote server.', 'nvdigital-open-operator-system-oos' ); ?>
							</label>
						</td>
					</tr>
				</table>

				<div class="wp-mcp-ai-mcp-app-actions" style="margin-top: 12px;">
					<button type="button" class="button wp-mcp-ai-test-mcp-app">
						<span class="dashicons dashicons-admin-links" style="vertical-align: text-bottom;"></span>
						<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
					</button>
					<button type="button" class="button wp-mcp-ai-discover-mcp-app">
						<span class="dashicons dashicons-search" style="vertical-align: text-bottom;"></span>
						<?php esc_html_e( 'Discover Tools', 'nvdigital-open-operator-system-oos' ); ?>
					</button>
					<span class="spinner wp-mcp-ai-mcp-app-spinner" style="display:none; float:none; margin-top:0;"></span>
				</div>

				<div class="wp-mcp-ai-mcp-app-result" style="display:none; margin-top: 10px;"></div>
			</div>
		</script>
			<script type="text/html" id="tmpl-wp-mcp-ai-mcp-app-ref-row">
				<div class="wp-mcp-ai-mcp-app-row" style="border: 1px solid #dcdcde; border-radius: 3px; padding: 15px; margin: 10px 0; background: #fff;">
					<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
						<span>
							<strong class="wp-mcp-ai-mcp-app-title"><?php esc_html_e( 'Remote Sites MCP Server', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<span class="wp-mcp-ai-mcp-app-status-badge wp-mcp-ai-mcp-app-status-unknown">
								<span class="wp-mcp-ai-mcp-app-status-dot"></span>
								<span class="wp-mcp-ai-mcp-app-status-text"><?php esc_html_e( 'Not tested', 'nvdigital-open-operator-system-oos' ); ?></span>
							</span>
							<span class="wp-mcp-ai-mcp-app-managed-badge"><?php esc_html_e( 'Managed in Remote Sites', 'nvdigital-open-operator-system-oos' ); ?></span>
						</span>
						<div>
							<label style="margin-right: 10px;">
								<input type="hidden" name="wp_mcp_ai_mcp_apps[{{data.index}}][enabled]" value="0" />
								<input type="checkbox" name="wp_mcp_ai_mcp_apps[{{data.index}}][enabled]" value="1" checked />
								<?php esc_html_e( 'Enabled', 'nvdigital-open-operator-system-oos' ); ?>
							</label>
							<button type="button" class="button button-link-delete wp-mcp-ai-remove-mcp-app"><?php esc_html_e( 'Remove', 'nvdigital-open-operator-system-oos' ); ?></button>
						</div>
					</div>
					<input type="hidden" name="wp_mcp_ai_mcp_apps[{{data.index}}][connection_ref]" value="" />
					<input type="hidden" name="wp_mcp_ai_mcp_apps[{{data.index}}][label]" value="" />
					<input type="hidden" name="wp_mcp_ai_mcp_apps[{{data.index}}][auth_type]" value="none" />
					<p class="description wp-mcp-ai-ref-description" style="margin: 0;"><?php esc_html_e( 'This app connects through a centrally managed MCP Server connection. Credentials and endpoint are managed on the Remote Sites page.', 'nvdigital-open-operator-system-oos' ); ?></p>
					<div class="wp-mcp-ai-ref-oauth-row" style="display: none; margin-top: 10px;">
						<p class="description"><?php esc_html_e( 'Click the button below to connect via browser-based OAuth 2.1 login.', 'nvdigital-open-operator-system-oos' ); ?></p>
						<button type="button" class="button wp-mcp-ai-connect-oauth">
							<?php esc_html_e( 'Connect via Web Login', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<button type="button" class="button wp-mcp-ai-reconnect-oauth" style="display:none;">
							<?php esc_html_e( 'Re-authenticate', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<div class="wp-mcp-ai-oauth-manual" style="display: none; margin-top: 10px;">
							<p class="description">
								<?php esc_html_e( 'Some servers (e.g. Upwork) only allow "localhost" callback URLs, so the login tab ends on a localhost address that does not load. If that happens: copy the full address from the login tab\'s address bar, paste it below, and click Complete Login.', 'nvdigital-open-operator-system-oos' ); ?>
							</p>
							<a href="#" class="wp-mcp-ai-oauth-open-link" target="_blank" rel="noopener noreferrer" style="display: block; margin-bottom: 6px;"><?php esc_html_e( 'Open the login page', 'nvdigital-open-operator-system-oos' ); ?></a>
							<input type="text" class="regular-text wp-mcp-ai-oauth-callback-url" placeholder="http://localhost:PORT/callback?code=...&state=..." />
							<button type="button" class="button button-primary wp-mcp-ai-complete-oauth"><?php esc_html_e( 'Complete Login', 'nvdigital-open-operator-system-oos' ); ?></button>
							<span class="spinner wp-mcp-ai-oauth-complete-spinner" style="display:none; float:none; margin: 0 0 0 6px;"></span>
						</div>
					</div>
				</div>
			</script>
		<?php
	}

		/**
		 * Render the JavaScript for the MCP Apps metabox.
		 *
		 * @since 1.8.0
		 * @since 1.9.1 Added Test Connection, Discover Tools, Test All, and JSON import.
		 * @return void
		 */
	protected function render_script() {
		$app_index        = (int) count( $this->get_current_apps_count() );
		$max_apps_message = esc_js( __( 'Maximum number of MCP Apps reached.', 'nvdigital-open-operator-system-oos' ) );
		$confirm_message  = esc_js( __( 'Remove this MCP App connection?', 'nvdigital-open-operator-system-oos' ) );
		$mcp_app_label    = esc_js( __( 'MCP App', 'nvdigital-open-operator-system-oos' ) );
		$lbl_connected    = esc_js( __( 'Connected', 'nvdigital-open-operator-system-oos' ) );
		$lbl_error        = esc_js( __( 'Error', 'nvdigital-open-operator-system-oos' ) );
		$lbl_not_tested   = esc_js( __( 'Not tested', 'nvdigital-open-operator-system-oos' ) );
		$lbl_tool         = esc_js( __( 'tool', 'nvdigital-open-operator-system-oos' ) );
		$lbl_tools        = esc_js( __( 'tools', 'nvdigital-open-operator-system-oos' ) );
		$lbl_url_required = esc_js( __( 'Please enter a Server URL first.', 'nvdigital-open-operator-system-oos' ) );
		$lbl_invalid_json = esc_js( __( 'The pasted text is not valid JSON. Expected a mcpServers block.', 'nvdigital-open-operator-system-oos' ) );
		$lbl_no_servers   = esc_js( __( 'No mcpServers entries found in the pasted JSON.', 'nvdigital-open-operator-system-oos' ) );
		$lbl_import_limit = esc_js( __( 'Importing these servers would exceed the maximum number of MCP Apps.', 'nvdigital-open-operator-system-oos' ) );
		$lbl_loopback     = esc_js( __( 'This server is on this WordPress site. Same-site REST endpoints are routed in-process to avoid TLS loopback deadlocks.', 'nvdigital-open-operator-system-oos' ) );
		$lbl_managed      = esc_js( __( 'Managed in Remote Sites — run Test Connection or Discover Tools from the Remote Sites page.', 'nvdigital-open-operator-system-oos' ) );
		$lbl_upwork_ref   = esc_js( __( 'This app connects to the official Upwork MCP gateway through a centrally managed Remote Sites connection. Complete the OAuth login below to finish setup.', 'nvdigital-open-operator-system-oos' ) );
		$lbl_flowhub_ref  = esc_js( __( 'This app connects to the official FlowHub MCP gateway through a centrally managed Remote Sites connection. Complete the OAuth login below to finish setup.', 'nvdigital-open-operator-system-oos' ) );

		ob_start();
		?>
				( function() {
					var appIndex = <?php echo (int) $app_index; ?>;
					var maxApps = 10;
					var restUrl = <?php echo wp_json_encode( esc_url_raw( rest_url( 'mcp-ai/v1/mcp-apps' ) ) ); ?>;
					var restNonce = <?php echo wp_json_encode( wp_create_nonce( 'wp_rest' ) ); ?>;
					var siteHost = <?php echo wp_json_encode( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ); ?>;
					var lblConnected = <?php echo wp_json_encode( $lbl_connected ); ?>;
					var lblError = <?php echo wp_json_encode( $lbl_error ); ?>;
					var lblNotTested = <?php echo wp_json_encode( $lbl_not_tested ); ?>;
					var lblTool = <?php echo wp_json_encode( $lbl_tool ); ?>;
					var lblTools = <?php echo wp_json_encode( $lbl_tools ); ?>;
					var lblUrlRequired = <?php echo wp_json_encode( $lbl_url_required ); ?>;
					var lblInvalidJson = <?php echo wp_json_encode( $lbl_invalid_json ); ?>;
					var lblNoServers = <?php echo wp_json_encode( $lbl_no_servers ); ?>;
					var lblImportLimit = <?php echo wp_json_encode( $lbl_import_limit ); ?>;
					var lblLoopback = <?php echo wp_json_encode( $lbl_loopback ); ?>;
					var lblManaged = <?php echo wp_json_encode( $lbl_managed ); ?>;
					var lblUpworkRef = <?php echo wp_json_encode( $lbl_upwork_ref ); ?>;
					var lblFlowhubRef = <?php echo wp_json_encode( $lbl_flowhub_ref ); ?>;
					var maxAppsMessage = <?php echo wp_json_encode( $max_apps_message ); ?>;
					var mcpAppLabel = <?php echo wp_json_encode( $mcp_app_label ); ?>;

					function getAssistantId() {
						var urlParams = new URLSearchParams( window.location.search );
						return parseInt( urlParams.get( 'post' ) || '0', 10 ) || 0;
					}

					function readRowConfig( row ) {
						var urlInput = row.querySelector( 'input[type="url"]' );
						var authSelect = row.querySelector( '.wp-mcp-ai-mcp-app-auth-type' );
						var tokenInput = row.querySelector( 'input.wp-mcp-ai-mcp-app-token-input' );
						var headerInput = row.querySelector( 'input[name$="[header_name]"]' );
						var timeoutInput = row.querySelector( 'input[type="number"]' );
						var verifyInput = row.querySelector( 'input[name$="[verify_ssl]"][value="1"]' );

						return {
							server_url: ( urlInput ? urlInput.value.trim() : '' ),
							auth_type: ( authSelect ? authSelect.value : 'none' ),
							token: ( tokenInput ? tokenInput.value.trim() : '' ),
							header_name: ( headerInput ? headerInput.value.trim() : '' ),
							timeout: parseInt( ( timeoutInput ? timeoutInput.value : '30' ), 10 ) || 30,
							verify_ssl: ( verifyInput ? verifyInput.checked : true ),
							assistant_id: getAssistantId()
						};
					}

					function setRowBusy( row, busy ) {
						var spinner = row.querySelector( '.wp-mcp-ai-mcp-app-spinner' );
						if ( spinner ) {
							spinner.style.display = busy ? 'inline-block' : 'none';
						}
						row.querySelectorAll( '.wp-mcp-ai-mcp-app-actions button' ).forEach( function( btn ) {
							btn.disabled = busy;
						} );
					}

					function ajaxPost( path, body, onOk, onFail ) {
						var xhr = new XMLHttpRequest();
						xhr.open( 'POST', restUrl + path );
						xhr.setRequestHeader( 'Content-Type', 'application/json' );
						xhr.setRequestHeader( 'X-WP-Nonce', restNonce );
						xhr.onload = function() {
							var data = null;
							try {
								data = JSON.parse( xhr.responseText );
							} catch ( e ) {
								data = null;
							}
							if ( xhr.status >= 200 && xhr.status < 300 && data ) {
								onOk( data );
								return;
							}
							var msg = 'Request failed (HTTP ' + xhr.status + ').';
							if ( data && data.message ) {
								msg = data.message;
							} else if ( data && data.code ) {
								msg = data.code + ': ' + ( data.message || '' );
							}
							onFail( msg );
						};
						xhr.onerror = function() {
							onFail( 'Network error. Please check the server URL and try again.' );
						};
						xhr.send( JSON.stringify( body ) );
					}

					function renderResult( row, ok, lines ) {
						var resultEl = row.querySelector( '.wp-mcp-ai-mcp-app-result' );
						if ( ! resultEl ) {
							return;
						}

						resultEl.innerHTML = '';
						resultEl.style.display = '';
						resultEl.className = 'wp-mcp-ai-mcp-app-result notice inline ' + ( ok ? 'notice-success' : 'notice-error' );
						resultEl.style.margin = '10px 0 0';
						resultEl.style.padding = '10px';

						var summary = document.createElement( 'div' );
						summary.style.fontWeight = 'bold';
						summary.style.marginBottom = '6px';
						summary.textContent = ( ok ? '✓ ' : '✕ ' ) + ( lines[0] || '' );
						resultEl.appendChild( summary );

						for ( var i = 1; i < lines.length; i++ ) {
							var line = document.createElement( 'div' );
							line.textContent = lines[i];
							resultEl.appendChild( line );
						}
					}

					function updateBadge( row, state, toolCount, errorMessage ) {
						var badge = row.querySelector( '.wp-mcp-ai-mcp-app-status-badge' );
						if ( badge ) {
							badge.classList.remove( 'wp-mcp-ai-mcp-app-status-ok', 'wp-mcp-ai-mcp-app-status-error', 'wp-mcp-ai-mcp-app-status-unknown' );
							badge.classList.add( 'wp-mcp-ai-mcp-app-status-' + state );
							badge.title = errorMessage || '';
							var textEl = badge.querySelector( '.wp-mcp-ai-mcp-app-status-text' );
							if ( textEl ) {
								textEl.textContent = state === 'ok' ? lblConnected : ( state === 'error' ? lblError : lblNotTested );
							}
						}

						var chip = row.querySelector( '.wp-mcp-ai-mcp-app-tool-count' );
						if ( toolCount !== null && toolCount !== undefined && toolCount >= 0 ) {
							if ( ! chip && badge ) {
								chip = document.createElement( 'span' );
								chip.className = 'wp-mcp-ai-mcp-app-tool-count';
								badge.parentNode.insertBefore( chip, badge.nextSibling );
							}
							if ( chip ) {
								chip.textContent = toolCount + ' ' + ( toolCount === 1 ? lblTool : lblTools );
							}
						} else if ( chip ) {
							chip.remove();
						}
					}

					function isRefRow( row ) {
						var refInput = row.querySelector( 'input[name$="[connection_ref]"]' );
						return !!( refInput && refInput.value );
					}

					function runTest( row ) {
						if ( isRefRow( row ) ) {
							renderResult( row, false, [ lblManaged ] );
							return;
						}
						var cfg = readRowConfig( row );
						if ( ! cfg.server_url ) {
							renderResult( row, false, [ lblUrlRequired ] );
							return;
						}

						setRowBusy( row, true );
						ajaxPost( '/test', cfg, function( data ) {
							setRowBusy( row, false );
							var lines = [];
							if ( data.success ) {
								var server = ( data.server_info && data.server_info.name ) ? data.server_info.name : '';
								var version = ( data.server_info && data.server_info.version ) ? ' ' + data.server_info.version : '';
								lines.push( lblConnected + ( server ? ' — ' + server + version : '' ) );
								lines.push( 'Protocol: ' + ( data.protocol || 'unknown' ) + ' · Handshake: ' + ( data.handshake || 'unknown' ) + ( data.session_active ? ' · session: active' : '' ) );
								lines.push( 'Latency: ' + ( data.latency_ms || 0 ) + ' ms' );
								if ( data.tool_count !== null && data.tool_count !== undefined ) {
									lines.push( 'Tools enumerated: ' + data.tool_count );
								}
								if ( data.tool_error ) {
									lines.push( 'Tool enumeration failed: ' + data.tool_error );
								}
								if ( data.same_origin ) {
									lines.push( '⚠ ' + lblLoopback );
								}
								updateBadge( row, 'ok', data.tool_count, '' );
							} else {
								lines.push( data.message || lblError );
								updateBadge( row, 'error', null, data.message || '' );
							}
							renderResult( row, data.success, lines );
						}, function( message ) {
							setRowBusy( row, false );
							renderResult( row, false, [ message ] );
							updateBadge( row, 'error', null, message );
						} );
					}

					function runDiscover( row ) {
						if ( isRefRow( row ) ) {
							renderResult( row, false, [ lblManaged ] );
							return;
						}
						var cfg = readRowConfig( row );
						if ( ! cfg.server_url ) {
							renderResult( row, false, [ lblUrlRequired ] );
							return;
						}
						cfg.refresh = true;

						setRowBusy( row, true );
						ajaxPost( '/discover', cfg, function( data ) {
							setRowBusy( row, false );
							var lines = [];
							if ( data.success ) {
								lines.push( 'Discovered ' + data.tool_count + ' ' + ( data.tool_count === 1 ? lblTool : lblTools ) + '.' );
								var tools = data.tools || [];
								tools.slice( 0, 25 ).forEach( function( tool ) {
									lines.push( '– ' + tool.name + ( tool.has_ui ? ' · UI' : '' ) );
								} );
								if ( tools.length > 25 ) {
									lines.push( '… and ' + ( tools.length - 25 ) + ' more' );
								}
								updateBadge( row, 'ok', data.tool_count, '' );
							} else {
								lines.push( data.message || lblError );
								updateBadge( row, 'error', null, data.message || '' );
							}
							renderResult( row, data.success, lines );
						}, function( message ) {
							setRowBusy( row, false );
							renderResult( row, false, [ message ] );
							updateBadge( row, 'error', null, message );
						} );
					}

					function appendNewRow() {
						var tmpl = document.getElementById( 'tmpl-wp-mcp-ai-mcp-app-row' );
						if ( ! tmpl ) {
							return null;
						}

						var html = tmpl.innerHTML.replace( /\{\{data\.index\}\}/g, appIndex );
						appIndex++;

						var wrapper = document.createElement( 'div' );
						wrapper.innerHTML = html;
						return wrapper.firstElementChild;
					}

					function mapAuth( server ) {
						var headers = server.headers || {};
						var authz = typeof headers.Authorization === 'string' ? headers.Authorization : ( typeof headers.authorization === 'string' ? headers.authorization : '' );

						if ( authz.indexOf( 'Basic ' ) === 0 ) {
							return { auth_type: 'basic', token: authz.substring( 6 ).trim(), header_name: '' };
						}
						if ( authz.indexOf( 'Bearer ' ) === 0 ) {
							return { auth_type: 'bearer', token: authz.substring( 7 ).trim(), header_name: '' };
						}
						if ( authz !== '' ) {
							return { auth_type: 'header', token: authz, header_name: 'Authorization' };
						}

						var keys = Object.keys( headers );
						if ( keys.length ) {
							return { auth_type: 'header', token: headers[ keys[0] ], header_name: keys[0] };
						}

						return { auth_type: 'none', token: '', header_name: '' };
					}

					function fillRowFromImport( row, name, server ) {
						var auth = mapAuth( server );

						var labelInput = row.querySelector( '.wp-mcp-ai-mcp-app-label' );
						var urlInput = row.querySelector( 'input[type="url"]' );
						var authSelect = row.querySelector( '.wp-mcp-ai-mcp-app-auth-type' );
						var tokenInput = row.querySelector( 'input.wp-mcp-ai-mcp-app-token-input' );
						var headerInput = row.querySelector( 'input[name$="[header_name]"]' );

						if ( labelInput ) {
							labelInput.value = name || '';
						}
						if ( urlInput ) {
							urlInput.value = server.url || '';
						}
						if ( authSelect ) {
							authSelect.value = auth.auth_type;
							authSelect.dispatchEvent( new Event( 'change' ) );
						}
						if ( tokenInput ) {
							tokenInput.value = auth.token || '';
						}
						if ( headerInput ) {
							headerInput.value = auth.header_name || '';
						}

						var titleEl = row.querySelector( '.wp-mcp-ai-mcp-app-title' );
						if ( titleEl ) {
							titleEl.textContent = name || <?php echo wp_json_encode( $mcp_app_label ); ?>;
						}
					}

					document.addEventListener( 'DOMContentLoaded', function() {
						var addBtn = document.getElementById( 'wp-mcp-ai-add-mcp-app' );
						var testAllBtn = document.getElementById( 'wp-mcp-ai-test-all-mcp-apps' );
						var importBtn = document.getElementById( 'wp-mcp-ai-import-mcp-apps' );
						var importPanel = document.getElementById( 'wp-mcp-ai-import-mcp-apps-panel' );
						var importApplyBtn = document.getElementById( 'wp-mcp-ai-import-mcp-apps-apply' );
						var importCancelBtn = document.getElementById( 'wp-mcp-ai-import-mcp-apps-cancel' );
						var importJsonEl = document.getElementById( 'wp-mcp-ai-import-mcp-apps-json' );
						var listEl = document.getElementById( 'wp-mcp-ai-mcp-apps-list' );
						var emptyEl = document.getElementById( 'wp-mcp-ai-mcp-apps-empty' );
						var remoteSelect = document.getElementById( 'wp-mcp-ai-add-from-remote' );
						var remoteBtn = document.getElementById( 'wp-mcp-ai-add-from-remote-btn' );

						if ( ! addBtn || ! listEl ) {
							return;
						}

						if ( remoteSelect && remoteBtn ) {
							remoteBtn.addEventListener( 'click', function() {
								var rows = listEl.querySelectorAll( '.wp-mcp-ai-mcp-app-row' );
								if ( rows.length >= maxApps ) {
									window.alert( maxAppsMessage );
									return;
								}

								var opt = remoteSelect.options[ remoteSelect.selectedIndex ];
								var ref = opt ? opt.value : '';
								var name = opt ? ( opt.getAttribute( 'data-name' ) || '' ) : '';
								var type = opt ? ( opt.getAttribute( 'data-type' ) || '' ) : '';
								var serverUrl = opt ? ( opt.getAttribute( 'data-server-url' ) || '' ) : '';
								if ( ! ref ) {
									return;
								}

								var tmpl = document.getElementById( 'tmpl-wp-mcp-ai-mcp-app-ref-row' );
								if ( ! tmpl ) {
									return;
								}

								var html = tmpl.innerHTML.replace( /\{\{data\.index\}\}/g, appIndex );
								appIndex++;

								var wrapper = document.createElement( 'div' );
								wrapper.innerHTML = html;
								var row = wrapper.firstElementChild;
								if ( ! row ) {
									return;
								}

								var refInput = row.querySelector( 'input[name$="[connection_ref]"]' );
								var labelInput = row.querySelector( 'input[name$="[label]"]' );
								if ( refInput ) {
									refInput.value = ref;
								}
								if ( labelInput ) {
									labelInput.value = name;
								}

								var titleEl = row.querySelector( '.wp-mcp-ai-mcp-app-title' );
								if ( titleEl ) {
									titleEl.textContent = name || mcpAppLabel;
								}

								// Upwork/FlowHub MCP connections authenticate through the OAuth login
								// flow — surface the login UI on the new reference row.
								if ( type === 'upwork' || type === 'flowhub' ) {
									var oauthRow = row.querySelector( '.wp-mcp-ai-ref-oauth-row' );
									if ( oauthRow ) {
										oauthRow.style.display = '';
									}
									row.querySelectorAll( '.wp-mcp-ai-connect-oauth, .wp-mcp-ai-reconnect-oauth' ).forEach( function( b ) {
										if ( serverUrl ) {
											b.setAttribute( 'data-server-url', serverUrl );
										}
									} );
									var descEl = row.querySelector( '.wp-mcp-ai-ref-description' );
									if ( descEl ) {
										descEl.textContent = type === 'upwork' ? lblUpworkRef : lblFlowhubRef;
									}
								}

								if ( emptyEl ) {
									emptyEl.style.display = 'none';
								}

								listEl.appendChild( row );
							} );
						}

						addBtn.addEventListener( 'click', function() {
							var rows = listEl.querySelectorAll( '.wp-mcp-ai-mcp-app-row' );
							if ( rows.length >= maxApps ) {
								window.alert( <?php echo wp_json_encode( $max_apps_message ); ?> );
								return;
							}

							var row = appendNewRow();
							if ( ! row ) {
								return;
							}

							if ( emptyEl ) {
								emptyEl.style.display = 'none';
							}

							listEl.appendChild( row );
						} );

						if ( testAllBtn ) {
							testAllBtn.addEventListener( 'click', function() {
								listEl.querySelectorAll( '.wp-mcp-ai-mcp-app-row' ).forEach( function( row ) {
									runTest( row );
								} );
							} );
						}

						if ( importBtn && importPanel ) {
							importBtn.addEventListener( 'click', function() {
								importPanel.style.display = importPanel.style.display === 'none' ? '' : 'none';
							} );
						}

						if ( importCancelBtn && importPanel ) {
							importCancelBtn.addEventListener( 'click', function() {
								importPanel.style.display = 'none';
								if ( importJsonEl ) {
									importJsonEl.value = '';
								}
							} );
						}

						if ( importApplyBtn && importJsonEl ) {
							importApplyBtn.addEventListener( 'click', function() {
								var text = importJsonEl.value.trim();
								if ( ! text ) {
									return;
								}

								var parsed = null;
								try {
									parsed = JSON.parse( text );
								} catch ( e ) {
									parsed = null;
								}

								if ( ! parsed ) {
									window.alert( <?php echo wp_json_encode( $lbl_invalid_json ); ?> );
									return;
								}

								var servers = parsed.mcpServers;
								if ( ! servers && parsed.url ) {
									servers = { imported: parsed };
								}
								if ( ! servers ) {
									window.alert( <?php echo wp_json_encode( $lbl_no_servers ); ?> );
									return;
								}

								var names = Object.keys( servers );
								var currentRows = listEl.querySelectorAll( '.wp-mcp-ai-mcp-app-row' );
								if ( currentRows.length + names.length > maxApps ) {
									window.alert( <?php echo wp_json_encode( $lbl_import_limit ); ?> );
									return;
								}

								names.forEach( function( name ) {
									var row = appendNewRow();
									if ( row ) {
										// Attach before filling so delegated change
										// handlers (auth type row visibility) fire.
										listEl.appendChild( row );
										fillRowFromImport( row, name, servers[ name ] );
									}
								} );

								if ( emptyEl ) {
									emptyEl.style.display = 'none';
								}

								importPanel.style.display = 'none';
								importJsonEl.value = '';
							} );
						}

						listEl.addEventListener( 'click', function( event ) {
								if ( event.target.closest( '.wp-mcp-ai-remove-mcp-app' ) ) {
									if ( window.confirm( <?php echo wp_json_encode( $confirm_message ); ?> ) ) {
										var row = event.target.closest( '.wp-mcp-ai-mcp-app-row' );
										if ( row ) {
											row.remove();
										}

										var remaining = listEl.querySelectorAll( '.wp-mcp-ai-mcp-app-row' );
										if ( remaining.length === 0 && emptyEl ) {
											emptyEl.style.display = '';
										}
									}
									return;
								}

								if ( event.target.closest( '.wp-mcp-ai-test-mcp-app' ) ) {
									event.preventDefault();
									var row = event.target.closest( '.wp-mcp-ai-mcp-app-row' );
									if ( row ) {
										runTest( row );
									}
									return;
								}

								if ( event.target.closest( '.wp-mcp-ai-discover-mcp-app' ) ) {
									event.preventDefault();
									var discoverRow = event.target.closest( '.wp-mcp-ai-mcp-app-row' );
									if ( discoverRow ) {
										runDiscover( discoverRow );
									}
									return;
								}

								if ( event.target.closest( '.wp-mcp-ai-oauth-open-link' ) ) {
									var openLink = event.target.closest( '.wp-mcp-ai-oauth-open-link' );
									if ( ! openLink.getAttribute( 'href' ) || openLink.getAttribute( 'href' ) === '#' ) {
										event.preventDefault();
										window.alert( 'Click "Connect via Web Login" first to start the login.' );
									}
									return;
								}

								if ( event.target.closest( '.wp-mcp-ai-complete-oauth' ) ) {
									event.preventDefault();
									var completeBtn = event.target.closest( '.wp-mcp-ai-complete-oauth' );
									var completeRow = completeBtn.closest( '.wp-mcp-ai-mcp-app-row' );
									var urlField = completeRow ? completeRow.querySelector( '.wp-mcp-ai-oauth-callback-url' ) : null;
									var callbackUrl = urlField ? urlField.value.trim() : '';
									if ( ! callbackUrl ) {
										window.alert( 'Paste the full localhost URL from the address bar of the login tab first.' );
										return;
									}

									// Extract the state from the pasted URL so it always
									// agrees with the value embedded in the callback.
									var stateMatch = ( callbackUrl.split( '?' )[ 1 ] || '' ).match( /(^|&)state=([^&]*)/ );
									if ( ! stateMatch ) {
										window.alert( 'The pasted URL is missing the state parameter. Copy the full address bar URL.' );
										return;
									}
									var stateParam = decodeURIComponent( stateMatch[ 2 ] );

									var spinner = completeRow ? completeRow.querySelector( '.wp-mcp-ai-oauth-complete-spinner' ) : null;
									completeBtn.disabled = true;
									if ( spinner ) {
										spinner.style.display = 'inline-block';
									}

									var cxhr = new XMLHttpRequest();
									cxhr.open( 'POST', '<?php echo esc_url_raw( rest_url( 'mcp-ai/v1/mcp-apps/oauth/complete' ) ); ?>' );
									cxhr.setRequestHeader( 'Content-Type', 'application/json' );
									cxhr.setRequestHeader( 'X-WP-Nonce', <?php echo wp_json_encode( wp_create_nonce( 'wp_rest' ) ); ?> );
									cxhr.onload = function() {
										var cdata = {};
										try {
											cdata = JSON.parse( cxhr.responseText );
										} catch ( e ) {
											cdata = {};
										}
										if ( cxhr.status === 200 && cdata.success ) {
											window.alert( cdata.message || 'MCP App connected successfully.' );
											window.location.reload();
										} else {
											window.alert( cdata.message || 'Failed to complete the OAuth login. Please try again.' );
											completeBtn.disabled = false;
											if ( spinner ) {
												spinner.style.display = 'none';
											}
										}
									};
									cxhr.onerror = function() {
										window.alert( 'Network error. Please try again.' );
										completeBtn.disabled = false;
										if ( spinner ) {
											spinner.style.display = 'none';
										}
									};
									cxhr.send( JSON.stringify( { state: stateParam, callback_url: callbackUrl } ) );
									return;
								}

								if ( event.target.closest( '.wp-mcp-ai-connect-oauth' ) || event.target.closest( '.wp-mcp-ai-reconnect-oauth' ) ) {
									event.preventDefault();
									var btn = event.target.closest( '.wp-mcp-ai-connect-oauth' ) || event.target.closest( '.wp-mcp-ai-reconnect-oauth' );
									var serverUrl = btn.getAttribute( 'data-server-url' ) || '';
									var row = btn.closest( '.wp-mcp-ai-mcp-app-row' );

									// Centrally managed reference rows carry the Remote Sites
									// connection ID; the OAuth completion then persists the
									// tokens to the encrypted central store.
									var refInput = row ? row.querySelector( 'input[name$="[connection_ref]"]' ) : null;
									var connectionRef = ( refInput && refInput.value ) ? refInput.value : '';

									// Read the server URL from the row's input field if data attribute is empty (new rows).
									if ( ! serverUrl && row ) {
										var urlInput = row.querySelector( 'input[type="url"]' );
										if ( urlInput ) {
											serverUrl = urlInput.value.trim();
										}
									}

									if ( ! serverUrl ) {
										window.alert( <?php echo wp_json_encode( $lbl_url_required ); ?> );
										return;
									}

									// Disable button while requesting.
									btn.disabled = true;
									btn.textContent = 'Connecting…';

									var xhr = new XMLHttpRequest();
									xhr.open( 'POST', '<?php echo esc_url_raw( rest_url( 'mcp-ai/v1/mcp-apps/oauth/init' ) ); ?>' );
									xhr.setRequestHeader( 'Content-Type', 'application/json' );
									xhr.setRequestHeader( 'X-WP-Nonce', <?php echo wp_json_encode( wp_create_nonce( 'wp_rest' ) ); ?> );
									xhr.onload = function() {
										if ( xhr.status === 200 ) {
											var data = JSON.parse( xhr.responseText );
											if ( data.authorization_url ) {
												if ( data.redirect_mode === 'manual_loopback' ) {
													// Providers like Upwork only accept localhost redirect
												// URIs: open the login in a new tab and let the admin
												// paste the resulting callback URL back here.
													window.open( data.authorization_url, '_blank' );
													if ( row ) {
														var manualBox = row.querySelector( '.wp-mcp-ai-oauth-manual' );
														if ( manualBox ) {
															manualBox.style.display = '';
														}
														var openLink = row.querySelector( '.wp-mcp-ai-oauth-open-link' );
														if ( openLink ) {
															openLink.href = data.authorization_url;
														}
													}
												} else {
													window.location.href = data.authorization_url;
												}
											} else {
												window.alert( 'Failed to start OAuth flow.' );
											}
											btn.disabled = false;
											btn.textContent = btn.classList.contains( 'wp-mcp-ai-reconnect-oauth' ) ? 'Re-authenticate' : 'Connect via Web Login';
										} else {
											// Surface the REST error message (e.g. the OAuth
											// discovery failure) plus the per-attempt
											// diagnostics and hint, so the admin can tell
											// "server has no OAuth" from "site could not
											// reach it" and knows the API-key alternative.
											var message = 'OAuth initiation failed. Check the server URL and try again.';
											try {
												var errData = JSON.parse( xhr.responseText );
												if ( errData && errData.message ) {
													message = errData.message;
												}
												if ( errData && errData.data ) {
													if ( errData.data.hint ) {
														message += '\n\n' + errData.data.hint;
													}
													var attempts = errData.data.attempts || [];
													if ( attempts.length ) {
														message += '\n\nDiscovery attempts:';
														attempts.slice( 0, 4 ).forEach( function( attempt ) {
															var outcome = attempt.status ? 'HTTP ' + attempt.status : ( attempt.error || attempt.result || 'failed' );
															message += '\n• ' + attempt.url + ' — ' + outcome;
														} );
														if ( attempts.length > 4 ) {
															message += '\n… and ' + ( attempts.length - 4 ) + ' more';
														}
													}
												}
											} catch ( e ) {
												// Non-JSON error body — keep the generic message.
											}
											window.alert( message );
											btn.disabled = false;
											btn.textContent = btn.classList.contains( 'wp-mcp-ai-reconnect-oauth' ) ? 'Re-authenticate' : 'Connect via Web Login';
										}
									};
									xhr.onerror = function() {
										window.alert( 'Network error. Please check the server URL and try again.' );
										btn.disabled = false;
										btn.textContent = btn.classList.contains( 'wp-mcp-ai-reconnect-oauth' ) ? 'Re-authenticate' : 'Connect via Web Login';
									};
									var payload = { server_url: serverUrl, assistant_id: getAssistantId() };
									if ( connectionRef ) {
										payload.connection_ref = connectionRef;
									}
									xhr.send( JSON.stringify( payload ) );
								}
							} );

						listEl.addEventListener( 'change', function( event ) {
							if ( event.target.classList.contains( 'wp-mcp-ai-mcp-app-auth-type' ) ) {
								var row = event.target.closest( '.wp-mcp-ai-mcp-app-row' );
								if ( ! row ) {
									return;
								}

								var tokenRow = row.querySelector( '.wp-mcp-ai-mcp-app-token-row' );
								var headerRow = row.querySelector( '.wp-mcp-ai-mcp-app-header-row' );
								var oauthRow = row.querySelector( '.wp-mcp-ai-mcp-app-oauth-row' );
								var value = event.target.value;

								if ( tokenRow ) {
									tokenRow.style.display = ( value === 'none' || value === 'oauth' ) ? 'none' : '';
								}
								if ( headerRow ) {
									headerRow.style.display = ( value === 'header' ) ? '' : 'none';
								}
								if ( oauthRow ) {
									oauthRow.style.display = ( value === 'oauth' ) ? '' : 'none';
								}
							}
						} );

						listEl.addEventListener( 'input', function( event ) {
							if ( event.target.classList.contains( 'wp-mcp-ai-mcp-app-label' ) ) {
								var row = event.target.closest( '.wp-mcp-ai-mcp-app-row' );
								if ( ! row ) {
									return;
								}

								var titleEl = row.querySelector( '.wp-mcp-ai-mcp-app-title' );
								if ( titleEl ) {
									titleEl.textContent = event.target.value || <?php echo wp_json_encode( $mcp_app_label ); ?>;
								}
							}
						} );
				} );
			} )();
			<?php
			$js = ob_get_clean();
			wp_print_inline_script_tag( $js );
	}

	/**
	 * Get current apps count for JS initialization.
	 *
	 * @since 1.8.0
	 * @return array
	 */
	protected function get_current_apps_count() {
		global $post;

		if ( ! $post || ! class_exists( 'WP_MCP_AI_MCP_App_Registry' ) ) {
			return array();
		}

		$registry = WP_MCP_AI_MCP_App_Registry::get_instance();
		return $registry->get_apps( $post->ID );
	}
}
