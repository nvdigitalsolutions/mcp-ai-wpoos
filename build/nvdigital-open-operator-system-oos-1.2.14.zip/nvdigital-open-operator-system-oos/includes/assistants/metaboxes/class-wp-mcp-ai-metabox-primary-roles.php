<?php
/**
 * Primary Roles Metabox for Assistants.
 *
 * @package WP_MCP_AI
 * @since 1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles the Primary Roles metabox for assistant posts.
 *
 * Allows selecting up to 3 professions as primary roles for programmatic prompt construction.
 *
 * @since 1.0.0
 */
class WP_MCP_AI_Metabox_Primary_Roles extends WP_MCP_AI_Metabox_Base {

	/**
	 * Reference to the Assistant CPT class for constants.
	 *
	 * @var WP_MCP_AI_Assistant_CPT
	 */
	protected $cpt;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @param WP_MCP_AI_Assistant_CPT $cpt Assistant CPT instance.
	 */
	public function __construct( $cpt ) {
		$this->cpt = $cpt;
	}

	/**
	 * Get the metabox ID.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function get_id() {
		return 'wp_mcp_ai_primary_roles';
	}

	/**
	 * Get the metabox title.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function get_title() {
		return __( 'Primary Roles', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get documentation URL for this metabox.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function get_documentation_url() {
		return 'https://github.com/nvdigitalsolutions/mcp-ai-wpoos/blob/main/docs/user-guides/professionals/PROFESSION_KNOWLEDGE_BASE_SYSTEM.md';
	}

	/**
	 * Check if current user can view this metabox.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	protected function can_view() {
		global $post;
		return current_user_can( 'edit_post', $post->ID );
	}

	/**
	 * Render the metabox content.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post The post object.
	 * @return void
	 */
	public function render( $post ) {
		if ( ! $this->can_view() ) {
			wp_die( esc_html__( 'You do not have permission to edit this assistant.', 'nvdigital-open-operator-system-oos' ), '', array( 'response' => 403 ) );
		}

		wp_nonce_field( 'wp_mcp_ai_primary_roles_meta', 'wp_mcp_ai_primary_roles_meta_nonce' );

		// Get currently assigned primary roles.
		$primary_roles = get_post_meta( $post->ID, WP_MCP_AI_Assistant_CPT::META_PRIMARY_ROLES, true );
		if ( ! is_array( $primary_roles ) ) {
			$primary_roles = array();
		}

		// Get all available professions.
		$professions = get_posts(
			array(
				'post_type'      => 'mcp_ai_profession',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'post_status'    => 'publish',
			)
		);

		?>
		<div class="wp-mcp-ai-primary-roles">
			<p class="description">
				<?php esc_html_e( 'Select up to 3 professions to define the primary roles for this assistant. Role instructions will be programmatically combined to create the system prompt.', 'nvdigital-open-operator-system-oos' ); ?>
			</p>

			<?php if ( empty( $professions ) ) : ?>
				<p class="description">
					<?php
					printf(
						/* translators: %s: URL to create profession */
						esc_html__( 'No professions found. Please %s first.', 'nvdigital-open-operator-system-oos' ),
						'<a href="' . esc_url( admin_url( 'post-new.php?post_type=mcp_ai_profession' ) ) . '">' . esc_html__( 'create a profession', 'nvdigital-open-operator-system-oos' ) . '</a>'
					);
					?>
				</p>
			<?php else : ?>
				<?php
				// Render search field using helper.
				WP_MCP_AI_Profession_Search_Helper::render_search_field();
				?>
				<table class="widefat striped" id="wp-mcp-ai-professions-table">
					<thead>
						<tr>
							<th style="width: 40px;"></th>
							<th><?php esc_html_e( 'Profession', 'nvdigital-open-operator-system-oos' ); ?></th>
							<th><?php esc_html_e( 'Category', 'nvdigital-open-operator-system-oos' ); ?></th>
							<th><?php esc_html_e( 'Description', 'nvdigital-open-operator-system-oos' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $professions as $profession ) : ?>
							<?php
							$category    = get_post_meta( $profession->ID, '_wp_mcp_ai_profession_category', true );
							$is_selected = in_array( $profession->ID, $primary_roles, true );
							?>
							<tr class="wp-mcp-ai-profession-row" <?php echo WP_MCP_AI_Profession_Search_Helper::get_profession_data_attributes( $profession ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_profession_data_attributes() returns pre-escaped HTML attribute string using esc_attr() on all dynamic values. ?>>
								<td>
									<input
										type="checkbox"
										name="wp_mcp_ai_primary_roles[]"
										value="<?php echo esc_attr( $profession->ID ); ?>"
										class="wp-mcp-ai-primary-role-checkbox"
										<?php checked( $is_selected ); ?>
									/>
								</td>
								<td><strong><?php echo esc_html( $profession->post_title ); ?></strong></td>
								<td>
									<?php if ( $category ) : ?>
										<span class="wp-mcp-ai-category-badge"><?php echo esc_html( ucfirst( str_replace( '_', ' ', $category ) ) ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<?php
									if ( $profession->post_excerpt ) {
										echo esc_html( $profession->post_excerpt );
									} elseif ( $profession->post_content ) {
										echo esc_html( wp_trim_words( wp_strip_all_tags( $profession->post_content ), 15 ) );
									}
									?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<p class="description" style="margin-top: 10px;">
					<?php esc_html_e( 'Maximum 3 roles can be selected. Additional selections will uncheck the first selected role.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>

				<?php
				// Render search styles and script using helper.
				WP_MCP_AI_Profession_Search_Helper::render_search_styles();
				WP_MCP_AI_Profession_Search_Helper::render_search_script();
				?>

				<?php
				wp_register_style( 'wp-mcp-ai-metabox-primary-roles', false, array(), WP_MCP_AI_VERSION );
				wp_enqueue_style( 'wp-mcp-ai-metabox-primary-roles' );
				wp_add_inline_style(
					'wp-mcp-ai-metabox-primary-roles',
					'.wp-mcp-ai-category-badge{display:inline-block;padding:2px 8px;border-radius:3px;background:#f0f0f1;font-size:12px}'
				);

				ob_start();
				?>
				( function() {
					var maxRoles = 3;

					document.addEventListener( 'DOMContentLoaded', function() {
						var checkboxes = document.querySelectorAll( '.wp-mcp-ai-primary-role-checkbox' );

						// Handle checkbox selection with max limit.
						checkboxes.forEach( function( checkbox ) {
							checkbox.addEventListener( 'change', function() {
								var checked = document.querySelectorAll( '.wp-mcp-ai-primary-role-checkbox:checked' );

								if ( checked.length > maxRoles ) {
									// Uncheck the first checked item.
									checked[0].checked = false;
								}
							} );
						} );
					} );
				} )();
				<?php
				$js = ob_get_clean();
				wp_print_inline_script_tag( $js );
				?>
			<?php endif; ?>
		</div>
		<?php
		$this->render_documentation_link();
	}
}
