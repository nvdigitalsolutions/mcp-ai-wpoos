<?php
/**
 * Defaults Metabox for Assistants.
 *
 * @package WP_MCP_AI
 * @since 1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles the Defaults metabox for assistant posts.
 *
 * Manages default provider, model, temperature, and system prompt settings.
 *
 * @since 1.0.0
 */
class WP_MCP_AI_Metabox_Defaults extends WP_MCP_AI_Metabox_Base {

	/**
	 * Reference to the Assistant CPT class for constants.
	 *
	 * @var WP_MCP_AI_Assistant_CPT
	 */
	protected $cpt;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @param WP_MCP_AI_Assistant_CPT $cpt Assistant CPT instance.
	 */
	public function __construct( $cpt ) {
		$this->cpt = $cpt;
	}

	/**
	 * Get the metabox ID.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function get_id() {
		return 'wp_mcp_ai_defaults';
	}

	/**
	 * Get the metabox title.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function get_title() {
		return __( 'Default Settings', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get documentation URL for this metabox.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function get_documentation_url() {
		return 'https://github.com/nvdigitalsolutions/mcp-ai-wpoos/blob/main/docs/admin-guides/SETTINGS_DASHBOARD_GUIDE.md#general-tab';
	}

	/**
	 * Check if current user can view this metabox.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	protected function can_view() {
		global $post;
		return current_user_can( 'edit_post', $post->ID );
	}

	/**
	 * Render the metabox content.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post The post object.
	 * @return void
	 */
	public function render( $post ) {
		if ( ! $this->can_view() ) {
			wp_die( esc_html__( 'You do not have permission to edit this assistant.', 'nvdigital-open-operator-system-oos' ), '', array( 'response' => 403 ) );
		}

		// Enqueue model selector JavaScript.
		// Script is registered globally in WP_MCP_AI_Admin_Scripts with localization.
		// We just need to enqueue it here for this metabox.
		wp_enqueue_script( 'wp-mcp-ai-model-selector' );

		wp_nonce_field( 'wp_mcp_ai_defaults_meta', 'wp_mcp_ai_defaults_meta_nonce' );

		$provider      = get_post_meta( $post->ID, WP_MCP_AI_Assistant_CPT::META_PROVIDER, true );
		$provider      = WP_MCP_AI_Assistant_CPT::sanitize_provider_meta( $provider );
		$model         = get_post_meta( $post->ID, WP_MCP_AI_Assistant_CPT::META_MODEL, true );
		$temperature   = get_post_meta( $post->ID, WP_MCP_AI_Assistant_CPT::META_TEMPERATURE, true );
		$system_prompt = get_post_meta( $post->ID, WP_MCP_AI_Assistant_CPT::META_SYSTEM_PROMPT, true );
		$adaptive_cap  = get_post_meta( $post->ID, WP_MCP_AI_Assistant_CPT::META_ADAPTIVE_TOOL_CAP, true );
		$adaptive_cap  = WP_MCP_AI_Assistant_CPT::sanitize_adaptive_tool_cap_meta( $adaptive_cap );

		$settings         = WP_MCP_AI_Admin_Settings::get_settings();
		$default_provider = isset( $settings['default_provider'] ) ? sanitize_key( $settings['default_provider'] ) : 'openai';

		if ( '' === $provider ) {
			$provider = $default_provider;
		}

		// Get enabled providers from centralized function.
		$provider_choices = WP_MCP_AI_Admin_Settings::get_available_providers();

		// Apply filter for third-party extensions (maintains backward compatibility).
		$provider_slugs = array_keys( $provider_choices );
		$provider_slugs = apply_filters( 'wp_mcp_ai_allowed_providers', $provider_slugs );

		// Filter the provider choices based on allowed slugs.
		if ( is_array( $provider_slugs ) && ! empty( $provider_slugs ) ) {
			$provider_choices = array_intersect_key( $provider_choices, array_flip( $provider_slugs ) );
		}

		// Fallback to all if filtering results in empty array.
		if ( empty( $provider_choices ) ) {
			$provider_choices = WP_MCP_AI_Admin_Settings::get_available_providers();
		}

		if ( '' === $temperature ) {
			$temperature = '';
		}

		// Load model service if available.
		$models = array();
		if ( ! class_exists( 'WP_MCP_AI_Model_Service' ) ) {
			require_once WP_MCP_AI_PATH . 'includes/services/class-wp-mcp-ai-model-service.php';
		}
		if ( class_exists( 'WP_MCP_AI_Model_Service' ) ) {
			$model_service = new WP_MCP_AI_Model_Service();
			$models        = $model_service->get_models_for_provider( $provider );
		}

		?>
	<p>
		<label for="wp-mcp-ai-provider"><strong><?php esc_html_e( 'Provider', 'nvdigital-open-operator-system-oos' ); ?></strong></label>
		<select id="wp-mcp-ai-provider" name="wp_mcp_ai_provider" class="widefat wp-mcp-ai-provider-select" data-model-target="#wp-mcp-ai-model">
			<?php
			foreach ( $provider_choices as $choice => $label ) {
				$choice = sanitize_key( $choice );
				if ( '' === $choice ) {
					continue;
				}
				?>
				<option value="<?php echo esc_attr( $choice ); ?>" <?php selected( $provider, $choice ); ?>><?php echo esc_html( $label ); ?></option>
				<?php
			}
			?>
		</select>
	</p>
	<p>
		<label for="wp-mcp-ai-model"><strong><?php esc_html_e( 'Model', 'nvdigital-open-operator-system-oos' ); ?></strong></label>
		<select id="wp-mcp-ai-model" name="wp_mcp_ai_model" class="widefat">
			<option value=""><?php esc_html_e( '— Select Model —', 'nvdigital-open-operator-system-oos' ); ?></option>
			<?php if ( ! empty( $models ) ) : ?>
				<?php foreach ( $models as $model_id => $model_name ) : ?>
					<option value="<?php echo esc_attr( $model_id ); ?>" <?php selected( $model, $model_id ); ?>>
						<?php echo esc_html( $model_name ); ?>
					</option>
				<?php endforeach; ?>
			<?php endif; ?>
			<?php if ( $model && ( empty( $models ) || ! isset( $models[ $model ] ) ) ) : ?>
				<option value="<?php echo esc_attr( $model ); ?>" selected="selected">
					<?php echo esc_html( $model ); ?><?php echo ! empty( $models ) ? ' (custom)' : ''; ?>
				</option>
			<?php endif; ?>
		</select>
	</p>
	<p>
		<label for="wp-mcp-ai-temperature"><strong><?php esc_html_e( 'Temperature', 'nvdigital-open-operator-system-oos' ); ?></strong></label>
		<input type="number" step="0.1" min="0" max="2" id="wp-mcp-ai-temperature" name="wp_mcp_ai_temperature" value="<?php echo esc_attr( $temperature ); ?>" class="widefat" />
	</p>
	<p>
		<label for="wp-mcp-ai-system-prompt"><strong><?php esc_html_e( 'System Prompt', 'nvdigital-open-operator-system-oos' ); ?></strong></label>
		<textarea id="wp-mcp-ai-system-prompt" name="wp_mcp_ai_system_prompt" class="widefat" rows="5"><?php echo esc_textarea( $system_prompt ); ?></textarea>
	</p>
	<p>
		<label>
			<input type="checkbox" name="wp_mcp_ai_prompt_caching" value="1"
				<?php checked( (bool) get_post_meta( $post->ID, WP_MCP_AI_Assistant_CPT::META_PROMPT_CACHING, true ) ); ?>>
			<strong><?php esc_html_e( 'Enable Prompt Caching', 'nvdigital-open-operator-system-oos' ); ?></strong>
		</label>
		<br>
		<span class="description">
			<?php esc_html_e( 'Reduces latency and API costs by caching the system prompt and tool definitions on supported providers (Anthropic, OpenAI, DeepSeek, Gemini). Static content is reused across conversation turns.', 'nvdigital-open-operator-system-oos' ); ?>
		</span>
	</p>
	<p>
		<label for="wp-mcp-ai-adaptive-tool-cap"><strong><?php esc_html_e( 'Model-Aware Tool Cap', 'nvdigital-open-operator-system-oos' ); ?></strong></label>
		<select id="wp-mcp-ai-adaptive-tool-cap" name="wp_mcp_ai_adaptive_tool_cap" class="widefat">
			<option value="" <?php selected( $adaptive_cap, '' ); ?>><?php esc_html_e( 'Default (use site setting)', 'nvdigital-open-operator-system-oos' ); ?></option>
			<option value="on" <?php selected( $adaptive_cap, 'on' ); ?>><?php esc_html_e( 'Enabled — cap tools to the model context window', 'nvdigital-open-operator-system-oos' ); ?></option>
			<option value="off" <?php selected( $adaptive_cap, 'off' ); ?>><?php esc_html_e( 'Disabled — always use the configured maximum', 'nvdigital-open-operator-system-oos' ); ?></option>
		</select>
		<br>
		<span class="description">
			<?php
			$recommended_cap = 0;
			if ( class_exists( 'WP_MCP_AI_Tool_Payload_Advisor' ) ) {
				$recommended_cap = WP_MCP_AI_Tool_Payload_Advisor::recommended_cap_for_model( trim( (string) $model ) );
			}

			if ( $recommended_cap > 0 ) {
				printf(
					/* translators: 1: model slug, 2: recommended maximum tool count */
					esc_html__( 'Recommended cap for %1$s: %2$d tools (fewer tools improves tool-selection accuracy on smaller context windows).', 'nvdigital-open-operator-system-oos' ),
					esc_html( trim( (string) $model ) ),
					(int) $recommended_cap
				);
			} else {
				esc_html_e( 'When enabled, tools are capped by the model context window: 40 tools up to 128K, 64 up to 256K, 100 above. The cap only lowers the configured maximum, never raises it.', 'nvdigital-open-operator-system-oos' );
			}
			?>
		</span>
	</p>
		<?php
		$this->render_documentation_link();
	}
}
