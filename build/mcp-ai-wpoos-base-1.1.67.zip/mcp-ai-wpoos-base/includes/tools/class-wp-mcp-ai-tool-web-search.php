<?php
/**
 * Tool that performs a web search using the configured provider.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Settings_Registry' ) ) {
	require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-settings-registry.php';
}

if ( ! class_exists( 'WP_MCP_AI_Cache_Helper' ) ) {
	require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-cache-helper.php';
}

if ( ! interface_exists( 'WP_MCP_AI_Tool_LLM_Sanitizer_Interface' ) ) {
	require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool-llm-sanitizer.php';
}

require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php';

/**
 * Performs lightweight web searches and returns the top results.
 *
 * This implementation follows industry best practices:
 *
 * **Architecture Patterns**:
 * - Single Responsibility: Tool focuses solely on web search, delegating SSE streaming
 *   to the orchestration layer (Separation of Concerns pattern)
 * - Strategy Pattern: Supports multiple search providers (Brave, DuckDuckGo) via
 *   configurable strategy without changing tool interface
 * - Context-Aware Execution: Adapts behavior based on execution context (agentic loop
 *   vs standalone API call) following Context pattern
 *
 * **WordPress Standards**:
 * - Implements core tool interfaces (WP_MCP_AI_Tool_Interface)
 * - Uses WordPress coding standards (WPCS)
 * - Follows WordPress hook patterns (actions, filters with proper documentation)
 * - Respects capability checks and user permissions
 * - Uses WordPress HTTP API (wp_remote_get) instead of cURL
 *
 * **API Integration Best Practices**:
 * - Brave Search API: Uses the Brave Search REST API v1 (https://api.search.brave.com/res/v1/web/search)
 *   Integration follows patterns from: https://github.com/brave/brave-search-mcp-server
 * - DuckDuckGo Instant Answer API: Uses the DuckDuckGo public API (https://api.duckduckgo.com/)
 *   Integration follows patterns from: https://github.com/GivAlz/duckduckgo-api-haystack
 *
 * **Reliability & Performance**:
 * - Synchronous execution with single HTTP request (10-second timeout, returns quickly)
 * - HTTP 202 (Accepted) responses returned immediately to orchestration layer for async handling
 * - Rate limiting to prevent abuse (configurable via filter)
 * - Result caching to reduce redundant API calls (configurable TTL)
 * - Result deduplication to prevent infinite loops
 *
 * **Security Controls**:
 * - User capability checks (requires 'read' capability minimum)
 * - Input sanitization (esc_url_raw, sanitize_text_field)
 * - Output escaping for safe data transmission
 * - Rate limiting per user to prevent abuse
 * - UTF-8 sanitization to prevent JSON encoding failures
 *
 * **Observability**:
 * - Detailed logging when agentic loop logging is enabled
 * - Action hooks for extensibility and monitoring
 * - Filter hooks for behavior customization
 *
 * **Agentic Loop Integration**:
 * In agentic loop contexts, results are returned synchronously to the orchestration layer
 * which handles SSE streaming via tool_result events. The wp_mcp_ai_web_search_completed
 * action only fires for standalone API calls outside of chat flows, preventing duplicate
 * events that could confuse the chat client (avoiding "double response" anti-pattern).
 *
 * @since 1.0.0
 * @package WP_MCP_AI
 */
class WP_MCP_AI_Tool_Web_Search implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_LLM_Sanitizer_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * Build a search API URL with RFC 1738-encoded query parameters.
	 *
	 * add_query_arg() does not URL-encode values (build_query() passes
	 * $urlencode=false), which would leave raw spaces in the search query
	 * sent to DuckDuckGo or Brave.
	 *
	 * @param string $base       Search API endpoint URL.
	 * @param array  $query_args Query parameters.
	 * @return string Encoded URL.
	 */
	protected function build_search_url( $base, array $query_args ) {
		$query_string = http_build_query( $query_args, '', '&', PHP_QUERY_RFC1738 );

		return $base . ( false === strpos( $base, '?' ) ? '?' : '&' ) . $query_string;
	}

	/**
	 * Maximum number of results to include in LLM payload.
	 *
	 * Chat client receives all results, but LLM only gets this many to reduce token usage.
	 *
	 * @since 1.0.0
	 * @var int
	 */
	const MAX_LLM_RESULTS = 3;

	/**
	 * Context flag indicating execution within an agentic loop.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	const CONTEXT_AGENTIC_LOOP = 'agentic_loop';

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'web_search';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Web Search', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Searches the public web via the configured provider and returns the top results.', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'query'                  => array(
					'type'        => 'string',
					'description' => __( 'The search query to look up.', 'mcp-ai-wpoos' ),
				),
				'max_results'            => array(
					'type'        => 'integer',
					'description' => __( 'Maximum number of results to return (1-10).', 'mcp-ai-wpoos' ),
					'minimum'     => 1,
					'maximum'     => 10,
					'default'     => 5,
				),
				'country'                => array(
					'type'        => 'string',
					'description' => __( 'ISO 3166-1 alpha-2 country code to geo-target results (e.g. "US", "GB", "DE"). Supported by Brave and Tavily.', 'mcp-ai-wpoos' ),
				),
				'language'               => array(
					'type'        => 'string',
					'description' => __( 'ISO 639-1 language code to localise results (e.g. "en", "de", "fr"). Combined with country for DuckDuckGo region targeting.', 'mcp-ai-wpoos' ),
				),
				'freshness'              => array(
					'type'        => 'string',
					'description' => __( 'Filter results by recency: "pd" = past day, "pw" = past week, "pm" = past month, "py" = past year. Supported by Brave.', 'mcp-ai-wpoos' ),
					'enum'        => array( 'pd', 'pw', 'pm', 'py' ),
				),
				'save_to_paper_store'    => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to automatically save search results to the Paper Store as a temporary record for later review or post creation.', 'mcp-ai-wpoos' ),
					'default'     => false,
				),
				'paper_store_collection' => array(
					'type'        => 'string',
					'description' => __( 'Paper Store collection name for saving results. Default: "web-search-results". Only used when save_to_paper_store is true.', 'mcp-ai-wpoos' ),
				),
				'paper_store_tags'       => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => __( 'Optional tags to apply to the Paper Store record for categorization.', 'mcp-ai-wpoos' ),
				),
			),
			'required'             => array( 'query' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @since 1.0.0
	 *
	 * @param array $arguments Tool arguments containing 'query' and optional 'max_results'.
	 * @param array $context   Execution context including user_id and agentic_loop flag.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'read' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to perform web searches.', 'mcp-ai-wpoos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'mcp-ai-wpoos' ) );
		}

		$query = isset( $arguments['query'] ) ? sanitize_text_field( $arguments['query'] ) : '';

		if ( '' === $query ) {
			return new WP_Error( 'wp_mcp_ai_missing_query', __( 'A search query is required.', 'mcp-ai-wpoos' ) );
		}

		$max_results = isset( $arguments['max_results'] ) ? absint( $arguments['max_results'] ) : 5;
		$max_results = $max_results > 0 ? min( $max_results, 10 ) : 5;

		$provider = WP_MCP_AI_Settings_Registry::get_setting( 'web_search_provider', 'duckduckgo' );

		// Extract optional localisation / freshness parameters (industry-standard fields).
		$search_options = array();

		if ( ! empty( $arguments['country'] ) ) {
			$country = strtoupper( sanitize_text_field( $arguments['country'] ) );
			if ( preg_match( '/^[A-Z]{2}$/', $country ) ) {
				$search_options['country'] = $country;
			}
		}

		if ( ! empty( $arguments['language'] ) ) {
			$search_options['language'] = strtolower( sanitize_text_field( $arguments['language'] ) );
		}

		$allowed_freshness = array( 'pd', 'pw', 'pm', 'py' );
		if ( ! empty( $arguments['freshness'] ) && in_array( $arguments['freshness'], $allowed_freshness, true ) ) {
			$search_options['freshness'] = $arguments['freshness'];
		}

		// Check cache first to avoid unnecessary API calls.
		if ( WP_MCP_AI_Cache_Helper::is_caching_enabled() ) {
			$cache_key     = $this->get_cache_key( $query, $max_results, $provider );
			$cached_result = WP_MCP_AI_Cache_Helper::get( $cache_key );

			if ( false !== $cached_result && is_array( $cached_result ) ) {
				$cached_result['cached'] = true;
				return $cached_result;
			}
		}

		// Check rate limiting after cache check to allow cached results even when rate limited.
		$rate_limit_check = $this->check_rate_limit( $user_id );
		if ( is_wp_error( $rate_limit_check ) ) {
			return $rate_limit_check;
		}

		// Perform the search.
		if ( 'brave' === $provider ) {
			$result = $this->perform_brave_search( $query, $max_results, $search_options );
		} elseif ( 'tavily' === $provider ) {
			$result = $this->perform_tavily_search( $query, $max_results, $search_options );
		} elseif ( 'exa' === $provider ) {
			$result = $this->perform_exa_search( $query, $max_results, $search_options );
		} elseif ( 'perplexity' === $provider ) {
			$result = $this->perform_perplexity_search( $query, $max_results, $search_options );
		} else {
			$result = $this->perform_duckduckgo_search( $query, $max_results, $search_options );
		}

		// Apply relevance reranking if the LibreChat addon is active and enabled.
		if ( ! is_wp_error( $result ) && ! empty( $result['results'] ) ) {
			$result = $this->maybe_rerank_results( $result, $query );
		}

		// Validate and normalize the result before caching and returning.
		// This ensures consistent structure and prevents corrupted data from being cached.
		if ( ! is_wp_error( $result ) ) {
			$result = $this->validate_and_normalize_result( $result, $query, $provider );
		}

		// Optionally save results to Paper Store as temp storage.
		if ( ! is_wp_error( $result ) && ! empty( $arguments['save_to_paper_store'] ) ) {
			$paper_save_result = $this->save_search_to_paper_store( $result, $arguments, $context );
			if ( ! is_wp_error( $paper_save_result ) ) {
				$result['paper_store_id']         = $paper_save_result;
				$result['paper_store_collection'] = isset( $arguments['paper_store_collection'] ) && ! empty( $arguments['paper_store_collection'] )
					? sanitize_key( $arguments['paper_store_collection'] )
					: 'web-search-results';
			}
		}

		// Cache successful results to reduce redundant API calls.
		if ( ! is_wp_error( $result ) && WP_MCP_AI_Cache_Helper::is_caching_enabled() ) {
			$cache_ttl = 5 * MINUTE_IN_SECONDS;

			/**
			 * Filter the cache TTL for web search results.
			 *
			 * @param int    $cache_ttl Cache time-to-live in seconds (default: 300).
			 * @param string $query     The search query.
			 * @param string $provider  Search provider name.
			 */
			$cache_ttl = apply_filters( 'wp_mcp_ai_web_search_cache_ttl', $cache_ttl, $query, $provider );

			$cache_key = $this->get_cache_key( $query, $max_results, $provider );
			WP_MCP_AI_Cache_Helper::set( $cache_key, $result, $cache_ttl );
		}

		// Fire action hook for non-agentic contexts (e.g., standalone tool API calls).
		// In agentic loop contexts, the result is already handled by the orchestration layer.
		// which sends it as a tool_result SSE event and adds it to the conversation.
		// Firing this action in agentic contexts would cause duplicate/conflicting events.
		$is_agentic_loop = ! empty( $context[ self::CONTEXT_AGENTIC_LOOP ] );

		/**
		 * Filter whether to fire the web_search_completed action.
		 *
		 * This allows advanced users to override the default behavior of skipping
		 * the action during agentic loops.
		 *
		 * @since 1.0.0
		 *
		 * @param bool  $should_fire   Whether to fire the action. Default false for agentic loops, true otherwise.
		 * @param array $result        Search results array.
		 * @param array $arguments     Original search arguments.
		 * @param array $context       Execution context.
		 * @param bool  $is_agentic_loop Whether executing within an agentic loop.
		 */
		$should_fire_action = apply_filters(
			'wp_mcp_ai_web_search_should_fire_completed_action',
			! $is_agentic_loop,
			$result,
			$arguments,
			$context,
			$is_agentic_loop
		);

		if ( ! is_wp_error( $result ) && $should_fire_action ) {
			// Log action firing for debugging (respects agentic loop logging setting).
			if ( WP_MCP_AI_Admin_Settings::is_agentic_loop_logging_enabled() ) {
				WP_MCP_AI_Logger::log_event(
					'debug',
					'Firing wp_mcp_ai_web_search_completed action',
					array(
						'query'           => $arguments['query'] ?? '',
						'result_count'    => $result['result_count'] ?? 0,
						'provider'        => $result['provider'] ?? 'unknown',
						'cached'          => $result['cached'] ?? false,
						'is_agentic_loop' => $is_agentic_loop,
					)
				);
			}

			/**
			 * Fires when a web search completes successfully outside of agentic loop.
			 *
			 * This hook allows extensions to react to search completions when the
			 * tool is called directly via REST API rather than through the chat flow.
			 *
			 * Note: By default, this action does NOT fire during agentic loop execution
			 * to avoid sending duplicate/conflicting events that could confuse the chat
			 * client. The orchestration layer handles result streaming in that context.
			 *
			 * @since 1.0.0
			 *
			 * @param array $result    Search results array with query, results, provider, etc.
			 * @param array $arguments Original search arguments (query, max_results).
			 * @param array $context   Execution context (user_id, agentic_loop flag, etc.).
			 */
			do_action( 'wp_mcp_ai_web_search_completed', $result, $arguments, $context );
		}

		return $result;
	}

	/**
	 * Check rate limiting for web searches.
	 *
	 * Prevents abuse and infinite loops by limiting search requests per user.
	 *
	 * @param int $user_id User ID performing the search.
	 * @return true|WP_Error True if allowed, WP_Error if rate limit exceeded.
	 */
	protected function check_rate_limit( $user_id ) {
		$transient_key  = 'wp_mcp_ai_web_search_' . $user_id;
		$current_count  = get_transient( $transient_key );
		$max_per_minute = 20; // Allow up to 20 searches per minute per user.

		/**
		 * Filter the maximum web searches allowed per minute per user.
		 *
		 * @param int $max_per_minute Maximum searches per minute (default: 20).
		 * @param int $user_id        User ID.
		 */
		$max_per_minute = apply_filters( 'wp_mcp_ai_web_search_rate_limit', $max_per_minute, $user_id );

		if ( false === $current_count ) {
			// First search, start counting.
			set_transient( $transient_key, 1, MINUTE_IN_SECONDS );
			return true;
		}

		if ( $current_count >= $max_per_minute ) {
			return new WP_Error(
				'wp_mcp_ai_rate_limit_exceeded',
				sprintf(
					/* translators: %d: maximum searches allowed per minute */
					__( 'Web search rate limit exceeded. Maximum %d searches per minute allowed.', 'mcp-ai-wpoos' ),
					$max_per_minute
				)
			);
		}

		// Increment counter.
		set_transient( $transient_key, $current_count + 1, MINUTE_IN_SECONDS );
		return true;
	}

	/**
	 * Generate a cache key for search results.
	 *
	 * @param string $query       The search query.
	 * @param int    $max_results Maximum number of results.
	 * @param string $provider    Search provider name.
	 * @return string Cache key for the search (without prefix - Cache Helper adds it).
	 */
	protected function get_cache_key( $query, $max_results, $provider ) {
		return 'search_' . md5( $query . '|' . $max_results . '|' . $provider );
	}

	/**
	 * Handle HTTP 202 (Accepted) response - search is being processed asynchronously.
	 *
	 * Returns an informational status (not a hard error) indicating the search service
	 * is still processing the request. The orchestration layer can use the retry_after
	 * value to determine appropriate timing for retry attempts.
	 *
	 * @param array $response The HTTP response array from wp_remote_get.
	 * @return WP_Error Error object with pending status and retry information.
	 */
	protected function handle_pending_response( $response ) {
		// Validate response is an array before proceeding.
		if ( ! is_array( $response ) ) {
			// Return informational status without retry_after if response is invalid.
			return new WP_Error(
				'wp_mcp_ai_search_pending',
				__(
					'The web search service is temporarily processing your request. Please try alternative information sources or retry in a few moments.',
					'mcp-ai-wpoos'
				),
				array(
					'status'      => 202,
					'is_pending'  => true,
					'should_wait' => false,
					'retry_after' => null,
				)
			);
		}

		// Extract retry-after header if present.
		// wp_remote_retrieve_header returns empty string when header is not found, not null.
		// Note: retry_after is kept as string to match HTTP header format and test expectations.
		$retry_after = wp_remote_retrieve_header( $response, 'retry-after' );

		// Build an informative message that maintains backward compatibility with tests.
		$message = __(
			'The web search service is temporarily processing your request. Please try alternative information sources or retry in a few moments.',
			'mcp-ai-wpoos'
		);

		if ( '' !== $retry_after ) {
			$message = sprintf(
				/* translators: %s: number of seconds to wait before retrying */
				__( 'The web search service is temporarily processing your request. The service suggests waiting %s seconds before retrying, or you can try alternative information sources.', 'mcp-ai-wpoos' ),
				$retry_after
			);
		}

		return new WP_Error(
			'wp_mcp_ai_search_pending',
			$message,
			array(
				'status'      => 202,
				'is_pending'  => true,
				'should_wait' => false,
				'retry_after' => '' !== $retry_after ? (string) $retry_after : null,
			)
		);
	}

	/**
	 * Perform a DuckDuckGo Instant Answer search.
	 *
	 * Uses the DuckDuckGo Instant Answer API following patterns from the
	 * duckduckgo-api-haystack reference implementation for proper response parsing
	 * and error handling.
	 *
	 * Executes a single synchronous HTTP request. If the service returns HTTP 202
	 * (Accepted), a pending error is returned immediately to allow the orchestration
	 * layer to handle retry timing and strategy.
	 *
	 * @link https://github.com/GivAlz/duckduckgo-api-haystack
	 *
	 * @param string $query       The sanitized search query.
	 * @param int    $max_results Maximum number of results to return.
	 *
	 * @param array  $options     Optional: country, language.
	 * @return array|WP_Error Search response payload or WP_Error on failure.
	 */
	protected function perform_duckduckgo_search( $query, $max_results, array $options = array() ) {
		$query_args = array(
			'q'             => $query,
			'format'        => 'json',
			'no_html'       => 1,
			'skip_disambig' => 1,
		);

		// Build DuckDuckGo region (kl) from country + language when provided.
		// Format: "{country_lower}-{language}" e.g. "us-en", "de-de".
		if ( ! empty( $options['country'] ) && ! empty( $options['language'] ) ) {
			$query_args['kl'] = strtolower( $options['country'] ) . '-' . strtolower( $options['language'] );
		} elseif ( ! empty( $options['language'] ) ) {
			$query_args['kl'] = strtolower( $options['language'] );
		}

		$request_url = $this->build_search_url( 'https://api.duckduckgo.com/', $query_args );

		$response = $this->perform_search_with_retry(
			$request_url,
			array(
				'timeout' => 10,
				'headers' => array(
					'Accept' => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			// Preserve pending and rate-limited responses as-is for orchestration layer.
			if ( 'wp_mcp_ai_search_pending' === $response->get_error_code()
				|| 'wp_mcp_ai_search_rate_limited' === $response->get_error_code()
			) {
				return $response;
			}

			return new WP_Error(
				'wp_mcp_ai_search_failed',
				__( 'The web search request failed.', 'mcp-ai-wpoos' ),
				$response->get_error_message()
			);
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );

		// Handle HTTP 202 (Accepted) - search is being processed asynchronously.
		// Return immediately to allow orchestration layer to manage retries.
		if ( 202 === $status_code ) {
			return $this->handle_pending_response( $response );
		}

		if ( 200 !== $status_code ) {
			return new WP_Error(
				'wp_mcp_ai_search_http_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'The web search service returned an unexpected HTTP status: %d.', 'mcp-ai-wpoos' ),
					$status_code
				)
			);
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( null === $data || ! is_array( $data ) ) {
			return new WP_Error( 'wp_mcp_ai_search_bad_json', __( 'The web search response could not be decoded.', 'mcp-ai-wpoos' ) );
		}

		$results = array();

		if ( ! empty( $data['AbstractText'] ) && ! empty( $data['AbstractURL'] ) ) {
			$results[] = array(
				'title'   => isset( $data['Heading'] ) ? $this->sanitize_utf8( sanitize_text_field( $data['Heading'] ) ) : $this->sanitize_utf8( sanitize_text_field( wp_trim_words( $data['AbstractText'], 12 ) ) ),
				'url'     => esc_url_raw( $data['AbstractURL'] ),
				'snippet' => $this->sanitize_utf8( sanitize_text_field( $data['AbstractText'] ) ),
				'source'  => 'duckduckgo',
				'type'    => 'abstract',
			);
		}

		if ( ! empty( $data['RelatedTopics'] ) && is_array( $data['RelatedTopics'] ) ) {
			foreach ( $data['RelatedTopics'] as $topic ) {
				if ( $this->maybe_add_topic_result( $topic, $results, $max_results ) ) {
					break;
				}
			}
		}

		// Deduplicate results by URL to prevent repeated content.
		$results = $this->deduplicate_results( $results );
		$results = array_slice( $results, 0, $max_results );

		if ( empty( $results ) ) {
			$task_id = $this->generate_task_id( $query, 'duckduckgo' );
			return $this->ensure_response_message(
				array(
					'task_id'        => $task_id,
					'query'          => $query,
					'results'        => array(),
					'note'           => __( 'No web search results were found for this query.', 'mcp-ai-wpoos' ),
					'cached'         => false,
					'provider'       => 'duckduckgo',
					'system_message' => sprintf(
						/* translators: %s: search query */
						__( 'Web search completed for "%s" but no results were found.', 'mcp-ai-wpoos' ),
						$query
					),
				),
				sprintf(
					/* translators: %s: search query */
					__( 'Web search completed for "%s" but no results were found.', 'mcp-ai-wpoos' ),
					$query
				)
			);
		}

		// Build descriptive text message for the LLM (removed from base result to prevent SSE streaming extraction).
		// The text will be added by sanitize_for_llm() for LLM consumption only.
		// Include system_message for chat client display without treating it as assistant content.
		$text_parts   = array();
		$text_parts[] = sprintf(
			/* translators: 1: result count, 2: search query */
			_n(
				'Found %1$d web search result for "%2$s"',
				'Found %1$d web search results for "%2$s"',
				count( $results ),
				'mcp-ai-wpoos'
			),
			count( $results ),
			$query
		);

		// Add brief summary of top results for chat UI visibility.
		if ( ! empty( $results[0]['title'] ) ) {
			$text_parts[] = sprintf(
				/* translators: %s: title of first search result */
				__( 'Top result: %s', 'mcp-ai-wpoos' ),
				wp_trim_words( $results[0]['title'], 10, '...' )
			);
		}

		$task_id = $this->generate_task_id( $query, 'duckduckgo' );
		return $this->ensure_response_message(
			array(
				'task_id'        => $task_id,
				'query'          => $query,
				'results'        => $results,
				'result_count'   => count( $results ),
				'cached'         => false,
				'provider'       => 'duckduckgo',
				'timestamp'      => time(),
				'system_message' => implode( ' ', $text_parts ), // System message for chat client (not extracted as assistant content).
			),
			sprintf(
				/* translators: %d: number of results */
				__( 'Found %d results', 'mcp-ai-wpoos' ),
				count( $results )
			)
		);
	}

	/**
	 * Perform a Brave Search API lookup.
	 *
	 * Uses the Brave Search REST API v1 following patterns from the
	 * brave-search-mcp-server reference implementation for proper authentication,
	 * response parsing, and error handling including async (HTTP 202) responses.
	 *
	 * Executes a single synchronous HTTP request. If the service returns HTTP 202
	 * (Accepted), a pending error is returned immediately to allow the orchestration
	 * layer to handle retry timing and strategy.
	 *
	 * @link https://github.com/brave/brave-search-mcp-server
	 *
	 * @param string $query       The sanitized search query.
	 * @param int    $max_results Maximum number of results to return.
	 * @param array  $options     Optional: country, language, freshness.
	 *
	 * @return array|WP_Error Search response payload or WP_Error on failure.
	 */
	protected function perform_brave_search( $query, $max_results, array $options = array() ) {
		$api_key = WP_MCP_AI_Settings_Registry::get_setting( 'brave_search_api_key', '' );

		if ( '' === $api_key ) {
			return new WP_Error( 'wp_mcp_ai_search_missing_api_key', __( 'A Brave Search API key is required to perform searches.', 'mcp-ai-wpoos' ) );
		}

		$query_args = array(
			'q'              => $query,
			'count'          => max( 1, $max_results ),
			'safesearch'     => 'moderate',
			'extra_snippets' => 1, // Return additional context snippets per result.
		);

		// Country targeting (ISO 3166-1 alpha-2).
		if ( ! empty( $options['country'] ) ) {
			$query_args['country'] = strtoupper( $options['country'] );
		}

		// Content language (ISO 639-1).
		if ( ! empty( $options['language'] ) ) {
			$query_args['search_lang'] = strtolower( $options['language'] );
		}

		// Freshness filter: pd=day, pw=week, pm=month, py=year.
		if ( ! empty( $options['freshness'] ) ) {
			$query_args['freshness'] = $options['freshness'];
		}

		$request_url = $this->build_search_url( 'https://api.search.brave.com/res/v1/web/search', $query_args );

		$response = $this->perform_search_with_retry(
			$request_url,
			array(
				'timeout' => 10,
				'headers' => array(
					'Accept'               => 'application/json',
					'X-Subscription-Token' => $api_key,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			// Preserve pending and rate-limited responses as-is for the orchestration layer.
			if ( 'wp_mcp_ai_search_pending' === $response->get_error_code()
				|| 'wp_mcp_ai_search_rate_limited' === $response->get_error_code()
			) {
				return $response;
			}

			return new WP_Error(
				'wp_mcp_ai_search_failed',
				__( 'The web search request failed.', 'mcp-ai-wpoos' ),
				$response->get_error_message()
			);
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );

		// Handle HTTP 202 (Accepted) - search is being processed asynchronously.
		// Return immediately to allow orchestration layer to manage retries.
		if ( 202 === $status_code ) {
			return $this->handle_pending_response( $response );
		}

		if ( 200 !== $status_code ) {
			return new WP_Error(
				'wp_mcp_ai_search_http_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'The web search service returned an unexpected HTTP status: %d.', 'mcp-ai-wpoos' ),
					$status_code
				)
			);
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( null === $data || ! is_array( $data ) ) {
			return new WP_Error( 'wp_mcp_ai_search_bad_json', __( 'The web search response could not be decoded.', 'mcp-ai-wpoos' ) );
		}

		$results = array();

		if ( isset( $data['web']['results'] ) && is_array( $data['web']['results'] ) ) {
			foreach ( $data['web']['results'] as $item ) {
				if ( empty( $item['url'] ) ) {
					continue;
				}

				$title   = isset( $item['title'] ) ? $this->sanitize_utf8( sanitize_text_field( $item['title'] ) ) : '';
				$snippet = '';

				if ( ! empty( $item['description'] ) ) {
					$snippet = $this->sanitize_utf8( sanitize_text_field( $item['description'] ) );
				}

				// Append extra_snippets (returned when extra_snippets=1 is set) for richer context.
				if ( ! empty( $item['extra_snippets'] ) && is_array( $item['extra_snippets'] ) ) {
					$extra   = $this->sanitize_utf8( sanitize_text_field( implode( ' ', $item['extra_snippets'] ) ) );
					$snippet = $snippet ? $snippet . ' ' . $extra : $extra;
				}

				$results[] = array(
					'title'   => $title ? $title : esc_url_raw( $item['url'] ),
					'url'     => esc_url_raw( $item['url'] ),
					'snippet' => $snippet,
					'source'  => 'brave',
					'type'    => 'result',
				);

				if ( count( $results ) >= $max_results ) {
					break;
				}
			}
		}

		// Deduplicate results by URL to prevent repeated content.
		$results = $this->deduplicate_results( $results );

		if ( empty( $results ) ) {
			$task_id = $this->generate_task_id( $query, 'brave' );
			return $this->ensure_response_message(
				array(
					'task_id'        => $task_id,
					'query'          => $query,
					'results'        => array(),
					'note'           => __( 'No web search results were found for this query.', 'mcp-ai-wpoos' ),
					'cached'         => false,
					'provider'       => 'brave',
					'system_message' => sprintf(
						/* translators: %s: search query */
						__( 'Web search completed for "%s" but no results were found.', 'mcp-ai-wpoos' ),
						$query
					),
				),
				sprintf(
					/* translators: %s: search query */
					__( 'Web search completed for "%s" but no results were found.', 'mcp-ai-wpoos' ),
					$query
				)
			);
		}

		// Build descriptive text message for the LLM and chat UI.
		$text_parts   = array();
		$text_parts[] = sprintf(
			/* translators: 1: result count, 2: search query */
			_n(
				'Found %1$d web search result for "%2$s"',
				'Found %1$d web search results for "%2$s"',
				count( $results ),
				'mcp-ai-wpoos'
			),
			count( $results ),
			$query
		);

		// Add brief summary of top results for chat UI visibility.
		if ( ! empty( $results[0]['title'] ) ) {
			$text_parts[] = sprintf(
				/* translators: %s: title of first search result */
				__( 'Top result: %s', 'mcp-ai-wpoos' ),
				wp_trim_words( $results[0]['title'], 10, '...' )
			);
		}

		$task_id = $this->generate_task_id( $query, 'brave' );
		return $this->ensure_response_message(
			array(
				'task_id'        => $task_id,
				'query'          => $query,
				'results'        => $results,
				'result_count'   => count( $results ),
				'cached'         => false,
				'provider'       => 'brave',
				'timestamp'      => time(),
				'system_message' => implode( ' ', $text_parts ), // System message for chat client (not extracted as assistant content).
			),
			sprintf(
				/* translators: %d: number of results */
				__( 'Found %d results', 'mcp-ai-wpoos' ),
				count( $results )
			)
		);
	}

	/**
	 * Maybe add a topic result to the results array.
	 *
	 * @param array $topic       Topic data from DuckDuckGo.
	 * @param array $results     Current list of results (passed by reference).
	 * @param int   $max_results Maximum number of results allowed.
	 *
	 * @return bool Whether the caller should stop processing further topics.
	 */
	protected function maybe_add_topic_result( $topic, array &$results, $max_results ) {
		if ( empty( $topic ) || ! is_array( $topic ) ) {
			return false;
		}

		if ( count( $results ) >= $max_results ) {
			return true;
		}

		if ( isset( $topic['Topics'] ) && is_array( $topic['Topics'] ) ) {
			foreach ( $topic['Topics'] as $nested_topic ) {
				if ( $this->maybe_add_topic_result( $nested_topic, $results, $max_results ) ) {
					return true;
				}
			}

			return false;
		}

		if ( empty( $topic['FirstURL'] ) || empty( $topic['Text'] ) ) {
			return false;
		}

		$results[] = array(
			'title'   => isset( $topic['Text'] ) ? $this->sanitize_utf8( sanitize_text_field( $topic['Text'] ) ) : '',
			'url'     => esc_url_raw( $topic['FirstURL'] ),
			'snippet' => isset( $topic['Result'] ) ? $this->sanitize_utf8( wp_strip_all_tags( $topic['Result'] ) ) : '',
			'source'  => 'duckduckgo',
			'type'    => 'result',
		);

		return count( $results ) >= $max_results;
	}

	/**
	 * Perform a Tavily search.
	 *
	 * Tavily is an AI-first search API purpose-built for LLM agents and RAG pipelines.
	 * It aggregates and parses real-time web content, returning structured results and
	 * optionally an AI-generated answer — all optimised for LLM consumption.
	 *
	 * @link https://docs.tavily.com/docs/rest-api/api-reference
	 *
	 * @param string $query       The sanitized search query.
	 * @param int    $max_results Maximum number of results to return.
	 * @param array  $options     Optional: country.
	 *
	 * @return array|WP_Error Search response payload or WP_Error on failure.
	 */
	protected function perform_tavily_search( $query, $max_results, array $options = array() ) {
		$api_key = WP_MCP_AI_Settings_Registry::get_setting( 'tavily_api_key', '' );

		if ( '' === $api_key ) {
			return new WP_Error( 'wp_mcp_ai_search_missing_api_key', __( 'A Tavily API key is required to perform searches.', 'mcp-ai-wpoos' ) );
		}

		$body = array(
			'query'          => $query,
			'max_results'    => max( 1, min( $max_results, 10 ) ),
			'search_depth'   => 'basic',
			'include_answer' => false,
		);

		// Tavily does not have an official country/language query param as of their current API.
		// The country value from $options is accepted in the schema for future compatibility
		// but is not forwarded in the request body. Future API versions may add geo-targeting.
		// phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable -- accepted for future use
		$encoded_body = wp_json_encode( $body );
		if ( false === $encoded_body ) {
			return new WP_Error( 'wp_mcp_ai_encoding_error', __( 'Failed to encode the Tavily search payload.', 'mcp-ai-wpoos' ) );
		}

		$response = $this->perform_search_with_retry(
			'https://api.tavily.com/search',
			array(
				'method'  => 'POST',
				'timeout' => 15,
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'    => $encoded_body,
			)
		);

		if ( is_wp_error( $response ) ) {
			// Preserve pending and rate-limited responses as-is for orchestration layer.
			if ( 'wp_mcp_ai_search_pending' === $response->get_error_code()
				|| 'wp_mcp_ai_search_rate_limited' === $response->get_error_code()
			) {
				return $response;
			}

			return new WP_Error(
				'wp_mcp_ai_search_failed',
				__( 'The web search request failed.', 'mcp-ai-wpoos' ),
				$response->get_error_message()
			);
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );

		if ( 202 === $status_code ) {
			return $this->handle_pending_response( $response );
		}

		if ( 200 !== $status_code ) {
			return new WP_Error(
				'wp_mcp_ai_search_http_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'The web search service returned an unexpected HTTP status: %d.', 'mcp-ai-wpoos' ),
					$status_code
				)
			);
		}

		$raw_body = wp_remote_retrieve_body( $response );
		$data     = json_decode( $raw_body, true );

		if ( null === $data || ! is_array( $data ) ) {
			return new WP_Error( 'wp_mcp_ai_search_bad_json', __( 'The web search response could not be decoded.', 'mcp-ai-wpoos' ) );
		}

		$results = array();

		if ( isset( $data['results'] ) && is_array( $data['results'] ) ) {
			foreach ( $data['results'] as $item ) {
				if ( empty( $item['url'] ) ) {
					continue;
				}

				$title = isset( $item['title'] ) ? $this->sanitize_utf8( sanitize_text_field( $item['title'] ) ) : '';
				// Tavily returns content (page excerpt) rather than a short description.
				$snippet = isset( $item['content'] ) ? $this->sanitize_utf8( sanitize_text_field( $item['content'] ) ) : '';

				$result_item = array(
					'title'   => $title ? $title : esc_url_raw( $item['url'] ),
					'url'     => esc_url_raw( $item['url'] ),
					'snippet' => $snippet,
					'source'  => 'tavily',
					'type'    => 'result',
				);

				if ( ! empty( $item['published_date'] ) ) {
					$result_item['published_date'] = sanitize_text_field( $item['published_date'] );
				}

				$results[] = $result_item;

				if ( count( $results ) >= $max_results ) {
					break;
				}
			}
		}

		// Deduplicate results by URL.
		$results = $this->deduplicate_results( $results );

		if ( empty( $results ) ) {
			$task_id = $this->generate_task_id( $query, 'tavily' );
			return $this->ensure_response_message(
				array(
					'task_id'        => $task_id,
					'query'          => $query,
					'results'        => array(),
					'note'           => __( 'No web search results were found for this query.', 'mcp-ai-wpoos' ),
					'cached'         => false,
					'provider'       => 'tavily',
					'system_message' => sprintf(
						/* translators: %s: search query */
						__( 'Web search completed for "%s" but no results were found.', 'mcp-ai-wpoos' ),
						$query
					),
				),
				sprintf(
					/* translators: %s: search query */
					__( 'Web search completed for "%s" but no results were found.', 'mcp-ai-wpoos' ),
					$query
				)
			);
		}

		// Build descriptive text for the LLM and chat UI.
		$text_parts   = array();
		$text_parts[] = sprintf(
			/* translators: 1: result count, 2: search query */
			_n(
				'Found %1$d web search result for "%2$s"',
				'Found %1$d web search results for "%2$s"',
				count( $results ),
				'mcp-ai-wpoos'
			),
			count( $results ),
			$query
		);

		if ( ! empty( $results[0]['title'] ) ) {
			$text_parts[] = sprintf(
				/* translators: %s: title of first search result */
				__( 'Top result: %s', 'mcp-ai-wpoos' ),
				wp_trim_words( $results[0]['title'], 10, '...' )
			);
		}

		$task_id = $this->generate_task_id( $query, 'tavily' );
		return $this->ensure_response_message(
			array(
				'task_id'        => $task_id,
				'query'          => $query,
				'results'        => $results,
				'result_count'   => count( $results ),
				'cached'         => false,
				'provider'       => 'tavily',
				'timestamp'      => time(),
				'system_message' => implode( ' ', $text_parts ),
			),
			sprintf(
				/* translators: %d: number of results */
				__( 'Found %d results', 'mcp-ai-wpoos' ),
				count( $results )
			)
		);
	}

		/**
		 * Perform a web search using Exa AI's neural search API.
		 *
		 * Exa provides semantic / neural web search purpose-built for AI applications.
		 * Unlike keyword-based search, Exa understands query intent and returns highly
		 * relevant results using embedding-based retrieval.
		 *
		 * API reference: https://docs.exa.ai/reference/search
		 *
		 * @param string $query       Search query string.
		 * @param int    $max_results Maximum number of results to return.
		 * @param array  $options     Optional: 'country', 'language', 'freshness' parameters.
		 * @return array|WP_Error Normalized result array or WP_Error on failure.
		 */
	protected function perform_exa_search( $query, $max_results, array $options = array() ) {
		$settings = WP_MCP_AI_Admin_Settings::get_settings();
		$api_key  = isset( $settings['exa_api_key'] ) ? trim( $settings['exa_api_key'] ) : '';

		if ( empty( $api_key ) ) {
			return new WP_Error(
				'wp_mcp_ai_missing_exa_api_key',
				__( 'An Exa AI API key is required. Configure it in NV oOS → Settings → Tools.', 'mcp-ai-wpoos' )
			);
		}

		$timeout = isset( $settings['request_timeout'] ) ? absint( $settings['request_timeout'] ) : 10;
		$timeout = max( 5, min( 15, $timeout ) );

		// Build request payload.
		$payload = array(
			'query'         => $query,
			'numResults'    => $max_results,
			'useAutoprompt' => true,
			'type'          => 'auto',
			'contents'      => array(
				'text' => array(
					'maxCharacters' => 1000,
				),
			),
		);

		// Freshness filter: Exa uses startCrawlDate / startPublishedDate.
		if ( ! empty( $options['freshness'] ) ) {
			$days_map = array(
				'pd' => 1,
				'pw' => 7,
				'pm' => 30,
				'py' => 365,
			);
			if ( isset( $days_map[ $options['freshness'] ] ) ) {
				$days                          = $days_map[ $options['freshness'] ];
				$payload['startPublishedDate'] = gmdate( 'Y-m-d\TH:i:s\Z', strtotime( "-{$days} days" ) );
			}
		}

		/**
		 * Filter the Exa AI search payload before it is sent.
		 *
		 * @param array  $payload     Request payload.
		 * @param string $query       Search query.
		 * @param int    $max_results Maximum results requested.
		 * @param array  $options     Search options.
		 */
		$payload = apply_filters( 'wp_mcp_ai_exa_search_payload', $payload, $query, $max_results, $options );

		$response = wp_remote_post(
			'https://api.exa.ai/search',
			array(
				'headers' => array(
					'x-api-key'    => $api_key,
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $timeout,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
			return new WP_Error(
				'wp_mcp_ai_exa_invalid_response',
				__( 'Exa AI returned an invalid response.', 'mcp-ai-wpoos' )
			);
		}

		if ( $code < 200 || $code >= 300 ) {
			$msg = isset( $data['error'] ) && is_string( $data['error'] ) ? $data['error'] : __( 'Exa AI search request failed.', 'mcp-ai-wpoos' );

			return new WP_Error( 'wp_mcp_ai_exa_error', $msg, array( 'status' => $code ) );
		}

		// Normalize results to the standard tool result format.
		$results = array();
		if ( isset( $data['results'] ) && is_array( $data['results'] ) ) {
			foreach ( $data['results'] as $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}

				$title   = isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : '';
				$url     = isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';
				$snippet = '';

				if ( isset( $item['text'] ) && is_string( $item['text'] ) ) {
					$snippet = sanitize_text_field( substr( $item['text'], 0, 300 ) );
				} elseif ( isset( $item['highlights'] ) && is_array( $item['highlights'] ) ) {
					$snippet = sanitize_text_field( implode( ' ', array_slice( $item['highlights'], 0, 2 ) ) );
				}

				if ( '' === $url ) {
					continue;
				}

				$results[] = array(
					'title'   => $title,
					'url'     => $url,
					'snippet' => $snippet,
				);
			}
		}

		$text_parts = array();
		foreach ( array_slice( $results, 0, self::MAX_LLM_RESULTS ) as $r ) {
			$text_parts[] = sprintf( '%s — %s', $r['title'], $r['snippet'] );
		}

		return $this->build_tool_result(
			array(
				'results'        => $results,
				'provider'       => 'exa',
				'query'          => $query,
				'system_message' => implode( ' ', $text_parts ),
			),
			sprintf(
				/* translators: %d: number of results */
				__( 'Found %d results', 'mcp-ai-wpoos' ),
				count( $results )
			)
		);
	}

	/**
	 * Build a canonical tool result envelope for a provider response.
	 *
	 * Ensures the payload always carries a user-facing 'message' field
	 * alongside the provider data, matching the shape returned by the
	 * other search providers (Brave, DuckDuckGo, Tavily) via
	 * ensure_response_message().
	 *
	 * @param array  $result_data      Provider response data.
	 * @param string $fallback_message Optional fallback message.
	 * @return array Canonical result envelope.
	 */
	protected function build_tool_result( $result_data, $fallback_message = '' ) {
		return $this->ensure_response_message( $result_data, $fallback_message );
	}

	/**
	 * Perform a web search using Perplexity's Sonar API.
	 *
	 * Perplexity Sonar is an AI-powered search model that produces grounded answers
	 * with inline citations from real-time web sources. The API uses the chat-completions
	 * format with `online_` or `sonar` model family prefixes.
	 *
	 * API reference: https://docs.perplexity.ai/reference/post_chat_completions
	 *
	 * @param string $query       Search query string.
	 * @param int    $max_results Maximum number of results to surface (informational only;
	 *                            Perplexity returns a synthesised answer with citations).
	 * @param array  $options     Optional: 'country', 'language' parameters.
	 * @return array|WP_Error Normalized result array or WP_Error on failure.
	 */
	protected function perform_perplexity_search( $query, $max_results, array $options = array() ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- $max_results retained for API signature parity.
		$settings = WP_MCP_AI_Admin_Settings::get_settings();
		$api_key  = isset( $settings['perplexity_api_key'] ) ? trim( $settings['perplexity_api_key'] ) : '';

		if ( empty( $api_key ) ) {
			return new WP_Error(
				'wp_mcp_ai_missing_perplexity_api_key',
				__( 'A Perplexity API key is required. Configure it in NV oOS → Settings → Tools.', 'mcp-ai-wpoos' )
			);
		}

		$timeout = isset( $settings['request_timeout'] ) ? absint( $settings['request_timeout'] ) : 15;
		$timeout = max( 5, min( 30, $timeout ) );

		// Choose the model — sonar-pro delivers richer citations.
		$model = apply_filters( 'wp_mcp_ai_perplexity_search_model', 'sonar-pro', $options );
		$model = sanitize_text_field( $model );

		// Build system instruction for concise, citation-rich answers.
		$system_instruction = __( 'You are a helpful web search assistant. Provide a clear, concise answer with relevant citations to real web sources. Cite your sources inline.', 'mcp-ai-wpoos' );

		// Append language hint to query if provided.
		$search_query = $query;
		if ( ! empty( $options['country'] ) ) {
			$search_query .= ' site:' . strtolower( $options['country'] );
		}

		$payload = array(
			'model'    => $model,
			'messages' => array(
				array(
					'role'    => 'system',
					'content' => $system_instruction,
				),
				array(
					'role'    => 'user',
					'content' => $search_query,
				),
			),
		);

		// Freshness via search_recency_filter.
		if ( ! empty( $options['freshness'] ) ) {
			$recency_map = array(
				'pd' => 'day',
				'pw' => 'week',
				'pm' => 'month',
				'py' => 'year',
			);
			if ( isset( $recency_map[ $options['freshness'] ] ) ) {
				$payload['search_recency_filter'] = $recency_map[ $options['freshness'] ];
			}
		}

		/**
		 * Filter the Perplexity search payload before it is sent.
		 *
		 * @param array  $payload  Request payload.
		 * @param string $query    Search query.
		 * @param array  $options  Search options.
		 */
		$payload = apply_filters( 'wp_mcp_ai_perplexity_search_payload', $payload, $query, $options );

		$response = wp_remote_post(
			'https://api.perplexity.ai/chat/completions',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $timeout,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
			return new WP_Error(
				'wp_mcp_ai_perplexity_invalid_response',
				__( 'Perplexity returned an invalid response.', 'mcp-ai-wpoos' )
			);
		}

		if ( $code < 200 || $code >= 300 ) {
			$msg = isset( $data['error']['message'] ) ? $data['error']['message'] : __( 'Perplexity search request failed.', 'mcp-ai-wpoos' );

			return new WP_Error( 'wp_mcp_ai_perplexity_error', $msg, array( 'status' => $code ) );
		}

		// Extract the answer text.
		$answer = '';
		if ( isset( $data['choices'][0]['message']['content'] ) ) {
			$answer = sanitize_textarea_field( $data['choices'][0]['message']['content'] );
		}

		// Extract citations.
		$citations = array();
		if ( isset( $data['citations'] ) && is_array( $data['citations'] ) ) {
			foreach ( $data['citations'] as $citation_url ) {
				if ( is_string( $citation_url ) && '' !== $citation_url ) {
					$citations[] = esc_url_raw( $citation_url );
				}
			}
		}

		// Build normalized result list from citations.
		$results = array();
		foreach ( $citations as $citation_url ) {
			$results[] = array(
				'title'   => '',
				'url'     => $citation_url,
				'snippet' => '',
			);
		}

		return $this->build_tool_result(
			array(
				'results'        => $results,
				'provider'       => 'perplexity',
				'query'          => $query,
				'answer'         => $answer,
				'citations'      => $citations,
				'system_message' => $answer,
			),
			'' !== $answer
				? __( 'Perplexity Sonar answered your query', 'mcp-ai-wpoos' )
				: __( 'No results found', 'mcp-ai-wpoos' )
		);
	}

	/**
	 * Perform a search request without blocking retry logic.
	 *
	 * Executes a single synchronous HTTP request and returns immediately.
	 * If the server returns HTTP 202 (Accepted), a pending error is returned
	 * to allow the orchestration layer to handle retries asynchronously.
	 *
	 * This approach ensures the tool returns quickly (typically < 10 seconds)
	 * and doesn't block agentic workflows, allowing the LLM to proceed with
	 * alternative information sources or retry later.
	 *
	 * @param string $url  Request URL.
	 * @param array  $args Request arguments for wp_remote_get.
	 *
	 * @return array|WP_Error HTTP response array or WP_Error for pending requests.
	 */
	protected function perform_search_with_retry( $url, $args = array() ) {
		$max_retries = 3;

		/**
		 * Filter the maximum number of retry attempts for web search HTTP requests.
		 *
		 * Retries are attempted only for 429 (Too Many Requests) responses.
		 *
		 * @since 2.9.0
		 *
		 * @param int    $max_retries Maximum retry attempts (default: 3).
		 * @param string $url         The request URL.
		 * @param array  $args        The request arguments.
		 */
		$max_retries = apply_filters( 'wp_mcp_ai_web_search_max_retries', $max_retries, $url, $args );

		$attempt = 0;

		while ( $attempt <= $max_retries ) {
			$response = wp_remote_get( $url, $args );

			// Network or WordPress errors should be returned immediately.
			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$status_code = (int) wp_remote_retrieve_response_code( $response );

			// Success - return the response.
			if ( 200 === $status_code ) {
				return $response;
			}

			// HTTP 202 (Accepted) - request is being processed asynchronously.
			// Return pending error immediately for orchestration layer to handle.
			if ( 202 === $status_code ) {
				return $this->handle_pending_response( $response );
			}

			// HTTP 429 (Too Many Requests) - apply rate-limit backoff and retry.
			if ( 429 === $status_code && $attempt < $max_retries ) {
				$retry_after = wp_remote_retrieve_header( $response, 'retry-after' );
				if ( '' !== $retry_after && is_numeric( $retry_after ) ) {
					$wait = min( (int) $retry_after, 10 ); // Cap at 10 seconds.
				} else {
					// Exponential backoff: 1s, 2s, 4s.
					$wait = pow( 2, $attempt );
				}

				++$attempt;

				if ( WP_MCP_AI_Admin_Settings::is_agentic_loop_logging_enabled() ) {
					WP_MCP_AI_Logger::log_event(
						'warning',
						'Web search rate-limited, retrying after backoff',
						array(
							'url'         => $url,
							'attempt'     => $attempt,
							'max_retries' => $max_retries,
							'wait'        => $wait,
						)
					);
				}

				sleep( $wait );
				continue;
			}

			// Other HTTP status codes (errors) - return the response for handling.
			return $response;
		}

		// All retries exhausted for 429 — return a clear rate-limit error.
		return new WP_Error(
			'wp_mcp_ai_search_rate_limited',
			sprintf(
				/* translators: %d: number of retry attempts made */
				__( 'The web search service is temporarily rate-limited. Tried %d times — please wait a moment and try again.', 'mcp-ai-wpoos' ),
				$max_retries + 1
			),
			array(
				'status'      => 429,
				'retry_after' => isset( $wait ) ? $wait * 2 : 8,
				'should_wait' => true,
			)
		);
	}

	/**
	 * Deduplicate search results by URL.
	 *
	 * Removes duplicate results to prevent the same content from appearing multiple times,
	 * which can help reduce confusion and prevent infinite loops in agentic workflows.
	 *
	 * @param array $results Array of search results.
	 * @return array Deduplicated results.
	 */
	protected function deduplicate_results( array $results ) {
		$seen_urls = array();
		$unique    = array();

		foreach ( $results as $result ) {
			if ( empty( $result['url'] ) ) {
				continue;
			}

			// Normalize URL for comparison (remove trailing slashes, query params that don't matter).
			$normalized_url = untrailingslashit( $result['url'] );

			// Skip if we've already seen this URL.
			if ( in_array( $normalized_url, $seen_urls, true ) ) {
				continue;
			}

			$seen_urls[] = $normalized_url;
			$unique[]    = $result;
		}

		return $unique;
	}

	/**
	 * Save search results to the Paper Store.
	 *
	 * Creates a temporary record in the specified Paper Store collection
	 * containing the full search result set, metadata, and source information.
	 *
	 * @since 1.4.0
	 *
	 * @param array $result    The validated search results.
	 * @param array $arguments Original tool arguments.
	 * @param array $context   Execution context.
	 * @return string|WP_Error Record ID on success, WP_Error on failure.
	 */
	private function save_search_to_paper_store( $result, $arguments, $context ) {
		// Gate 1 — Sanitize at entry.
		$collection = isset( $arguments['paper_store_collection'] ) && ! empty( $arguments['paper_store_collection'] )
			? sanitize_key( $arguments['paper_store_collection'] )
			: 'web-search-results';

		$query = isset( $arguments['query'] ) ? sanitize_text_field( $arguments['query'] ) : '';

		// Sanitize tags.
		$tags = array();
		if ( isset( $arguments['paper_store_tags'] ) && is_array( $arguments['paper_store_tags'] ) ) {
			foreach ( $arguments['paper_store_tags'] as $tag ) {
				$tag = sanitize_text_field( $tag );
				if ( ! empty( $tag ) ) {
					$tags[] = $tag;
				}
			}
		}

		// Generate unique record ID.
		$record_id = 'wp_mcp_ai_ws_' . substr( md5( $query . time() . wp_rand() ), 0, 12 );

		// Build record.
		$record = array(
			'id'          => $record_id,
			'type'        => $collection,
			'title'       => ! empty( $query ) ? $query : __( 'Web Search Results', 'mcp-ai-wpoos' ),
			'description' => sprintf(
				/* translators: 1: query, 2: result count, 3: provider */
				__( 'Web search for "%1$s" — %2$d results via %3$s.', 'mcp-ai-wpoos' ),
				$query,
				isset( $result['result_count'] ) ? (int) $result['result_count'] : 0,
				isset( $result['provider'] ) ? $result['provider'] : 'unknown'
			),
			'tags'        => $tags,
			'status'      => 'draft',
			'meta'        => array(
				'query'          => $query,
				'provider'       => isset( $result['provider'] ) ? $result['provider'] : 'unknown',
				'result_count'   => isset( $result['result_count'] ) ? (int) $result['result_count'] : 0,
				'user_id'        => isset( $context['user_id'] ) ? (int) $context['user_id'] : get_current_user_id(),
				'cached'         => isset( $result['cached'] ) ? (bool) $result['cached'] : false,
				'search_options' => array(
					'country'   => isset( $arguments['country'] ) ? sanitize_text_field( $arguments['country'] ) : '',
					'language'  => isset( $arguments['language'] ) ? sanitize_text_field( $arguments['language'] ) : '',
					'freshness' => isset( $arguments['freshness'] ) ? sanitize_text_field( $arguments['freshness'] ) : '',
				),
			),
			'body'        => array(
				'results' => isset( $result['results'] ) ? $result['results'] : array(),
			),
		);

		// Save to Paper Store.
		$manager = WP_MCP_AI_Paper_Store_Manager::get_instance();
		$repo    = $manager->get_repository( $collection );

		$saved = $repo->save( $record );

		if ( is_wp_error( $saved ) ) {
			WP_MCP_AI_Logger::log_error(
				'Failed to save web search results to Paper Store: ' . $saved->get_error_message(),
				array(
					'query'      => $query,
					'collection' => $collection,
					'record_id'  => $record_id,
				)
			);
			return $saved;
		}

		/**
		 * Fires when web search results are saved to the Paper Store.
		 *
		 * @since 1.4.0
		 *
		 * @param string $record_id  The Paper Store record ID.
		 * @param string $collection The Paper Store collection name.
		 * @param array  $result     The search results that were saved.
		 * @param array  $arguments  Original tool arguments.
		 * @param array  $context    Execution context.
		 */
		do_action( 'wp_mcp_ai_web_search_saved_to_paper_store', $record_id, $collection, $result, $arguments, $context );

		return $record_id;
	}

	/**
	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {
		return array(
			'name'                  => $this->get_name(),
			'description'           => $this->get_description(),
			'toolkit'               => 'research_discovery',
			'pattern_compatibility' => array( 'orchestrator', 'peer_to_peer', 'sequential' ),
			'profession_tags'       => array( 'researcher', 'journalist', 'analyst', 'writer', 'librarian' ),
			'risk_level'            => 'info',
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'requires-credentials', // May require API credentials depending on provider.
			'requires-capability',  // Requires user capabilities.
			'read-only',            // Only retrieves data, does not modify state.
			'external-api',         // Makes external HTTP requests.
			'rate-limited',         // Subject to provider rate limits.
			'cacheable',            // Results can be cached for short periods.
			'network-dependent',    // Requires internet connectivity.
			'non-deterministic',    // Results may vary over time.
			// Note: 'may-timeout' and 'async' flags are intentionally NOT included.
			// This tool executes a single synchronous HTTP request with a 10-second timeout.
			// and completes quickly in normal conditions. When external search APIs return
			// HTTP 202 (pending), the error is returned to the caller for handling.
		);
	}

	/**
	 * Generate a unique task ID for web search results.
	 *
	 * This enables tracking and caching of search results for SSE retrieval,
	 * similar to how Crawl4AI jobs are tracked.
	 *
	 * @param string $query    The search query.
	 * @param string $provider Search provider name.
	 * @return string Unique task identifier.
	 */
	protected function generate_task_id( $query, $provider ) {
		// Generate a unique ID with timestamp and query hash for better uniqueness.
		$timestamp = time();
		$hash      = substr( md5( $query . $provider . microtime( true ) ), 0, 8 );

		return 'search-' . $provider . '-' . $timestamp . '-' . $hash;
	}

	/**
	 * Sanitize web search results for LLM consumption.
	 *
	 * Web searches can return large result sets with long URLs and snippets that
	 * consume many tokens. The LLM doesn't need the full dataset - it only needs
	 * enough information to understand what was found and provide a response.
	 *
	 * This method keeps essential metadata (query, result_count, text summary) and
	 * provides a condensed version of results that's sufficient for the LLM while
	 * the chat client receives the full result set.
	 *
	 * Note: The 'text' field is generated here for LLM consumption and is NOT included
	 * in the base tool result to prevent it from being extracted and streamed as
	 * assistant content during SSE streaming (which would break the chat client connection).
	 *
	 * @param mixed $result Tool execution result.
	 * @return mixed Sanitized result with condensed data for LLM.
	 */
	public function sanitize_for_llm( $result ) {
		if ( ! is_array( $result ) ) {
			return $result;
		}

		// Keep only essential fields for the LLM.
		$keep_fields = array(
			'query',                   // The search query (essential context).
			'result_count',            // How many results were found.
			'note',                    // Any notes (e.g., "no results found").
			'provider',                // Which search provider was used.
			'cached',                  // Whether results were cached.
			'paper_store_id',          // Paper Store record ID if saved.
			'paper_store_collection',  // Paper Store collection name if saved.
		);

		$sanitized = array();
		foreach ( $keep_fields as $key ) {
			if ( isset( $result[ $key ] ) ) {
				$sanitized[ $key ] = $result[ $key ];
			}
		}

		// Generate descriptive text for the LLM.
		// This is created here rather than in the base result to prevent.
		// it from being extracted during SSE streaming fallback text extraction.
		$text = $this->generate_result_text( $result );
		if ( '' !== $text ) {
			$sanitized['text'] = $text;
		}

		// Include a condensed version of results (just titles and URLs, no snippets).
		// This gives the LLM enough context to reference specific results if needed.
		// while dramatically reducing token usage.
		if ( ! empty( $result['results'] ) && is_array( $result['results'] ) ) {
			$condensed_results = array();

			// Only include top results for LLM (chat client gets all results).
			$count = 0;

			foreach ( $result['results'] as $item ) {
				if ( $count >= self::MAX_LLM_RESULTS ) {
					break;
				}

				// Include title, URL, and a trimmed snippet so the LLM has enough context
				// to ground its answer without consuming excessive tokens.
				$condensed_results[] = array(
					'title'   => isset( $item['title'] ) ? $item['title'] : '',
					'url'     => isset( $item['url'] ) ? $item['url'] : '',
					'snippet' => isset( $item['snippet'] ) ? wp_trim_words( $item['snippet'], 40, '...' ) : '',
				);

				++$count;
			}

			if ( ! empty( $condensed_results ) ) {
				$sanitized['results'] = $condensed_results;
			}
		}

		return ! empty( $sanitized ) ? $sanitized : $result;
	}

	/**
	 * Generate descriptive text for search results.
	 *
	 * Creates a human-readable summary of the search operation for LLM consumption.
	 * This text is only included in the LLM-sanitized version to prevent it from
	 * being extracted and streamed as assistant content during SSE streaming.
	 *
	 * @param array $result Tool execution result.
	 * @return string Descriptive text about the search results.
	 */
	protected function generate_result_text( array $result ) {
		$query = isset( $result['query'] ) ? $result['query'] : '';

		// Handle empty results case.
		if ( empty( $result['results'] ) || 0 === $result['result_count'] ) {
			return sprintf(
				/* translators: %s: search query */
				__( 'Web search completed for "%s" but no results were found.', 'mcp-ai-wpoos' ),
				$query
			);
		}

		// Build descriptive text for successful search.
		$result_count = isset( $result['result_count'] ) ? absint( $result['result_count'] ) : 0;
		$text_parts   = array();

		$text_parts[] = sprintf(
			/* translators: 1: result count, 2: search query */
			_n(
				'Found %1$d web search result for "%2$s"',
				'Found %1$d web search results for "%2$s"',
				$result_count,
				'mcp-ai-wpoos'
			),
			$result_count,
			$query
		);

		// Add brief summary of top result if available.
		if ( ! empty( $result['results'][0]['title'] ) ) {
			$text_parts[] = sprintf(
				/* translators: %s: title of first search result */
				__( 'Top result: %s', 'mcp-ai-wpoos' ),
				wp_trim_words( $result['results'][0]['title'], 10, '...' )
			);
		}

		return implode( ' ', $text_parts );
	}

	/**
	 * Sanitize a string to ensure it contains only valid UTF-8 characters.
	 *
	 * Search results from external APIs may contain invalid UTF-8 sequences
	 * that can cause wp_json_encode() to fail, corrupting SSE streams and
	 * causing HTTP2 protocol errors. This method removes or replaces invalid
	 * sequences to ensure the string is safe for JSON encoding.
	 *
	 * @param string $input String to sanitize.
	 * @return string Sanitized string with only valid UTF-8 characters.
	 */
	protected function sanitize_utf8( $input ) {
		// Return early for non-strings.
		if ( ! is_string( $input ) ) {
			return $input;
		}

		// Remove invalid UTF-8 sequences from the source string.
		// The iconv IGNORE flag skips any bytes that are not valid in the source encoding (UTF-8),.
		// effectively removing malformed UTF-8 sequences while preserving valid characters.
		$sanitized = iconv( 'UTF-8', 'UTF-8//IGNORE', $input );

		// If iconv failed (returned false), fall back to mb_convert_encoding.
		if ( false === $sanitized && function_exists( 'mb_convert_encoding' ) ) {
			$sanitized = mb_convert_encoding( $input, 'UTF-8', 'UTF-8' );
		}

		// If both methods failed, use preg_replace to remove common problematic control characters.
		// This targets specific control characters (null bytes, form feed, etc.) that often cause issues.
		// Note: Not using 'u' modifier since we're dealing with potentially invalid UTF-8.
		if ( false === $sanitized ) {
			$sanitized = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $input );
		}

		// Final fallback: if still invalid, return empty string.
		if ( false === $sanitized ) {
			return '';
		}

		return $sanitized;
	}

	/**
	 * Validate and normalize search results to ensure consistent structure.
	 *
	 * This method ensures that all search results have the expected structure
	 * and all required fields are present. It also validates that the data can
	 * be JSON-encoded without errors, which is critical for SSE streaming.
	 *
	 * @param array  $result   Raw search result from provider.
	 * @param string $query    Original search query.
	 * @param string $provider Provider name.
	 * @return array Validated and normalized result.
	 */
	protected function validate_and_normalize_result( array $result, $query, $provider ) {
		// Ensure required top-level fields are present.
		$normalized = array(
			'query'        => isset( $result['query'] ) ? $this->sanitize_utf8( $result['query'] ) : $query,
			'provider'     => isset( $result['provider'] ) ? sanitize_key( $result['provider'] ) : $provider,
			'cached'       => isset( $result['cached'] ) ? (bool) $result['cached'] : false,
			'results'      => isset( $result['results'] ) && is_array( $result['results'] ) ? $result['results'] : array(),
			'result_count' => isset( $result['result_count'] ) ? absint( $result['result_count'] ) : 0,
		);

		// Preserve task_id if present (critical for SSE tracking).
		if ( isset( $result['task_id'] ) ) {
			$normalized['task_id'] = sanitize_text_field( $result['task_id'] );
		}

		// Add optional fields if present.
		if ( isset( $result['note'] ) ) {
			$normalized['note'] = $this->sanitize_utf8( $result['note'] );
		}

		// Preserve Perplexity's synthesized answer and citations when present.
		// These are the primary value of the Sonar API and must survive
		// normalization for chat clients to render them.
		if ( isset( $result['answer'] ) ) {
			$normalized['answer'] = $this->sanitize_utf8( $result['answer'] );
		}

		if ( isset( $result['citations'] ) && is_array( $result['citations'] ) ) {
			$citations = array();
			foreach ( $result['citations'] as $citation ) {
				$citation = is_string( $citation ) ? esc_url_raw( $citation ) : '';
				if ( '' !== $citation ) {
					$citations[] = $citation;
				}
			}
			$normalized['citations'] = $citations;
		}

		if ( isset( $result['system_message'] ) ) {
			$normalized['system_message'] = $this->sanitize_utf8( $result['system_message'] );
		}

		if ( isset( $result['timestamp'] ) ) {
			$normalized['timestamp'] = absint( $result['timestamp'] );
		}

		// Validate each result item to ensure it can be JSON-encoded.
		$validated_results = array();
		foreach ( $normalized['results'] as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			// Ensure each result has required fields with safe values.
			$validated_item = array(
				'title'   => isset( $item['title'] ) ? $this->sanitize_utf8( $item['title'] ) : '',
				'url'     => isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '',
				'snippet' => isset( $item['snippet'] ) ? $this->sanitize_utf8( $item['snippet'] ) : '',
				'source'  => isset( $item['source'] ) ? sanitize_key( $item['source'] ) : $provider,
				'type'    => isset( $item['type'] ) ? sanitize_key( $item['type'] ) : 'result',
			);

			// Skip items with no title and no URL (invalid results).
			if ( '' === $validated_item['title'] && '' === $validated_item['url'] ) {
				continue;
			}

			// Verify this item can be JSON-encoded before including it.
			$test_encode = wp_json_encode( $validated_item );
			if ( false !== $test_encode ) {
				$validated_results[] = $validated_item;
			} elseif ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				// Log the problematic item for debugging.
				WP_MCP_AI_Logger::log_error(
					'web_search_result_json_encode_failed',
					'Failed to JSON encode search result item',
					array(
						'query'      => $query,
						'provider'   => $provider,
						'json_error' => function_exists( 'json_last_error_msg' ) ? json_last_error_msg() : 'Unknown',
					)
				);
			}
		}

		$normalized['results']      = $validated_results;
		$normalized['result_count'] = count( $validated_results );

		// Update system_message field if result count changed due to validation.
		if ( isset( $normalized['system_message'] ) && count( $validated_results ) !== count( $result['results'] ) ) {
			$normalized['system_message'] = sprintf(
				/* translators: 1: result count, 2: search query */
				_n(
					'Found %1$d web search result for "%2$s"',
					'Found %1$d web search results for "%2$s"',
					count( $validated_results ),
					'mcp-ai-wpoos'
				),
				count( $validated_results ),
				$query
			);

			if ( ! empty( $validated_results[0]['title'] ) ) {
				$normalized['system_message'] .= ' ' . sprintf(
					/* translators: %s: title of first search result */
					__( 'Top result: %s', 'mcp-ai-wpoos' ),
					wp_trim_words( $validated_results[0]['title'], 10, '...' )
				);
			}
		}

		// Final validation: ensure the entire result can be JSON-encoded.
		$final_encode = wp_json_encode( $normalized );
		if ( false === $final_encode ) {
			// If even the normalized result fails encoding, return a safe minimal result.
			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_error(
					'web_search_complete_result_json_encode_failed',
					'Failed to JSON encode complete search result',
					array(
						'query'      => $query,
						'provider'   => $provider,
						'json_error' => function_exists( 'json_last_error_msg' ) ? json_last_error_msg() : 'Unknown',
					)
				);
			}

			// Return minimal safe result.
			return array(
				'query'          => $query,
				'provider'       => $provider,
				'cached'         => false,
				'results'        => array(),
				'result_count'   => 0,
				'note'           => __( 'Search completed but results could not be properly encoded for transmission.', 'mcp-ai-wpoos' ),
				'system_message' => sprintf(
					/* translators: %s: search query */
					__( 'Web search for "%s" completed but encountered data encoding issues.', 'mcp-ai-wpoos' ),
					$query
				),
			);
		}

		return $normalized;
	}

	/**
	 * Optionally rerank search results using a relevance reranking API (Jina or Cohere).
	 *
	 * Only active when the NV oOS LibreChat addon is enabled and the reranking
	 * feature toggle is on. Falls back silently to the original order if the
	 * reranker is unavailable, misconfigured, or returns an error.
	 *
	 * @since 1.1.29
	 *
	 * @param array  $result Search result array with 'results' key.
	 * @param string $query  Original search query.
	 * @return array Possibly reranked result (original order preserved on failure).
	 */
	protected function maybe_rerank_results( array $result, $query ) {
		// Guard: reranking requires the LibreChat addon.
		$settings = get_option( 'nvoos_librechat_settings', array() );
		if ( empty( $settings['enable_web_search'] ) || empty( $settings['rerank_provider'] ) ) {
			return $result;
		}

		$results = isset( $result['results'] ) ? $result['results'] : array();
		if ( count( $results ) < 2 ) {
			return $result; // Nothing to rerank.
		}

		$provider = sanitize_key( $settings['rerank_provider'] );

		// Build documents list: combine title + snippet for relevance scoring.
		$documents = array();
		foreach ( $results as $item ) {
			$text        = isset( $item['title'] ) ? $item['title'] : '';
			$text       .= isset( $item['snippet'] ) ? ' ' . $item['snippet'] : '';
			$documents[] = trim( $text );
		}

		if ( 'cohere' === $provider ) {
			$reranked_indices = $this->perform_rerank_cohere( $query, $documents );
		} else {
			$reranked_indices = $this->perform_rerank_jina( $query, $documents );
		}

		// If reranking failed or returned empty, keep original order.
		if ( empty( $reranked_indices ) || count( $reranked_indices ) !== count( $results ) ) {
			return $result;
		}

		// Reorder results by relevance.
		$reranked = array();
		foreach ( $reranked_indices as $index ) {
			if ( isset( $results[ $index ] ) ) {
				$reranked[] = $results[ $index ];
			}
		}

		$result['results']  = $reranked;
		$result['reranked'] = true;

		return $result;
	}

	/**
	 * Rerank results using the Jina AI Reranker API.
	 *
	 * API reference: https://jina.ai/reranker/
	 *
	 * @param string $query     Search query.
	 * @param array  $documents Array of document texts to score.
	 * @return array Array of indices sorted by descending relevance, or empty on failure.
	 */
	protected function perform_rerank_jina( $query, array $documents ) {
		$response = wp_remote_post(
			'https://api.jina.ai/v1/rerank',
			array(
				'timeout' => 5,
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'model'     => 'jina-reranker-v2-base-multilingual',
						'query'     => $query,
						'documents' => $documents,
						'top_n'     => count( $documents ),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array();
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status_code ) {
			return array();
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) || ! isset( $data['results'] ) || ! is_array( $data['results'] ) ) {
			return array();
		}

		$indices = array();
		foreach ( $data['results'] as $item ) {
			if ( isset( $item['index'] ) ) {
				$indices[] = absint( $item['index'] );
			}
		}

		return $indices;
	}

	/**
	 * Rerank results using the Cohere Rerank API.
	 *
	 * API reference: https://docs.cohere.com/reference/rerank
	 *
	 * @param string $query     Search query.
	 * @param array  $documents Array of document texts to score.
	 * @return array Array of indices sorted by descending relevance, or empty on failure.
	 */
	protected function perform_rerank_cohere( $query, array $documents ) {
		// Cohere requires an API key. Use the NV oOS core API key slot or a dedicated filter.
		$api_key = '';

		if ( class_exists( 'WP_MCP_AI_Admin_Settings' ) ) {
			$core_settings = WP_MCP_AI_Admin_Settings::get_settings();
			$api_key       = isset( $core_settings['openai_api_key'] ) ? trim( $core_settings['openai_api_key'] ) : '';
		}

		/**
		 * Filter the Cohere API key for reranking.
		 *
		 * @param string $api_key Cohere API key.
		 */
		$api_key = apply_filters( 'wp_mcp_ai_cohere_rerank_api_key', $api_key );

		if ( empty( $api_key ) ) {
			return array();
		}

		$response = wp_remote_post(
			'https://api.cohere.ai/v1/rerank',
			array(
				'timeout' => 5,
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'model'            => 'rerank-english-v3.0',
						'query'            => $query,
						'documents'        => $documents,
						'top_n'            => count( $documents ),
						'return_documents' => false,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array();
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status_code ) {
			return array();
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) || ! isset( $data['results'] ) || ! is_array( $data['results'] ) ) {
			return array();
		}

		$indices = array();
		foreach ( $data['results'] as $item ) {
			if ( isset( $item['index'] ) ) {
				$indices[] = absint( $item['index'] );
			}
		}

		return $indices;
	}
}
