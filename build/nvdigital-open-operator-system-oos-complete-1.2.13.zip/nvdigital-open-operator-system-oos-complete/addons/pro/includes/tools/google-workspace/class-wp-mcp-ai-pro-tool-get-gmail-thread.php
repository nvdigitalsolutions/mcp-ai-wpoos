<?php
/**
 * Tool that reads a full Gmail thread by thread ID.
 *
 * Returns every message in the thread, newest first, with per-message plain
 * text (or sanitised HTML) bodies. Solves digest-style reads — e.g. an invoice
 * thread or a PR/CI notification chain — in a single call.
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-envelope.php';
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-admin-settings.php';
require_once __DIR__ . '/class-wp-mcp-ai-pro-gmail-client.php';

/**
 * Provides an assistant tool for reading a full Gmail thread.
 */
class WP_MCP_AI_Pro_Tool_Get_Gmail_Thread implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	use WP_MCP_AI_Tool_Envelope;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'get_gmail_thread';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Get Gmail Thread', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Reads a full Gmail thread by thread ID and returns all messages newest-first with plain text (default) or sanitised HTML bodies, up to max_messages. Each message also carries extracted attachment text (PDF, CSV, text) when attachments exist. Use thread IDs from search_gmail results. Bodies longer than max_chars are truncated at a word boundary with the truncated flag set.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Reading an entire Gmail conversation by thread ID, newest first, to absorb invoice, support, or notification chains in one call.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Reading a single message; use get_gmail_message. Finding threads; use search_gmail. Label or read-state changes; use modify_gmail_message.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'search_gmail', 'get_gmail_message', 'modify_gmail_message' ),
			'notes'           => __( 'Returns up to max_messages (1-50, default 10) with each body capped at max_chars; message_count vs returned_count shows truncation. Per message, body_source shows which part supplied the text and an empty body carries body_empty_reason (e.g. no_text_parts for attachment-only emails). Each message also carries attachments with extracted text where possible (PDFs, CSVs, text files).', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'thread_id'           => array(
					'type'        => 'string',
					'description' => __( 'Gmail thread ID to read. Obtain thread IDs from search_gmail results.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'connection_id'       => array(
					'type'        => 'string',
					'description' => __( 'Optional Gmail connection ID from Remote Sites. If not provided, uses settings-based credentials; when those are not configured, the only enabled Remote Sites Gmail connection is used automatically (if several are enabled, pass one explicitly). Call list_gmail_connections to discover IDs.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'max_messages'        => array(
					'type'        => 'integer',
					'description' => __( 'Maximum number of messages to return from the thread (1-50).', 'nvdigital-open-operator-system-oos-pro' ),
					'minimum'     => 1,
					'maximum'     => 50,
					'default'     => 10,
				),
				'max_chars'           => array(
					'type'        => 'integer',
					'description' => __( 'Maximum body characters per message (100-50000). Longer bodies are truncated at a word boundary and flagged with truncated=true.', 'nvdigital-open-operator-system-oos-pro' ),
					'minimum'     => 100,
					'maximum'     => 50000,
					'default'     => 4000,
				),
				'format'              => array(
					'type'        => 'string',
					'description' => __( 'Body format: "plain" strips all tags (default), "html" returns sanitised HTML with scripts, styles, and images removed.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'plain', 'html' ),
					'default'     => 'plain',
				),
				'include_attachments' => array(
					'type'        => 'boolean',
					'description' => __( 'When true, includes attachment filenames per message. Default true.', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => true,
				),
			),
			'required'             => array( 'thread_id' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'manage_options';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		$required_capability = apply_filters( 'wp_mcp_ai_get_gmail_thread_capability', 'manage_options', $context, $arguments, $this );

		if ( $required_capability && ( ! $user_id || ! user_can( $user_id, $required_capability ) ) ) { // phpcs:ignore WordPress.WP.Capabilities.Undetermined -- Capability resolved via the wp_mcp_ai_get_gmail_thread_capability filter (default manage_options).
			return new WP_Error( 'wp_mcp_ai_gmail_forbidden', __( 'You do not have permission to read Gmail threads.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		if ( is_multisite() && $user_id && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_gmail_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		// Gate 1 — sanitise at entry.
		$thread_id           = isset( $arguments['thread_id'] ) ? sanitize_text_field( $arguments['thread_id'] ) : '';
		$connection_id       = isset( $arguments['connection_id'] ) ? sanitize_key( $arguments['connection_id'] ) : '';
		$max_messages        = isset( $arguments['max_messages'] ) ? absint( $arguments['max_messages'] ) : 10;
		$max_chars           = isset( $arguments['max_chars'] ) ? absint( $arguments['max_chars'] ) : 4000;
		$format              = isset( $arguments['format'] ) ? sanitize_key( $arguments['format'] ) : 'plain';
		$include_attachments = array_key_exists( 'include_attachments', $arguments ) ? (bool) $arguments['include_attachments'] : true;

		if ( '' === $thread_id ) {
			return new WP_Error( 'wp_mcp_ai_gmail_missing_thread_id', __( 'A Gmail thread ID is required. Obtain thread IDs from search_gmail results.', 'nvdigital-open-operator-system-oos-pro' ) );
		}
		if ( $max_messages < 1 ) {
			$max_messages = 1;
		}
		if ( $max_messages > 50 ) {
			$max_messages = 50;
		}
		if ( $max_chars < 100 ) {
			$max_chars = 100;
		}
		if ( $max_chars > 50000 ) {
			$max_chars = 50000;
		}
		if ( 'html' !== $format ) {
			$format = 'plain';
		}

		$credentials = WP_MCP_AI_Pro_Gmail_Client::resolve_credentials( $connection_id, $context );
		if ( is_wp_error( $credentials ) ) {
			return $credentials;
		}

		$resolved_id   = isset( $credentials['connection_id'] ) ? (string) $credentials['connection_id'] : '';
		$resolved_name = isset( $credentials['connection_name'] ) ? (string) $credentials['connection_name'] : '';

		$timeout = WP_MCP_AI_Pro_Gmail_Client::get_request_timeout();

		$access_token = WP_MCP_AI_Pro_Gmail_Client::request_access_token(
			$credentials['client_id'],
			$credentials['client_secret'],
			$credentials['refresh_token'],
			$timeout
		);
		if ( is_wp_error( $access_token ) ) {
			return $access_token;
		}

		$gmail_user = '' !== $credentials['configured_user'] ? $credentials['configured_user'] : 'me';

		$payload = WP_MCP_AI_Pro_Gmail_Client::request(
			'GET',
			$gmail_user,
			'threads/' . rawurlencode( $thread_id ),
			$access_token,
			$timeout,
			array( 'format' => 'full' )
		);
		if ( is_wp_error( $payload ) ) {
			return $payload;
		}

		$raw_messages = isset( $payload['messages'] ) && is_array( $payload['messages'] ) ? $payload['messages'] : array();

		// The Gmail API does not guarantee thread message ordering — sort newest first.
		usort(
			$raw_messages,
			static function ( $a, $b ) {
				$ta = WP_MCP_AI_Pro_Gmail_Client::get_timestamp( $a );
				$tb = WP_MCP_AI_Pro_Gmail_Client::get_timestamp( $b );
				$ta = null === $ta ? 0 : $ta;
				$tb = null === $tb ? 0 : $tb;

				return $tb <=> $ta;
			}
		);

		$messages           = array();
		$hydration_warnings = array();
		foreach ( array_slice( $raw_messages, 0, $max_messages ) as $message_payload ) {
			$current_message_id = ! empty( $message_payload['id'] ) ? (string) $message_payload['id'] : '';

			// Recover oversized inline text parts stored as attachmentId.
			if ( '' !== $current_message_id ) {
				$warnings = WP_MCP_AI_Pro_Gmail_Client::hydrate_inline_attachments(
					$message_payload,
					$gmail_user,
					$current_message_id,
					$access_token,
					$timeout
				);
				foreach ( $warnings as $warning ) {
					$hydration_warnings[] = $current_message_id . ': ' . $warning->get_error_message();
				}
			}

			$message = WP_MCP_AI_Pro_Gmail_Client::normalize_message(
				$message_payload,
				$format,
				$max_chars,
				false,
				$include_attachments,
				''
			);

			// Surface extracted text for attached PDFs and other text-bearing files.
			if ( '' !== $current_message_id ) {
				$message['attachments'] = WP_MCP_AI_Pro_Gmail_Client::get_attachments_with_text(
					$message_payload,
					$gmail_user,
					$current_message_id,
					$access_token,
					$timeout,
					$max_chars
				);
			}

			$messages[] = $message;
		}

		$data = array(
			'thread_id'       => isset( $payload['id'] ) ? (string) $payload['id'] : $thread_id,
			'history_id'      => isset( $payload['historyId'] ) ? (string) $payload['historyId'] : '',
			'message_count'   => count( $raw_messages ),
			'returned_count'  => count( $messages ),
			'messages'        => $messages,
			'connection_id'   => $resolved_id,
			'connection_name' => $resolved_name,
		);

		if ( ! empty( $hydration_warnings ) ) {
			$data['body_hydration_warnings'] = $hydration_warnings;
		}

		return $this->format_success_response(
			__( 'Gmail thread retrieved.', 'nvdigital-open-operator-system-oos-pro' ),
			array( 'data' => $data )
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro tier tool.
			'read-only',            // Only reads data, does not modify state.
			'external-api',         // Calls the Gmail API.
			'network-dependent',    // Requires internet connectivity.
			'requires-capability',  // Requires user capabilities.
			'pii-data',             // Thread bodies contain personal data.
		);
	}
}
