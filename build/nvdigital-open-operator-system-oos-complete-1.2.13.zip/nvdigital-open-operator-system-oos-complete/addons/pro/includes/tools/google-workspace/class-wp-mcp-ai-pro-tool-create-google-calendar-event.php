<?php
/**
 * Tool for creating Google Calendar events.
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';

/**
 * Provides an assistant tool that creates events in Google Calendar.
 */
class WP_MCP_AI_Pro_Tool_Create_Google_Calendar_Event implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface, WP_MCP_AI_Tool_Data_Contract_Interface {
	const DEFAULT_REQUIRED_CAPABILITY = 'manage_options';
	const TOKEN_GRANT_TYPE            = 'urn:ietf:params:oauth:grant-type:jwt-bearer';
	const DEFAULT_SCOPE               = 'https://www.googleapis.com/auth/calendar.events';
	const DEFAULT_TOKEN_URI           = 'https://oauth2.googleapis.com/token';

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'create_google_calendar_event';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Create Google Calendar Event', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Creates an event in a connected Google Calendar using either a provided access token or a service account.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Creating a new Google Calendar event with exact start and end times, attendees, reminders, or a Google Meet link.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Creating events from plain language; use quick_add_google_calendar_event. Changing existing events; use update_google_calendar_event.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'check_google_calendar_availability', 'quick_add_google_calendar_event', 'update_google_calendar_event' ),
			'notes'           => __( 'Pass duration_minutes when end_time is omitted. create_meet_link is generated asynchronously and may be missing from the immediate response.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'connection_id'    => array(
					'type'        => 'string',
					'description' => __( 'Optional Google Calendar connection ID from Remote Sites. If not provided, uses settings-based credentials; when those are not configured, the only enabled Remote Sites Google Calendar connection is used automatically (if several are enabled, pass one explicitly).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'summary'          => array(
					'type'        => 'string',
					'description' => __( 'Event title that will appear on the calendar.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'description'      => array(
					'type'        => 'string',
					'description' => __( 'Optional long-form description for the event.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'location'         => array(
					'type'        => 'string',
					'description' => __( 'Optional location for the event.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'start_time'       => array(
					'type'        => 'string',
					'description' => __( 'Event start time in ISO 8601 format or YYYY-MM-DD for all-day events.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'end_time'         => array(
					'type'        => 'string',
					'description' => __( 'Event end time in ISO 8601 format or YYYY-MM-DD for all-day events.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'duration_minutes' => array(
					'type'        => array( 'number', 'integer' ),
					'minimum'     => 1,
					'description' => __( 'Duration in minutes to use when end_time is omitted.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'timezone'         => array(
					'type'        => 'string',
					'description' => __( 'Optional IANA timezone identifier applied to the start and end time.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'calendar_id'      => array(
					'type'        => 'string',
					'description' => __( 'Override the calendar identifier. Falls back to the configured default.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'attendees'        => array(
					'type'        => 'array',
					'description' => __( 'Optional attendee list. Provide email strings or objects with email, name, and optional status.', 'nvdigital-open-operator-system-oos-pro' ),
					'items'       => array(
						'anyOf' => array(
							array(
								'type' => 'string',
							),
							array(
								'type'                 => 'object',
								'properties'           => array(
									'email'    => array( 'type' => 'string' ),
									'name'     => array( 'type' => 'string' ),
									'optional' => array( 'type' => 'boolean' ),
								),
								'required'             => array( 'email' ),
								'additionalProperties' => true,
							),
						),
					),
				),
				'send_updates'     => array(
					'type'        => 'string',
					'enum'        => array( 'all', 'externalOnly', 'none' ),
					'description' => __( 'Controls whether attendees receive update emails (all, externalOnly, or none).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'reminders'        => array(
					'type'                 => 'object',
					'description'          => __( 'Optional reminder overrides. Supports use_default and overrides array with method and minutes.', 'nvdigital-open-operator-system-oos-pro' ),
					'properties'           => array(
						'use_default' => array(
							'type'        => 'boolean',
							'description' => __( 'Whether to use the calendar\'s default reminder settings.', 'nvdigital-open-operator-system-oos-pro' ),
						),
						'overrides'   => array(
							'type'        => 'array',
							'description' => __( 'Custom reminder definitions.', 'nvdigital-open-operator-system-oos-pro' ),
							'items'       => array(
								'type'                 => 'object',
								'properties'           => array(
									'method'  => array(
										'type' => 'string',
										'enum' => array( 'email', 'popup' ),
									),
									'minutes' => array(
										'type'    => array( 'number', 'integer' ),
										'minimum' => 0,
									),
								),
								'required'             => array( 'method', 'minutes' ),
								'additionalProperties' => false,
							),
						),
					),
					'additionalProperties' => false,
				),
				'create_meet_link' => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to attach a Google Meet conference to the event. The link is generated asynchronously by Google, so it may not be present in the immediate response.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),
			'required'             => array( 'summary', 'start_time' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_data_contract() {
		return array(
			'produces' => 'event_id',
			'consumes' => null,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		$required_capability = apply_filters(
			'wp_mcp_ai_google_calendar_required_capability',
			self::DEFAULT_REQUIRED_CAPABILITY,
			$context,
			$arguments,
			$this
		);

		if ( $required_capability && ( ! $user_id || ! user_can( $user_id, $required_capability ) ) ) { // phpcs:ignore WordPress.WP.Capabilities.Undetermined -- Capability resolved via the wp_mcp_ai_google_calendar_required_capability filter (default manage_options).
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to create calendar events.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 403 ) );
		}

		if ( is_multisite() && $user_id && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 403 ) );
		}

		$summary = isset( $arguments['summary'] ) ? sanitize_text_field( $arguments['summary'] ) : '';
		if ( '' === $summary ) {
			return new WP_Error( 'wp_mcp_ai_missing_summary', __( 'An event summary is required.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
		}

		$description = isset( $arguments['description'] ) ? trim( wp_kses_post( $arguments['description'] ) ) : '';
		$location    = isset( $arguments['location'] ) ? sanitize_text_field( $arguments['location'] ) : '';
		$timezone    = isset( $arguments['timezone'] ) ? sanitize_text_field( $arguments['timezone'] ) : '';

		$calendar_id = isset( $arguments['calendar_id'] ) ? sanitize_text_field( $arguments['calendar_id'] ) : '';

		// Resolve credentials before falling back to the legacy calendar-ID filter,
		// so a configured connection can supply the default calendar.
		require_once WP_MCP_AI_PATH . 'includes/google/class-wp-mcp-ai-google-calendar-credentials.php';

		$connection_id = isset( $arguments['connection_id'] ) ? sanitize_key( $arguments['connection_id'] ) : '';
		$credentials   = WP_MCP_AI_Google_Calendar_Credentials::resolve( $connection_id, $context, $arguments );

		if ( is_wp_error( $credentials ) ) {
			return $credentials;
		}

		// Writing events requires the events scope. Google's granular consent lets
		// users approve a subset, so this must be checked rather than assumed.
		$scope_check = WP_MCP_AI_Google_Calendar_Credentials::require_scope(
			$credentials,
			WP_MCP_AI_Google_Calendar_Scopes::SCOPE_EVENTS
		);

		if ( is_wp_error( $scope_check ) ) {
			return $scope_check;
		}

		$calendar_id = WP_MCP_AI_Google_Calendar_Credentials::resolve_calendar_id( $credentials, $calendar_id );

		if ( '' === $calendar_id ) {
			return new WP_Error( 'wp_mcp_ai_missing_calendar', __( 'A target Google Calendar identifier is required.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
		}

		// Fall back to the site/connection time zone so recurring expansion and DST
		// handling are deterministic.
		if ( '' === $timezone && ! empty( $credentials['timezone'] ) ) {
			$timezone = (string) $credentials['timezone'];
		}

		if ( empty( $arguments['start_time'] ) || ! is_string( $arguments['start_time'] ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_start_time', __( 'A valid start time must be provided.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
		}

		$start = $this->parse_event_time( $arguments['start_time'], $timezone, 'start_time' );
		if ( is_wp_error( $start ) ) {
			return $start;
		}

		$end = null;
		if ( ! empty( $arguments['end_time'] ) ) {
			if ( ! is_string( $arguments['end_time'] ) ) {
				return new WP_Error( 'wp_mcp_ai_invalid_end_time', __( 'The event end time must be a string value.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
			}

			$end = $this->parse_event_time( $arguments['end_time'], $timezone, 'end_time' );
			if ( is_wp_error( $end ) ) {
				return $end;
			}
		}

		$duration_minutes = 0;
		if ( isset( $arguments['duration_minutes'] ) && '' !== $arguments['duration_minutes'] ) {
			if ( ! is_numeric( $arguments['duration_minutes'] ) ) {
				return new WP_Error( 'wp_mcp_ai_invalid_duration', __( 'The duration must be a numeric value.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
			}

			$duration_minutes = (float) $arguments['duration_minutes'];
			if ( $duration_minutes <= 0 ) {
				return new WP_Error( 'wp_mcp_ai_invalid_duration', __( 'The duration must be greater than zero.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
			}
		}

		if ( null === $end ) {
			if ( $duration_minutes <= 0 ) {
				return new WP_Error( 'wp_mcp_ai_missing_end_time', __( 'Provide an end time or duration for the event.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
			}

			if ( 'dateTime' !== $start['type'] || ! isset( $start['datetime'] ) ) {
				return new WP_Error( 'wp_mcp_ai_duration_requires_time', __( 'Durations may only be used with date/time events.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
			}

			$end_datetime = clone $start['datetime'];
			$end_datetime->modify( '+' . $duration_minutes . ' minutes' );

			$end_value = array( 'dateTime' => $end_datetime->format( DATE_RFC3339 ) );
			if ( $timezone ) {
				$end_value['timeZone'] = $timezone;
			}

			$end = array(
				'type'     => 'dateTime',
				'value'    => $end_value,
				'datetime' => $end_datetime,
			);
		}

		$validation = $this->validate_time_range( $start, $end );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$attendees = array();
		if ( ! empty( $arguments['attendees'] ) ) {
			$attendees = $this->normalise_attendees( $arguments['attendees'] );
		}

		$reminders = array();
		if ( ! empty( $arguments['reminders'] ) ) {
			$reminders = $this->normalise_reminders( $arguments['reminders'] );
		}

		$send_updates = '';
		if ( ! empty( $arguments['send_updates'] ) ) {
			$candidate = sanitize_text_field( $arguments['send_updates'] );
			if ( in_array( $candidate, array( 'all', 'externalOnly', 'none' ), true ) ) {
				$send_updates = $candidate;
			}
		}

		$payload = array(
			'summary' => $summary,
			'start'   => $start['value'],
			'end'     => $end['value'],
		);

		if ( '' !== $description ) {
			$payload['description'] = $description;
		}

		if ( '' !== $location ) {
			$payload['location'] = $location;
		}

		if ( ! empty( $attendees ) ) {
			$payload['attendees'] = $attendees;
		}

		if ( ! empty( $reminders ) ) {
			$payload['reminders'] = $reminders;
		}

		$timeout = (int) apply_filters( 'wp_mcp_ai_google_calendar_request_timeout', 15, $context, $arguments, $this );
		if ( $timeout <= 0 ) {
			$timeout = 15;
		}

		$query = array();

		if ( '' !== $send_updates ) {
			$query['sendUpdates'] = $send_updates;
		}

		// Google Meet: conferenceDataVersion=1 is mandatory on every request that
		// carries conference data, and requestId acts as an idempotency key -
		// reusing it makes Google ignore the request, so it is derived
		// deterministically from the event payload rather than randomised.
		if ( ! empty( $arguments['create_meet_link'] ) ) {
			$query['conferenceDataVersion'] = 1;

			$payload['conferenceData'] = array(
				'createRequest' => array(
					'requestId'             => substr(
						hash( 'sha256', wp_json_encode( array( $calendar_id, $summary, $payload['start'], $payload['end'] ) ) ),
						0,
						32
					),
					'conferenceSolutionKey' => array( 'type' => 'hangoutsMeet' ),
				),
			);
		}

		$client = WP_MCP_AI_Google_Calendar_Credentials::make_client(
			$credentials,
			array( 'timeout' => $timeout )
		);

		if ( is_wp_error( $client ) ) {
			return $client;
		}

		$decoded = $client->insert_event( $calendar_id, $payload, $query );

		if ( is_wp_error( $decoded ) ) {
			return $decoded;
		}

		$meet_link = '';

		if ( ! empty( $decoded['conferenceData']['entryPoints'] ) && is_array( $decoded['conferenceData']['entryPoints'] ) ) {
			foreach ( $decoded['conferenceData']['entryPoints'] as $entry_point ) {
				if ( isset( $entry_point['entryPointType'], $entry_point['uri'] ) && 'video' === $entry_point['entryPointType'] ) {
					$meet_link = (string) $entry_point['uri'];
					break;
				}
			}
		}

		if ( '' === $meet_link && ! empty( $decoded['hangoutLink'] ) ) {
			$meet_link = (string) $decoded['hangoutLink'];
		}

		// Conference data is generated asynchronously; surface the pending state so
		// callers know to re-read the event rather than assuming no link exists.
		$conference_status = isset( $decoded['conferenceData']['createRequest']['status']['statusCode'] )
			? (string) $decoded['conferenceData']['createRequest']['status']['statusCode']
			: '';

		return array(
			'success'           => true,
			'event_id'          => isset( $decoded['id'] ) ? (string) $decoded['id'] : '',
			'calendar_id'       => $calendar_id,
			'html_link'         => isset( $decoded['htmlLink'] ) ? (string) $decoded['htmlLink'] : '',
			'status'            => isset( $decoded['status'] ) ? (string) $decoded['status'] : '',
			'summary'           => isset( $decoded['summary'] ) ? (string) $decoded['summary'] : $summary,
			'start'             => isset( $decoded['start'] ) ? $decoded['start'] : $payload['start'],
			'end'               => isset( $decoded['end'] ) ? $decoded['end'] : $payload['end'],
			'attendee_count'    => isset( $decoded['attendees'] ) && is_array( $decoded['attendees'] ) ? count( $decoded['attendees'] ) : 0,
			'meet_link'         => $meet_link,
			'conference_status' => $conference_status,
			'credential_source' => isset( $credentials['source'] ) ? (string) $credentials['source'] : '',
			'connection_id'     => isset( $credentials['connection_id'] ) ? (string) $credentials['connection_id'] : '',
			'connection_name'   => isset( $credentials['connection_name'] ) ? (string) $credentials['connection_name'] : '',
		);
	}

	/**
	 * Resolve a Google API access token either from filters or a service account exchange.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Request context.
	 * @return string|WP_Error
	 */
	protected function resolve_access_token( array $arguments, array $context ) {
		$token = apply_filters( 'wp_mcp_ai_google_calendar_access_token', '', $context, $arguments, $this );
		if ( is_string( $token ) ) {
			$token = trim( $token );
		}

		if ( ! empty( $token ) ) {
			return $token;
		}

		$credentials = apply_filters( 'wp_mcp_ai_google_calendar_service_account_credentials', array(), $context, $arguments, $this );
		if ( empty( $credentials ) || ! is_array( $credentials ) ) {
			return new WP_Error( 'wp_mcp_ai_calendar_missing_credentials', __( 'Google Calendar credentials were not provided.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 500 ) );
		}

		return $this->exchange_service_account_token( $credentials, $arguments, $context );
	}

	/**
	 * Exchange a service account credential for an access token.
	 *
	 * @param array $credentials Service account configuration.
	 * @param array $arguments   Tool arguments.
	 * @param array $context     Request context.
	 * @return string|WP_Error
	 */
	protected function exchange_service_account_token( array $credentials, array $arguments, array $context ) {
		$client_email = isset( $credentials['client_email'] ) ? sanitize_email( $credentials['client_email'] ) : '';
		$private_key  = isset( $credentials['private_key'] ) ? trim( (string) $credentials['private_key'] ) : '';
		$token_uri    = isset( $credentials['token_uri'] ) ? esc_url_raw( $credentials['token_uri'] ) : '';
		$delegated    = isset( $credentials['delegated_email'] ) ? sanitize_email( $credentials['delegated_email'] ) : '';

		if ( '' === $client_email || '' === $private_key ) {
			return new WP_Error( 'wp_mcp_ai_calendar_invalid_credentials', __( 'Incomplete Google service account credentials.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 500 ) );
		}

		if ( '' === $token_uri ) {
			$token_uri = self::DEFAULT_TOKEN_URI;
		}

		$scopes = isset( $credentials['scopes'] ) ? $credentials['scopes'] : self::DEFAULT_SCOPE;
		if ( is_array( $scopes ) ) {
			$scopes = implode( ' ', array_filter( array_map( 'trim', $scopes ) ) );
		} else {
			$scopes = trim( (string) $scopes );
		}

		if ( '' === $scopes ) {
			$scopes = self::DEFAULT_SCOPE;
		}

		$now    = time();
		$claims = array(
			'iss'   => $client_email,
			'scope' => $scopes,
			'aud'   => $token_uri,
			'iat'   => $now,
			'exp'   => $now + 3600,
		);

		if ( '' !== $delegated ) {
			$claims['sub'] = $delegated;
		}

		$assertion = $this->build_jwt_assertion( $claims, $private_key );
		if ( is_wp_error( $assertion ) ) {
			return $assertion;
		}

		$timeout = (int) apply_filters( 'wp_mcp_ai_google_calendar_request_timeout', 15, $context, $arguments, $this );
		if ( $timeout <= 0 ) {
			$timeout = 15;
		}

		$response = wp_remote_post(
			$token_uri,
			array(
				'headers' => array(
					'Content-Type' => 'application/x-www-form-urlencoded',
				),
				'timeout' => $timeout,
				'body'    => array(
					'grant_type' => self::TOKEN_GRANT_TYPE,
					'assertion'  => $assertion,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'wp_mcp_ai_calendar_token_error',
				__( 'Unable to obtain a Google access token.', 'nvdigital-open-operator-system-oos-pro' ),
				array(
					'status' => 500,
					'error'  => $response,
				)
			);
		}

		$status = wp_remote_retrieve_response_code( $response );
		$body   = wp_remote_retrieve_body( $response );
		$data   = json_decode( $body, true );

		if ( $status < 200 || $status >= 300 || ! isset( $data['access_token'] ) ) {
			$message = __( 'Google rejected the service account token request.', 'nvdigital-open-operator-system-oos-pro' );
			if ( isset( $data['error_description'] ) ) {
				$message = sprintf( '%s %s', $message, $data['error_description'] );
			}

			return new WP_Error(
				'wp_mcp_ai_calendar_token_error',
				$message,
				array(
					'status'   => $status,
					'response' => $data,
				)
			);
		}

		return (string) $data['access_token'];
	}

	/**
	 * Build a signed JWT assertion using the provided claims and private key.
	 *
	 * @param array  $claims      Assertion claims.
	 * @param string $private_key RSA private key.
	 * @return string|WP_Error
	 */
	protected function build_jwt_assertion( array $claims, $private_key ) {
		$header = array(
			'alg' => 'RS256',
			'typ' => 'JWT',
		);

		$segments = array(
			$this->base64url_encode( wp_json_encode( $header ) ),
			$this->base64url_encode( wp_json_encode( $claims ) ),
		);

		$input     = implode( '.', $segments );
		$signature = '';

		$success = openssl_sign( $input, $signature, $private_key, 'sha256' );
		if ( ! $success ) {
			return new WP_Error( 'wp_mcp_ai_calendar_signing_failed', __( 'Unable to sign the service account assertion.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 500 ) );
		}

		$segments[] = $this->base64url_encode( $signature );

		return implode( '.', $segments );
	}

	/**
	 * Normalise a list of attendees into the Google Calendar payload format.
	 *
	 * @param array $attendees Raw attendee definitions.
	 * @return array
	 */
	protected function normalise_attendees( $attendees ) {
		if ( ! is_array( $attendees ) ) {
			return array();
		}

		$normalised = array();

		foreach ( $attendees as $attendee ) {
			$email = '';
			$entry = array();

			if ( is_string( $attendee ) ) {
				$email = sanitize_email( $attendee );
				if ( '' === $email ) {
					continue;
				}

				$entry = array( 'email' => $email );
			} elseif ( is_array( $attendee ) ) {
				$email = isset( $attendee['email'] ) ? sanitize_email( $attendee['email'] ) : '';
				if ( '' === $email ) {
					continue;
				}

				$entry = array( 'email' => $email );

				if ( isset( $attendee['name'] ) ) {
					$display = sanitize_text_field( $attendee['name'] );
					if ( '' !== $display ) {
						$entry['displayName'] = $display;
					}
				}

				if ( isset( $attendee['optional'] ) ) {
					$entry['optional'] = (bool) $attendee['optional'];
				}
			}

			if ( '' === $email ) {
				continue;
			}

			// Google warns that submitting accepted/declined/tentative for a new
			// event can silently reset the guest's response and hide the event from
			// their calendar. `needsAction` is Google's recommended value for new
			// events, so it is set explicitly rather than left to the API default.
			if ( ! isset( $entry['responseStatus'] ) ) {
				$entry['responseStatus'] = 'needsAction';
			}

			$normalised[ $email ] = $entry;
		}

		return array_values( $normalised );
	}

	/**
	 * Normalise reminder overrides into the Google Calendar payload format.
	 *
	 * @param array $reminders Raw reminder definition.
	 * @return array
	 */
	protected function normalise_reminders( $reminders ) {
		if ( ! is_array( $reminders ) ) {
			return array();
		}

		$payload = array();

		if ( array_key_exists( 'use_default', $reminders ) ) {
			$payload['useDefault'] = (bool) $reminders['use_default'];
		}

		if ( ! empty( $reminders['overrides'] ) && is_array( $reminders['overrides'] ) ) {
			$overrides = array();

			foreach ( $reminders['overrides'] as $override ) {
				if ( ! is_array( $override ) ) {
					continue;
				}

				$method = isset( $override['method'] ) ? sanitize_text_field( $override['method'] ) : '';
				if ( ! in_array( $method, array( 'email', 'popup' ), true ) ) {
					continue;
				}

				if ( ! isset( $override['minutes'] ) || ! is_numeric( $override['minutes'] ) ) {
					continue;
				}

				$minutes = (int) $override['minutes'];
				if ( $minutes < 0 ) {
					continue;
				}

				$overrides[] = array(
					'method'  => $method,
					'minutes' => $minutes,
				);
			}

			if ( ! empty( $overrides ) ) {
				$payload['overrides'] = $overrides;
			}
		}

		return $payload;
	}

	/**
	 * Validate that the event start and end times form a sane range.
	 *
	 * @param array $start Parsed start definition.
	 * @param array $end   Parsed end definition.
	 * @return true|WP_Error
	 */
	protected function validate_time_range( array $start, array $end ) {
		if ( 'date' === $start['type'] && 'date' === $end['type'] ) {
			$start_date = $start['value']['date'];
			$end_date   = $end['value']['date'];

			if ( strcmp( $end_date, $start_date ) <= 0 ) {
				return new WP_Error( 'wp_mcp_ai_invalid_time_range', __( 'The event end date must be after the start date.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
			}

			return true;
		}

		if ( 'dateTime' !== $start['type'] || 'dateTime' !== $end['type'] ) {
			return new WP_Error( 'wp_mcp_ai_invalid_time_range', __( 'Start and end times must both be full date/time values or all-day dates.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
		}

		if ( ! isset( $start['datetime'], $end['datetime'] ) ) {
			return new WP_Error( 'wp_mcp_ai_invalid_time_range', __( 'Invalid start or end time provided.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
		}

		if ( $end['datetime'] <= $start['datetime'] ) {
			return new WP_Error( 'wp_mcp_ai_invalid_time_range', __( 'The event end time must be after the start time.', 'nvdigital-open-operator-system-oos-pro' ), array( 'status' => 400 ) );
		}

		return true;
	}

	/**
	 * Parse a provided date/time string into the Google Calendar payload format.
	 *
	 * @param string $value    Raw date/time string.
	 * @param string $timezone Optional timezone override.
	 * @param string $label    Field label for error messages.
	 * @return array|WP_Error
	 */
	protected function parse_event_time( $value, $timezone, $label ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_time',
				__( 'A valid date or time value must be supplied.', 'nvdigital-open-operator-system-oos-pro' ),
				array(
					'status' => 400,
					'field'  => $label,
				)
			);
		}

		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
			return array(
				'type'  => 'date',
				'value' => array( 'date' => $value ),
			);
		}

		try {
			$datetime = new DateTime( $value );
		} catch ( Exception $exception ) {
			// Intentionally empty - error handled elsewhere.
			return new WP_Error(
				'wp_mcp_ai_invalid_time',
				__( 'Unable to parse the supplied date/time value.', 'nvdigital-open-operator-system-oos-pro' ),
				array(
					'status' => 400,
					'field'  => $label,
				)
			);
		}

		if ( $timezone ) {
			try {
				$datetime->setTimezone( new DateTimeZone( $timezone ) );
			} catch ( Exception $exception ) {
				// Intentionally empty - error handled elsewhere.
				return new WP_Error(
					'wp_mcp_ai_invalid_timezone',
					__( 'The provided timezone is not valid.', 'nvdigital-open-operator-system-oos-pro' ),
					array(
						'status' => 400,
						'field'  => $label,
					)
				);
			}
		}

		$value = array( 'dateTime' => $datetime->format( DATE_RFC3339 ) );
		if ( $timezone ) {
			$value['timeZone'] = $timezone;
		}

		return array(
			'type'     => 'dateTime',
			'value'    => $value,
			'datetime' => $datetime,
		);
	}

	/**
	 * Base64 URL-safe encoding helper.
	 *
	 * @param string $data Raw data.
	 * @return string
	 */
	protected function base64url_encode( $data ) {
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- RFC 4648 base64url encoding required for the OAuth 2.0 JWT assertion; benign, no code obfuscation.
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro tier tool.
			'write',                // Creates calendar events.
			'external-api',         // Calls Google Calendar API.
			'network-dependent',    // Requires internet connectivity.
			'requires-capability',  // Requires user capabilities.
		);
	}
}
