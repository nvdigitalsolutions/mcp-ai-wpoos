<?php
/**
 * Tool that searches Gmail messages using stored OAuth credentials.
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-admin-settings.php';
require_once __DIR__ . '/class-wp-mcp-ai-pro-gmail-client.php';

/**
 * Provides an assistant tool for searching Gmail messages via the Gmail REST API.
 */
class WP_MCP_AI_Pro_Tool_Search_Gmail implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
	const GMAIL_API_BASE = 'https://gmail.googleapis.com/gmail/v1';

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'search_gmail';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Search Gmail Messages', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Searches the configured Gmail inbox and returns recent matches with sender, subject, timestamps, snippets, and attachment names. Results are sorted newest-first and can be collapsed per thread (thread_group), reduced to bare IDs (ids_only), or have snippets trimmed or omitted (snippet_length). Use get_gmail_message or get_gmail_thread to read full bodies.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Finding emails by Gmail query syntax when you need sender, subject, and snippet metadata at a glance.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Reading a message body or full conversation; use get_gmail_message or get_gmail_thread after searching.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'get_gmail_message', 'get_gmail_thread', 'list_gmail_connections' ),
			'notes'           => __( 'Supports Gmail query operators like from:, subject:, and label:; max_results caps at 50 per page.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'connection_id'  => array(
					'type'        => 'string',
					'description' => __( 'Optional Gmail connection ID from Remote Sites. If not provided, uses settings-based credentials; when those are not configured, the only enabled Remote Sites Gmail connection is used automatically (if several are enabled, pass one explicitly). Call list_gmail_connections to discover IDs.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'query'          => array(
					'type'        => 'string',
					'description' => __( 'Gmail search query string. Supports the same syntax as the Gmail web interface.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'max_results'    => array(
					'type'        => 'integer',
					'description' => __( 'Maximum number of messages to return (1-50).', 'nvdigital-open-operator-system-oos-pro' ),
					'minimum'     => 1,
					'maximum'     => 50,
					'default'     => 5,
				),
				'label_ids'      => array(
					'type'        => 'array',
					'description' => __( 'Optional Gmail label IDs to filter the results (for example INBOX or CATEGORY_PROMOTIONS).', 'nvdigital-open-operator-system-oos-pro' ),
					'items'       => array(
						'type' => 'string',
					),
				),
				'page_token'     => array(
					'type'        => 'string',
					'description' => __( 'Page token returned by a previous Gmail search response to fetch the next page of results.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'ids_only'       => array(
					'type'        => 'boolean',
					'description' => __( 'When true, returns only message IDs and thread IDs without fetching details — cheap for large result sets. Hydrate individual messages afterwards with get_gmail_message.', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => false,
				),
				'snippet_length' => array(
					'type'        => 'integer',
					'description' => __( 'Maximum snippet length in characters. Gmail snippets are at most ~150 characters server-side, so larger values only prevent truncation. Use 0 to omit snippets entirely.', 'nvdigital-open-operator-system-oos-pro' ),
					'minimum'     => 0,
					'maximum'     => 1000,
					'default'     => 150,
				),
				'thread_group'   => array(
					'type'        => 'boolean',
					'description' => __( 'When true, collapses results to one row per email thread: the newest message summary plus a message_count for the fetched page. Ignored when ids_only is true.', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => false,
				),
			),
			'required'             => array( 'query' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		$required_capability = apply_filters( 'wp_mcp_ai_search_gmail_capability', 'manage_options', $context, $arguments, $this );

		if ( $required_capability && ( ! $user_id || ! user_can( $user_id, $required_capability ) ) ) { // phpcs:ignore WordPress.WP.Capabilities.Undetermined -- Capability resolved via the wp_mcp_ai_search_gmail_capability filter (default manage_options).
			return new WP_Error( 'wp_mcp_ai_gmail_forbidden', __( 'You do not have permission to search Gmail.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		if ( is_multisite() && $user_id && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_gmail_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		// Check if connection_id is provided.
		$connection_id = isset( $arguments['connection_id'] ) ? sanitize_key( $arguments['connection_id'] ) : '';

		// Resolve credentials via the shared Gmail client so this tool stays
		// consistent with get_gmail_message/get_gmail_thread/modify_gmail_message
		// and list_gmail_connections (which accept gmail, google_workspace and
		// email_imap connection types).
		if ( ! class_exists( 'WP_MCP_AI_Pro_Gmail_Client' ) ) {
			require_once WP_MCP_AI_PRO_PATH . 'includes/tools/google-workspace/class-wp-mcp-ai-pro-gmail-client.php';
		}

		$credentials = WP_MCP_AI_Pro_Gmail_Client::resolve_credentials( $connection_id, $context );
		if ( is_wp_error( $credentials ) ) {
			return $credentials;
		}

		$client_id         = $credentials['client_id'];
		$client_secret     = $credentials['client_secret'];
		$refresh_token     = $credentials['refresh_token'];
		$configured_user   = $credentials['configured_user'];
		$credential_source = $credentials['source'];
		$resolved_id       = isset( $credentials['connection_id'] ) ? (string) $credentials['connection_id'] : '';
		$resolved_name     = isset( $credentials['connection_name'] ) ? (string) $credentials['connection_name'] : '';

		$query = isset( $arguments['query'] ) ? trim( (string) $arguments['query'] ) : '';

		if ( '' === $query ) {
			return new WP_Error( 'wp_mcp_ai_gmail_missing_query', __( 'A Gmail search query is required.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		// Load timeout from settings.
		$settings = WP_MCP_AI_Admin_Settings::get_settings();
		$timeout  = isset( $settings['request_timeout'] ) ? max( 5, absint( $settings['request_timeout'] ) ) : 30;

		$max_results = isset( $arguments['max_results'] ) ? absint( $arguments['max_results'] ) : 5;
		if ( $max_results < 1 ) {
			$max_results = 1;
		}
		if ( $max_results > 50 ) {
			$max_results = 50;
		}

		$label_ids = array();
		if ( ! empty( $arguments['label_ids'] ) ) {
			if ( is_array( $arguments['label_ids'] ) ) {
				foreach ( $arguments['label_ids'] as $label ) {
					$label = trim( (string) $label );
					if ( '' !== $label ) {
						$label_ids[] = $label;
					}
				}
			} else {
				$label = trim( (string) $arguments['label_ids'] );
				if ( '' !== $label ) {
					$label_ids[] = $label;
				}
			}
		}

		$page_token = isset( $arguments['page_token'] ) ? trim( (string) $arguments['page_token'] ) : '';

		$ids_only       = ! empty( $arguments['ids_only'] );
		$thread_group   = ! $ids_only && ! empty( $arguments['thread_group'] );
		$snippet_length = array_key_exists( 'snippet_length', $arguments ) ? absint( $arguments['snippet_length'] ) : 150;
		if ( $snippet_length > 1000 ) {
			$snippet_length = 1000;
		}

		$access_token = $this->request_access_token( $client_id, $client_secret, $refresh_token, $timeout );
		if ( is_wp_error( $access_token ) ) {
			return $access_token;
		}

		$gmail_user = '' !== $configured_user ? $configured_user : 'me';

		$list_url = $this->build_messages_list_url( $gmail_user, $query, $max_results, $label_ids, $page_token );

		$response = wp_remote_get(
			$list_url,
			array(
				'timeout' => $timeout,
				'headers' => array(
					'Accept'        => 'application/json',
					'Authorization' => 'Bearer ' . $access_token,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			WP_MCP_AI_Admin_Settings::log( 'Gmail search request failed.', array( 'error' => $response->get_error_message() ) );

			return new WP_Error( 'wp_mcp_ai_gmail_http_error', __( 'The Gmail search request failed.', 'nvdigital-open-operator-system-oos-pro' ), $response );
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status_code ) {
			WP_MCP_AI_Admin_Settings::log( 'Gmail search returned unexpected status.', array( 'status' => $status_code ) );

			return new WP_Error(
				'wp_mcp_ai_gmail_http_status',
				sprintf(
					/* translators: %d: HTTP status code. */
					__( 'Gmail returned an unexpected HTTP status: %d.', 'nvdigital-open-operator-system-oos-pro' ),
					$status_code
				),
				array(
					'status' => $status_code,
					'body'   => wp_remote_retrieve_body( $response ),
				)
			);
		}

		$body         = wp_remote_retrieve_body( $response );
		$list_payload = json_decode( $body, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $list_payload ) ) {
			WP_MCP_AI_Admin_Settings::log( 'Gmail search returned invalid JSON.', array( 'body' => $body ) );

			return new WP_Error( 'wp_mcp_ai_gmail_invalid_json', __( 'Gmail returned an invalid response.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$messages = array();
		if ( ! empty( $list_payload['messages'] ) && is_array( $list_payload['messages'] ) ) {
			foreach ( $list_payload['messages'] as $message_ref ) {
				if ( empty( $message_ref['id'] ) ) {
					continue;
				}

				if ( $ids_only ) {
					// Mirrors Gmail format=minimal: no per-message detail requests.
					$messages[] = array(
						'id'        => (string) $message_ref['id'],
						'thread_id' => isset( $message_ref['threadId'] ) ? (string) $message_ref['threadId'] : '',
					);
					continue;
				}

				$message_details = $this->fetch_message_details( $gmail_user, $message_ref['id'], $access_token, $timeout );
				if ( is_wp_error( $message_details ) ) {
					return $message_details;
				}

				if ( ! empty( $message_details ) ) {
					$messages[] = $message_details;
				}
			}
		}

		if ( ! $ids_only ) {
			// Apply the snippet length preference.
			if ( 0 === $snippet_length ) {
				foreach ( $messages as $key => $message ) {
					unset( $messages[ $key ]['snippet'] );
				}
			} elseif ( $snippet_length < 150 ) {
				foreach ( $messages as $key => $message ) {
					$messages[ $key ]['snippet'] = WP_MCP_AI_Pro_Gmail_Client::truncate_snippet(
						isset( $message['snippet'] ) ? $message['snippet'] : '',
						$snippet_length
					);
				}
			}

			// The Gmail list endpoint does not guarantee ordering — sort newest first.
			usort( $messages, array( $this, 'sort_by_timestamp_desc' ) );

			if ( $thread_group ) {
				$messages = $this->group_by_thread( $messages );
			}
		}

		return array(
			'messages'             => $messages,
			'result_size_estimate' => isset( $list_payload['resultSizeEstimate'] ) ? absint( $list_payload['resultSizeEstimate'] ) : count( $messages ),
			'next_page_token'      => isset( $list_payload['nextPageToken'] ) ? (string) $list_payload['nextPageToken'] : '',
			'has_more'             => ! empty( $list_payload['nextPageToken'] ),
			'connection_id'        => '' !== $resolved_id ? $resolved_id : $connection_id,
			'connection_name'      => $resolved_name,
			'user_email'           => $configured_user,
			'credential_source'    => $credential_source,
		);
	}

	/**
	 * Sort message rows newest-first by epoch timestamp.
	 *
	 * Rows without a timestamp sort last (stable for equal keys).
	 *
	 * @param array $a First message row.
	 * @param array $b Second message row.
	 * @return int Comparison result.
	 */
	protected function sort_by_timestamp_desc( $a, $b ) {
		$ta = isset( $a['timestamp'] ) ? (int) $a['timestamp'] : 0;
		$tb = isset( $b['timestamp'] ) ? (int) $b['timestamp'] : 0;

		if ( $ta === $tb ) {
			return 0;
		}

		return ( $ta > $tb ) ? -1 : 1;
	}

	/**
	 * Collapse message rows into one row per thread.
	 *
	 * The representative row is the newest message in the thread; a
	 * message_count records how many fetched-page messages were collapsed.
	 * Note the count only covers the current page of results.
	 *
	 * @param array $messages Message rows.
	 * @return array Grouped rows, newest thread first.
	 */
	protected function group_by_thread( $messages ) {
		$threads = array();

		foreach ( $messages as $message ) {
			$thread_id = ! empty( $message['thread_id'] ) ? (string) $message['thread_id'] : ( isset( $message['id'] ) ? (string) $message['id'] : '' );

			if ( ! isset( $threads[ $thread_id ] ) ) {
				$threads[ $thread_id ] = array(
					'latest' => $message,
					'count'  => 0,
				);
			}

			++$threads[ $thread_id ]['count'];

			$current   = isset( $threads[ $thread_id ]['latest']['timestamp'] ) ? (int) $threads[ $thread_id ]['latest']['timestamp'] : 0;
			$candidate = isset( $message['timestamp'] ) ? (int) $message['timestamp'] : 0;
			if ( $candidate >= $current ) {
				$threads[ $thread_id ]['latest'] = $message;
			}
		}

		$grouped = array();
		foreach ( $threads as $thread_id => $thread ) {
			$row                  = $thread['latest'];
			$row['thread_id']     = $thread_id;
			$row['message_count'] = $thread['count'];
			$grouped[]            = $row;
		}

		usort( $grouped, array( $this, 'sort_by_timestamp_desc' ) );

		return $grouped;
	}

	/**
	 * Request an access token from Google's OAuth endpoint using a stored refresh token.
	 *
	 * @param string $client_id     OAuth client ID.
	 * @param string $client_secret OAuth client secret.
	 * @param string $refresh_token Refresh token for the Gmail API.
	 * @param int    $timeout       Request timeout in seconds.
	 * @return string|WP_Error
	 */
	protected function request_access_token( $client_id, $client_secret, $refresh_token, $timeout ) {
		$response = wp_remote_post(
			self::TOKEN_ENDPOINT,
			array(
				'timeout' => $timeout,
				'body'    => array(
					'client_id'     => $client_id,
					'client_secret' => $client_secret,
					'refresh_token' => $refresh_token,
					'grant_type'    => 'refresh_token',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			WP_MCP_AI_Admin_Settings::log( 'Gmail token request failed.', array( 'error' => $response->get_error_message() ) );

			return new WP_Error( 'wp_mcp_ai_gmail_token_error', __( 'Failed to refresh the Gmail access token.', 'nvdigital-open-operator-system-oos-pro' ), $response );
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status_code ) {
			WP_MCP_AI_Admin_Settings::log( 'Gmail token request returned unexpected status.', array( 'status' => $status_code ) );

			return new WP_Error(
				'wp_mcp_ai_gmail_token_status',
				sprintf(
					/* translators: %d: HTTP status code. */
					__( 'The Gmail token endpoint returned an unexpected status: %d.', 'nvdigital-open-operator-system-oos-pro' ),
					$status_code
				),
				array(
					'status' => $status_code,
					'body'   => wp_remote_retrieve_body( $response ),
				)
			);
		}

		$body    = wp_remote_retrieve_body( $response );
		$payload = json_decode( $body, true );
		if ( JSON_ERROR_NONE !== json_last_error() || empty( $payload['access_token'] ) ) {
			WP_MCP_AI_Admin_Settings::log( 'Gmail token response returned invalid JSON.', array( 'body' => $body ) );

			return new WP_Error( 'wp_mcp_ai_gmail_token_invalid', __( 'Gmail returned an invalid token response.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		return (string) $payload['access_token'];
	}

	/**
	 * Fetch message metadata and snippets for a given Gmail message ID.
	 *
	 * @param string $user_id      Gmail user identifier (email address or "me").
	 * @param string $message_id   Gmail message ID.
	 * @param string $access_token OAuth access token.
	 * @param int    $timeout      Request timeout.
	 * @return array|WP_Error
	 */
	protected function fetch_message_details( $user_id, $message_id, $access_token, $timeout ) {
		$detail_url = sprintf( '%s/users/%s/messages/%s', self::GMAIL_API_BASE, rawurlencode( $user_id ), rawurlencode( $message_id ) );
		$detail_url = $this->append_query_string(
			$detail_url,
			array(
				'format'          => 'metadata',
				'metadataHeaders' => array( 'Subject', 'From', 'To', 'Date' ),
				'fields'          => 'id,threadId,labelIds,snippet,internalDate,payload(headers,filename,parts(filename))',
			)
		);

		$response = wp_remote_get(
			$detail_url,
			array(
				'timeout' => $timeout,
				'headers' => array(
					'Accept'        => 'application/json',
					'Authorization' => 'Bearer ' . $access_token,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			WP_MCP_AI_Admin_Settings::log(
				'Gmail message detail request failed.',
				array(
					'id'    => $message_id,
					'error' => $response->get_error_message(),
				)
			);

			return new WP_Error( 'wp_mcp_ai_gmail_message_error', __( 'Failed to load Gmail message details.', 'nvdigital-open-operator-system-oos-pro' ), $response );
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status_code ) {
			WP_MCP_AI_Admin_Settings::log(
				'Gmail message detail returned unexpected status.',
				array(
					'id'     => $message_id,
					'status' => $status_code,
				)
			);

			return new WP_Error(
				'wp_mcp_ai_gmail_message_status',
				sprintf(
					/* translators: %1$s: Gmail message ID, %2$d: HTTP status code. */
					__( 'Gmail returned an unexpected status (%2$d) while loading message %1$s.', 'nvdigital-open-operator-system-oos-pro' ),
					$message_id,
					$status_code
				),
				array(
					'status' => $status_code,
					'body'   => wp_remote_retrieve_body( $response ),
				)
			);
		}

		$body    = wp_remote_retrieve_body( $response );
		$payload = json_decode( $body, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $payload ) ) {
			WP_MCP_AI_Admin_Settings::log(
				'Gmail message detail returned invalid JSON.',
				array(
					'id'   => $message_id,
					'body' => $body,
				)
			);

			return new WP_Error( 'wp_mcp_ai_gmail_message_invalid', __( 'Gmail returned an invalid message response.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$headers = isset( $payload['payload']['headers'] ) && is_array( $payload['payload']['headers'] ) ? $payload['payload']['headers'] : array();

		$subject = $this->find_header_value( $headers, 'Subject' );
		$from    = $this->find_header_value( $headers, 'From' );
		$to      = $this->find_header_value( $headers, 'To' );
		$date    = $this->find_header_value( $headers, 'Date' );

		$attachment_names = WP_MCP_AI_Pro_Gmail_Client::get_attachment_names( $payload );

		$timestamp = WP_MCP_AI_Pro_Gmail_Client::get_timestamp( $payload );

		return array(
			'id'               => isset( $payload['id'] ) ? (string) $payload['id'] : $message_id,
			'thread_id'        => isset( $payload['threadId'] ) ? (string) $payload['threadId'] : '',
			'labels'           => isset( $payload['labelIds'] ) && is_array( $payload['labelIds'] ) ? array_values( array_map( 'strval', $payload['labelIds'] ) ) : array(),
			'subject'          => (string) $subject,
			'from'             => (string) $from,
			'to'               => (string) $to,
			'date'             => (string) $date,
			'timestamp'        => $timestamp,
			'snippet'          => isset( $payload['snippet'] ) ? (string) $payload['snippet'] : '',
			'has_attachments'  => count( $attachment_names ) > 0,
			'attachment_names' => $attachment_names,
			'permalink'        => sprintf( 'https://mail.google.com/mail/u/0/#all/%s', rawurlencode( isset( $payload['id'] ) ? $payload['id'] : $message_id ) ),
		);
	}

	/**
	 * Build the Gmail messages list endpoint URL with query parameters.
	 *
	 * @param string $user_id     Gmail user identifier.
	 * @param string $query       Search query.
	 * @param int    $max_results Maximum number of results to return.
	 * @param array  $label_ids   Optional label filters.
	 * @param string $page_token  Optional page token.
	 * @return string
	 */
	protected function build_messages_list_url( $user_id, $query, $max_results, $label_ids, $page_token ) {
		$base = sprintf( '%s/users/%s/messages', self::GMAIL_API_BASE, rawurlencode( $user_id ) );

		$params = array(
			'q'          => $query,
			'maxResults' => $max_results,
		);

		if ( '' !== $page_token ) {
			$params['pageToken'] = $page_token;
		}

		return $this->append_query_string( $base, array_merge( $params, array( 'labelIds' => (array) $label_ids ) ) );
	}

	/**
	 * Append query parameters to a URL, expanding list values into repeated parameters.
	 *
	 * @param string $url         Base URL.
	 * @param array  $parameters  Query parameters. Array values will be expanded into repeated keys.
	 * @return string
	 */
	protected function append_query_string( $url, $parameters ) {
		$parts = array();

		foreach ( $parameters as $key => $value ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $item ) {
					if ( null === $item || '' === $item ) {
						continue;
					}

					$parts[] = rawurlencode( $key ) . '=' . rawurlencode( $item );
				}
			} elseif ( null !== $value && '' !== $value ) {
				$parts[] = rawurlencode( $key ) . '=' . rawurlencode( $value );
			}
		}

		if ( empty( $parts ) ) {
			return $url;
		}

		return $url . ( false === strpos( $url, '?' ) ? '?' : '&' ) . implode( '&', $parts );
	}

	/**
	 * Locate a header value within the Gmail message headers array.
	 *
	 * @param array  $headers List of header objects from the Gmail API response.
	 * @param string $name    Header name to find.
	 * @return string
	 */
	protected function find_header_value( $headers, $name ) {
		if ( empty( $headers ) || '' === $name ) {
			return '';
		}

		foreach ( $headers as $header ) {
			if ( ! is_array( $header ) ) {
				continue;
			}

			$header_name = isset( $header['name'] ) ? (string) $header['name'] : '';
			if ( 0 === strcasecmp( $header_name, $name ) ) {
				return isset( $header['value'] ) ? (string) $header['value'] : '';
			}
		}

		return '';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro tier tool.
			'read-only',            // Only reads data, does not modify state.
			'external-api',         // Calls Gmail API.
			'network-dependent',    // Requires internet connectivity.
			'requires-capability',  // Requires user capabilities.
		);
	}
}
