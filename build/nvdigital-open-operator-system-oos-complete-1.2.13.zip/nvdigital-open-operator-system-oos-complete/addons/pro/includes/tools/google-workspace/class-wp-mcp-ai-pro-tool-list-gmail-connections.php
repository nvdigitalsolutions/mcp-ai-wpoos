<?php
/**
 * Tool that lists configured Gmail connections.
 *
 * Lets an agent discover valid connection_id values for search_gmail,
 * get_gmail_message, get_gmail_thread, and modify_gmail_message instead of
 * guessing. Credentials are never exposed — only id, name, type, enabled
 * state, and the configured user email are returned.
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-envelope.php';
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-admin-settings.php';

/**
 * Provides an assistant tool for discovering Gmail connections.
 */
class WP_MCP_AI_Pro_Tool_List_Gmail_Connections implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	use WP_MCP_AI_Tool_Envelope;

	/**
	 * Connection types that count as Gmail-capable inboxes.
	 */
	const GMAIL_CONNECTION_TYPES = array( 'gmail', 'google_workspace', 'email_imap' );

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'list_gmail_connections';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'List Gmail Connections', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Lists configured Gmail connections (Remote Sites roster plus the settings-based fallback) with their connection IDs, names, types, enabled state, and user emails. Use the returned IDs as connection_id for search_gmail, get_gmail_message, get_gmail_thread, and modify_gmail_message. Credentials are never returned.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Discovering valid connection_id values before calling search_gmail, get_gmail_message, get_gmail_thread, or modify_gmail_message.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Searching or reading messages; use search_gmail to find and get_gmail_message to read a specific message.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'search_gmail', 'get_gmail_message', 'get_gmail_thread' ),
			'notes'           => __( 'Credentials are never returned; the settings row appears only when settings-based Gmail credentials exist.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			// An empty stdClass encodes as `{}`; an empty PHP array would
			// encode as `[]`, which strict providers (DeepSeek) reject with
			// "[] is not of type 'object'" when MCP clients forward the schema.
			'properties'           => new stdClass(),
			'required'             => array(),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'manage_options';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments (none).
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		$required_capability = apply_filters( 'wp_mcp_ai_list_gmail_connections_capability', 'manage_options', $context, $arguments, $this );

		if ( $required_capability && ( ! $user_id || ! user_can( $user_id, $required_capability ) ) ) { // phpcs:ignore WordPress.WP.Capabilities.Undetermined -- Capability resolved via the wp_mcp_ai_list_gmail_connections_capability filter (default manage_options).
			return new WP_Error( 'wp_mcp_ai_gmail_forbidden', __( 'You do not have permission to list Gmail connections.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		if ( is_multisite() && $user_id && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_gmail_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		if ( ! class_exists( 'WP_MCP_AI_Pro_Gmail_Client' ) ) {
			require_once WP_MCP_AI_PRO_PATH . 'includes/tools/google-workspace/class-wp-mcp-ai-pro-gmail-client.php';
		}

		// Assistant-level restriction: when the assistant has a configured
		// Remote Site Connections list, discovery is limited to that list — the
		// same contract as remote_wp_connection's list_connections.
		$allowed_ids = WP_MCP_AI_Pro_Gmail_Client::get_allowed_connection_ids( $context );
		$connections = array();

		if ( class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
			$all_connections = WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections();

			if ( is_array( $all_connections ) ) {
				foreach ( $all_connections as $conn_id => $connection ) {
					if ( ! is_array( $connection ) ) {
						continue;
					}

					if ( null !== $allowed_ids && ! in_array( (string) $conn_id, $allowed_ids, true ) ) {
						continue;
					}

					$conn_type = isset( $connection['connection_type'] ) ? sanitize_key( $connection['connection_type'] ) : '';
					if ( ! in_array( $conn_type, self::GMAIL_CONNECTION_TYPES, true ) ) {
						continue;
					}

					// Redacted by construction: credentials are never copied out.
					$connections[] = array(
						'id'              => (string) $conn_id,
						'name'            => isset( $connection['name'] ) ? (string) $connection['name'] : (string) $conn_id,
						'connection_type' => $conn_type,
						'enabled'         => ! empty( $connection['enabled'] ),
						'user_email'      => isset( $connection['user_email'] ) ? (string) $connection['user_email'] : '',
					);
				}
			}
		}

		// Settings-based fallback: represents the inbox used when connection_id is omitted.
		// Restricted assistants only see it when the assistant editor granted the
		// "settings" row; unrestricted assistants always see it.
		$settings_fallback_allowed = ( null === $allowed_ids || in_array( 'settings', $allowed_ids, true ) );
		$settings = WP_MCP_AI_Admin_Settings::get_settings();
		if ( $settings_fallback_allowed && ! empty( $settings['gmail_client_id'] ) && ! empty( $settings['gmail_refresh_token'] ) ) {
			$connections[] = array(
				'id'              => 'settings',
				'name'            => __( 'NV oOS Gmail settings (default connection)', 'nvdigital-open-operator-system-oos-pro' ),
				'connection_type' => 'gmail',
				'enabled'         => true,
				'user_email'      => isset( $settings['gmail_user_email'] ) ? (string) $settings['gmail_user_email'] : '',
			);
		}

		$data = array(
			'connections' => $connections,
			'note'        => __( 'Credentials are never included in this list. Omit connection_id to use the site-wide settings-based default ("settings" row); when no settings credentials are configured, the only enabled connection is used automatically. If several connections are enabled, pass the connection_id explicitly — Gmail tools will not guess between them. Assistants with a Remote Site Connections restriction only see the connections enabled for them, including the "settings" row when it is checked in the assistant editor.', 'nvdigital-open-operator-system-oos-pro' ),
		);

		return $this->format_success_response(
			__( 'Gmail connections listed.', 'nvdigital-open-operator-system-oos-pro' ),
			array( 'data' => $data )
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro tier tool.
			'read-only',            // Only reads configuration, does not modify state.
			'local-only',           // No external API calls.
			'requires-capability',  // Requires user capabilities.
		);
	}
}
