<?php
/**
 * WP MCP AI - Main Plugin File
 *
 * This file contains the core plugin functionality and is included by the
 * main plugin entry point (mcp-ai-wpoos-base.php for base version,
 * or mcp-ai-wpoos.php itself for the combined version).
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prevent double-loading of the plugin.
 * This check must come before any constants are defined to ensure we exit early
 * if the plugin has already been loaded through another entry point.
 */
if ( function_exists( 'wp_mcp_ai_core_loaded' ) ) {
	return;
}

/**
 * WP_MCP_AI_FILE must be defined here — it is tied to __FILE__ in this specific file.
 * All other plugin constants are centralised in includes/bootstrap/constants.php.
 */
if ( ! defined( 'WP_MCP_AI_FILE' ) ) {
	define( 'WP_MCP_AI_FILE', __FILE__ );
}

/**
 * Check PHP version compatibility before loading any classes.
 *
 * This plugin requires PHP 7.4 or later. On older PHP versions, class files
 * will fail to parse with syntax errors. We check the version early to provide
 * a clear error message instead of cryptic parse errors.
 */
if ( version_compare( PHP_VERSION, '7.4.0', '<' ) ) {
	/**
	 * Display admin notice for PHP version incompatibility.
	 */
	function wp_mcp_ai_php_version_notice() {
		$message = sprintf(
			'<strong>Open Operator System</strong> requires PHP version %2$s or higher. You are running PHP version %1$s. Please contact your hosting provider to upgrade PHP.',
			PHP_VERSION,
			'7.4.0'
		);
		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			wp_kses_post( $message )
		);
	}

	/**
	 * Prevent plugin activation on incompatible PHP versions.
	 */
	function wp_mcp_ai_deactivate_self() {
		deactivate_plugins( plugin_basename( WP_MCP_AI_FILE ) );
	}

	add_action( 'admin_notices', 'wp_mcp_ai_php_version_notice' );
	add_action( 'admin_init', 'wp_mcp_ai_deactivate_self' );

	return;
}

/**
 * Bootstrap-integrity guard.
 *
 * A partial plugin update can leave core bootstrap files missing, which would
 * otherwise cascade into fatal errors on every request. This block is fully
 * self-contained (it must not depend on helpers.php, which may itself be
 * missing): it stat()s the critical bootstrap chain against __DIR__ and, when
 * any file is absent, bails out before the require chain runs.
 *
 * The admin_notices closure only runs after init, so esc_html__() is safe here
 * despite the textdomain not being loadable yet during file parsing.
 *
 * @since 1.1.96
 */
$wp_mcp_ai_required_bootstrap = array(
	'includes/bootstrap/constants.php',
	'includes/bootstrap/autoload.php',
	'includes/bootstrap/helpers.php',
	'includes/bootstrap/cron.php',
	'includes/bootstrap/hooks.php',
	'includes/bootstrap/loader.php',
	'includes/bootstrap/activation.php',
	'includes/class-wp-mcp-ai-plugin.php',
	'includes/bootstrap/oos-bridge.php',
);
$wp_mcp_ai_missing_bootstrap  = array();
foreach ( $wp_mcp_ai_required_bootstrap as $wp_mcp_ai_bootstrap_file ) {
	if ( ! file_exists( __DIR__ . '/' . $wp_mcp_ai_bootstrap_file ) ) {
		$wp_mcp_ai_missing_bootstrap[] = $wp_mcp_ai_bootstrap_file;
	}
}
if ( ! empty( $wp_mcp_ai_missing_bootstrap ) ) {
	if ( is_admin() ) {
		add_action(
			'admin_notices',
			function () use ( $wp_mcp_ai_missing_bootstrap ) {
				if ( ! current_user_can( 'manage_options' ) ) {
					return;
				}
				printf(
					'<div class="notice notice-error"><p><strong>Open Operator System:</strong> %s</p><p><code>%s</code></p></div>',
					esc_html__( 'Critical plugin files are missing from this installation (incomplete update). Reinstall or update the plugin to restore it.', 'nvdigital-open-operator-system-oos' ),
					implode( '</code>, <code>', array_map( 'esc_html', array_slice( $wp_mcp_ai_missing_bootstrap, 0, 5 ) ) )
				);
			}
		);
	}

	return;
}

// ---------------------------------------------------------------------------
// Pre-populate the l10n global with a NOOP_Translations instance before
// loader.php runs. This prevents WordPress 6.7+ from firing
// _load_textdomain_just_in_time warnings when translation functions
// (__(), esc_html__(), etc.) are called during plugin bootstrap (pre-init).
//
// NOOP_Translations is a WordPress core class (wp-includes/pomo/mo.php,
// loaded before plugins) that returns strings unchanged — exactly what
// English sites need when no .mo files exist.
//
// When real .mo files are loaded later on 'init' by WordPress's automatic
// locale machinery, load_textdomain() merges them into the existing object.
// ---------------------------------------------------------------------------
global $l10n;
if ( ! isset( $l10n['nvdigital-open-operator-system-oos'] ) && class_exists( 'NOOP_Translations' ) ) {
	$l10n['nvdigital-open-operator-system-oos'] = new NOOP_Translations();
}

// Load bootstrap files in dependency order.
require_once __DIR__ . '/includes/bootstrap/constants.php';
require_once __DIR__ . '/includes/bootstrap/autoload.php';
require_once __DIR__ . '/includes/bootstrap/helpers.php';
require_once __DIR__ . '/includes/bootstrap/cron.php';
require_once __DIR__ . '/includes/bootstrap/hooks.php';
require_once __DIR__ . '/includes/bootstrap/loader.php';
require_once __DIR__ . '/includes/bootstrap/activation.php';
require_once __DIR__ . '/includes/class-wp-mcp-ai-plugin.php';
require_once __DIR__ . '/includes/bootstrap/oos-bridge.php';

// Register lifecycle hooks (must reference WP_MCP_AI_FILE, defined above).
register_activation_hook( WP_MCP_AI_FILE, 'wp_mcp_ai_activate' );
register_deactivation_hook( WP_MCP_AI_FILE, 'wp_mcp_ai_deactivate' );
register_uninstall_hook( WP_MCP_AI_FILE, 'wp_mcp_ai_uninstall' );

// Boot the plugin on plugins_loaded.
if ( ! has_action( 'plugins_loaded', 'wp_mcp_ai_bootstrap' ) ) {
	add_action( 'plugins_loaded', 'wp_mcp_ai_bootstrap', 20 );
}

// Load plugin textdomain for bundled translations.
add_action( 'init', 'wp_mcp_ai_load_textdomain' );
function wp_mcp_ai_load_textdomain() {
	load_plugin_textdomain(
		'nvdigital-open-operator-system-oos',
		false,
		dirname( plugin_basename( WP_MCP_AI_FILE ) ) . '/languages/'
	);
}

// ---------------------------------------------------------------------------
// Export Provider Registration (Backup & Restore)
// ---------------------------------------------------------------------------

/**
 * Register core export providers for the Backup & Restore feature.
 *
 * Fires on admin_init so providers are available when the Settings
 * Management page renders. Addons hook into the same action to
 * register their own providers.
 *
 * @since 1.2.0
 *
 * @return void
 */
function wp_mcp_ai_register_export_providers(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( ! class_exists( 'WP_MCP_AI_Export_Manager' ) ) {
		// Autoload will handle this, but ensure the file is discoverable.
		$export_dir = WP_MCP_AI_PATH . 'includes/admin/export/';
		require_once $export_dir . 'interface-wp-mcp-ai-export-provider.php';
		require_once $export_dir . 'class-wp-mcp-ai-export-provider-base.php';
		require_once $export_dir . 'class-wp-mcp-ai-export-manager.php';
		require_once $export_dir . 'class-wp-mcp-ai-export-provider-core-settings.php';
		require_once $export_dir . 'class-wp-mcp-ai-export-provider-toolkit-options.php';
		require_once $export_dir . 'class-wp-mcp-ai-export-provider-addon-options.php';
		require_once $export_dir . 'class-wp-mcp-ai-export-provider-assistants.php';
		require_once $export_dir . 'class-wp-mcp-ai-export-provider-cpts.php';
		require_once $export_dir . 'class-wp-mcp-ai-export-provider-custom-tables.php';
		require_once $export_dir . 'class-wp-mcp-ai-export-provider-federation.php';
	}

	$manager = WP_MCP_AI_Export_Manager::instance();

	// Core providers (always available).
	$manager->register( new WP_MCP_AI_Export_Provider_Core_Settings() );
	$manager->register( new WP_MCP_AI_Export_Provider_Toolkit_Options() );
	$manager->register( new WP_MCP_AI_Export_Provider_Addon_Options() );
	$manager->register( new WP_MCP_AI_Export_Provider_Assistants() );
	$manager->register( new WP_MCP_AI_Export_Provider_CPTs() );
	$manager->register( new WP_MCP_AI_Export_Provider_Custom_Tables() );
	$manager->register( new WP_MCP_AI_Export_Provider_Federation() );

	/**
	 * Fires when export providers are being registered.
	 *
	 * Addons should hook here to register their own providers
	 * via $manager->register().
	 *
	 * @since 1.2.0
	 *
	 * @param WP_MCP_AI_Export_Manager $manager The export manager instance.
	 */
	do_action( 'wp_mcp_ai_register_export_providers', $manager );
}

add_action( 'admin_init', 'wp_mcp_ai_register_export_providers', 20 );
