<?php
/**
 * Pro Workflow Builder Presets
 *
 * Provides pre-built workflow DAG (Directed Acyclic Graph) presets for the
 * Pro Workflow Builder. Each preset is a complete workflow template that can
 * be loaded into the React-based builder UI, giving users a head start with
 * common automation patterns.
 *
 * Preset categories:
 * - content:       Content creation and publishing workflows.
 * - seo:           Search engine optimisation workflows.
 * - ecommerce:     E-commerce and product management workflows.
 * - marketing:     Marketing automation workflows.
 * - data:          Data processing and analysis workflows.
 * - communication: Messaging and notification workflows.
 * - maintenance:   Site maintenance workflows.
 * - onboarding:    User and content onboarding workflows.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Workflow_Presets
 * @since      1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Pro_Workflow_Presets' ) ) {

	/**
	 * Class WP_MCP_AI_Pro_Workflow_Presets
	 *
	 * Registry of pre-built workflow DAG presets for the Pro Workflow Builder.
	 * All methods are static so the class can be used without instantiation.
	 *
	 * @since 1.0.0
	 */
	class WP_MCP_AI_Pro_Workflow_Presets {

		// ------------------------------------------------------------------
		// Preset retrieval
		// ------------------------------------------------------------------

		/**
		 * Get every available workflow preset.
		 *
		 * Presets are grouped internally by category but returned as a flat
		 * associative array keyed by preset ID.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Associative array of preset definitions.
		 */
		public static function get_presets() {
			$presets = array_merge(
				self::get_content_presets(),
				self::get_seo_presets(),
				self::get_ecommerce_presets(),
				self::get_marketing_presets(),
				self::get_data_presets(),
				self::get_communication_presets(),
				self::get_maintenance_presets(),
				self::get_onboarding_presets(),
				self::get_crm_support_presets(),
				self::get_outreach_presets(),
				self::get_fashion_presets(),
				self::get_fnb_presets(),
				self::get_gtmetrix_presets()
			);

			return $presets;
		}

		/**
		 * Food & Beverage Management toolkit workflows.
		 *
		 * @since 1.6.0
		 *
		 * @return array<string,array> F&B workflow presets.
		 */
		private static function get_fnb_presets() {
			return array(
				'fnb_weekend_prep'   => array(
					'name'        => __( 'Weekend Prep Plan', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Forecast weekend covers and portions, check stock shortfalls and supplier cut-offs, then save the R-03 plan as a draft.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'fnb',
					'icon'        => 'dashicons-calendar-alt',
					'tags'        => array( 'fnb', 'weekend', 'stock' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Weekend Friday', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'The Friday of the weekend to plan (Y-m-d).', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 75,
							),
							'data'     => array(
								'label'       => __( 'Weekend Demand', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'fnb_weekend_demand',
								'arguments'   => array( 'friday' => '{{input.friday}}' ),
								'description' => __( 'Expected covers, portions, shortfalls and supplier cut-offs (M-12/M-13).', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Generate R-03', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'fnb_generate_report',
								'arguments'   => array(
									'report_id' => 'R-03',
									'date'      => '{{input.friday}}',
								),
								'description' => __( 'Build the weekend prep plan in the Report-library layout.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 225,
							),
							'data'     => array(
								'label'       => __( 'Draft Plan', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Save the R-03 output as a draft for the head chef and bar manager.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
				'fnb_monthly_review' => array(
					'name'        => __( 'Monthly Cost Review', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Compare the month against budget and the previous month, split volume vs per-cover effects, then save the R-08 review as a draft.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'fnb',
					'icon'        => 'dashicons-chart-line',
					'tags'        => array( 'fnb', 'monthly', 'cost' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Month', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'The month to review (Y-m).', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 75,
							),
							'data'     => array(
								'label'       => __( 'Compare Periods', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'fnb_compare_periods',
								'arguments'   => array( 'month' => '{{input.month}}' ),
								'description' => __( 'Headline metrics month on month.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Generate R-08', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'fnb_generate_report',
								'arguments'   => array(
									'report_id' => 'R-08',
									'month'     => '{{input.month}}',
								),
								'description' => __( 'Actual vs budget vs last month with the volume/per-cover split.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 225,
							),
							'data'     => array(
								'label'       => __( 'Draft Review', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Save the R-08 output as a draft for the owner.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
				'fnb_monthly_export' => array(
					'name'        => __( 'Monthly Report Export (CSV/PDF)', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Export the monthly cost review (and other client reports) as CSV or PDF via fnb_export_report.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'fnb',
					'icon'        => 'dashicons-media-spreadsheet',
					'tags'        => array( 'fnb', 'monthly', 'export' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Month', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'The month to export (Y-m).', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 75,
							),
							'data'     => array(
								'label'       => __( 'Export R-08', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'fnb_export_report',
								'arguments'   => array(
									'report_id' => 'R-08',
									'month'     => '{{input.month}}',
									'format'    => 'csv',
								),
								'description' => __( 'Export the monthly cost review to CSV.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Exported file', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Downloadable CSV/PDF of the report.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		/**
		 * GTmetrix Performance toolkit workflows.
		 *
		 * @since 1.2.5
		 *
		 * @return array<string,array> GTmetrix workflow presets.
		 */
		private static function get_gtmetrix_presets() {
			return array(
				'gtmetrix_audit_fix_pipeline'     => array(
					'name'        => __( 'GTmetrix Audit & Fix Pipeline', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Test a URL, analyze the report, generate the WPCode-ready fix snippet and install it as an inactive draft.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'gtmetrix',
					'icon'        => 'dashicons-performance',
					'tags'        => array( 'gtmetrix', 'performance', 'wpcode' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Page URL', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'The page to audit (must be on an allowed host).', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 75,
							),
							'data'     => array(
								'label'       => __( 'Start Test', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'gtmetrix_start_test',
								'arguments'   => array( 'url' => '{{input.url}}' ),
								'description' => __( 'Run a Lighthouse test (credit-gated).', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Poll Status', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'gtmetrix_get_test_status',
								'arguments'   => array( 'test_id' => '{{node_2.test_id}}' ),
								'description' => __( 'Wait for the test to complete.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 225,
							),
							'data'     => array(
								'label'       => __( 'Analyze', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'gtmetrix_analyze_report',
								'arguments'   => array( 'report_id' => '{{node_3.report_id}}' ),
								'description' => __( 'CWV assessment, budgets and the mapped fix list.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Snippet', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'gtmetrix_generate_wpcode_snippet',
								'arguments'   => array( 'report_id' => '{{node_3.report_id}}' ),
								'description' => __( 'WPCode-ready snippet from the matched fixes.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 375,
							),
							'data'     => array(
								'label'       => __( 'Install Draft', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'gtmetrix_install_wpcode_fix',
								'arguments'   => array( 'report_id' => '{{node_3.report_id}}' ),
								'description' => __( 'Save the fixes as an inactive WPCode draft.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Fix Summary', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Draft snippet ID, blocks and staging notes.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
				'gtmetrix_deploy_regression_gate' => array(
					'name'        => __( 'GTmetrix Deploy Regression Gate', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Retest a page after a deploy and compare against its previous report for a pass/fail regression verdict.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'gtmetrix',
					'icon'        => 'dashicons-update-alt',
					'tags'        => array( 'gtmetrix', 'deploy', 'regression' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Page URL', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'The page to retest.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 75,
							),
							'data'     => array(
								'label'       => __( 'Retest Page', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'gtmetrix_retest_page',
								'arguments'   => array( 'url' => '{{input.url}}' ),
								'description' => __( 'New run with the page saved options.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Compare', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'gtmetrix_compare_reports',
								'arguments'   => array( 'url' => '{{input.url}}' ),
								'description' => __( 'Before/after delta against the previous snapshot.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 225,
							),
							'data'     => array(
								'label'       => __( 'Pass/Fail', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Regression verdict with per-metric deltas.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		/**
		 * Get a single preset by its ID.
		 *
		 * @since  1.0.0
		 * @param  string $preset_id The unique preset identifier.
		 * @return array|null Preset definition array, or null if not found.
		 */
		public static function get_preset( $preset_id ) {
			$preset_id = sanitize_key( $preset_id );

			if ( '' === $preset_id ) {
				return null;
			}

			$presets = self::get_presets();

			return isset( $presets[ $preset_id ] ) ? $presets[ $preset_id ] : null;
		}

		/**
		 * Get all presets belonging to a specific category.
		 *
		 * @since  1.0.0
		 * @param  string $category Category slug (e.g. 'content', 'seo').
		 * @return array<string, array> Filtered preset definitions.
		 */
		public static function get_presets_by_category( $category ) {
			$category = sanitize_key( $category );

			return array_filter(
				self::get_presets(),
				function ( $preset ) use ( $category ) {
					return isset( $preset['category'] ) && $preset['category'] === $category;
				}
			);
		}

		/**
		 * Get the list of available preset categories.
		 *
		 * @since  1.0.0
		 * @return array<string, string> Slug => label pairs.
		 */
		public static function get_categories() {
			return array(
				'content'       => __( 'Content Creation & Publishing', 'nvdigital-open-operator-system-oos-pro' ),
				'seo'           => __( 'Search Engine Optimisation', 'nvdigital-open-operator-system-oos-pro' ),
				'ecommerce'     => __( 'E-Commerce & Product Management', 'nvdigital-open-operator-system-oos-pro' ),
				'marketing'     => __( 'Marketing Automation', 'nvdigital-open-operator-system-oos-pro' ),
				'data'          => __( 'Data Processing & Analysis', 'nvdigital-open-operator-system-oos-pro' ),
				'communication' => __( 'Messaging & Notifications', 'nvdigital-open-operator-system-oos-pro' ),
				'maintenance'   => __( 'Site Maintenance', 'nvdigital-open-operator-system-oos-pro' ),
				'onboarding'    => __( 'User & Content Onboarding', 'nvdigital-open-operator-system-oos-pro' ),
				'crm_support'   => __( 'CRM — Support & Ticket Management', 'nvdigital-open-operator-system-oos-pro' ),
				'outreach'      => __( 'Outreach — Admissibility & Signals', 'nvdigital-open-operator-system-oos-pro' ),
				'fashion'       => __( 'AI Fashion Production', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		// ------------------------------------------------------------------
		// Preset installation
		// ------------------------------------------------------------------

		/**
		 * Prepare a preset for loading into the Workflow Builder.
		 *
		 * Returns the nodes and edges arrays ready to be consumed by the
		 * ReactFlow-based builder UI.
		 *
		 * @since  1.0.0
		 * @param  string $preset_id The unique preset identifier.
		 * @return array|\WP_Error Workflow data on success, WP_Error on failure.
		 */
		public static function install_preset( $preset_id ) {
			$preset = self::get_preset( $preset_id );

			if ( null === $preset ) {
				return new \WP_Error(
					'invalid_preset',
					/* translators: %s: preset identifier */
					sprintf( __( 'Workflow preset "%s" does not exist.', 'nvdigital-open-operator-system-oos-pro' ), sanitize_key( $preset_id ) )
				);
			}

			return array(
				'name'        => $preset['name'],
				'description' => $preset['description'],
				'category'    => $preset['category'],
				'icon'        => $preset['icon'],
				'tags'        => $preset['tags'],
				'nodes'       => $preset['nodes'],
				'edges'       => $preset['edges'],
			);
		}

		// ------------------------------------------------------------------
		// Content presets
		// ------------------------------------------------------------------

		/**
		 * Get content creation and publishing workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Content preset definitions.
		 */
		private static function get_content_presets() {
			return array(
				'content_pipeline'         => array(
					'name'        => __( 'Blog Post Pipeline', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Research a topic, generate an outline, write a draft, optimise for SEO, and publish.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'content',
					'icon'        => 'dashicons-admin-page',
					'tags'        => array( 'content', 'seo', 'publishing' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Topic Input', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Enter the blog topic to research.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_1b',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 75,
							),
							'data'     => array(
								'label'       => __( 'Check Existing Content', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_recent_posts',
								'arguments'   => array(
									'status' => 'publish',
									'limit'  => 20,
								),
								'description' => __( 'Review recently published posts to avoid duplicate topics and identify content gaps.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Research Topic', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'web_search',
								'arguments'   => array( 'query' => '{{input.topic}}' ),
								'description' => __( 'Research the topic using web search.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Outline', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'outline' ),
								'description' => __( 'Generate a structured outline from research.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Write Draft', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_status' => 'draft',
									'post_type'   => 'post',
								),
								'description' => __( 'Create a draft post from the outline.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Optimise SEO', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'seo_meta_optimizer',
								'arguments'   => array( 'post_id' => '{{node_4.post_id}}' ),
								'description' => __( 'Optimise post meta for search engines.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Publish Post', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array(
									'post_id'     => '{{node_4.post_id}}',
									'post_status' => 'publish',
								),
								'description' => __( 'Publish the finished post.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 900,
							),
							'data'     => array(
								'label'       => __( 'Pipeline Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Blog post published successfully.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_1b',
							'source'       => 'node_1',
							'target'       => 'node_1b',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_1b_2',
							'source'       => 'node_1b',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
				'content_refresh'          => array(
					'name'        => __( 'Content Refresh', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Find old posts, analyse performance, update content, and regenerate images.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'content',
					'icon'        => 'dashicons-update',
					'tags'        => array( 'content', 'maintenance', 'images' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Find Old Posts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'content_freshness_checker',
								'arguments'   => array( 'max_age_days' => 180 ),
								'description' => __( 'Identify posts older than 180 days.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Analyse Performance', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_analytics',
								'arguments'   => array( 'metric' => 'pageviews' ),
								'description' => __( 'Pull analytics data for identified posts.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Needs Update?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.pageviews < 100',
								'description' => __( 'Check if post performance is below threshold.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Update Content', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array( 'post_status' => 'draft' ),
								'description' => __( 'Refresh the post content with updated information.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Regenerate Images', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'generate_openai_image',
								'arguments'   => array( 'size' => '1024x1024' ),
								'description' => __( 'Generate fresh featured images for the post.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Refresh Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Content refresh workflow finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_6',
							'source'       => 'node_3',
							'target'       => 'node_6',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
				'social_content_repurpose' => array(
					'name'        => __( 'Repurpose for Social', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Take an existing post, generate social media snippets, and schedule them.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'content',
					'icon'        => 'dashicons-share',
					'tags'        => array( 'content', 'social', 'scheduling' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Select Post', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Choose the post to repurpose for social media.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Get Post Content', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_post',
								'arguments'   => array( 'post_id' => '{{input.post_id}}' ),
								'description' => __( 'Retrieve the full post content.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Social Snippets', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'social_snippets' ),
								'description' => __( 'Create platform-specific social media snippets.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Generate Social Image', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'generate_openai_image',
								'arguments'   => array( 'size' => '1200x630' ),
								'description' => __( 'Create an optimised image for social sharing.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Schedule Posts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'post',
									'post_status' => 'future',
								),
								'description' => __( 'Schedule the social media posts for publishing.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Repurpose Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Social media content scheduled.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
				'newsletter_workflow'      => array(
					'name'        => __( 'Newsletter Builder', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Collect top posts, generate a summary, format the email, and send the newsletter.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'content',
					'icon'        => 'dashicons-email-alt',
					'tags'        => array( 'content', 'email', 'newsletter' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Collect Top Posts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_recent_posts',
								'arguments'   => array(
									'count'   => 5,
									'orderby' => 'comment_count',
								),
								'description' => __( 'Get the top-performing recent posts.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Generate Summary', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'newsletter_digest' ),
								'description' => __( 'Summarise each post into a newsletter-ready digest.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Format Email', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'email_html' ),
								'description' => __( 'Format the digest into an email-friendly layout.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Send Newsletter', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'newsletter' ),
								'description' => __( 'Broadcast the newsletter to subscribers.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Newsletter Sent', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Newsletter has been sent to all subscribers.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// SEO presets
		// ------------------------------------------------------------------

		/**
		 * Get search engine optimisation workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> SEO preset definitions.
		 */
		private static function get_seo_presets() {
			return array(
				'seo_audit'                 => array(
					'name'        => __( 'SEO Audit', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Crawl pages, check meta tags, analyse keywords, and generate an audit report.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'seo',
					'icon'        => 'dashicons-search',
					'tags'        => array( 'seo', 'audit', 'meta' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Crawl Pages', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'run_crawl4ai_job',
								'arguments'   => array( 'depth' => 2 ),
								'description' => __( 'Crawl the site to discover all pages.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Check Meta Tags', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_rankmath_seo',
								'arguments'   => array( 'check' => 'meta_tags' ),
								'description' => __( 'Analyse meta tags for each discovered page.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Analyse Keywords', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_search_console',
								'arguments'   => array( 'metric' => 'keywords' ),
								'description' => __( 'Pull keyword performance from Search Console.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Generate Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'seo_audit_report' ),
								'description' => __( 'Compile findings into a visual SEO audit report.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Audit Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'SEO audit report generated.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
				'broken_link_repair'        => array(
					'name'        => __( 'Link Repair', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Scan for broken links, suggest replacements, and update posts automatically.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'seo',
					'icon'        => 'dashicons-admin-links',
					'tags'        => array( 'seo', 'links', 'maintenance' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Scan Links', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'run_crawl4ai_job',
								'arguments'   => array( 'mode' => 'link_scan' ),
								'description' => __( 'Crawl the site to identify all outbound and internal links.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Broken Links Found?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_1.broken_count > 0',
								'description' => __( 'Check if any broken links were detected.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Suggest Replacements', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'suggest_internal_links',
								'arguments'   => array( 'post_id' => '{{node_1.post_id}}' ),
								'description' => __( 'Find replacement URLs for broken links.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Update Posts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array(
									'post_id' => '{{node_3.post_id}}',
									'content' => '{{node_3.updated_content}}',
								),
								'description' => __( 'Replace broken links with suggested alternatives.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Repair Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Broken links have been repaired.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_2_5',
							'source'       => 'node_2',
							'target'       => 'node_5',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
				'keyword_research_pipeline' => array(
					'name'        => __( 'Keyword Pipeline', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Research keywords, analyse competition, prioritise opportunities, generate an image, and create content briefs.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'seo',
					'icon'        => 'dashicons-search',
					'tags'        => array( 'seo', 'keywords', 'research' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Seed Keywords', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Enter seed keywords to begin research.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_1b',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 75,
							),
							'data'     => array(
								'label'       => __( 'Check Existing Content', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_recent_posts',
								'arguments'   => array(
									'status' => 'publish',
									'limit'  => 30,
								),
								'description' => __( 'Review recently published posts to identify which keywords and topics are already covered, so briefs target genuine content gaps.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Research Keywords', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'web_search',
								'arguments'   => array( 'query' => '{{input.keywords}} keyword research' ),
								'description' => __( 'Find related keywords and search volumes.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Analyse Competition', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_search_console',
								'arguments'   => array( 'metric' => 'impressions' ),
								'description' => __( 'Evaluate competition levels for each keyword.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Prioritise Keywords', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'content_recommendation_engine',
								'arguments'   => array( 'mode' => 'ranking_potential' ),
								'description' => __( 'Rank keywords by opportunity score.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4b',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 525,
							),
							'data'     => array(
								'label'       => __( 'Generate Featured Image', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'generate_openai_image',
								'arguments'   => array(
									'prompt'  => '{{node_1.value}}',
									'size'    => '1792x1024',
									'model'   => 'dall-e-3',
									'quality' => 'hd',
								),
								'description' => __( 'Generate an AI featured image for the content.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Create Content Briefs', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'         => 'post',
									'post_status'       => 'draft',
									'featured_image_id' => '{{node_4b.attachment_id}}',
								),
								'description' => __( 'Generate content briefs for prioritised keywords.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Pipeline Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Keyword research pipeline finished. Content briefs ready.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_1b',
							'source'       => 'node_1',
							'target'       => 'node_1b',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_1b_2',
							'source'       => 'node_1b',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_4b',
							'source'       => 'node_4',
							'target'       => 'node_4b',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4b_5',
							'source'       => 'node_4b',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),

					),
				),
			);
		}

		// ------------------------------------------------------------------
		// E-commerce presets
		// ------------------------------------------------------------------

		/**
		 * Get e-commerce and product management workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> E-commerce preset definitions.
		 */
		private static function get_ecommerce_presets() {
			return array(
				'product_launch'          => array(
					'name'        => __( 'Product Launch', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Create a product, generate description, set pricing, publish, and announce.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'ecommerce',
					'icon'        => 'dashicons-cart',
					'tags'        => array( 'ecommerce', 'product', 'launch' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Product Details', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Enter basic product information.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Create Product', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_woo_product',
								'arguments'   => array( 'status' => 'draft' ),
								'description' => __( 'Create the WooCommerce product in draft mode.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Description', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'product_description' ),
								'description' => __( 'Generate an SEO-optimised product description.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Generate Product Image', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'generate_openai_image',
								'arguments'   => array( 'size' => '1024x1024' ),
								'description' => __( 'Create a product image using AI.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Publish Product', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array(
									'post_status'       => 'publish',
									'featured_image_id' => '{{node_4.attachment_id}}',
								),
								'description' => __( 'Set the product to published status.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Announce Launch', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'announcements' ),
								'description' => __( 'Broadcast the product launch announcement.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 900,
							),
							'data'     => array(
								'label'       => __( 'Launch Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Product launched and announced successfully.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
				'order_fulfillment_check' => array(
					'name'        => __( 'Order Fulfillment Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Get pending orders, check inventory, flag issues, and notify the team.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'ecommerce',
					'icon'        => 'dashicons-clipboard',
					'tags'        => array( 'ecommerce', 'orders', 'inventory' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Get Pending Orders', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_woo_recent_orders',
								'arguments'   => array( 'status' => 'pending' ),
								'description' => __( 'Retrieve all orders awaiting fulfillment.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Check Inventory', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_woo_products',
								'arguments'   => array( 'check' => 'stock_status' ),
								'description' => __( 'Verify stock levels for ordered products.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Stock Issues?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.out_of_stock_count > 0',
								'description' => __( 'Check if any ordered items are out of stock.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Flag Issues', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'mcp_ai_task',
									'post_status' => 'publish',
								),
								'description' => __( 'Create a task for stock issues requiring attention.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Notify Team', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'operations' ),
								'description' => __( 'Alert the operations team about stock issues.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Check Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Order fulfillment check completed.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_6',
							'source'       => 'node_3',
							'target'       => 'node_6',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
				'review_response'         => array(
					'name'        => __( 'Review Response', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Get new product reviews, analyse sentiment, and draft responses.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'ecommerce',
					'icon'        => 'dashicons-star-filled',
					'tags'        => array( 'ecommerce', 'reviews', 'sentiment' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Get New Reviews', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array(
									'post_type' => 'product',
									'meta_key'  => 'rating', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Staging environment preset.
								),
								'description' => __( 'Fetch recent product reviews.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Analyse Sentiment', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_analyze_sentiment',
								'arguments'   => array( 'text' => '{{node_1.reviews}}' ),
								'description' => __( 'Determine the sentiment of each review.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Negative Review?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.sentiment === "negative"',
								'description' => __( 'Route based on review sentiment.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Draft Apology Response', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'tone' => 'empathetic' ),
								'description' => __( 'Draft a thoughtful response to the negative review.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 400,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Draft Thank-You Response', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'tone' => 'grateful' ),
								'description' => __( 'Draft a thank-you response for the positive review.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Responses Ready', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Review responses drafted and ready for approval.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_5',
							'source'       => 'node_3',
							'target'       => 'node_5',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_6',
							'source'       => 'node_4',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Marketing presets
		// ------------------------------------------------------------------

		/**
		 * Get marketing automation workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Marketing preset definitions.
		 */
		private static function get_marketing_presets() {
			return array(
				'lead_nurture_sequence' => array(
					'name'        => __( 'Lead Nurture', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Identify cold leads, segment them, generate personalised messages, and send.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'marketing',
					'icon'        => 'dashicons-groups',
					'tags'        => array( 'marketing', 'leads', 'email' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Identify Cold Leads', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array(
									'post_type' => 'mcp_ai_contact',
									'status'    => 'cold',
								),
								'description' => __( 'Find leads that have gone cold.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Segment Leads', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'auto_categorize_content',
								'arguments'   => array( 'taxonomy' => 'lead_segment' ),
								'description' => __( 'Segment leads by industry and engagement level.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Personalised Message', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'personalised_email' ),
								'description' => __( 'Create a personalised nurture message for each segment.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Send Messages', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'email' ),
								'description' => __( 'Deliver the personalised messages to leads.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Nurture Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Lead nurture sequence dispatched.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
				'campaign_performance'  => array(
					'name'        => __( 'Campaign Review', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Collect campaign metrics, analyse ROI, generate a report, and broadcast a summary.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'marketing',
					'icon'        => 'dashicons-chart-area',
					'tags'        => array( 'marketing', 'analytics', 'reporting' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Collect Metrics', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_analytics',
								'arguments'   => array( 'metric' => 'conversions' ),
								'description' => __( 'Pull campaign conversion and traffic metrics.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Analyse ROI', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'visualize_workflow_metrics',
								'arguments'   => array( 'mode' => 'roi_analysis' ),
								'description' => __( 'Calculate return on investment for each campaign.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'campaign_report' ),
								'description' => __( 'Compile a visual campaign performance report.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Broadcast Summary', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'marketing' ),
								'description' => __( 'Share the campaign summary with the marketing team.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Review Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Campaign performance review completed.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
				'competitor_analysis'   => array(
					'name'        => __( 'Competitor Watch', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Monitor competitors, compare metrics, summarise findings, and alert the team.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'marketing',
					'icon'        => 'dashicons-visibility',
					'tags'        => array( 'marketing', 'competitors', 'research' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Competitor URLs', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Enter competitor website URLs to monitor.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Monitor Competitors', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'run_crawl4ai_job',
								'arguments'   => array( 'mode' => 'competitor_scan' ),
								'description' => __( 'Crawl competitor sites for changes.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Compare Metrics', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_pagespeed',
								'arguments'   => array(
									'url'      => '{{input.urls}}',
									'strategy' => 'both',
								),
								'description' => __( 'Compare performance metrics against competitors.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Summarise Findings', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'competitive_analysis' ),
								'description' => __( 'Compile a summary of competitive insights.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Alert Team', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'strategy' ),
								'description' => __( 'Notify the strategy team of key findings.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Analysis Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Competitor analysis finished and team notified.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Data presets
		// ------------------------------------------------------------------

		/**
		 * Get data processing and analysis workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Data preset definitions.
		 */
		private static function get_data_presets() {
			return array(
				'data_cleanup_pipeline' => array(
					'name'        => __( 'Data Cleanup', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Audit records, find duplicates, merge them, validate, and generate a report.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'data',
					'icon'        => 'dashicons-database',
					'tags'        => array( 'data', 'cleanup', 'duplicates' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Audit Records', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array( 'post_type' => 'any' ),
								'description' => __( 'Scan all content records for data quality issues.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Find Duplicates', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'semantic_content_search',
								'arguments'   => array( 'threshold' => 0.9 ),
								'description' => __( 'Use semantic search to identify duplicate content.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Duplicates Found?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.duplicate_count > 0',
								'description' => __( 'Check if duplicate records were detected.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Merge Records', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'save_post',
								'arguments'   => array(
									'post_id'    => '{{node_2.canonical_id}}',
									'merge_from' => '{{node_2.duplicate_ids}}',
								),
								'description' => __( 'Merge duplicate records into canonical entries.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Validate Data', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'validate_reasoning_chain',
								'arguments'   => array( 'data_set' => '{{node_4.result}}' ),
								'description' => __( 'Run validation checks on the cleaned data set.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Generate Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'cleanup_report' ),
								'description' => __( 'Create a cleanup summary report.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 900,
							),
							'data'     => array(
								'label'       => __( 'Cleanup Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Data cleanup pipeline finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_5',
							'source'       => 'node_3',
							'target'       => 'node_5',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
				'analytics_digest'      => array(
					'name'        => __( 'Analytics Digest', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Pull metrics, calculate trends, generate charts, and email a report.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'data',
					'icon'        => 'dashicons-chart-line',
					'tags'        => array( 'data', 'analytics', 'reporting' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Pull Metrics', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_analytics',
								'arguments'   => array( 'metric' => 'all' ),
								'description' => __( 'Retrieve site analytics data.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Calculate Trends', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'openai_usage_analytics',
								'arguments'   => array( 'mode' => 'trend_analysis' ),
								'description' => __( 'Identify trends and patterns in the data.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Generate Charts', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'line' ),
								'description' => __( 'Visualise the metrics as charts.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Email Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'email_digest' ),
								'description' => __( 'Send the analytics digest via email.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Digest Sent', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Analytics digest emailed to stakeholders.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Communication presets
		// ------------------------------------------------------------------

		/**
		 * Get messaging and notification workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Communication preset definitions.
		 */
		private static function get_communication_presets() {
			return array(
				'support_escalation' => array(
					'name'        => __( 'Support Escalation', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Check the support queue, identify urgent tickets, assign agents, and notify.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'communication',
					'icon'        => 'dashicons-sos',
					'tags'        => array( 'communication', 'support', 'escalation' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Check Support Queue', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array(
									'post_type' => 'mcp_ai_task',
									'status'    => 'open',
								),
								'description' => __( 'Retrieve open support tickets from the queue.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Identify Urgent Tickets', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_analyze_sentiment',
								'arguments'   => array( 'mode' => 'urgency_detection' ),
								'description' => __( 'Analyse tickets to identify urgent issues.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Urgent Tickets Found?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.urgency_level === "high"',
								'description' => __( 'Check if any tickets require immediate attention.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Assign Agents', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'delegate_to_agent',
								'arguments'   => array( 'priority' => 'high' ),
								'description' => __( 'Assign urgent tickets to available support agents.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Notify Team', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'support' ),
								'description' => __( 'Alert the support team about escalated tickets.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Escalation Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Support escalation workflow finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_6',
							'source'       => 'node_3',
							'target'       => 'node_6',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
				'team_standup'       => array(
					'name'        => __( 'Daily Standup', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Collect status updates from the team, summarise progress, and broadcast to channels.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'communication',
					'icon'        => 'dashicons-megaphone',
					'tags'        => array( 'communication', 'standup', 'team' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Collect Status Updates', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array(
									'post_type'  => 'mcp_ai_task',
									'date_query' => 'today',
								),
								'description' => __( 'Gather recent task updates from team members.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Summarise Progress', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'client_summarize_text',
								'arguments'   => array( 'format' => 'standup_summary' ),
								'description' => __( 'Create a concise standup summary from updates.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Broadcast to Channels', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'general' ),
								'description' => __( 'Post the standup summary to team channels.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Standup Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Daily standup summary has been shared.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Maintenance presets
		// ------------------------------------------------------------------

		/**
		 * Get site maintenance workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Maintenance preset definitions.
		 */
		private static function get_maintenance_presets() {
			return array(
				'health_check'  => array(
					'name'        => __( 'Site Health Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Check site performance, scan for security issues, audit plugins, and generate a report.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'maintenance',
					'icon'        => 'dashicons-heart',
					'tags'        => array( 'maintenance', 'health', 'security' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Check Performance', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'sitekit_get_pagespeed',
								'arguments'   => array( 'strategy' => 'both' ),
								'description' => __( 'Run a PageSpeed performance check.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Scan Security', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'run_crawl4ai_job',
								'arguments'   => array( 'mode' => 'security_scan' ),
								'description' => __( 'Scan for common security vulnerabilities.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Audit Plugins', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'search_content',
								'arguments'   => array( 'type' => 'plugin_audit' ),
								'description' => __( 'Check installed plugins for updates and compatibility.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Issues Found?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_3.issues_count > 0',
								'description' => __( 'Determine if any health issues need attention.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Generate Report', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_chart',
								'arguments'   => array( 'type' => 'health_report' ),
								'description' => __( 'Create a detailed site health report.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Notify Admin', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'admin' ),
								'description' => __( 'Alert the site administrator about issues.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 900,
							),
							'data'     => array(
								'label'       => __( 'Health Check Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Site health check finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_4_7',
							'source'       => 'node_4',
							'target'       => 'node_7',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
				'backup_verify' => array(
					'name'        => __( 'Backup Verify', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Trigger a backup, verify its integrity, log the result, and notify the admin.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'maintenance',
					'icon'        => 'dashicons-backup',
					'tags'        => array( 'maintenance', 'backup', 'verification' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Trigger Backup', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'execute_workflow',
								'arguments'   => array( 'action' => 'backup_database' ),
								'description' => __( 'Initiate a full site backup.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Verify Integrity', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'validate_workflow',
								'arguments'   => array( 'check' => 'backup_integrity' ),
								'description' => __( 'Validate the backup file integrity.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Backup Valid?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.is_valid === true',
								'description' => __( 'Check if the backup passed integrity verification.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Log Success', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'mcp_ai_task',
									'post_status' => 'publish',
								),
								'description' => __( 'Record the successful backup in the log.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 400,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Log Failure', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'mcp_ai_task',
									'post_status' => 'publish',
									'priority'    => 'high',
								),
								'description' => __( 'Record the backup failure for investigation.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Notify Admin', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'admin' ),
								'description' => __( 'Send backup status notification to the admin.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Backup Workflow Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Backup verification process finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_3_5',
							'source'       => 'node_3',
							'target'       => 'node_5',
							'sourceHandle' => 'false',
						),
						array(
							'id'           => 'edge_4_6',
							'source'       => 'node_4',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Onboarding presets
		// ------------------------------------------------------------------

		/**
		 * Get user and content onboarding workflow presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Onboarding preset definitions.
		 */
		private static function get_onboarding_presets() {
			return array(
				'user_onboarding' => array(
					'name'        => __( 'User Onboarding', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Detect a new user, create welcome content, assign resources, and send a welcome message.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'onboarding',
					'icon'        => 'dashicons-admin-users',
					'tags'        => array( 'onboarding', 'users', 'welcome' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'New User Detected', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Triggered when a new user registers.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Create Welcome Content', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_post',
								'arguments'   => array(
									'post_type'   => 'page',
									'post_status' => 'publish',
								),
								'description' => __( 'Generate a personalised welcome page for the user.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Assign Resources', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'delegate_to_agent',
								'arguments'   => array( 'task' => 'resource_assignment' ),
								'description' => __( 'Assign onboarding resources and tutorials to the user.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Generate Welcome Image', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'generate_openai_image',
								'arguments'   => array( 'prompt' => 'welcome banner' ),
								'description' => __( 'Create a personalised welcome banner.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Send Welcome Message', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'probe_chat',
								'arguments'   => array( 'channel' => 'welcome' ),
								'description' => __( 'Send the welcome message to the new user.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Onboarding Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'User onboarding workflow finished.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		/**
		 * Get Outreach admissibility workflow presets (Proposal 129).
		 *
		 * @since  3.3.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_outreach_presets() {
			return array(
				'outreach_readiness_gate' => array(
					'name'        => __( 'Outreach Readiness Gate', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Check domain authentication and sending readiness, then build a signal cohort and export it only when the readiness gate passes.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'outreach',
					'icon'        => 'dashicons-shield-alt',
					'tags'        => array( 'crm', 'outreach', 'deliverability', 'signals', 'cohort' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Outreach Cycle', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Start a campaign preparation cycle.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Check Sending Domain', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'check_sending_domain',
								'arguments'   => array(),
								'description' => __( 'Verify SPF, DKIM and DMARC records.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Get Sending Readiness', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_sending_readiness',
								'arguments'   => array(),
								'description' => __( 'Score warmup, bounce, complaint and verified coverage.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Ready to Send?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_3.ready == true',
								'description' => __( 'Only proceed when no readiness blockers remain.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Build Signal Cohort', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'query_signal_cohort',
								'arguments'   => array(
									'must'  => array( 'no_online_booking' ),
									'limit' => 50,
								),
								'description' => __( 'Count and sample leads with the confirmed buying signal.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 750,
							),
							'data'     => array(
								'label'       => __( 'Export Outreach CSV', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'export_outreach_csv',
								'arguments'   => array(
									'limit'              => 500,
									'include_suppressed' => false,
								),
								'description' => __( 'Write a sequencer-ready CSV with evidence and verification status.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_7',
							'type'     => 'output',
							'position' => array(
								'x' => 100,
								'y' => 900,
							),
							'data'     => array(
								'label'       => __( 'Audience Ready', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Readiness passed and the cohort was exported.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_8',
							'type'     => 'output',
							'position' => array(
								'x' => 400,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Blocked — Fix Readiness', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Resolve the readiness blockers before building the list.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_5_6',
							'source'       => 'node_5',
							'target'       => 'node_6',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_6_7',
							'source'       => 'node_6',
							'target'       => 'node_7',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_4_8',
							'source'       => 'node_4',
							'target'       => 'node_8',
							'sourceHandle' => 'false',
						),
					),
				),
				'outreach_held_review'    => array(
					'name'        => __( 'Outreach Held-Mail Review', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'List held outbox mail and dry-run the gate on the first held message so a human can read why it was stopped before approving.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'outreach',
					'icon'        => 'dashicons-email-alt',
					'tags'        => array( 'crm', 'outreach', 'approval', 'held', 'gate' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Daily Review', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Start the held-mail review.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'List Held Mail', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'review_held_send',
								'arguments'   => array(
									'action' => 'list',
									'limit'  => 20,
								),
								'description' => __( 'List messages held by the gate or agent guard.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'condition',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Any Held?', 'nvdigital-open-operator-system-oos-pro' ),
								'expression'  => 'node_2.count > 0',
								'description' => __( 'Only review when held mail exists.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'tool',
							'position' => array(
								'x' => 100,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Preview First Held Draft', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'preview_pre_send_gate',
								'arguments'   => array(
									'lead_id' => '{{node_2.held.0.lead_id}}',
									'body'    => '{{node_2.held.0.body}}',
								),
								'description' => __( 'Dry-run the gate on the first held message.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_5',
							'type'     => 'output',
							'position' => array(
								'x' => 100,
								'y' => 600,
							),
							'data'     => array(
								'label'       => __( 'Read Each Held Message', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Approve or reject each held message individually.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_6',
							'type'     => 'output',
							'position' => array(
								'x' => 400,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'No Held Mail', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Nothing needs review today.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'true',
						),
						array(
							'id'           => 'edge_4_5',
							'source'       => 'node_4',
							'target'       => 'node_5',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_6',
							'source'       => 'node_3',
							'target'       => 'node_6',
							'sourceHandle' => 'false',
						),
					),
				),
			);
		}

		/**
		 * Get CRM Support Ticket workflow presets.
		 *
		 * @since  2.6.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_crm_support_presets() {
			return array(
				'support_ticket_triage'        => array(
					'name'        => __( 'Support Ticket Triage', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Auto-triage pipeline: classify incoming support tickets, suggest priority and category, assign to the right team member.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'crm_support',
					'icon'        => 'dashicons-sos',
					'tags'        => array( 'crm', 'support', 'triage', 'classification' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'New Ticket Created', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Triggered when a new support ticket is created.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Classify Ticket', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'AI classifies the ticket category and suggests priority.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'classify_support_ticket',
								'arguments'   => array( 'apply_results' => true ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Update Status', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Move ticket to Triaged status.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'update_support_ticket',
								'arguments'   => array( 'status' => 'triaged' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Ticket Triaged', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Ticket is classified and ready for agent.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
				'support_ticket_resolution'    => array(
					'name'        => __( 'Support Ticket Resolution', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Resolution workflow: review ticket, add resolution notes, mark as resolved, and trigger CSAT survey.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'crm_support',
					'icon'        => 'dashicons-yes-alt',
					'tags'        => array( 'crm', 'support', 'resolution', 'csat' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Ticket in Progress', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Ticket is being worked on by an agent.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Add Resolution Note', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Add internal resolution note to the ticket.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'update_support_ticket',
								'arguments'   => array( 'note' => 'Resolution note' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Resolve Ticket', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Mark the ticket as resolved.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'resolve_support_ticket',
								'arguments'   => array( 'resolution_type' => 'solved' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Ticket Resolved + CSAT Queued', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Resolution complete, CSAT survey triggered.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
				'support_escalation_handling'  => array(
					'name'        => __( 'Support Escalation Handling', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Escalation workflow: detect SLA breaches, escalate priority, notify managers, and update ticket status.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'crm_support',
					'icon'        => 'dashicons-warning',
					'tags'        => array( 'crm', 'support', 'escalation', 'sla' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'SLA Breach Detected', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'A ticket SLA has been breached or is at risk.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Escalate Priority', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Bump the ticket priority level.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'escalate_support_ticket',
								'arguments'   => array( 'new_priority' => 'high' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Get SLA Report', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Generate updated SLA compliance report.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_ticket_sla_report',
								'arguments'   => array( 'group_by' => 'assignee' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Escalation Complete', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Ticket escalated and managers notified.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),

				// -- Customer Management workflow presets (v2.6.0) --
				'lead_to_customer_conversion'  => array(
					'name'        => __( 'Lead-to-Customer Conversion', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'End-to-end lead conversion pipeline: qualify lead, convert to customer record, create linked deal.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'crm_support',
					'icon'        => 'dashicons-update',
					'tags'        => array( 'crm', 'customers', 'conversion', 'pipeline' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Lead Ready for Conversion', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Lead has reached SQL/Opportunity stage.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Qualify Lead (BANT)', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Run BANT qualification to validate lead readiness.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'qualify_lead_bant',
								'arguments'   => array( 'lead_id' => '{{input.lead_id}}' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Convert to Customer', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Create customer record with linked deal.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'convert_lead_to_customer',
								'arguments'   => array( 'create_deal' => true ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Customer Created + Deal Open', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Customer record created with linked deal in pipeline.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
				'customer_onboarding_sequence' => array(
					'name'        => __( 'Customer Onboarding', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Post-conversion onboarding workflow: create welcome activity and schedule follow-up.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'crm_support',
					'icon'        => 'dashicons-welcome-learn-more',
					'tags'        => array( 'crm', 'customers', 'onboarding', 'automation' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Customer Created', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'A new customer record has been created.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Get Customer Details', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Retrieve full customer record.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'get_customer',
								'arguments'   => array( 'customer_id' => '{{input.customer_id}}' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Create Welcome Activity', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Schedule a welcome call or onboarding meeting.', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'create_crm_activity',
								'arguments'   => array(
									'activity_type' => 'call',
									'subject'       => 'Customer Welcome Call',
								),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Onboarding Initiated', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Welcome activity created, onboarding sequence started.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Fashion presets
		// ------------------------------------------------------------------

		/**
		 * Get AI fashion production workflow presets.
		 *
		 * These presets reference the fashion_* Pro tools, which only
		 * register when the NV oOS Media Studio addon is active; the
		 * builder marks missing tools as unavailable nodes.
		 *
		 * @since  1.1.91
		 * @return array<string, array> Fashion preset definitions.
		 */
		private static function get_fashion_presets() {
			return array(
				'fashion_product_creative' => array(
					'name'        => __( 'Product Image Creative Pipeline', 'nvdigital-open-operator-system-oos-pro' ),
					'description' => __( 'Turn a flat product photo into an on-model lifestyle image, then a marketplace-ready packshot.', 'nvdigital-open-operator-system-oos-pro' ),
					'category'    => 'fashion',
					'icon'        => 'dashicons-businessperson',
					'tags'        => array( 'fashion', 'media', 'ecommerce', 'ai' ),
					'nodes'       => array(
						array(
							'id'       => 'node_1',
							'type'     => 'input',
							'position' => array(
								'x' => 250,
								'y' => 0,
							),
							'data'     => array(
								'label'       => __( 'Product Image', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'Media Library attachment ID of the product photo.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_2',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 150,
							),
							'data'     => array(
								'label'       => __( 'Generate On-Model', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'fashion_onmodel_generate',
								'arguments'   => array( 'attachment_id' => '{{input.attachment_id}}' ),
								'description' => __( 'Render the garment on an AI model.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_3',
							'type'     => 'tool',
							'position' => array(
								'x' => 250,
								'y' => 300,
							),
							'data'     => array(
								'label'       => __( 'Marketplace Packshot', 'nvdigital-open-operator-system-oos-pro' ),
								'toolSlug'    => 'fashion_packshot',
								'arguments'   => array( 'attachment_id' => '{{node_2.attachment_id}}' ),
								'description' => __( 'Produce a white-background packshot of the on-model result.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
						array(
							'id'       => 'node_4',
							'type'     => 'output',
							'position' => array(
								'x' => 250,
								'y' => 450,
							),
							'data'     => array(
								'label'       => __( 'Creative Ready', 'nvdigital-open-operator-system-oos-pro' ),
								'description' => __( 'On-model lifestyle and packshot variants are ready for review.', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
					'edges'       => array(
						array(
							'id'           => 'edge_1_2',
							'source'       => 'node_1',
							'target'       => 'node_2',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_2_3',
							'source'       => 'node_2',
							'target'       => 'node_3',
							'sourceHandle' => 'output',
						),
						array(
							'id'           => 'edge_3_4',
							'source'       => 'node_3',
							'target'       => 'node_4',
							'sourceHandle' => 'output',
						),
					),
				),
			);
		}
	}
}
