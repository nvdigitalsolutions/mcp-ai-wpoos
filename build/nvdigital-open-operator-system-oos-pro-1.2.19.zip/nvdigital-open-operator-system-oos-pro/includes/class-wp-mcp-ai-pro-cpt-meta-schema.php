<?php
/**
 * Pro CPT Meta Schema Registry.
 *
 * Registers custom meta-field definitions for every CPT managed by the pro
 * toolkit so they are exposed via the `get_post_type_schema` base tool.
 *
 * @package WP_MCP_AI_Pro
 * @since   3.4.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides custom meta-field schema definitions for all pro-managed CPTs.
 *
 * Other code can retrieve the schema for a specific CPT via:
 *   apply_filters( 'wp_mcp_ai_post_type_meta_schema', array(), $post_type )
 *
 * or directly:
 *   WP_MCP_AI_Pro_CPT_Meta_Schema::get( 'mcp_ai_task' )
 */
class WP_MCP_AI_Pro_CPT_Meta_Schema {

	/**
	 * Initialize the class by hooking into the base tool filter.
	 *
	 * @since 3.4.0
	 */
	public static function init() {
		add_filter( 'wp_mcp_ai_post_type_meta_schema', array( __CLASS__, 'filter_meta_schema' ), 10, 2 );
	}

	/**
	 * Filter callback: inject the pro meta schema for a given post type.
	 *
	 * @param array  $schema    Existing meta schema (may be populated by other hooks).
	 * @param string $post_type The post type slug being described.
	 * @return array Merged meta schema.
	 */
	public static function filter_meta_schema( $schema, $post_type ) {
		$pro_schema = self::get( $post_type );
		if ( ! empty( $pro_schema ) ) {
			$schema = array_merge( $schema, $pro_schema );
		}
		return $schema;
	}

	/**
	 * Return the meta-field schema for a given pro-managed CPT.
	 *
	 * Each entry is keyed by the meta key (without the leading underscore used
	 * for internal storage) and contains:
	 *   - meta_key   (string)  Actual storage key used in get/update_post_meta.
	 *   - label      (string)  Human-readable field label.
	 *   - type       (string)  JSON-Schema primitive: string|integer|number|boolean|array|object.
	 *   - description (string) What the field stores.
	 *   - enum       (array)   Optional list of allowed values.
	 *
	 * @param string $post_type The CPT slug.
	 * @return array Meta field definitions, or empty array for unknown post types.
	 */
	public static function get( $post_type ) {
		$schemas = self::all_schemas();
		return isset( $schemas[ $post_type ] ) ? $schemas[ $post_type ] : array();
	}

	/**
	 * Return meta schemas for all pro-managed CPTs.
	 *
	 * @return array Associative array keyed by CPT slug.
	 */
	public static function all_schemas() {
		return array(

			// ----------------------------------------------------------------
			// Project Management Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_task'         => array(
				'_task_status'           => array(
					'meta_key'    => '_task_status',
					'label'       => __( 'Task Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Current workflow status of the task.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'todo', 'in-progress', 'review', 'completed', 'cancelled' ),
				),
				'_task_priority'         => array(
					'meta_key'    => '_task_priority',
					'label'       => __( 'Priority', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Task urgency level.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'low', 'medium', 'high', 'urgent' ),
				),
				'_task_category'         => array(
					'meta_key'    => '_task_category',
					'label'       => __( 'Category', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Task category/type.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'general', 'bug', 'feature', 'maintenance', 'research', 'documentation', 'design', 'testing' ),
				),
				'_task_project_id'       => array(
					'meta_key'    => '_task_project_id',
					'label'       => __( 'Project ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the parent mcp_ai_project post.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_task_due_date'         => array(
					'meta_key'    => '_task_due_date',
					'label'       => __( 'Due Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Due date in YYYY-MM-DD format.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_task_assigned_to'      => array(
					'meta_key'    => '_task_assigned_to',
					'label'       => __( 'Assigned To', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'WordPress user ID the task is assigned to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_task_tags'             => array(
					'meta_key'    => '_task_tags',
					'label'       => __( 'Tags', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Comma-separated list of tags.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_task_estimated_effort' => array(
					'meta_key'    => '_task_estimated_effort',
					'label'       => __( 'Estimated Effort (hours)', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Estimated hours required to complete the task.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_task_actual_effort'    => array(
					'meta_key'    => '_task_actual_effort',
					'label'       => __( 'Actual Effort (hours)', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Actual hours spent on the task.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_project'      => array(
				'_project_status'      => array(
					'meta_key'    => '_project_status',
					'label'       => __( 'Project Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Current phase of the project.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'planning', 'active', 'on-hold', 'completed', 'cancelled' ),
				),
				'_project_start_date'  => array(
					'meta_key'    => '_project_start_date',
					'label'       => __( 'Start Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Project start date in YYYY-MM-DD format.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_project_end_date'    => array(
					'meta_key'    => '_project_end_date',
					'label'       => __( 'End Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Project end/deadline date in YYYY-MM-DD format.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_project_assigned_to' => array(
					'meta_key'    => '_project_assigned_to',
					'label'       => __( 'Assigned To', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Array of WordPress user IDs assigned to the project.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_task_plan'       => array(
				'_goal'        => array(
					'meta_key'    => '_goal',
					'label'       => __( 'Goal', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'High-level goal the plan is intended to achieve.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_task_count'  => array(
					'meta_key'    => '_task_count',
					'label'       => __( 'Task Count', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Number of tasks defined in the plan.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_project_id'  => array(
					'meta_key'    => '_project_id',
					'label'       => __( 'Project ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the mcp_ai_project this plan belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_template_id' => array(
					'meta_key'    => '_template_id',
					'label'       => __( 'Template ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the mcp_task_template used to generate this plan.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_task_template'   => array(
				'_category'     => array(
					'meta_key'    => '_category',
					'label'       => __( 'Category', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Template category for filtering.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_task_count'   => array(
					'meta_key'    => '_task_count',
					'label'       => __( 'Task Count', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Number of tasks defined in the template.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_placeholders' => array(
					'meta_key'    => '_placeholders',
					'label'       => __( 'Placeholders', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'List of {{placeholder}} tokens found in the template markdown.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Event Management Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_event'        => array(
				'_event_start_date' => array(
					'meta_key'    => '_event_start_date',
					'label'       => __( 'Start Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Event start date in YYYY-MM-DD format.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_event_end_date'   => array(
					'meta_key'    => '_event_end_date',
					'label'       => __( 'End Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Event end date in YYYY-MM-DD format. Defaults to start date for single-day events.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_event_start_time' => array(
					'meta_key'    => '_event_start_time',
					'label'       => __( 'Start Time', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Event start time in HH:MM (24-hour) format. Empty for all-day events.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_event_end_time'   => array(
					'meta_key'    => '_event_end_time',
					'label'       => __( 'End Time', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Event end time in HH:MM (24-hour) format.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_event_all_day'    => array(
					'meta_key'    => '_event_all_day',
					'label'       => __( 'All Day', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'boolean',
					'description' => __( 'Whether the event spans the entire day (stored as "1" or "0").', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_event_type'       => array(
					'meta_key'    => '_event_type',
					'label'       => __( 'Event Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Classification of the event.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'meeting', 'deadline', 'milestone', 'reminder', 'other' ),
				),
				'_event_location'   => array(
					'meta_key'    => '_event_location',
					'label'       => __( 'Location', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Physical or virtual location for the event.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_event_attendees'  => array(
					'meta_key'    => '_event_attendees',
					'label'       => __( 'Attendees', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of WordPress user IDs attending the event.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_event_project_id' => array(
					'meta_key'    => '_event_project_id',
					'label'       => __( 'Project ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the mcp_ai_project this event is associated with.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Places Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_place'        => array(
				'_place_type'               => array(
					'meta_key'    => '_place_type',
					'label'       => __( 'Place Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Category of the place (e.g. restaurant, hotel, museum, park).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_address'            => array(
					'meta_key'    => '_place_address',
					'label'       => __( 'Full Address', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Full street address as a single string.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_latitude'           => array(
					'meta_key'    => '_place_latitude',
					'label'       => __( 'Latitude', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Latitude coordinate (−90 to 90).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_longitude'          => array(
					'meta_key'    => '_place_longitude',
					'label'       => __( 'Longitude', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Longitude coordinate (−180 to 180).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_address_components' => array(
					'meta_key'    => '_place_address_components',
					'label'       => __( 'Address Components', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'object',
					'description' => __( 'Structured address parts (street, city, state, country, postal_code).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_phone'              => array(
					'meta_key'    => '_place_phone',
					'label'       => __( 'Phone', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Contact phone number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_email'              => array(
					'meta_key'    => '_place_email',
					'label'       => __( 'Email', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Contact email address.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_website'            => array(
					'meta_key'    => '_place_website',
					'label'       => __( 'Website', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Website URL.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_rating'             => array(
					'meta_key'    => '_place_rating',
					'label'       => __( 'Rating', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Overall rating from 0 to 5.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_price_level'        => array(
					'meta_key'    => '_place_price_level',
					'label'       => __( 'Price Level', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Price tier from 1 (cheapest) to 4 (most expensive).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_business_hours'     => array(
					'meta_key'    => '_place_business_hours',
					'label'       => __( 'Business Hours', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'object',
					'description' => __( 'Serialized object of hours by weekday (monday, tuesday, … sunday).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_amenities'          => array(
					'meta_key'    => '_place_amenities',
					'label'       => __( 'Amenities', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of amenity slugs (e.g. "wifi", "parking").', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_place_google_place_id'    => array(
					'meta_key'    => '_place_google_place_id',
					'label'       => __( 'Google Place ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Google Places API identifier for this location.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Health & Wellness Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_member'       => array(
				'_member_date_of_birth'      => array(
					'meta_key'    => '_member_date_of_birth',
					'label'       => __( 'Date of Birth', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Date of birth in YYYY-MM-DD format.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_member_gender'             => array(
					'meta_key'    => '_member_gender',
					'label'       => __( 'Gender', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Self-reported gender.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_member_blood_type'         => array(
					'meta_key'    => '_member_blood_type',
					'label'       => __( 'Blood Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'ABO blood group (e.g. A+, O−).', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-' ),
				),
				'_member_email'              => array(
					'meta_key'    => '_member_email',
					'label'       => __( 'Email', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Contact email address for the member.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_member_phone'              => array(
					'meta_key'    => '_member_phone',
					'label'       => __( 'Phone', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Contact phone number for the member.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_member_address'            => array(
					'meta_key'    => '_member_address',
					'label'       => __( 'Address', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Physical address of the member.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_member_emergency_contact'  => array(
					'meta_key'    => '_member_emergency_contact',
					'label'       => __( 'Emergency Contact', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Emergency contact name and details.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_member_mrn'                => array(
					'meta_key'    => '_member_mrn',
					'label'       => __( 'Medical Record Number (MRN)', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Internal or provider-assigned medical record number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_member_preferred_pharmacy' => array(
					'meta_key'    => '_member_preferred_pharmacy',
					'label'       => __( 'Preferred Pharmacy', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Preferred pharmacy name and/or address.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_pet_species'               => array(
					'meta_key'    => '_pet_species',
					'label'       => __( 'Species (pet)', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Animal species when member type is "pet".', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_pet_breed'                 => array(
					'meta_key'    => '_pet_breed',
					'label'       => __( 'Breed (pet)', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Animal breed when member type is "pet".', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_med_record'   => array(
				'_medical_record_member_id'           => array(
					'meta_key'    => '_medical_record_member_id',
					'label'       => __( 'Member ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the mcp_ai_member this record belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_medical_record_date'                => array(
					'meta_key'    => '_medical_record_date',
					'label'       => __( 'Record Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Date the medical record was created (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_medical_record_icd_code'            => array(
					'meta_key'    => '_medical_record_icd_code',
					'label'       => __( 'ICD-10 Code', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'ICD-10-CM diagnosis code (e.g. J18.9).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_medical_record_lab_value'           => array(
					'meta_key'    => '_medical_record_lab_value',
					'label'       => __( 'Lab Value', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Numeric or text result of a lab test.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_medical_record_lab_unit'            => array(
					'meta_key'    => '_medical_record_lab_unit',
					'label'       => __( 'Lab Unit', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Unit of measure for the lab value (e.g. mg/dL, mmol/L).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_medical_record_lab_reference_range' => array(
					'meta_key'    => '_medical_record_lab_reference_range',
					'label'       => __( 'Lab Reference Range', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Normal range for the lab value (e.g. "70–100").', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_medical_record_lab_abnormal'        => array(
					'meta_key'    => '_medical_record_lab_abnormal',
					'label'       => __( 'Abnormal Flag', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'boolean',
					'description' => __( 'Whether the lab result is outside the reference range.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_medical_record_provider'            => array(
					'meta_key'    => '_medical_record_provider',
					'label'       => __( 'Provider', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Name of the healthcare provider or facility.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_allergy'      => array(
				'_allergy_member_id'          => array(
					'meta_key'    => '_allergy_member_id',
					'label'       => __( 'Member ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the mcp_ai_member this allergy record belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_allergy_allergen'           => array(
					'meta_key'    => '_allergy_allergen',
					'label'       => __( 'Allergen', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'The substance causing the allergic reaction.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_allergy_severity'           => array(
					'meta_key'    => '_allergy_severity',
					'label'       => __( 'Severity', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Clinical severity of the allergy.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'mild', 'moderate', 'severe', 'life-threatening' ),
				),
				'_allergy_type'               => array(
					'meta_key'    => '_allergy_type',
					'label'       => __( 'Allergy Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'FHIR allergy category.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'food', 'medication', 'environment', 'biologic', 'other' ),
				),
				'_allergy_onset_type'         => array(
					'meta_key'    => '_allergy_onset_type',
					'label'       => __( 'Onset Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Speed of allergic reaction onset.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'immediate', 'delayed' ),
				),
				'_allergy_treatment'          => array(
					'meta_key'    => '_allergy_treatment',
					'label'       => __( 'Treatment', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Treatment or management notes for the allergy.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_allergy_reactions'          => array(
					'meta_key'    => '_allergy_reactions',
					'label'       => __( 'Reactions', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Comma-separated list of observed reaction symptoms.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_allergy_diagnosed_date'     => array(
					'meta_key'    => '_allergy_diagnosed_date',
					'label'       => __( 'Diagnosed Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Date allergy was first diagnosed (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_allergy_last_reaction_date' => array(
					'meta_key'    => '_allergy_last_reaction_date',
					'label'       => __( 'Last Reaction Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Date of the most recent allergic reaction (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_prescription' => array(
				'_prescription_member_id'         => array(
					'meta_key'    => '_prescription_member_id',
					'label'       => __( 'Member ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the mcp_ai_member this prescription belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_medication_name'   => array(
					'meta_key'    => '_prescription_medication_name',
					'label'       => __( 'Medication Name', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Brand or generic name of the prescribed medication.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_dosage'            => array(
					'meta_key'    => '_prescription_dosage',
					'label'       => __( 'Dosage', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Dosage strength (e.g. "10mg").', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_frequency'         => array(
					'meta_key'    => '_prescription_frequency',
					'label'       => __( 'Frequency', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Administration frequency (e.g. "twice daily").', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_status'            => array(
					'meta_key'    => '_prescription_status',
					'label'       => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Current prescription status.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'active', 'completed', 'discontinued', 'on-hold' ),
				),
				'_prescription_doctor'            => array(
					'meta_key'    => '_prescription_doctor',
					'label'       => __( 'Prescribing Doctor', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Name of the prescribing physician.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_start_date'        => array(
					'meta_key'    => '_prescription_start_date',
					'label'       => __( 'Start Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Date prescription was started (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_end_date'          => array(
					'meta_key'    => '_prescription_end_date',
					'label'       => __( 'End Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Date prescription ends or ended (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_refills_remaining' => array(
					'meta_key'    => '_prescription_refills_remaining',
					'label'       => __( 'Refills Remaining', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Number of refills remaining on the prescription.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_rx_number'         => array(
					'meta_key'    => '_prescription_rx_number',
					'label'       => __( 'Rx Number', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Pharmacy prescription number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_ndc_code'          => array(
					'meta_key'    => '_prescription_ndc_code',
					'label'       => __( 'NDC Code', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'National Drug Code (11-digit, format: XXXXX-XXXX-XX).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_route'             => array(
					'meta_key'    => '_prescription_route',
					'label'       => __( 'Route', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Route of administration (e.g. oral, topical, injection).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_quantity'          => array(
					'meta_key'    => '_prescription_quantity',
					'label'       => __( 'Quantity', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Quantity dispensed per fill.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_quantity_unit'     => array(
					'meta_key'    => '_prescription_quantity_unit',
					'label'       => __( 'Quantity Unit', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Unit of the dispensed quantity (e.g. tablets, mL).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_prescription_indication'        => array(
					'meta_key'    => '_prescription_indication',
					'label'       => __( 'Indication', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Medical reason or diagnosis for which the medication was prescribed.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_checkup'      => array(
				'_checkup_member_id'        => array(
					'meta_key'    => '_checkup_member_id',
					'label'       => __( 'Member ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the mcp_ai_member this checkup belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_checkup_datetime'         => array(
					'meta_key'    => '_checkup_datetime',
					'label'       => __( 'Appointment Date/Time', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'ISO 8601 datetime of the appointment (YYYY-MM-DD HH:MM).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_checkup_status'           => array(
					'meta_key'    => '_checkup_status',
					'label'       => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Appointment status.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'scheduled', 'completed', 'cancelled', 'no-show' ),
				),
				'_checkup_provider'         => array(
					'meta_key'    => '_checkup_provider',
					'label'       => __( 'Provider', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Name of the healthcare provider or practice.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_checkup_location'         => array(
					'meta_key'    => '_checkup_location',
					'label'       => __( 'Location', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Clinic, hospital, or virtual appointment location.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_checkup_type'             => array(
					'meta_key'    => '_checkup_type',
					'label'       => __( 'Appointment Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Kind of medical appointment (e.g. annual, specialist, follow-up).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_checkup_chief_complaint'  => array(
					'meta_key'    => '_checkup_chief_complaint',
					'label'       => __( 'Chief Complaint', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Primary reason for the visit in the patient\'s own words.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_checkup_diagnosis'        => array(
					'meta_key'    => '_checkup_diagnosis',
					'label'       => __( 'Diagnosis', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Diagnosis or assessment made during the visit.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_checkup_duration_minutes' => array(
					'meta_key'    => '_checkup_duration_minutes',
					'label'       => __( 'Duration (minutes)', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Length of the appointment in minutes.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_checkup_copay_amount'     => array(
					'meta_key'    => '_checkup_copay_amount',
					'label'       => __( 'Copay Amount', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Patient copay amount paid at the visit.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_checkup_follow_up_date'   => array(
					'meta_key'    => '_checkup_follow_up_date',
					'label'       => __( 'Follow-Up Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Scheduled follow-up date (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_policy'       => array(
				'_policy_member_id'         => array(
					'meta_key'    => '_policy_member_id',
					'label'       => __( 'Member ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the mcp_ai_member this insurance policy belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_number'            => array(
					'meta_key'    => '_policy_number',
					'label'       => __( 'Policy Number', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Insurance policy or member ID number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_group_number'      => array(
					'meta_key'    => '_policy_group_number',
					'label'       => __( 'Group Number', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Employer or plan group number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_plan_type'         => array(
					'meta_key'    => '_policy_plan_type',
					'label'       => __( 'Plan Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Insurance plan category (e.g. HMO, PPO, EPO, HDHP).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_copay_primary'     => array(
					'meta_key'    => '_policy_copay_primary',
					'label'       => __( 'Primary Care Copay', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Copay amount for primary care visits.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_copay_specialist'  => array(
					'meta_key'    => '_policy_copay_specialist',
					'label'       => __( 'Specialist Copay', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Copay amount for specialist visits.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_deductible'        => array(
					'meta_key'    => '_policy_deductible',
					'label'       => __( 'Deductible', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Annual deductible amount.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_out_of_pocket_max' => array(
					'meta_key'    => '_policy_out_of_pocket_max',
					'label'       => __( 'Out-of-Pocket Maximum', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Annual out-of-pocket maximum.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_rx_bin'            => array(
					'meta_key'    => '_policy_rx_bin',
					'label'       => __( 'Rx BIN', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Pharmacy Benefit Manager bank identification number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_rx_pcn'            => array(
					'meta_key'    => '_policy_rx_pcn',
					'label'       => __( 'Rx PCN', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Processor Control Number for pharmacy claims.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_rx_group'          => array(
					'meta_key'    => '_policy_rx_group',
					'label'       => __( 'Rx Group', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Pharmacy benefit group number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_provider'          => array(
					'meta_key'    => '_policy_provider',
					'label'       => __( 'Insurance Provider', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Name of the insurance company.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_status'            => array(
					'meta_key'    => '_policy_status',
					'label'       => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Current policy status.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'active', 'inactive', 'pending', 'cancelled' ),
				),
				'_policy_effective_date'    => array(
					'meta_key'    => '_policy_effective_date',
					'label'       => __( 'Effective Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Policy effective/start date (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_policy_expiration_date'   => array(
					'meta_key'    => '_policy_expiration_date',
					'label'       => __( 'Expiration Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Policy expiration date (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Education / iSAMS Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_student'      => array(
				'_student_first_name'      => array(
					'meta_key'    => '_student_first_name',
					'label'       => __( 'First Name', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Student\'s given (first) name.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_student_last_name'       => array(
					'meta_key'    => '_student_last_name',
					'label'       => __( 'Last Name', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Student\'s family (last) name.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_student_year_group'      => array(
					'meta_key'    => '_student_year_group',
					'label'       => __( 'Year Group', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Academic year group or grade level (e.g. "Year 10", "Grade 5").', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_student_house'           => array(
					'meta_key'    => '_student_house',
					'label'       => __( 'House', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'School house or homeroom group.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_student_email'           => array(
					'meta_key'    => '_student_email',
					'label'       => __( 'Email', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Student\'s school or personal email address.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_student_isams_id'        => array(
					'meta_key'    => '_student_isams_id',
					'label'       => __( 'iSAMS ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Unique identifier from the iSAMS MIS system.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_student_google_id'       => array(
					'meta_key'    => '_student_google_id',
					'label'       => __( 'Google Classroom ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Google Classroom user ID, used to match roster members during Classroom sync.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_student_google_email'    => array(
					'meta_key'    => '_student_google_email',
					'label'       => __( 'Google Email', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Google account email used as the fallback match key during Classroom sync.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_student_eca_enrollments' => array(
					'meta_key'    => '_student_eca_enrollments',
					'label'       => __( 'ECA Enrollments', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of mcp_ai_eca post IDs the student is enrolled in.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_eca'          => array(
				'_eca_code'              => array(
					'meta_key'    => '_eca_code',
					'label'       => __( 'ECA Code', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Short code identifier for the extra-curricular activity.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_type'              => array(
					'meta_key'    => '_eca_type',
					'label'       => __( 'ECA Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Category of activity (e.g. sport, arts, academic, service).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_google_course_id'  => array(
					'meta_key'    => '_eca_google_course_id',
					'label'       => __( 'Google Classroom Course ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Google Classroom course linked to this ECA. Used by the Classroom sync, announcement, and analytics tools.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_classroom_sync'    => array(
					'meta_key'    => '_eca_classroom_sync',
					'label'       => __( 'Classroom Sync Direction', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Sync direction for the linked Classroom course: off, roster-in, or bi-directional.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_day'               => array(
					'meta_key'    => '_eca_day',
					'label'       => __( 'Day', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Day of the week the activity runs.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_start_time'        => array(
					'meta_key'    => '_eca_start_time',
					'label'       => __( 'Start Time', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Activity start time in HH:MM (24-hour) format.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_end_time'          => array(
					'meta_key'    => '_eca_end_time',
					'label'       => __( 'End Time', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Activity end time in HH:MM (24-hour) format.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_venue'             => array(
					'meta_key'    => '_eca_venue',
					'label'       => __( 'Venue', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Location where the activity takes place.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_max_students'      => array(
					'meta_key'    => '_eca_max_students',
					'label'       => __( 'Max Students', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Maximum number of students allowed to enroll.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_year_groups'       => array(
					'meta_key'    => '_eca_year_groups',
					'label'       => __( 'Eligible Year Groups', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of year groups eligible for this ECA.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_teachers'          => array(
					'meta_key'    => '_eca_teachers',
					'label'       => __( 'Teachers / Staff', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of WordPress user IDs supervising the activity.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_is_paid'           => array(
					'meta_key'    => '_eca_is_paid',
					'label'       => __( 'Paid Activity', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'boolean',
					'description' => __( 'Whether the activity requires a participation fee ("yes"/"no").', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_cost'              => array(
					'meta_key'    => '_eca_cost',
					'label'       => __( 'Cost', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Participation fee amount.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_cost_period'       => array(
					'meta_key'    => '_eca_cost_period',
					'label'       => __( 'Cost Period', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Billing period for the cost (e.g. per_term, per_year, one_time).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_requires_audition' => array(
					'meta_key'    => '_eca_requires_audition',
					'label'       => __( 'Requires Audition', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'boolean',
					'description' => __( 'Whether students must audition or try out to join ("yes"/"no").', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_booking_type'      => array(
					'meta_key'    => '_eca_booking_type',
					'label'       => __( 'Booking Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'How enrollment is handled (e.g. open, audition, invite_only).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_eca_status'            => array(
					'meta_key'    => '_eca_status',
					'label'       => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Activity status (e.g. active, inactive, cancelled).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_quiz'         => array(
				'_mcp_ai_quiz_description'   => array(
					'meta_key'    => '_mcp_ai_quiz_description',
					'label'       => __( 'Description', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Detailed instructions or overview shown to students before the quiz.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_mcp_ai_quiz_time_limit'    => array(
					'meta_key'    => '_mcp_ai_quiz_time_limit',
					'label'       => __( 'Time Limit (minutes)', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Maximum time allowed to complete the quiz in minutes (0 = no limit).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_mcp_ai_quiz_questions'     => array(
					'meta_key'    => '_mcp_ai_quiz_questions',
					'label'       => __( 'Questions', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of question objects (text, type, options, correct_answer, points).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_mcp_ai_quiz_total_points'  => array(
					'meta_key'    => '_mcp_ai_quiz_total_points',
					'label'       => __( 'Total Points', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Sum of points across all quiz questions.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_mcp_ai_quiz_passing_score' => array(
					'meta_key'    => '_mcp_ai_quiz_passing_score',
					'label'       => __( 'Passing Score (%)', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Minimum percentage score required to pass the quiz.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Media & Content Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_media_tpl'    => array(
				'_template_type'     => array(
					'meta_key'    => '_template_type',
					'label'       => __( 'Template Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Media type the template is designed for (e.g. image, video, audio).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_template_prompts'  => array(
					'meta_key'    => '_template_prompts',
					'label'       => __( 'Prompts', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of AI generation prompts used by this template.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_template_settings' => array(
					'meta_key'    => '_template_settings',
					'label'       => __( 'Settings', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'object',
					'description' => __( 'Serialized configuration object (dimensions, style, output format, etc.).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_media_coll'   => array(
				'_collection_type'  => array(
					'meta_key'    => '_collection_type',
					'label'       => __( 'Collection Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Category of media in this collection.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_collection_items' => array(
					'meta_key'    => '_collection_items',
					'label'       => __( 'Items', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of WordPress attachment IDs belonging to this collection.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_image_tpl'    => array(
				'_image_prompt' => array(
					'meta_key'    => '_image_prompt',
					'label'       => __( 'Image Prompt', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'AI image generation prompt for this template.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_image_style'  => array(
					'meta_key'    => '_image_style',
					'label'       => __( 'Style', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Visual style directive appended to image generation prompts.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_image_size'   => array(
					'meta_key'    => '_image_size',
					'label'       => __( 'Size', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Output image dimensions (e.g. 1024x1024, 16:9).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_doc_tpl'      => array(
				'_doc_template_variables' => array(
					'meta_key'    => '_doc_template_variables',
					'label'       => __( 'Template Variables', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of {{variable}} token names used in this document template.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_doc_template_format'    => array(
					'meta_key'    => '_doc_template_format',
					'label'       => __( 'Output Format', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Target output format when the template is rendered (e.g. html, markdown, pdf).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// CRM / Company Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_company'      => array(
				'_company_industry'    => array(
					'meta_key'    => '_company_industry',
					'label'       => __( 'Industry', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Industry vertical the company operates in.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_company_size'        => array(
					'meta_key'    => '_company_size',
					'label'       => __( 'Company Size', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Number of employees or size tier (e.g. 1-10, 11-50, 51-200).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_company_website'     => array(
					'meta_key'    => '_company_website',
					'label'       => __( 'Website', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Company website URL.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_company_phone'       => array(
					'meta_key'    => '_company_phone',
					'label'       => __( 'Phone', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Primary contact phone number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_company_address'     => array(
					'meta_key'    => '_company_address',
					'label'       => __( 'Address', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Company headquarters or main office address.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_company_status'      => array(
					'meta_key'    => '_company_status',
					'label'       => __( 'Lead Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'CRM pipeline status for this company.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'prospect', 'lead', 'qualified', 'customer', 'churned' ),
				),
				'_company_assigned_to' => array(
					'meta_key'    => '_company_assigned_to',
					'label'       => __( 'Assigned To', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'WordPress user ID of the account owner.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_customer'     => array(
				'email'           => array(
					'meta_key'    => 'email',
					'label'       => __( 'Email', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Primary contact email address.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'first_name'      => array(
					'meta_key'    => 'first_name',
					'label'       => __( 'First Name', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Customer contact first name.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'last_name'       => array(
					'meta_key'    => 'last_name',
					'label'       => __( 'Last Name', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Customer contact last name.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'phone'           => array(
					'meta_key'    => 'phone',
					'label'       => __( 'Phone', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Customer contact phone number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'company_name'    => array(
					'meta_key'    => 'company_name',
					'label'       => __( 'Company', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Company the customer belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'lifecycle_stage' => array(
					'meta_key'    => 'lifecycle_stage',
					'label'       => __( 'Lifecycle Stage', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'CRM lifecycle stage for this customer.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'contact_owner'   => array(
					'meta_key'    => 'contact_owner',
					'label'       => __( 'Contact Owner', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'WordPress user ID of the account owner.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'customer_since'  => array(
					'meta_key'    => 'customer_since',
					'label'       => __( 'Customer Since', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Date the lead converted to a customer.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'source_lead_id'  => array(
					'meta_key'    => 'source_lead_id',
					'label'       => __( 'Source Lead', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Lead post ID this customer converted from.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_lead'         => array(
				'email'           => array(
					'meta_key'    => 'email',
					'label'       => __( 'Email', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Lead contact email address.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'phone'           => array(
					'meta_key'    => 'phone',
					'label'       => __( 'Phone', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Lead contact phone number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'company_name'    => array(
					'meta_key'    => 'company_name',
					'label'       => __( 'Company', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Company name attached to this lead.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'lead_status'     => array(
					'meta_key'    => 'lead_status',
					'label'       => __( 'Lead Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Current qualification status of the lead.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'lifecycle_stage' => array(
					'meta_key'    => 'lifecycle_stage',
					'label'       => __( 'Lifecycle Stage', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'CRM lifecycle stage for this lead.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'lead_score'      => array(
					'meta_key'    => 'lead_score',
					'label'       => __( 'Lead Score', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Qualification score assigned to the lead.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'contact_owner'   => array(
					'meta_key'    => 'contact_owner',
					'label'       => __( 'Contact Owner', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'WordPress user ID of the account owner.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'source'          => array(
					'meta_key'    => 'source',
					'label'       => __( 'Source', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Channel the lead originated from.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_deal'         => array(
				'_deal_amount'      => array(
					'meta_key'    => '_deal_amount',
					'label'       => __( 'Amount', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Deal monetary value.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_deal_stage'       => array(
					'meta_key'    => '_deal_stage',
					'label'       => __( 'Stage', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Current pipeline stage of the deal.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_deal_probability' => array(
					'meta_key'    => '_deal_probability',
					'label'       => __( 'Probability', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Win probability percentage (0-100).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_deal_close_date'  => array(
					'meta_key'    => '_deal_close_date',
					'label'       => __( 'Close Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Expected or actual close date.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_deal_owner'       => array(
					'meta_key'    => '_deal_owner',
					'label'       => __( 'Owner', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'WordPress user ID of the deal owner.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_deal_source'      => array(
					'meta_key'    => '_deal_source',
					'label'       => __( 'Source', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Channel the deal originated from.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_ticket'       => array(
				'_ticket_status'      => array(
					'meta_key'    => '_ticket_status',
					'label'       => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Current support ticket status.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_ticket_priority'    => array(
					'meta_key'    => '_ticket_priority',
					'label'       => __( 'Priority', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Support priority of the ticket.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_ticket_category'    => array(
					'meta_key'    => '_ticket_category',
					'label'       => __( 'Category', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Support category the ticket belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_ticket_assignee_id' => array(
					'meta_key'    => '_ticket_assignee_id',
					'label'       => __( 'Assignee', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'WordPress user ID of the assigned agent.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_ticket_contact_id'  => array(
					'meta_key'    => '_ticket_contact_id',
					'label'       => __( 'Contact', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'Customer post ID the ticket belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_ticket_source'      => array(
					'meta_key'    => '_ticket_source',
					'label'       => __( 'Source', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Channel the ticket was raised from.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_ticket_sla_status'  => array(
					'meta_key'    => '_ticket_sla_status',
					'label'       => __( 'SLA Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'SLA tracking state for the ticket.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Professions (base CPT — Proposal 084 Phase 4b W12 console port)
			// ----------------------------------------------------------------

			'mcp_ai_profession'   => array(
				'_wp_mcp_ai_profession_category'         => array(
					'meta_key'    => '_wp_mcp_ai_profession_category',
					'label'       => __( 'Category', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Profession category (advisory, creative, technical…).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_wp_mcp_ai_profession_expertise'        => array(
					'meta_key'    => '_wp_mcp_ai_profession_expertise',
					'label'       => __( 'Expertise', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Expertise areas for this profession.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_wp_mcp_ai_profession_default_tools'    => array(
					'meta_key'    => '_wp_mcp_ai_profession_default_tools',
					'label'       => __( 'Default Tools', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Default tool slugs for this profession.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_wp_mcp_ai_profession_role_description' => array(
					'meta_key'    => '_wp_mcp_ai_profession_role_description',
					'label'       => __( 'Role Description', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Primary role description for assistants of this profession.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_wp_mcp_ai_profession_agent_role'       => array(
					'meta_key'    => '_wp_mcp_ai_profession_agent_role',
					'label'       => __( 'Agent Role', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Agent role designation for this profession.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_wp_mcp_ai_profession_region'           => array(
					'meta_key'    => '_wp_mcp_ai_profession_region',
					'label'       => __( 'Region', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Geographic or market region this profession serves.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_wp_mcp_ai_profession_warnings'         => array(
					'meta_key'    => '_wp_mcp_ai_profession_warnings',
					'label'       => __( 'Warnings', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Warnings and disclaimers for assistants of this profession.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Calendar Booking (Proposal 084 Phase 4d W14 console port)
			// ----------------------------------------------------------------

			'mcp_appointment'     => array(
				'_client_name'      => array(
					'meta_key'    => '_client_name',
					'label'       => __( 'Client', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Client name for the appointment.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_appointment_type' => array(
					'meta_key'    => '_appointment_type',
					'label'       => __( 'Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Appointment type or service category.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_start_time'       => array(
					'meta_key'    => '_start_time',
					'label'       => __( 'Start', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Appointment start time.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_end_time'         => array(
					'meta_key'    => '_end_time',
					'label'       => __( 'End', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Appointment end time.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_status'           => array(
					'meta_key'    => '_status',
					'label'       => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Appointment status (booked, confirmed, cancelled…).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Finance Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_fin_account'  => array(
				'_fin_account_type'        => array(
					'meta_key'    => '_fin_account_type',
					'label'       => __( 'Account Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Category of financial account (e.g. checking, savings, credit, investment).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fin_account_balance'     => array(
					'meta_key'    => '_fin_account_balance',
					'label'       => __( 'Balance', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Current account balance.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fin_account_currency'    => array(
					'meta_key'    => '_fin_account_currency',
					'label'       => __( 'Currency', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'ISO 4217 currency code (e.g. USD, EUR, GBP).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fin_account_institution' => array(
					'meta_key'    => '_fin_account_institution',
					'label'       => __( 'Institution', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Name of the financial institution or bank.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fin_account_last_sync'   => array(
					'meta_key'    => '_fin_account_last_sync',
					'label'       => __( 'Last Synced', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'ISO 8601 timestamp of the last data sync.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Architecture Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_arch_proj'    => array(
				'_arch_proj_client'     => array(
					'meta_key'    => '_arch_proj_client',
					'label'       => __( 'Client', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Name of the client or project owner.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_proj_status'     => array(
					'meta_key'    => '_arch_proj_status',
					'label'       => __( 'Project Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Current phase of the architectural project.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'concept', 'schematic', 'design_development', 'construction_docs', 'construction', 'completed' ),
				),
				'_arch_proj_location'   => array(
					'meta_key'    => '_arch_proj_location',
					'label'       => __( 'Location', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Site address or general location.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_proj_budget'     => array(
					'meta_key'    => '_arch_proj_budget',
					'label'       => __( 'Budget', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Project construction budget.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_proj_start_date' => array(
					'meta_key'    => '_arch_proj_start_date',
					'label'       => __( 'Start Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Project kickoff date (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_proj_end_date'   => array(
					'meta_key'    => '_arch_proj_end_date',
					'label'       => __( 'Completion Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Projected or actual completion date (YYYY-MM-DD).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_arch_draw'    => array(
				'_arch_draw_project_id' => array(
					'meta_key'    => '_arch_draw_project_id',
					'label'       => __( 'Project ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the parent mcp_ai_arch_proj post.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_draw_type'       => array(
					'meta_key'    => '_arch_draw_type',
					'label'       => __( 'Drawing Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Type of architectural drawing (e.g. floor_plan, elevation, section, detail).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_draw_scale'      => array(
					'meta_key'    => '_arch_draw_scale',
					'label'       => __( 'Scale', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Drawing scale (e.g. 1:100, 1/4"=1\'0").', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_draw_sheet_no'   => array(
					'meta_key'    => '_arch_draw_sheet_no',
					'label'       => __( 'Sheet Number', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Drawing sheet or page number (e.g. A-101).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_draw_revision'   => array(
					'meta_key'    => '_arch_draw_revision',
					'label'       => __( 'Revision', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Current revision identifier (e.g. A, B, 1, 2).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_draw_file_id'    => array(
					'meta_key'    => '_arch_draw_file_id',
					'label'       => __( 'File Attachment ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'WordPress attachment ID for the drawing file (PDF/DWG/image).', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_arch_spec'    => array(
				'_arch_spec_project_id' => array(
					'meta_key'    => '_arch_spec_project_id',
					'label'       => __( 'Project ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the parent mcp_ai_arch_proj post.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_spec_division'   => array(
					'meta_key'    => '_arch_spec_division',
					'label'       => __( 'Division', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'MasterFormat division number (e.g. 03 - Concrete, 09 - Finishes).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_spec_section'    => array(
					'meta_key'    => '_arch_spec_section',
					'label'       => __( 'Section', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'MasterFormat section code (e.g. 03 30 00 - Cast-in-Place Concrete).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_spec_revision'   => array(
					'meta_key'    => '_arch_spec_revision',
					'label'       => __( 'Revision', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Specification document revision identifier.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_arch_spec_file_id'    => array(
					'meta_key'    => '_arch_spec_file_id',
					'label'       => __( 'File Attachment ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'WordPress attachment ID for the specification document.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Chat Channels Toolkit (CPT fallback storage)
			// ----------------------------------------------------------------

			'mcp_chan_contact'    => array(
				'_chan_contact_user_id'   => array(
					'meta_key'    => '_chan_contact_user_id',
					'label'       => __( 'WP User ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'WordPress user ID associated with this channel contact.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_chan_contact_channel'   => array(
					'meta_key'    => '_chan_contact_channel',
					'label'       => __( 'Channel', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Communication channel identifier (e.g. sms, email, whatsapp).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_chan_contact_handle'    => array(
					'meta_key'    => '_chan_contact_handle',
					'label'       => __( 'Handle / Address', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Channel-specific contact handle, phone number, or email.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_chan_contact_last_seen' => array(
					'meta_key'    => '_chan_contact_last_seen',
					'label'       => __( 'Last Seen', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'ISO 8601 timestamp of last activity for this contact.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_chan_message'    => array(
				'_chan_msg_contact_id' => array(
					'meta_key'    => '_chan_msg_contact_id',
					'label'       => __( 'Contact ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'integer',
					'description' => __( 'ID of the mcp_chan_contact this message belongs to.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_chan_msg_direction'  => array(
					'meta_key'    => '_chan_msg_direction',
					'label'       => __( 'Direction', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Whether the message was inbound or outbound.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'inbound', 'outbound' ),
				),
				'_chan_msg_status'     => array(
					'meta_key'    => '_chan_msg_status',
					'label'       => __( 'Delivery Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Message delivery status.', 'nvdigital-open-operator-system-oos-pro' ),
					'enum'        => array( 'sent', 'delivered', 'read', 'failed' ),
				),
				'_chan_msg_media_ids'  => array(
					'meta_key'    => '_chan_msg_media_ids',
					'label'       => __( 'Media Attachments', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of WordPress attachment IDs included in the message.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// WebChat (P2P) Toolkit
			// ----------------------------------------------------------------

			'mcp_ai_webchat'      => array(
				'_webchat_room_type'     => array(
					'meta_key'    => '_webchat_room_type',
					'label'       => __( 'Room Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Type of chat room (e.g. direct, group, support).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_webchat_participants'  => array(
					'meta_key'    => '_webchat_participants',
					'label'       => __( 'Participants', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'array',
					'description' => __( 'Serialized array of WordPress user IDs participating in the room.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_webchat_last_activity' => array(
					'meta_key'    => '_webchat_last_activity',
					'label'       => __( 'Last Activity', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'ISO 8601 timestamp of the most recent message in the room.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_webchat_is_archived'   => array(
					'meta_key'    => '_webchat_is_archived',
					'label'       => __( 'Archived', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'boolean',
					'description' => __( 'Whether the chat room has been archived.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			// ----------------------------------------------------------------
			// Food & Beverage Toolkit (Phase 9 native storage)
			// ----------------------------------------------------------------

			'mcp_ai_fnb_sale'     => array(
				'_fnb_date'     => array(
					'meta_key'    => '_fnb_date',
					'label'       => __( 'Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Sale date (spec table 6.0).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_month'    => array(
					'meta_key'    => '_fnb_month',
					'label'       => __( 'Month', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Sale month (Y-m).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_item_id'  => array(
					'meta_key'    => '_fnb_item_id',
					'label'       => __( 'Item ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Menu item ID from spec table 1.0.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_item'     => array(
					'meta_key'    => '_fnb_item',
					'label'       => __( 'Item', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Menu item name.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_type'     => array(
					'meta_key'    => '_fnb_type',
					'label'       => __( 'Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Sale type (Food, Beverage, Other).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_qty_sold' => array(
					'meta_key'    => '_fnb_qty_sold',
					'label'       => __( 'Qty Sold', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Units sold.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_price'    => array(
					'meta_key'    => '_fnb_price',
					'label'       => __( 'Price', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Unit price.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_revenue'  => array(
					'meta_key'    => '_fnb_revenue',
					'label'       => __( 'Revenue', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Line revenue.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_fnb_purchase' => array(
				'_fnb_delivery_date' => array(
					'meta_key'    => '_fnb_delivery_date',
					'label'       => __( 'Delivery Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Delivery date (spec table 8.0).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_month'         => array(
					'meta_key'    => '_fnb_month',
					'label'       => __( 'Month', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Delivery month (Y-m).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_supplier_id'   => array(
					'meta_key'    => '_fnb_supplier_id',
					'label'       => __( 'Supplier ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Supplier ID from spec table 4.0.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_invoice'       => array(
					'meta_key'    => '_fnb_invoice',
					'label'       => __( 'Invoice', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Supplier invoice number.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_ingredient_id' => array(
					'meta_key'    => '_fnb_ingredient_id',
					'label'       => __( 'Ingredient ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Ingredient ID from spec table 3.0.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_category'      => array(
					'meta_key'    => '_fnb_category',
					'label'       => __( 'Category', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Ingredient category.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_packs'         => array(
					'meta_key'    => '_fnb_packs',
					'label'       => __( 'Packs', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Number of packs ordered.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_pack_size'     => array(
					'meta_key'    => '_fnb_pack_size',
					'label'       => __( 'Pack Size', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Pack size description.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_qty_delivered' => array(
					'meta_key'    => '_fnb_qty_delivered',
					'label'       => __( 'Qty Delivered', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Quantity delivered.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_pack_price'    => array(
					'meta_key'    => '_fnb_pack_price',
					'label'       => __( 'Pack Price', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Price per pack.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_line_total'    => array(
					'meta_key'    => '_fnb_line_total',
					'label'       => __( 'Line Total', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Line total.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_fnb_stock'    => array(
				'_fnb_count_date'    => array(
					'meta_key'    => '_fnb_count_date',
					'label'       => __( 'Count Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Stock-count date (spec table 9.0).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_count_type'    => array(
					'meta_key'    => '_fnb_count_type',
					'label'       => __( 'Count Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Count type (Opening, Full, Closing, …).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_period_start'  => array(
					'meta_key'    => '_fnb_period_start',
					'label'       => __( 'Period Start', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Start of the counted period.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_ingredient_id' => array(
					'meta_key'    => '_fnb_ingredient_id',
					'label'       => __( 'Ingredient ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Ingredient ID from spec table 3.0.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_unit'          => array(
					'meta_key'    => '_fnb_unit',
					'label'       => __( 'Unit', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Unit of measure.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_category'      => array(
					'meta_key'    => '_fnb_category',
					'label'       => __( 'Category', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Ingredient category.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_opening'       => array(
					'meta_key'    => '_fnb_opening',
					'label'       => __( 'Opening', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Opening quantity.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_bought'        => array(
					'meta_key'    => '_fnb_bought',
					'label'       => __( 'Bought', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Quantity bought during the period.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_closing'       => array(
					'meta_key'    => '_fnb_closing',
					'label'       => __( 'Closing', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Closing quantity.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_used'          => array(
					'meta_key'    => '_fnb_used',
					'label'       => __( 'Used', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Quantity used during the period.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_unit_cost'     => array(
					'meta_key'    => '_fnb_unit_cost',
					'label'       => __( 'Unit Cost', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Unit cost.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_closing_value' => array(
					'meta_key'    => '_fnb_closing_value',
					'label'       => __( 'Closing Value', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Closing value.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_fnb_waste'    => array(
				'_fnb_date'          => array(
					'meta_key'    => '_fnb_date',
					'label'       => __( 'Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Waste-log date (spec table 10.0).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_month'         => array(
					'meta_key'    => '_fnb_month',
					'label'       => __( 'Month', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Waste month (Y-m).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_ingredient_id' => array(
					'meta_key'    => '_fnb_ingredient_id',
					'label'       => __( 'Ingredient ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Ingredient ID from spec table 3.0.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_ingredient'    => array(
					'meta_key'    => '_fnb_ingredient',
					'label'       => __( 'Ingredient', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Ingredient name.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_qty'           => array(
					'meta_key'    => '_fnb_qty',
					'label'       => __( 'Qty', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Wasted quantity.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_unit'          => array(
					'meta_key'    => '_fnb_unit',
					'label'       => __( 'Unit', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Unit of measure.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_reason'        => array(
					'meta_key'    => '_fnb_reason',
					'label'       => __( 'Reason', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Logged waste reason.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_logged_by'     => array(
					'meta_key'    => '_fnb_logged_by',
					'label'       => __( 'Logged By', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Staff member who logged the waste.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_value'         => array(
					'meta_key'    => '_fnb_value',
					'label'       => __( 'Value', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Waste value.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),

			'mcp_ai_fnb_booking'  => array(
				'_fnb_booking_id' => array(
					'meta_key'    => '_fnb_booking_id',
					'label'       => __( 'Booking ID', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Booking ID (spec table 16.0).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_date'       => array(
					'meta_key'    => '_fnb_date',
					'label'       => __( 'Date', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Booking date.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_day'        => array(
					'meta_key'    => '_fnb_day',
					'label'       => __( 'Day', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Day of week.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_time'       => array(
					'meta_key'    => '_fnb_time',
					'label'       => __( 'Time', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Booking time.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_session'    => array(
					'meta_key'    => '_fnb_session',
					'label'       => __( 'Session', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Service session (lunch, dinner, bar, …).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_type'       => array(
					'meta_key'    => '_fnb_type',
					'label'       => __( 'Type', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Booking type (day bed, table, group, …).', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_guests'     => array(
					'meta_key'    => '_fnb_guests',
					'label'       => __( 'Guests', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'number',
					'description' => __( 'Guest count.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_notes'      => array(
					'meta_key'    => '_fnb_notes',
					'label'       => __( 'Notes', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Booking notes.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'_fnb_status'     => array(
					'meta_key'    => '_fnb_status',
					'label'       => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
					'type'        => 'string',
					'description' => __( 'Booking status.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),
		);
	}
}
