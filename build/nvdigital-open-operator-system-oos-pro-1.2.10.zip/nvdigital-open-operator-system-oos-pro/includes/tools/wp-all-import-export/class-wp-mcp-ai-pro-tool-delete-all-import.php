<?php
/**
 * Pro Tool: Delete WP All Import Template.
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent parse errors on PHP < 7.4 by exiting before class definition.
if ( version_compare( PHP_VERSION, '7.4.0', '<' ) ) {
	return;
}

/**
 * Deletes a WP All Import template.
 */
class WP_MCP_AI_Pro_Tool_Delete_All_Import implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	/**
	 * Determine whether WP All Import is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return class_exists( 'PMXI_Plugin' ) || defined( 'PMXI_VERSION' );
	}

	/**
	 * Message explaining why the tool is unavailable.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'The WP All Import Pro tool is disabled because WP All Import plugin is not active.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'delete_all_import';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Delete WP All Import Template', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Deletes a WP All Import template and its associated files (Pro feature). Requires WP All Import plugin.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Permanently deleting a WP All Import template by import ID, along with its uploaded files and scheduled cron events.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Keeping the template and its recurring schedule; use schedule_all_import instead, or delete_all_export for export templates.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'schedule_all_import', 'delete_all_export' ),
			'notes'           => __( 'Requires manage_options and an active WP All Import plugin. Deletion is permanent and cannot be undone.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'import_id' => array(
					'type'        => 'integer',
					'description' => __( 'The ID of the import template to delete.', 'nvdigital-open-operator-system-oos-pro' ),
					'minimum'     => 1,
				),
			),
			'required'             => array( 'import_id' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! self::is_available() ) {
			return new WP_Error( 'wp_mcp_ai_all_import_missing', __( 'WP All Import is not active on this site.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You must be logged in to delete imports.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		if ( ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to delete imports.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		if ( empty( $arguments['import_id'] ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_param', __( 'Import ID is required.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$import_id = absint( $arguments['import_id'] );

		// Verify import exists.
		$import = get_post( $import_id );
		if ( ! $import || 'import' !== $import->post_type ) {
			return new WP_Error( 'wp_mcp_ai_invalid_import', __( 'Invalid import ID.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$import_name = $import->post_title;

		// Clear any scheduled events for this import.
		$hook = get_post_meta( $import_id, 'schedule_hook', true );
		if ( $hook ) {
			$scheduled = wp_next_scheduled( $hook, array( $import_id ) );
			if ( $scheduled ) {
				wp_unschedule_event( $scheduled, $hook, array( $import_id ) );
			}
		}

		// Delete import files if they exist.
		$upload_dir = wp_upload_dir();
		$import_dir = $upload_dir['basedir'] . '/wpallimport/files/' . $import_id;
		if ( is_dir( $import_dir ) ) {
			$this->delete_directory( $import_dir );
		}

		// Delete the import post and all associated meta.
		$deleted = wp_delete_post( $import_id, true );

		if ( ! $deleted ) {
			return new WP_Error( 'wp_mcp_ai_delete_failed', __( 'Failed to delete import template.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		return array(
			'success'     => true,
			'message'     => __( 'Import template deleted successfully.', 'nvdigital-open-operator-system-oos-pro' ),
			'import_id'   => $import_id,
			'import_name' => $import_name,
		);
	}

	/**
	 * Recursively delete a directory.
	 *
	 * @param string $dir Directory path.
	 */
	private function delete_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$files = array_diff( scandir( $dir ), array( '.', '..' ) );
		foreach ( $files as $file ) {
			$path = $dir . '/' . $file;
			is_dir( $path ) ? $this->delete_directory( $path ) : wp_delete_file( $path );
		}
		rmdir( $dir );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-plugin',     // Requires WP All Import plugin.
			'state-changing',      // Modifies state by deleting data.
			'destructive',         // Permanently deletes data.
			'local-only',          // No external API calls.
			'requires-capability', // Requires 'manage_options' capability.
		);
	}
}
