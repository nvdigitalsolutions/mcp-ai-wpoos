Neplex Vectorizer – Now Bundled with the Base Plugin
=====================================================

The neplex-vectorizer library is now included directly in the base
plugin distribution.  This optional-component archive exists only
as a placeholder for compatibility with older download URLs.

If you are running a recent version of the plugin you do not need
to download or install this archive.
