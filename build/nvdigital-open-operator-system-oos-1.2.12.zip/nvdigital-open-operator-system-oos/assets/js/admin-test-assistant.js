/**
 * Test Assistant Admin Interface
 *
 * Provides modal-based chat interface for testing AI assistants in the WordPress admin.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

(function () {
	'use strict';

	/**
	 * Escape HTML to prevent XSS attacks.
	 *
	 * @param {string} text Text to escape.
	 * @return {string} Escaped text.
	 */
	function escapeHtml(text) {
		const div = document.createElement('div');
		div.textContent = text;
		return div.innerHTML;
	}

	/**
	 * Initialize the test assistant interface.
	 */
	function init() {
		const testButtons = document.querySelectorAll('.wp-mcp-ai-test-assistant-btn');
		const modal = document.getElementById('wp-mcp-ai-test-modal');
		
		if (!testButtons.length || !modal) {
			return;
		}

		const modalClose = modal.querySelector('.wp-mcp-ai-test-modal__close');
		const modalBackdrop = modal.querySelector('.wp-mcp-ai-test-modal__backdrop');

		// Attach click handlers to test buttons.
		testButtons.forEach(function (button) {
			button.addEventListener('click', function () {
				const assistantId = parseInt( button.getAttribute('data-assistant-id'), 10 ) || 0;
				const assistantTitle = button.getAttribute('data-assistant-title');
				const toolShortcutsJson = button.getAttribute('data-tool-shortcuts');
				const provider = button.getAttribute('data-provider');
				const model = button.getAttribute('data-model');
				let toolShortcuts = [];

				// Parse tool shortcuts if available
				if (toolShortcutsJson) {
					try {
						toolShortcuts = JSON.parse(toolShortcutsJson);
						if (!Array.isArray(toolShortcuts)) {
							toolShortcuts = [];
						}
					} catch (e) {
						toolShortcuts = [];
					}
				}

				if (assistantId) {
					openTestModal(assistantId, assistantTitle, toolShortcuts, provider, model);
				}
			});
		});

		// Close modal on close button click.
		if (modalClose) {
			modalClose.addEventListener('click', closeTestModal);
		}

		// Close modal on backdrop click only (not when clicking inside the panel).
		if (modal) {
			modal.addEventListener('click', function(event) {
				// Close only if clicking on the modal container or backdrop, not the panel or its contents.
				if (event.target === modal || event.target === modalBackdrop) {
					closeTestModal();
				}
			});
		}

		// Close modal on Escape key.
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && modal.style.display !== 'none') {
				closeTestModal();
			}
		});
	}

	/**
	 * Open the test modal with chat interface for the specified assistant.
	 *
	 * @param {string} assistantId     The assistant post ID.
	 * @param {string} assistantTitle  The assistant title for display.
	 * @param {Array}  toolShortcuts   Tool shortcuts configuration for the assistant.
	 * @param {string} provider        The AI provider (e.g., 'openai', 'embedded', 'gemini').
	 * @param {string} model           The model identifier.
	 */
	function openTestModal(assistantId, assistantTitle, toolShortcuts, provider, model) {
		const modal = document.getElementById('wp-mcp-ai-test-modal');
		const modalTitle = document.getElementById('wp-mcp-ai-test-modal__title');
		const chatContainer = document.getElementById('wp-mcp-ai-test-chat-container');

		// Default to empty array if not provided
		if (!Array.isArray(toolShortcuts)) {
			toolShortcuts = [];
		}

		if (!modal || !chatContainer) {
			return;
		}

		// Update modal title.
		if (modalTitle) {
			modalTitle.textContent = escapeHtml(assistantTitle || 'Test Assistant');
		}

		// Clear previous chat container.
		chatContainer.innerHTML = '';

		// Create unique instance ID for this chat.
		const instanceId = 'wp-mcp-ai-test-chat-' + assistantId + '-' + Date.now();

		// Build chat HTML structure (based on shortcode template).
		const chatHTML = buildChatHTML(instanceId);
		chatContainer.innerHTML = chatHTML;

		// Initialize chat instance configuration.
		if (!window.wpMcpAiChatInstances) {
			window.wpMcpAiChatInstances = {};
		}

		// Build endpoints from base REST URL
		const baseRestUrl = (window.wpMcpAiChat && window.wpMcpAiChat.restUrl) ? window.wpMcpAiChat.restUrl : '/wp-json/mcp-ai/v1';

		// Get file upload configuration from global config
		const fileAccept = (window.wpMcpAiChat && window.wpMcpAiChat.fileAccept) ? window.wpMcpAiChat.fileAccept : '';
		const allowedImageMimes = (window.wpMcpAiChat && window.wpMcpAiChat.allowedImageMimes) ? window.wpMcpAiChat.allowedImageMimes : [];
		const allowedFileMimes = (window.wpMcpAiChat && window.wpMcpAiChat.allowedFileMimes) ? window.wpMcpAiChat.allowedFileMimes : [];
		const allowedExtensions = (window.wpMcpAiChat && window.wpMcpAiChat.allowedExtensions) ? window.wpMcpAiChat.allowedExtensions : [];

		window.wpMcpAiChatInstances[instanceId] = {
			assistantId: assistantId,
			embeddedAssistantId: parseInt(assistantId, 10) || 0,
			userId: (window.wpMcpAiChat && typeof window.wpMcpAiChat.currentUserId !== 'undefined') ? window.wpMcpAiChat.currentUserId : 0,
			messagesEndpoint: baseRestUrl + 'chat-client',
			toolsEndpoint: baseRestUrl + 'tools',
			embeddedConfigEndpoint: baseRestUrl + 'embedded-client-config',
			filesEndpoint: (window.wpMcpAiChat && window.wpMcpAiChat.filesEndpoint) ? window.wpMcpAiChat.filesEndpoint : baseRestUrl + 'files/',
			transcriptsEndpoint: (window.wpMcpAiChat && window.wpMcpAiChat.transcriptsEndpoint) ? window.wpMcpAiChat.transcriptsEndpoint : baseRestUrl + 'chat-transcripts',
			crawl4aiTaskEndpoint: baseRestUrl + 'crawl4ai/task/',
			uploadEndpoint: (window.wpMcpAiChat && window.wpMcpAiChat.uploadEndpoint) ? window.wpMcpAiChat.uploadEndpoint : '/wp-json/wp/v2/media',
			sessionKey: generateSessionKey(),
			enableStreaming: true,
			canUploadAttachments: true,
			saveTranscript: true, // Enable transcript saving for admin testing
			allowSensitiveTools: true, // Admin users can access all tools
			toolShortcuts: toolShortcuts, // Tool shortcuts from assistant config
			provider: provider || '', // Add provider for client-side execution detection
			model: model || '', // Add model for client-side execution
			fileAccept: fileAccept,
			allowedImageMimes: allowedImageMimes,
			allowedFileMimes: allowedFileMimes,
			allowedExtensions: allowedExtensions,
			restNonce: (window.wpMcpAiChat && window.wpMcpAiChat.nonce) ? window.wpMcpAiChat.nonce : '',
			historyPerPage: 20,
		};

		// Note: loadAssistantConfig removed as we now pass shortcuts directly

		// Show modal.
		modal.style.display = 'block';
		document.body.classList.add('wp-mcp-ai-test-modal-open');

		// Trigger chat.js initialization.
		initializeChatInstance(instanceId);
	}

	/**
	 * Close the test modal.
	 */
	function closeTestModal() {
		const modal = document.getElementById('wp-mcp-ai-test-modal');
		const chatContainer = document.getElementById('wp-mcp-ai-test-chat-container');

		if (modal) {
			modal.style.display = 'none';
			document.body.classList.remove('wp-mcp-ai-test-modal-open');
		}

		// Clear chat container.
		if (chatContainer) {
			chatContainer.innerHTML = '';
		}
	}

	/**
	 * Build the chat interface HTML structure.
	 *
	 * @param {string} instanceId Unique instance identifier.
	 * @return {string} HTML string for chat interface.
	 */
	function buildChatHTML(instanceId) {
		const escapedInstanceId = escapeHtml(instanceId);
		const placeholderEscaped = escapeHtml(getPlaceholder());
		const attachLabelEscaped = escapeHtml(getAttachLabel());
		const transcribeLabelEscaped = escapeHtml(getTranscribeLabel());
		const sendLabelEscaped = escapeHtml(getSendLabel());
		
		return '<div class="wp-mcp-ai-chat" id="' + escapedInstanceId + '" data-wp-mcp-ai-chat>' +
			'<div class="wp-mcp-ai-chat__transcript-controls">' +
			'<button type="button" class="wp-mcp-ai-chat__transcript-toggle" aria-expanded="false" aria-label="Expand conversation">' +
			'<svg class="wp-mcp-ai-chat__transcript-toggle-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
			'<path d="M12 15.5a1 1 0 0 1-.7-.29l-5-5a1 1 0 0 1 1.4-1.42L12 13.09l4.3-4.3a1 1 0 0 1 1.4 1.42l-5 5a1 1 0 0 1-.7.29z" />' +
			'</svg>' +
			'<span class="screen-reader-text">Expand conversation</span>' +
			'</button>' +
			'</div>' +
			'<div class="wp-mcp-ai-chat__messages" role="log" aria-live="polite" aria-atomic="false"></div>' +
			'<form class="wp-mcp-ai-chat__form">' +
			'<div class="wp-mcp-ai-chat__status" role="status" aria-live="polite" hidden></div>' +
			'<div class="wp-mcp-ai-chat__tool-shortcuts-wrapper" hidden>' +
			'<button type="button" class="wp-mcp-ai-chat__tool-shortcuts-toggle wp-mcp-ai-chat__tool-shortcuts-toggle--collapsed" aria-expanded="false" aria-controls="' + escapedInstanceId + '-tool-shortcuts">' +
			'<span class="wp-mcp-ai-chat__tool-shortcuts-toggle-text">Quick Tasks</span>' +
			'<svg class="wp-mcp-ai-chat__tool-shortcuts-toggle-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
			'<path d="M12 15.5a1 1 0 0 1-.7-.29l-5-5a1 1 0 0 1 1.4-1.42L12 13.09l4.3-4.3a1 1 0 0 1 1.4 1.42l-5 5a1 1 0 0 1-.7.29z" />' +
			'</svg>' +
			'</button>' +
			'<div id="' + escapedInstanceId + '-tool-shortcuts" class="wp-mcp-ai-chat__tool-shortcuts wp-mcp-ai-chat__tool-shortcuts--collapsed" role="group" aria-label="Assistant tool tasks" hidden></div>' +
			'</div>' +
			'<textarea class="wp-mcp-ai-chat__input" rows="4" placeholder="' + placeholderEscaped + '" required></textarea>' +
			'<div class="wp-mcp-ai-chat__attachments" hidden>' +
			'<div class="wp-mcp-ai-chat__attachments-header">Attachments</div>' +
			'<ul class="wp-mcp-ai-chat__attachments-list"></ul>' +
			'</div>' +
			'<div class="wp-mcp-ai-chat__actions">' +
			'<input type="file" class="wp-mcp-ai-chat__file-input" multiple hidden />' +
			'<input type="file" class="wp-mcp-ai-chat__transcribe-input" accept="audio/*" hidden />' +
			'<button type="button" class="wp-mcp-ai-chat__transcribe" aria-label="' + transcribeLabelEscaped + '">' +
			'<svg class="wp-mcp-ai-chat__transcribe-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
			'<path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 14 0h-2z"></path>' +
			'<path d="M12 16a7 7 0 0 0 6.93-6H17a5 5 0 0 1-10 0H5.07A7 7 0 0 0 12 16zm-1 2.05V21h2v-2.95A9 9 0 0 0 20.95 11H19a7 7 0 0 1-14 0H3.05A9 9 0 0 0 11 18.05z"></path>' +
			'</svg>' +
			'<span class="screen-reader-text">' + transcribeLabelEscaped + '</span>' +
			'</button>' +
			'<button type="button" class="wp-mcp-ai-chat__attach">' + attachLabelEscaped + '</button>' +
			'<button type="submit" class="wp-mcp-ai-chat__submit">' + sendLabelEscaped + '</button>' +
			'</div>' +
			'</form>' +
			'<div class="wp-mcp-ai-chat__controls">' +
			'<div class="wp-mcp-ai-chat__quota-monitor" role="status" aria-live="polite" aria-atomic="true"></div>' +
			'<div class="wp-mcp-ai-chat__cron-status" role="status" aria-live="polite" aria-atomic="true" hidden>' +
			'<span class="wp-mcp-ai-chat__cron-status-label">Jobs:</span>' +
			'<span class="wp-mcp-ai-chat__cron-status-pending" title="Pending jobs">' +
			'<span class="wp-mcp-ai-chat__cron-status-count">0</span>' +
			'</span>' +
			'<span class="wp-mcp-ai-chat__cron-status-completed" title="Completed jobs">' +
			'<span class="wp-mcp-ai-chat__cron-status-count">0</span>' +
			'</span>' +
			'</div>' +
			'<div class="wp-mcp-ai-chat__control-buttons">' +
			'<button type="button" class="wp-mcp-ai-chat__save" aria-label="Save conversation" title="Save conversation">' +
			'<svg class="wp-mcp-ai-chat__save-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
			'<path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2zM5 5v14h14V9h-4V5H5z" />' +
			'<path d="M7 5h6v3H7V5zm5 9a2 2 0 11-4 0 2 2 0 014 0z" />' +
			'</svg>' +
			'<span class="screen-reader-text">Save conversation</span>' +
			'</button>' +
			'<button type="button" class="wp-mcp-ai-chat__export" aria-label="Export conversation" title="Export conversation">' +
			'<svg class="wp-mcp-ai-chat__export-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
			'<path d="M12 16a1 1 0 01-1-1V5a1 1 0 012 0v10a1 1 0 01-1 1z" />' +
			'<path d="M12 16a1 1 0 01-.707-.293l-4-4a1 1 0 011.414-1.414L12 13.586l3.293-3.293a1 1 0 011.414 1.414l-4 4A1 1 0 0112 16z" />' +
			'<path d="M5 19a1 1 0 010-2h14a1 1 0 010 2H5z" />' +
			'</svg>' +
			'<span class="screen-reader-text">Export conversation</span>' +
			'</button>' +
			'<button type="button" class="wp-mcp-ai-chat__history-toggle" aria-expanded="false" aria-controls="' + escapedInstanceId + '-history" aria-label="Show previous conversations">' +
			'<svg class="wp-mcp-ai-chat__history-toggle-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
			'<path d="M6 5.5a1 1 0 011-1h10a1 1 0 110 2H7a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H7a1 1 0 01-1-1zm0 6a1 1 0 011-1h7a1 1 0 010 2H7a1 1 0 01-1-1z" />' +
			'<path d="M5 9a1 1 0 012 0 1 1 0 11-2 0zm0 6a1 1 0 012 0 1 1 0 11-2 0zm0-12a1 1 0 012 0 1 1 0 11-2 0z" />' +
			'</svg>' +
			'<span class="screen-reader-text">Show previous conversations</span>' +
			'</button>' +
			'<button type="button" class="wp-mcp-ai-chat__new-chat" aria-label="Start new conversation">' +
			'<svg class="wp-mcp-ai-chat__new-chat-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
			'<path d="M12 4a1 1 0 011 1v6h6a1 1 0 110 2h-6v6a1 1 0 11-2 0v-6H5a1 1 0 110-2h6V5a1 1 0 011-1z" />' +
			'</svg>' +
			'<span class="screen-reader-text">Start new conversation</span>' +
			'</button>' +
			'</div>' +
			'</div>' +
			'<section class="wp-mcp-ai-chat__history" id="' + escapedInstanceId + '-history" hidden aria-label="Previous conversations">' +
			'<div class="wp-mcp-ai-chat__history-header">' +
			'<button type="button" class="wp-mcp-ai-chat__history-refresh" aria-label="Refresh conversation history" title="Refresh conversation history">' +
			'<svg class="wp-mcp-ai-chat__history-refresh-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
			'<path d="M4 12a8 8 0 018-8V3c-1.105 0-2.165.21-3.13.594l1.42 1.42A6.004 6.004 0 0112 5a7 7 0 110 14 7 7 0 01-6.93-6H3a8 8 0 008 8 8 8 0 000-16V3l-3 3 3 3v-1.078z"/>' +
			'</svg>' +
			'<span class="screen-reader-text">Refresh conversation history</span>' +
			'</button>' +
			'</div>' +
			'<div class="wp-mcp-ai-chat__history-status" role="status" aria-live="polite" hidden></div>' +
			'<ul class="wp-mcp-ai-chat__history-list" role="list"></ul>' +
			'</section>' +
			'</div>';
	}

	/**
	 * Initialize a chat instance manually.
	 *
	 * @param {string} instanceId Instance identifier.
	 */
	function initializeChatInstance(instanceId) {
		// Wait a brief moment for DOM to settle.
		setTimeout(function () {
			const container = document.getElementById(instanceId);

			if (!container) {
				return;
			}

			// Trigger a DOMContentLoaded event to re-init chat.js.
			const event = document.createEvent('Event');
			event.initEvent('DOMContentLoaded', true, true);
			document.dispatchEvent(event);

			// Focus the textarea to give user immediate access.
			setTimeout(function() {
				const textarea = container.querySelector('.wp-mcp-ai-chat__input');
				if (textarea) {
					textarea.focus();
				}
			}, 200);
		}, 100);
	}

	/**
	 * Generate a unique session key for the chat instance.
	 *
	 * @return {string} Session key.
	 */
	function generateSessionKey() {
		const array = new Uint8Array( 16 );
		crypto.getRandomValues( array );
		return 'test-' + Array.from( array, function( b ) { return b.toString( 16 ).padStart( 2, '0' ); } ).join( '' );
	}

	/**
	 * Get placeholder text for input.
	 *
	 * @return {string} Placeholder text.
	 */
	function getPlaceholder() {
		return (window.wpMcpAiChat && window.wpMcpAiChat.strings && window.wpMcpAiChat.strings.placeholder) ? window.wpMcpAiChat.strings.placeholder : 'Ask something...';
	}

	/**
	 * Get send button label.
	 *
	 * @return {string} Send label.
	 */
	function getSendLabel() {
		return (window.wpMcpAiChat && window.wpMcpAiChat.strings && window.wpMcpAiChat.strings.send) ? window.wpMcpAiChat.strings.send : 'Send';
	}

	/**
	 * Get attach button label.
	 *
	 * @return {string} Attach label.
	 */
	function getAttachLabel() {
		return (window.wpMcpAiChat && window.wpMcpAiChat.strings && window.wpMcpAiChat.strings.attachFile) ? window.wpMcpAiChat.strings.attachFile : 'Attach file';
	}

	/**
	 * Get transcribe button label.
	 *
	 * @return {string} Transcribe label.
	 */
	function getTranscribeLabel() {
		return (window.wpMcpAiChat && window.wpMcpAiChat.strings && window.wpMcpAiChat.strings.transcribeAudio) ? window.wpMcpAiChat.strings.transcribeAudio : 'Transcribe audio';
	}

	// Initialize when DOM is ready.
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
