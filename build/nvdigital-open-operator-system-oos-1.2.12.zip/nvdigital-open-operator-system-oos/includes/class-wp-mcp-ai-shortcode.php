<?php
/**
 * Shortcode renderer for the front-end chat interface.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent parse errors on PHP < 7.4 by exiting before class definition.
if ( version_compare( PHP_VERSION, '7.4.0', '<' ) ) {
	return;
}

/**
 * Registers the [mcp_ai_chat] shortcode and enqueues frontend assets.
 */
class WP_MCP_AI_Shortcode {
	const SHORTCODE = 'mcp_ai_chat';

	/**
	 * Script handle for the chat interface.
	 */
	const SCRIPT_HANDLE = 'wp-mcp-ai-chat';

	/**
	 * Style handle for the chat interface.
	 */
	const STYLE_HANDLE = 'wp-mcp-ai-chat';

	/**
	 * Default lifetime for guest access tokens (in seconds).
	 * Used when no admin setting is configured.
	 */
	const GUEST_TOKEN_TTL = DAY_IN_SECONDS;

	/**
	 * Maximum allowed lifetime for guest tokens (7 days).
	 * Provides a hard cap regardless of configuration.
	 */
	const GUEST_TOKEN_MAX_TTL = 604800;

	/**
	 * Minimum allowed lifetime for guest tokens (60 seconds).
	 */
	const GUEST_TOKEN_MIN_TTL = 60;

	/**
	 * Prefix used for guest access transients.
	 */
	const GUEST_TOKEN_TRANSIENT_PREFIX = 'wp_mcp_ai_guest_access_';

	/**
	 * Default async tool timeout in seconds (5 minutes).
	 * Used when not configured in admin settings.
	 */
	const ASYNC_TOOL_TIMEOUT_DEFAULT = 300;

	/**
	 * Minimum async tool timeout in seconds (1 minute).
	 * Must match the 'min' value in the admin settings field.
	 */
	const ASYNC_TOOL_TIMEOUT_MIN = 60;

	/**
	 * Bootstraps hooks.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_assets' ) );

		// Defer user-dependent localisation (nonce, currentUserId, memory
		// endpoints) until after WordPress has determined the current user.
		// On init, get_current_user_id() returns 0, producing a nonce that
		// fails rest_cookie_check_errors for logged-in users.
		add_action( 'wp', array( $this, 'localize_user_dependent_data' ) );

		// Only register the legacy [mcp_ai_chat] shortcode when legacy mode is
		// active. Set define( 'WP_MCP_AI_LEGACY_CHAT_JS', false ) in wp-config.php
		// to disable legacy mode and use [nvoos_chat_spa] instead.
		if ( defined( 'WP_MCP_AI_LEGACY_CHAT_JS' ) && ! WP_MCP_AI_LEGACY_CHAT_JS ) {
			add_action( 'enqueue_block_assets', array( $this, 'maybe_enqueue_style_for_block_themes' ) );
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_assets' ) );
			return;
		}

		add_shortcode( self::SHORTCODE, array( $this, 'render_shortcode' ) );

		add_action( 'enqueue_block_assets', array( $this, 'maybe_enqueue_style_for_block_themes' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_assets' ) );
	}

	/**
	 * Register assets used by the shortcode.
	 *
	 * Uses a bundled JavaScript file (chat-bundle.js) that combines all chat-related
	 * services into a single optimized file. This reduces HTTP requests from 9 files
	 * to just 1 file, improving page load performance.
	 *
	 * The bundle includes:
	 * - sse-service.js (Server-Sent Events)
	 * - job-event-bus.js (event coordination)
	 * - cron-status-service.js (async job status)
	 * - chat-storage-service.js (localStorage)
	 * - chat-clipboard-service.js (copy functionality)
	 * - chat-markdown-service.js (markdown rendering)
	 * - chat-ui-utilities-service.js (DOM helpers)
	 * - chat-audio-service.js (TTS/transcription)
	 * - chat.js (main chat application)
	 */
	public function register_assets() {
		$is_elementor_editor = $this->is_elementor_editor_init();

		// Use TypeScript-compiled bundle when WP_MCP_AI_USE_TS_BUILD constant
		// or the orchestration settings option is enabled.
		$ts_build = ( defined( 'WP_MCP_AI_USE_TS_BUILD' ) && WP_MCP_AI_USE_TS_BUILD )
			|| ( class_exists( 'WP_MCP_AI_Settings_Registry' )
				&& WP_MCP_AI_Settings_Registry::get_setting( 'use_ts_build', false ) );
		$js_dir   = $ts_build ? 'assets/js/dist/' : 'assets/js/';
		$js_ext   = $ts_build ? '.js' : '.min.js';

		$script_relative            = $js_dir . 'chat-bundle' . $js_ext;
		$style_relative             = 'assets/css/chat.css';
		$cron_status_style_relative = 'assets/css/cron-status.css';

		$script_path            = WP_MCP_AI_URL . $script_relative;
		$style_path             = WP_MCP_AI_URL . $style_relative;
		$cron_status_style_path = WP_MCP_AI_URL . $cron_status_style_relative;

		$script_version            = $this->get_asset_version( $script_relative );
		$style_version             = $this->get_asset_version( $style_relative );
		$cron_status_style_version = $this->get_asset_version( $cron_status_style_relative );

		// Register cron status styles (still needed for CSS).

		wp_register_style(
			'wp-mcp-ai-cron-status',
			$cron_status_style_path,
			array(),
			$cron_status_style_version
		);

		wp_register_style(
			self::STYLE_HANDLE,
			$style_path,
			array( 'wp-mcp-ai-cron-status' ), // Depend on cron status CSS.
			$style_version
		);

		// Register voice chat styles.
		$voice_style_relative = 'assets/css/voice-chat.css';
		wp_register_style(
			'wp-mcp-ai-voice-chat',
			WP_MCP_AI_URL . $voice_style_relative,
			array( self::STYLE_HANDLE ),
			$this->get_asset_version( $voice_style_relative )
		);

		// Register embedded LLM client scripts via the Embedded addon (or Pro addon).
		// The addon provides the actual script files and handles registration.
		if ( ! defined( 'WP_MCP_AI_BASE_VERSION' ) || ! WP_MCP_AI_BASE_VERSION ) {
			/**
			 * Fires to let the Embedded addon register its WebLLM scripts.
			 *
			 * @since 2.3.0
			 */
			do_action( 'wp_mcp_ai_register_embedded_scripts' );
		}

		if ( class_exists( 'WP_MCP_AI_Admin_Settings' ) ) {
			$color_css = WP_MCP_AI_Admin_Settings::get_chat_color_css();

			if ( $color_css ) {
				wp_add_inline_style( self::STYLE_HANDLE, $color_css );
			}
		}

		// Register bundled chat script (includes all services in a single file).

		// This replaces the previous 8 separate script registrations with 1 bundled file.

		wp_register_script(
			self::SCRIPT_HANDLE,
			$script_path,
			array(), // No dependencies - all services are bundled together.
			$script_version,
			true
		);

		// Register realtime voice service (standalone, loaded on demand).
		$voice_realtime_relative = $this->resolve_js_asset_path( $js_dir, 'chat-voice-realtime-service', $js_ext );
		wp_register_script(
			'wp-mcp-ai-voice-realtime',
			WP_MCP_AI_URL . $voice_realtime_relative,
			array(),
			$this->get_asset_version( $voice_realtime_relative ),
			true
		);

		// Register WebRTC voice service (standalone, loaded on demand).
		$voice_webrtc_relative = $this->resolve_js_asset_path( $js_dir, 'chat-webrtc-service', $js_ext );
		wp_register_script(
			'wp-mcp-ai-voice-webrtc',
			WP_MCP_AI_URL . $voice_webrtc_relative,
			array(),
			$this->get_asset_version( $voice_webrtc_relative ),
			true
		);

		// Register translation service (standalone, loaded on demand).
		$translation_relative = $this->resolve_js_asset_path( $js_dir, 'chat-translation-service', $js_ext );
		wp_register_script(
			'wp-mcp-ai-translation',
			WP_MCP_AI_URL . $translation_relative,
			array( 'wp-mcp-ai-voice-webrtc' ),
			$this->get_asset_version( $translation_relative ),
			true
		);

		// Register transcription service (standalone, loaded on demand).
		$transcription_relative = $this->resolve_js_asset_path( $js_dir, 'chat-transcription-realtime-service', $js_ext );
		wp_register_script(
			'wp-mcp-ai-transcription',
			WP_MCP_AI_URL . $transcription_relative,
			array( 'wp-mcp-ai-voice-webrtc' ),
			$this->get_asset_version( $transcription_relative ),
			true
		);

		// Register browser voice service (standalone, loaded on demand).
		$voice_browser_relative = $this->resolve_js_asset_path( $js_dir, 'chat-browser-voice-service', $js_ext );
		wp_register_script(
			'wp-mcp-ai-voice-browser',
			WP_MCP_AI_URL . $voice_browser_relative,
			array(),
			$this->get_asset_version( $voice_browser_relative ),
			true
		);

		// Register voice mode integration (glues voice services to chat UI).
		$voice_integration_relative = $this->resolve_js_asset_path( $js_dir, 'chat-voice-mode-integration', $js_ext );
		wp_register_script(
			'wp-mcp-ai-voice-integration',
			WP_MCP_AI_URL . $voice_integration_relative,
			array( self::SCRIPT_HANDLE ),
			$this->get_asset_version( $voice_integration_relative ),
			true
		);

		// Memory endpoints are injected after user authentication via the
		// localize_user_dependent_data() method (hooked to 'wp'). Calling
		// get_chat_memory_endpoints_inline_script() here on 'init' would
		// return empty because get_current_user_id() is still 0.

		// Register chat bubble assets (floating chat widget).
		$bubble_script_relative = 'assets/js/chat-bubble.js';
		$bubble_style_relative  = 'assets/css/chat-bubble.css';

		if ( ! wp_script_is( 'wp-mcp-ai-chat-bubble', 'registered' ) ) {
			wp_register_script(
				'wp-mcp-ai-chat-bubble',
				WP_MCP_AI_URL . $bubble_script_relative,
				array( self::SCRIPT_HANDLE ),
				$this->get_asset_version( $bubble_script_relative ),
				true
			);
		}

		if ( ! wp_style_is( 'wp-mcp-ai-chat-bubble-style', 'registered' ) ) {
			wp_register_style(
				'wp-mcp-ai-chat-bubble-style',
				WP_MCP_AI_URL . $bubble_style_relative,
				array( self::STYLE_HANDLE ),
				$this->get_asset_version( $bubble_style_relative )
			);
		}

		// Skip localization in Elementor editor to prevent JavaScript conflicts.
		if ( $is_elementor_editor ) {
			// Provide minimal localization for Elementor editor to support voice chat and file uploads.
			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$chat_debug_mode = ! empty( $settings['enable_extended_logging'] ) && current_user_can( 'manage_options' );
			wp_localize_script(
				self::SCRIPT_HANDLE,
				'wpMcpAiChat',
				array(
					'restUrl'             => esc_url_raw( trailingslashit( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE ) ) ) ),
					'uploadEndpoint'      => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( 'wp/v2/media' ) ) ),
					'prepareEndpoint'     => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/attachments/prepare' ) ) ),
					'messagesEndpoint'    => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-client' ) ) ),
					'filesEndpoint'       => esc_url_raw( trailingslashit( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/files' ) ) ) ),
					'toolsEndpoint'       => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/tools' ) ) ),
					'transcriptsEndpoint' => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-transcripts' ) ) ),
					'voiceEndpoint'       => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/voice/session' ) ) ),
					'voiceConfigEndpoint' => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/voice/config' ) ) ),
					'historyPerPage'      => 20,
					'maxHistoryMessages'  => isset( $settings['max_history_messages'] ) ? absint( $settings['max_history_messages'] ) : 8,
					'currentUserId'       => get_current_user_id(),
					'nonce'               => wp_create_nonce( 'wp_rest' ),
					'showUsageCosts'      => false,
					'showCapabilityFlags' => false,
					'asyncToolTimeout'    => self::get_async_tool_timeout_ms( $settings ),
					'chatDebugMode'       => $chat_debug_mode,
					'isElementorEditor'   => true,
					'strings'             => array(
						'placeholder' => __( 'Ask something…', 'nvdigital-open-operator-system-oos' ),
					),
				)
			);
			return;
		}

		// Get plugin settings for cost display configuration.
		$settings         = WP_MCP_AI_Admin_Settings::get_settings();
		$chat_debug_mode  = ! empty( $settings['enable_extended_logging'] ) && current_user_can( 'manage_options' );
		$show_usage_costs = isset( $settings['show_usage_costs'] ) ? (bool) $settings['show_usage_costs'] : false;

		// Allow filtering of cost display setting.
		$show_usage_costs = apply_filters( 'wp_mcp_ai_show_usage_costs', $show_usage_costs, get_current_user_id() );

		// Get capability flags display setting.
		$show_capability_flags = isset( $settings['show_capability_flags'] ) ? (bool) $settings['show_capability_flags'] : false;

		// Allow filtering of capability flags display setting.
		$show_capability_flags = apply_filters( 'wp_mcp_ai_show_capability_flags', $show_capability_flags, get_current_user_id() );

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'wpMcpAiChat',
			array(
				'restUrl'             => esc_url_raw( trailingslashit( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE ) ) ) ),
				'uploadEndpoint'      => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( 'wp/v2/media' ) ) ),
				'prepareEndpoint'     => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/attachments/prepare' ) ) ),
				'messagesEndpoint'    => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-client' ) ) ),
				'filesEndpoint'       => esc_url_raw( trailingslashit( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/files' ) ) ) ),
				'toolsEndpoint'       => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/tools' ) ) ),
				'transcriptsEndpoint' => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-transcripts' ) ) ),
				'voiceEndpoint'       => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/voice/session' ) ) ),
				'voiceConfigEndpoint' => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/voice/config' ) ) ),
				'historyPerPage'      => 20,
				'maxHistoryMessages'  => isset( $settings['max_history_messages'] ) ? absint( $settings['max_history_messages'] ) : 8,
				'currentUserId'       => get_current_user_id(),
				'nonce'               => wp_create_nonce( 'wp_rest' ),
				'showUsageCosts'      => $show_usage_costs,
				'showCapabilityFlags' => $show_capability_flags,
				'asyncToolTimeout'    => self::get_async_tool_timeout_ms( $settings ),
				'chatDebugMode'       => $chat_debug_mode,
				'voiceMode'           => isset( $settings['voice_mode'] ) ? $settings['voice_mode'] : 'auto',
				'voiceAutoPlay'       => isset( $settings['voice_auto_play'] ) ? (bool) $settings['voice_auto_play'] : false,
				'vadEnabled'          => isset( $settings['enable_voice_activity_detection'] ) ? (bool) $settings['enable_voice_activity_detection'] : true,
				'vadSilenceThreshold' => isset( $settings['vad_silence_threshold'] ) ? absint( $settings['vad_silence_threshold'] ) : 1200,
				'vadMinSpeech'        => isset( $settings['vad_min_speech_duration'] ) ? absint( $settings['vad_min_speech_duration'] ) : 400,
				'vadMinRecordingMs'   => isset( $settings['vad_min_recording_ms'] ) ? absint( $settings['vad_min_recording_ms'] ) : 500,
				'vadAudioThreshold'   => isset( $settings['vad_audio_threshold'] ) ? floatval( $settings['vad_audio_threshold'] ) : -50,
				'strings'             => $this->get_strings(),
			)
		);
	}

	/**
	 * Overwrite user-dependent localisation keys (nonce, currentUserId) with
	 * values generated after WordPress has authenticated the current user.
	 *
	 * Also injects the chat-memory bridge endpoints so that
	 * chat-memory-service.js can locate the REST routes. Both operations
	 * must happen after user authentication because:
	 *   - wp_create_nonce('wp_rest') uses the current user's session token.
	 *     On init the user is still 0, producing a nonce that fails
	 *     rest_cookie_check_errors for logged-in users ("Cookie check failed").
	 *   - get_chat_memory_endpoints_inline_script() skips guests, but on
	 *     init every user appears to be a guest.
	 *
	 * Hooked to 'wp' so that determine_current_user has already run.
	 * For admin pages the enqueue_chat_assets() path in the test-page base
	 * class also calls wp_localize_script later (on admin_enqueue_scripts),
	 * but the 'wp' hook provides a single safe correction point for the
	 * frontend shortcode, block, and Elementor widget surfaces.
	 *
	 * @since 1.1.29
	 *
	 * @return void
	 */
	public function localize_user_dependent_data() {
		// Only localise when the handle is registered (should always be true
		// after init, but defensive).
		if ( ! wp_script_is( self::SCRIPT_HANDLE, 'registered' ) ) {
			return;
		}

		$user_id = get_current_user_id();

		// Preserve chatDebugMode from the initial register_assets() call
		// so the second wp_localize_script call (which WordPress appends
		// as a new `var wpMcpAiChat = {...}` declaration) does not strip
		// the debugging flag from the JS global.
		$settings        = WP_MCP_AI_Admin_Settings::get_settings();
		$chat_debug_mode = ! empty( $settings['enable_extended_logging'] ) && current_user_can( 'manage_options' );

		// Overwrite the nonce and current user ID that were set (with user 0)
		// during register_assets() on init.
		//
		// Use wp_add_inline_script to merge individual properties onto the
		// existing window.wpMcpAiChat object instead of calling
		// wp_localize_script, which would create a new `var wpMcpAiChat = ...`
		// declaration that strips every other key (messagesEndpoint, restUrl,
		// etc.) that was set during register_assets().
		$update_script  = 'window.wpMcpAiChat = window.wpMcpAiChat || {};';
		$update_script .= 'window.wpMcpAiChat.nonce = ' . wp_json_encode( wp_create_nonce( 'wp_rest' ) ) . ';';
		$update_script .= 'window.wpMcpAiChat.currentUserId = ' . wp_json_encode( $user_id ) . ';';
		$update_script .= 'window.wpMcpAiChat.chatDebugMode = ' . wp_json_encode( $chat_debug_mode ) . ';';
		wp_add_inline_script( self::SCRIPT_HANDLE, $update_script, 'after' );

		// Inject the chat-memory bridge endpoints now that we know the user.
		$memory_endpoints = self::get_chat_memory_endpoints_inline_script();
		if ( '' !== $memory_endpoints ) {
			wp_add_inline_script( self::SCRIPT_HANDLE, $memory_endpoints, 'after' );
		}

		// Inject the storage-worker config (no user gate; benefits guests too).
		$storage_worker = self::get_storage_worker_inline_script();
		if ( '' !== $storage_worker ) {
			wp_add_inline_script( self::SCRIPT_HANDLE, $storage_worker, 'after' );
		}
	}

	/**
	 * Determine the version string for an asset, using the file modification time when available.
	 *
	 * Falls back to the plugin version when the asset does not exist on disk.
	 *
	 * @param string $relative_path Asset path relative to the plugin root.
	 * @return string
	 */
	protected function get_asset_version( $relative_path ) {
		$relative_path = ltrim( $relative_path, '/' );
		$absolute_path = WP_MCP_AI_PATH . $relative_path;

		if ( file_exists( $absolute_path ) ) {
			$modified = filemtime( $absolute_path );

			if ( $modified ) {
				return WP_MCP_AI_VERSION . '.' . $modified;
			}
		}

		return WP_MCP_AI_VERSION;
	}

	/**
	 * Resolve the best available JS file extension for a given basename.
	 *
	 * When the build system produces .min.js files but one is missing on disk,
	 * gracefully fall back to the non-minified .js source to prevent MIME-type
	 * errors (404s served as text/html by the web server).
	 *
	 * @since 1.2.0
	 *
	 * @param string $js_dir   Directory path relative to plugin root (e.g. 'assets/js/').
	 * @param string $basename File basename without extension.
	 * @param string $js_ext   Preferred extension (e.g. '.min.js' or '.js').
	 * @return string Relative path with the best available extension.
	 */
	protected function resolve_js_asset_path( $js_dir, $basename, $js_ext ) {
		$relative = $js_dir . $basename . $js_ext;

		// If we prefer .min.js but it doesn't exist, try .js.
		if ( '.min.js' === $js_ext && ! file_exists( WP_MCP_AI_PATH . $relative ) ) {
			$fallback = $js_dir . $basename . '.js';
			if ( file_exists( WP_MCP_AI_PATH . $fallback ) ) {
				return $fallback;
			}
		}

		return $relative;
	}

	/**
	 * Ensure block themes and the Site Editor receive the base styles when editing.
	 */
	public function maybe_enqueue_style_for_block_themes() {
		if ( is_admin() && wp_style_is( self::STYLE_HANDLE, 'registered' ) ) {
			wp_enqueue_style( self::STYLE_HANDLE );
		}
	}

	/**
	 * Check if currently in Elementor editor mode.
	 *
	 * @return bool True if in Elementor editor mode, false otherwise.
	 */
	protected function is_elementor_editor() {
		if ( class_exists( '\Elementor\Plugin' ) ) {
			$elementor = \Elementor\Plugin::instance();
			if ( $elementor && $elementor->editor && $elementor->editor->is_edit_mode() ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check if currently in Elementor editor context during early initialization.
	 *
	 * This method checks for Elementor editor context when Elementor may not be fully loaded yet.
	 * Use during init or earlier hooks when Elementor\Plugin may not be available.
	 *
	 * @return bool True if in Elementor editor mode, false otherwise.
	 */
	protected function is_elementor_editor_init() {
		// Check via GET parameter (Elementor uses 'action=elementor' for editor).
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Elementor handles its own nonce verification.
		if ( isset( $_GET['action'] ) && 'elementor' === sanitize_text_field( wp_unslash( $_GET['action'] ) ) ) {
			return true;
		}

		// Fallback to full check if Elementor is loaded.
		return $this->is_elementor_editor();
	}

	/**
	 * Render the editor preview notice for Elementor editor.
	 *
	 * @return string HTML for the editor preview notice.
	 */
	protected function render_editor_notice() {
		ob_start();
		?>
		<div class="wp-mcp-ai-chat__editor-notice">
			<strong><?php esc_html_e( 'Editor Preview:', 'nvdigital-open-operator-system-oos' ); ?></strong>
			<?php esc_html_e( 'This is a preview of the chat widget. Full functionality will be available on the published page.', 'nvdigital-open-operator-system-oos' ); ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Check if embedded provider is available for the assistant.
	 *
	 * @param string $provider The provider to check.
	 * @return bool True if embedded provider is available, false otherwise.
	 */
	protected function is_embedded_provider_available( $provider ) {
		if ( 'embedded' !== $provider ) {
			return false;
		}
		// Check via filter (Embedded addon or Pro addon can provide embedded support).
		return (bool) apply_filters( 'wp_mcp_ai_is_embedded_provider_available', defined( 'WP_MCP_AI_PRO_VERSION' ) );
	}

	/**
	 * Get localized strings for the chat interface.
	 *
	 * Provides all user-facing text strings for the JavaScript chat widget,
	 * including UI labels, status messages, error messages, and role labels.
	 * Strings are translatable via WordPress i18n functions.
	 *
	 * @return array Array of localized strings for JavaScript.
	 */
	protected function get_strings() {
		$strings = array(
			'placeholder'                   => __( 'Ask something…', 'nvdigital-open-operator-system-oos' ),
			'send'                          => __( 'Send', 'nvdigital-open-operator-system-oos' ),
			'build'                         => __( 'Build', 'nvdigital-open-operator-system-oos' ),
			'building'                      => __( 'Building assistant…', 'nvdigital-open-operator-system-oos' ),
			'buildSuccess'                  => __( 'Assistant created successfully!', 'nvdigital-open-operator-system-oos' ),
			'buildError'                    => __( 'Failed to create assistant. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'bundlingMessages'              => __( 'Preparing to send…', 'nvdigital-open-operator-system-oos' ),
			'sending'                       => __( 'Sending message…', 'nvdigital-open-operator-system-oos' ),
			'waiting'                       => __( 'Waiting for the assistant…', 'nvdigital-open-operator-system-oos' ),
			'error'                         => __( 'Something went wrong. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'missingAssistant'              => __( 'Assistant configuration was not found.', 'nvdigital-open-operator-system-oos' ),
			'notAuthorized'                 => __( 'You do not have permission to chat with this assistant.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: tool name being executed */
			'toolExecuting'                 => __( 'Running tool: %s', 'nvdigital-open-operator-system-oos' ),
			'toolSuccess'                   => __( 'Tool completed successfully.', 'nvdigital-open-operator-system-oos' ),
			'toolError'                     => __( 'The tool request failed.', 'nvdigital-open-operator-system-oos' ),
			'toolQueued'                    => __( 'Tool queued. Results will appear shortly.', 'nvdigital-open-operator-system-oos' ),
			'toolPolling'                   => __( 'Tool is processing…', 'nvdigital-open-operator-system-oos' ),
			'toolTimeout'                   => __( 'Tool timed out before completing.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: tool failure error message */
			'toolFailed'                    => __( 'Tool failed: %s', 'nvdigital-open-operator-system-oos' ),
			'speechToolSuccess'             => __( 'Speech audio saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'imageToolSuccess'              => __( 'Image saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: task name */
			'toolShortcutLabel'             => __( 'Insert task: %s', 'nvdigital-open-operator-system-oos' ),
			'emptyMessage'                  => __( 'Enter a message before sending.', 'nvdigital-open-operator-system-oos' ),
			'attachFile'                    => __( 'Attach file', 'nvdigital-open-operator-system-oos' ),
			'transcribe'                    => __( 'Transcribe', 'nvdigital-open-operator-system-oos' ),
			'transcribeAudio'               => __( 'Transcribe audio', 'nvdigital-open-operator-system-oos' ),
			'transcribing'                  => __( 'Transcribing audio…', 'nvdigital-open-operator-system-oos' ),
			'recording'                     => __( 'Recording… tap to stop.', 'nvdigital-open-operator-system-oos' ),
			'stopRecording'                 => __( 'Stop recording', 'nvdigital-open-operator-system-oos' ),
			'recordingError'                => __( 'Could not access your microphone. Please allow access or upload an audio file instead.', 'nvdigital-open-operator-system-oos' ),
			'transcriptionError'            => __( 'The transcription request failed. Please try again.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: file name */
			'transcriptionSuccess'          => __( 'Inserted transcription from "%s".', 'nvdigital-open-operator-system-oos' ),
			'transcriptionFileTooLarge'     => __( 'The selected audio file is too large. Please choose a file under 25MB.', 'nvdigital-open-operator-system-oos' ),
			'transcribeChooseSource'        => __( 'Press OK to record with your microphone, or Cancel to choose an audio file.', 'nvdigital-open-operator-system-oos' ),
			'transcriptionEndpointNotFound' => __( 'Transcription service is temporarily unavailable. Please try again later.', 'nvdigital-open-operator-system-oos' ),
			'transcriptionNotConfigured'    => __( 'Transcription is not properly configured. Please contact support.', 'nvdigital-open-operator-system-oos' ),
			'translate'                     => __( 'Translate', 'nvdigital-open-operator-system-oos' ),
			'translateAudio'                => __( 'Translate audio', 'nvdigital-open-operator-system-oos' ),
			'translating'                   => __( 'Translating audio…', 'nvdigital-open-operator-system-oos' ),
			'translationError'              => __( 'The translation request failed. Please try again.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: file name */
			'translationSuccess'            => __( 'Inserted translation from "%s".', 'nvdigital-open-operator-system-oos' ),
			'translationFileTooLarge'       => __( 'The selected audio file is too large. Please choose a file under 25MB.', 'nvdigital-open-operator-system-oos' ),
			'translateChooseSource'         => __( 'Press OK to record with your microphone, or Cancel to choose an audio file.', 'nvdigital-open-operator-system-oos' ),
			'translationEndpointNotFound'   => __( 'Translation service is temporarily unavailable. Please try again later.', 'nvdigital-open-operator-system-oos' ),
			'translationNotConfigured'      => __( 'Translation is not properly configured. Please contact support.', 'nvdigital-open-operator-system-oos' ),
			'voiceChatError'                => __( 'Voice chat failed. Please try again or type your message.', 'nvdigital-open-operator-system-oos' ),
			'voiceChatEndpointNotFound'     => __( 'Voice chat service is temporarily unavailable. Please type your message instead.', 'nvdigital-open-operator-system-oos' ),
			'voiceChatNotConfigured'        => __( 'Voice chat is not properly configured. Please type your message instead.', 'nvdigital-open-operator-system-oos' ),
			'voiceChatProcessing'           => __( 'Processing your voice message…', 'nvdigital-open-operator-system-oos' ),
			'voiceChatNoData'               => __( 'No audio was recorded.', 'nvdigital-open-operator-system-oos' ),
			'voiceChatFileTooLarge'         => __( 'The recorded audio is too large. Please try a shorter message.', 'nvdigital-open-operator-system-oos' ),
			'voiceChatPermissionDenied'     => __( 'Microphone access was denied.', 'nvdigital-open-operator-system-oos' ),
			'voiceChatRecording'            => __( 'Recording… speak now or tap to stop and send. (Hands-free: pauses auto-send)', 'nvdigital-open-operator-system-oos' ),
			'voiceChatSending'              => __( 'Sending your message…', 'nvdigital-open-operator-system-oos' ),
			'attachmentsLabel'              => __( 'Attachments', 'nvdigital-open-operator-system-oos' ),
			'removeAttachment'              => __( 'Remove', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: file name being uploaded */
			'uploadingFile'                 => __( 'Uploading "%s"…', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: file name being processed */
			'processingFile'                => __( 'Processing "%s"…', 'nvdigital-open-operator-system-oos' ),
			'uploadError'                   => __( 'The file could not be uploaded. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'uploadInProgress'              => __( 'Please wait for uploads to finish before sending.', 'nvdigital-open-operator-system-oos' ),
			'downloadAttachment'            => __( 'Download attachment', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: file name with unsupported type */
			'unsupportedFileType'           => __( '"%s" is not a supported file type. Please choose a different file.', 'nvdigital-open-operator-system-oos' ),
			'unsupportedMultipleFiles'      => __( 'Some selected files are not supported. Please try different files.', 'nvdigital-open-operator-system-oos' ),
			'unsupportedFileLabel'          => __( 'This file', 'nvdigital-open-operator-system-oos' ),
			'expandTranscript'              => __( 'Expand conversation', 'nvdigital-open-operator-system-oos' ),
			'collapseTranscript'            => __( 'Collapse conversation', 'nvdigital-open-operator-system-oos' ),
			'newConversation'               => __( 'Start new conversation', 'nvdigital-open-operator-system-oos' ),
			'loadConversation'              => __( 'Load conversation', 'nvdigital-open-operator-system-oos' ),
			'jsonResponse'                  => __( 'JSON response', 'nvdigital-open-operator-system-oos' ),
			'historyToggleShow'             => __( 'Show previous conversations', 'nvdigital-open-operator-system-oos' ),
			'historyToggleHide'             => __( 'Hide previous conversations', 'nvdigital-open-operator-system-oos' ),
			'historyLoading'                => __( 'Loading conversations…', 'nvdigital-open-operator-system-oos' ),
			'historyEmpty'                  => __( 'No previous conversations yet.', 'nvdigital-open-operator-system-oos' ),
			'historyError'                  => __( 'Unable to load conversation history.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %d: number of messages in chat history */
			'historyMessageCount'           => __( '%d messages', 'nvdigital-open-operator-system-oos' ),
			'historySingleMessage'          => __( '1 message', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: conversation identifier */
			'historyPreviewFallback'        => __( 'Conversation %s', 'nvdigital-open-operator-system-oos' ),
			'historySessionLoading'         => __( 'Loading conversation…', 'nvdigital-open-operator-system-oos' ),
			'historySessionError'           => __( 'Unable to load this conversation. Please try again.', 'nvdigital-open-operator-system-oos' ),
			'historyNoMessages'             => __( 'No messages were saved for this conversation.', 'nvdigital-open-operator-system-oos' ),
			'savingPost'                    => __( 'Saving post…', 'nvdigital-open-operator-system-oos' ),
			'saveConversation'              => __( 'Save conversation', 'nvdigital-open-operator-system-oos' ),
			'savingConversation'            => __( 'Saving current conversation...', 'nvdigital-open-operator-system-oos' ),
			'conversationSaved'             => __( 'Conversation saved successfully.', 'nvdigital-open-operator-system-oos' ),
			'saveFailed'                    => __( 'Failed to save conversation. See console for details.', 'nvdigital-open-operator-system-oos' ),
			'saveFailedProceed'             => __( 'Failed to save conversation: ', 'nvdigital-open-operator-system-oos' ),
			'proceedAnyway'                 => __( 'Do you want to proceed anyway? Your current conversation will be lost.', 'nvdigital-open-operator-system-oos' ),
			'saveFailedKeepingConversation' => __( 'Conversation not cleared. You can try again later.', 'nvdigital-open-operator-system-oos' ),
			'noConversationToSave'          => __( 'No conversation to save. Start chatting first!', 'nvdigital-open-operator-system-oos' ),
			'saveSkipped'                   => __( 'Save not available for this conversation.', 'nvdigital-open-operator-system-oos' ),
			'confirmClearConversation'      => __( 'Start a new conversation? Your current conversation will be saved automatically.', 'nvdigital-open-operator-system-oos' ),
			'noConversationToExport'        => __( 'No conversation to export. Start chatting first!', 'nvdigital-open-operator-system-oos' ),
			'exportFormatPrompt'            => __( 'Choose export format:\n- json\n- markdown\n- text', 'nvdigital-open-operator-system-oos' ),
			'invalidExportFormat'           => __( 'Invalid format. Please choose json, markdown, or text.', 'nvdigital-open-operator-system-oos' ),
			'exportFailed'                  => __( 'Export failed: ', 'nvdigital-open-operator-system-oos' ),
			'exportSuccess'                 => __( 'Conversation exported successfully as ', 'nvdigital-open-operator-system-oos' ),
			'deleteConversation'            => __( 'Delete this conversation', 'nvdigital-open-operator-system-oos' ),
			'confirmDeleteConversation'     => __( 'Are you sure you want to delete this conversation? This action cannot be undone.', 'nvdigital-open-operator-system-oos' ),
			'veoVideoToolSuccess'           => __( 'Video generated successfully and saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'videoNotSupported'             => __( 'Your browser does not support video playback.', 'nvdigital-open-operator-system-oos' ),
			'downloadVideo'                 => __( 'Download video', 'nvdigital-open-operator-system-oos' ),
			'videoGenerating'               => __( 'Video generation started. Your video will be available within approximately 5 minutes.', 'nvdigital-open-operator-system-oos' ),
			'videoPending'                  => __( 'Pending • ~5 min', 'nvdigital-open-operator-system-oos' ),
			'geminiImageToolSuccess'        => __( 'Gemini image saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'editGeminiImageToolSuccess'    => __( 'Gemini image edited and saved to the Media Library.', 'nvdigital-open-operator-system-oos' ),
			'tokensLabel'                   => __( 'Tokens', 'nvdigital-open-operator-system-oos' ),
			'costLabel'                     => __( 'Cost', 'nvdigital-open-operator-system-oos' ),
			'estimatedCostLabel'            => __( 'Est. Cost', 'nvdigital-open-operator-system-oos' ),
			/* translators: %d: number of tokens used */
			'tokensUsed'                    => __( '%d tokens', 'nvdigital-open-operator-system-oos' ),
			/* translators: %d: total tokens, %d: input tokens, %d: output tokens */
			'tokensBreakdown'               => __( '%1$d total (%2$d in / %3$d out)', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: cost in USD */
			'costAmount'                    => __( '$%s', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: tool name that is processing */
			'toolProcessing'                => __( '%s is temporarily processing your request. The assistant will continue using available information.', 'nvdigital-open-operator-system-oos' ),
			/* translators: %s: tool name that is temporarily unavailable */
			'toolTemporarilyUnavailable'    => __( '%s temporarily unavailable', 'nvdigital-open-operator-system-oos' ),
			// Embedded LLM client messages.
			'embeddedClientMissing'         => __( 'Embedded LLM client not loaded. Please refresh the page.', 'nvdigital-open-operator-system-oos' ),
			'embeddedClientInvalid'         => __( 'Embedded LLM client is not properly initialized. Please refresh the page and clear your browser cache.', 'nvdigital-open-operator-system-oos' ),
			'embeddedClientInitializing'    => __( 'Initializing embedded AI client...', 'nvdigital-open-operator-system-oos' ),
			'embeddedClientInitError'       => __( 'Failed to initialize embedded AI client: ', 'nvdigital-open-operator-system-oos' ),
			'roleLabels'                    => array(
				'assistant' => __( 'Assistant', 'nvdigital-open-operator-system-oos' ),
				'user'      => __( 'You', 'nvdigital-open-operator-system-oos' ),
				'system'    => __( 'System', 'nvdigital-open-operator-system-oos' ),
				'tool'      => __( 'Tool', 'nvdigital-open-operator-system-oos' ),
			),
		);

		/**
		 * Filter the localized strings for the chat interface.
		 *
		 * Allows developers and themes to customize the chat interface text,
		 * enabling white-label customization, brand-specific messaging, and
		 * contextual modifications without modifying core plugin code.
		 *
		 * @since 1.0.0
		 *
		 * @param array $strings Array of localized strings with keys matching
		 *                       JavaScript properties (e.g., 'placeholder', 'send', 'error').
		 *
		 * @example
		 * ```php
		 * add_filter( 'wp_mcp_ai_chat_strings', function( $strings ) {
		 *     $strings['placeholder'] = 'How can we assist you today?';
		 *     $strings['error'] = 'Something went wrong. Please contact support.';
		 *     return $strings;
		 * });
		 * ```
		 */
		return apply_filters( 'wp_mcp_ai_chat_strings', $strings );
	}

	/**
	 * Apply script localization to the chat script handle.
	 * This method centralizes the localization logic to avoid duplication.
	 *
	 * @param array $settings Plugin settings array.
	 * @return void
	 */
	protected function apply_script_localization( $settings ) {
		$show_usage_costs      = isset( $settings['show_usage_costs'] ) ? (bool) $settings['show_usage_costs'] : false;
		$show_usage_costs      = apply_filters( 'wp_mcp_ai_show_usage_costs', $show_usage_costs, get_current_user_id() );
		$show_capability_flags = isset( $settings['show_capability_flags'] ) ? (bool) $settings['show_capability_flags'] : false;
		$show_capability_flags = apply_filters( 'wp_mcp_ai_show_capability_flags', $show_capability_flags, get_current_user_id() );

		wp_localize_script(
			self::SCRIPT_HANDLE,
			'wpMcpAiChat',
			array(
				'restUrl'             => esc_url_raw( trailingslashit( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE ) ) ) ),
				'uploadEndpoint'      => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( 'wp/v2/media' ) ) ),
				'prepareEndpoint'     => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/attachments/prepare' ) ) ),
				'messagesEndpoint'    => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-client' ) ) ),
				'filesEndpoint'       => esc_url_raw( trailingslashit( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/files' ) ) ) ),
				'toolsEndpoint'       => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/tools' ) ) ),
				'transcriptsEndpoint' => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-transcripts' ) ) ),
				'historyPerPage'      => 20,
				'maxHistoryMessages'  => isset( $settings['max_history_messages'] ) ? absint( $settings['max_history_messages'] ) : 8,
				'currentUserId'       => get_current_user_id(),
				'nonce'               => wp_create_nonce( 'wp_rest' ),
				'showUsageCosts'      => $show_usage_costs,
				'showCapabilityFlags' => $show_capability_flags,
				'asyncToolTimeout'    => self::get_async_tool_timeout_ms( $settings ),
				'vadEnabled'          => isset( $settings['enable_voice_activity_detection'] ) ? (bool) $settings['enable_voice_activity_detection'] : true,
				'vadSilenceThreshold' => isset( $settings['vad_silence_threshold'] ) ? absint( $settings['vad_silence_threshold'] ) : 1200,
				'vadMinSpeech'        => isset( $settings['vad_min_speech_duration'] ) ? absint( $settings['vad_min_speech_duration'] ) : 400,
				'vadMinRecordingMs'   => isset( $settings['vad_min_recording_ms'] ) ? absint( $settings['vad_min_recording_ms'] ) : 500,
				'vadAudioThreshold'   => isset( $settings['vad_audio_threshold'] ) ? floatval( $settings['vad_audio_threshold'] ) : -50,
				'strings'             => $this->get_strings(),
			)
		);
	}

	/**
	 * Render the chat shortcode.
	 *
	 * @param array  $atts    Shortcode attributes.
	 * @param string $content Content (unused).
	 * @param string $tag     Shortcode tag.
	 *
	 * @return string
	 */
	/**
	 * Render the shortcode output.
	 *
	 * @param array|string $atts    Shortcode attributes.
	 * @param string       $content Shortcode content.
	 * @param string       $tag     Shortcode tag name.
	 * @return string Rendered HTML output.
	 */
	public function render_shortcode( $atts, $content = '', $tag = '' ) {
		try {
			$atts = shortcode_atts(
				array(
					'assistant'             => '',
					'profession'            => '',
					'team'                  => '', // Team ID for multi-agent coordination.
					'allow_guests'          => 'false',
					'save_transcript'       => 'true',
					'enable_streaming'      => 'true',
					'allow_sensitive_tools' => 'false',
					'template'              => 'classic',
					'cpt_actions'           => '', // JSON-encoded array of CPT action buttons.
					'additional_tools'      => '', // Comma-separated list of tool slugs to make available regardless of assistant config.
				),
				$atts,
				$tag
			);

			$assistant_id          = self::resolve_assistant_id( $atts['assistant'] );
			$allow_guests          = wp_validate_boolean( $atts['allow_guests'] );
			$save_transcript       = wp_validate_boolean( $atts['save_transcript'] );
			$enable_streaming      = wp_validate_boolean( $atts['enable_streaming'] );
			$allow_sensitive_tools = wp_validate_boolean( $atts['allow_sensitive_tools'] );
			$template              = sanitize_key( $atts['template'] );

			// Validate template value - default to 'classic' if invalid.
			$allowed_templates = array( 'classic', 'speech-bubbles', 'compact', 'sidebar' );
			if ( ! in_array( $template, $allowed_templates, true ) ) {
				$template = 'classic';
			}

			// Fetch settings once for use throughout this method.
			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			// Check if this is a profession test request.
			$is_profession_test = is_string( $assistant_id ) && 0 === strpos( $assistant_id, 'profession_' );

			if ( ! $assistant_id ) {
				$assistant_id = isset( $settings['default_assistant'] ) ? absint( $settings['default_assistant'] ) : 0;
			}

			if ( ! $assistant_id ) {
				WP_MCP_AI_Logger::log_warning(
					'Shortcode rendered without valid assistant ID',
					array(
						'attributes' => $atts,
						'context'    => 'shortcode_rendering',
					)
				);
				return '<div class="wp-mcp-ai-chat__notice">' . esc_html__( 'No assistant has been selected. Please provide an assistant attribute or configure a default.', 'nvdigital-open-operator-system-oos' ) . '</div>';
			}

			// For profession tests, validate the profession and get associated assistant for permissions.
			if ( $is_profession_test ) {
				$profession_id = absint( str_replace( 'profession_', '', $assistant_id ) );
				$profession    = get_post( $profession_id );

				if ( ! $profession || 'mcp_ai_profession' !== $profession->post_type ) {
					WP_MCP_AI_Logger::log_error(
						'Shortcode attempted to render unavailable profession',
						array(
							'assistant_id'      => $assistant_id,
							'profession_id'     => $profession_id,
							'profession_exists' => (bool) $profession,
							'post_type'         => $profession ? $profession->post_type : null,
							'attributes'        => $atts,
						)
					);
					return '<div class="wp-mcp-ai-chat__notice">' . esc_html__( 'The requested profession is not available.', 'nvdigital-open-operator-system-oos' ) . '</div>';
				}

				// For permissions check, use the profession's associated assistant or default assistant.
				$permissions_assistant_id = get_post_meta( $profession_id, '_wp_mcp_ai_profession_associated_assistant', true );
				$permissions_assistant_id = absint( $permissions_assistant_id );
				if ( ! $permissions_assistant_id ) {
					$permissions_assistant_id = isset( $settings['default_assistant'] ) ? absint( $settings['default_assistant'] ) : 0;
				}
				$assistant = $permissions_assistant_id ? get_post( $permissions_assistant_id ) : null;
			} else {
				$permissions_assistant_id = absint( $assistant_id );
				$assistant                = get_post( $assistant_id );
			}

			// Handle team parameter for multi-agent coordination.
			$team_id               = ! empty( $atts['team'] ) ? absint( $atts['team'] ) : 0;
			$team_data             = null;
			$team_members          = array();
			$orchestration_mode    = '';
			$result_aggregation    = '';
			$multi_agent_enabled   = false;
			$supports_unified_mode = false;

			if ( $team_id > 0 ) {
				$team_post = get_post( $team_id );
				if ( $team_post && 'mcp_ai_team' === $team_post->post_type ) {
					// Team exists - check if multi-agent is enabled.
					$multi_agent_enabled = WP_MCP_AI_Settings_Registry::get_setting( 'enable_multi_agent_teams', true );

					if ( $multi_agent_enabled ) {
						// Load team configuration.
						$team_members = get_post_meta( $team_id, '_wp_mcp_ai_team_members', true );
						if ( ! is_array( $team_members ) ) {
							$team_members = array();
						}

						$orchestration_mode = get_post_meta( $team_id, '_wp_mcp_ai_team_orchestration_mode', true );
						$result_aggregation = get_post_meta( $team_id, '_wp_mcp_ai_team_result_aggregation', true );

						$orchestration_mode = $orchestration_mode ? $orchestration_mode : 'sequential';
						$result_aggregation = $result_aggregation ? $result_aggregation : 'consensus';

						$supports_unified_mode = count( $team_members ) > 1;

						$team_data = array(
							'id'                    => $team_id,
							'title'                 => $team_post->post_title,
							'members'               => $team_members,
							'orchestration_mode'    => $orchestration_mode,
							'result_aggregation'    => $result_aggregation,
							'multi_agent_enabled'   => $multi_agent_enabled,
							'supports_unified_mode' => $supports_unified_mode,
						);

						WP_MCP_AI_Logger::log_event(
							'shortcode_team_detected',
							'Team chat interface initialized',
							array(
								'team_id'               => $team_id,
								'member_count'          => count( $team_members ),
								'orchestration_mode'    => $orchestration_mode,
								'supports_unified_mode' => $supports_unified_mode,
							)
						);
					}
				}
			}

			// Validate assistant for permissions (not required for profession tests with no associated assistant).
			if ( ! $is_profession_test || $permissions_assistant_id ) {
				if ( ! $assistant || WP_MCP_AI_Assistant_CPT::POST_TYPE !== $assistant->post_type || 'publish' !== $assistant->post_status ) {
					WP_MCP_AI_Logger::log_error(
						'Shortcode attempted to render unavailable assistant',
						array(
							'assistant_id'             => $assistant_id,
							'permissions_assistant_id' => isset( $permissions_assistant_id ) ? $permissions_assistant_id : null,
							'is_profession_test'       => $is_profession_test,
							'assistant_exists'         => (bool) $assistant,
							'post_type'                => $assistant ? $assistant->post_type : null,
							'post_status'              => $assistant ? $assistant->post_status : null,
							'attributes'               => $atts,
						)
					);
					return '<div class="wp-mcp-ai-chat__notice">' . esc_html__( 'The requested assistant is not available.', 'nvdigital-open-operator-system-oos' ) . '</div>';
				}
			}

			$guest_token = '';
			if ( $allow_guests ) {
				// Use permissions_assistant_id for guest token if available, otherwise assistant_id.
				$guest_token_assistant_id = isset( $permissions_assistant_id ) ? $permissions_assistant_id : $assistant_id;
				$guest_token              = self::generate_guest_token( $guest_token_assistant_id );
			}

			// Use the effective capability (per-assistant or global).
			// For profession tests, use the permissions_assistant_id for capability check.
			$capability_assistant_id = isset( $permissions_assistant_id ) ? $permissions_assistant_id : $assistant_id;
			$capability              = function_exists( 'wp_mcp_ai_get_effective_chat_capability' )
				? wp_mcp_ai_get_effective_chat_capability( $capability_assistant_id, 'shortcode' )
				: wp_mcp_ai_get_required_chat_capability( $capability_assistant_id, 'shortcode' );

			if ( $guest_token ) {
				$capability = 'public';
			}

			if ( $capability && 'public' !== $capability && ! current_user_can( $capability ) ) {
				$current_user_id   = get_current_user_id();
				$current_user      = wp_get_current_user();
				$user_capabilities = ( $current_user && isset( $current_user->allcaps ) ) ? $current_user->allcaps : array();

				// Only log a warning when a logged-in user lacks the required capability.
				// Unauthenticated visitors hitting a restricted shortcode is expected
				// behaviour and does not need a warning log entry — use debug level instead
				// so that it remains visible when debug logging is enabled.
				if ( $current_user_id > 0 ) {
					WP_MCP_AI_Logger::log_warning(
						'Shortcode access denied due to insufficient capability',
						array(
							'assistant_id'        => $assistant_id,
							'required_capability' => $capability,
							'user_id'             => $current_user_id,
							'user_capabilities'   => $user_capabilities,
						)
					);
				} else {
					WP_MCP_AI_Logger::log_event(
						'debug',
						'Shortcode access denied: visitor lacks required capability',
						array(
							'assistant_id'        => $assistant_id,
							'required_capability' => $capability,
						)
					);
				}
				return '<div class="wp-mcp-ai-chat__notice">' . esc_html__( 'You do not have permission to chat with this assistant.', 'nvdigital-open-operator-system-oos' ) . '</div>';
			}

			// Render the actual widget in Elementor editor for better preview.
			// The WP_DEBUG fix in the main plugin class ensures debug output.

			// won't break the editor when WP_DEBUG is enabled.
			// Use the init variant so the editor detection also honours the
			// `action=elementor` request flag, matching register_assets().
			$is_elementor_editor = $this->is_elementor_editor_init();

			// Get assistant provider and model for client-side execution (embedded provider).
			// This must be done BEFORE enqueuing chat scripts to ensure correct dependency order.
			// For profession tests, use the permissions_assistant_id to get the associated assistant's provider.
			// If permissions_assistant_id is not set, fall back to assistant_id (though this is rare).
			$assistant_provider            = '';
			$assistant_model               = '';
			$assistant_config_for_provider = array(); // Initialize to empty array to prevent undefined variable errors.
			if ( class_exists( 'WP_MCP_AI_Assistant_CPT' ) ) {
				// Determine which assistant ID to use for provider check.
				if ( $is_profession_test && isset( $permissions_assistant_id ) ) {
					// For profession tests, check the associated assistant's provider.
					$provider_check_id = $permissions_assistant_id;
				} else {
					// For regular assistants or profession tests without associated assistant.
					$provider_check_id = $assistant_id;
				}

				$assistant_config_for_provider = WP_MCP_AI_Assistant_CPT::get_assistant_configuration( absint( $provider_check_id ) );
				$assistant_provider            = isset( $assistant_config_for_provider['provider'] ) ? sanitize_key( $assistant_config_for_provider['provider'] ) : '';
				$assistant_model               = isset( $assistant_config_for_provider['model'] ) ? sanitize_text_field( $assistant_config_for_provider['model'] ) : '';
			}

			// Enqueue embedded LLM client scripts if this assistant uses the client-side WebLLM provider.
			// Server-side GGUF models share the 'embedded' provider key but are served by llama.cpp on
			// the server — they do not need the WebLLM browser scripts.
			// Multiple widgets can coexist - each checks state.config.provider in JavaScript.
			$is_embedded_server_model = 'embedded' === $assistant_provider
				&& ! empty( $assistant_model )
				&& apply_filters( 'wp_mcp_ai_is_embedded_server_model', false, $assistant_model );
			$needs_embedded_provider  = $this->is_embedded_provider_available( $assistant_provider ) && ! $is_embedded_server_model;

			// Parse additional_tools from the shortcode attribute early so it can be used for:
			// 1. Embedded provider tool definition resolution (added to $tool_slugs_to_include below).
			// 2. Enhanced WebLLM script enqueueing ($has_tools flag below).
			// 3. Tool shortcuts ($additional_tools_for_shortcuts variable below).
			// The parsed slugs are stored in $config['additionalTools'] for the server-side (OpenAI) path,
			// and also resolved to full OpenAI function definitions for the embedded path.
			$additional_tools = array();
			if ( ! empty( $atts['additional_tools'] ) ) {
				$additional_tools_raw = sanitize_text_field( $atts['additional_tools'] );
				$additional_tools     = array_map( 'trim', explode( ',', $additional_tools_raw ) );
				$additional_tools     = array_values( array_filter( array_map( 'sanitize_key', $additional_tools ) ) );
			}

			// Check if assistant has tools, system prompt, or knowledge (used in multiple places).
			// Also consider the profession shortcode attribute: if a profession is specified, a professional
			// role prompt will be built and sent as the system prompt, so the enhanced embedded scripts
			// must be enqueued even when the assistant itself has no system_prompt configured.
			// Also consider additional_tools: if any are specified, treat them as "has tools" so the
			// enhanced WebLLM scripts (tool adapter, function calling client) are enqueued.
			$has_tools         = ( ! empty( $assistant_config_for_provider['tools'] ) && is_array( $assistant_config_for_provider['tools'] ) ) || ! empty( $additional_tools );
			$has_system_prompt = ! empty( $assistant_config_for_provider['system_prompt'] ) || ! empty( $atts['profession'] );
			$has_knowledge     = ! empty( $assistant_config_for_provider['memory_files'] ) || ! empty( $assistant_config_for_provider['vector_store_id'] );

			if ( $needs_embedded_provider && ! $is_elementor_editor ) {
				/**
				 * Fires to enqueue embedded provider scripts (WebLLM loader, client, tool adapter).
				 * The Embedded addon handles the actual enqueue from its own assets.
				 *
				 * @since 2.3.0
				 *
				 * @param bool $needs_embedded    Whether embedded provider scripts are needed.
				 * @param bool $has_tools         Whether the assistant has tools configured.
				 * @param bool $has_system_prompt Whether the assistant has a system prompt.
				 * @param bool $has_knowledge     Whether the assistant has knowledge files.
				 */
				do_action( 'wp_mcp_ai_enqueue_embedded_scripts', $needs_embedded_provider, $has_tools, $has_system_prompt, $has_knowledge );
			}

			// Enqueue chat script (always with same dependencies - no conditional changes).
			// This prevents conflicts when multiple widgets with different providers are on the same page.
			wp_enqueue_script( self::SCRIPT_HANDLE );
			wp_enqueue_style( self::STYLE_HANDLE );
			wp_enqueue_style( 'wp-mcp-ai-voice-chat' );

			// Enqueue voice mode integration when voice mode is enabled.
			if ( isset( $settings['voice_mode'] ) && 'off' !== $settings['voice_mode'] ) {
				wp_enqueue_script( 'wp-mcp-ai-voice-integration' );
			}

			// Enqueue slash commands integration if available.
			if ( wp_script_is( 'wp-mcp-ai-slash-commands', 'registered' ) ) {
				wp_enqueue_script( 'wp-mcp-ai-slash-commands' );
			}

			$instance_id = wp_unique_id( 'wp-mcp-ai-chat-' );
			$textarea_id = $instance_id . '-input';
			$session_key = wp_generate_uuid4();

			if ( ! $session_key ) {
				$session_key = wp_unique_id( 'wp-mcp-ai-session-' );
			}

			$session_key = sanitize_key( $session_key );

			// Allow attachments (including voice chat and transcription) if:
			// 1. User has upload_files capability, OR
			// 2. Guest access is enabled for this widget
			// This ensures that if users have access to the widget, they have access to its built-in tools.
			$can_upload_attachments = current_user_can( 'upload_files' ) || $allow_guests;

			// Get assistant content if available (not applicable for profession tests without associated assistant).
			$assistant_content = '';
			if ( ! $is_profession_test && $assistant ) {
				$assistant_content = get_post_field( 'post_content', $assistant->ID );
				if ( $assistant_content ) {
					$assistant_content = apply_filters( 'the_content', $assistant_content );
				}
			}

			// Get assistant tools for sidebar template display.
			$assistant_tools = array();
			if ( 'sidebar' === $template && ! $is_profession_test && class_exists( 'WP_MCP_AI_Assistant_CPT' ) ) {
				$config_for_tools = WP_MCP_AI_Assistant_CPT::get_assistant_configuration( absint( $assistant_id ) );
				if ( ! empty( $config_for_tools['tools'] ) && is_array( $config_for_tools['tools'] ) ) {
					$assistant_tools = array_values( array_filter( array_map( 'sanitize_key', $config_for_tools['tools'] ) ) );
				}
			}

			// Handle profession attribute to build professional role prompt.
			$professional_prompt  = '';
			$profession_data      = null;
			$profession_mem_files = array();
			if ( ! empty( $atts['profession'] ) ) {
				$profession_id = absint( $atts['profession'] );
				if ( $profession_id > 0 ) {
					$profession_post = get_post( $profession_id );
					if ( $profession_post && 'mcp_ai_profession' === $profession_post->post_type ) {
						$profession_data = $profession_post;
						// Build profession prompt similar to build_prompt_from_primary_roles.
						if ( class_exists( 'WP_MCP_AI_Assistant_CPT' ) && method_exists( 'WP_MCP_AI_Assistant_CPT', 'build_prompt_from_primary_roles' ) ) {
							$professional_prompt = WP_MCP_AI_Assistant_CPT::build_prompt_from_primary_roles( array( $profession_id ) );
						}
						// Collect profession memory files so they can be merged into the embedded client config.
						$fetched = get_post_meta( $profession_id, '_wp_mcp_ai_profession_memory_files', true );
						if ( is_array( $fetched ) && ! empty( $fetched ) ) {
							$profession_mem_files = $fetched;
						}
					}
				}
			} elseif ( $is_profession_test && ! empty( $profession_id ) ) {
				// For profession tests (assistant="profession_XXX"), build the profession's prompt so the
				// embedded LLM client receives the correct professional role prompt.
				// $profession is guaranteed valid here — invalid professions return early above.
				$profession_data = $profession;
				if ( class_exists( 'WP_MCP_AI_Assistant_CPT' ) && method_exists( 'WP_MCP_AI_Assistant_CPT', 'build_prompt_from_primary_roles' ) ) {
					$professional_prompt = WP_MCP_AI_Assistant_CPT::build_prompt_from_primary_roles( array( $profession_id ) );
				}
				// Collect profession memory files so they can be merged into the embedded client config.
				$fetched = get_post_meta( $profession_id, '_wp_mcp_ai_profession_memory_files', true );
				if ( is_array( $fetched ) && ! empty( $fetched ) ) {
					$profession_mem_files = $fetched;
				}
			}

			$config = array(
				'id'                         => $instance_id,
				'assistantId'                => $assistant_id, // This preserves "profession_XXX" format for profession tests.
				'embeddedAssistantId'        => absint( $permissions_assistant_id ),
				'userId'                     => get_current_user_id(),
				'restUrl'                    => esc_url_raw( trailingslashit( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE ) ) ) ),
				'uploadEndpoint'             => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( 'wp/v2/media' ) ) ),
				'prepareEndpoint'            => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/attachments/prepare' ) ) ),
				'messagesEndpoint'           => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-client' ) ) ),
				'toolsEndpoint'              => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/tools' ) ) ),
				'filesEndpoint'              => esc_url_raw( trailingslashit( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/files' ) ) ) ),
				'transcriptsEndpoint'        => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-transcripts' ) ) ),
				'chatFeedbackEndpoint'       => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-feedback' ) ) ),
				'embeddedConfigEndpoint'     => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/embedded-client-config' ) ) ),
				'vectorStorePreloadEndpoint' => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/vector-store-preload' ) ) ),
				'crawl4aiTaskEndpoint'       => esc_url_raw( trailingslashit( WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/crawl4ai/task' ) ) ) ),
				'crawl4aiDefaultPollMs'      => 5000,
				'requiredCapability'         => $capability ? $capability : '',
				'allowGuests'                => (bool) $allow_guests,
				'canUploadAttachments'       => (bool) $can_upload_attachments,
				'saveTranscript'             => (bool) $save_transcript,
				'enableStreaming'            => (bool) $enable_streaming,
				'allowSensitiveTools'        => (bool) $allow_sensitive_tools,
				'sessionKey'                 => $session_key,
				'historyPerPage'             => 20,
				'maxHistoryMessages'         => isset( $settings['max_history_messages'] ) ? absint( $settings['max_history_messages'] ) : 8,
				'restNonce'                  => wp_create_nonce( 'wp_rest' ),
				'assistantName'              => $is_profession_test && isset( $profession ) && $profession ? get_the_title( $profession->ID ) : get_the_title( $assistant_id ),
				'assistantAvatar'            => $is_profession_test ? '' : ( has_post_thumbnail( $assistant_id ) ? get_the_post_thumbnail_url( $assistant_id, 'thumbnail' ) : '' ),
				'assistantBio'               => $is_profession_test ? '' : $assistant_content,
			);

			// Add async tool timeout using helper method (reuses $settings already fetched).
			$config['asyncToolTimeout'] = self::get_async_tool_timeout_ms( $settings );

			// Chat-session stream endpoint for async continuation delivery.
			// The {session_id} placeholder is replaced client-side when the session ID is known.
			$config['sessionStreamEndpoint'] = esc_url_raw(
				WP_MCP_AI_Request_Context::normalise_rest_url(
					rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-sessions/{session_id}/stream' )
				)
			);

			/**
			 * Feature flag: async chat continuation (server-side LLM re-entry after
			 * an async tool finishes).  Defaults to true for new installs.
			 *
			 * @since 1.9.4
			 *
			 * @param bool $enabled Whether the client-side SSE session stream is enabled.
			 */
			$config['asyncChatContinuation'] = (bool) apply_filters( 'wp_mcp_ai_chat_continuation_enabled', true );

			// Feature flag: replace the 4-counter strip with the full Tasks drawer + toasts.
			// Off by default; flip on once the flag has been tested in production for one patch cycle.
			// See docs/features/chat/cron-status-tasks-drawer-plan.md Phase 3b / PR-D.
			$config['chatTasksDrawer'] = (bool) apply_filters( 'wp_mcp_ai_chat_tasks_drawer', true );

			// Add provider and model for client-side execution (embedded provider).
			// Also include system_prompt and temperature for embedded provider to use assistant defaults.
			if ( ! empty( $assistant_provider ) ) {
				$config['provider'] = $assistant_provider;
			}
			if ( ! empty( $assistant_model ) ) {
				$config['model'] = $assistant_model;
			}

			// Flag server-side GGUF models so chat.js routes them to the REST API
			// instead of the client-side WebLLM path. Both share provider='embedded',
			// but GGUF models are run by llama.cpp on the server.
			if ( $is_embedded_server_model ) {
				$config['isEmbeddedServer'] = true;
			}

			// Add assistant defaults (system_prompt, temperature) for client-side execution.
			// This ensures embedded providers have access to the same defaults as server-side providers.
			if ( ! empty( $assistant_config_for_provider['system_prompt'] ) ) {
				$resolved_assistant_id = is_numeric( $assistant_id ) ? (int) $assistant_id : 0;

				/**
				 * Apply the harness Prompt Cue injector to the system prompt
				 * pre-localised into the page render. This is the third
				 * (initial) chat surface alongside the REST chat path and
				 * embedded-config endpoint; running the same filter here
				 * keeps the three surfaces in sync.
				 *
				 * @since 1.4.0
				 */
				$config['systemPrompt'] = (string) apply_filters(
					'wp_mcp_ai_resolved_system_prompt',
					(string) $assistant_config_for_provider['system_prompt'],
					$resolved_assistant_id,
					array( 'surface' => 'shortcode_bootstrap' )
				);
			}
			if ( isset( $assistant_config_for_provider['temperature'] ) && '' !== $assistant_config_for_provider['temperature'] ) {
				$config['temperature'] = floatval( $assistant_config_for_provider['temperature'] );
			}

			// Pass max_tokens from the orchestration layer so the embedded client-side
			// model respects the same token budget as server-side providers instead of
			// falling back to a hardcoded default.
			if ( class_exists( 'WP_MCP_AI_Resource_Manager' ) ) {
				$config['max_tokens'] = WP_MCP_AI_Resource_Manager::instance()->get_max_tokens();
			}

			// Add base knowledge (memory files and vector store) for embedded provider.
			// This enables the embedded client to access the same knowledge base as server-side providers.
			// Merge assistant memory files with any profession memory files so both are available.
			$combined_memory_files = array();
			if ( ! empty( $assistant_config_for_provider['memory_files'] ) && is_array( $assistant_config_for_provider['memory_files'] ) ) {
				$combined_memory_files = $assistant_config_for_provider['memory_files'];
			}
			if ( ! empty( $profession_mem_files ) ) {
				$combined_memory_files = array_values( array_unique( array_merge( $combined_memory_files, $profession_mem_files ) ) );
			}
			if ( ! empty( $combined_memory_files ) ) {
				$config['memoryFiles'] = $combined_memory_files;
			}
			if ( ! empty( $assistant_config_for_provider['vector_store_id'] ) ) {
				$config['vectorStoreId'] = $assistant_config_for_provider['vector_store_id'];
			}

			// Add tool definitions for embedded provider (Phase 1: Tool Support Implementation).
			// This enables client-side LLM to know which tools are available and call them.
			// Tools will be executed server-side via the existing orchestration layer.
			$tool_slugs_to_include = array();

			// Start with assistant's configured tools.
			if ( ! empty( $assistant_config_for_provider['tools'] ) && is_array( $assistant_config_for_provider['tools'] ) ) {
				$tool_slugs_to_include = $assistant_config_for_provider['tools'];
			}

			// Merge additional_tools from the shortcode attribute so the embedded client receives their
			// full OpenAI function definitions.  The server-side (OpenAI) path gets these as slugs via
			// $config['additionalTools'] and resolves them on every request, but the embedded client
			// needs the resolved definitions up-front in $config['tools'].
			foreach ( $additional_tools as $additional_slug ) {
				if ( ! in_array( $additional_slug, $tool_slugs_to_include, true ) ) {
					$tool_slugs_to_include[] = $additional_slug;
				}
			}

			// Automatically add semantic_content_search if assistant has knowledge files (RAG pattern).
			// This enables embedded client to retrieve knowledge content server-side when needed.
			if ( $has_knowledge && ! in_array( 'semantic_content_search', $tool_slugs_to_include, true ) ) {
				$tool_slugs_to_include[] = 'semantic_content_search';

				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- WP_DEBUG-gated diagnostic trace confirming semantic_content_search auto-add for knowledge-file assistants.
					error_log(
						sprintf(
							'[WP_MCP_AI] Auto-adding semantic_content_search tool for assistant %d (has knowledge files)',
							$assistant_id
						)
					);
				}
			}

			// Build tool definitions for embedded client.
			if ( ! empty( $tool_slugs_to_include ) ) {
				$tool_definitions = array();

				if ( class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
					$registry = WP_MCP_AI_Tool_Registry::get_instance();

					foreach ( $tool_slugs_to_include as $tool_slug ) {
						// Use registry's get_tool_definition() which relies on the required tool
						// interface methods (get_slug, get_description, get_parameters_schema).
						// This works for ALL registered tools, unlike get_definition() which is
						// an optional method not part of WP_MCP_AI_Tool_Interface.
						$tool_definition = $registry->get_tool_definition( $tool_slug );
						if ( $tool_definition && is_array( $tool_definition ) ) {
							// Wrap in OpenAI function-calling format expected by the embedded LLM client.
							// get_tool_definition() always returns name, description, and parameters
							// via the required WP_MCP_AI_Tool_Interface methods.
							$tool_definitions[] = array(
								'type'     => 'function',
								'function' => array(
									'name'        => $tool_definition['name'],
									'description' => $tool_definition['description'],
									'parameters'  => $tool_definition['parameters'],
								),
							);
						}
					}
				}

				if ( ! empty( $tool_definitions ) ) {
					$config['tools'] = $tool_definitions;

					// Log tool definitions being passed to embedded provider.
					if ( class_exists( 'WP_MCP_AI_Logger' ) && 'embedded' === $assistant_provider ) {
						WP_MCP_AI_Logger::log_event(
							'embedded_tools_config',
							'Embedded provider: Tool definitions passed to client',
							array(
								'assistant_id'      => $assistant_id,
								'tool_count'        => count( $tool_definitions ),
								'has_knowledge'     => $has_knowledge,
								'auto_added_search' => $has_knowledge && in_array( 'semantic_content_search', $tool_slugs_to_include, true ),
								'tool_names'        => array_map(
									function ( $def ) {
										return isset( $def['function']['name'] ) ? $def['function']['name'] : 'unknown';
									},
									$tool_definitions
								),
							)
						);
					}
				}
			}

			// Add team information if team is configured.
			if ( ! empty( $team_data ) ) {
				$config['teamData'] = $team_data;
			}

			// Get tool shortcuts - for profession tests, get them from the profession's associated assistant if available.
			$shortcuts_assistant_id = $is_profession_test && isset( $permissions_assistant_id ) ? $permissions_assistant_id : $assistant_id;
			// Pass additional_tools so shortcuts can be generated for them too.
			$additional_tools_for_shortcuts = ! empty( $additional_tools ) ? $additional_tools : array();
			$tool_shortcuts                 = self::get_assistant_tool_shortcuts( $shortcuts_assistant_id, $additional_tools_for_shortcuts );
			if ( ! empty( $tool_shortcuts ) ) {
				$config['toolShortcuts'] = $tool_shortcuts;
			}

			// Get suggested prompts if available (post meta on assistant).
			$suggested_prompts = array();
			if ( ! $is_profession_test ) {
				$prompts_raw = get_post_meta( $assistant_id, '_wp_mcp_ai_suggested_prompts', true );
				if ( is_array( $prompts_raw ) && ! empty( $prompts_raw ) ) {
					$suggested_prompts = array_values( array_filter( array_map( 'sanitize_text_field', $prompts_raw ) ) );
				}
			}
			if ( ! empty( $suggested_prompts ) ) {
				$config['suggestedPrompts'] = $suggested_prompts;
			}

			// Parse CPT action buttons if provided.
			$cpt_actions = array();
			if ( ! empty( $atts['cpt_actions'] ) ) {
				// Try to decode as base64 first (new format to avoid shortcode bracket conflicts).
				$decoded_json = base64_decode( $atts['cpt_actions'], true );
				if ( false !== $decoded_json ) {
					$decoded_actions = json_decode( $decoded_json, true );
					if ( is_array( $decoded_actions ) ) {
						$cpt_actions = $decoded_actions;
					}
				}

				// Fallback to direct JSON decode for backwards compatibility.
				if ( empty( $cpt_actions ) ) {
					$decoded_actions = json_decode( $atts['cpt_actions'], true );
					if ( is_array( $decoded_actions ) ) {
						$cpt_actions = $decoded_actions;
					}
				}
			}
			if ( ! empty( $cpt_actions ) ) {
				$config['cptActions'] = $cpt_actions;
			}

			// Store additional_tools as slugs in config for the server-side (OpenAI) path.
			// These tools will be available regardless of the assistant's configured tools.
			// Note: For the embedded provider, these are already resolved and merged into
			// $config['tools'] above via $tool_slugs_to_include.
			if ( ! empty( $additional_tools ) ) {
				$config['additionalTools'] = $additional_tools;
			}

			if ( $can_upload_attachments && class_exists( 'WP_MCP_AI_Message_Attachments' ) ) {
				$allowed_mime_sets   = WP_MCP_AI_Message_Attachments::get_allowed_mime_types();
				$allowed_image_mimes = isset( $allowed_mime_sets['image'] ) ? (array) $allowed_mime_sets['image'] : array();
				$allowed_file_mimes  = isset( $allowed_mime_sets['file'] ) ? (array) $allowed_mime_sets['file'] : array();
				$allowed_extensions  = self::get_allowed_extensions_for_mimes( array_merge( $allowed_image_mimes, $allowed_file_mimes ) );
				$file_accept_tokens  = self::build_file_accept_tokens( $allowed_image_mimes, $allowed_file_mimes, $allowed_extensions );

				if ( ! empty( $allowed_image_mimes ) ) {
					$config['allowedImageMimes'] = array_values( $allowed_image_mimes );
				}

				if ( ! empty( $allowed_file_mimes ) ) {
					$config['allowedFileMimes'] = array_values( $allowed_file_mimes );
				}

				if ( ! empty( $allowed_extensions ) ) {
					$config['allowedExtensions'] = array_values( $allowed_extensions );
				}

				if ( ! empty( $file_accept_tokens ) ) {
					$config['fileAccept'] = implode( ',', $file_accept_tokens );
				}
			}

			if ( $guest_token ) {
				$config['guestToken'] = $guest_token;
			}

			// Add professional role prompt if provided via profession attribute.
			if ( ! empty( $professional_prompt ) ) {
				// For server-side providers: keep professionalPrompt as a separate config field so
				// the JS can pass it to the server in the chat payload for server-side system-prompt
				// assembly and for the professional-selector feature.
				// For embedded providers: pre-combine with the assistant's own system prompt so the
				// embedded client always has a populated systemPrompt from the initial page render —
				// no extra server round-trip is needed.  We intentionally omit professionalPrompt
				// from the embedded config to prevent JS from double-combining professional content
				// that is already included in systemPrompt.
				if ( 'embedded' !== $assistant_provider ) {
					$config['professionalPrompt'] = $professional_prompt;
				} elseif ( ! empty( $config['systemPrompt'] ) ) {
					// Merge professional role first, then assistant instructions — the same separator
					// and ordering used by the server-side REST handler (class-wp-mcp-ai-rest.php).
					$config['systemPrompt'] = $professional_prompt . "\n\n---\n\n# Additional Instructions\n\n" . $config['systemPrompt'];
				} else {
					$config['systemPrompt'] = $professional_prompt;
				}
			}

			// Include profession info for display purposes.
			if ( $profession_data ) {
				$config['professionId']   = $profession_data->ID;
				$config['professionName'] = $profession_data->post_title;
			}

			// Store config in a global for AJAX access (used by professional selector).
			if ( ! isset( $GLOBALS['wp_mcp_ai_chat_configs'] ) ) {
				$GLOBALS['wp_mcp_ai_chat_configs'] = array();
			}
			$GLOBALS['wp_mcp_ai_chat_configs'][ $instance_id ] = $config;

			// Log for debugging PM assistant issues.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- WP_DEBUG-gated diagnostic trace confirming shortcode config storage per instance.
				error_log(
					sprintf(
						'[WP_MCP_AI] Shortcode stored config for instance: %s (assistant_id: %s)',
						$instance_id,
						isset( $config['assistantId'] ) ? $config['assistantId'] : 'N/A'
					)
				);
			}

			$inline_config  = 'window.wpMcpAiChatInstances = window.wpMcpAiChatInstances || {};';
			$inline_config .= 'window.wpMcpAiChatInstances[' . wp_json_encode( $instance_id ) . '] = ' . wp_json_encode( $config ) . ';';
			wp_add_inline_script( self::SCRIPT_HANDLE, $inline_config, 'before' );

			ob_start();
			$messages_id = $instance_id . '-messages';

			// Build container classes based on template.
			$container_classes = array( 'wp-mcp-ai-chat' );
			if ( 'classic' !== $template ) {
				$container_classes[] = 'wp-mcp-ai-chat--template-' . $template;
			}
			?>
		<div class="<?php echo esc_attr( implode( ' ', $container_classes ) ); ?>" id="<?php echo esc_attr( $instance_id ); ?>" data-wp-mcp-ai-chat data-template="<?php echo esc_attr( $template ); ?>"
						<?php
						// Emit AI transparency data attributes (Proposal 017 — SGI/Article 50).
						if ( class_exists( 'WP_MCP_AI_Transparency_Service' ) ) {
							$transparency_svc   = WP_MCP_AI_Transparency_Service::get_instance();
							$transparency_attrs = $transparency_svc->get_chat_data_attributes();
							foreach ( $transparency_attrs as $attr_key => $attr_value ) {
								echo ' ' . esc_attr( $attr_key ) . '="' . esc_attr( $attr_value ) . '"';
							}
						}
						?>
					>
			<?php
			// Render AI disclosure banner (Proposal 017 — EU AI Act Article 50(1)).
			if ( class_exists( 'WP_MCP_AI_Transparency_Service' ) ) {
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Method returns pre-escaped HTML.
				echo WP_MCP_AI_Transparency_Service::get_instance()->get_disclosure_banner_html();
			}

			if ( $is_elementor_editor ) {
				echo $this->render_editor_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_editor_notice() returns a static HTML string with all dynamic values escaped via esc_html_e().
			}

			// Render consent modal (Proposal 017 — pre-interaction AI consent).
			if ( class_exists( 'WP_MCP_AI_Transparency_Service' ) ) {
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Method returns pre-escaped HTML.
				echo WP_MCP_AI_Transparency_Service::get_instance()->get_consent_modal_html();
			}
			?>
			<div class="wp-mcp-ai-chat__assistant">
				<div class="wp-mcp-ai-chat__profile">
					<div class="wp-mcp-ai-chat__profile-avatar">
						<?php
						$avatar_url = '';
						if ( ! $is_profession_test && has_post_thumbnail( $assistant_id ) ) {
							$avatar_url = get_the_post_thumbnail_url( $assistant_id, 'thumbnail' );
						}
						if ( $avatar_url ) :
							?>
							<img src="<?php echo esc_url( $avatar_url ); ?>" alt="" class="wp-mcp-ai-chat__profile-img" width="48" height="48" loading="lazy">
						<?php else : ?>
							<span class="wp-mcp-ai-chat__profile-icon" aria-hidden="true">
								<svg viewBox="0 0 24 24" width="24" height="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
							</span>
						<?php endif; ?>
					</div>
					<div class="wp-mcp-ai-chat__profile-info">
						<div class="wp-mcp-ai-chat__profile-header">
							<span class="wp-mcp-ai-chat__profile-name">
								<?php
								if ( $is_profession_test && isset( $profession ) && $profession ) {
									echo esc_html( get_the_title( $profession->ID ) );
								} else {
									echo esc_html( get_the_title( $assistant_id ) );
								}
								?>
							</span>
							<?php if ( ! empty( $assistant_provider ) ) : ?>
								<span class="wp-mcp-ai-chat__profile-badges">
									<span class="wp-mcp-ai-chat__profile-badge wp-mcp-ai-chat__profile-badge--provider">
										<?php echo esc_html( ucfirst( $assistant_provider ) ); ?>
									</span>
									<?php if ( ! empty( $assistant_model ) ) : ?>
										<span class="wp-mcp-ai-chat__profile-badge wp-mcp-ai-chat__profile-badge--model">
											<?php echo esc_html( $assistant_model ); ?>
										</span>
									<?php endif; ?>
									<?php if ( $profession_data && ! empty( $profession_data->post_title ) ) : ?>
										<span class="wp-mcp-ai-chat__profile-badge wp-mcp-ai-chat__profile-badge--profession">
											<?php echo esc_html( $profession_data->post_title ); ?>
										</span>
									<?php endif; ?>
								</span>
							<?php endif; ?>
						</div>
						<?php if ( $assistant_content && ! $is_profession_test ) : ?>
							<button type="button" class="wp-mcp-ai-chat__profile-toggle" aria-expanded="false" aria-controls="<?php echo esc_attr( $instance_id ); ?>-bio">
								<span class="wp-mcp-ai-chat__profile-toggle-text"><?php esc_html_e( 'About this assistant', 'nvdigital-open-operator-system-oos' ); ?></span>
								<svg class="wp-mcp-ai-chat__profile-toggle-icon" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M12 15.5a1 1 0 01-.7-.29l-5-5a1 1 0 011.4-1.42L12 13.09l4.3-4.3a1 1 0 011.4 1.42l-5 5a1 1 0 01-.7.29z"/></svg>
							</button>
							<div id="<?php echo esc_attr( $instance_id ); ?>-bio" class="wp-mcp-ai-chat__profile-bio" hidden>
								<?php echo wp_kses_post( $assistant_content ); ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
				<label class="wp-mcp-ai-chat__label screen-reader-text" for="<?php echo esc_attr( $textarea_id ); ?>">
					<?php esc_html_e( 'Chat message', 'nvdigital-open-operator-system-oos' ); ?>
				</label>
			</div>
			<div class="wp-mcp-ai-chat__transcript-controls">
				<button
					type="button"
					class="wp-mcp-ai-chat__transcript-toggle"
					aria-expanded="false"
					aria-label="<?php echo esc_attr__( 'Expand conversation', 'nvdigital-open-operator-system-oos' ); ?>"
				>
					<svg class="wp-mcp-ai-chat__transcript-toggle-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
						<path d="M12 15.5a1 1 0 0 1-.7-.29l-5-5a1 1 0 0 1 1.4-1.42L12 13.09l4.3-4.3a1 1 0 0 1 1.4 1.42l-5 5a1 1 0 0 1-.7.29z" />
					</svg>
					<span class="screen-reader-text"><?php esc_html_e( 'Expand conversation', 'nvdigital-open-operator-system-oos' ); ?></span>
				</button>
			</div>
			<div class="wp-mcp-ai-chat__messages" aria-live="polite"></div>
			<div class="wp-mcp-ai-chat__agent-panel" role="complementary" aria-label="<?php echo esc_attr__( 'Agent team activity', 'nvdigital-open-operator-system-oos' ); ?>" hidden>
				<div class="wp-mcp-ai-chat__agent-panel-header">
					<button type="button" class="wp-mcp-ai-chat__agent-panel-toggle" aria-expanded="false">
						<svg class="wp-mcp-ai-chat__agent-panel-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false">
							<path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z" />
						</svg>
						<span class="wp-mcp-ai-chat__agent-panel-title"><?php esc_html_e( 'Agent Team', 'nvdigital-open-operator-system-oos' ); ?></span>
						<span class="wp-mcp-ai-chat__agent-panel-count" aria-label="<?php echo esc_attr__( 'Active agents', 'nvdigital-open-operator-system-oos' ); ?>">0</span>
						<svg class="wp-mcp-ai-chat__agent-panel-chevron" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" focusable="false">
							<path d="M12 15.5a1 1 0 0 1-.7-.29l-5-5a1 1 0 0 1 1.4-1.42L12 13.09l4.3-4.3a1 1 0 0 1 1.4 1.42l-5 5a1 1 0 0 1-.7.29z" />
						</svg>
					</button>
				</div>
				<div class="wp-mcp-ai-chat__agent-panel-body" hidden>
					<div class="wp-mcp-ai-chat__agent-cards" role="list" aria-label="<?php echo esc_attr__( 'Sub-agents', 'nvdigital-open-operator-system-oos' ); ?>"></div>
					<div class="wp-mcp-ai-chat__workflow-tracker" role="status" aria-label="<?php echo esc_attr__( 'Workflow progress', 'nvdigital-open-operator-system-oos' ); ?>" hidden>
						<div class="wp-mcp-ai-chat__workflow-tracker-header">
							<span class="wp-mcp-ai-chat__workflow-tracker-title"><?php esc_html_e( 'Workflow Progress', 'nvdigital-open-operator-system-oos' ); ?></span>
							<span class="wp-mcp-ai-chat__workflow-tracker-progress">0%</span>
						</div>
						<div class="wp-mcp-ai-chat__workflow-tracker-bar">
							<div class="wp-mcp-ai-chat__workflow-tracker-fill"></div>
						</div>
						<ol class="wp-mcp-ai-chat__workflow-tracker-steps" aria-label="<?php echo esc_attr__( 'Workflow steps', 'nvdigital-open-operator-system-oos' ); ?>"></ol>
					</div>
				</div>
			</div>
				<div class="wp-mcp-ai-chat__prompts" role="group" aria-label="<?php echo esc_attr__( 'Suggested questions', 'nvdigital-open-operator-system-oos' ); ?>"></div>
				<form class="wp-mcp-ai-chat__form" data-instance-id="<?php echo esc_attr( $instance_id ); ?>">
				<div class="wp-mcp-ai-chat__status" role="status" aria-live="polite" hidden></div>
				<div class="wp-mcp-ai-chat__tool-shortcuts-wrapper" hidden>
					<button type="button" class="wp-mcp-ai-chat__tool-shortcuts-toggle wp-mcp-ai-chat__tool-shortcuts-toggle--collapsed" aria-expanded="false" aria-controls="<?php echo esc_attr( $instance_id . '-tool-shortcuts' ); ?>">
						<span class="wp-mcp-ai-chat__tool-shortcuts-toggle-text"><?php esc_html_e( 'Quick Tasks', 'nvdigital-open-operator-system-oos' ); ?></span>
						<svg class="wp-mcp-ai-chat__tool-shortcuts-toggle-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M12 15.5a1 1 0 0 1-.7-.29l-5-5a1 1 0 0 1 1.4-1.42L12 13.09l4.3-4.3a1 1 0 0 1 1.4 1.42l-5 5a1 1 0 0 1-.7.29z" />
						</svg>
					</button>
					<div id="<?php echo esc_attr( $instance_id . '-tool-shortcuts' ); ?>" class="wp-mcp-ai-chat__tool-shortcuts wp-mcp-ai-chat__tool-shortcuts--collapsed" role="group" aria-label="<?php echo esc_attr__( 'Assistant tool tasks', 'nvdigital-open-operator-system-oos' ); ?>" hidden></div>
				</div>
				<textarea id="<?php echo esc_attr( $textarea_id ); ?>" class="wp-mcp-ai-chat__input" rows="4" placeholder="<?php echo esc_attr__( 'Ask something…', 'nvdigital-open-operator-system-oos' ); ?>" required></textarea>
				<div class="wp-mcp-ai-chat__attachments" hidden>
					<div class="wp-mcp-ai-chat__attachments-header"><?php esc_html_e( 'Attachments', 'nvdigital-open-operator-system-oos' ); ?></div>
					<ul class="wp-mcp-ai-chat__attachments-list"></ul>
				</div>
				<div class="wp-mcp-ai-chat__actions">
					<input type="file" class="wp-mcp-ai-chat__file-input" multiple hidden />
					<input type="file" class="wp-mcp-ai-chat__transcribe-input" accept="audio/*" hidden<?php echo esc_attr( $can_upload_attachments ? '' : ' disabled' ); ?> />
					<input type="file" class="wp-mcp-ai-chat__translate-input" accept="audio/*" hidden<?php echo esc_attr( $can_upload_attachments ? '' : ' disabled' ); ?> />
					<button type="button" class="wp-mcp-ai-chat__translate" aria-label="<?php echo esc_attr__( 'Translate audio', 'nvdigital-open-operator-system-oos' ); ?>"<?php echo esc_attr( $can_upload_attachments ? '' : ' disabled hidden' ); ?>>
						<svg class="wp-mcp-ai-chat__translate-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M12.87 15.07l-2.54-2.51.03-.03A17.52 17.52 0 0 0 14.07 6H17V4h-7V2H8v2H1v2h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04M18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12m-2.62 7l1.62-4.33L19.12 17h-3.24z"></path>
						</svg>
						<span class="screen-reader-text"><?php esc_html_e( 'Translate audio', 'nvdigital-open-operator-system-oos' ); ?></span>
					</button>
					<button type="button" class="wp-mcp-ai-chat__voice-chat" aria-label="<?php echo esc_attr__( 'Voice chat', 'nvdigital-open-operator-system-oos' ); ?>"<?php echo esc_attr( $can_upload_attachments ? '' : ' disabled hidden' ); ?>>
						<svg class="wp-mcp-ai-chat__voice-chat-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 14 0h-2z"></path>
							<circle cx="12" cy="12" r="1.5" fill="currentColor"/>
						</svg>
						<span class="screen-reader-text"><?php esc_html_e( 'Voice chat', 'nvdigital-open-operator-system-oos' ); ?></span>
					</button>
					<button type="button" class="wp-mcp-ai-chat__transcribe" aria-label="<?php echo esc_attr__( 'Transcribe audio', 'nvdigital-open-operator-system-oos' ); ?>"<?php echo esc_attr( $can_upload_attachments ? '' : ' disabled hidden' ); ?>>
						<svg class="wp-mcp-ai-chat__transcribe-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 14 0h-2z"></path>
							<path d="M12 16a7 7 0 0 0 6.93-6H17a5 5 0 0 1-10 0H5.07A7 7 0 0 0 12 16zm-1 2.05V21h2v-2.95A9 9 0 0 0 20.95 11H19a7 7 0 0 1-14 0H3.05A9 9 0 0 0 11 18.05z"></path>
						</svg>
						<span class="screen-reader-text"><?php esc_html_e( 'Transcribe audio', 'nvdigital-open-operator-system-oos' ); ?></span>
					</button>
					<button type="button" class="wp-mcp-ai-chat__attach">
						<?php esc_html_e( 'Attach file', 'nvdigital-open-operator-system-oos' ); ?>
					</button>
					<button type="button" class="wp-mcp-ai-chat__build" hidden>
						<?php esc_html_e( 'Build', 'nvdigital-open-operator-system-oos' ); ?>
					</button>
					<button type="submit" class="wp-mcp-ai-chat__submit">
						<?php esc_html_e( 'Send', 'nvdigital-open-operator-system-oos' ); ?>
					</button>
				</div>
			</form>
			<div class="wp-mcp-ai-chat__controls">
				<div class="wp-mcp-ai-chat__quota-monitor" role="status" aria-live="polite" aria-atomic="true"></div>
				<div class="wp-mcp-ai-chat__cron-status" role="status" aria-live="polite" aria-atomic="true" hidden>
					<span class="wp-mcp-ai-chat__cron-status-label"><?php esc_html_e( 'Jobs:', 'nvdigital-open-operator-system-oos' ); ?></span>
					<span class="wp-mcp-ai-chat__cron-status-active" title="<?php esc_attr_e( 'Active jobs', 'nvdigital-open-operator-system-oos' ); ?>">
						<span class="wp-mcp-ai-chat__cron-status-count">0</span>
					</span>
					<span class="wp-mcp-ai-chat__cron-status-pending" title="<?php esc_attr_e( 'Pending jobs', 'nvdigital-open-operator-system-oos' ); ?>">
						<span class="wp-mcp-ai-chat__cron-status-count">0</span>
					</span>
					<span class="wp-mcp-ai-chat__cron-status-completed" title="<?php esc_attr_e( 'Completed jobs', 'nvdigital-open-operator-system-oos' ); ?>">
						<span class="wp-mcp-ai-chat__cron-status-count">0</span>
					</span>
					<span class="wp-mcp-ai-chat__cron-status-failed" title="<?php esc_attr_e( 'Failed jobs', 'nvdigital-open-operator-system-oos' ); ?>">
						<span class="wp-mcp-ai-chat__cron-status-count">0</span>
					</span>
					<span class="wp-mcp-ai-chat__cron-status-health" title="<?php esc_attr_e( 'System health', 'nvdigital-open-operator-system-oos' ); ?>" data-status="unknown">
						<span class="wp-mcp-ai-chat__cron-status-icon">●</span>
					</span>
				</div>
				<?php /* Tasks-drawer button (only visible when the chatTasksDrawer feature flag is on). */ ?>
				<button type="button" class="wp-mcp-ai-chat__tasks-btn" hidden aria-haspopup="dialog" aria-expanded="false">
					<span class="wp-mcp-ai-chat__tasks-btn__label"><?php esc_html_e( 'Jobs', 'nvdigital-open-operator-system-oos' ); ?></span>
					<span class="wp-mcp-ai-chat__tasks-btn__badge" aria-hidden="true">0</span>
				</button>
				<?php /* Tasks drawer panel — populated and toggled by chat.js. */ ?>
				<div class="wp-mcp-ai-chat__tasks-drawer" hidden role="dialog" aria-label="<?php esc_attr_e( 'Tasks', 'nvdigital-open-operator-system-oos' ); ?>">
					<div class="wp-mcp-ai-chat__tasks-drawer__header">
						<span class="wp-mcp-ai-chat__tasks-drawer__health" data-status="unknown" aria-hidden="true">●</span>
						<span class="wp-mcp-ai-chat__tasks-drawer__title"><?php esc_html_e( 'Tasks', 'nvdigital-open-operator-system-oos' ); ?></span>
						<button type="button" class="wp-mcp-ai-chat__tasks-drawer__close" aria-label="<?php esc_attr_e( 'Close Tasks drawer', 'nvdigital-open-operator-system-oos' ); ?>">✕</button>
					</div>
					<div class="wp-mcp-ai-chat__tasks-drawer__filters" role="tablist">
						<button type="button" class="wp-mcp-ai-chat__tasks-drawer__filter wp-mcp-ai-chat__tasks-drawer__filter--active" role="tab" aria-selected="true" data-filter="all"><?php esc_html_e( 'All', 'nvdigital-open-operator-system-oos' ); ?></button>
						<button type="button" class="wp-mcp-ai-chat__tasks-drawer__filter" role="tab" aria-selected="false" data-filter="running"><?php esc_html_e( 'Running', 'nvdigital-open-operator-system-oos' ); ?></button>
						<button type="button" class="wp-mcp-ai-chat__tasks-drawer__filter" role="tab" aria-selected="false" data-filter="queued"><?php esc_html_e( 'Pending', 'nvdigital-open-operator-system-oos' ); ?></button>
						<button type="button" class="wp-mcp-ai-chat__tasks-drawer__filter" role="tab" aria-selected="false" data-filter="completed"><?php esc_html_e( 'Completed', 'nvdigital-open-operator-system-oos' ); ?></button>
						<button type="button" class="wp-mcp-ai-chat__tasks-drawer__filter" role="tab" aria-selected="false" data-filter="failed"><?php esc_html_e( 'Failed', 'nvdigital-open-operator-system-oos' ); ?></button>
					</div>
					<div class="wp-mcp-ai-chat__tasks-drawer__batch" hidden>
						<label class="wp-mcp-ai-chat__tasks-drawer__batch-select">
							<input type="checkbox" class="wp-mcp-ai-chat__tasks-drawer__select-all" aria-label="<?php esc_attr_e( 'Select all jobs', 'nvdigital-open-operator-system-oos' ); ?>">
							<span><?php esc_html_e( 'Select all', 'nvdigital-open-operator-system-oos' ); ?></span>
						</label>
						<button type="button" class="wp-mcp-ai-chat__tasks-drawer__batch-cancel" hidden><?php esc_html_e( 'Cancel selected', 'nvdigital-open-operator-system-oos' ); ?></button>
						<button type="button" class="wp-mcp-ai-chat__tasks-drawer__batch-retry" hidden><?php esc_html_e( 'Retry selected', 'nvdigital-open-operator-system-oos' ); ?></button>
						<button type="button" class="wp-mcp-ai-chat__tasks-drawer__batch-dismiss" hidden><?php esc_html_e( 'Dismiss selected', 'nvdigital-open-operator-system-oos' ); ?></button>
					</div>
					<ul class="wp-mcp-ai-chat__tasks-drawer__list" role="list"></ul>
					<p class="wp-mcp-ai-chat__tasks-drawer__empty" hidden><?php esc_html_e( 'No tasks found.', 'nvdigital-open-operator-system-oos' ); ?></p>
				</div>
				<?php /* Toast container — showJobToast() appends/removes items here. */ ?>
				<div class="wp-mcp-ai-chat__job-toast-container" aria-live="polite" role="status"></div>
				<div class="wp-mcp-ai-chat__control-buttons">
					<button
						type="button"
						class="wp-mcp-ai-chat__save"
						aria-label="<?php echo esc_attr__( 'Save conversation', 'nvdigital-open-operator-system-oos' ); ?>"
						title="<?php echo esc_attr__( 'Save conversation', 'nvdigital-open-operator-system-oos' ); ?>"
					>
						<svg class="wp-mcp-ai-chat__save-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2zM5 5v14h14V9h-4V5H5z" />
							<path d="M7 5h6v3H7V5zm5 9a2 2 0 11-4 0 2 2 0 014 0z" />
						</svg>
						<span class="screen-reader-text"><?php esc_html_e( 'Save conversation', 'nvdigital-open-operator-system-oos' ); ?></span>
					</button>
					<button
						type="button"
						class="wp-mcp-ai-chat__export"
						aria-label="<?php echo esc_attr__( 'Export conversation', 'nvdigital-open-operator-system-oos' ); ?>"
						title="<?php echo esc_attr__( 'Export conversation', 'nvdigital-open-operator-system-oos' ); ?>"
					>
						<svg class="wp-mcp-ai-chat__export-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M12 16a1 1 0 01-1-1V5a1 1 0 012 0v10a1 1 0 01-1 1z" />
							<path d="M12 16a1 1 0 01-.707-.293l-4-4a1 1 0 011.414-1.414L12 13.586l3.293-3.293a1 1 0 011.414 1.414l-4 4A1 1 0 0112 16z" />
							<path d="M5 19a1 1 0 010-2h14a1 1 0 010 2H5z" />
						</svg>
						<span class="screen-reader-text"><?php esc_html_e( 'Export conversation', 'nvdigital-open-operator-system-oos' ); ?></span>
					</button>
					<button
						type="button"
						class="wp-mcp-ai-chat__history-toggle"
						aria-expanded="false"
						aria-controls="<?php echo esc_attr( $instance_id ); ?>-history"
						aria-label="<?php echo esc_attr__( 'Show previous conversations', 'nvdigital-open-operator-system-oos' ); ?>"
					>
						<svg class="wp-mcp-ai-chat__history-toggle-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M6 5.5a1 1 0 011-1h10a1 1 0 110 2H7a1 1 0 01-1-1zm0 6a1 1 0 011-1h10a1 1 0 110 2H7a1 1 0 01-1-1zm0 6a1 1 0 011-1h7a1 1 0 010 2H7a1 1 0 01-1-1z" />
							<path d="M5 9a1 1 0 012 0 1 1 0 11-2 0zm0 6a1 1 0 012 0 1 1 0 11-2 0zm0-12a1 1 0 012 0 1 1 0 11-2 0z" />
						</svg>
						<span class="screen-reader-text"><?php esc_html_e( 'Show previous conversations', 'nvdigital-open-operator-system-oos' ); ?></span>
					</button>
					<button
						type="button"
						class="wp-mcp-ai-chat__new-chat"
						aria-label="<?php echo esc_attr__( 'Start new conversation', 'nvdigital-open-operator-system-oos' ); ?>"
					>
						<svg class="wp-mcp-ai-chat__new-chat-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M12 4a1 1 0 011 1v6h6a1 1 0 110 2h-6v6a1 1 0 11-2 0v-6H5a1 1 0 110-2h6V5a1 1 0 011-1z" />
						</svg>
						<span class="screen-reader-text"><?php esc_html_e( 'Start new conversation', 'nvdigital-open-operator-system-oos' ); ?></span>
					</button>
					<button
						type="button"
						class="wp-mcp-ai-chat__dark-toggle"
						aria-label="<?php echo esc_attr__( 'Switch to dark mode', 'nvdigital-open-operator-system-oos' ); ?>"
						title="<?php echo esc_attr__( 'Toggle dark mode', 'nvdigital-open-operator-system-oos' ); ?>"
						hidden
					>
						<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 7a5 5 0 100 10 5 5 0 000-10z"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
					</button>
					<?php if ( ! empty( $team_data ) && $supports_unified_mode ) : ?>
					<button
						type="button"
						class="wp-mcp-ai-chat__team-mode-toggle"
						data-mode="individual"
						aria-label="<?php echo esc_attr__( 'Switch to unified team mode', 'nvdigital-open-operator-system-oos' ); ?>"
						title="<?php echo esc_attr__( 'Switch between unified team and individual member modes', 'nvdigital-open-operator-system-oos' ); ?>"
					>
						<svg class="wp-mcp-ai-chat__team-mode-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<!-- Switch/Shuffle icon - clearly indicates mode toggling -->
							<path d="M10.59 9.17L5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41l-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z"/>
						</svg>
						<span class="screen-reader-text"><?php esc_html_e( 'Team mode toggle', 'nvdigital-open-operator-system-oos' ); ?></span>
					</button>
					<?php endif; ?>
					<?php if ( ! empty( $cpt_actions ) ) : ?>
					<div class="wp-mcp-ai-chat__cpt-actions" role="group" aria-label="<?php echo esc_attr__( 'Post type actions', 'nvdigital-open-operator-system-oos' ); ?>"></div>
					<?php endif; ?>
				</div>
			</div>
			<section class="wp-mcp-ai-chat__history" id="<?php echo esc_attr( $instance_id ); ?>-history" hidden aria-label="<?php esc_attr_e( 'Previous conversations', 'nvdigital-open-operator-system-oos' ); ?>">
				<div class="wp-mcp-ai-chat__history-header">
					<button type="button" class="wp-mcp-ai-chat__history-refresh" aria-label="<?php echo esc_attr__( 'Refresh conversation history', 'nvdigital-open-operator-system-oos' ); ?>" title="<?php echo esc_attr__( 'Refresh conversation history', 'nvdigital-open-operator-system-oos' ); ?>">
						<svg class="wp-mcp-ai-chat__history-refresh-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M4 12a8 8 0 018-8V3c-1.105 0-2.165.21-3.13.594l1.42 1.42A6.004 6.004 0 0112 5a7 7 0 110 14 7 7 0 01-6.93-6H3a8 8 0 008 8 8 8 0 000-16V3l-3 3 3 3v-1.078z"/>
						</svg>
						<span class="screen-reader-text"><?php esc_html_e( 'Refresh conversation history', 'nvdigital-open-operator-system-oos' ); ?></span>
					</button>
				</div>
				<div class="wp-mcp-ai-chat__history-status" role="status" aria-live="polite" hidden></div>
				<?php if ( 'sidebar' === $template && ! empty( $assistant_tools ) ) : ?>
					<div class="wp-mcp-ai-chat__tools-list">
						<h3 class="wp-mcp-ai-chat__tools-list-header"><?php esc_html_e( 'Available Tools', 'nvdigital-open-operator-system-oos' ); ?></h3>
						<ul class="wp-mcp-ai-chat__tools-items">
							<?php foreach ( $assistant_tools as $tool_slug ) : ?>
								<li class="wp-mcp-ai-chat__tools-item">
									<span class="wp-mcp-ai-chat__tools-item-icon">
										<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false">
											<path d="M10 2a1 1 0 011 1v4.586l3.707-3.707a1 1 0 111.414 1.414L12.414 9H17a1 1 0 110 2h-4.586l3.707 3.707a1 1 0 01-1.414 1.414L11 12.414V17a1 1 0 11-2 0v-4.586l-3.707 3.707a1 1 0 01-1.414-1.414L7.586 11H3a1 1 0 110-2h4.586L3.879 5.293a1 1 0 011.414-1.414L9 7.586V3a1 1 0 011-1z"/>
										</svg>
									</span>
									<span class="wp-mcp-ai-chat__tools-item-name"><?php echo esc_html( str_replace( '_', ' ', $tool_slug ) ); ?></span>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>
				<ul class="wp-mcp-ai-chat__history-list" role="list"></ul>
				<button type="button" class="wp-mcp-ai-chat__history-load-more" hidden>
					<?php esc_html_e( 'Load More', 'nvdigital-open-operator-system-oos' ); ?>
				</button>
			</section>
		</div>
			<?php
			// All dynamic values in this output buffer are escaped:
			// - User-facing text: esc_html(), esc_html_e(), esc_html__()
			// - HTML attributes: esc_attr(), esc_attr__(), esc_attr_e()
			// - URLs: esc_url(), esc_url_raw()
			// - Post content: wp_kses_post() (line where $assistant_content is echoed)
			// - JSON config: wp_json_encode() via wp_add_inline_script().
			return ob_get_clean();

		} catch ( Exception $e ) {
			// Catch any unexpected errors during shortcode rendering.
			WP_MCP_AI_Logger::log_critical(
				'Unexpected error rendering chat shortcode',
				array(
					'exception_message' => $e->getMessage(),
					'exception_code'    => $e->getCode(),
					'exception_file'    => $e->getFile(),
					'exception_line'    => $e->getLine(),
					'attributes'        => $atts,
				)
			);

			// Return user-friendly error message.
			return '<div class="wp-mcp-ai-chat__notice wp-mcp-ai-chat__error">' .
				esc_html__( 'Unable to load the chat interface. Please try refreshing the page or contact support if the problem persists.', 'nvdigital-open-operator-system-oos' ) .
				'</div>';
		}
	}

	/**
	 * ---------------------------------------------------------------
	 * Footer chat-bubble rendering
	 *
	 * Elementor widgets and Gutenberg blocks render the chat-bubble
	 * shell via wp_footer so the markup is a direct child of <body>.
	 * This avoids:
	 *  1. Stacking-context / overflow:hidden traps in page-builder
	 *     sections (Elementor header/footer templates especially).
	 *  2. wp_kses_post() stripping data-* attributes that chat.js
	 *     relies on for initialisation.
	 *  3. Script-timing issues when the header template renders
	 *     after footer scripts have already been printed.
	 * ------------------------------------------------------------- */

	/**
	 * Queued chat-bubble HTML fragments for footer rendering.
	 *
	 * @var string[]
	 */
	private static $footer_bubbles = array();

	/**
	 * Whether the wp_footer hook has been registered.
	 *
	 * @var bool
	 */
	private static $footer_hook_registered = false;

	/**
	 * Queue a fully-built chat-bubble HTML fragment for rendering
	 * inside wp_footer.
	 *
	 * Used by the Gutenberg chat-bubble block.  The Elementor widget
	 * renders inline and does not use this mechanism (JS promotes
	 * the element to document.body instead).
	 *
	 * The HTML should already be properly escaped at the call-site
	 * (esc_attr, esc_html, sanitize_hex_color, etc.).
	 *
	 * @param string $html Complete bubble HTML.
	 */
	public static function queue_footer_bubble( $html ) {
		self::$footer_bubbles[] = $html;

		if ( ! self::$footer_hook_registered ) {
			// Priority 5: render before footer scripts (priority 20) so the
			// DOM is present when chat.js and chat-bubble.js auto-initialise.
			add_action( 'wp_footer', array( __CLASS__, 'render_footer_bubbles' ), 5 );
			self::$footer_hook_registered = true;
		}
	}

	/**
	 * Output all queued chat-bubble fragments.
	 *
	 * Hooked to `wp_footer` at priority 5.
	 *
	 * Because the bubble HTML is injected after DOMContentLoaded, the
	 * chat-bubble.js auto-initialiser may have already run its global
	 * scan.  An inline script is appended to re-trigger initialisation
	 * so the newly-injected bubbles receive event listeners.
	 */
	public static function render_footer_bubbles() {
		if ( empty( self::$footer_bubbles ) ) {
			return;
		}

		foreach ( self::$footer_bubbles as $html ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML pre-escaped by callers using esc_attr(), esc_html(), sanitize_hex_color(), and wp_kses_post().
			echo $html;
		}

		// Re-trigger bubble init AND chat init for the just-injected markup.
		// chat-bubble.js exposes window.wpMcpAiChatBubble.init().
		// chat.js exposes window.wpMcpAiChatInit.init().
		// wp_get_inline_script_tag() (WP 5.7+) adds the CSP nonce automatically.
		$reinit_js = 'if(window.wpMcpAiChatInit&&window.wpMcpAiChatInit.init){window.wpMcpAiChatInit.init();}'
			. 'if(window.wpMcpAiChatBubble&&window.wpMcpAiChatBubble.init){window.wpMcpAiChatBubble.init();}';

		// Plugin requires WP 6.0+; wp_get_inline_script_tag() (added in WP 5.7) is always available.
		echo wp_get_inline_script_tag( $reinit_js ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_get_inline_script_tag() escapes and adds CSP nonce.

		self::$footer_bubbles = array();
	}

	/**
	 * Sanitise shortcode output while preserving elements the chat UI needs.
	 *
	 * WordPress's wp_kses_post() strips data-* attributes and SVG elements
	 * by default.  The chat interface relies on:
	 *
	 *  - `data-wp-mcp-ai-chat` and `data-template` for JS initialisation.
	 *  - SVG icons inside action buttons (send, attach, transcribe, etc.).
	 *  - Form element attributes (`required`, `placeholder`, `accept`,
	 *    `multiple`, `aria-controls`, `aria-label`, `hidden`).
	 *
	 * This wrapper temporarily extends the kses allow-list with the
	 * specific tags and attributes the chat UI needs, then removes the
	 * filter.  Only safe, presentation-only SVG elements are allowed —
	 * script, foreignObject, and event-handler attributes are NOT added.
	 *
	 * @param string $html Raw shortcode output.
	 * @return string Sanitised HTML with required elements intact.
	 */
	public static function kses_chat_output( $html ) {
		$filter = function ( $tags, $context ) {
			if ( 'post' !== $context ) {
				return $tags;
			}

			// Data attributes the chat JS needs on container elements.
			$extra_attrs = array(
				'data-wp-mcp-ai-chat'        => true,
				'data-template'              => true,
				'data-wp-mcp-ai-initialized' => true,
				'data-instance-id'           => true,
				'hidden'                     => true,
				'aria-controls'              => true,
				'aria-label'                 => true,
				'aria-expanded'              => true,
				'aria-hidden'                => true,
				'aria-live'                  => true,
				'required'                   => true,
				'placeholder'                => true,
			);

			foreach ( $tags as $tag => $attrs ) {
				if ( is_array( $attrs ) ) {
					$tags[ $tag ] = array_merge( $attrs, $extra_attrs );
				}
			}

			// Form element tags must be allowed unconditionally because wp_kses_allowed_html('post')
			// does not include them in all WordPress versions.  Relying on isset( $tags['form'] )
			// meant that the <form> tag — and therefore the chat submit handler — was silently
			// stripped by kses whenever WordPress's default 'post' allowlist lacked form elements,
			// leaving the rendered chat container with inert buttons.
			//
			// Pattern: merge any attrs already on the tag (if WordPress added it), then apply ours.
			$form_base    = ( isset( $tags['form'] ) && is_array( $tags['form'] ) ) ? $tags['form'] : array();
			$tags['form'] = array_merge(
				$form_base,
				$extra_attrs,
				array(
					'id'               => true,
					'class'            => true,
					'method'           => true,
					'action'           => true,
					'data-instance-id' => true,
				)
			);

			$button_base    = ( isset( $tags['button'] ) && is_array( $tags['button'] ) ) ? $tags['button'] : array();
			$tags['button'] = array_merge(
				$button_base,
				$extra_attrs,
				array(
					'type'          => true,
					'name'          => true,
					'value'         => true,
					'title'         => true,
					'disabled'      => true,
					'aria-haspopup' => true,
					'aria-atomic'   => true,
					'aria-selected' => true,
				)
			);

			$input_base    = ( isset( $tags['input'] ) && is_array( $tags['input'] ) ) ? $tags['input'] : array();
			$tags['input'] = array_merge(
				$input_base,
				$extra_attrs,
				array(
					'type'      => true,
					'name'      => true,
					'value'     => true,
					'disabled'  => true,
					'checked'   => true,
					'accept'    => true,
					'multiple'  => true,
					'min'       => true,
					'max'       => true,
					'step'      => true,
					'maxlength' => true,
				)
			);

			$select_base    = ( isset( $tags['select'] ) && is_array( $tags['select'] ) ) ? $tags['select'] : array();
			$tags['select'] = array_merge(
				$select_base,
				$extra_attrs,
				array(
					'name'     => true,
					'disabled' => true,
					'required' => true,
				)
			);

			$option_base    = ( isset( $tags['option'] ) && is_array( $tags['option'] ) ) ? $tags['option'] : array();
			$tags['option'] = array_merge(
				$option_base,
				$extra_attrs,
				array(
					'value'    => true,
					'selected' => true,
				)
			);

			$textarea_base    = ( isset( $tags['textarea'] ) && is_array( $tags['textarea'] ) ) ? $tags['textarea'] : array();
			$tags['textarea'] = array_merge(
				$textarea_base,
				$extra_attrs,
				array(
					'id'          => true,
					'class'       => true,
					'rows'        => true,
					'name'        => true,
					'disabled'    => true,
					'maxlength'   => true,
					'required'    => true,
					'placeholder' => true,
				)
			);

			// Safe SVG elements for chat UI icons (no script, foreignObject,
			// or event-handler attributes).
			//
			// Note: WordPress kses normalises attribute names to lowercase, so
			// `viewBox` in HTML becomes `viewbox` after kses processing.  Most
			// browsers tolerate lowercase `viewbox` in inline SVG; for strict
			// SVG compliance the icons would need to live outside kses.
			$svg_global = array(
				'class'       => true,
				'id'          => true,
				'style'       => true,
				'aria-hidden' => true,
				'focusable'   => true,
				'role'        => true,
			);

			$tags['svg'] = array_merge(
				$svg_global,
				array(
					'xmlns'        => true,
					'width'        => true,
					'height'       => true,
					'viewbox'      => true, // Lowercase – kses normalises viewBox → viewbox.
					'fill'         => true,
					'stroke'       => true,
					'stroke-width' => true, // SVG attribute is hyphenated (stroke-width).
				)
			);

			$tags['path'] = array(
				'd'               => true,
				'fill'            => true,
				'stroke'          => true,
				'stroke-width'    => true,
				'stroke-linecap'  => true,
				'stroke-linejoin' => true,
				'class'           => true,
			);

			$tags['circle'] = array(
				'cx'    => true,
				'cy'    => true,
				'r'     => true,
				'fill'  => true,
				'class' => true,
			);

			$tags['line'] = array(
				'x1'              => true,
				'y1'              => true,
				'x2'              => true,
				'y2'              => true,
				'stroke'          => true,
				'stroke-width'    => true,
				'stroke-linecap'  => true,
				'stroke-linejoin' => true,
				'class'           => true,
			);

			$tags['rect'] = array(
				'x'      => true,
				'y'      => true,
				'width'  => true,
				'height' => true,
				'rx'     => true,
				'ry'     => true,
				'fill'   => true,
				'stroke' => true,
				'class'  => true,
			);

			$tags['g'] = array(
				'fill'      => true,
				'transform' => true,
				'class'     => true,
			);

			$tags['polyline'] = array(
				'points'          => true,
				'fill'            => true,
				'stroke'          => true,
				'stroke-width'    => true,
				'stroke-linecap'  => true,
				'stroke-linejoin' => true,
				'class'           => true,
			);

			$tags['polygon'] = array(
				'points' => true,
				'fill'   => true,
				'stroke' => true,
				'class'  => true,
			);

			return $tags;
		};

		add_filter( 'wp_kses_allowed_html', $filter, 99, 2 );
		$safe = wp_kses_post( $html );
		remove_filter( 'wp_kses_allowed_html', $filter, 99 );

		return $safe;
	}

	/**
	 * Resolve the assistant identifier provided via shortcode attributes.
	 *
	 * Accepts numeric IDs, assistant slugs, or profession test identifiers (profession_XXX).
	 * Gracefully falls back when the supplied value cannot be resolved.
	 *
	 * @param mixed $assistant Assistant shortcode attribute value.
	 * @return int|string|false Assistant post ID when available, profession test identifier (profession_XXX) for profession testing, or 0 if not found.
	 */
	public static function resolve_assistant_id( $assistant ) {
		$assistant = is_scalar( $assistant ) ? trim( (string) $assistant ) : '';

		if ( '' === $assistant ) {
			return 0;
		}

		// Check if this is a profession test request (profession_XXX format).
		if ( is_string( $assistant ) && 0 === strpos( $assistant, 'profession_' ) ) {
			$profession_id = absint( str_replace( 'profession_', '', $assistant ) );
			if ( $profession_id ) {
				// Verify it's actually a profession post.
				$profession_post = get_post( $profession_id );
				if ( $profession_post && 'mcp_ai_profession' === $profession_post->post_type ) {
					// Return the full profession identifier to preserve it through the flow.
					return 'profession_' . $profession_id;
				}
			}
		}

		$maybe_id = absint( $assistant );
		if ( $maybe_id ) {
			$assistant_post = get_post( $maybe_id );
			if ( $assistant_post && WP_MCP_AI_Assistant_CPT::POST_TYPE === $assistant_post->post_type ) {
				return $maybe_id;
			}
		}

		$slug_candidates = array( $assistant );

		if ( function_exists( 'sanitize_title' ) ) {
			$sanitized = sanitize_title( $assistant );
			if ( $sanitized && $sanitized !== $assistant ) {
				$slug_candidates[] = $sanitized;
			}
		}

		foreach ( array_unique( $slug_candidates ) as $slug ) {
			$assistant_post = get_page_by_path( $slug, OBJECT, WP_MCP_AI_Assistant_CPT::POST_TYPE );
			if ( $assistant_post ) {
				return (int) $assistant_post->ID;
			}
		}

		return 0;
	}

	/**
	 * Generate a guest access token for the given assistant.
	 *
	 * Optionally binds the token to the page origin so a token leaked from
	 * one origin cannot be replayed from another (audit F-AUTHZ-04 / R-S-09).
	 * Pass `$origin` to override the default (the host portion of `home_url()`),
	 * or filter `wp_mcp_ai_guest_token_issuance_origin` to provide a different
	 * binding host. An empty string disables the binding for this token (legacy
	 * behaviour).
	 *
	 * @param int    $assistant_id Assistant post ID.
	 * @param string $origin       Optional. Origin host to bind the token to.
	 *                             Defaults to the host of `home_url()`. Pass an
	 *                             empty string to disable binding.
	 * @return string Guest access token or empty string on failure.
	 */
	public static function generate_guest_token( $assistant_id, $origin = null ) {
		$assistant_id = absint( $assistant_id );

		if ( ! $assistant_id ) {
			return '';
		}

		$token = wp_generate_password( 32, false, false );

		if ( ! $token ) {
			return '';
		}

		$ttl = self::get_guest_token_ttl();

		if ( null === $origin ) {
			$origin = self::default_guest_token_origin();
		}

		/**
		 * Filter the origin a guest token is bound to at issuance.
		 *
		 * Return an empty string to disable origin binding for this token.
		 *
		 * @param string $origin       Bound origin host (lower-case, no scheme).
		 * @param int    $assistant_id Assistant post ID.
		 */
		$origin = apply_filters( 'wp_mcp_ai_guest_token_issuance_origin', $origin, $assistant_id );

		$record = array(
			'assistant_id' => $assistant_id,
			'created'      => time(),
			'origin'       => is_string( $origin ) ? strtolower( trim( $origin ) ) : '',
		);

		$saved = set_transient( self::build_guest_token_key( $token ), $record, $ttl );

		if ( ! $saved ) {
			return '';
		}

		return $token;
	}

	/**
	 * Validate a guest token and ensure it is scoped to the requested assistant.
	 *
	 * Enforces both the transient-based sliding TTL and an absolute maximum
	 * lifetime from the token's creation timestamp to prevent indefinite renewal.
	 *
	 * When a `WP_REST_Request` is provided and the token's stored record is
	 * bound to an origin, the request's `Origin` header (or `Referer` host as a
	 * fallback) must match the bound origin or be present in the allowlist
	 * returned by the `wp_mcp_ai_guest_token_allowed_origins` filter
	 * (audit F-AUTHZ-04 / R-S-09). Records persisted before this binding
	 * was introduced (no `origin` field) skip the check for backward
	 * compatibility for the remainder of their TTL.
	 *
	 * @param string               $token        Guest access token supplied by the client.
	 * @param int                  $assistant_id Assistant post ID provided in the request.
	 * @param WP_REST_Request|null $request      Optional. REST request to derive the
	 *                                            calling origin from for binding checks.
	 * @return int|false Assistant ID associated with the token when valid, false otherwise.
	 */
	public static function validate_guest_token( $token, $assistant_id = 0, $request = null ) {
		$token = is_string( $token ) ? trim( $token ) : '';

		if ( '' === $token ) {
			return false;
		}

		$data = get_transient( self::build_guest_token_key( $token ) );

		if ( empty( $data ) || ! is_array( $data ) ) {
			return false;
		}

		// Enforce absolute maximum lifetime.
		$created = isset( $data['created'] ) ? absint( $data['created'] ) : 0;
		if ( $created > 0 && ( time() - $created ) > self::GUEST_TOKEN_MAX_TTL ) {
			delete_transient( self::build_guest_token_key( $token ) );
			return false;
		}

		$stored_assistant = isset( $data['assistant_id'] ) ? absint( $data['assistant_id'] ) : 0;

		if ( $assistant_id && $stored_assistant && $assistant_id !== $stored_assistant ) {
			return false;
		}

		// Origin binding (audit F-AUTHZ-04 / R-S-09). Skip when the record has
		// no stored origin (legacy tokens issued before binding was introduced)
		// or when the caller did not pass a request — internal call paths such
		// as CLI / cron must remain unaffected.
		$bound_origin = isset( $data['origin'] ) ? (string) $data['origin'] : '';
		if ( '' !== $bound_origin && $request instanceof WP_REST_Request ) {
			$request_origin = self::extract_request_origin_host( $request );

			/**
			 * Filter the list of origin hosts allowed to use a guest token.
			 *
			 * The bound origin is always included; this filter lets
			 * integrators add additional origins (e.g. for a single token
			 * shared across an explicit allowlist of customer domains).
			 *
			 * @param string[]        $allowed_origins Lower-case host names.
			 * @param int             $stored_assistant Assistant post ID the token is scoped to.
			 * @param WP_REST_Request $request         Incoming REST request.
			 */
			$allowed_origins = apply_filters(
				'wp_mcp_ai_guest_token_allowed_origins',
				array( $bound_origin ),
				$stored_assistant,
				$request
			);

			if ( ! is_array( $allowed_origins ) ) {
				$allowed_origins = array( $bound_origin );
			}
			$allowed_origins = array_values( array_unique( array_filter( array_map( 'strtolower', array_map( 'trim', $allowed_origins ) ) ) ) );

			if ( '' === $request_origin || ! in_array( $request_origin, $allowed_origins, true ) ) {
				return false;
			}
		}

		// Refresh the sliding TTL for active sessions.
		set_transient( self::build_guest_token_key( $token ), $data, self::get_guest_token_ttl() );

		return $stored_assistant;
	}

	/**
	 * Default origin host to bind a freshly issued guest token to.
	 *
	 * Returns the lower-case host portion of `home_url()`, which matches what
	 * the browser will send as the `Origin` header when the chat widget calls
	 * back into the REST API from a same-origin page or a same-origin iframe.
	 *
	 * @return string Host or empty string.
	 */
	protected static function default_guest_token_origin() {
		$home_host = wp_parse_url( home_url(), PHP_URL_HOST );
		return is_string( $home_host ) ? strtolower( $home_host ) : '';
	}

	/**
	 * Derive the calling origin host from a REST request.
	 *
	 * Prefers the `Origin` header (set by the browser on cross-origin XHR /
	 * fetch and on POST). Falls back to the host portion of `Referer` when
	 * `Origin` is absent, which covers same-origin GETs that some browsers
	 * still send without an `Origin` header.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return string Lower-case host or empty string when neither header is present.
	 */
	protected static function extract_request_origin_host( WP_REST_Request $request ) {
		$origin = $request->get_header( 'origin' );
		if ( is_string( $origin ) && '' !== $origin && 'null' !== strtolower( $origin ) ) {
			$host = wp_parse_url( $origin, PHP_URL_HOST );
			if ( is_string( $host ) && '' !== $host ) {
				return strtolower( $host );
			}
		}

		$referer = $request->get_header( 'referer' );
		if ( is_string( $referer ) && '' !== $referer ) {
			$host = wp_parse_url( $referer, PHP_URL_HOST );
			if ( is_string( $host ) && '' !== $host ) {
				return strtolower( $host );
			}
		}

		return '';
	}

	/**
	 * Build the transient key used to persist guest access tokens.
	 *
	 * @param string $token Guest access token.
	 * @return string
	 */
	protected static function build_guest_token_key( $token ) {
		return self::GUEST_TOKEN_TRANSIENT_PREFIX . md5( $token );
	}

	/**
	 * Get the configured guest token TTL from admin settings.
	 *
	 * Falls back to the default constant if the setting is not configured
	 * and enforces the maximum allowed lifetime cap.
	 *
	 * @return int TTL in seconds.
	 */
	protected static function get_guest_token_ttl() {
		$ttl = self::GUEST_TOKEN_TTL;

		if ( class_exists( 'WP_MCP_AI_Settings_Registry' ) ) {
			$configured = WP_MCP_AI_Settings_Registry::get_setting( 'guest_token_lifetime', self::GUEST_TOKEN_TTL );
			$ttl        = absint( $configured );
		}

		// Enforce minimum and maximum caps.
		$ttl = max( self::GUEST_TOKEN_MIN_TTL, min( $ttl, self::GUEST_TOKEN_MAX_TTL ) );

		return $ttl;
	}

	/**
	 * Get async tool timeout in milliseconds from settings.
	 *
	 * This helper ensures consistent timeout calculation across all contexts
	 * (shortcode, admin test pages, etc.).
	 *
	 * @param array|null $settings Optional pre-fetched settings array.
	 * @return int Timeout in milliseconds (default 300000ms / 5 minutes).
	 */
	public static function get_async_tool_timeout_ms( $settings = null ) {
		if ( null === $settings ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
		}

		$async_timeout_seconds = isset( $settings['async_tool_timeout'] ) ? absint( $settings['async_tool_timeout'] ) : self::ASYNC_TOOL_TIMEOUT_DEFAULT;
		return max( self::ASYNC_TOOL_TIMEOUT_MIN, $async_timeout_seconds ) * 1000;
	}

	/**
	 * Build an inline JS snippet that augments the localized `wpMcpAiChat`
	 * object with the chat-client ⇄ memory bridge endpoints.
	 *
	 * The snippet is appended after every `wp_localize_script( SCRIPT_HANDLE, 'wpMcpAiChat', ... )`
	 * call in the plugin (block render, shortcode, Elementor widget, embedded
	 * client), so the chat-memory-service.js can locate the REST routes.
	 *
	 * Returns an empty string when the user is not logged in (the bridge
	 * disallows guest access) or when the kill-switch filter disables it.
	 *
	 * @since 1.6.0
	 *
	 * @return string Inline JS snippet ready for wp_add_inline_script.
	 */
	public static function get_chat_memory_endpoints_inline_script() {
		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return '';
		}

		if (
			class_exists( 'WP_MCP_AI_REST_Chat_Memory_Controller' )
			&& ! WP_MCP_AI_REST_Chat_Memory_Controller::is_chat_memory_enabled( $user_id )
		) {
			return '';
		}

		$base = WP_MCP_AI_Request_Context::normalise_rest_url( rest_url( WP_MCP_AI_REST::REST_NAMESPACE . '/chat-memory' ) );
		$base = esc_url_raw( $base );

		$endpoints = array(
			'preferences' => $base . '/preferences',
			'wakeUp'      => $base . '/wake-up',
			'recall'      => $base . '/recall',
			'store'       => $base . '/store',
			'audit'       => $base . '/audit',
			'sessionBase' => $base . '/sessions/',
			'itemBase'    => $base . '/',
		);

		$json = wp_json_encode( $endpoints );
		if ( false === $json ) {
			return '';
		}

		return 'window.wpMcpAiChat = window.wpMcpAiChat || {}; window.wpMcpAiChat.memoryEndpoints = ' . $json . ';';
	}

	/**
	 * Build an inline JS snippet that augments the localized `wpMcpAiChat`
	 * object with the storage-worker URL and offload threshold.
	 *
	 * Mirrors get_chat_memory_endpoints_inline_script(): appended after every
	 * wp_localize_script( SCRIPT_HANDLE, 'wpMcpAiChat', ... ) call so the
	 * storage-util.js service can spawn the worker on every chat surface
	 * (shortcode, block, Elementor, embedded client, admin pages).
	 *
	 * No user gate — guest chat surfaces benefit too. A non-positive
	 * threshold disables the offload entirely (kill switch).
	 *
	 * @since 1.1.62
	 *
	 * @return string Inline JS snippet ready for wp_add_inline_script.
	 */
	public static function get_storage_worker_inline_script() {
		$threshold = (int) apply_filters( 'wp_mcp_ai_storage_worker_threshold', 10000 );
		$threshold = max( 0, $threshold );

		$worker_url = plugins_url( 'assets/js/storage-worker.js', WP_MCP_AI_FILE );

		$json = wp_json_encode(
			array(
				'storageWorkerUrl'       => esc_url_raw( $worker_url ),
				'storageWorkerThreshold' => $threshold,
			)
		);
		if ( false === $json ) {
			return '';
		}

		return 'window.wpMcpAiChat = window.wpMcpAiChat || {};'
			. 'if ( window.wpMcpAiChat.storageWorkerUrl === undefined ) {'
			. 'Object.assign( window.wpMcpAiChat, ' . $json . ' ); }';
	}

	/**
	 * Retrieve tool shortcut metadata for the supplied assistant.
	 *
	 * @param int   $assistant_id    Assistant post ID.
	 * @param array $additional_tools Optional array of additional tool slugs to include shortcuts for.
	 * @return array[]
	 */
	public static function get_assistant_tool_shortcuts( $assistant_id, $additional_tools = array() ) {
		$assistant_id = absint( $assistant_id );

		if ( ! $assistant_id ) {
			return array();
		}

		if ( ! class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
			return array();
		}

		$config             = WP_MCP_AI_Assistant_CPT::get_assistant_configuration( $assistant_id );
		$shortcuts          = array();
		$selected_tools     = array();
		$prebuilt_overrides = array();

		if ( ! empty( $config['tools'] ) && is_array( $config['tools'] ) ) {
			foreach ( $config['tools'] as $tool_slug ) {
				$tool_slug = sanitize_key( $tool_slug );

				if ( '' === $tool_slug ) {
					continue;
				}

				$selected_tools[] = $tool_slug;
			}

			$selected_tools = array_values( array_unique( $selected_tools ) );
		}

		// Merge in additional tools from shortcode parameter.
		if ( ! empty( $additional_tools ) && is_array( $additional_tools ) ) {
			foreach ( $additional_tools as $tool_slug ) {
				$tool_slug = sanitize_key( $tool_slug );

				if ( '' === $tool_slug ) {
					continue;
				}

				// Only add if not already in the list.
				if ( ! in_array( $tool_slug, $selected_tools, true ) ) {
					$selected_tools[] = $tool_slug;
				}
			}

			$selected_tools = array_values( array_unique( $selected_tools ) );
		}

		if ( ! empty( $config['tool_shortcuts'] ) && is_array( $config['tool_shortcuts'] ) ) {
			$custom_shortcuts = $config['tool_shortcuts'];

			if ( method_exists( 'WP_MCP_AI_Assistant_CPT', 'sanitize_tool_shortcuts_meta' ) ) {
				$custom_shortcuts = WP_MCP_AI_Assistant_CPT::sanitize_tool_shortcuts_meta( $custom_shortcuts );
			}

			/**
			 * Filter the list of custom prompt shortcuts configured for an assistant.
			 *
			 * @since 1.1.0
			 *
			 * @param array $custom_shortcuts Sanitized custom shortcuts.
			 * @param int   $assistant_id     Assistant post ID.
			 * @param array $config           Assistant configuration array.
			 */
			$custom_shortcuts = apply_filters( 'wp_mcp_ai_assistant_custom_tool_shortcuts', $custom_shortcuts, $assistant_id, $config );

			if ( is_array( $custom_shortcuts ) ) {
				foreach ( $custom_shortcuts as $custom_shortcut ) {
					if ( ! is_array( $custom_shortcut ) ) {
						continue;
					}

					// Skip hidden shortcuts.
					if ( isset( $custom_shortcut['hidden'] ) && $custom_shortcut['hidden'] ) {
						continue;
					}

					$label   = isset( $custom_shortcut['label'] ) ? sanitize_text_field( $custom_shortcut['label'] ) : '';
					$payload = isset( $custom_shortcut['payload'] ) ? sanitize_textarea_field( $custom_shortcut['payload'] ) : '';

					if ( '' === $label || '' === $payload ) {
						continue;
					}

					$tool_slug = '';
					if ( isset( $custom_shortcut['tool'] ) && is_string( $custom_shortcut['tool'] ) ) {
						$tool_slug = sanitize_key( $custom_shortcut['tool'] );
					}

					if ( '' !== $tool_slug && ! in_array( $tool_slug, $selected_tools, true ) ) {
						continue;
					}

					$entry = array(
						'tool'    => ( '' !== $tool_slug ) ? $tool_slug : 'custom',
						'label'   => $label,
						'payload' => $payload,
					);

					if ( isset( $custom_shortcut['description'] ) && is_string( $custom_shortcut['description'] ) ) {
						$entry['description'] = sanitize_textarea_field( $custom_shortcut['description'] );
					}

					$shortcuts[] = $entry;
				}
			}
		}

		if ( ! empty( $config['tool_prebuilt_shortcuts'] ) && is_array( $config['tool_prebuilt_shortcuts'] ) ) {
			$prebuilt_overrides = $config['tool_prebuilt_shortcuts'];

			if ( method_exists( 'WP_MCP_AI_Assistant_CPT', 'sanitize_prebuilt_tool_shortcuts_meta' ) ) {
				$prebuilt_overrides = WP_MCP_AI_Assistant_CPT::sanitize_prebuilt_tool_shortcuts_meta( $prebuilt_overrides );
			}
		}

		if ( ! empty( $config['disable_prebuilt_shortcuts'] ) ) {
			// Even with prebuilt shortcuts disabled, ensure fallback shortcut if no custom shortcuts.
			if ( empty( $shortcuts ) ) {
				$fallback_shortcut = array(
					'tool'    => 'default',
					'label'   => sanitize_text_field( __( 'What can you do?', 'nvdigital-open-operator-system-oos' ) ),
					'payload' => sanitize_textarea_field( 'Can you tell me what you can do?' ),
				);

				/**
				 * Filter the default shortcut shown when an assistant has no tool shortcuts configured.
				 *
				 * @since 1.0.1
				 *
				 * @param array $fallback_shortcut Default shortcut configuration.
				 * @param int   $assistant_id      Assistant post ID.
				 */
				$fallback_shortcut = apply_filters( 'wp_mcp_ai_default_tool_shortcut', $fallback_shortcut, $assistant_id );

				if ( is_array( $fallback_shortcut ) && ! empty( $fallback_shortcut['label'] ) && ! empty( $fallback_shortcut['payload'] ) ) {
					$fallback_shortcut['tool'] = isset( $fallback_shortcut['tool'] ) && is_string( $fallback_shortcut['tool'] )
						? sanitize_key( $fallback_shortcut['tool'] )
						: 'default';

					$fallback_shortcut['label']   = sanitize_text_field( $fallback_shortcut['label'] );
					$fallback_shortcut['payload'] = sanitize_textarea_field( $fallback_shortcut['payload'] );

					if ( isset( $fallback_shortcut['description'] ) ) {
						if ( is_string( $fallback_shortcut['description'] ) ) {
							$fallback_shortcut['description'] = sanitize_textarea_field( $fallback_shortcut['description'] );
						} else {
							unset( $fallback_shortcut['description'] );
						}
					}

					$shortcuts[] = $fallback_shortcut;
				}
			}
			return $shortcuts;
		}

		if ( empty( $selected_tools ) ) {
			// Even with no tools selected, ensure fallback shortcut if no custom shortcuts.
			if ( empty( $shortcuts ) ) {
				$fallback_shortcut = array(
					'tool'    => 'default',
					'label'   => sanitize_text_field( __( 'What can you do?', 'nvdigital-open-operator-system-oos' ) ),
					'payload' => sanitize_textarea_field( 'Can you tell me what you can do?' ),
				);

				/**
				 * Filter the default shortcut shown when an assistant has no tool shortcuts configured.
				 *
				 * @since 1.0.1
				 *
				 * @param array $fallback_shortcut Default shortcut configuration.
				 * @param int   $assistant_id      Assistant post ID.
				 */
				$fallback_shortcut = apply_filters( 'wp_mcp_ai_default_tool_shortcut', $fallback_shortcut, $assistant_id );

				if ( is_array( $fallback_shortcut ) && ! empty( $fallback_shortcut['label'] ) && ! empty( $fallback_shortcut['payload'] ) ) {
					$fallback_shortcut['tool'] = isset( $fallback_shortcut['tool'] ) && is_string( $fallback_shortcut['tool'] )
						? sanitize_key( $fallback_shortcut['tool'] )
						: 'default';

					$fallback_shortcut['label']   = sanitize_text_field( $fallback_shortcut['label'] );
					$fallback_shortcut['payload'] = sanitize_textarea_field( $fallback_shortcut['payload'] );

					if ( isset( $fallback_shortcut['description'] ) ) {
						if ( is_string( $fallback_shortcut['description'] ) ) {
							$fallback_shortcut['description'] = sanitize_textarea_field( $fallback_shortcut['description'] );
						} else {
							unset( $fallback_shortcut['description'] );
						}
					}

					$shortcuts[] = $fallback_shortcut;
				}
			}
			return $shortcuts;
		}

		$registry = WP_MCP_AI_Tool_Registry::get_instance();

		foreach ( $selected_tools as $tool_slug ) {
			$tool = $registry->get_tool( $tool_slug );

			if ( ! $tool ) {
				continue;
			}

			if ( array_key_exists( $tool_slug, $prebuilt_overrides ) ) {
				$override_settings  = $prebuilt_overrides[ $tool_slug ];
				$override_shortcuts = array();

				if ( isset( $override_settings['shortcuts'] ) && is_array( $override_settings['shortcuts'] ) ) {
					$override_shortcuts = $override_settings['shortcuts'];
				}

				if ( ! empty( $override_shortcuts ) ) {
					foreach ( $override_shortcuts as $override_shortcut ) {
						if ( ! is_array( $override_shortcut ) ) {
							continue;
						}

						// Skip hidden shortcuts.
						if ( isset( $override_shortcut['hidden'] ) && $override_shortcut['hidden'] ) {
							continue;
						}

						$label   = isset( $override_shortcut['label'] ) ? sanitize_text_field( $override_shortcut['label'] ) : '';
						$payload = isset( $override_shortcut['payload'] ) ? sanitize_textarea_field( $override_shortcut['payload'] ) : '';

						if ( '' === $label || '' === $payload ) {
							continue;
						}

						$entry = array(
							'tool'    => $tool_slug,
							'label'   => $label,
							'payload' => $payload,
						);

						if ( isset( $override_shortcut['description'] ) && is_string( $override_shortcut['description'] ) ) {
							$entry['description'] = sanitize_textarea_field( $override_shortcut['description'] );
						}

						$shortcuts[] = $entry;
					}
				}

				continue;
			}

			$tasks         = array();
			$skip_fallback = false;

			if ( $tool instanceof WP_MCP_AI_Tool_Shortcuts_Interface ) {
				$tasks = $tool->get_shortcut_tasks();
			} elseif ( method_exists( $tool, 'get_shortcut_tasks' ) ) {
				$tasks = $tool->get_shortcut_tasks();
			}

			if ( null === $tasks ) {
				$skip_fallback = true;
			}

			$tasks = apply_filters( 'wp_mcp_ai_tool_shortcut_tasks', $tasks, $tool, $assistant_id );
			$tasks = apply_filters( 'wp_mcp_ai_tool_shortcut_tasks_' . $tool_slug, $tasks, $tool, $assistant_id );

			if ( null === $tasks ) {
				continue;
			}

			$should_register_fallback = ! $skip_fallback;

			if ( $tool instanceof WP_MCP_AI_Tool_Fallback_Shortcut_Interface ) {
				$should_register_fallback = (bool) $tool->should_register_fallback_shortcut( $assistant_id );
			} elseif ( method_exists( $tool, 'should_register_fallback_shortcut' ) ) {
				$should_register_fallback = (bool) $tool->should_register_fallback_shortcut( $assistant_id );
			}

			/**
			 * Filter whether a fallback shortcut should be automatically appended for the tool.
			 *
			 * @since 1.0.1
			 *
			 * @param bool                     $should_register_fallback Whether the fallback shortcut should be added.
			 * @param WP_MCP_AI_Tool_Interface $tool                     Tool instance currently being processed.
			 * @param int                      $assistant_id             Assistant post ID.
			 * @param mixed                    $tasks                    Shortcut tasks supplied by the tool.
			 */
			$should_register_fallback = apply_filters(
				'wp_mcp_ai_tool_should_register_fallback_shortcut',
				$should_register_fallback,
				$tool,
				$assistant_id,
				$tasks
			);

			if ( empty( $tasks ) || ! is_array( $tasks ) ) {
				if ( ! $should_register_fallback ) {
					continue;
				}

				$shortcuts[] = array(
					'tool'    => $tool->get_slug(),
					'label'   => $tool->get_slug(),
					'payload' => $tool->get_slug(),
				);
				continue;
			}

			foreach ( $tasks as $task ) {
				if ( ! is_array( $task ) ) {
					continue;
				}

				$label   = isset( $task['label'] ) && is_string( $task['label'] ) ? sanitize_text_field( $task['label'] ) : '';
				$payload = isset( $task['payload'] ) && is_string( $task['payload'] ) ? sanitize_textarea_field( $task['payload'] ) : '';

				if ( '' === $label && '' === $payload ) {
					continue;
				}

				if ( '' === $label ) {
					$label = $tool->get_slug();
				}

				if ( '' === $payload ) {
					$payload = $tool->get_slug();
				}

				$entry = array(
					'tool'    => $tool->get_slug(),
					'label'   => $label,
					'payload' => $payload,
				);

				if ( isset( $task['description'] ) && is_string( $task['description'] ) ) {
					$entry['description'] = sanitize_textarea_field( $task['description'] );
				}

				$shortcuts[] = $entry;
			}
		}

		$shortcuts = apply_filters( 'wp_mcp_ai_assistant_tool_shortcuts', $shortcuts, $assistant_id );

		$shortcuts = array_values(
			array_filter(
				$shortcuts,
				static function ( $shortcut ) {
					if ( empty( $shortcut ) || ! is_array( $shortcut ) ) {
						return false;
					}

					if ( empty( $shortcut['label'] ) || empty( $shortcut['payload'] ) ) {
						return false;
					}

					return true;
				}
			)
		);

		$default_shortcut = array(
			'tool'    => 'default',
			'label'   => sanitize_text_field( __( 'What can you do?', 'nvdigital-open-operator-system-oos' ) ),
			'payload' => sanitize_textarea_field( 'what are some things you can do' ),
		);

		/**
		 * Filter the default shortcut that is appended for every assistant.
		 *
		 * @since 1.0.1
		 *
		 * @param array $default_shortcut Default shortcut configuration.
		 * @param int   $assistant_id     Assistant post ID.
		 */
		$default_shortcut = apply_filters( 'wp_mcp_ai_default_tool_shortcut', $default_shortcut, $assistant_id );

		if ( is_array( $default_shortcut ) && ! empty( $default_shortcut['label'] ) && ! empty( $default_shortcut['payload'] ) ) {
			$default_shortcut['tool'] = isset( $default_shortcut['tool'] ) && is_string( $default_shortcut['tool'] )
				? sanitize_key( $default_shortcut['tool'] )
				: 'default';

			$default_shortcut['label']   = sanitize_text_field( $default_shortcut['label'] );
			$default_shortcut['payload'] = sanitize_textarea_field( $default_shortcut['payload'] );

			if ( isset( $default_shortcut['description'] ) ) {
				if ( is_string( $default_shortcut['description'] ) ) {
					$default_shortcut['description'] = sanitize_textarea_field( $default_shortcut['description'] );
				} else {
					unset( $default_shortcut['description'] );
				}
			}

			$has_default_shortcut = false;

			foreach ( $shortcuts as $shortcut ) {
				if ( ! is_array( $shortcut ) ) {
					continue;
				}

				if ( isset( $shortcut['payload'] ) && $shortcut['payload'] === $default_shortcut['payload'] ) {
					$has_default_shortcut = true;
					break;
				}
			}

			if ( ! $has_default_shortcut ) {
				$shortcuts[] = $default_shortcut;
			}
		}

		if ( empty( $shortcuts ) ) {
			$fallback_shortcut = array(
				'tool'    => 'default',
				'label'   => sanitize_text_field( __( 'What are some things you can do?', 'nvdigital-open-operator-system-oos' ) ),
				'payload' => sanitize_textarea_field( 'what are some things you can do' ),
			);

			/**
			 * Filter the default shortcut shown when an assistant has no tool shortcuts configured.
			 *
			 * @since 1.0.1
			 *
			 * @param array $fallback_shortcut Default shortcut configuration.
			 * @param int   $assistant_id      Assistant post ID.
			 */
			$fallback_shortcut = apply_filters( 'wp_mcp_ai_default_tool_shortcut', $fallback_shortcut, $assistant_id );

			if ( is_array( $fallback_shortcut ) && ! empty( $fallback_shortcut['label'] ) && ! empty( $fallback_shortcut['payload'] ) ) {
				$fallback_shortcut['tool'] = isset( $fallback_shortcut['tool'] ) && is_string( $fallback_shortcut['tool'] )
					? sanitize_key( $fallback_shortcut['tool'] )
					: 'default';

				$fallback_shortcut['label']   = sanitize_text_field( $fallback_shortcut['label'] );
				$fallback_shortcut['payload'] = sanitize_textarea_field( $fallback_shortcut['payload'] );

				if ( isset( $fallback_shortcut['description'] ) ) {
					if ( is_string( $fallback_shortcut['description'] ) ) {
						$fallback_shortcut['description'] = sanitize_textarea_field( $fallback_shortcut['description'] );
					} else {
						unset( $fallback_shortcut['description'] );
					}
				}

				$shortcuts[] = $fallback_shortcut;
			}
		}

		return $shortcuts;
	}

	/**
	 * Collect unique file extensions that correspond to the supplied MIME types.
	 *
	 * @param array $allowed_mimes List of MIME types.
	 * @return array
	 */
	protected static function get_allowed_extensions_for_mimes( array $allowed_mimes ) {
		if ( empty( $allowed_mimes ) ) {
			return array();
		}

		$allowed_mimes = array_values(
			array_unique(
				array_filter(
					array_map( 'strtolower', $allowed_mimes )
				)
			)
		);

		if ( empty( $allowed_mimes ) ) {
			return array();
		}

		$extensions = array();
		$mime_map   = wp_get_mime_types();

		foreach ( $mime_map as $exts => $mime ) {
			$mime = strtolower( $mime );

			if ( ! in_array( $mime, $allowed_mimes, true ) ) {
				continue;
			}

			$parts = array_map( 'trim', explode( '|', $exts ) );

			foreach ( $parts as $extension ) {
				if ( '' === $extension ) {
					continue;
				}

				$extensions[] = strtolower( $extension );
			}
		}

		$custom_mime_extensions = array(
			'application/x-ndjson' => array( 'ndjson', 'jsonl' ),
			'application/jsonl'    => array( 'jsonl' ),
		);

		foreach ( $custom_mime_extensions as $mime => $custom_extensions ) {
			if ( ! in_array( $mime, $allowed_mimes, true ) ) {
				continue;
			}

			foreach ( $custom_extensions as $extension ) {
				$extension = strtolower( (string) $extension );

				if ( '' === $extension ) {
					continue;
				}

				$extensions[] = $extension;
			}
		}

		return array_values( array_unique( $extensions ) );
	}

	/**
	 * Build the tokens used for the file input accept attribute.
	 *
	 * @param array $image_mimes    Allowed image MIME types.
	 * @param array $file_mimes     Allowed file MIME types.
	 * @param array $extensions     Allowed file extensions (without dots).
	 * @return array
	 */
	protected static function build_file_accept_tokens( array $image_mimes, array $file_mimes, array $extensions ) {
		$tokens = array();

		foreach ( array_merge( $image_mimes, $file_mimes ) as $mime ) {
			$mime = strtolower( (string) $mime );

			if ( '' !== $mime ) {
				$tokens[] = $mime;
			}
		}

		foreach ( $extensions as $extension ) {
			$extension = strtolower( (string) $extension );

			if ( '' === $extension ) {
				continue;
			}

			$extension = ltrim( $extension, '.' );

			if ( '' !== $extension ) {
				$tokens[] = '.' . $extension;
			}
		}

		return array_values(
			array_unique(
				array_filter( $tokens )
			)
		);
	}
}
