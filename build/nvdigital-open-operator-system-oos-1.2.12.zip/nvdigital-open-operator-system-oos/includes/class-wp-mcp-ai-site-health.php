<?php
/**
 * Site Health Integration
 *
 * Integrates with WordPress Site Health to provide monitoring and diagnostics
 * for the NV oOS plugin functionality.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Site Health Integration Class
 *
 * Registers custom health checks and debug information for the plugin.
 */
class WP_MCP_AI_Site_Health {

	/**
	 * Initialize site health integration
	 */
	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register WordPress hooks
	 */
	private function register_hooks() {
		// Register site health tests.
		add_filter( 'site_status_tests', array( $this, 'register_tests' ) );

		// Register debug information.
		add_filter( 'debug_information', array( $this, 'register_debug_info' ) );
	}

	/**
	 * Register site health tests
	 *
	 * @param array $tests Existing tests.
	 * @return array Modified tests array
	 */
	public function register_tests( $tests ) {
		// Direct tests (run immediately).
		$tests['direct']['wp_mcp_ai_api_connectivity'] = array(
			'label' => __( 'NV oOS API Connectivity', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_api_connectivity' ),
		);

		$tests['direct']['wp_mcp_ai_model_availability'] = array(
			'label' => __( 'NV oOS Model Availability', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_model_availability' ),
		);

		$tests['direct']['wp_mcp_ai_credentials'] = array(
			'label' => __( 'NV oOS Credentials Validation', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_credentials' ),
		);

		$tests['direct']['wp_mcp_ai_tool_functionality'] = array(
			'label' => __( 'NV oOS Tool Functionality', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_tool_functionality' ),
		);

		$tests['direct']['wp_mcp_ai_mcp_schema_compliance'] = array(
			'label' => __( 'NV oOS MCP Tool Schema Compliance', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_mcp_schema_compliance' ),
		);

		$tests['direct']['wp_mcp_ai_database_schema'] = array(
			'label' => __( 'NV oOS Database Schema', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_database_schema' ),
		);

		$tests['direct']['wp_mcp_ai_cache_backend'] = array(
			'label' => __( 'NV oOS Cache Backend', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_cache_backend' ),
		);

		$tests['direct']['wp_mcp_ai_queue_storage'] = array(
			'label' => __( 'NV oOS Queue Storage Engine', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_queue_storage' ),
		);

		// Security tests (1.2.0).
		$tests['direct']['wp_mcp_ai_cron_configuration'] = array(
			'label' => __( 'NV oOS Cron Configuration', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_cron_configuration' ),
		);

		$tests['direct']['wp_mcp_ai_security_posture'] = array(
			'label' => __( 'NV oOS Security Posture', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_security_posture' ),
		);

		$tests['direct']['wp_mcp_ai_file_integrity'] = array(
			'label' => __( 'Open Operator System — File Integrity', 'nvdigital-open-operator-system-oos' ),
			'test'  => array( $this, 'test_file_integrity' ),
		);

		return $tests;
	}

	/**
	 * Register debug information
	 *
	 * @param array $debug_info Existing debug information.
	 * @return array Modified debug information
	 */
	public function register_debug_info( $debug_info ) {
		$debug_info['nvdigital-open-operator-system-oos'] = array(
			'label'  => __( 'NV oOS', 'nvdigital-open-operator-system-oos' ),
			'fields' => $this->get_debug_fields(),
		);

		return $debug_info;
	}

	/**
	 * Test plugin file integrity
	 *
	 * @return array Test result
	 */
	public function test_file_integrity() {
		$result = array(
			'label'       => __( 'Open Operator System — File Integrity', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'Files', 'nvdigital-open-operator-system-oos' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => 'wp_mcp_ai_file_integrity',
		);

		if ( function_exists( 'wp_mcp_ai_prune_missing_files_option' ) ) {
			wp_mcp_ai_prune_missing_files_option();
		}

		$missing = get_option( 'wp_mcp_ai_missing_files', array() );
		$missing = is_array( $missing ) ? $missing : array();

		if ( empty( $missing ) ) {
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'All plugin files present.', 'nvdigital-open-operator-system-oos' )
			);
		} else {
			$result['status'] = 'critical';
			/* translators: Plugin files missing from disk */
			$result['label']       = __( 'Plugin files missing', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'Some plugin files are missing from this installation (likely an incomplete update). Reinstall or update the plugin to restore them.', 'nvdigital-open-operator-system-oos' )
			);
			$result['actions']     = sprintf(
				'<p><code>%s</code></p>',
				implode( '</code>, <code>', array_map( 'esc_html', $missing ) )
			);
		}

		return $result;
	}

	/**
	 * Test API connectivity
	 *
	 * @return array Test result
	 */
	public function test_api_connectivity() {
		$result = array(
			'label'       => __( 'AI Provider API Connectivity', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'AI', 'nvdigital-open-operator-system-oos' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => 'wp_mcp_ai_api_connectivity',
		);

		// Get configured API providers from settings array.
		if ( ! class_exists( 'WP_MCP_AI_Admin_Settings' ) ) {
			$result['status']      = 'critical';
			$result['label']       = __( 'Settings class not available', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'The settings system is not yet initialized. This is normal during plugin activation.', 'nvdigital-open-operator-system-oos' )
			);
			return $result;
		}

		$settings   = WP_MCP_AI_Admin_Settings::get_settings();
		$openai_key = isset( $settings['openai_api_key'] ) ? $settings['openai_api_key'] : '';
		$gemini_key = isset( $settings['gemini_api_key'] ) ? $settings['gemini_api_key'] : '';
		$ollama_url = isset( $settings['ollama_endpoint_url'] ) ? $settings['ollama_endpoint_url'] : '';

		$providers_configured = 0;
		$providers_working    = 0;
		$issues               = array();

		// Test OpenAI.
		if ( ! empty( $openai_key ) ) {
			++$providers_configured;
			$openai_test = $this->test_openai_connection( $openai_key );
			if ( ! is_wp_error( $openai_test ) && $openai_test['success'] ) {
				++$providers_working;
			} else {
				/* translators: %s: OpenAI error message */
				$issues[] = sprintf( __( 'OpenAI: %s', 'nvdigital-open-operator-system-oos' ), is_wp_error( $openai_test ) ? $openai_test->get_error_message() : $openai_test['message'] );
			}
		}

		// Test Gemini.
		if ( ! empty( $gemini_key ) ) {
			++$providers_configured;
			$gemini_test = $this->test_gemini_connection( $gemini_key );
			if ( ! is_wp_error( $gemini_test ) && $gemini_test['success'] ) {
				++$providers_working;
			} else {
				/* translators: %s: Gemini error message */
				$issues[] = sprintf( __( 'Gemini: %s', 'nvdigital-open-operator-system-oos' ), is_wp_error( $gemini_test ) ? $gemini_test->get_error_message() : $gemini_test['message'] );
			}
		}

		// Test Ollama.
		if ( ! empty( $ollama_url ) ) {
			++$providers_configured;
			$ollama_test = $this->test_ollama_connection( $ollama_url );
			if ( ! is_wp_error( $ollama_test ) && $ollama_test['success'] ) {
				++$providers_working;
			} else {
				/* translators: %s: Ollama error message */
				$issues[] = sprintf( __( 'Ollama: %s', 'nvdigital-open-operator-system-oos' ), is_wp_error( $ollama_test ) ? $ollama_test->get_error_message() : $ollama_test['message'] );
			}
		}

		// Determine status.
		if ( 0 === $providers_configured ) {
			$result['status'] = 'critical';
			/* translators: No AI providers configured */
			$result['label']       = __( 'No AI providers configured', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'You need to configure at least one AI provider (OpenAI, Gemini, or Ollama) for the NV oOS plugin to function.', 'nvdigital-open-operator-system-oos' )
			);
			$result['actions']     = sprintf(
				'<p><a href="%s">%s</a></p>',
				esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard' ) ),
				__( 'Configure AI Providers', 'nvdigital-open-operator-system-oos' )
			);
		} elseif ( $providers_working === $providers_configured ) {
			$result['status'] = 'good';
			/* translators: %d: number of providers working */
			$result['label']       = sprintf( __( 'All %d AI providers are working', 'nvdigital-open-operator-system-oos' ), $providers_working );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'All configured AI providers are responding correctly.', 'nvdigital-open-operator-system-oos' )
			);
		} elseif ( $providers_working > 0 ) {
			$result['status'] = 'recommended';
			/* translators: 1: working providers, 2: total providers */
			$result['label']       = sprintf( __( '%1$d of %2$d AI providers are working', 'nvdigital-open-operator-system-oos' ), $providers_working, $providers_configured );
			$result['description'] = sprintf(
				'<p>%s</p><ul><li>%s</li></ul>',
				__( 'Some AI providers are experiencing issues:', 'nvdigital-open-operator-system-oos' ),
				implode( '</li><li>', array_map( 'esc_html', $issues ) )
			);
		} else {
			$result['status'] = 'critical';
			/* translators: Critical: No AI providers working */
			$result['label']       = __( 'No AI providers are working', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p><ul><li>%s</li></ul>',
				__( 'All configured AI providers are experiencing issues:', 'nvdigital-open-operator-system-oos' ),
				implode( '</li><li>', array_map( 'esc_html', $issues ) )
			);
			$result['actions']     = sprintf(
				'<p><a href="%s">%s</a></p>',
				esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard' ) ),
				__( 'Check AI Provider Settings', 'nvdigital-open-operator-system-oos' )
			);
		}

		return $result;
	}

	/**
	 * Test model availability
	 *
	 * @return array Test result
	 */
	public function test_model_availability() {
		$result = array(
			'label'       => __( 'AI Models Availability', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'AI', 'nvdigital-open-operator-system-oos' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => 'wp_mcp_ai_model_availability',
		);

		// Count available models.
		$available_models = array();

		// Get settings from settings array.
		if ( ! class_exists( 'WP_MCP_AI_Admin_Settings' ) ) {
			$result['status']      = 'critical';
			$result['label']       = __( 'Settings class not available', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'The settings system is not yet initialized. This is normal during plugin activation.', 'nvdigital-open-operator-system-oos' )
			);
			return $result;
		}

		$settings = WP_MCP_AI_Admin_Settings::get_settings();

		// Check OpenAI models.
		$openai_key = isset( $settings['openai_api_key'] ) ? $settings['openai_api_key'] : '';
		if ( ! empty( $openai_key ) ) {
			$available_models[] = 'OpenAI GPT';
		}

		// Check Gemini models.
		$gemini_key = isset( $settings['gemini_api_key'] ) ? $settings['gemini_api_key'] : '';
		if ( ! empty( $gemini_key ) ) {
			$available_models[] = 'Google Gemini';
		}

		// Check Ollama models.
		$ollama_url = isset( $settings['ollama_endpoint_url'] ) ? $settings['ollama_endpoint_url'] : '';
		if ( ! empty( $ollama_url ) ) {
			$available_models[] = 'Ollama (Local)';
		}

		if ( empty( $available_models ) ) {
			$result['status'] = 'critical';
			/* translators: No AI models available */
			$result['label']       = __( 'No AI models available', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'No AI models are currently available. Configure at least one AI provider.', 'nvdigital-open-operator-system-oos' )
			);
		} else {
			/* translators: %s: comma-separated list of available models */
			$result['label']       = sprintf( __( 'AI models available: %s', 'nvdigital-open-operator-system-oos' ), implode( ', ', $available_models ) );
			$result['description'] = sprintf(
				'<p>%s</p>',
				/* translators: %d: number of AI models */
				sprintf( __( 'You have %d AI model provider(s) configured and available.', 'nvdigital-open-operator-system-oos' ), count( $available_models ) )
			);
		}

		return $result;
	}

	/**
	 * Test credentials validation
	 *
	 * @return array Test result
	 */
	public function test_credentials() {
		$result = array(
			'label'       => __( 'Assistant Credentials', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'Security', 'nvdigital-open-operator-system-oos' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => 'wp_mcp_ai_credentials',
		);

		// Count assistants.
		$assistants = wp_count_posts( 'mcp_ai_assistant' );
		$total      = isset( $assistants->publish ) ? $assistants->publish : 0;

		// Count assistants with credentials.
		$args = array(
			'post_type'      => 'mcp_ai_assistant',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- meta_query required to query plugin-specific post meta; no alternative index-based query available.
				array(
					'key'     => '_wp_mcp_ai_credentials',
					'compare' => 'EXISTS',
				),
			),
		);

		$with_credentials = count( get_posts( $args ) );

		if ( $total > 0 ) {
			/* translators: 1: assistants with credentials, 2: total assistants */
			$result['label']       = sprintf( __( '%1$d of %2$d assistants have credentials', 'nvdigital-open-operator-system-oos' ), $with_credentials, $total );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'Credentials are securely hashed and stored.', 'nvdigital-open-operator-system-oos' )
			);
		} else {
			$result['status'] = 'recommended';
			/* translators: No assistants created */
			$result['label']       = __( 'No assistants created yet', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'Create AI assistants to start using the NV oOS plugin.', 'nvdigital-open-operator-system-oos' )
			);
			$result['actions']     = sprintf(
				'<p><a href="%s">%s</a></p>',
				esc_url( admin_url( 'post-new.php?post_type=mcp_ai_assistant' ) ),
				__( 'Create Assistant', 'nvdigital-open-operator-system-oos' )
			);
		}

		return $result;
	}

	/**
	 * Test tool functionality
	 *
	 * @return array Test result
	 */
	public function test_tool_functionality() {
		$result = array(
			'label'       => __( 'Tool Functionality', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'Tools', 'nvdigital-open-operator-system-oos' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => 'wp_mcp_ai_tool_functionality',
		);

		// Get tool registry - check if class exists first.
		if ( ! class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
			$result['status'] = 'recommended';
			/* translators: Tool registry not available */
			$result['label']       = __( 'Tool registry not yet available', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'The tool registry is initializing. This is normal during plugin activation.', 'nvdigital-open-operator-system-oos' )
			);
			return $result;
		}

		$registry = WP_MCP_AI_Tool_Registry::get_instance();
		if ( ! $registry ) {
			$result['status'] = 'critical';
			/* translators: Tool registry not initialized */
			$result['label']       = __( 'Tool registry not initialized', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'The tool registry failed to initialize. Check PHP error logs.', 'nvdigital-open-operator-system-oos' )
			);
			return $result;
		}

		$tools = $registry->get_tools();
		$count = is_array( $tools ) ? count( $tools ) : 0;

		if ( $count > 0 ) {
			/* translators: %d: number of tools */
			$result['label']       = sprintf( __( '%d tools available', 'nvdigital-open-operator-system-oos' ), $count );
			$result['description'] = sprintf(
				'<p>%s</p>',
				/* translators: %d: number of tools */
				sprintf( __( 'The tool registry has successfully loaded %d tools.', 'nvdigital-open-operator-system-oos' ), $count )
			);
		} else {
			$result['status'] = 'recommended';
			/* translators: No tools loaded */
			$result['label']       = __( 'No tools loaded', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'No tools are currently loaded. This may indicate a configuration issue.', 'nvdigital-open-operator-system-oos' )
			);
		}

		return $result;
	}

	/**
	 * Test MCP tool schema compliance (proposal 066).
	 *
	 * Runs the schema auditor over the registry and flags agent-client
	 * hazards (untyped roots, root combinators, bracket property names,
	 * prefixItems tuples, over-budget schemas, unbounded integer IDs).
	 * The audit is transient-cached for 15 minutes because walking the full
	 * registry JSON-encodes every schema.
	 *
	 * @return array Test result
	 */
	public function test_mcp_schema_compliance() {
		$result = array(
			'label'       => __( 'MCP Tool Schema Compliance', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'MCP', 'nvdigital-open-operator-system-oos' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => 'wp_mcp_ai_mcp_schema_compliance',
		);

		if ( ! class_exists( 'WP_MCP_AI_Tool_Schema_Auditor' ) ) {
			$result['status']      = 'recommended';
			$result['label']       = __( 'Schema auditor unavailable', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'The MCP schema auditor class is not loaded. This is normal during plugin activation.', 'nvdigital-open-operator-system-oos' )
			);
			return $result;
		}

		$summary = $this->get_schema_compliance_summary();

		if ( 0 === $summary['slugs_affected'] ) {
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'All tool schemas conform to the MCP agent-client hazard baseline.', 'nvdigital-open-operator-system-oos' )
			);
			return $result;
		}

		$result['status'] = 'recommended';
		/* translators: %d: number of affected tools */
		$result['label']       = sprintf( __( '%d tools with MCP schema hazards', 'nvdigital-open-operator-system-oos' ), $summary['slugs_affected'] );
		$result['description'] = sprintf(
			'<p>%s</p><ul>%s</ul>',
			__(
				'Some tool input schemas use shapes that specific agent clients (Claude Code, Codex) mishandle. The tools/list surface normalizes or skips them at runtime, but the tool authors should fix the schemas:',
				'nvdigital-open-operator-system-oos'
			),
			$this->render_schema_findings_list( $summary )
		);

		return $result;
	}

	/**
	 * Render the schema findings summary as an HTML list.
	 *
	 * @param array $summary Auditor summary from WP_MCP_AI_Tool_Schema_Auditor::summarize().
	 * @return string HTML list items.
	 */
	private function render_schema_findings_list( $summary ) {
		$labels = array(
			WP_MCP_AI_Tool_Schema_Auditor::FINDING_ROOT_TYPE_MISSING   => __( 'Missing root type', 'nvdigital-open-operator-system-oos' ),
			WP_MCP_AI_Tool_Schema_Auditor::FINDING_ROOT_COMBINATOR     => __( 'Root oneOf/anyOf next to properties', 'nvdigital-open-operator-system-oos' ),
			WP_MCP_AI_Tool_Schema_Auditor::FINDING_BRACKET_PROPERTY    => __( 'Bracketed property names', 'nvdigital-open-operator-system-oos' ),
			WP_MCP_AI_Tool_Schema_Auditor::FINDING_PREFIX_ITEMS        => __( 'prefixItems tuples', 'nvdigital-open-operator-system-oos' ),
			WP_MCP_AI_Tool_Schema_Auditor::FINDING_ENUM_IN_ANYOF_LARGE => __( 'Enum in combinator on large schema', 'nvdigital-open-operator-system-oos' ),
			WP_MCP_AI_Tool_Schema_Auditor::FINDING_OVER_BUDGET         => __( 'Schema over emit budget', 'nvdigital-open-operator-system-oos' ),
			WP_MCP_AI_Tool_Schema_Auditor::FINDING_UNSAFE_INTEGER      => __( 'Unbounded integer id/amount field', 'nvdigital-open-operator-system-oos' ),
			WP_MCP_AI_Tool_Schema_Auditor::FINDING_SLUG_TOO_LONG       => __( 'Tool slug over length limit', 'nvdigital-open-operator-system-oos' ),
		);

		$items = array();

		foreach ( $summary['counts'] as $code => $count ) {
			$label  = isset( $labels[ $code ] ) ? $labels[ $code ] : $code;
			$sample = isset( $summary['samples'][ $code ] ) ? $summary['samples'][ $code ] : array();

			$line = sprintf(
				/* translators: 1: finding label, 2: affected tool count, 3: sample slugs */
				__( '%1$s: %2$d tool(s)%3$s', 'nvdigital-open-operator-system-oos' ),
				esc_html( $label ),
				$count,
				! empty( $sample ) ? ' — ' . esc_html( implode( ', ', array_slice( $sample, 0, 5 ) ) ) : ''
			);

			$items[] = '<li>' . $line . '</li>';
		}

		return implode( '', $items );
	}

	/**
	 * Fetch (or compute, transient-cached) the schema compliance summary.
	 *
	 * @return array Auditor summary.
	 */
	private function get_schema_compliance_summary() {
		$cached = get_transient( 'wp_mcp_ai_schema_compliance_summary' );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$summary = WP_MCP_AI_Tool_Schema_Auditor::summarize(
			WP_MCP_AI_Tool_Schema_Auditor::audit_registry()
		);

		set_transient( 'wp_mcp_ai_schema_compliance_summary', $summary, 15 * MINUTE_IN_SECONDS );

		return $summary;
	}

	/**
	 * Test database schema
	 *
	 * @return array Test result
	 */
	public function test_database_schema() {
		$result = array(
			'label'       => __( 'Database Schema', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'Database', 'nvdigital-open-operator-system-oos' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => 'wp_mcp_ai_database_schema',
		);

		global $wpdb;

		// Check if assistant post type is registered.
		$post_type_exists = post_type_exists( 'mcp_ai_assistant' );

		if ( ! $post_type_exists ) {
			$result['status'] = 'critical';
			/* translators: Assistant post type not registered */
			$result['label']       = __( 'Assistant post type not registered', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'The mcp_ai_assistant post type is not registered. Plugin may not be activated correctly.', 'nvdigital-open-operator-system-oos' )
			);
			return $result;
		}

		// Check for required options. The plugin persists its installed
		// version under `wp_mcp_ai_activated_version` (written on every
		// activation by wp_mcp_ai_activate_single_site()); the legacy
		// `wp_mcp_ai_version` / `wp_mcp_ai_tool_registry` option names
		// were never written by any release and produced false positives.
		$required_options = array(
			'wp_mcp_ai_activated_version',
		);

		$missing_options = array();
		foreach ( $required_options as $option ) {
			if ( false === get_option( $option ) ) {
				$missing_options[] = $option;
			}
		}

		if ( ! empty( $missing_options ) ) {
			$result['status'] = 'recommended';
			/* translators: Some database options missing */
			$result['label']       = __( 'Some database options missing', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p><ul><li>%s</li></ul>',
				__( 'The following options are not set:', 'nvdigital-open-operator-system-oos' ),
				implode( '</li><li>', array_map( 'esc_html', $missing_options ) )
			);
		} else {
			$result['label']       = __( 'Database schema is correct', 'nvdigital-open-operator-system-oos' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'All required post types and options are present.', 'nvdigital-open-operator-system-oos' )
			);
		}

		return $result;
	}

	/**
	 * Get debug fields
	 *
	 * @return array Debug fields
	 */
	private function get_debug_fields() {
		$fields = array();

		// Plugin version.
		$fields['version'] = array(
			'label' => __( 'Plugin Version', 'nvdigital-open-operator-system-oos' ),
			'value' => defined( 'WP_MCP_AI_VERSION' ) ? WP_MCP_AI_VERSION : __( 'Unknown', 'nvdigital-open-operator-system-oos' ),
		);

		// Base version mode.
		$fields['base_version'] = array(
			'label' => __( 'Base Version Mode', 'nvdigital-open-operator-system-oos' ),
			'value' => defined( 'WP_MCP_AI_BASE_VERSION' ) && WP_MCP_AI_BASE_VERSION ? __( 'Yes', 'nvdigital-open-operator-system-oos' ) : __( 'No', 'nvdigital-open-operator-system-oos' ),
		);

		// Configured providers.
		$providers = array();
		if ( class_exists( 'WP_MCP_AI_Admin_Settings' ) ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			if ( ! empty( $settings['openai_api_key'] ) ) {
				$providers[] = 'OpenAI';
			}
			if ( ! empty( $settings['gemini_api_key'] ) ) {
				$providers[] = 'Google Gemini';
			}
			if ( ! empty( $settings['ollama_endpoint_url'] ) ) {
				$providers[] = 'Ollama';
			}
		}

		$fields['providers'] = array(
			'label' => __( 'Configured Providers', 'nvdigital-open-operator-system-oos' ),
			'value' => ! empty( $providers ) ? implode( ', ', $providers ) : __( 'None', 'nvdigital-open-operator-system-oos' ),
		);

		// Assistant count.
		$assistants                = wp_count_posts( 'mcp_ai_assistant' );
		$fields['assistant_count'] = array(
			'label' => __( 'Assistants Created', 'nvdigital-open-operator-system-oos' ),
			'value' => isset( $assistants->publish ) ? $assistants->publish : 0,
		);

		// Tool count - check if class exists and registry is initialized.
		$tool_count = 0;
		if ( class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
			$registry   = WP_MCP_AI_Tool_Registry::get_instance();
			$tools      = $registry ? $registry->get_tools() : array();
			$tool_count = is_array( $tools ) ? count( $tools ) : 0;
		}
		$fields['tool_count'] = array(
			'label' => __( 'Tools Available', 'nvdigital-open-operator-system-oos' ),
			'value' => $tool_count,
		);

		// MCP schema compliance summary (proposal 066).
		$schema_summary                  = $this->get_schema_compliance_summary();
		$fields['mcp_schema_compliance'] = array(
			'label' => __( 'MCP Tool Schema Compliance', 'nvdigital-open-operator-system-oos' ),
			'value' => 0 === $schema_summary['slugs_affected']
				? __( 'No hazards', 'nvdigital-open-operator-system-oos' )
				: sprintf(
					/* translators: 1: affected tool count, 2: finding code counts */
					__( '%1$d tool(s) affected: %2$s', 'nvdigital-open-operator-system-oos' ),
					$schema_summary['slugs_affected'],
					wp_json_encode( $schema_summary['counts'] )
				),
		);

		// JetEngine integration.
		$fields['jetengine'] = array(
			'label' => __( 'JetEngine Integration', 'nvdigital-open-operator-system-oos' ),
			'value' => class_exists( 'Jet_Engine' ) ? __( 'Active', 'nvdigital-open-operator-system-oos' ) : __( 'Inactive', 'nvdigital-open-operator-system-oos' ),
		);

		// WooCommerce integration.
		$fields['woocommerce'] = array(
			'label' => __( 'WooCommerce Integration', 'nvdigital-open-operator-system-oos' ),
			'value' => class_exists( 'WooCommerce' ) ? __( 'Active', 'nvdigital-open-operator-system-oos' ) : __( 'Inactive', 'nvdigital-open-operator-system-oos' ),
		);

		// Elementor integration.
		$fields['elementor'] = array(
			'label' => __( 'Elementor Integration', 'nvdigital-open-operator-system-oos' ),
			'value' => defined( 'ELEMENTOR_VERSION' ) ? __( 'Active', 'nvdigital-open-operator-system-oos' ) : __( 'Inactive', 'nvdigital-open-operator-system-oos' ),
		);

		// Debug mode.
		$fields['debug_mode'] = array(
			'label' => __( 'Debug Mode', 'nvdigital-open-operator-system-oos' ),
			'value' => ( defined( 'WP_MCP_AI_DEBUG' ) && WP_MCP_AI_DEBUG ) ? __( 'Enabled', 'nvdigital-open-operator-system-oos' ) : __( 'Disabled', 'nvdigital-open-operator-system-oos' ),
		);

		// Logging.
		$fields['logging'] = array(
			'label' => __( 'Logging Enabled', 'nvdigital-open-operator-system-oos' ),
			'value' => get_option( 'wp_mcp_ai_enable_logging' ) ? __( 'Yes', 'nvdigital-open-operator-system-oos' ) : __( 'No', 'nvdigital-open-operator-system-oos' ),
		);

		return $fields;
	}

	/**
	 * Test OpenAI connection
	 *
	 * @param string $api_key API key.
	 * @return array Test result with success and message
	 */
	private function test_openai_connection( $api_key ) {
		// Simple connectivity test - check if API key format is valid.
		// Full API test would require making actual API call.
		if ( empty( $api_key ) || strlen( $api_key ) < 20 ) {
			return new WP_Error( 'wp_mcp_ai_error', __( 'Invalid API key format', 'nvdigital-open-operator-system-oos' ) );
		}

		return array(
			'success' => true,
			'message' => __( 'API key configured', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * Test Gemini connection
	 *
	 * @param string $api_key API key.
	 * @return array Test result with success and message
	 */
	private function test_gemini_connection( $api_key ) {
		// Simple connectivity test - check if API key format is valid.
		if ( empty( $api_key ) || strlen( $api_key ) < 20 ) {
			return new WP_Error( 'wp_mcp_ai_error', __( 'Invalid API key format', 'nvdigital-open-operator-system-oos' ) );
		}

		return array(
			'success' => true,
			'message' => __( 'API key configured', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * Test Ollama connection
	 *
	 * @param string $url Ollama URL.
	 * @return array Test result with success and message
	 */
	private function test_ollama_connection( $url ) {
		// Simple connectivity test - check if URL format is valid.
		if ( empty( $url ) || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return new WP_Error( 'wp_mcp_ai_error', __( 'Invalid URL format', 'nvdigital-open-operator-system-oos' ) );
		}

		return array(
			'success' => true,
			'message' => __( 'URL configured', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * Test cache backend configuration.
	 *
	 * Checks whether a persistent object cache (Redis/Memcached) is active.
	 * A persistent cache is recommended for production deployments to avoid
	 * wp_options autoload bloat and cache divergence across nodes.
	 *
	 * @since 1.1.37
	 * @return array Test result.
	 */
	public function test_cache_backend() {
		$using_ext_cache = wp_using_ext_object_cache();

		if ( $using_ext_cache ) {
			$backend = 'unknown';
			global $wp_object_cache;

			if ( $wp_object_cache && method_exists( $wp_object_cache, 'redis_instance' ) ) {
				$backend = 'Redis';
			} elseif ( $wp_object_cache && method_exists( $wp_object_cache, 'get_mc' ) ) {
				$backend = 'Memcached';
			}

			return array(
				'label'       => __( 'Persistent object cache is active', 'nvdigital-open-operator-system-oos' ),
				'status'      => 'good',
				'badge'       => array(
					'label' => __( 'Performance', 'nvdigital-open-operator-system-oos' ),
					'color' => 'green',
				),
				'description' => sprintf(
					'<p>%s</p>',
					sprintf(
						/* translators: %s: cache backend name */
						__( 'NV oOS is using %s for object caching. Transients and cache entries are stored outside wp_options, reducing database load and preventing cache divergence in multi-server deployments.', 'nvdigital-open-operator-system-oos' ),
						'<strong>' . esc_html( $backend ) . '</strong>'
					)
				),
				'test'        => 'wp_mcp_ai_cache_backend',
			);
		}

		return array(
			'label'       => __( 'No persistent object cache detected', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'recommended',
			'badge'       => array(
				'label' => __( 'Performance', 'nvdigital-open-operator-system-oos' ),
				'color' => 'orange',
			),
			'description' => sprintf(
				'<p>%s</p><p>%s</p>',
				__( 'NV oOS is using the WordPress database (wp_options) for object caching. This is acceptable for development but may cause performance issues under concurrent load in production.', 'nvdigital-open-operator-system-oos' ),
				sprintf(
					/* translators: %s: link to Cloudways Redis documentation */
					__( 'If you are on Cloudways, Redis can be enabled with one click in Server Settings &rarr; Packages. For other hosts, install a Redis object cache plugin. %s', 'nvdigital-open-operator-system-oos' ),
					'<a href="https://support.cloudways.com/en/articles/5120689-how-to-manage-your-server-settings" target="_blank">' . esc_html__( 'Cloudways Redis Guide', 'nvdigital-open-operator-system-oos' ) . '</a>'
				)
			),
			'test'        => 'wp_mcp_ai_cache_backend',
		);
	}

	/**
	 * Test queue storage engine.
	 *
	 * Checks whether the Job Queue Manager and Dead Letter Queue are using
	 * custom DB tables (v1.1.37+) or the legacy wp_options storage.
	 *
	 * @since 1.1.37
	 * @return array Test result.
	 */
	public function test_queue_storage() {
		$issues = array();

		// Check Dead Letter Queue storage.
		if ( class_exists( 'WP_MCP_AI_Dead_Letter_Queue' ) ) {
			if ( ! method_exists( 'WP_MCP_AI_Dead_Letter_Queue', 'create_table' ) ) {
				$issues[] = __( 'Dead Letter Queue is using wp_options storage (upgrade recommended).', 'nvdigital-open-operator-system-oos' );
			}
		}

		// Check Job Queue Manager storage.
		if ( class_exists( 'WP_MCP_AI_Job_Queue_Manager' ) ) {
			if ( ! method_exists( 'WP_MCP_AI_Job_Queue_Manager', 'create_table' ) ) {
				$issues[] = __( 'Job Queue Manager is using wp_options storage (upgrade recommended).', 'nvdigital-open-operator-system-oos' );
			}
		}

		if ( empty( $issues ) ) {
			return array(
				'label'       => __( 'Queue storage uses custom database tables', 'nvdigital-open-operator-system-oos' ),
				'status'      => 'good',
				'badge'       => array(
					'label' => __( 'Performance', 'nvdigital-open-operator-system-oos' ),
					'color' => 'green',
				),
				'description' => sprintf(
					'<p>%s</p>',
					__( 'Job queue and dead letter queue are using dedicated database tables with row-level locking. This prevents data corruption under concurrent writes and allows horizontal worker scaling.', 'nvdigital-open-operator-system-oos' )
				),
				'test'        => 'wp_mcp_ai_queue_storage',
			);
		}

		return array(
			'label'       => __( 'Queue storage can be improved', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'recommended',
			'badge'       => array(
				'label' => __( 'Performance', 'nvdigital-open-operator-system-oos' ),
				'color' => 'orange',
			),
			'description' => sprintf(
				'<p>%s</p><ul><li>%s</li></ul>',
				__( 'Some queue components are using wp_options for storage, which is not safe for concurrent access:', 'nvdigital-open-operator-system-oos' ),
				implode( '</li><li>', array_map( 'esc_html', $issues ) )
			),
			'test'        => 'wp_mcp_ai_queue_storage',
		);
	}

	/**
	 * Test: check if DISABLE_WP_CRON is configured for production.
	 *
	 * @since 1.2.0
	 * @return array Test result.
	 */
	public function test_cron_configuration() {
		$result = array(
			'label'       => __( 'Cron Configuration', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'Performance', 'nvdigital-open-operator-system-oos' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => 'wp_mcp_ai_cron_configuration',
		);

		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
			$result['description'] = '<p>' . esc_html__( 'DISABLE_WP_CRON is enabled. Background tasks will run reliably via system cron.', 'nvdigital-open-operator-system-oos' ) . '</p>';
		} else {
			$result['status']      = 'recommended';
			$result['label']       = __( 'DISABLE_WP_CRON is not set', 'nvdigital-open-operator-system-oos' );
			$result['description'] = '<p>' . esc_html__( 'NV oOS uses WordPress cron for background AI tasks. Without a system cron, tasks rely on site traffic to trigger. Add define( DISABLE_WP_CRON, true ) to wp-config.php and set up a system cron job.', 'nvdigital-open-operator-system-oos' ) . '</p>';
		}

		return $result;
	}

	/**
	 * Test: check core security posture indicators.
	 *
	 * @since 1.2.0
	 * @return array Test result.
	 */
	public function test_security_posture() {
		$result = array(
			'label'       => __( 'Security Posture', 'nvdigital-open-operator-system-oos' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'Security', 'nvdigital-open-operator-system-oos' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => '',
			'test'        => 'wp_mcp_ai_security_posture',
		);

		$issues = array();

		// Encryption key.
		if ( empty( get_option( 'wp_mcp_ai_master_key', '' ) ) ) {
			$issues[] = __( 'Encryption master key not set.', 'nvdigital-open-operator-system-oos' );
		}

		// Webhook secret.
		$secret = function_exists( 'wp_mcp_ai_get_api_key' )
			? wp_mcp_ai_get_api_key( 'webhook_secret', '' )
			: get_option( 'wp_mcp_ai_webhook_secret', '' );
		if ( empty( $secret ) ) {
			$issues[] = __( 'Webhook HMAC secret not configured.', 'nvdigital-open-operator-system-oos' );
		}

		if ( ! empty( $issues ) ) {
			$result['status']      = 'recommended';
			$result['label']       = __( 'Security improvements recommended', 'nvdigital-open-operator-system-oos' );
			$result['description'] = '<ul><li>' . implode( '</li><li>', array_map( 'esc_html', $issues ) ) . '</li></ul>';
		} else {
			$result['description'] = '<p>' . esc_html__( 'Core security measures are configured.', 'nvdigital-open-operator-system-oos' ) . '</p>';
		}

		return $result;
	}
}
