<?php
/**
 * Tool that retrieves product data from Flowhub API.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent parse errors on PHP < 7.4 by exiting before class definition.
if ( version_compare( PHP_VERSION, '7.4.0', '<' ) ) {
	return;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';

// Guard the client require so a missing/corrupt install (e.g. incomplete
// update) degrades to "tool unavailable" instead of fataling the whole site.
if ( file_exists( WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-flowhub-client.php' ) ) {
	require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-flowhub-client.php';
}
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-logger.php';

/**
 * Provides a tool for retrieving product catalog from Flowhub.
 */
class WP_MCP_AI_Tool_Flowhub_Get_Products implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Tool_Product_Card;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'flowhub_get_products';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Flowhub Get Products', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Retrieve cannabis product catalog from Flowhub including strains, concentrates, edibles, accessories with pricing, descriptions, THC/CBD content, and compliance information. Supports category filtering and pagination.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Browsing the Flowhub catalog: strains, concentrates, edibles, pricing, and THC/CBD content.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Current stock levels or catalog writes; use flowhub_get_inventory or flowhub_manage_product.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'flowhub_get_inventory', 'flowhub_manage_product' ),
			'notes'           => __( 'Filter by category such as flower, concentrate, or edible; paginate with limit and offset.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'connection_id' => array(
					'type'        => 'string',
					'description' => __( 'Optional Remote Sites connection ID for Flowhub (conn_...). Omit to auto-resolve: toolkit settings credentials, then the configured sync connections, then the first enabled FlowHub connection.', 'nvdigital-open-operator-system-oos' ),
				),
				'limit'         => array(
					'type'        => 'integer',
					'description' => __( 'Maximum number of products to retrieve (1-100).', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 1,
					'maximum'     => 100,
					'default'     => 20,
				),
				'offset'        => array(
					'type'        => 'integer',
					'description' => __( 'Number of products to skip for pagination.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 0,
					'default'     => 0,
				),
				'category'      => array(
					'type'        => 'string',
					'description' => __( 'Filter by product category (e.g., "flower", "concentrate", "edible", "accessories").', 'nvdigital-open-operator-system-oos' ),
				),
				'timeout'       => array(
					'type'        => 'integer',
					'description' => __( 'Request timeout in seconds (5-60).', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 5,
					'maximum'     => 60,
					'default'     => 30,
				),
			),
			'required'             => array(),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Check whether the tool can be registered.
	 *
	 * @since 1.1.22
	 * @return bool
	 */
	public static function is_available() {
		return class_exists( 'WP_MCP_AI_Flowhub_Client' );
	}

	/**
	 * Provide a message explaining why the tool is unavailable.
	 *
	 * @since 1.1.22
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'Flowhub client is not available. The Flowhub integration requires API credentials to be configured.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id   = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : 0;
		$has_token = ! empty( $context['token_authenticated'] );

		if ( ! $user_id && ! $has_token ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You must be authenticated to retrieve Flowhub products.', 'nvdigital-open-operator-system-oos' ), array( 'status' => rest_authorization_required_code() ) );
		}

		if ( $user_id ) {
			// TMA storefront: subscribers only need the 'read' capability.
			$is_tma = isset( $context['source'] ) && 'telegram_mini_app' === $context['source'];
			if ( $is_tma ) {
				if ( ! user_can( $user_id, 'read' ) ) {
					return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to retrieve product data.', 'nvdigital-open-operator-system-oos' ) );
				}
			} elseif ( ! user_can( $user_id, 'manage_woocommerce' ) && ! user_can( $user_id, 'manage_options' ) ) {
				return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to retrieve product data.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
				return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
			}
		}

		// Resolve the target FlowHub connection: explicit argument, settings
		// credentials, configured sync connections, or the first enabled
		// FlowHub connection in Remote Sites.
		if ( ! class_exists( 'WP_MCP_AI_FlowHub_Connection_Helper' ) ) {
			$helper_file = WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-flowhub-connection-helper.php';
			if ( file_exists( $helper_file ) ) {
				require_once $helper_file;
			}
		}
		if ( ! class_exists( 'WP_MCP_AI_FlowHub_Connection_Helper' ) ) {
			return new WP_Error(
				'wp_mcp_ai_flowhub_helper_missing',
				__( 'The Flowhub connection helper is not available on this site.', 'nvdigital-open-operator-system-oos' )
			);
		}
		$connection_id = isset( $arguments['connection_id'] ) ? sanitize_key( $arguments['connection_id'] ) : null;
		$resolved      = WP_MCP_AI_FlowHub_Connection_Helper::resolve_connection( $connection_id );

		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		$connection_id = $resolved['connection_id'];
		$client_id     = $resolved['credentials']['client_id'];
		$api_key       = $resolved['credentials']['api_key'];
		$location_id   = $resolved['credentials']['location_id'];

		// Use the base client class, passing connection_id for lazy credential resolution.
		if ( ! class_exists( 'WP_MCP_AI_Flowhub_Client' ) ) {
			$client_file = WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-flowhub-client.php';
			if ( file_exists( $client_file ) ) {
				require_once $client_file;
			}
		}
		if ( ! class_exists( 'WP_MCP_AI_Flowhub_Client' ) ) {
			return new WP_Error(
				'wp_mcp_ai_flowhub_client_missing',
				__( 'The Flowhub client is not available on this site.', 'nvdigital-open-operator-system-oos' )
			);
		}
		$client  = new WP_MCP_AI_Flowhub_Client( $connection_id );
		$options = array();

		if ( isset( $arguments['limit'] ) ) {
			$options['limit'] = max( 1, min( 100, absint( $arguments['limit'] ) ) );
		}
		if ( isset( $arguments['offset'] ) ) {
			$options['offset'] = max( 0, absint( $arguments['offset'] ) );
		}
		if ( isset( $arguments['category'] ) ) {
			$options['category'] = sanitize_text_field( $arguments['category'] );
		}
		if ( isset( $arguments['timeout'] ) ) {
			$options['timeout'] = max( 5, min( 60, absint( $arguments['timeout'] ) ) );
		}

		$result = $client->get_products( $options );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Add summary for frontend display.
		$summary = __( 'Retrieved products from Flowhub', 'nvdigital-open-operator-system-oos' );
		if ( isset( $result['total'] ) ) {
			$summary = sprintf(
				/* translators: %d: number of products */
				__( 'Retrieved %d products from Flowhub', 'nvdigital-open-operator-system-oos' ),
				absint( $result['total'] )
			);
		}

		// Generate rich product cards for chat display.
		$products_data = isset( $result['products'] ) ? $result['products'] : ( isset( $result['data'] ) ? $result['data'] : array() );
		if ( ! empty( $products_data ) && is_array( $products_data ) ) {
			$cards_message = $this->format_product_cards( $products_data, 'flowhub' );
			if ( ! empty( $cards_message ) ) {
				$summary .= "\n\n" . $cards_message;
			}
		}

		$result = array_merge(
			array(
				'message' => $summary,
				'summary' => $summary,
			),
			$result
		);

		/**
		 * Allow third parties to filter the Flowhub products result.
		 *
		 * @param array $result    Final response payload.
		 * @param array $arguments Original tool arguments.
		 * @param array $context   Invocation context.
		 */
		$result = apply_filters( 'wp_mcp_ai_flowhub_get_products_result', $result, $arguments, $context );

		return $result;
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'ecommerce_business',

			'pattern_compatibility' => array( 'orchestrator' ),

			'profession_tags'       => array( 'product_manager', 'ecommerce_manager' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro tier tool.
			'external-api',         // Makes external API calls.
			'requires-credentials', // Requires Flowhub API credentials.
			'requires-capability',  // Requires user capabilities.
			'read-only',            // Only reads data, does not modify state.
			'rate-limited',         // Subject to Flowhub API rate limits.
			'paginated',            // Supports pagination.
		);
	}
}
