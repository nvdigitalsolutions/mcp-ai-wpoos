<?php
/**
 * Tool that retrieves ReliefWeb reports filtered by country or disaster type.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Queries the ReliefWeb API for recent humanitarian reports.
 */
class WP_MCP_AI_Tool_ReliefWeb_Reports implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * Base endpoint for ReliefWeb report searches.
	 */
	const ENDPOINT = 'https://api.reliefweb.int/v1/reports';

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'reliefweb_reports';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'ReliefWeb Reports', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Searches the ReliefWeb humanitarian dataset for recent reports filtered by country or disaster type.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Humanitarian situational research: recent ReliefWeb reports filtered by country or disaster type.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Live disaster alerts or general news; use get_gdacs_events for alerts and web_search for broader coverage.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'get_gdacs_events', 'web_search' ),
			'notes'           => __( 'Queries the ReliefWeb v1 reports API; apply country and disaster_type filters to keep results focused.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'country'       => array(
					'type'        => 'string',
					'description' => __( 'Optional country name to filter by (for example, Jamaica).', 'nvdigital-open-operator-system-oos' ),
				),
				'disaster_type' => array(
					'type'        => 'string',
					'description' => __( 'Optional disaster type to filter by (for example, Storm).', 'nvdigital-open-operator-system-oos' ),
				),
				'search'        => array(
					'type'        => 'string',
					'description' => __( 'Optional keyword search applied across report titles and body content.', 'nvdigital-open-operator-system-oos' ),
				),
				'limit'         => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'maximum'     => 50,
					'default'     => 10,
					'description' => __( 'Maximum number of reports to return (1-50).', 'nvdigital-open-operator-system-oos' ),
				),
				'sort'          => array(
					'type'        => 'string',
					'enum'        => array( 'date:desc', 'date:asc' ),
					'default'     => 'date:desc',
					'description' => __( 'Sort order for the ReliefWeb API (newest first by default).', 'nvdigital-open-operator-system-oos' ),
				),
			),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'read' ) ) {
			return new WP_Error( 'wp_mcp_ai_reliefweb_forbidden', __( 'You do not have permission to search ReliefWeb reports.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_reliefweb_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		$country       = isset( $arguments['country'] ) ? sanitize_text_field( $arguments['country'] ) : '';
		$disaster_type = isset( $arguments['disaster_type'] ) ? sanitize_text_field( $arguments['disaster_type'] ) : '';
		$search_term   = isset( $arguments['search'] ) ? sanitize_text_field( $arguments['search'] ) : '';

		if ( '' === $country && '' === $disaster_type ) {
			return new WP_Error( 'wp_mcp_ai_reliefweb_missing_filter', __( 'Provide at least a country or disaster type to search ReliefWeb reports.', 'nvdigital-open-operator-system-oos' ) );
		}

		$limit = isset( $arguments['limit'] ) ? absint( $arguments['limit'] ) : 10;

		if ( $limit <= 0 ) {
			$limit = 10;
		}

		$limit = min( $limit, 50 );

		$sort = isset( $arguments['sort'] ) ? sanitize_text_field( $arguments['sort'] ) : 'date:desc';
		if ( ! in_array( $sort, array( 'date:desc', 'date:asc' ), true ) ) {
			$sort = 'date:desc';
		}

		$payload = array(
			'limit'  => $limit,
			'sort'   => array( $sort ),
			'fields' => array(
				'include' => array( 'title', 'url', 'url_alias', 'date', 'country', 'disaster_type', 'source' ),
			),
		);

		$conditions = array();

		if ( '' !== $country ) {
			$conditions[] = array(
				'field' => 'country.name',
				'value' => $country,
			);
		}

		if ( '' !== $disaster_type ) {
			$conditions[] = array(
				'field' => 'disaster_type',
				'value' => $disaster_type,
			);
		}

		if ( ! empty( $conditions ) ) {
			$payload['filter'] = array(
				'conditions' => $conditions,
			);

			if ( count( $conditions ) > 1 ) {
				$payload['filter']['operator'] = 'OR';
			}
		}

		if ( '' !== $search_term ) {
			$payload['query'] = array(
				'value'  => $search_term,
				'fields' => array( 'title', 'body', 'country.name' ),
			);
		}

		$payload = apply_filters( 'wp_mcp_ai_reliefweb_request_payload', $payload, $arguments, $context );

		$appname = apply_filters( 'wp_mcp_ai_reliefweb_appname', 'nvdigital-open-operator-system-oos', $arguments, $context );
		$appname = sanitize_text_field( $appname );

		if ( '' === $appname ) {
			$appname = 'nvdigital-open-operator-system-oos';
		}

		$query_args = array(
			'appname' => $appname,
			'profile' => 'full',
		);

		// add_query_arg() does not URL-encode values (build_query() passes
		// $urlencode=false); the appname is filterable, so encode explicitly
		// with RFC 1738.
		$query_string = http_build_query( $query_args, '', '&', PHP_QUERY_RFC1738 );
		$request_url  = self::ENDPOINT . ( false === strpos( self::ENDPOINT, '?' ) ? '?' : '&' ) . $query_string;

		$timeout = (int) apply_filters( 'wp_mcp_ai_reliefweb_timeout', 15, $arguments, $context );
		if ( $timeout < 5 ) {
			$timeout = 5;
		}

		$response = wp_remote_post(
			$request_url,
			array(
				'timeout' => $timeout,
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'wp_mcp_ai_reliefweb_http_error',
				__( 'The ReliefWeb request failed.', 'nvdigital-open-operator-system-oos' ),
				$response
			);
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status_code ) {
			return new WP_Error(
				'wp_mcp_ai_reliefweb_bad_status',
				sprintf(
					/* translators: %d: HTTP status code. */
					__( 'ReliefWeb returned an unexpected HTTP status: %d.', 'nvdigital-open-operator-system-oos' ),
					$status_code
				),
				array(
					'status' => $status_code,
					'body'   => wp_remote_retrieve_body( $response ),
				)
			);
		}

		$body    = wp_remote_retrieve_body( $response );
		$decoded = json_decode( $body, true );

		if ( null === $decoded || ! is_array( $decoded ) ) {
			return new WP_Error( 'wp_mcp_ai_reliefweb_bad_json', __( 'The ReliefWeb response could not be decoded.', 'nvdigital-open-operator-system-oos' ) );
		}

		$results = array();

		if ( ! empty( $decoded['data'] ) && is_array( $decoded['data'] ) ) {
			foreach ( $decoded['data'] as $item ) {
				if ( empty( $item['fields'] ) || ! is_array( $item['fields'] ) ) {
					continue;
				}

				$fields = $item['fields'];

				$countries = array();
				if ( ! empty( $fields['country'] ) && is_array( $fields['country'] ) ) {
					foreach ( $fields['country'] as $country_item ) {
						if ( ! empty( $country_item['name'] ) ) {
							$countries[] = sanitize_text_field( $country_item['name'] );
						}
					}
				}

				$disasters = array();
				if ( ! empty( $fields['disaster_type'] ) && is_array( $fields['disaster_type'] ) ) {
					foreach ( $fields['disaster_type'] as $disaster_item ) {
						if ( ! empty( $disaster_item['name'] ) ) {
							$disasters[] = sanitize_text_field( $disaster_item['name'] );
						}
					}
				}

				$sources = array();
				if ( ! empty( $fields['source'] ) && is_array( $fields['source'] ) ) {
					foreach ( $fields['source'] as $source_item ) {
						if ( ! empty( $source_item['name'] ) ) {
							$sources[] = sanitize_text_field( $source_item['name'] );
						}
					}
				}

				$report_url = '';
				if ( ! empty( $fields['url_alias'] ) ) {
					$report_url = esc_url_raw( $fields['url_alias'] );
				} elseif ( ! empty( $fields['url'] ) ) {
					$report_url = esc_url_raw( $fields['url'] );
				} elseif ( ! empty( $item['href'] ) ) {
					$report_url = esc_url_raw( $item['href'] );
				}

				$date_original = '';
				if ( ! empty( $fields['date']['original'] ) ) {
					$date_original = sanitize_text_field( $fields['date']['original'] );
				} elseif ( ! empty( $fields['date']['created'] ) ) {
					$date_original = sanitize_text_field( $fields['date']['created'] );
				}

				$results[] = array_filter(
					array(
						'id'             => isset( $item['id'] ) ? sanitize_text_field( $item['id'] ) : '',
						'title'          => isset( $fields['title'] ) ? sanitize_text_field( $fields['title'] ) : '',
						'url'            => $report_url,
						'countries'      => $countries,
						'disaster_types' => $disasters,
						'sources'        => $sources,
						'published_at'   => $date_original,
					)
				);
			}
		}

		$summary_text = sprintf(
			/* translators: %d: number of reports found */
			__( 'Found %d ReliefWeb report(s)', 'nvdigital-open-operator-system-oos' ),
			isset( $decoded['count'] ) ? (int) $decoded['count'] : count( $results )
		);

		return array(
			'message'  => $summary_text,
			'summary'  => $summary_text,
			'filters'  => array_filter(
				array(
					'country'       => $country,
					'disaster_type' => $disaster_type,
					'search'        => $search_term,
					'sort'          => $sort,
					'limit'         => $limit,
				)
			),
			'total'    => isset( $decoded['totalCount'] ) ? (int) $decoded['totalCount'] : null,
			'returned' => isset( $decoded['count'] ) ? (int) $decoded['count'] : count( $results ),
			'results'  => $results,
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'geospatial_location',

			'pattern_compatibility' => array( 'event_driven' ),

			'profession_tags'       => array( 'disaster_response_coordinator', 'humanitarian_worker' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',            // Only reads data, does not modify state.
			'external-api',         // Makes external API calls to ReliefWeb.
			'requires-capability',  // Requires user capabilities.
		);
	}
}
