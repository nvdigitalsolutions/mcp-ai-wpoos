<?php
/**
 * Async Job Queue Manager
 *
 * Manages background job execution for commands, workflows, and agentic loops.
 * Integrates with chat-client for real-time updates and supports unlimited iterations.
 *
 * @package WP_MCP_AI
 * @since 2.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Async_Job_Queue' ) ) {
	/**
	 * Async Job Queue Manager Class
	 *
	 * Provides a unified queue system for:
	 * - Slash command execution
	 * - Workflow orchestration
	 * - Tool execution
	 * - Long-running agentic loops
	 *
	 * Features:
	 * - Priority-based scheduling (urgent, high, normal, low, batch)
	 * - Job state management (queued, running, paused, completed, failed)
	 * - Progress tracking (0-100%)
	 * - Resource-aware execution
	 * - Retry logic with exponential backoff
	 * - Dead letter queue integration
	 * - SSE streaming for real-time updates
	 * - Webhook notifications
	 *
	 * @since 2.0.0
	 */
	class WP_MCP_AI_Async_Job_Queue {
		/**
		 * Database table name (without prefix).
		 *
		 * @var string
		 */
		const TABLE_NAME = 'mcp_ai_job_queue';

		/**
		 * Database schema version for the job queue table.
		 *
		 * Bump when the table structure changes so `maybe_create_table()`
		 * re-runs dbDelta on the next page load.
		 *
		 * @var string
		 */
		const DB_VERSION = '1.0.0';

		/**
		 * Flag tracking whether the custom table is available.
		 *
		 * @var bool|null
		 */
		private static $table_exists = null;

		/**
		 * Job priority levels.
		 */
		const PRIORITY_URGENT = 1; // Real-time (< 1s).
		const PRIORITY_HIGH   = 2; // Interactive (< 5s).
		const PRIORITY_NORMAL = 3; // Standard (< 30s).
		const PRIORITY_LOW    = 4; // Background (< 5min).
		const PRIORITY_BATCH  = 5; // Non-urgent (> 30min).

		/**
		 * Job statuses.
		 */
		const STATUS_QUEUED    = 'queued';
		const STATUS_RUNNING   = 'running';
		const STATUS_PAUSED    = 'paused';
		const STATUS_COMPLETED = 'completed';
		const STATUS_FAILED    = 'failed';
		const STATUS_CANCELLED = 'cancelled';

		/**
		 * Job types.
		 */
		const TYPE_COMMAND                  = 'command';
		const TYPE_WORKFLOW                 = 'workflow';
		const TYPE_TOOL                     = 'tool';
		const TYPE_AGENTIC_LOOP             = 'agentic_loop';
		const TYPE_CONVERSATION_IMPORT      = 'conversation_import';
		const TYPE_CHAT_STREAM_CONTINUATION = 'chat_stream_continuation';

		/**
		 * Cron hook for job processing.
		 */
		const CRON_HOOK = 'wp_mcp_ai_process_job_queue';

		/**
		 * Cron hook for cleanup.
		 */
		const CRON_CLEANUP_HOOK = 'wp_mcp_ai_cleanup_job_queue';

		/**
		 * Maximum job execution time (seconds).
		 */
		const MAX_EXECUTION_TIME = 300; // 5 minutes.

		/**
		 * Maximum retries for failed jobs.
		 */
		const MAX_RETRIES = 3;

		/**
		 * Job cleanup age (days).
		 */
		const CLEANUP_AGE_DAYS = 30;

			/**
			 * Jobs stuck in running/queued beyond this many days are reaped as
			 * failed by the daily cleanup (a crashed runner never writes
			 * completed_at, so the terminal-status DELETE alone would keep them
			 * forever).
			 *
			 * @since 1.1.98
			 */
			const STALE_AGE_DAYS = 7;

		/**
		 * Initialize the job queue system.
		 *
		 * Sets up database table, cron jobs, and hooks.
		 *
		 * @return void
		 */
		public static function init() {
			// Create database table (version-gated; dbDelta only runs when needed).
			self::maybe_create_table();

			// Schedule cron jobs.
			self::schedule_cron_jobs();

			// Register cron hooks.
			add_action( self::CRON_HOOK, array( __CLASS__, 'process_queue' ) );
			add_action( self::CRON_CLEANUP_HOOK, array( __CLASS__, 'cleanup_old_jobs' ) );

			// Admin hooks.
			if ( is_admin() ) {
				add_action( 'admin_menu', array( __CLASS__, 'register_admin_page' ) );
			}

			// Re-evaluate cron scheduling when RabbitMQ settings change.
			add_action( 'update_option_wp_mcp_ai_settings', array( __CLASS__, 'on_settings_updated' ), 10, 2 );
		}

		/**
		 * Create the job queue table if it is missing or outdated.
		 *
		 * Runs on every page load via `init()`, but dbDelta is only invoked
		 * when the stored schema version differs or the table is missing
		 * (e.g. after a restore or a manual table drop).
		 *
		 * @since 1.3.0
		 * @return void
		 */
		public static function maybe_create_table() {
			if ( self::DB_VERSION === get_option( 'wp_mcp_ai_async_job_queue_db_version' ) && self::use_custom_table() ) {
				return;
			}

			self::create_table();

			// Persist the version only when the table verifiably exists.
			// dbDelta can fail silently (e.g. restricted DB privileges),
			// and persisting regardless would leave the table permanently
			// missing without retrying.
			if ( self::use_custom_table() ) {
				update_option( 'wp_mcp_ai_async_job_queue_db_version', self::DB_VERSION );
			}
		}

		/**
		 * Check if the custom table is available.
		 *
		 * @since 1.3.0
		 * @return bool True if the custom table exists and should be used.
		 */
		private static function use_custom_table() {
			if ( null !== self::$table_exists ) {
				return self::$table_exists;
			}

			global $wpdb;
			$table_name = $wpdb->prefix . self::TABLE_NAME;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Lightweight existence probe on a custom plugin table; no WP API for custom tables.
			$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) );

			self::$table_exists = ( $table_name === $exists );
			return self::$table_exists;
		}

		/**
		 * Create the job queue database table.
		 *
		 * @return void
		 */
		public static function create_table() {
			global $wpdb;

			$table_name      = $wpdb->prefix . self::TABLE_NAME;
			$charset_collate = $wpdb->get_charset_collate();

			$sql = "CREATE TABLE IF NOT EXISTS $table_name (
				id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				job_type VARCHAR(50) NOT NULL,
				job_data LONGTEXT NOT NULL,
				priority TINYINT(1) NOT NULL DEFAULT 3,
				status VARCHAR(20) NOT NULL DEFAULT 'queued',
				progress TINYINT(3) UNSIGNED NOT NULL DEFAULT 0,
				created_at DATETIME NOT NULL,
				started_at DATETIME DEFAULT NULL,
				completed_at DATETIME DEFAULT NULL,
				result LONGTEXT DEFAULT NULL,
				error LONGTEXT DEFAULT NULL,
				retries TINYINT(2) UNSIGNED NOT NULL DEFAULT 0,
				max_retries TINYINT(2) UNSIGNED NOT NULL DEFAULT 3,
				chat_session VARCHAR(255) DEFAULT NULL,
				user_id BIGINT(20) UNSIGNED DEFAULT NULL,
				assistant_id BIGINT(20) UNSIGNED DEFAULT NULL,
				PRIMARY KEY  (id),
				KEY status_priority (status, priority),
				KEY chat_session (chat_session),
				KEY user_id (user_id),
				KEY created_at (created_at)
			) $charset_collate;";

			if ( ! function_exists( 'dbDelta' ) ) {
				require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			}
			dbDelta( $sql );

			// Verify instead of optimistically trusting dbDelta: it can fail
			// silently, and a poisoned cache would turn every queue read into
			// a flood of "table doesn't exist" database errors.
			self::$table_exists = null;
		}

		/**
		 * Schedule cron jobs for queue processing.
		 *
		 * When RabbitMQ is the primary transport with a dedicated queue
		 * worker, the DB polling cron is unnecessary — jobs are consumed
		 * via AMQP push. The daily cleanup cron always runs regardless
		 * of transport.
		 *
		 * @since 1.3.0 Added RabbitMQ transport gating.
		 *
		 * @return void
		 */
		public static function schedule_cron_jobs() {
			// If RabbitMQ is the primary transport, skip the DB polling cron
			// to avoid wasted MySQL connections (1,440 queries/day).
			$is_rmq = self::is_rabbitmq_primary_transport();

			if ( $is_rmq ) {
				$timestamp = wp_next_scheduled( self::CRON_HOOK );
				if ( $timestamp ) {
					wp_unschedule_event( $timestamp, self::CRON_HOOK );
				}
			}

			if ( ! $is_rmq && ! wp_next_scheduled( self::CRON_HOOK ) ) {
				wp_schedule_event( time(), 'minute', self::CRON_HOOK );
			}

			// Cleanup old jobs daily (always runs).
			if ( ! wp_next_scheduled( self::CRON_CLEANUP_HOOK ) ) {
				wp_schedule_event( time(), 'daily', self::CRON_CLEANUP_HOOK );
			}
		}

		/**
		 * Check whether RabbitMQ is the primary job transport.
		 *
		 * @since 1.3.0
		 *
		 * @return bool True when RabbitMQ is enabled and a dedicated
		 *              worker is configured.
		 */
		private static function is_rabbitmq_primary_transport() {
			if ( ! class_exists( 'WP_MCP_AI_RabbitMQ_Client' ) ) {
				return false;
			}

			try {
				if ( ! WP_MCP_AI_RabbitMQ_Client::get_instance()->is_available() ) {
					return false;
				}
			} catch ( \Exception $e ) {
				return false;
			}

			return (bool) get_option( 'wp_mcp_ai_queue_worker_dedicated', false );
		}

		/**
		 * Re-evaluate cron scheduling when RabbitMQ settings change.
		 *
		 * Hooked to update_option_wp_mcp_ai_settings.
		 *
		 * @since 1.3.0
		 *
		 * @param mixed $old_value Previous settings.
		 * @param mixed $new_value New settings.
		 * @return void
		 */
		public static function on_settings_updated( $old_value, $new_value ) {
			$old_rmq    = ! empty( $old_value['rabbitmq_enabled'] );
			$new_rmq    = ! empty( $new_value['rabbitmq_enabled'] );
			$old_worker = ! empty( $old_value['queue_worker_dedicated'] );
			$new_worker = ! empty( $new_value['queue_worker_dedicated'] );

			if ( $old_rmq !== $new_rmq || $old_worker !== $new_worker ) {
				// Clear and re-schedule — schedule_cron_jobs() will decide.
				wp_clear_scheduled_hook( self::CRON_HOOK );
				self::schedule_cron_jobs();
			}
		}

		/**
		 * Queue a new job.
		 *
		 * @param array $args Job arguments.
		 * @return int|WP_Error Job ID on success, WP_Error on failure.
		 */
		public static function queue_job( $args ) {
			global $wpdb;

			// Validate required fields.
			if ( empty( $args['job_type'] ) ) {
				return new WP_Error(
					'missing_job_type',
					__( 'Job type is required.', 'nvdigital-open-operator-system-oos' )
				);
			}

			if ( empty( $args['job_data'] ) ) {
				return new WP_Error(
					'missing_job_data',
					__( 'Job data is required.', 'nvdigital-open-operator-system-oos' )
				);
			}

			// Prepare job data.
			$job_data = array(
				'job_type'     => sanitize_text_field( $args['job_type'] ),
				'job_data'     => wp_json_encode( $args['job_data'] ),
				'priority'     => isset( $args['priority'] ) ? absint( $args['priority'] ) : self::PRIORITY_NORMAL,
				'status'       => self::STATUS_QUEUED,
				'progress'     => 0,
				'created_at'   => current_time( 'mysql' ),
				'retries'      => 0,
				'max_retries'  => isset( $args['max_retries'] ) ? absint( $args['max_retries'] ) : self::MAX_RETRIES,
				'chat_session' => isset( $args['chat_session'] ) ? sanitize_text_field( $args['chat_session'] ) : null,
				'user_id'      => isset( $args['user_id'] ) ? absint( $args['user_id'] ) : get_current_user_id(),
				'assistant_id' => isset( $args['assistant_id'] ) ? absint( $args['assistant_id'] ) : null,
			);

			// Insert into database.
			$table_name = $wpdb->prefix . self::TABLE_NAME;
			$inserted   = $wpdb->insert( $table_name, $job_data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom plugin table not covered by WP object cache; direct query required for real-time job status.

			if ( false === $inserted ) {
				return new WP_Error(
					'insert_failed',
					__( 'Failed to queue job.', 'nvdigital-open-operator-system-oos' ),
					array( 'db_error' => $wpdb->last_error )
				);
			}

			$job_id = $wpdb->insert_id;

			// Emit SSE event if chat session provided.
			if ( ! empty( $args['chat_session'] ) ) {
				self::emit_sse_event(
					'job_queued',
					array(
						'job_id'       => $job_id,
						'job_type'     => $args['job_type'],
						'priority'     => $job_data['priority'],
						'chat_session' => $args['chat_session'],
					)
				);
			}

			// Log activity.
			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event(
					'info',
					'Job queued',
					array(
						'job_id'   => $job_id,
						'job_type' => $args['job_type'],
						'priority' => $job_data['priority'],
					)
				);
			}

			// Phase 4: when Action Scheduler is available, dispatch the job for
			// immediate execution instead of waiting for the WP-Cron tick. The
			// legacy `process_queue` path stays in place as a safety net.
			self::maybe_enqueue_through_scheduler_bridge( $job_id );

			return $job_id;
		}

		/**
		 * Whether the Phase 4 Action Scheduler bridge is loaded and usable.
		 *
		 * @since 1.2.0
		 *
		 * @return bool
		 */
		protected static function is_scheduler_bridge_available() {
			return class_exists( 'WP_MCP_AI_Async_Scheduler_Bridge' )
				&& WP_MCP_AI_Async_Scheduler_Bridge::is_available();
		}

		/**
		 * Dispatch a job through the Action Scheduler bridge if available.
		 *
		 * Safe no-op when the bridge isn't loaded — callers can invoke this
		 * unconditionally and the legacy WP-Cron path takes over.
		 *
		 * @since 1.2.0
		 *
		 * @param int $job_id Job ID.
		 * @return void
		 */
		protected static function maybe_enqueue_through_scheduler_bridge( $job_id ) {
			if ( ! self::is_scheduler_bridge_available() ) {
				return;
			}
			WP_MCP_AI_Async_Scheduler_Bridge::enqueue_job( (int) $job_id );
		}

		/**
		 * Process a single queued job by ID.
		 *
		 * Mirrors `process_queue()` but targets a specific row, so the Action
		 * Scheduler bridge can dispatch jobs individually instead of polling
		 * once per minute. Idempotent: jobs that are already running, completed,
		 * or cancelled are silently skipped.
		 *
		 * @since 1.2.0
		 *
		 * @param int $job_id Job ID.
		 * @return void
		 */
		public static function process_specific_job( $job_id ) {
			global $wpdb;

			$job_id = (int) $job_id;
			if ( $job_id <= 0 ) {
				return;
			}

			$table_name = $wpdb->prefix . self::TABLE_NAME;

			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a safe, plugin-controlled value.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom plugin table not covered by WP object cache; direct query required for real-time job status.
			$job = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM $table_name WHERE id = %d AND status = %s",
					$job_id,
					self::STATUS_QUEUED
				),
				ARRAY_A
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			if ( ! $job ) {
				return;
			}

			// Update job status to running.
			self::update_job(
				$job['id'],
				array(
					'status'     => self::STATUS_RUNNING,
					'started_at' => current_time( 'mysql' ),
				)
			);

			// Decode job data with a defensive guard against corrupted rows.
			$decoded_job_data = json_decode( $job['job_data'], true );
			if ( ! is_array( $decoded_job_data ) ) {
				self::update_job(
					$job['id'],
					array(
						'status'       => self::STATUS_FAILED,
						'error'        => array(
							'message' => __( 'Job data is not valid JSON.', 'nvdigital-open-operator-system-oos' ),
							'code'    => 'invalid_job_data',
						),
						'completed_at' => current_time( 'mysql' ),
					)
				);
				return;
			}
			$job['job_data'] = $decoded_job_data;

			// Defensive defaults for older rows that may pre-date these columns.
			$retries     = isset( $job['retries'] ) ? (int) $job['retries'] : 0;
			$max_retries = isset( $job['max_retries'] ) ? (int) $job['max_retries'] : self::MAX_RETRIES;

			try {
				$result = self::execute_job( $job );

				self::update_job(
					$job['id'],
					array(
						'status'       => self::STATUS_COMPLETED,
						'progress'     => 100,
						'result'       => $result,
						'completed_at' => current_time( 'mysql' ),
					)
				);

				self::send_webhook_notification( $job, $result );

			} catch ( Exception $e ) {
				$error = array(
					'message' => $e->getMessage(),
					'code'    => $e->getCode(),
					'trace'   => $e->getTraceAsString(),
				);

				if ( $retries < $max_retries ) {
					self::update_job(
						$job['id'],
						array(
							'status'  => self::STATUS_QUEUED,
							'error'   => $error,
							'retries' => $retries + 1,
						)
					);

					// Re-enqueue with Action Scheduler so the retry runs ASAP
					// rather than waiting for the next WP-Cron tick.
					self::maybe_enqueue_through_scheduler_bridge( (int) $job['id'] );
				} else {
					self::update_job(
						$job['id'],
						array(
							'status'       => self::STATUS_FAILED,
							'error'        => $error,
							'completed_at' => current_time( 'mysql' ),
						)
					);

					if ( class_exists( 'WP_MCP_AI_Dead_Letter_Queue' ) ) {
						WP_MCP_AI_Dead_Letter_Queue::add(
							WP_MCP_AI_Dead_Letter_Queue::TYPE_JOB_QUEUE,
							(string) $job['id'],
							array(
								'job_id'   => (int) $job['id'],
								'job_data' => $job['job_data'],
							),
							isset( $error['message'] ) ? $error['message'] : wp_json_encode( $error )
						);
					}
				}
			}
		}

		/**
		 * Get a job by ID.
		 *
		 * @param int $job_id Job ID.
		 * @return array|null Job data or null if not found.
		 */
		public static function get_job( $job_id ) {
			global $wpdb;

			$table_name = $wpdb->prefix . self::TABLE_NAME;
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a safe, plugin-controlled value.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom plugin table not covered by WP object cache; direct query required for real-time job status.
			$job = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM $table_name WHERE id = %d",  // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a safe, plugin-controlled value.
					$job_id
				),
				ARRAY_A
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			if ( ! $job ) {
				return null;
			}

			// Decode JSON fields.
			$job['job_data'] = json_decode( $job['job_data'], true );
			if ( ! empty( $job['result'] ) ) {
				$job['result'] = json_decode( $job['result'], true );
			}
			if ( ! empty( $job['error'] ) ) {
				$job['error'] = json_decode( $job['error'], true );
			}

			return $job;
		}

		/**
		 * Update a job.
		 *
		 * @param int   $job_id Job ID.
		 * @param array $data   Data to update.
		 * @return bool True on success, false on failure.
		 */
		public static function update_job( $job_id, $data ) {
			global $wpdb;

			// Prepare update data.
			$update_data = array();

			if ( isset( $data['status'] ) ) {
				$update_data['status'] = sanitize_text_field( $data['status'] );
			}

			if ( isset( $data['progress'] ) ) {
				$update_data['progress'] = min( 100, absint( $data['progress'] ) );
			}

			if ( isset( $data['result'] ) ) {
				$update_data['result'] = wp_json_encode( $data['result'] );
			}

			if ( isset( $data['error'] ) ) {
				$update_data['error'] = wp_json_encode( $data['error'] );
			}

			if ( isset( $data['started_at'] ) ) {
				$update_data['started_at'] = sanitize_text_field( $data['started_at'] );
			}

			if ( isset( $data['completed_at'] ) ) {
				$update_data['completed_at'] = sanitize_text_field( $data['completed_at'] );
			}

			if ( isset( $data['retries'] ) ) {
				$update_data['retries'] = absint( $data['retries'] );
			}

			if ( empty( $update_data ) ) {
				return false;
			}

			$table_name = $wpdb->prefix . self::TABLE_NAME;
			$updated    = $wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom plugin table not covered by WP object cache; direct query required for real-time job status.
				$table_name,
				$update_data,
				array( 'id' => $job_id )
			);

			// Emit SSE event for progress updates.
			if ( isset( $data['progress'] ) || isset( $data['status'] ) ) {
				$job = self::get_job( $job_id );
				if ( $job && ! empty( $job['chat_session'] ) ) {
					$event_data = array(
						'job_id'       => $job_id,
						'chat_session' => $job['chat_session'],
					);

					if ( isset( $data['progress'] ) ) {
						$event_data['progress'] = $data['progress'];
					}

					if ( isset( $data['status'] ) ) {
						$event_data['status'] = $data['status'];
					}

					if ( isset( $data['result'] ) ) {
						$event_data['result'] = $data['result'];
					}

					$event_name = isset( $data['status'] ) && self::STATUS_COMPLETED === $data['status']
						? 'job_completed'
						: 'job_progress';

					self::emit_sse_event( $event_name, $event_data );
				}
			}

			return false !== $updated;
		}

		/**
		 * Process the job queue.
		 *
		 * Processes pending jobs based on priority and system resources.
		 *
		 * @return void
		 */
		public static function process_queue() {
			global $wpdb;

			// Get next job to process (highest priority first).
			$table_name = $wpdb->prefix . self::TABLE_NAME;
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a safe, plugin-controlled value.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom plugin table not covered by WP object cache; direct query required for real-time job status.
			$job = $wpdb->get_row(
				"SELECT * FROM $table_name
				WHERE status = 'queued' 
				ORDER BY priority ASC, created_at ASC 
				LIMIT 1",
				ARRAY_A
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			if ( ! $job ) {
				return; // No jobs to process.
			}

			// Update job status to running.
			self::update_job(
				$job['id'],
				array(
					'status'     => self::STATUS_RUNNING,
					'started_at' => current_time( 'mysql' ),
				)
			);

			// Decode job data.
			$job['job_data'] = json_decode( $job['job_data'], true );

			// Execute the job.
			try {
				$result = self::execute_job( $job );

				// Update job as completed.
				self::update_job(
					$job['id'],
					array(
						'status'       => self::STATUS_COMPLETED,
						'progress'     => 100,
						'result'       => $result,
						'completed_at' => current_time( 'mysql' ),
					)
				);

				// Send webhook notification if configured.
				self::send_webhook_notification( $job, $result );

			} catch ( Exception $e ) {
				// Job failed.
				$error = array(
					'message' => $e->getMessage(),
					'code'    => $e->getCode(),
					'trace'   => $e->getTraceAsString(),
				);

				// Check if we should retry.
				if ( $job['retries'] < $job['max_retries'] ) {
					// Retry the job.
					self::update_job(
						$job['id'],
						array(
							'status'  => self::STATUS_QUEUED,
							'error'   => $error,
							'retries' => $job['retries'] + 1,
						)
					);
				} else {
					// Max retries exceeded, move to dead letter queue.
					self::update_job(
						$job['id'],
						array(
							'status'       => self::STATUS_FAILED,
							'error'        => $error,
							'completed_at' => current_time( 'mysql' ),
						)
					);

					// Add to dead letter queue.
					if ( class_exists( 'WP_MCP_AI_Dead_Letter_Queue' ) ) {
						WP_MCP_AI_Dead_Letter_Queue::add(
							WP_MCP_AI_Dead_Letter_Queue::TYPE_JOB_QUEUE,
							(string) $job['id'],
							array(
								'job_id'   => (int) $job['id'],
								'job_data' => $job['job_data'],
							),
							isset( $error['message'] ) ? $error['message'] : wp_json_encode( $error )
						);
					}
				}
			}
		}

		/**
		 * Execute a job based on its type.
		 *
		 * @param array $job Job data.
		 * @return mixed Job result.
		 * @throws Exception If job execution fails.
		 */
		private static function execute_job( $job ) {
			switch ( $job['job_type'] ) {
				case self::TYPE_COMMAND:
					return self::execute_command_job( $job );

				case self::TYPE_WORKFLOW:
					return self::execute_workflow_job( $job );

				case self::TYPE_TOOL:
					return self::execute_tool_job( $job );

				case self::TYPE_AGENTIC_LOOP:
					return self::execute_agentic_loop_job( $job );

				case self::TYPE_CONVERSATION_IMPORT:
					return self::execute_conversation_import_job( $job );

				case self::TYPE_CHAT_STREAM_CONTINUATION:
					return self::execute_chat_stream_continuation_job( $job );

				default:
					throw new Exception(
						sprintf(
							/* translators: %s: Job type */
							__( 'Unknown job type: %s', 'nvdigital-open-operator-system-oos' ), // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception thrown, not echoed to output.
							$job['job_type'] // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception thrown, not echoed to output.
						)
					);
			}
		}

		/**
		 * Execute a conversation import job.
		 *
		 * Delegates to the conversation import queue bridge, which runs the
		 * import manager and updates job progress after every batch.
		 *
		 * @param array $job Job data.
		 * @return array Import report.
		 * @throws Exception If the import bridge is unavailable.
		 */
		private static function execute_conversation_import_job( $job ) {
			if ( ! class_exists( 'WP_MCP_AI_Conversation_Import_Queue' ) ) {
				throw new Exception( __( 'Conversation import bridge not available.', 'nvdigital-open-operator-system-oos' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception thrown, not echoed to output.
			}

			return WP_MCP_AI_Conversation_Import_Queue::execute( $job['job_data'], (int) $job['id'] );
		}

		/**
		 * Execute a chat stream continuation job (SSE long-run offload).
		 *
		 * Delegates to the offload worker, which resumes the agentic loop
		 * from the continuation snapshot off the request thread.
		 *
		 * @param array $job Job data.
		 * @return array Job result.
		 * @throws Exception If the offload worker is unavailable.
		 */
		private static function execute_chat_stream_continuation_job( $job ) {
			if ( ! class_exists( 'WP_MCP_AI_Chat_Stream_Offload_Worker' ) ) {
				if ( ! wp_mcp_ai_class_exists_via_autoload( WP_MCP_AI_PATH . 'includes/services/class-wp-mcp-ai-chat-stream-offload-worker.php' ) ) {
					require_once WP_MCP_AI_PATH . 'includes/services/class-wp-mcp-ai-chat-stream-offload-worker.php';
				}
			}
			if ( ! class_exists( 'WP_MCP_AI_Chat_Stream_Offload_Worker' ) ) {
				throw new Exception( __( 'Chat stream offload worker not available.', 'nvdigital-open-operator-system-oos' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception thrown, not echoed to output.
			}

			return WP_MCP_AI_Chat_Stream_Offload_Worker::run( $job['job_data'], (int) $job['id'] );
		}

		/**
		 * Execute a command job.
		 *
		 * @param array $job Job data.
		 * @return mixed Command result.
		 * @throws Exception If the slash command toolkit is not available.
		 */
		private static function execute_command_job( $job ) {
			// Integration with slash command toolkit manager.
			if ( ! class_exists( 'WP_MCP_AI_Slash_Command_Toolkit_Manager' ) ) {
				throw new Exception( __( 'Slash command toolkit not available.', 'nvdigital-open-operator-system-oos' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception thrown, not echoed to output.
			}

			$command = $job['job_data']['command'] ?? '';
			$args    = $job['job_data']['args'] ?? array();

			// Execute command.
			$manager = new WP_MCP_AI_Slash_Command_Toolkit_Manager();
			return $manager->execute_command( $command, $args );
		}

		/**
		 * Execute a workflow job.
		 *
		 * @param array $job Job data.
		 * @return mixed Workflow result.
		 * @throws Exception If the workflow orchestrator is not available.
		 */
		private static function execute_workflow_job( $job ) {
			// Integration with workflow orchestrator.
			if ( ! class_exists( 'WP_MCP_AI_Workflow_Orchestrator' ) ) {
				throw new Exception( __( 'Workflow orchestrator not available.', 'nvdigital-open-operator-system-oos' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception thrown, not echoed to output.
			}

			$workflow_id = $job['job_data']['workflow_id'] ?? '';

			// Execute workflow.
			$orchestrator = new WP_MCP_AI_Workflow_Orchestrator();
			return $orchestrator->execute_workflow( $workflow_id, $job['job_data'] );
		}

		/**
		 * Execute a tool job.
		 *
		 * @param array $job Job data.
		 * @return mixed Tool result.
		 * @throws Exception If the tool async executor is not available.
		 */
		private static function execute_tool_job( $job ) {
			// Integration with tool async executor.
			if ( ! class_exists( 'WP_MCP_AI_Tool_Async_Executor' ) ) {
				throw new Exception( __( 'Tool async executor not available.', 'nvdigital-open-operator-system-oos' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception thrown, not echoed to output.
			}

			$tool_slug = $job['job_data']['tool_slug'] ?? '';
			$arguments = $job['job_data']['arguments'] ?? array();

			// Execute tool.
			return WP_MCP_AI_Tool_Async_Executor::execute_tool( $tool_slug, $arguments );
		}

		/**
		 * Execute an agentic loop job.
		 *
		 * @param array $_job Job data (unused — not yet implemented).
		 * @return mixed Agentic loop result.
		 * @throws Exception Always thrown as not yet implemented.
		 *
		 * @phpcs:disable VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable -- Reserved parameter for future implementation.
		 */
		private static function execute_agentic_loop_job( $_job ) {
			unset( $_job ); // Reserved for future implementation.

			// TODO: Implement agentic loop execution.
			// This would integrate with the chat controller's agentic loop logic
			// but allow for unlimited iterations in the background.

			throw new Exception( __( 'Agentic loop execution not yet implemented.', 'nvdigital-open-operator-system-oos' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception thrown, not echoed to output.
		}

		/**
		 * Emit SSE event for job updates.
		 *
		 * @param string $event_name Event name.
		 * @param array  $event_data Event data.
		 * @return void
		 */
		private static function emit_sse_event( $event_name, $event_data ) {
			if ( class_exists( 'WP_MCP_AI_SSE_Handler' ) ) {
				do_action( 'wp_mcp_ai_emit_sse_event', $event_name, $event_data );
			}
		}

		/**
		 * Send webhook notification for job completion.
		 *
		 * @param array $job    Job data.
		 * @param mixed $result Job result.
		 * @return void
		 */
		private static function send_webhook_notification( $job, $result ) {
			if ( ! class_exists( 'WP_MCP_AI_Job_Notifier' ) ) {
				return;
			}

			WP_MCP_AI_Job_Notifier::handle_job_completed(
				(string) $job['id'],
				$result,
				array( 'job_type' => $job['job_type'] )
			);
		}

		/**
		 * Cleanup old completed/failed jobs and reap stale running/queued jobs.
		 *
		 * @return void
		 */
		public static function cleanup_old_jobs() {
			global $wpdb;

			$table_name = $wpdb->prefix . self::TABLE_NAME;
			$age_days   = apply_filters( 'wp_mcp_ai_job_queue_cleanup_age_days', self::CLEANUP_AGE_DAYS );

			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a safe, plugin-controlled value.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom plugin table not covered by WP object cache; direct query required for real-time job status.
			$deleted = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM $table_name
					WHERE status IN ('completed', 'failed', 'cancelled')
					AND completed_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
					$age_days
				)
			);

			// Reap stale jobs that never reached a terminal status: rows stuck
			// in running/queued beyond the stale window (e.g. a crashed runner)
			// would otherwise accumulate forever because the DELETE above only
			// covers terminal statuses with a completed_at timestamp.
			$stale_age_days = apply_filters( 'wp_mcp_ai_job_queue_stale_age_days', self::STALE_AGE_DAYS );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom plugin table not covered by WP object cache; direct query required for real-time job status.
			$reaped = $wpdb->query(
				$wpdb->prepare(
					"UPDATE $table_name
					SET status = %s, error = %s, completed_at = NOW()
					WHERE status IN (%s, %s)
					AND created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
					self::STATUS_FAILED,
					'Stale job: no completion within the stale-job window.',
					self::STATUS_RUNNING,
					self::STATUS_QUEUED,
					$stale_age_days
				)
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			if ( ( $deleted || $reaped ) && class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event(
					'info',
					'Cleaned up old jobs',
					array(
						'count'        => $deleted,
						'stale_reaped' => $reaped,
					)
				);
			}
		}

		/**
		 * Cancel a job.
		 *
		 * @param int $job_id Job ID.
		 * @return bool True on success, false on failure.
		 */
		public static function cancel_job( $job_id ) {
			return self::update_job(
				$job_id,
				array(
					'status'       => self::STATUS_CANCELLED,
					'completed_at' => current_time( 'mysql' ),
				)
			);
		}

		/**
		 * Pause a job.
		 *
		 * @param int $job_id Job ID.
		 * @return bool True on success, false on failure.
		 */
		public static function pause_job( $job_id ) {
			return self::update_job(
				$job_id,
				array(
					'status' => self::STATUS_PAUSED,
				)
			);
		}

		/**
		 * Resume a paused job.
		 *
		 * @param int $job_id Job ID.
		 * @return bool True on success, false on failure.
		 */
		public static function resume_job( $job_id ) {
			return self::update_job(
				$job_id,
				array(
					'status' => self::STATUS_QUEUED,
				)
			);
		}

		/**
		 * Get jobs by status.
		 *
		 * @param string $status Job status.
		 * @param int    $limit  Maximum number of jobs to return.
		 * @return array Array of jobs.
		 */
		public static function get_jobs_by_status( $status, $limit = 100 ) {
			global $wpdb;

			$table_name = $wpdb->prefix . self::TABLE_NAME;
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a safe, plugin-controlled value.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom plugin table not covered by WP object cache; direct query required for real-time job status.
			$jobs = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM $table_name
					WHERE status = %s 
					ORDER BY created_at DESC 
					LIMIT %d",
					$status,
					$limit
				),
				ARRAY_A
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			// Decode JSON fields.
			foreach ( $jobs as &$job ) {
				$job['job_data'] = json_decode( $job['job_data'], true );
				if ( ! empty( $job['result'] ) ) {
					$job['result'] = json_decode( $job['result'], true );
				}
				if ( ! empty( $job['error'] ) ) {
					$job['error'] = json_decode( $job['error'], true );
				}
			}

			return $jobs;
		}

		/**
		 * Get queue statistics.
		 *
		 * @return array Queue statistics.
		 */
		public static function get_queue_stats() {
			if ( ! self::use_custom_table() ) {
				// Fail soft: the Load Guard calls this on every REST dispatch,
				// so a missing table must never spam SQL errors per request.
				return array(
					'total'     => 0,
					'queued'    => 0,
					'running'   => 0,
					'completed' => 0,
					'failed'    => 0,
				);
			}

			global $wpdb;

			$table_name = esc_sql( $wpdb->prefix . self::TABLE_NAME );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Direct queries on custom plugin table with esc_sql()-escaped table name; no WP API for custom tables.
			return array(
				'total'     => $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" ),
				'queued'    => $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table_name} WHERE status = %s", 'queued' ) ),
				'running'   => $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table_name} WHERE status = %s", 'running' ) ),
				'completed' => $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table_name} WHERE status = %s", 'completed' ) ),
				'failed'    => $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table_name} WHERE status = %s", 'failed' ) ),
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}

		/**
		 * Register admin page for job queue management.
		 *
		 * @return void
		 */
		public static function register_admin_page() {
			// Admin page will be implemented separately.
			// For now, just register the menu item.
			add_submenu_page(
				'wp-mcp-ai',
				__( 'Job Queue', 'nvdigital-open-operator-system-oos' ),
				__( 'Job Queue', 'nvdigital-open-operator-system-oos' ),
				'manage_options',
				'wp-mcp-ai-job-queue',
				array( __CLASS__, 'render_admin_page' )
			);
		}

		/**
		 * Render admin page (placeholder).
		 *
		 * @return void
		 */
		public static function render_admin_page() {
			$stats = self::get_queue_stats();
			?>
			<div class="wrap">
				<h1><?php esc_html_e( 'Async Job Queue', 'nvdigital-open-operator-system-oos' ); ?></h1>
				
				<div class="wp-mcp-ai-job-queue-stats">
					<h2><?php esc_html_e( 'Queue Statistics', 'nvdigital-open-operator-system-oos' ); ?></h2>
					<table class="widefat">
						<tbody>
							<tr>
								<td><?php esc_html_e( 'Total Jobs', 'nvdigital-open-operator-system-oos' ); ?></td>
								<td><?php echo esc_html( $stats['total'] ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Queued', 'nvdigital-open-operator-system-oos' ); ?></td>
								<td><?php echo esc_html( $stats['queued'] ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Running', 'nvdigital-open-operator-system-oos' ); ?></td>
								<td><?php echo esc_html( $stats['running'] ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Completed', 'nvdigital-open-operator-system-oos' ); ?></td>
								<td><?php echo esc_html( $stats['completed'] ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Failed', 'nvdigital-open-operator-system-oos' ); ?></td>
								<td><?php echo esc_html( $stats['failed'] ); ?></td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="wp-mcp-ai-job-queue-recent">
					<h2><?php esc_html_e( 'Recent Jobs', 'nvdigital-open-operator-system-oos' ); ?></h2>
					<?php
					$recent_jobs = self::get_jobs_by_status( self::STATUS_QUEUED, 10 );
					if ( empty( $recent_jobs ) ) {
						echo '<p>' . esc_html__( 'No queued jobs.', 'nvdigital-open-operator-system-oos' ) . '</p>';
					} else {
						echo '<table class="widefat">';
						echo '<thead><tr>';
						echo '<th>' . esc_html__( 'ID', 'nvdigital-open-operator-system-oos' ) . '</th>';
						echo '<th>' . esc_html__( 'Type', 'nvdigital-open-operator-system-oos' ) . '</th>';
						echo '<th>' . esc_html__( 'Priority', 'nvdigital-open-operator-system-oos' ) . '</th>';
						echo '<th>' . esc_html__( 'Status', 'nvdigital-open-operator-system-oos' ) . '</th>';
						echo '<th>' . esc_html__( 'Created', 'nvdigital-open-operator-system-oos' ) . '</th>';
						echo '</tr></thead><tbody>';

						foreach ( $recent_jobs as $job ) {
							echo '<tr>';
							echo '<td>' . esc_html( $job['id'] ) . '</td>';
							echo '<td>' . esc_html( $job['job_type'] ) . '</td>';
							echo '<td>' . esc_html( $job['priority'] ) . '</td>';
							echo '<td>' . esc_html( $job['status'] ) . '</td>';
							echo '<td>' . esc_html( $job['created_at'] ) . '</td>';
							echo '</tr>';
						}

						echo '</tbody></table>';
					}
					?>
				</div>
			</div>
			<?php
		}
	}

	// Initialize on plugin load.
	add_action( 'plugins_loaded', array( 'WP_MCP_AI_Async_Job_Queue', 'init' ) );
}
