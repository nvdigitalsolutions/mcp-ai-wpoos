<?php
/**
 * One-time migration that rewrites stored model references away from ids
 * retired during the April 2026 model catalog refresh.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rewrites legacy model identifiers stored in user options and assistant
 * post meta to documented successors, so existing assistants keep working
 * after deprecated ids are removed from the catalog.
 */
class WP_MCP_AI_Model_Catalog_Migration {

	/**
	 * Option key used to record that the migration has run for the current
	 * catalog version. The catalog file's `version` field is appended so any
	 * future catalog refresh re-runs this routine.
	 */
	const OPTION_KEY = 'wp_mcp_ai_model_catalog_migration_version';

	/**
	 * Map of removed ids to their documented successor.
	 *
	 * Keep this list in sync with the removals applied in includes/data/model-catalog.json.
	 *
	 * @return array
	 */
	public static function get_legacy_id_map() {
		return array(
			// OpenAI sunset.
			'gpt-3.5-turbo'                        => 'gpt-4o-mini',
			'gpt-3.5-turbo-16k'                    => 'gpt-4o-mini',
			'gpt-4'                                => 'gpt-4.1',
			'gpt-4-turbo'                          => 'gpt-4.1',
			'gpt-4-1106-preview'                   => 'gpt-4.1',
			'gpt-4-vision-preview'                 => 'gpt-4.1',
			'o1'                                   => 'gpt-5.6-sol',
			'o1-mini'                              => 'gpt-5.6-terra',
			'o1-preview'                           => 'gpt-5.6-sol',
			'o1-pro'                               => 'gpt-5.6-sol',
			'gpt-4.1-2025-04-14'                   => 'gpt-4.1',
			'chatgpt-4o-latest'                    => 'gpt-4.1',
			// Anthropic retired.
			'claude-3-haiku-20240307'              => 'claude-haiku-4-5',
			'claude-3-opus-20240229'               => 'claude-opus-4-6',
			'claude-3-opus'                        => 'claude-opus-4-6',
			'claude-3-sonnet'                      => 'claude-sonnet-4-6',
			'claude-3-haiku'                       => 'claude-haiku-4-5',
			'claude-opus-4-20250514'               => 'claude-opus-4-6',
			'claude-sonnet-4-20250514'             => 'claude-sonnet-4-6',
			'claude-opus-4-1-20250805'             => 'claude-opus-4-6',
			'claude-mythos-preview'                => 'claude-mythos-5',
			'claude-3.5-sonnet'                    => 'claude-sonnet-4-6',
			'claude-3.5-sonnet-v2'                 => 'claude-sonnet-4-6',
			'claude-sonnet-4.5'                    => 'claude-sonnet-4-6',
			'claude-haiku-4.5'                     => 'claude-haiku-4-5',
			'claude-opus-4.1'                      => 'claude-opus-4-6',
			'claude-opus-4.0'                      => 'claude-opus-4-6',
			// Anthropic retired (October 2026 refresh).
			'claude-3-5-haiku-20241022'            => 'claude-haiku-4-5',
			'claude-3-5-sonnet-20241022'           => 'claude-sonnet-4-6',
			// Gemini sunset.
			'gemini-pro'                           => 'gemini-2.5-pro',
			'gemini-pro-vision'                    => 'gemini-2.5-pro',
			'gemini-1.5-pro'                       => 'gemini-2.5-pro',
			'gemini-1.5-pro-002'                   => 'gemini-2.5-pro',
			'gemini-1.5-flash'                     => 'gemini-2.5-flash',
			'gemini-1.5-flash-002'                 => 'gemini-2.5-flash',
			'gemini-2.0-flash'                     => 'gemini-2.5-flash',
			'gemini-2.0-flash-lite'                => 'gemini-2.5-flash-lite',
			'gemini-2.0-flash-image'               => 'gemini-3.1-flash-image',
			'gemini-2.5-flash-image'               => 'gemini-3.1-flash-image',
			'gemini-live-2.5-flash-preview'        => 'gemini-3.8-live',
			'gemini-omni-flash'                    => 'gemini-omni-1.1-flash',
			'gemini-3-pro-preview'                 => 'gemini-3.1-pro',
			'gemini-3-flash-preview'               => 'gemini-3.5-flash',
			'gemini-3.1-pro-preview'               => 'gemini-3.1-pro',
			'gemini-3.1-flash'                     => 'gemini-3.5-flash',
			'imagen-3'                             => 'gemini-3.1-flash-image',
			'imagen-4'                             => 'gemini-3.1-flash-image',
			// NIM deprecated.
			'meta/llama-3.1-405b-instruct'         => 'meta/llama-3.3-70b-instruct',
			'meta/llama-3.1-70b-instruct'          => 'meta/llama-3.3-70b-instruct',
			'meta/llama-3.1-8b-instruct'           => 'meta/llama-3.2-3b-instruct',
			'microsoft/phi-3-medium-128k-instruct' => 'microsoft/phi-4',
			'microsoft/phi-3-medium-4k-instruct'   => 'microsoft/phi-4',
			'microsoft/phi-3-mini-128k-instruct'   => 'microsoft/phi-4',
			'microsoft/phi-3-mini-4k-instruct'     => 'microsoft/phi-4',
			'microsoft/phi-3-small-128k-instruct'  => 'microsoft/phi-4',
			'microsoft/phi-3-small-8k-instruct'    => 'microsoft/phi-4',
			// Vertex / GCP stale.

			// DeepSeek legacy aliases (deepseek-chat / deepseek-reasoner retired
			// 2026-07-24; V4 Flash + V4 Flash Vision retired 2026-09-10) → V4.1 Flash.
			// deepseek-v4-pro is deliberately NOT mapped: DeepSeek announced on
			// 2026-09-10 that V4 Pro stays servable past 2026-09-14 (billing
			// unchanged, no new sunset date), so stored references are left alone.
			'deepseek-chat'                        => 'deepseek-flash',
			'deepseek-reasoner'                    => 'deepseek-flash',
			'deepseek-coder'                       => 'deepseek-flash',
			'deepseek-v4-flash'                    => 'deepseek-flash',
			'deepseek-v4-flash-vision-exp'         => 'deepseek-flash',
			// OpenAI codex line shut down 2026-07-23 → gpt-5.6 tiers.
			'gpt-5-codex'                          => 'gpt-5.6-sol',
			'gpt-5.1-codex'                        => 'gpt-5.6-sol',
			'gpt-5.1-codex-max'                    => 'gpt-5.6-sol',
			'gpt-5.1-codex-mini'                   => 'gpt-5.6-terra',
			'gpt-5.2-codex'                        => 'gpt-5.6-sol',
			'gpt-5-chat-latest'                    => 'gpt-5.6-sol',
			'gpt-5.1-chat-latest'                  => 'gpt-5.6-sol',
			'gpt-5.2-chat-latest'                  => 'gpt-5.6-sol',
			'gpt-5.3-chat-latest'                  => 'gpt-5.6-sol',
			// Kimi / Moonshot discontinued (k2 series 2026-05-25; k2.5 + moonshot-v1
			// series 2026-08-31) → kimi-k3.
			'kimi-latest'                          => 'kimi-k3',
			'kimi-k2'                              => 'kimi-k3',
			'kimi-k2-thinking'                     => 'kimi-k3',
			'kimi-k2.5'                            => 'kimi-k3',
			'moonshot-v1-auto'                     => 'kimi-k3',
			'moonshot-v1-8k'                       => 'kimi-k3',
			'moonshot-v1-32k'                      => 'kimi-k3',
			'moonshot-v1-128k'                     => 'kimi-k3',
			'moonshot-v1-8k-vision-preview'        => 'kimi-k3',
			'moonshot-v1-32k-vision-preview'       => 'kimi-k3',
			'moonshot-v1-128k-vision-preview'      => 'kimi-k3',
		);
	}

	/**
	 * Run the migration if it has not been recorded for the current catalog version.
	 *
	 * @param string $catalog_version Version string from the bundled JSON catalog.
	 *                                Used as part of the option to allow re-running
	 *                                after future refreshes.
	 * @return bool True when the migration ran, false when it was already complete.
	 */
	public static function run_if_needed( $catalog_version = '' ) {
		$catalog_version = $catalog_version ? sanitize_text_field( $catalog_version ) : 'unknown';
		$last_ran        = get_option( self::OPTION_KEY, '' );
		if ( $last_ran === $catalog_version ) {
			return false;
		}

		$map = self::get_legacy_id_map();
		if ( empty( $map ) ) {
			update_option( self::OPTION_KEY, $catalog_version, false );
			return false;
		}

		$rewrites = array(
			'configs'    => self::migrate_model_configs_option( $map ),
			'assistants' => self::migrate_assistant_post_meta( $map ),
			'settings'   => self::migrate_default_model_setting( $map ),
		);

		update_option( self::OPTION_KEY, $catalog_version, false );

		if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
			WP_MCP_AI_Logger::log_event(
				'model_catalog_migration_completed',
				'Rewrote stored model identifiers to current catalog successors.',
				array(
					'catalog_version' => $catalog_version,
					'rewrites'        => $rewrites,
				)
			);
		}

		return true;
	}

	/**
	 * Rewrite legacy keys inside the wp_mcp_ai_model_configs option array.
	 *
	 * @param array $map Legacy id => successor id.
	 * @return int Number of rewritten entries.
	 */
	protected static function migrate_model_configs_option( array $map ) {
		$option_name = class_exists( 'WP_MCP_AI_Model_Config' ) ? WP_MCP_AI_Model_Config::CONFIGS_OPTION : 'wp_mcp_ai_model_configs';
		$configs     = get_option( $option_name, array() );
		if ( ! is_array( $configs ) || empty( $configs ) ) {
			return 0;
		}

		$rewritten = 0;
		foreach ( $map as $legacy => $successor ) {
			if ( ! isset( $configs[ $legacy ] ) ) {
				continue;
			}
			// Only move the entry when there is no existing successor configured.
			if ( ! isset( $configs[ $successor ] ) ) {
				$configs[ $successor ] = $configs[ $legacy ];
			}
			unset( $configs[ $legacy ] );
			++$rewritten;
		}

		// Also rewrite fallback_model fields pointing at retired ids.
		foreach ( $configs as $key => $config ) {
			if ( ! is_array( $config ) ) {
				continue;
			}
			if ( ! empty( $config['fallback_model'] ) && isset( $map[ $config['fallback_model'] ] ) ) {
				$configs[ $key ]['fallback_model'] = $map[ $config['fallback_model'] ];
				++$rewritten;
			}
		}

		if ( $rewritten > 0 ) {
			update_option( $option_name, $configs, false );
		}

		return $rewritten;
	}

	/**
	 * Rewrite assistant post meta `_wp_mcp_ai_model` values.
	 *
	 * @param array $map Legacy id => successor id.
	 * @return int Number of rewritten posts.
	 */
	protected static function migrate_assistant_post_meta( array $map ) {
		global $wpdb;
		if ( ! isset( $wpdb ) ) {
			return 0;
		}

		$legacy_ids = array_keys( $map );
		if ( empty( $legacy_ids ) ) {
			return 0;
		}

		// Single IN-clause query to find every post_id whose stored model is a legacy id,
		// rather than one query per legacy id.
		$placeholders = implode( ', ', array_fill( 0, count( $legacy_ids ), '%s' ) );
		$rows         = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-time migration; caching would return stale data.
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders is a fixed list of %s tokens.
				"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IN ( {$placeholders} )",
				array_merge( array( '_wp_mcp_ai_model' ), $legacy_ids )
			)
		);

		$rewritten = 0;
		if ( ! empty( $rows ) ) {
			foreach ( $rows as $row ) {
				$legacy = $row->meta_value;
				if ( ! isset( $map[ $legacy ] ) ) {
					continue;
				}
				update_post_meta( (int) $row->post_id, '_wp_mcp_ai_model', $map[ $legacy ] );
				++$rewritten;
			}
		}

		return $rewritten;
	}

	/**
	 * Rewrite global model settings that point at removed ids.
	 *
	 * Covers the OpenAI-oriented `default_model` key plus the per-provider
	 * default chat-model keys, so a retired id stored under e.g.
	 * `deepseek_model` is migrated to its successor too.
	 *
	 * @param array $map Legacy id => successor id.
	 * @return int Number of rewritten settings keys.
	 */
	protected static function migrate_default_model_setting( array $map ) {
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( ! is_array( $settings ) ) {
			return 0;
		}

		// Settings keys that hold a plain chat-model id (not base URLs,
		// embeddings, or vision-specific pins).
		$model_keys = array(
			'default_model',
			'default_gemini_model',
			'anthropic_model',
			'deepseek_model',
			'kimi_model',
		);

		$rewritten = 0;
		foreach ( $model_keys as $key ) {
			if ( empty( $settings[ $key ] ) || ! isset( $map[ $settings[ $key ] ] ) ) {
				continue;
			}

			$settings[ $key ] = $map[ $settings[ $key ] ];
			++$rewritten;
		}

		if ( $rewritten > 0 ) {
			update_option( 'wp_mcp_ai_settings', $settings );
		}

		return $rewritten;
	}
}
