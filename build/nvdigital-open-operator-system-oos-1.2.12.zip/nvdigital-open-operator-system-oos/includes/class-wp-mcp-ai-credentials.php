<?php
/**
 * Credential management helpers for NV oOS.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Credentials' ) ) {
	/**
	 * Handles creation, storage, and validation of assistant credentials.
	 */
	class WP_MCP_AI_Credentials {
		const META_KEY            = '_wp_mcp_ai_credentials';
		const ASSISTANT_POST_TYPE = 'mcp_ai_assistant';
		const INDEX_OPTION        = 'wp_mcp_ai_credential_index';

		/**
		 * Default credential lifetime in seconds (90 days).
		 *
		 * @since 1.2.0
		 * @var int
		 */
		const DEFAULT_LIFETIME = 7776000; // 90 days.

		/**
		 * Calculate credential expiry from the admin setting.
		 *
		 * @since 1.2.0
		 * @return string Expiry date in MySQL format, or empty string for no expiry.
		 */
		private static function calculate_expiry() {
			$days = 90;
			if ( function_exists( 'wp_mcp_ai_get_settings_repository' ) ) {
				$days = absint( wp_mcp_ai_get_settings_repository()->get( 'credential_lifetime_days', 90 ) );
			}
			if ( $days <= 0 ) {
				return '';
			}
			return gmdate( 'Y-m-d H:i:s', time() + ( $days * DAY_IN_SECONDS ) );
		}

		/**
		 * Determine whether a token string matches the expected credential format.
		 *
		 * @param string $token Raw token string.
		 * @return bool
		 */
		public static function is_token_format( $token ) {
			$parts = self::parse_token( $token );

			return null !== $parts;
		}

		/**
		 * Parse a token into its identifier and secret components.
		 *
		 * @param string $token Raw token string.
		 * @return array|null
		 */
		public static function parse_token( $token ) {
			if ( ! is_string( $token ) || '' === $token ) {
				return null;
			}

			$parts = explode( '.', $token, 2 );
			if ( 2 !== count( $parts ) ) {
				return null;
			}

			$identifier = sanitize_key( $parts[0] );
			$secret     = trim( $parts[1] );

			if ( '' === $identifier || '' === $secret ) {
				return null;
			}

			if ( 0 !== strpos( $identifier, 'cred_' ) ) {
				return null;
			}

			return array( $identifier, $secret );
		}

		/**
		 * Retrieve all stored credentials for an assistant.
		 *
		 * @param int $assistant_id Assistant post ID.
		 * @return array
		 */
		public static function get_credentials( $assistant_id ) {
			$assistant_id = absint( $assistant_id );
			if ( ! $assistant_id ) {
				return array();
			}

			$stored = get_post_meta( $assistant_id, self::META_KEY, true );
			if ( ! is_array( $stored ) ) {
				return array();
			}

			return self::normalize_credentials( $stored );
		}

		/**
		 * Issue a new credential for an assistant.
		 *
		 * @param int $assistant_id Assistant post ID.
		 * @param int $user_id      Issuing user ID.
		 * @return array|WP_Error {
		 *     Array containing the raw token and stored credential metadata.
		 *
		 *     @type string $token      Raw token value (identifier.secret).
		 *     @type array  $credential Stored credential metadata.
		 * }
		 */
		public static function issue_credential( $assistant_id, $user_id ) {
			$assistant_id = absint( $assistant_id );
			$user_id      = absint( $user_id );

			if ( ! self::is_valid_assistant( $assistant_id ) ) {
				return new WP_Error( 'wp_mcp_ai_invalid_assistant', __( 'Unable to issue a credential for the requested assistant.', 'nvdigital-open-operator-system-oos' ) );
			}

			$credentials = self::get_credentials( $assistant_id );

			$credential_id = self::generate_unique_id( $credentials );
			$secret        = wp_generate_password( 32, false, false );
			$hash          = wp_hash_password( $secret );

			$record = array(
				'id'         => $credential_id,
				'hash'       => $hash,
				'created_at' => current_time( 'mysql', true ),
				'created_by' => $user_id,
				'revoked_at' => '',
				'revoked_by' => 0,
				'expires_at' => self::calculate_expiry(),
			);

			$credentials[] = $record;

			self::store_credentials( $assistant_id, $credentials );
			self::update_index( $credential_id, $assistant_id );

			WP_MCP_AI_Logger::log_event(
				'credential_issued',
				'Assistant credential issued.',
				array(
					'assistant_id'  => $assistant_id,
					'credential_id' => $credential_id,
					'user_id'       => $user_id,
				)
			);

			return array(
				'token'      => $credential_id . '.' . $secret,
				'credential' => $record,
			);
		}

		/**
		 * Revoke an existing credential.
		 *
		 * @param int    $assistant_id  Assistant post ID.
		 * @param string $credential_id Credential identifier.
		 * @param int    $user_id       Acting user ID.
		 * @return array|WP_Error Updated credential record on success.
		 */
		public static function revoke_credential( $assistant_id, $credential_id, $user_id ) {
			$assistant_id  = absint( $assistant_id );
			$credential_id = sanitize_key( $credential_id );
			$user_id       = absint( $user_id );

			if ( ! self::is_valid_assistant( $assistant_id ) ) {
				return new WP_Error( 'wp_mcp_ai_invalid_assistant', __( 'Unable to revoke the credential for the requested assistant.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( '' === $credential_id ) {
				return new WP_Error( 'wp_mcp_ai_unknown_credential', __( 'The requested credential could not be found.', 'nvdigital-open-operator-system-oos' ) );
			}

			$credentials = self::get_credentials( $assistant_id );

			foreach ( $credentials as $index => $credential ) {
				if ( $credential_id !== $credential['id'] ) {
					continue;
				}

				if ( ! empty( $credential['revoked_at'] ) ) {
					return new WP_Error( 'wp_mcp_ai_credential_already_revoked', __( 'The credential has already been revoked.', 'nvdigital-open-operator-system-oos' ) );
				}

				$credentials[ $index ]['revoked_at'] = current_time( 'mysql', true );
				$credentials[ $index ]['revoked_by'] = $user_id;

				self::store_credentials( $assistant_id, $credentials );

				WP_MCP_AI_Logger::log_event(
					'credential_revoked',
					'Assistant credential revoked.',
					array(
						'assistant_id'  => $assistant_id,
						'credential_id' => $credential_id,
						'user_id'       => $user_id,
					)
				);

				return $credentials[ $index ];
			}

			return new WP_Error( 'wp_mcp_ai_unknown_credential', __( 'The requested credential could not be found.', 'nvdigital-open-operator-system-oos' ) );
		}

		/**
		 * Permanently delete a credential.
		 *
		 * @param int    $assistant_id  Assistant post ID.
		 * @param string $credential_id Credential identifier.
		 * @param int    $user_id       Acting user ID.
		 * @return array|WP_Error Deleted credential record on success.
		 */
		public static function delete_credential( $assistant_id, $credential_id, $user_id ) {
			$assistant_id  = absint( $assistant_id );
			$credential_id = sanitize_key( $credential_id );
			$user_id       = absint( $user_id );

			if ( ! self::is_valid_assistant( $assistant_id ) ) {
				return new WP_Error( 'wp_mcp_ai_invalid_assistant', __( 'Unable to delete the credential for the requested assistant.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( '' === $credential_id ) {
				return new WP_Error( 'wp_mcp_ai_unknown_credential', __( 'The requested credential could not be found.', 'nvdigital-open-operator-system-oos' ) );
			}

			$credentials = self::get_credentials( $assistant_id );

			foreach ( $credentials as $index => $credential ) {
				if ( $credential_id !== $credential['id'] ) {
					continue;
				}

				$deleted = $credential;
				unset( $credentials[ $index ] );

				self::store_credentials( $assistant_id, array_values( $credentials ) );
				self::remove_from_index( $credential_id );

				WP_MCP_AI_Logger::log_event(
					'credential_deleted',
					'Assistant credential deleted.',
					array(
						'assistant_id'  => $assistant_id,
						'credential_id' => $credential_id,
						'user_id'       => $user_id,
					)
				);

				return $deleted;
			}

			return new WP_Error( 'wp_mcp_ai_unknown_credential', __( 'The requested credential could not be found.', 'nvdigital-open-operator-system-oos' ) );
		}

		/**
		 * Validate a credential token.
		 *
		 * @param string   $token          Raw token.
		 * @param int|null $assistant_hint Optional assistant ID hint from the request.
		 * @return array|WP_Error Credential metadata when valid.
		 */
		public static function validate_token( $token, $assistant_hint = null ) {
			$parsed = self::parse_token( $token );
			if ( null === $parsed ) {
				return new WP_Error( 'wp_mcp_ai_invalid_token', __( 'The provided credential token is invalid.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 401 ) );
			}

			list( $credential_id, $secret ) = $parsed;

			$assistant_ids = array();
			$hint_id       = absint( $assistant_hint );
			if ( $hint_id ) {
				$assistant_ids[] = $hint_id;
			}

			$index = self::get_index();
			if ( isset( $index[ $credential_id ] ) ) {
				$assistant_ids[] = absint( $index[ $credential_id ] );
			}

			$assistant_ids = array_values( array_unique( array_filter( $assistant_ids ) ) );

			if ( empty( $assistant_ids ) ) {
				return new WP_Error( 'wp_mcp_ai_invalid_token', __( 'The provided credential token is invalid.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 401 ) );
			}

			foreach ( $assistant_ids as $assistant_id ) {
				$credentials = self::get_credentials( $assistant_id );
				foreach ( $credentials as $credential ) {
					if ( $credential_id !== $credential['id'] ) {
						continue;
					}

					if ( ! empty( $credential['revoked_at'] ) ) {
						return new WP_Error( 'wp_mcp_ai_revoked_token', __( 'This credential has been revoked.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 401 ) );
					}

					// Check expiry (1.2.0). Credentials issued before this field
					// existed will have no expires_at and are treated as non-expiring.
					if ( ! empty( $credential['expires_at'] ) ) {
						$expires_at = strtotime( $credential['expires_at'] );
						if ( false !== $expires_at && time() > $expires_at ) {
							return new WP_Error(
								'wp_mcp_ai_expired_token',
								__( 'This credential has expired. Please generate a new credential.', 'nvdigital-open-operator-system-oos' ),
								array( 'status' => 401 )
							);
						}
					}

					if ( wp_check_password( $secret, $credential['hash'] ) ) {
						return array(
							'assistant_id'  => $assistant_id,
							'credential_id' => $credential['id'],
							'created_at'    => $credential['created_at'],
							'created_by'    => $credential['created_by'],
						);
					}

					return new WP_Error( 'wp_mcp_ai_invalid_token', __( 'The provided credential token is invalid.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 401 ) );
				}
			}

			return new WP_Error( 'wp_mcp_ai_invalid_token', __( 'The provided credential token is invalid.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 401 ) );
		}

		/**
		 * Remove all credential mappings for an assistant from the index.
		 *
		 * @param int $assistant_id Assistant post ID.
		 */
		public static function purge_assistant_credentials( $assistant_id ) {
			$assistant_id = absint( $assistant_id );

			if ( ! $assistant_id ) {
				return;
			}

			$credentials = self::get_credentials( $assistant_id );

			if ( empty( $credentials ) ) {
				return;
			}

			foreach ( $credentials as $credential ) {
				if ( empty( $credential['id'] ) ) {
					continue;
				}

				self::remove_from_index( $credential['id'] );
			}
		}

		/**
		 * Normalize an array of stored credential records.
		 *
		 * @param array $credentials Raw credential array.
		 * @return array
		 */
		protected static function normalize_credentials( $credentials ) {
			$normalized = array();

			foreach ( $credentials as $credential ) {
				if ( ! is_array( $credential ) ) {
					continue;
				}

				$id   = isset( $credential['id'] ) ? sanitize_key( $credential['id'] ) : '';
				$hash = isset( $credential['hash'] ) ? (string) $credential['hash'] : '';

				if ( '' === $id || '' === $hash ) {
					continue;
				}

				// IMPORTANT: any new field added to the issued record in
				// issue_credential() MUST be carried through here. Dropping a
				// field causes silent data loss on every read-modify-write
				// round-trip (revoke/delete rewrites the whole meta array).
				$normalized[] = array(
					'id'         => $id,
					'hash'       => $hash,
					'created_at' => isset( $credential['created_at'] ) ? sanitize_text_field( $credential['created_at'] ) : '',
					'created_by' => isset( $credential['created_by'] ) ? absint( $credential['created_by'] ) : 0,
					'revoked_at' => isset( $credential['revoked_at'] ) ? sanitize_text_field( $credential['revoked_at'] ) : '',
					'revoked_by' => isset( $credential['revoked_by'] ) ? absint( $credential['revoked_by'] ) : 0,
					'expires_at' => isset( $credential['expires_at'] ) ? sanitize_text_field( $credential['expires_at'] ) : '',
				);
			}

			return $normalized;
		}

		/**
		 * Persist credentials to post meta.
		 *
		 * @param int   $assistant_id Assistant post ID.
		 * @param array $credentials  Credential list.
		 */
		protected static function store_credentials( $assistant_id, $credentials ) {
			update_post_meta( $assistant_id, self::META_KEY, array_values( $credentials ) );
		}

		/**
		 * Repair credential records that lost their expiry date.
		 *
		 * Versions before 1.1.44 dropped `expires_at` during the
		 * normalize_credentials() round-trip that revoke_credential() and
		 * delete_credential() perform. Any credential record created after
		 * the expiry feature shipped (1.2.0) that is missing `expires_at`
		 * has it recomputed from `created_at + credential_lifetime_days`.
		 *
		 * Idempotent: safe to run multiple times. Revoked credentials are
		 * skipped — there is no value in extending a dead token.
		 *
		 * @since 1.1.44
		 *
		 * @return array { @type int $scanned @type int $repaired }
		 */
		public static function repair_missing_expiry() {
			$assistant_ids = get_posts(
				array(
					'post_type'      => self::ASSISTANT_POST_TYPE,
					'post_status'    => 'any',
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'meta_key'       => self::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One-shot upgrade repair routine; bounded by assistant count.
				)
			);

			$scanned  = 0;
			$repaired = 0;

			$days = 90;
			if ( function_exists( 'wp_mcp_ai_get_settings_repository' ) ) {
				$days = absint( wp_mcp_ai_get_settings_repository()->get( 'credential_lifetime_days', 90 ) );
			}

			// A zero/negative lifetime means credentials do not expire by policy.
			if ( $days <= 0 ) {
				return array(
					'scanned'  => 0,
					'repaired' => 0,
				);
			}

			foreach ( $assistant_ids as $assistant_id ) {
				$credentials = self::get_credentials( $assistant_id );

				if ( empty( $credentials ) ) {
					continue;
				}

				$changed = false;

				foreach ( $credentials as $index => $credential ) {
					++$scanned;

					if ( ! empty( $credential['expires_at'] ) || ! empty( $credential['revoked_at'] ) ) {
						continue;
					}

					$created_at = isset( $credential['created_at'] ) ? strtotime( $credential['created_at'] ) : false;
					if ( false === $created_at ) {
						continue;
					}

					$credentials[ $index ]['expires_at'] = gmdate( 'Y-m-d H:i:s', $created_at + ( $days * DAY_IN_SECONDS ) );
					$changed                             = true;
					++$repaired;
				}

				if ( $changed ) {
					self::store_credentials( $assistant_id, $credentials );
				}
			}

			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event(
					'credential_expiry_repair',
					'Credential expiry repair routine completed.',
					array(
						'scanned'  => $scanned,
						'repaired' => $repaired,
					)
				);
			}

			return array(
				'scanned'  => $scanned,
				'repaired' => $repaired,
			);
		}

		/**
		 * Determine whether an assistant ID is valid.
		 *
		 * @param int $assistant_id Assistant post ID.
		 * @return bool
		 */
		protected static function is_valid_assistant( $assistant_id ) {
			if ( ! $assistant_id ) {
				return false;
			}

			return self::ASSISTANT_POST_TYPE === get_post_type( $assistant_id );
		}

		/**
		 * Generate a unique credential identifier.
		 *
		 * @param array $credentials Existing credentials.
		 * @return string
		 */
		protected static function generate_unique_id( $credentials ) {
			$existing = wp_list_pluck( $credentials, 'id' );

			do {
				$candidate = 'cred_' . strtolower( wp_generate_password( 12, false, false ) );
			} while ( in_array( $candidate, $existing, true ) );

			return $candidate;
		}

		/**
		 * Retrieve the credential index option.
		 *
		 * @return array
		 */
		protected static function get_index() {
			$index = get_option( self::INDEX_OPTION, array() );

			if ( ! is_array( $index ) ) {
				return array();
			}

			$clean = array();
			foreach ( $index as $credential_id => $assistant_id ) {
				$key = sanitize_key( $credential_id );
				if ( '' === $key ) {
					continue;
				}

				$clean[ $key ] = absint( $assistant_id );
			}

			return $clean;
		}

		/**
		 * Update the credential index with a new mapping.
		 *
		 * @param string $credential_id Credential identifier.
		 * @param int    $assistant_id  Assistant post ID.
		 */
		protected static function update_index( $credential_id, $assistant_id ) {
			$index                   = self::get_index();
			$index[ $credential_id ] = absint( $assistant_id );
			update_option( self::INDEX_OPTION, $index, false );
		}

		/**
		 * Remove a credential from the index.
		 *
		 * @param string $credential_id Credential identifier.
		 */
		protected static function remove_from_index( $credential_id ) {
			$index = self::get_index();

			if ( isset( $index[ $credential_id ] ) ) {
				unset( $index[ $credential_id ] );
				update_option( self::INDEX_OPTION, $index, false );
			}
		}
	}
}
