<?php
/**
 * JetEngine Custom Content Type registration for AI assistants.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ensure the AI assistants CCT exists and expose helper accessors.
 */
class WP_MCP_AI_JetEngine_Assistants_CCT {
	const SLUG = 'assistants';

	/**
	 * Base ID for meta field identifiers.
	 * Using 20000 range to avoid conflicts with other CCT fields.
	 */
	const FIELD_ID_BASE = 20000;

	/**
	 * Hook into JetEngine to provision the assistants content type.
	 */
	public static function bootstrap() {
		// Run after JetEngine initialises the Custom Content Types module but before.
		// the manager registers existing instances (priority 10).
		add_action( 'init', array( __CLASS__, 'maybe_register_cct' ), 0 );

		// Ensure data stores module is enabled when JetEngine is active.
		add_action( 'init', array( __CLASS__, 'maybe_enable_data_stores' ), 0 );
	}

	/**
	 * Retrieve the assistants CCT slug.
	 *
	 * @return string
	 */
	public static function get_slug() {
		return self::SLUG;
	}

	/**
	 * Retrieve the JetEngine item handler for the assistants content type.
	 *
	 * Consumers can use the returned handler similarly to `jet_engine()->cct->item_handler`
	 * when interacting with the assistants records programmatically.
	 *
	 * @return object|null
	 */
	public static function get_item_handler() {
		$module = self::get_cct_module();

		if ( ! $module ) {
			return null;
		}

		if ( empty( $module->manager ) ) {
			return null;
		}

		$instance = $module->manager->get_content_types( self::SLUG );

		if ( ! $instance ) {
			return null;
		}

		return $instance->get_item_handler();
	}

	/**
	 * Automatically enable the JetEngine data stores module if it's not already active.
	 */
	public static function maybe_enable_data_stores() {
		if ( ! function_exists( 'jet_engine' ) ) {
			return;
		}

		$engine = jet_engine();

		if ( empty( $engine->modules ) || ! method_exists( $engine->modules, 'is_module_active' ) ) {
			return;
		}

		// Check if data stores module is already active.
		if ( $engine->modules->is_module_active( 'data-stores' ) ) {
			return;
		}

		// Check if the module exists.
		if ( ! method_exists( $engine->modules, 'get_module' ) ) {
			return;
		}

		$module = $engine->modules->get_module( 'data-stores' );

		if ( ! $module ) {
			return;
		}

		// Activate the data stores module.
		if ( method_exists( $engine->modules, 'activate_module' ) ) {
			$engine->modules->activate_module( 'data-stores' );
		}
	}

	/**
	 * Register the assistants CCT if it is missing.
	 */
	public static function maybe_register_cct() {
		$module = self::get_cct_module();

		if ( ! $module ) {
			return;
		}

		if ( empty( $module->manager ) || empty( $module->manager->data ) ) {
			return;
		}

		if ( self::cct_exists( $module ) ) {
			return;
		}

		$data    = $module->manager->data;
		$request = self::get_registration_request();

		$data->set_request( $request );

		if ( method_exists( $data, 'sanitize_item_request' ) && ! $data->sanitize_item_request() ) {
			return;
		}

		$item = $data->sanitize_item_from_request();

		if ( empty( $item ) || ! is_array( $item ) ) {
			return;
		}

		$data->before_item_update( $item, true );

		$item_id = $data->update_item_in_db( $item );

		if ( ! $item_id ) {
			return;
		}

		$item['id'] = $item_id;

		$data->after_item_update( $item, true );

		if ( ! empty( $data->db ) && method_exists( $data->db, 'query_raw' ) ) {
			$data->db->query_raw( 'post_types' );
		}
	}

	/**
	 * Determine whether the assistants CCT already exists.
	 *
	 * @param \Jet_Engine\Modules\Custom_Content_Types\Module $module Module instance.
	 * @return bool
	 */
	protected static function cct_exists( $module ) {
		$data = $module->manager->data;

		if ( empty( $data->db ) ) {
			return false;
		}

		$records = $data->db->query(
			'post_types',
			array(
				'slug'   => self::SLUG,
				'status' => 'content-type',
			),
			null,
			false
		);

		return ! empty( $records );
	}

	/**
	 * Retrieve the JetEngine Custom Content Types module instance.
	 *
	 * @return \Jet_Engine\Modules\Custom_Content_Types\Module|null
	 */
	protected static function get_cct_module() {
		if ( ! function_exists( 'jet_engine' ) ) {
			return null;
		}

		$engine = jet_engine();

		if ( empty( $engine->modules ) || ! method_exists( $engine->modules, 'is_module_active' ) ) {
			return null;
		}

		if ( ! $engine->modules->is_module_active( 'custom-content-types' ) ) {
			return null;
		}

		$module_wrapper = $engine->modules->get_module( 'custom-content-types' );

		if ( empty( $module_wrapper ) || empty( $module_wrapper->instance ) ) {
			return null;
		}

		return $module_wrapper->instance;
	}

	/**
	 * Build the request payload used to register the content type.
	 *
	 * @return array
	 */
	protected static function get_registration_request() {
		$label = __( 'AI Assistants', 'mcp-ai-wpoos' );

		return array(
			'name'        => $label,
			'slug'        => self::SLUG,
			'args'        => self::get_cct_args( $label ),
			'meta_fields' => self::get_meta_fields(),
		);
	}

	/**
	 * Assemble the JetEngine arguments for the assistants CCT.
	 *
	 * @param string $label Human-readable label for the content type.
	 * @return array
	 */
	protected static function get_cct_args( $label ) {
		return array(
			'name'                => $label,
			'slug'                => self::SLUG,
			'position'            => '-1',
			'icon'                => 'dashicons-lightbulb',
			'capability'          => 'manage_options',
			'has_single'          => false,
			'create_index'        => true,
			'hide_field_names'    => false,
			'rest_get_enabled'    => true,
			'rest_put_enabled'    => true,
			'rest_post_enabled'   => true,
			'rest_delete_enabled' => true,
			'rest_get_access'     => 'manage_options',
			'rest_put_access'     => 'edit_posts',
			'rest_post_access'    => 'edit_posts',
			'rest_delete_access'  => 'edit_posts',
			'admin_columns'       => array(
				'_ID'         => array(
					'enabled'     => true,
					'prefix'      => '#',
					'is_sortable' => true,
					'is_num'      => true,
				),
				'title'       => array(
					'enabled'     => true,
					'is_sortable' => true,
				),
				'description' => array(
					'enabled'     => true,
					'is_sortable' => false,
				),
				'provider'    => array(
					'enabled'     => true,
					'is_sortable' => true,
				),
				'model'       => array(
					'enabled'     => true,
					'is_sortable' => false,
				),
				'cct_created' => array(
					'enabled'     => true,
					'is_sortable' => true,
				),
			),
		);
	}

	/**
	 * Define the assistants meta field configuration.
	 *
	 * @return array
	 */
	protected static function get_meta_fields() {
		$base_id = self::FIELD_ID_BASE;

		$fields = array(
			self::build_field(
				++$base_id,
				'title',
				__( 'Title', 'mcp-ai-wpoos' ),
				'text',
				array(
					'is_required' => true,
					'description' => __( 'Assistant display name.', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'description',
				__( 'Description', 'mcp-ai-wpoos' ),
				'textarea',
				array(
					'description' => __( 'Assistant description or purpose.', 'mcp-ai-wpoos' ),
					'rows'        => 4,
				)
			),
			self::build_field(
				++$base_id,
				'provider',
				__( 'Provider', 'mcp-ai-wpoos' ),
				'text',
				array(
					'description' => __( 'AI provider (e.g., openai, gemini, ollama).', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'model',
				__( 'Model', 'mcp-ai-wpoos' ),
				'text',
				array(
					'description' => __( 'Model identifier (e.g., gpt-4o-mini).', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'system_prompt',
				__( 'System Prompt', 'mcp-ai-wpoos' ),
				'textarea',
				array(
					'description' => __( 'System instructions for the assistant.', 'mcp-ai-wpoos' ),
					'rows'        => 8,
				)
			),
			self::build_field(
				++$base_id,
				'temperature',
				__( 'Temperature', 'mcp-ai-wpoos' ),
				'number',
				array(
					'min'         => 0,
					'max'         => 2,
					'step'        => 0.1,
					'description' => __( 'Sampling temperature (0-2).', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'tools',
				__( 'Tools', 'mcp-ai-wpoos' ),
				'textarea',
				array(
					'description' => __( 'JSON array of enabled tool slugs.', 'mcp-ai-wpoos' ),
					'rows'        => 4,
				)
			),
		);

		foreach ( $fields as &$field ) {
			$field['show_in_rest'] = true;
		}

		return $fields;
	}

	/**
	 * Utility to construct a JetEngine meta field definition.
	 *
	 * @param int    $id        Deterministic field identifier.
	 * @param string $name      Field slug.
	 * @param string $label     Field label.
	 * @param string $type      JetEngine field type.
	 * @param array  $overrides Optional overrides for the base configuration.
	 * @return array
	 */
	protected static function build_field( $id, $name, $label, $type, $overrides = array() ) {
		$field = array(
			'id'          => absint( $id ),
			'name'        => sanitize_key( $name ),
			'title'       => $label,
			'object_type' => 'field',
			'type'        => $type,
			'width'       => '100%',
			'isNested'    => false,
			'options'     => array(),
		);

		return array_merge( $field, $overrides );
	}
}

WP_MCP_AI_JetEngine_Assistants_CCT::bootstrap();
