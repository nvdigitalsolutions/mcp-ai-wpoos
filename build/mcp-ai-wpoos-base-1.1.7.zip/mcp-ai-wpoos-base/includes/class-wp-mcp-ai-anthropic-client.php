<?php
/**
 * Anthropic API client wrapper.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Anthropic_Client' ) ) {
	/**
	 * Provides a wrapper around Anthropic's Messages API endpoint.
	 */
	class WP_MCP_AI_Anthropic_Client {
		const API_ENDPOINT     = 'https://api.anthropic.com/v1/messages';
		const API_COUNT_TOKENS = 'https://api.anthropic.com/v1/messages/count_tokens';
		const API_VERSION      = '2023-06-01';
		const USER_AGENT       = 'WP-MCP-AI-Anthropic-Client/1.0';
		const DEFAULT_BASE_URL = 'https://api.anthropic.com/v1';

		/**
		 * Maximum image size in bytes (10MB).
		 * Anthropic API recommends images under 5MB for optimal performance.
		 */
		const MAX_IMAGE_SIZE_BYTES = 10485760; // 10 * 1024 * 1024.

		/**
		 * Base64 encoding overhead multiplier.
		 * Base64 encoding increases size by ~33%, so 1.37 accounts for the overhead
		 * plus some buffer for the data URL prefix.
		 */
		const BASE64_OVERHEAD_MULTIPLIER = 1.37;

		/**
		 * Maximum data URL length (calculated from MAX_IMAGE_SIZE_BYTES).
		 */
		const MAX_DATA_URL_LENGTH = 14369951; // MAX_IMAGE_SIZE_BYTES * BASE64_OVERHEAD_MULTIPLIER.

		/**
		 * Allowed image media types for Anthropic vision API.
		 */
		const ALLOWED_IMAGE_TYPES = array( 'jpeg', 'jpg', 'png', 'gif', 'webp' );

		/**
		 * Retrieve the configured API key.
		 *
		 * @return string
		 */
		public function get_api_key() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			return isset( $settings['anthropic_api_key'] ) ? $settings['anthropic_api_key'] : '';
		}

		/**
		 * Retrieve the configured model.
		 *
		 * @return string
		 */
		public function get_model() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			return isset( $settings['anthropic_model'] ) ? $settings['anthropic_model'] : '';
		}

		/**
		 * Retrieve the configured base URL for the Anthropic API.
		 *
		 * When a custom base URL is configured (e.g. for Claude Team/Enterprise
		 * or an Anthropic-compatible proxy), all requests are routed through it.
		 *
		 * @return string Base URL without trailing slash.
		 */
		public function get_base_url() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$base_url = isset( $settings['anthropic_base_url'] ) ? trim( $settings['anthropic_base_url'] ) : '';

			if ( '' === $base_url ) {
				$base_url = self::DEFAULT_BASE_URL;
			}

			return untrailingslashit( $base_url );
		}

		/**
		 * Resolve a full endpoint URL respecting any custom base URL.
		 *
		 * Replaces the default https://api.anthropic.com/v1 prefix with the configured
		 * base URL so that all requests honour custom proxy / enterprise endpoints.
		 *
		 * @param string $default_url The default Anthropic endpoint URL.
		 * @return string Resolved endpoint URL.
		 */
		public function resolve_endpoint( $default_url ) {
			$base_url = $this->get_base_url();

			if ( self::DEFAULT_BASE_URL === $base_url ) {
				return $default_url;
			}

			// Replace the default base with the custom base.
			$path = str_replace( self::DEFAULT_BASE_URL, '', $default_url );

			return $base_url . $path;
		}

		/**
		 * Build the standard HTTP request headers for Anthropic API calls.
		 *
		 * Includes x-api-key, anthropic-version, Content-Type headers.
		 * Follows Anthropic's API authentication standards including support
		 * for Team and Enterprise workspace API keys.
		 *
		 * @param string $api_key      API key for the x-api-key header.
		 * @param string $content_type Content-Type header value. Default 'application/json'.
		 * @return array Associative array of HTTP headers.
		 */
		public function build_request_headers( $api_key, $content_type = 'application/json' ) {
			$headers = array(
				'Content-Type'      => $content_type,
				'x-api-key'         => $api_key,
				'anthropic-version' => self::API_VERSION,
			);

			/**
			 * Filter the Anthropic request headers before sending.
			 *
			 * Allows third-party plugins to inject or modify headers for all
			 * Anthropic API requests (e.g. adding custom tracking or proxy headers).
			 *
			 * @since 2.6.0
			 *
			 * @param array  $headers  Associative array of HTTP headers.
			 * @param string $api_key  The API key being used.
			 */
			$headers = apply_filters( 'wp_mcp_ai_anthropic_request_headers', $headers, $api_key );

			return $headers;
		}

		/**
		 * Perform a chat completion request against Anthropic.
		 *
		 * @param array $messages Message payload to send to Anthropic.
		 * @param array $options  Additional options (model, temperature, max_tokens, timeout).
		 * @return array|WP_Error
		 */
		public function create_chat_completion( array $messages, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_anthropic_api_key',
					__( 'No Anthropic API key has been configured.', 'mcp-ai-wpoos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_anthropic_api_key' => __( 'Add an Anthropic API key in the NV oOS settings.', 'mcp-ai-wpoos' ),
						),
					)
				);
			}

			$model = $this->resolve_model( $options );

			if ( empty( $model ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_anthropic_model',
					__( 'No Anthropic model has been configured.', 'mcp-ai-wpoos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_anthropic_model' => __( 'Choose an Anthropic model in the NV oOS settings.', 'mcp-ai-wpoos' ),
						),
					)
				);
			}

			// Pre-flight TPM validation: truncate conversation if it exceeds the
			// model's tokens-per-minute limit to avoid an API rejection.
			$messages = $this->enforce_tpm_budget( $messages, $model, $options );
			if ( is_wp_error( $messages ) ) {
				return $messages;
			}

			$payload = $this->build_payload( $messages, $options );

			if ( is_wp_error( $payload ) ) {
				return $payload;
			}

			$payload['model'] = $model;

			$headers = $this->build_request_headers( $api_key );

			// Add anthropic-beta header when needed.
			$betas = $this->resolve_beta_features( $payload, $options );
			if ( ! empty( $betas ) ) {
				$headers['anthropic-beta'] = implode( ',', $betas );
			}

			$request_args = array(
				'headers' => $headers,
				'body'    => wp_json_encode( $payload ),
				'timeout' => $this->resolve_timeout( $options ),
			);

			WP_MCP_AI_Logger::log_event( 'anthropic_request', 'Sending request to Anthropic.', array( 'payload' => $this->obfuscate_request_for_log( $payload ) ) );

			$response = wp_remote_post( $this->resolve_endpoint( self::API_ENDPOINT ), $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Anthropic request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Anthropic API request failed to complete.', 'mcp-ai-wpoos' ),
					__( 'Anthropic', 'mcp-ai-wpoos' )
				);
			}

			$code     = wp_remote_retrieve_response_code( $response );
			$body     = wp_remote_retrieve_body( $response );
			$decoded  = json_decode( $body, true );
			$json_err = json_last_error();

			if ( JSON_ERROR_NONE !== $json_err ) {
				WP_MCP_AI_Logger::log_error( 'Failed to decode Anthropic response.', array( 'body' => $body ) );

				return new WP_Error( 'wp_mcp_ai_invalid_response', __( 'The Anthropic API returned malformed JSON.', 'mcp-ai-wpoos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Anthropic.', 'mcp-ai-wpoos' );
				$error_type    = isset( $decoded['error']['type'] ) ? sanitize_text_field( $decoded['error']['type'] ) : '';

				// Build structured error data with Anthropic-specific metadata.
				$error_data = array(
					'status' => $code,
					'body'   => $decoded,
				);

				// Anthropic-specific error codes for better downstream handling.
				$error_code = 'wp_mcp_ai_api_error';
				if ( 429 === $code ) {
					$error_code = 'wp_mcp_ai_rate_limit_exceeded';
					// Extract retry-after header if present.
					$retry_after = wp_remote_retrieve_header( $response, 'retry-after' );
					if ( ! empty( $retry_after ) ) {
						$error_data['retry_after'] = absint( $retry_after );
					}
					$error_data['actions'] = array(
						'rate_limit_info' => __( 'The Anthropic API rate limit has been exceeded. The request will be retried automatically, or try again in a few moments.', 'mcp-ai-wpoos' ),
					);
				} elseif ( 529 === $code || 'overloaded_error' === $error_type ) {
					$error_code            = 'wp_mcp_ai_overloaded';
					$error_data['actions'] = array(
						'overloaded_info' => __( 'The Anthropic API is temporarily overloaded. Please wait a moment and try again.', 'mcp-ai-wpoos' ),
					);
				} elseif ( 413 === $code || 'request_too_large' === $error_type ) {
					$error_code            = 'wp_mcp_ai_request_too_large';
					$error_data['actions'] = array(
						'request_too_large_info' => __( 'The request exceeds the model\'s context window. Try reducing the conversation length or switching to a model with a larger context window.', 'mcp-ai-wpoos' ),
					);
				}

				WP_MCP_AI_Logger::log_error(
					'Anthropic returned an error response.',
					array(
						'code'       => $code,
						'error_type' => $error_type,
						'body'       => $decoded,
					)
				);

				return new WP_Error(
					$error_code,
					$error_message,
					$error_data
				);
			}

			$normalized = $this->normalize_response( $decoded );

			if ( ! isset( $normalized['model'] ) && ! empty( $model ) ) {
				$normalized['model'] = $model;
			}

			WP_MCP_AI_Logger::log_event( 'anthropic_response', 'Anthropic request completed.', array( 'response' => $normalized ) );

			return $normalized;
		}

		/**
		 * Test the connection to Anthropic API.
		 *
		 * @return array|WP_Error
		 */
		public function test_connection() {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_anthropic_api_key',
					__( 'No Anthropic API key has been configured.', 'mcp-ai-wpoos' ),
					array( 'status' => 400 )
				);
			}

			// Send a minimal test request.
			$test_messages = array(
				array(
					'role'    => 'user',
					'content' => 'Hi',
				),
			);

			$result = $this->create_chat_completion(
				$test_messages,
				array(
					'model'      => $this->get_model() ? $this->get_model() : 'claude-3-haiku-20240307',
					'max_tokens' => 10,
				)
			);

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return array(
				'success' => true,
				'message' => __( 'Successfully connected to Anthropic.', 'mcp-ai-wpoos' ),
			);
		}

		/**
		 * Return the static list of supported Claude models.
		 *
		 * Anthropic does not expose a public REST endpoint to enumerate models, so a
		 * curated static list is returned instead. The list mirrors the models named
		 * in the Anthropic proposal (Claude 3 Haiku / Sonnet / Opus; Claude 4 Sonnet
		 * / Opus) plus the latest Sonnet snapshot used as the default.
		 *
		 * @param array $options Unused; reserved for future API-based enumeration.
		 * @return array Array of model objects with 'id', 'name', and 'context_window' keys.
		 */
		public function list_models( array $options = array() ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- $options reserved for future API-based enumeration.
			return array(
				array(
					'id'             => 'claude-3-haiku-20240307',
					'name'           => __( 'Claude 3 Haiku (fastest)', 'mcp-ai-wpoos' ),
					'context_window' => 200000,
				),
				array(
					'id'             => 'claude-3-5-sonnet-20241022',
					'name'           => __( 'Claude 3.5 Sonnet', 'mcp-ai-wpoos' ),
					'context_window' => 200000,
				),
				array(
					'id'             => 'claude-3-opus-20240229',
					'name'           => __( 'Claude 3 Opus', 'mcp-ai-wpoos' ),
					'context_window' => 200000,
				),
				array(
					'id'             => 'claude-haiku-4-5',
					'name'           => __( 'Claude Haiku 4.5 (fastest)', 'mcp-ai-wpoos' ),
					'context_window' => 200000,
				),
				array(
					'id'             => 'claude-sonnet-4-5',
					'name'           => __( 'Claude Sonnet 4.5', 'mcp-ai-wpoos' ),
					'context_window' => 200000,
				),
				array(
					'id'             => 'claude-sonnet-4-6',
					'name'           => __( 'Claude Sonnet 4.6 (recommended)', 'mcp-ai-wpoos' ),
					'context_window' => 200000,
				),
				array(
					'id'             => 'claude-opus-4-5',
					'name'           => __( 'Claude Opus 4.5', 'mcp-ai-wpoos' ),
					'context_window' => 200000,
				),
				array(
					'id'             => 'claude-opus-4-6',
					'name'           => __( 'Claude Opus 4.6 (most capable)', 'mcp-ai-wpoos' ),
					'context_window' => 200000,
				),
			);
		}

		/**
		 * Count input tokens for a given message list via Anthropic's token-counting endpoint.
		 *
		 * Uses `POST /v1/messages/count_tokens` which returns the number of input tokens
		 * without actually running inference, making it useful for cost estimation and
		 * context-window management.
		 *
		 * @param array $messages Chat messages in OpenAI-compatible format.
		 * @param array $options  Optional parameters:
		 *                        - model (string): Override the model used for counting.
		 *                        - system_prompt (string): System instruction included in count.
		 *                        - tools (array): Tool definitions to include in the count.
		 *                        - timeout (int): HTTP timeout in seconds.
		 * @return int|WP_Error Input token count or WP_Error on failure.
		 */
		public function count_tokens( array $messages, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_anthropic_api_key',
					__( 'No Anthropic API key has been configured.', 'mcp-ai-wpoos' ),
					array( 'status' => 400 )
				);
			}

			$model = $this->resolve_model( $options );

			// Build the payload — same structure as /v1/messages but without max_tokens.
			$payload = array(
				'model'    => $model,
				'messages' => array(),
			);

			// Add system prompt if provided.
			if ( ! empty( $options['system_prompt'] ) ) {
				$payload['system'] = wp_kses_post( (string) $options['system_prompt'] );
			}

			// Add tool definitions if provided.
			if ( ! empty( $options['tools'] ) ) {
				$payload['tools'] = $this->translate_tools_for_anthropic( (array) $options['tools'] );
			}

			// Format messages using the same helper as create_chat_completion.
			foreach ( $messages as $message ) {
				if ( ! is_array( $message ) ) {
					continue;
				}

				$role    = isset( $message['role'] ) ? sanitize_key( $message['role'] ) : 'user';
				$content = isset( $message['content'] ) ? $message['content'] : '';

				if ( 'system' === $role ) {
					if ( empty( $payload['system'] ) ) {
						$payload['system'] = wp_kses_post( (string) $content );
					}
					continue;
				}

				if ( ! in_array( $role, array( 'user', 'assistant' ), true ) ) {
					continue;
				}

				$normalized = $this->normalize_content_for_anthropic( $content );

				if ( ! empty( $normalized ) ) {
					$payload['messages'][] = array(
						'role'    => $role,
						'content' => $normalized,
					);
				}
			}

			if ( empty( $payload['messages'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_messages',
					__( 'At least one user or assistant message is required for token counting.', 'mcp-ai-wpoos' ),
					array( 'status' => 400 )
				);
			}

			$timeout = $this->resolve_timeout( $options );

			$request_args = array(
				'method'  => 'POST',
				'headers' => $this->build_request_headers( $api_key ),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $timeout,
			);

			WP_MCP_AI_Logger::log_event(
				'anthropic_count_tokens',
				'Counting tokens with Anthropic.',
				array(
					'model'         => $model,
					'message_count' => count( $payload['messages'] ),
				)
			);

			$response = wp_remote_post( $this->resolve_endpoint( self::API_COUNT_TOKENS ), $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error(
					'Anthropic count_tokens request failed.',
					array( 'error' => $response->get_error_message() )
				);

				return $response;
			}

			$code    = wp_remote_retrieve_response_code( $response );
			$body    = wp_remote_retrieve_body( $response );
			$decoded = json_decode( $body, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				return new WP_Error(
					'wp_mcp_ai_anthropic_count_tokens_invalid_response',
					__( 'Anthropic returned malformed JSON for token counting.', 'mcp-ai-wpoos' )
				);
			}

			if ( $code < 200 || $code >= 300 ) {
				$message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Anthropic token counting request failed.', 'mcp-ai-wpoos' );

				return new WP_Error(
					'wp_mcp_ai_anthropic_count_tokens_error',
					$message,
					array( 'status' => $code )
				);
			}

			if ( ! isset( $decoded['input_tokens'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_anthropic_count_tokens_missing',
					__( 'Anthropic count_tokens response did not include input_tokens.', 'mcp-ai-wpoos' )
				);
			}

			return absint( $decoded['input_tokens'] );
		}

		/**
		 * Resolve the model identifier for the request.
		 *
		 * @param array $options Request options.
		 * @return string
		 */
		protected function resolve_model( array $options ) {
			if ( ! empty( $options['model'] ) ) {
				return sanitize_text_field( $options['model'] );
			}

			$model = $this->get_model();

			if ( ! empty( $model ) ) {
				return $model;
			}

			return 'claude-3-5-sonnet-20241022';
		}

		/**
		 * Safety margin applied when truncating messages to fit within TPM budget.
		 *
		 * Using 80 % of the TPM limit leaves headroom for output tokens and
		 * overhead that the heuristic token estimator cannot capture precisely.
		 *
		 * This mirrors WP_MCP_AI_REST::TPM_SAFETY_MARGIN — keep in sync.
		 */
		const TPM_SAFETY_MARGIN = 0.8;

		/**
		 * Enforce TPM (tokens-per-minute) budget before dispatching to the API.
		 *
		 * If the estimated token count for the conversation exceeds the model's
		 * configured TPM limit the method automatically truncates older messages
		 * so the request fits. When truncation alone is not enough a WP_Error is
		 * returned so the caller can surface a meaningful message to the user.
		 *
		 * @param array  $messages Messages array (OpenAI-compatible format).
		 * @param string $model    Resolved model identifier.
		 * @param array  $options  Request options.
		 * @return array|WP_Error  Potentially truncated messages, or WP_Error.
		 */
		protected function enforce_tpm_budget( array $messages, $model, array $options ) {
			if ( ! class_exists( 'WP_MCP_AI_Token_Budget_Manager' ) ) {
				return $messages;
			}

			$max_output_tokens = isset( $options['max_tokens'] ) ? absint( $options['max_tokens'] ) : 0;

			// If max_output_tokens is not explicitly set, the calculate_budget method will
			// auto-reserve a percentage. For the initial validation, pass 0 so the budget
			// manager uses its model-aware defaults (which now cap against TPM).
			$tpm_validation = WP_MCP_AI_Token_Budget_Manager::validate_tpm_limit( $messages, $model, $max_output_tokens );

			if ( ! is_wp_error( $tpm_validation ) ) {
				return $messages;
			}

			// TPM exceeded — attempt automatic truncation.
			$tpm_limit     = WP_MCP_AI_Token_Budget_Manager::get_model_tpm_limit( $model );
			$target_tokens = $tpm_limit ? (int) ( $tpm_limit * self::TPM_SAFETY_MARGIN ) : 0;

			if ( $target_tokens <= 0 ) {
				// No usable TPM limit available; cannot truncate meaningfully.
				return $tpm_validation;
			}

			// If the explicit max_output_tokens is larger than what the TPM budget can
			// accommodate alongside input, cap it so we leave at least 50% of the budget
			// for input tokens. This prevents the output reservation from starving the
			// input budget (e.g. max_tokens=32000 with TPM=40000 would leave 0 for input).
			$max_output_for_budget = $max_output_tokens;
			if ( $max_output_for_budget > 0 && $max_output_for_budget > (int) ( $target_tokens * 0.5 ) ) {
				$max_output_for_budget = (int) ( $target_tokens * 0.5 );
				WP_MCP_AI_Logger::log_event(
					'anthropic_tpm_output_capped',
					'Capped max_output_tokens to fit within Anthropic TPM budget.',
					array(
						'model'               => $model,
						'original_max_tokens' => $max_output_tokens,
						'capped_max_tokens'   => $max_output_for_budget,
						'tpm_limit'           => $tpm_limit,
					)
				);
			}

			// Reserve room for the output tokens within the TPM budget.
			$input_target = $target_tokens;
			if ( $max_output_for_budget > 0 && $max_output_for_budget < $target_tokens ) {
				$input_target = $target_tokens - $max_output_for_budget;
			}

			// Ensure we have a reasonable minimum input budget.
			$input_target = max( 1024, $input_target );

			$messages = WP_MCP_AI_Token_Budget_Manager::truncate_messages( $messages, $model, $input_target );

			WP_MCP_AI_Logger::log_event(
				'anthropic_tpm_truncation',
				'Messages truncated to fit within Anthropic TPM budget.',
				array(
					'model'         => $model,
					'tpm_limit'     => $tpm_limit,
					'target_tokens' => $input_target,
					'message_count' => count( $messages ),
				)
			);

			// Re-validate after truncation — use the capped output value.
			$tpm_validation = WP_MCP_AI_Token_Budget_Manager::validate_tpm_limit( $messages, $model, $max_output_for_budget );

			if ( is_wp_error( $tpm_validation ) ) {
				WP_MCP_AI_Logger::log_error(
					'Anthropic TPM limit still exceeded after message truncation.',
					array(
						'model'         => $model,
						'tpm_limit'     => $tpm_limit,
						'target_tokens' => $input_target,
						'error'         => $tpm_validation->get_error_message(),
					)
				);
				return $tpm_validation;
			}

			return $messages;
		}

		/**
		 * Build the request payload sent to Anthropic.
		 *
		 * @param array $messages Chat messages.
		 * @param array $options  Request options.
		 * @return array|WP_Error
		 */
		protected function build_payload( array $messages, array $options ) {
			if ( empty( $messages ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_messages',
					__( 'No chat messages were provided for the request.', 'mcp-ai-wpoos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'review_request_payload' => __( 'Provide at least one user or system message before calling the API.', 'mcp-ai-wpoos' ),
						),
					)
				);
			}

			$anthropic_messages = array();
			$system_parts       = array();

			foreach ( $messages as $message ) {
				if ( ! is_array( $message ) ) {
					continue;
				}

				$role    = isset( $message['role'] ) ? sanitize_key( $message['role'] ) : 'user';
				$content = isset( $message['content'] ) ? $message['content'] : '';

				// System messages go into a separate field.
				if ( 'system' === $role ) {
					$text_parts = $this->normalize_segments_to_text( $content );
					if ( ! empty( $text_parts ) ) {
						$system_parts = array_merge( $system_parts, $text_parts );
					}
					continue;
				}

				// Tool result messages must be converted to Anthropic's tool_result format
				// and grouped under a user-role message.
				if ( 'tool' === $role ) {
					$tool_use_id    = isset( $message['tool_call_id'] ) ? sanitize_text_field( $message['tool_call_id'] ) : '';
					$result_content = is_string( $content ) ? $content : wp_json_encode( $content );

					$tool_result_block = array(
						'type'        => 'tool_result',
						'tool_use_id' => $tool_use_id,
						'content'     => $result_content,
					);

					// Detect failed tool executions and mark with is_error so Claude can
					// respond appropriately (e.g. retry, fallback, or explain the failure).
					// Check explicit flag first, then fall back to JSON-content inspection.
					$is_tool_error = ! empty( $message['is_error'] );
					if ( ! $is_tool_error && is_string( $result_content ) ) {
						$decoded_result = json_decode( $result_content, true );
						if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded_result ) ) {
							$is_tool_error = ! empty( $decoded_result['error'] ) || ! empty( $decoded_result['error_code'] );
						}
					}
					if ( $is_tool_error ) {
						$tool_result_block['is_error'] = true;
					}

					// Append to the previous user message if it is already a tool-result
					// user message (i.e. consecutive tool results from the same turn).
					$last_idx = count( $anthropic_messages ) - 1;
					if (
						$last_idx >= 0
						&& 'user' === $anthropic_messages[ $last_idx ]['role']
						&& is_array( $anthropic_messages[ $last_idx ]['content'] )
						&& ! empty( $anthropic_messages[ $last_idx ]['content'] )
						&& isset( $anthropic_messages[ $last_idx ]['content'][0]['type'] )
						&& 'tool_result' === $anthropic_messages[ $last_idx ]['content'][0]['type']
					) {
						$anthropic_messages[ $last_idx ]['content'][] = $tool_result_block;
					} else {
						$anthropic_messages[] = array(
							'role'    => 'user',
							'content' => array( $tool_result_block ),
						);
					}
					continue;
				}

				// Assistant messages may carry tool_calls (OpenAI format) from a previous
				// run_with_tools iteration. Convert them to Anthropic tool_use blocks.
				if ( 'assistant' === $role ) {
					$assistant_content = array();

					// Include text / image content.
					$normalized_content = $this->normalize_content_for_anthropic( $content );
					if ( ! empty( $normalized_content ) ) {
						if ( is_string( $normalized_content ) ) {
							$assistant_content[] = array(
								'type' => 'text',
								'text' => $normalized_content,
							);
						} elseif ( is_array( $normalized_content ) ) {
							foreach ( $normalized_content as $block ) {
								$assistant_content[] = $block;
							}
						}
					}

					// Convert tool_calls (OpenAI format) to Anthropic tool_use blocks.
					if ( ! empty( $message['tool_calls'] ) && is_array( $message['tool_calls'] ) ) {
						foreach ( $message['tool_calls'] as $tool_call ) {
							if ( ! isset( $tool_call['function']['name'] ) ) {
								continue;
							}

							$args = array();
							if ( isset( $tool_call['function']['arguments'] ) ) {
								$raw_args = $tool_call['function']['arguments'];
								if ( is_string( $raw_args ) ) {
									$decoded = json_decode( $raw_args, true );
									if ( JSON_ERROR_NONE === json_last_error() ) {
										$args = is_array( $decoded ) ? $decoded : array();
									}
								} elseif ( is_array( $raw_args ) ) {
									$args = $raw_args;
								}
							}

							$assistant_content[] = array(
								'type'  => 'tool_use',
								'id'    => isset( $tool_call['id'] ) ? sanitize_text_field( $tool_call['id'] ) : 'toolu_' . wp_generate_password( 16, false ),
								'name'  => sanitize_text_field( $tool_call['function']['name'] ),
								'input' => (object) $args,
							);
						}
					}

					if ( empty( $assistant_content ) ) {
						continue;
					}

					// Anthropic forbids consecutive messages with the same role.
					// Merge consecutive assistant messages to avoid API validation errors.
					// This can occur when conversation history stores an intermediate assistant
					// message (from the agentic loop) followed by the final assistant message.
					$last_idx = count( $anthropic_messages ) - 1;
					if (
						$last_idx >= 0
						&& 'assistant' === $anthropic_messages[ $last_idx ]['role']
						&& is_array( $anthropic_messages[ $last_idx ]['content'] )
					) {
						$anthropic_messages[ $last_idx ]['content'] = array_merge(
							$anthropic_messages[ $last_idx ]['content'],
							$assistant_content
						);
					} else {
						$anthropic_messages[] = array(
							'role'    => 'assistant',
							'content' => $assistant_content,
						);
					}
					continue;
				}

				// Default: user (or any other) message.
				$normalized_content = $this->normalize_content_for_anthropic( $content );

				if ( empty( $normalized_content ) ) {
					continue;
				}

				// Anthropic forbids consecutive messages with the same role.
				// Merge into the previous message when the roles match.
				$last_idx = count( $anthropic_messages ) - 1;
				if ( $last_idx >= 0 && $role === $anthropic_messages[ $last_idx ]['role'] ) {
					$prev_content = $anthropic_messages[ $last_idx ]['content'];
					if ( is_string( $prev_content ) && is_string( $normalized_content ) ) {
						$anthropic_messages[ $last_idx ]['content'] = $prev_content . "\n\n" . $normalized_content;
					} elseif ( is_array( $prev_content ) && is_array( $normalized_content ) ) {
						$anthropic_messages[ $last_idx ]['content'] = array_merge( $prev_content, $normalized_content );
					} elseif ( is_string( $prev_content ) && is_array( $normalized_content ) ) {
						$anthropic_messages[ $last_idx ]['content'] = array_merge(
							array(
								array(
									'type' => 'text',
									'text' => $prev_content,
								),
							),
							$normalized_content
						);
					} else {
						// prev is array, new is string.
						$anthropic_messages[ $last_idx ]['content'][] = array(
							'type' => 'text',
							'text' => $normalized_content,
						);
					}
				} else {
					$anthropic_messages[] = array(
						'role'    => $role,
						'content' => $normalized_content,
					);
				}
			}

			// Anthropic requires conversations to end with a user message.
			// Remove any trailing assistant messages to prevent the
			// "conversation must end with a user message" error.
			$last_msg = ! empty( $anthropic_messages ) ? end( $anthropic_messages ) : false;
			while ( $last_msg && 'assistant' === $last_msg['role'] ) {
				array_pop( $anthropic_messages );
				WP_MCP_AI_Logger::log_event(
					'anthropic_message_normalized',
					'Removed trailing assistant message to satisfy Anthropic API requirement that conversations end with a user message.'
				);
				$last_msg = ! empty( $anthropic_messages ) ? end( $anthropic_messages ) : false;
			}

			if ( empty( $anthropic_messages ) ) {
				return new WP_Error(
					'wp_mcp_ai_no_valid_messages',
					__( 'No valid messages found for the Anthropic request.', 'mcp-ai-wpoos' ),
					array( 'status' => 400 )
				);
			}

			$payload = array(
				'messages' => $anthropic_messages,
			);

			// Build combined system text.
			$system_text = '';
			if ( ! empty( $system_parts ) ) {
				$system_text = implode( "\n\n", $system_parts );
			}
			if ( ! empty( $options['system_prompt'] ) ) {
				$extra       = wp_kses_post( $options['system_prompt'] );
				$system_text = '' !== $system_text ? $system_text . "\n\n" . $extra : $extra;
			}

			if ( '' !== $system_text ) {
				// Use prompt caching when requested: send system as a content block with
				// cache_control so Anthropic can reuse the KV cache across turns.
				// 'ephemeral' = short-lived cache (5 min TTL) that drastically cuts
				// input token costs when the same system prompt is reused across calls.
				if ( ! empty( $options['cache_system_prompt'] ) ) {
					$payload['system'] = array(
						array(
							'type'          => 'text',
							'text'          => $system_text,
							'cache_control' => array( 'type' => 'ephemeral' ),
						),
					);
				} else {
					$payload['system'] = $system_text;
				}
			}

			// Set max_tokens (required by Anthropic).
			// Anthropic's max_tokens refers to the maximum output tokens the model should
			// generate. We cap this against the model's known output limit and, when a
			// TPM budget is active, ensure it does not consume the entire per-minute
			// allowance — leaving room for input tokens.
			if ( isset( $options['max_tokens'] ) && $options['max_tokens'] > 0 ) {
				$max_tokens = absint( $options['max_tokens'] );
			} else {
				$resource_mgr = WP_MCP_AI_Resource_Manager::instance();
				$max_tokens   = $resource_mgr->get_max_tokens();

				/**
				 * Filter the maximum tokens for Anthropic requests.
				 *
				 * @param int   $max_tokens The maximum tokens to use.
				 * @param array $options    Request options.
				 */
				$max_tokens = apply_filters( 'wp_mcp_ai_anthropic_max_tokens', $max_tokens, $options );
				$max_tokens = max( 1, absint( $max_tokens ) );
			}

			// Cap against the model's known maximum output limit.
			if ( class_exists( 'WP_MCP_AI_Token_Budget_Manager' ) ) {
				$resolved_model   = isset( $payload['model'] ) ? $payload['model'] : ( isset( $options['model'] ) ? $options['model'] : '' );
				$model_output_cap = WP_MCP_AI_Token_Budget_Manager::get_model_max_output_tokens( $resolved_model );
				if ( $model_output_cap > 0 && $max_tokens > $model_output_cap ) {
					$max_tokens = $model_output_cap;
				}

				// Ensure max_tokens does not consume the entire TPM budget.
				// Leave at least 50% of the TPM budget for input tokens.
				$tpm_limit = WP_MCP_AI_Token_Budget_Manager::get_model_tpm_limit( $resolved_model );
				if ( null !== $tpm_limit && $tpm_limit > 0 ) {
					$tpm_output_cap = (int) ( $tpm_limit * 0.5 );
					if ( $max_tokens > $tpm_output_cap ) {
						$max_tokens = max( 1024, $tpm_output_cap );
					}
				}
			}

			$payload['max_tokens'] = $max_tokens;

			// Add temperature if specified.
			if ( array_key_exists( 'temperature', $options ) && '' !== $options['temperature'] && null !== $options['temperature'] ) {
				$payload['temperature'] = (float) $options['temperature'];
			}

			// Add tools if specified (Anthropic format).
			if ( ! empty( $options['tools'] ) && is_array( $options['tools'] ) ) {
				$tools = $this->translate_tools_for_anthropic( $options['tools'] );
				if ( ! empty( $tools ) ) {
					// When prompt caching is enabled, mark the last tool definition with
					// cache_control so Anthropic can cache the entire tool block (saves
					// tokens on subsequent turns that use the same tool set).
					if ( ! empty( $options['cache_system_prompt'] ) ) {
						$last_tool_idx                            = count( $tools ) - 1;
						$tools[ $last_tool_idx ]['cache_control'] = array( 'type' => 'ephemeral' );
					}
					$payload['tools'] = $tools;
				}
			}

			// Add tool_choice if specified.
			// Supported values: 'auto' (default), 'any' (force tool use), 'none' (no tools),
			// or array with 'type' => 'tool' and 'name' => 'tool_name'.
			if ( isset( $options['tool_choice'] ) ) {
				$payload['tool_choice'] = $this->resolve_tool_choice( $options['tool_choice'] );
			}

			// Add extended thinking when a budget is specified.
			// See https://docs.anthropic.com/en/docs/build-with-claude/extended-thinking.
			if ( ! empty( $options['thinking_budget_tokens'] ) ) {
				$budget_tokens = absint( $options['thinking_budget_tokens'] );
				if ( $budget_tokens > 0 ) {
					$payload['thinking'] = array(
						'type'          => 'enabled',
						'budget_tokens' => $budget_tokens,
					);
					// Extended thinking requires temperature = 1 (Anthropic requirement).
					$payload['temperature'] = 1;
				}
			}

			return $payload;
		}

		/**
		 * Translate OpenAI-style tools to Anthropic format.
		 *
		 * @since 1.0.0
		 *
		 * @param array $tools Array of tool definitions in OpenAI format.
		 * @return array Array of tool definitions in Anthropic format.
		 */
		protected function translate_tools_for_anthropic( array $tools ) {
			$anthropic_tools = array();

			foreach ( $tools as $tool ) {
				if ( ! isset( $tool['function'] ) || ! is_array( $tool['function'] ) ) {
					continue;
				}

				$function = $tool['function'];
				if ( ! isset( $function['name'] ) ) {
					continue;
				}

				$anthropic_tool = array(
					'name'        => sanitize_text_field( $function['name'] ),
					'description' => isset( $function['description'] ) ? sanitize_text_field( $function['description'] ) : '',
				);

				// Add input schema if parameters are provided.
				if ( isset( $function['parameters'] ) && is_array( $function['parameters'] ) ) {
					$anthropic_tool['input_schema'] = $function['parameters'];
				}

				$anthropic_tools[] = $anthropic_tool;
			}

			return $anthropic_tools;
		}

		/**
		 * Normalize content segments to text fragments.
		 *
		 * @param mixed $segments Message segments.
		 * @return array
		 */
		protected function normalize_segments_to_text( $segments ) {
			if ( is_string( $segments ) || is_numeric( $segments ) ) {
				$text = trim( wp_kses_post( (string) $segments ) );

				return '' === $text ? array() : array( $text );
			}

			if ( ! is_array( $segments ) ) {
				return array();
			}

			$fragments = array();

			foreach ( $segments as $segment ) {
				if ( is_string( $segment ) || is_numeric( $segment ) ) {
					$text = trim( wp_kses_post( (string) $segment ) );
					if ( '' !== $text ) {
						$fragments[] = $text;
					}
					continue;
				}

				if ( ! is_array( $segment ) ) {
					continue;
				}

				$type = isset( $segment['type'] ) ? sanitize_key( $segment['type'] ) : 'text';

				switch ( $type ) {
					case 'input_text':
					case 'text':
						$text = '';
						if ( isset( $segment['text'] ) ) {
							$text = (string) $segment['text'];
						} elseif ( isset( $segment['content'] ) ) {
							$text = (string) $segment['content'];
						}
						$text = trim( wp_kses_post( $text ) );
						if ( '' !== $text ) {
							$fragments[] = $text;
						}
						break;

					default:
						if ( isset( $segment['text'] ) && '' !== $segment['text'] ) {
							$fragments[] = trim( wp_kses_post( (string) $segment['text'] ) );
						}
						break;
				}
			}

			return $fragments;
		}

		/**
		 * Normalize content for Anthropic's content format.
		 *
		 * @param mixed $content Message content.
		 * @return array|string Array of content blocks if images present, string otherwise.
		 */
		protected function normalize_content_for_anthropic( $content ) {
			// If it's a simple string, return it as-is.
			if ( is_string( $content ) || is_numeric( $content ) ) {
				$text = trim( wp_kses_post( (string) $content ) );
				return '' !== $text ? $text : '';
			}

			// If it's an array, check for images and convert to Anthropic content blocks.
			if ( is_array( $content ) ) {
				$content_blocks = array();
				$has_images     = false;

				foreach ( $content as $segment ) {
					// Handle string segments.
					if ( is_string( $segment ) || is_numeric( $segment ) ) {
						$text = trim( wp_kses_post( (string) $segment ) );
						if ( '' !== $text ) {
							$content_blocks[] = array(
								'type' => 'text',
								'text' => $text,
							);
						}
						continue;
					}

					// Handle array segments.
					if ( ! is_array( $segment ) ) {
						continue;
					}

					$type = isset( $segment['type'] ) ? sanitize_key( $segment['type'] ) : 'text';

					// Handle image types.
					if ( 'image' === $type || 'image_url' === $type ) {
						$image_block = $this->build_image_content_block( $segment );
						if ( null !== $image_block ) {
							$content_blocks[] = $image_block;
							$has_images       = true;
						}
						continue;
					}

					// Handle text types.
					if ( 'input_text' === $type || 'text' === $type ) {
						$text = '';
						if ( isset( $segment['text'] ) ) {
							$text = (string) $segment['text'];
						} elseif ( isset( $segment['content'] ) ) {
							$text = (string) $segment['content'];
						}
						$text = trim( wp_kses_post( $text ) );
						if ( '' !== $text ) {
							$content_blocks[] = array(
								'type' => 'text',
								'text' => $text,
							);
						}
						continue;
					}

					// Default: try to extract text.
					if ( isset( $segment['text'] ) && '' !== $segment['text'] ) {
						$text = trim( wp_kses_post( (string) $segment['text'] ) );
						if ( '' !== $text ) {
							$content_blocks[] = array(
								'type' => 'text',
								'text' => $text,
							);
						}
					}
				}

				// If we have images, return content blocks array.
				if ( $has_images && ! empty( $content_blocks ) ) {
					return $content_blocks;
				}

				// Otherwise, extract text and join (backward compatible).
				$text_parts = array();
				foreach ( $content_blocks as $block ) {
					if ( isset( $block['type'] ) && 'text' === $block['type'] && isset( $block['text'] ) ) {
						$text_parts[] = $block['text'];
					}
				}

				if ( ! empty( $text_parts ) ) {
					return implode( "\n\n", $text_parts );
				}
			}

			return '';
		}

		/**
		 * Build an image content block in Anthropic format.
		 *
		 * @param array $segment Image segment with image data.
		 * @return array|null Anthropic image block or null if invalid.
		 */
		protected function build_image_content_block( $segment ) {
			if ( ! is_array( $segment ) ) {
				return null;
			}

			$image_url  = '';
			$image_data = '';

			// Handle OpenAI-style image_url format.
			if ( isset( $segment['image_url'] ) ) {
				if ( is_string( $segment['image_url'] ) ) {
					$image_url = $segment['image_url'];
				} elseif ( is_array( $segment['image_url'] ) && isset( $segment['image_url']['url'] ) ) {
					$image_url = $segment['image_url']['url'];
				}
			} elseif ( isset( $segment['url'] ) ) {
				$image_url = $segment['url'];
			} elseif ( isset( $segment['data'] ) ) {
				$image_data = $segment['data'];
			}

			// Handle data: URLs.
			if ( ! empty( $image_url ) && 0 === strpos( $image_url, 'data:' ) ) {
				// Validate URL length to prevent memory exhaustion.
				if ( strlen( $image_url ) > self::MAX_DATA_URL_LENGTH ) {
					WP_MCP_AI_Logger::log_error( 'Data URL too large for image.', array( 'length' => strlen( $image_url ) ) );
					return null;
				}

				// Extract base64 data from data URL.
				$matches = array();
				if ( preg_match( '/^data:image\/(\w+);base64,(.+)$/', $image_url, $matches ) ) {
					$media_type = $matches[1];
					$image_data = $matches[2];

					// Validate media type.
					if ( in_array( strtolower( $media_type ), self::ALLOWED_IMAGE_TYPES, true ) ) {
						$media_type = $this->normalize_image_media_type( $media_type );

						return array(
							'type'   => 'image',
							'source' => array(
								'type'       => 'base64',
								'media_type' => 'image/' . $media_type,
								'data'       => $image_data,
							),
						);
					}
				}

				WP_MCP_AI_Logger::log_error( 'Invalid data URL format for image.', array( 'url' => substr( $image_url, 0, 100 ) ) );
				return null;
			}

			// Handle remote URLs - fetch and convert to base64.
			if ( ! empty( $image_url ) && ( 0 === strpos( $image_url, 'http://' ) || 0 === strpos( $image_url, 'https://' ) ) ) {
				$response = wp_remote_get(
					$image_url,
					array(
						'timeout'    => 30,
						'user-agent' => self::USER_AGENT,
					)
				);

				if ( is_wp_error( $response ) ) {
					WP_MCP_AI_Logger::log_error(
						'Failed to fetch remote image.',
						array(
							'url'   => $image_url,
							'error' => $response->get_error_message(),
						)
					);
					return null;
				}

				// Validate content length before retrieving body.
				$content_length = wp_remote_retrieve_header( $response, 'content-length' );
				if ( ! empty( $content_length ) && absint( $content_length ) > self::MAX_IMAGE_SIZE_BYTES ) {
					WP_MCP_AI_Logger::log_error(
						'Remote image too large.',
						array(
							'url'            => $image_url,
							'content_length' => $content_length,
						)
					);
					return null;
				}

				$body         = wp_remote_retrieve_body( $response );
				$content_type = wp_remote_retrieve_header( $response, 'content-type' );

				if ( empty( $body ) ) {
					WP_MCP_AI_Logger::log_error( 'Empty response body when fetching image.', array( 'url' => $image_url ) );
					return null;
				}

				// Validate actual body size as fallback.
				if ( strlen( $body ) > self::MAX_IMAGE_SIZE_BYTES ) {
					WP_MCP_AI_Logger::log_error(
						'Remote image body too large.',
						array(
							'url'  => $image_url,
							'size' => strlen( $body ),
						)
					);
					return null;
				}

				// Determine media type.
				$media_type = '';
				if ( ! empty( $content_type ) ) {
					// Extract main type from content-type header.
					$content_type_parts = explode( ';', $content_type );
					$main_type          = trim( $content_type_parts[0] );

					if ( 0 === strpos( $main_type, 'image/' ) ) {
						$media_type = str_replace( 'image/', '', $main_type );
					}
				}

				// Validate media type.
				if ( empty( $media_type ) || ! in_array( strtolower( $media_type ), self::ALLOWED_IMAGE_TYPES, true ) ) {
					WP_MCP_AI_Logger::log_error(
						'Unsupported image media type.',
						array(
							'url'        => $image_url,
							'media_type' => $media_type,
						)
					);
					return null;
				}

				$media_type = $this->normalize_image_media_type( $media_type );

				// Validate that encoded size won't exceed limits before encoding.
				$estimated_encoded_size = strlen( $body ) * self::BASE64_OVERHEAD_MULTIPLIER;
				if ( $estimated_encoded_size > self::MAX_DATA_URL_LENGTH ) {
					WP_MCP_AI_Logger::log_error(
						'Image size exceeds maximum allowed size after base64 encoding.',
						array(
							'url'               => $image_url,
							'body_size'         => strlen( $body ),
							'estimated_encoded' => $estimated_encoded_size,
							'max_allowed'       => self::MAX_DATA_URL_LENGTH,
						)
					);
					return null;
				}

				// Convert to base64.
				$image_data = base64_encode( $body ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- base64_encode used to encode binary image data for API transmission, not for obfuscation.

				return array(
					'type'   => 'image',
					'source' => array(
						'type'       => 'base64',
						'media_type' => 'image/' . $media_type,
						'data'       => $image_data,
					),
				);
			}

			// Handle raw base64 data.
			if ( ! empty( $image_data ) ) {
				$media_type = 'jpeg';
				if ( isset( $segment['media_type'] ) ) {
					$provided_type = sanitize_text_field( $segment['media_type'] );
					if ( 0 === strpos( $provided_type, 'image/' ) ) {
						$media_type = str_replace( 'image/', '', $provided_type );
					} else {
						$media_type = $provided_type;
					}
				} else {
					// Log warning when media type is assumed.
					WP_MCP_AI_Logger::log_event( 'anthropic_image_media_type_assumed', 'Media type not specified for base64 image data, assuming JPEG.' );
				}

				$media_type = $this->normalize_image_media_type( $media_type );

				// Validate media type (jpg already normalized to jpeg above).
				// Filter out 'jpg' from allowed types since it's normalized to 'jpeg'.
				$allowed_types_normalized = array_diff( self::ALLOWED_IMAGE_TYPES, array( 'jpg' ) );
				if ( in_array( $media_type, $allowed_types_normalized, true ) ) {
					return array(
						'type'   => 'image',
						'source' => array(
							'type'       => 'base64',
							'media_type' => 'image/' . $media_type,
							'data'       => $image_data,
						),
					);
				}

				WP_MCP_AI_Logger::log_error( 'Unsupported image media type for raw data.', array( 'media_type' => $media_type ) );
				return null;
			}

			WP_MCP_AI_Logger::log_error(
				'No valid image data found in segment.',
				array(
					'segment_type'   => isset( $segment['type'] ) ? $segment['type'] : 'unknown',
					'has_image_url'  => isset( $segment['image_url'] ),
					'has_url'        => isset( $segment['url'] ),
					'has_data'       => isset( $segment['data'] ),
					'has_media_type' => isset( $segment['media_type'] ),
				)
			);
			return null;
		}

		/**
		 * Normalize image media type for Anthropic API.
		 *
		 * Converts 'jpg' to 'jpeg' to match Anthropic's expected format.
		 *
		 * @param string $media_type The media type to normalize (e.g., 'jpg', 'jpeg', 'png').
		 * @return string The normalized media type.
		 */
		protected function normalize_image_media_type( $media_type ) {
			if ( 'jpg' === strtolower( $media_type ) ) {
				return 'jpeg';
			}
			return strtolower( $media_type );
		}

		/**
		 * Resolve the tool_choice value to Anthropic API format.
		 *
		 * Maps standard values ('auto', 'any', 'none') and OpenAI-style tool_choice
		 * arrays to the Anthropic API's tool_choice object format.
		 *
		 * @param mixed $tool_choice String ('auto'|'any'|'none') or array with 'type'/'name' keys.
		 * @return array Anthropic-formatted tool_choice object.
		 */
		protected function resolve_tool_choice( $tool_choice ) {
			if ( is_array( $tool_choice ) ) {
				// Already an array; ensure 'type' is set.
				if ( isset( $tool_choice['type'] ) ) {
					return $tool_choice;
				}
				// OpenAI-style: { type: 'function', function: { name: '...' } }.
				if ( isset( $tool_choice['function']['name'] ) ) {
					return array(
						'type' => 'tool',
						'name' => sanitize_text_field( $tool_choice['function']['name'] ),
					);
				}
				return array( 'type' => 'auto' );
			}

			$choice = sanitize_text_field( (string) $tool_choice );

			switch ( $choice ) {
				case 'required':
				case 'any':
					return array( 'type' => 'any' );
				case 'none':
					return array( 'type' => 'none' );
				default:
					return array( 'type' => 'auto' );
			}
		}

		/**
		 * Resolve required Anthropic beta features for a payload.
		 *
		 * Returns beta feature identifiers that must be sent in the
		 * 'anthropic-beta' request header for the given payload.
		 *
		 * @param array $payload The built request payload.
		 * @param array $options Original request options.
		 * @return string[] Beta feature identifiers.
		 */
		protected function resolve_beta_features( array $payload, array $options ) {
			$betas = array();

			// Prompt caching is GA on claude-3-5 and later but still requires the header
			// on older (claude-3-haiku, claude-3-sonnet) models.
			if ( ! empty( $options['cache_system_prompt'] ) ) {
				$betas[] = 'prompt-caching-2024-07-31';
			}

			// Token-efficient tools reduces the overhead tokens used by tool definitions,
			// which can cut input costs by up to 40% when many tools are attached.
			// Supported on Claude 3.5 Sonnet and later models.
			if ( ! empty( $payload['tools'] ) ) {
				$betas[] = 'token-efficient-tools-2025-02-19';
			}

			// Extended thinking requires the interleaved-thinking beta for models that
			// support it but have not yet promoted it to GA.
			if ( ! empty( $payload['thinking'] ) ) {
				$betas[] = 'interleaved-thinking-2025-05-14';
			}

			// Allow callers to pass additional betas via options.
			if ( ! empty( $options['anthropic_betas'] ) && is_array( $options['anthropic_betas'] ) ) {
				foreach ( $options['anthropic_betas'] as $beta ) {
					$beta = sanitize_text_field( (string) $beta );
					if ( '' !== $beta && ! in_array( $beta, $betas, true ) ) {
						$betas[] = $beta;
					}
				}
			}

			return $betas;
		}

		/**
		 * Resolve the timeout for the request.
		 *
		 * @param array $options Request options.
		 * @return int
		 */
		protected function resolve_timeout( array $options ) {
			$settings     = WP_MCP_AI_Admin_Settings::get_settings();
			$resource_mgr = WP_MCP_AI_Resource_Manager::instance();

			$timeout = isset( $settings['request_timeout'] ) ? absint( $settings['request_timeout'] ) : $resource_mgr->get_request_timeout();

			if ( isset( $options['timeout'] ) && $options['timeout'] ) {
				$timeout = max( 5, absint( $options['timeout'] ) );
			}

			return max( 5, $timeout );
		}

		/**
		 * Convert an Anthropic response to an OpenAI-style structure for downstream compatibility.
		 *
		 * @param array $response Decoded Anthropic response.
		 * @return array
		 */
		protected function normalize_response( array $response ) {
			$message    = array( 'role' => 'assistant' );
			$segments   = array();
			$tool_calls = array();

			// Extract content from Anthropic's response.
			$thinking_blocks = array();
			if ( isset( $response['content'] ) && is_array( $response['content'] ) ) {
				foreach ( $response['content'] as $block ) {
					if ( ! is_array( $block ) ) {
						continue;
					}

					$type = isset( $block['type'] ) ? sanitize_key( $block['type'] ) : '';

					if ( 'text' === $type && isset( $block['text'] ) ) {
						$segments[] = array(
							'type' => 'text',
							'text' => (string) $block['text'],
						);
					}

					// Collect extended thinking blocks.
					if ( 'thinking' === $type && isset( $block['thinking'] ) ) {
						$thinking_blocks[] = (string) $block['thinking'];
					}

					// Handle tool use blocks if present.
					if ( 'tool_use' === $type ) {
						$tool_call = $this->convert_anthropic_tool_use_to_tool_call( $block );
						if ( $tool_call ) {
							$tool_calls[] = $tool_call;
						}
					}
				}
			}

			if ( ! empty( $segments ) ) {
				$message['content'] = $segments;
			}

			if ( ! empty( $tool_calls ) ) {
				$message['tool_calls'] = $tool_calls;
			}

			// Expose thinking content separately so callers can display or log it.
			if ( ! empty( $thinking_blocks ) ) {
				$message['thinking'] = implode( "\n\n", $thinking_blocks );
			}

			$normalized = array(
				'choices'  => array(
					array(
						'index'   => 0,
						'message' => $message,
					),
				),
				'provider' => 'anthropic',
			);

			// Add finish reason if present.
			if ( isset( $response['stop_reason'] ) ) {
				$normalized['choices'][0]['finish_reason'] = $this->normalize_stop_reason( $response['stop_reason'] );
			}

			// Add usage metadata if present.
			if ( isset( $response['usage'] ) && is_array( $response['usage'] ) ) {
				$usage = array();

				if ( isset( $response['usage']['input_tokens'] ) ) {
					$usage['prompt_tokens'] = (int) $response['usage']['input_tokens'];
				}

				if ( isset( $response['usage']['output_tokens'] ) ) {
					$usage['completion_tokens'] = (int) $response['usage']['output_tokens'];
				}

				if ( isset( $usage['prompt_tokens'] ) && isset( $usage['completion_tokens'] ) ) {
					$usage['total_tokens'] = $usage['prompt_tokens'] + $usage['completion_tokens'];
				}

				if ( ! empty( $usage ) ) {
					$normalized['usage'] = $usage;
				}
			}

			// Add model if present.
			if ( isset( $response['model'] ) ) {
				$normalized['model'] = sanitize_text_field( $response['model'] );
			}

			return $normalized;
		}

		/**
		 * Convert Anthropic tool_use block to OpenAI-style tool call.
		 *
		 * @param array $tool_use Anthropic tool_use block.
		 * @return array|null
		 */
		protected function convert_anthropic_tool_use_to_tool_call( array $tool_use ) {
			if ( ! isset( $tool_use['name'] ) ) {
				return null;
			}

			$name = sanitize_text_field( $tool_use['name'] );
			$id   = isset( $tool_use['id'] ) ? sanitize_text_field( $tool_use['id'] ) : 'anthropic-' . uniqid();

			$args = isset( $tool_use['input'] ) && is_array( $tool_use['input'] ) ? $tool_use['input'] : array();

			return array(
				'id'       => $id,
				'type'     => 'function',
				'function' => array(
					'name'      => $name,
					'arguments' => wp_json_encode( $args ),
				),
			);
		}

		/**
		 * Normalize Anthropic stop_reason to OpenAI finish_reason.
		 *
		 * @param string $stop_reason Anthropic stop reason.
		 * @return string
		 */
		protected function normalize_stop_reason( $stop_reason ) {
			$stop_reason = sanitize_key( $stop_reason );

			switch ( $stop_reason ) {
				case 'end_turn':
					return 'stop';
				case 'max_tokens':
					return 'length';
				case 'stop_sequence':
					return 'stop';
				case 'tool_use':
					return 'tool_calls';
				default:
					return 'stop';
			}
		}

		/**
		 * Remove large payloads from the logged request.
		 *
		 * @param array $payload Request payload.
		 * @return array
		 */
		protected function obfuscate_request_for_log( array $payload ) {
			if ( isset( $payload['messages'] ) ) {
				$payload['messages'] = '[redacted]';
			}

			if ( isset( $payload['system'] ) ) {
				$payload['system'] = '[redacted]';
			}

			return $payload;
		}

		/**
		 * Execute a chat completion with tools and recursive tool execution.
		 *
		 * This method provides automatic tool execution in a loop for Anthropic.
		 * Note: Anthropic uses "tool use" terminology instead of "function calling".
		 *
		 * @since 1.0.0
		 *
		 * @param array $messages Array of conversation messages.
		 * @param array $tools    Array of tool definitions with executable functions.
		 * @param array $options  Optional configuration:
		 *                        - strictValidation (bool): Validate arguments before execution. Default: true.
		 *                        - maxRecursiveToolRuns (int): Maximum recursion depth. Default: 5.
		 *                        - streamFinalResponse (bool): Enable streaming (not implemented for PHP). Default: false.
		 *                        - verbose (bool): Detailed logging. Default: false.
		 *                        - autoTrimTools (bool): Context-based tool selection. Default: false.
		 *                        - maxTools (int): Max tools when trimming. Default: 10.
		 *                        - model, temperature, timeout, etc.
		 * @return array|WP_Error Final response or error.
		 * @throws Exception If tool function is not callable.
		 */
		public function run_with_tools( array $messages, array $tools = array(), array $options = array() ) {
			// Configuration options with defaults.
			$strict_validation     = isset( $options['strictValidation'] ) ? (bool) $options['strictValidation'] : true;
			$max_recursive_runs    = isset( $options['maxRecursiveToolRuns'] ) ? absint( $options['maxRecursiveToolRuns'] ) : 5;
			$stream_final_response = isset( $options['streamFinalResponse'] ) ? (bool) $options['streamFinalResponse'] : false;
			$verbose               = isset( $options['verbose'] ) ? (bool) $options['verbose'] : false;
			$auto_trim_tools       = isset( $options['autoTrimTools'] ) ? (bool) $options['autoTrimTools'] : false;

			if ( $verbose ) {
				WP_MCP_AI_Logger::log_event(
					'anthropic_run_with_tools_start',
					'Starting Anthropic embedded function calling.',
					array(
						'message_count'      => count( $messages ),
						'tool_count'         => count( $tools ),
						'strict_validation'  => $strict_validation,
						'max_recursive_runs' => $max_recursive_runs,
						'auto_trim_tools'    => $auto_trim_tools,
					)
				);
			}

			// Validate tools array.
			if ( empty( $tools ) ) {
				return new WP_Error(
					'wp_mcp_ai_no_tools',
					__( 'At least one tool must be provided for embedded function calling.', 'mcp-ai-wpoos' ),
					array( 'status' => 400 )
				);
			}

			// Auto-trim tools if enabled.
			if ( $auto_trim_tools ) {
				$tools = $this->auto_trim_tools( $messages, $tools, $options );
				if ( $verbose ) {
					WP_MCP_AI_Logger::log_event(
						'anthropic_auto_trim_tools',
						'Automatically trimmed tools based on context.',
						array( 'remaining_tool_count' => count( $tools ) )
					);
				}
			}

			// Convert tools to Anthropic format and create tool lookup.
			$tool_definitions = array();
			$tool_functions   = array();

			foreach ( $tools as $tool ) {
				if ( ! isset( $tool['name'] ) || ! isset( $tool['function'] ) ) {
					continue;
				}

				$tool_name = sanitize_text_field( $tool['name'] );

				// Build tool definition for API.
				$definition = array(
					'name'        => $tool_name,
					'description' => isset( $tool['description'] ) ? sanitize_text_field( $tool['description'] ) : '',
				);

				if ( isset( $tool['parameters'] ) && is_array( $tool['parameters'] ) ) {
					$definition['parameters'] = $tool['parameters'];
				}

				$tool_definitions[] = array(
					'type'     => 'function',
					'function' => $definition,
				);

				// Store executable function.
				$tool_functions[ $tool_name ] = $tool['function'];
			}

			// Prepare options with tools.
			$request_options          = $options;
			$request_options['tools'] = $tool_definitions;

			// Execute recursive tool calling loop.
			$conversation_messages = $messages;
			$recursion_count       = 0;

			while ( $recursion_count < $max_recursive_runs ) {
				++$recursion_count;

				if ( $verbose ) {
					WP_MCP_AI_Logger::log_event(
						'anthropic_tool_run_iteration',
						sprintf( 'Tool execution iteration %d/%d', $recursion_count, $max_recursive_runs ),
						array( 'message_count' => count( $conversation_messages ) )
					);
				}

				// Make API request.
				$response = $this->create_chat_completion( $conversation_messages, $request_options );

				if ( is_wp_error( $response ) ) {
					return $response;
				}

				// Check if model wants to call any tools.
				$tool_calls = array();
				if ( isset( $response['choices'][0]['message']['tool_calls'] ) ) {
					$tool_calls = $response['choices'][0]['message']['tool_calls'];
				}

				// If no tool calls, we're done.
				if ( empty( $tool_calls ) ) {
					if ( $verbose ) {
						WP_MCP_AI_Logger::log_event(
							'anthropic_run_with_tools_complete',
							'Completed without tool calls.',
							array( 'iterations' => $recursion_count )
						);
					}

					// Return final response.
					return $response;
				}

				// Add assistant's tool call message to conversation.
				$conversation_messages[] = $response['choices'][0]['message'];

				// Execute each tool call.
				foreach ( $tool_calls as $tool_call ) {
					if ( ! isset( $tool_call['function']['name'] ) ) {
						continue;
					}

					$function_name = $tool_call['function']['name'];
					$tool_call_id  = isset( $tool_call['id'] ) ? $tool_call['id'] : uniqid( 'tool-', true );

					// Check if function exists.
					if ( ! isset( $tool_functions[ $function_name ] ) ) {
						$error_message = sprintf(
							/* translators: %s: function name */
							__( 'Tool function "%s" not found.', 'mcp-ai-wpoos' ),
							$function_name
						);

						$conversation_messages[] = array(
							'role'         => 'tool',
							'tool_call_id' => $tool_call_id,
							'name'         => $function_name,
							'content'      => wp_json_encode( array( 'error' => $error_message ) ),
						);

						WP_MCP_AI_Logger::log_error(
							'Anthropic tool function not found.',
							array(
								'function_name' => $function_name,
								'tool_call_id'  => $tool_call_id,
							)
						);
						continue;
					}

					// Parse arguments.
					$arguments = array();
					if ( isset( $tool_call['function']['arguments'] ) ) {
						$args_json = $tool_call['function']['arguments'];
						if ( is_string( $args_json ) ) {
							$arguments = json_decode( $args_json, true );
							if ( JSON_ERROR_NONE !== json_last_error() ) {
								$arguments = array();
							}
						} elseif ( is_array( $args_json ) ) {
							$arguments = $args_json;
						}
					}

					// Validate arguments if strict validation is enabled.
					if ( $strict_validation ) {
						$validation_error = $this->validate_tool_arguments( $function_name, $arguments, $tool_definitions );
						if ( is_wp_error( $validation_error ) ) {
							$conversation_messages[] = array(
								'role'         => 'tool',
								'tool_call_id' => $tool_call_id,
								'name'         => $function_name,
								'content'      => wp_json_encode( array( 'error' => $validation_error->get_error_message() ) ),
							);

							WP_MCP_AI_Logger::log_error(
								'Anthropic tool argument validation failed.',
								array(
									'function_name' => $function_name,
									'error'         => $validation_error->get_error_message(),
								)
							);
							continue;
						}
					}

					// Execute the tool function.
					try {
						$function_callable = $tool_functions[ $function_name ];

						if ( ! is_callable( $function_callable ) ) {
							throw new Exception( 'Tool function is not callable.' );
						}

						$result = call_user_func( $function_callable, $arguments );

						// Convert result to JSON string.
						$result_content = is_string( $result ) ? $result : wp_json_encode( $result );

						$conversation_messages[] = array(
							'role'         => 'tool',
							'tool_call_id' => $tool_call_id,
							'name'         => $function_name,
							'content'      => $result_content,
						);

						if ( $verbose ) {
							WP_MCP_AI_Logger::log_event(
								'anthropic_tool_executed',
								sprintf( 'Executed tool: %s', $function_name ),
								array(
									'function_name' => $function_name,
									'tool_call_id'  => $tool_call_id,
									'result_length' => strlen( $result_content ),
								)
							);
						}
					} catch ( Exception $e ) {
						$error_message = $e->getMessage();

						$conversation_messages[] = array(
							'role'         => 'tool',
							'tool_call_id' => $tool_call_id,
							'name'         => $function_name,
							'content'      => wp_json_encode( array( 'error' => $error_message ) ),
						);

						WP_MCP_AI_Logger::log_error(
							'Anthropic tool execution failed.',
							array(
								'function_name' => $function_name,
								'error'         => $error_message,
							)
						);
					}
				}
			}

			// Max recursion reached.
			if ( $verbose ) {
				WP_MCP_AI_Logger::log_event(
					'anthropic_max_recursion_reached',
					'Maximum recursive tool runs reached.',
					array( 'max_runs' => $max_recursive_runs )
				);
			}

			return new WP_Error(
				'wp_mcp_ai_max_tool_recursion',
				__( 'Maximum recursive tool runs reached without completion.', 'mcp-ai-wpoos' ),
				array(
					'status'         => 500,
					'max_runs'       => $max_recursive_runs,
					'final_messages' => $conversation_messages,
				)
			);
		}

		/**
		 * Validate tool arguments against the tool definition schema.
		 *
		 * @since 1.0.0
		 *
		 * @param string $function_name    Name of the function being called.
		 * @param array  $arguments        Arguments provided by the model.
		 * @param array  $tool_definitions Array of tool definitions.
		 * @return true|WP_Error True if valid, WP_Error otherwise.
		 */
		protected function validate_tool_arguments( $function_name, $arguments, $tool_definitions ) {
			// Find the tool definition.
			$tool_schema = null;
			foreach ( $tool_definitions as $tool_def ) {
				if ( isset( $tool_def['function']['name'] ) && $tool_def['function']['name'] === $function_name ) {
					$tool_schema = isset( $tool_def['function']['parameters'] ) ? $tool_def['function']['parameters'] : null;
					break;
				}
			}

			if ( null === $tool_schema ) {
				return true; // No schema to validate against.
			}

			// Check required parameters.
			if ( isset( $tool_schema['required'] ) && is_array( $tool_schema['required'] ) ) {
				foreach ( $tool_schema['required'] as $required_param ) {
					if ( ! isset( $arguments[ $required_param ] ) ) {
						return new WP_Error(
							'wp_mcp_ai_missing_required_param',
							sprintf(
								/* translators: %1$s: parameter name, %2$s: function name */
								__( 'Required parameter "%1$s" missing for tool "%2$s".', 'mcp-ai-wpoos' ),
								$required_param,
								$function_name
							),
							array( 'parameter' => $required_param )
						);
					}
				}
			}

			// Validate parameter types.
			if ( isset( $tool_schema['properties'] ) && is_array( $tool_schema['properties'] ) ) {
				foreach ( $arguments as $param_name => $param_value ) {
					if ( ! isset( $tool_schema['properties'][ $param_name ] ) ) {
						continue;
					}

					$param_schema = $tool_schema['properties'][ $param_name ];
					if ( ! isset( $param_schema['type'] ) ) {
						continue;
					}

					$expected_type = $param_schema['type'];
					$actual_type   = gettype( $param_value );

					$type_map = array(
						'boolean' => 'boolean',
						'integer' => 'number',
						'double'  => 'number',
						'string'  => 'string',
						'array'   => 'array',
						'object'  => 'object',
						'NULL'    => 'null',
					);

					$mapped_type = isset( $type_map[ $actual_type ] ) ? $type_map[ $actual_type ] : $actual_type;

					if ( 'number' === $expected_type && in_array( $mapped_type, array( 'number', 'integer' ), true ) ) {
						continue;
					}

					if ( $expected_type !== $mapped_type ) {
						return new WP_Error(
							'wp_mcp_ai_invalid_param_type',
							sprintf(
								/* translators: %1$s: parameter name, %2$s: expected type, %3$s: actual type */
								__( 'Parameter "%1$s" expected type "%2$s" but got "%3$s".', 'mcp-ai-wpoos' ),
								$param_name,
								$expected_type,
								$mapped_type
							),
							array(
								'parameter'     => $param_name,
								'expected_type' => $expected_type,
								'actual_type'   => $mapped_type,
							)
						);
					}
				}
			}

			return true;
		}

		/**
		 * Automatically trim tools based on context to reduce token usage.
		 *
		 * @since 1.0.0
		 *
		 * @param array $messages Message history.
		 * @param array $tools    Array of tool definitions.
		 * @param array $options  Request options.
		 * @return array Trimmed tools array.
		 */
		protected function auto_trim_tools( $messages, $tools, $options = array() ) {
			// Get the last user message.
			$last_user_message = '';
			for ( $i = count( $messages ) - 1; $i >= 0; $i-- ) {
				if ( isset( $messages[ $i ]['role'] ) && 'user' === $messages[ $i ]['role'] ) {
					$last_user_message = isset( $messages[ $i ]['content'] ) ? strtolower( (string) $messages[ $i ]['content'] ) : '';
					break;
				}
			}

			if ( empty( $last_user_message ) || empty( $tools ) ) {
				return $tools;
			}

			// Score each tool.
			$scored_tools = array();
			foreach ( $tools as $tool ) {
				$score = 0;

				if ( isset( $tool['name'] ) ) {
					$tool_name  = strtolower( str_replace( array( '-', '_' ), ' ', $tool['name'] ) );
					$name_words = explode( ' ', $tool_name );
					foreach ( $name_words as $word ) {
						if ( ! empty( $word ) && false !== strpos( $last_user_message, $word ) ) {
							$score += 3;
						}
					}
				}

				if ( isset( $tool['description'] ) ) {
					$tool_desc  = strtolower( $tool['description'] );
					$desc_words = explode( ' ', $tool_desc );
					foreach ( $desc_words as $word ) {
						if ( strlen( $word ) > 3 && false !== strpos( $last_user_message, $word ) ) {
							++$score;
						}
					}
				}

				$scored_tools[] = array(
					'tool'  => $tool,
					'score' => $score,
				);
			}

			usort(
				$scored_tools,
				function ( $a, $b ) {
					return $b['score'] - $a['score'];
				}
			);

			$max_tools     = isset( $options['maxTools'] ) ? absint( $options['maxTools'] ) : 10;
			$trimmed_tools = array();

			foreach ( array_slice( $scored_tools, 0, $max_tools ) as $scored ) {
				if ( $scored['score'] > 0 || count( $trimmed_tools ) < 3 ) {
					$trimmed_tools[] = $scored['tool'];
				}
			}

			if ( empty( $trimmed_tools ) ) {
				return $tools;
			}

			return $trimmed_tools;
		}
	}
}
