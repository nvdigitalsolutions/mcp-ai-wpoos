<?php
/**
 * OpenRouter API client wrapper.
 *
 * OpenRouter exposes an OpenAI-compatible REST API at
 * https://openrouter.ai/api/v1.  It acts as a unified gateway in front of many
 * upstream providers (OpenAI, Anthropic, Meta, Google, Mistral, etc.) and is
 * accessed through a single API key.
 *
 * Best-practice headers per the OpenRouter documentation:
 *  - `HTTP-Referer`: identifies the calling application on the OpenRouter
 *    leaderboard / dashboard. Defaults to `home_url()`.
 *  - `X-Title`: human-readable application name shown alongside the referer.
 *
 * @link    https://openrouter.ai/docs/api-reference/overview
 * @link    https://openrouter.ai/docs/quickstart
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_OpenRouter_Client' ) ) {
	/**
	 * Provides a wrapper around the OpenRouter API (OpenAI-compatible).
	 *
	 * Supports chat completions, tool/function calling, JSON mode, streaming
	 * (SSE identical to OpenAI), and live model listing.
	 *
	 * Note on embeddings: OpenRouter does not currently expose a public
	 * embeddings endpoint.  No `WP_MCP_AI_Embedding_Provider_OpenRouter` is
	 * registered.
	 */
	class WP_MCP_AI_OpenRouter_Client {

		/**
		 * Default base URL for the OpenRouter API (no trailing slash).
		 *
		 * The base URL already includes `/api/v1` so endpoint constants below
		 * are appended directly.
		 *
		 * @var string
		 */
		const DEFAULT_BASE_URL = 'https://openrouter.ai/api/v1';

		/**
		 * Chat completions path relative to the base URL.
		 *
		 * @var string
		 */
		const API_ENDPOINT = '/chat/completions';

		/**
		 * Model listing path relative to the base URL.
		 *
		 * @var string
		 */
		const API_MODELS = '/models';

		/**
		 * User-Agent string sent with every request.
		 *
		 * @var string
		 */
		const USER_AGENT = 'WP-MCP-AI-OpenRouter-Client/1.0';

		/**
		 * Default chat model when none is configured.
		 *
		 * `openrouter/auto` lets OpenRouter pick a recommended model — this is
		 * the safest default because OpenRouter rotates which providers are
		 * available behind it.  Operators are encouraged to choose an explicit
		 * model in the settings screen for predictable cost / behaviour.
		 *
		 * @var string
		 */
		const DEFAULT_MODEL = 'openrouter/auto';

		// -------------------------------------------------------------------------
		// Accessors.
		// -------------------------------------------------------------------------

		/**
		 * Retrieve the configured OpenRouter API key.
		 *
		 * @return string Empty string when not configured.
		 */
		public function get_api_key() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			return isset( $settings['openrouter_api_key'] ) ? $settings['openrouter_api_key'] : '';
		}

		/**
		 * Retrieve the configured default model.
		 *
		 * @return string Empty string when not configured.
		 */
		public function get_model() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			return isset( $settings['openrouter_model'] ) ? $settings['openrouter_model'] : '';
		}

		/**
		 * Retrieve the configured base URL.
		 *
		 * Supports custom proxies via the `openrouter_base_url` setting.
		 * Falls back to {@see DEFAULT_BASE_URL}.
		 *
		 * @return string Base URL without trailing slash.
		 */
		public function get_base_url() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$base_url = isset( $settings['openrouter_base_url'] ) ? trim( $settings['openrouter_base_url'] ) : '';

			if ( '' === $base_url ) {
				$base_url = self::DEFAULT_BASE_URL;
			}

			return untrailingslashit( $base_url );
		}

		/**
		 * Retrieve the value sent in the `HTTP-Referer` header.
		 *
		 * Defaults to the WordPress site's `home_url()` when no override is
		 * configured.  OpenRouter uses this string to identify which
		 * application made the request on its leaderboard / dashboard.
		 *
		 * @return string
		 */
		public function get_site_url() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$site_url = isset( $settings['openrouter_site_url'] ) ? trim( $settings['openrouter_site_url'] ) : '';

			if ( '' === $site_url && function_exists( 'home_url' ) ) {
				$site_url = home_url( '/' );
			}

			return esc_url_raw( $site_url );
		}

		/**
		 * Retrieve the value sent in the `X-Title` header.
		 *
		 * Defaults to the WordPress site name (`get_bloginfo( 'name' )`).
		 *
		 * @return string
		 */
		public function get_app_title() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$title    = isset( $settings['openrouter_app_title'] ) ? trim( $settings['openrouter_app_title'] ) : '';

			if ( '' === $title && function_exists( 'get_bloginfo' ) ) {
				$title = get_bloginfo( 'name' );
			}

			if ( '' === $title ) {
				$title = 'NV oOS';
			}

			return sanitize_text_field( $title );
		}

		// -------------------------------------------------------------------------
		// HTTP helpers.
		// -------------------------------------------------------------------------

		/**
		 * Build standard HTTP request headers for OpenRouter API calls.
		 *
		 * @param string $api_key API key to authorise the request.
		 * @return array Associative array of HTTP headers.
		 */
		protected function build_request_headers( $api_key ) {
			$headers = array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $api_key,
				'User-Agent'    => self::USER_AGENT,
				'HTTP-Referer'  => $this->get_site_url(),
				'X-Title'       => $this->get_app_title(),
			);

			/**
			 * Filter the OpenRouter request headers before sending.
			 *
			 * @since 2026.05
			 *
			 * @param array  $headers Associative array of HTTP headers.
			 * @param string $api_key The API key being used.
			 */
			return apply_filters( 'wp_mcp_ai_openrouter_request_headers', $headers, $api_key );
		}

		/**
		 * Resolve the request timeout in seconds.
		 *
		 * @param array $options Request options may carry a 'timeout' key.
		 * @return int
		 */
		protected function resolve_timeout( array $options ) {
			$default = 60;

			if ( ! empty( $options['timeout'] ) && is_numeric( $options['timeout'] ) ) {
				return max( 10, absint( $options['timeout'] ) );
			}

			return $default;
		}

		/**
		 * Resolve the model from $options, falling back to the configured default.
		 *
		 * @param array $options Request options.
		 * @return string
		 */
		protected function resolve_model( array $options ) {
			if ( ! empty( $options['model'] ) ) {
				return sanitize_text_field( $options['model'] );
			}

			$model = $this->get_model();

			return ! empty( $model ) ? $model : self::DEFAULT_MODEL;
		}

		// -------------------------------------------------------------------------
		// Core methods.
		// -------------------------------------------------------------------------

		/**
		 * Perform a chat completion request against the OpenRouter API.
		 *
		 * The OpenRouter API is OpenAI-compatible: messages, tools,
		 * response_format, and streaming options are passed through unchanged.
		 *
		 * Tool/function calling support varies per upstream model — OpenRouter
		 * silently ignores unsupported parameters rather than erroring, so the
		 * client passes them through verbatim.
		 *
		 * @param array $messages Message payload (OpenAI-compatible format).
		 * @param array $options  Additional options:
		 *                        - model (string): Override the model
		 *                          (e.g. "openai/gpt-4o-mini",
		 *                          "anthropic/claude-3.5-sonnet").
		 *                        - temperature (float): Sampling temperature.
		 *                        - top_p (float): Nucleus sampling.
		 *                        - max_tokens (int): Maximum output tokens.
		 *                        - tools (array): OpenAI-compatible tool defs.
		 *                        - tool_choice (string|array): Tool selection.
		 *                        - response_format (array): JSON-mode hint.
		 *                        - stream (bool): Enable SSE streaming.
		 *                        - timeout (int): HTTP timeout in seconds.
		 *                        - system_prompt (string): System instruction.
		 *                        - provider (array): OpenRouter routing
		 *                          preferences (e.g. ["order" => [...]]).
		 *                        - models (array): Fallback model list for
		 *                          OpenRouter's automatic routing.
		 * @return array|WP_Error Normalised completion response or WP_Error on failure.
		 */
		public function create_chat_completion( array $messages, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_openrouter_api_key',
					__( 'No OpenRouter API key has been configured.', 'mcp-ai-wpoos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_openrouter_api_key' => __( 'Add an OpenRouter API key in the NV oOS settings.', 'mcp-ai-wpoos' ),
						),
					)
				);
			}

			$model = $this->resolve_model( $options );

			if ( empty( $model ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_openrouter_model',
					__( 'No OpenRouter model has been configured.', 'mcp-ai-wpoos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_openrouter_model' => __( 'Choose an OpenRouter model in the NV oOS settings.', 'mcp-ai-wpoos' ),
						),
					)
				);
			}

			$payload = $this->build_payload( $messages, $options, $model );

			if ( is_wp_error( $payload ) ) {
				return $payload;
			}

			$url = $this->get_base_url() . self::API_ENDPOINT;

			$request_args = array(
				'headers' => $this->build_request_headers( $api_key ),
				'body'    => wp_json_encode( $payload ),
				'timeout' => max( 60, $this->resolve_timeout( $options ) ),
			);

			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event(
					'openrouter_request',
					'Sending request to OpenRouter.',
					array(
						'model'         => $model,
						'message_count' => count( $messages ),
						'has_tools'     => ! empty( $payload['tools'] ),
					)
				);
			}

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
					WP_MCP_AI_Logger::log_error( 'OpenRouter request failed.', array( 'error' => $response->get_error_message() ) );
				}

				if ( class_exists( 'WP_MCP_AI_HTTP' ) ) {
					return WP_MCP_AI_HTTP::prepare_transport_error(
						$response,
						'wp_mcp_ai_http_error',
						__( 'The OpenRouter API request failed to complete.', 'mcp-ai-wpoos' ),
						__( 'OpenRouter', 'mcp-ai-wpoos' )
					);
				}

				return $response;
			}

			$code     = wp_remote_retrieve_response_code( $response );
			$body     = wp_remote_retrieve_body( $response );
			$decoded  = json_decode( $body, true );
			$json_err = json_last_error();

			if ( JSON_ERROR_NONE !== $json_err ) {
				if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
					WP_MCP_AI_Logger::log_error( 'Failed to decode OpenRouter response.', array( 'body' => $body ) );
				}

				return new WP_Error( 'wp_mcp_ai_openrouter_invalid_response', __( 'The OpenRouter API returned malformed JSON.', 'mcp-ai-wpoos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				return $this->handle_api_error( $code, is_array( $decoded ) ? $decoded : array(), $response );
			}

			$normalized = $this->normalize_response( is_array( $decoded ) ? $decoded : array() );

			if ( ! isset( $normalized['model'] ) && ! empty( $model ) ) {
				$normalized['model'] = $model;
			}

			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event( 'openrouter_response', 'OpenRouter request completed.', array( 'model' => $model ) );
			}

			return $normalized;
		}

		/**
		 * List available models from the OpenRouter API.
		 *
		 * The /models endpoint returns an OpenAI-shaped JSON object with a
		 * `data` array of model objects.  Each entry includes the namespaced
		 * `id` (e.g. "openai/gpt-4o"), context length, pricing, and the
		 * upstream provider that serves it.
		 *
		 * @return array|WP_Error Array of model objects or WP_Error on failure.
		 */
		public function list_models() {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_openrouter_api_key',
					__( 'No OpenRouter API key has been configured.', 'mcp-ai-wpoos' ),
					array( 'status' => 400 )
				);
			}

			$url = $this->get_base_url() . self::API_MODELS;

			$request_args = array(
				'timeout' => 30,
				'headers' => $this->build_request_headers( $api_key ),
			);

			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event( 'openrouter_list_models', 'Fetching models from OpenRouter.', array( 'url' => $url ) );
			}

			$response = wp_remote_get( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
					WP_MCP_AI_Logger::log_error( 'OpenRouter model listing failed.', array( 'error' => $response->get_error_message() ) );
				}

				return $response;
			}

			$code    = wp_remote_retrieve_response_code( $response );
			$body    = wp_remote_retrieve_body( $response );
			$decoded = json_decode( $body, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				return new WP_Error( 'wp_mcp_ai_openrouter_invalid_response', __( 'The OpenRouter API returned malformed JSON.', 'mcp-ai-wpoos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected error from OpenRouter models endpoint.', 'mcp-ai-wpoos' );

				return new WP_Error(
					'wp_mcp_ai_openrouter_api_error',
					$error_message,
					array( 'status' => $code )
				);
			}

			$models = array();

			if ( isset( $decoded['data'] ) && is_array( $decoded['data'] ) ) {
				foreach ( $decoded['data'] as $model ) {
					if ( ! is_array( $model ) || empty( $model['id'] ) ) {
						continue;
					}

					$entry = array(
						'id'             => sanitize_text_field( $model['id'] ),
						'name'           => isset( $model['name'] ) ? sanitize_text_field( $model['name'] ) : '',
						'context_length' => isset( $model['context_length'] ) ? absint( $model['context_length'] ) : 0,
					);

					if ( isset( $model['pricing'] ) && is_array( $model['pricing'] ) ) {
						// Pricing is reported as USD-per-token strings.
						$entry['pricing'] = array(
							'prompt'     => isset( $model['pricing']['prompt'] ) ? (string) $model['pricing']['prompt'] : '',
							'completion' => isset( $model['pricing']['completion'] ) ? (string) $model['pricing']['completion'] : '',
						);
					}

					$models[] = $entry;
				}
			}

			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event( 'openrouter_list_models', 'OpenRouter models retrieved.', array( 'count' => count( $models ) ) );
			}

			return $models;
		}

		/**
		 * Test the connection to the OpenRouter API.
		 *
		 * Sends a 1-token chat completion to verify API key and network access.
		 *
		 * @return array|WP_Error Success array or WP_Error on failure.
		 */
		public function test_connection() {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_openrouter_api_key',
					__( 'No OpenRouter API key has been configured.', 'mcp-ai-wpoos' ),
					array( 'status' => 400 )
				);
			}

			$test_model = $this->get_model() ? $this->get_model() : self::DEFAULT_MODEL;

			$result = $this->create_chat_completion(
				array(
					array(
						'role'    => 'user',
						'content' => 'Hi',
					),
				),
				array(
					'model'      => $test_model,
					'max_tokens' => 5,
				)
			);

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return array(
				'success' => true,
				'message' => __( 'Successfully connected to OpenRouter.', 'mcp-ai-wpoos' ),
				'model'   => $test_model,
			);
		}

		/**
		 * Count tokens using a heuristic estimator.
		 *
		 * OpenRouter does not expose a public token-count endpoint and the
		 * accurate tokenizer varies per upstream model.  The same chars/4
		 * heuristic used by other non-OpenAI providers is applied here.
		 *
		 * @param array $messages Chat messages in OpenAI-compatible format.
		 * @param array $options  Optional parameters (model, system_prompt, timeout).
		 * @return int Estimated input token count.
		 */
		public function count_tokens( array $messages, array $options = array() ) {
			$char_count = 0;

			foreach ( $messages as $message ) {
				if ( is_array( $message ) && isset( $message['content'] ) ) {
					$char_count += strlen( (string) $message['content'] );
				}
			}

			if ( ! empty( $options['system_prompt'] ) ) {
				$char_count += strlen( (string) $options['system_prompt'] );
			}

			// Heuristic: ~4 chars per token (same approximation used across the codebase).
			return max( 1, (int) ceil( $char_count / 4 ) );
		}

		// -------------------------------------------------------------------------
		// Private helpers.
		// -------------------------------------------------------------------------

		/**
		 * Build the JSON payload sent to OpenRouter.
		 *
		 * @param array  $messages Chat messages.
		 * @param array  $options  Request options.
		 * @param string $model    Resolved model identifier.
		 * @return array|WP_Error
		 */
		protected function build_payload( array $messages, array $options, $model ) {
			if ( empty( $messages ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_messages',
					__( 'No chat messages were provided for the OpenRouter request.', 'mcp-ai-wpoos' ),
					array( 'status' => 400 )
				);
			}

			$payload = array(
				'model'    => $model,
				'messages' => array(),
			);

			// Inject system prompt when provided as a top-level option.
			if ( ! empty( $options['system_prompt'] ) ) {
				$payload['messages'][] = array(
					'role'    => 'system',
					'content' => wp_kses_post( (string) $options['system_prompt'] ),
				);
			}

			// Pass through messages unchanged (OpenAI-compatible format).
			foreach ( $messages as $message ) {
				if ( ! is_array( $message ) ) {
					continue;
				}
				$payload['messages'][] = $message;
			}

			// Optional parameters.
			if ( isset( $options['temperature'] ) && is_numeric( $options['temperature'] ) ) {
				$payload['temperature'] = (float) $options['temperature'];
			}

			if ( isset( $options['top_p'] ) && is_numeric( $options['top_p'] ) ) {
				$payload['top_p'] = (float) $options['top_p'];
			}

			if ( isset( $options['max_tokens'] ) && is_numeric( $options['max_tokens'] ) ) {
				$payload['max_tokens'] = absint( $options['max_tokens'] );
			}

			// JSON mode.
			if ( isset( $options['response_format'] ) && is_array( $options['response_format'] ) ) {
				$payload['response_format'] = $options['response_format'];
			}

			// Streaming flag.
			if ( ! empty( $options['stream'] ) ) {
				$payload['stream'] = true;
			}

			// Tool/function calling — pass through verbatim. OpenRouter
			// silently ignores tools for upstream models that do not support
			// them rather than rejecting the request.
			if ( ! empty( $options['tools'] ) && is_array( $options['tools'] ) ) {
				$payload['tools'] = $options['tools'];

				if ( isset( $options['tool_choice'] ) ) {
					$payload['tool_choice'] = $options['tool_choice'];
				}
			}

			// OpenRouter-specific routing options.
			if ( isset( $options['provider'] ) && is_array( $options['provider'] ) ) {
				$payload['provider'] = $options['provider'];
			}

			if ( isset( $options['models'] ) && is_array( $options['models'] ) ) {
				$payload['models'] = array_values( array_filter( array_map( 'sanitize_text_field', $options['models'] ) ) );
			}

			if ( isset( $options['transforms'] ) && is_array( $options['transforms'] ) ) {
				$payload['transforms'] = array_values( array_map( 'sanitize_text_field', $options['transforms'] ) );
			}

			// Prompt caching: pass through to upstream providers via OpenRouter.
			if ( ! empty( $options['prompt_cache_key'] ) ) {
				$payload['prompt_cache_key'] = sanitize_text_field( $options['prompt_cache_key'] );
			}

			// Prompt cache retention for providers that support it.
			if ( ! empty( $options['prompt_cache_retention'] ) && in_array( $options['prompt_cache_retention'], array( 'in_memory', '24h' ), true ) ) {
				$payload['prompt_cache_retention'] = $options['prompt_cache_retention'];
			}

			/**
			 * Filter the OpenRouter request payload before it is sent.
			 *
			 * @since 2026.05
			 *
			 * @param array  $payload  Request payload.
			 * @param array  $messages Original messages.
			 * @param array  $options  Request options.
			 * @param string $model    Resolved model identifier.
			 */
			return apply_filters( 'wp_mcp_ai_openrouter_request_payload', $payload, $messages, $options, $model );
		}

		/**
		 * Handle a non-2xx API response and return an appropriate WP_Error.
		 *
		 * @param int          $code     HTTP status code.
		 * @param array        $decoded  Decoded JSON response body.
		 * @param array|object $response Full WP HTTP response.
		 * @return WP_Error
		 */
		protected function handle_api_error( $code, array $decoded, $response ) {
			$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from OpenRouter.', 'mcp-ai-wpoos' );
			$error_data    = array(
				'status' => $code,
				'body'   => $decoded,
			);

			$error_code = 'wp_mcp_ai_openrouter_api_error';

			if ( 401 === $code || 403 === $code ) {
				$error_code            = 'wp_mcp_ai_openrouter_auth_error';
				$error_data['actions'] = array(
					'auth_info' => __( 'Verify your OpenRouter API key in NV oOS → Providers → OpenRouter.', 'mcp-ai-wpoos' ),
				);
			} elseif ( 402 === $code ) {
				// OpenRouter returns 402 when the account is out of credits.
				$error_code            = 'wp_mcp_ai_openrouter_insufficient_credits';
				$error_data['actions'] = array(
					'credits_info' => __( 'Your OpenRouter account has insufficient credits. Top up at https://openrouter.ai/credits.', 'mcp-ai-wpoos' ),
				);
			} elseif ( 429 === $code ) {
				$error_code  = 'wp_mcp_ai_rate_limit_exceeded';
				$retry_after = wp_remote_retrieve_header( $response, 'retry-after' );
				if ( ! empty( $retry_after ) ) {
					$error_data['retry_after'] = absint( $retry_after );
				}
				$error_data['actions'] = array(
					'rate_limit_info' => __( 'The OpenRouter API rate limit has been exceeded. Try again in a few moments.', 'mcp-ai-wpoos' ),
				);
			}

			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_error(
					'OpenRouter returned an error response.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);
			}

			return new WP_Error( $error_code, $error_message, $error_data );
		}

		/**
		 * Normalise an OpenRouter response to the plugin's internal format.
		 *
		 * The response format is OpenAI-compatible, so only light
		 * normalisation is required to satisfy the internal contract expected
		 * by the REST layer.
		 *
		 * @param array $decoded Decoded JSON response.
		 * @return array Normalised response.
		 */
		protected function normalize_response( array $decoded ) {
			// Extract the primary choice.
			$choice  = isset( $decoded['choices'][0] ) ? $decoded['choices'][0] : array();
			$message = isset( $choice['message'] ) ? $choice['message'] : array();
			$content = isset( $message['content'] ) ? $message['content'] : '';

			$normalized = array(
				'content'       => $content,
				'finish_reason' => isset( $choice['finish_reason'] ) ? $choice['finish_reason'] : '',
				'model'         => isset( $decoded['model'] ) ? $decoded['model'] : '',
				'usage'         => isset( $decoded['usage'] ) ? $decoded['usage'] : array(),
				'raw'           => $decoded,
			);

			// Pass through tool_calls when present (function calling).
			if ( ! empty( $message['tool_calls'] ) ) {
				$normalized['tool_calls'] = $message['tool_calls'];
			}

			// Pass through reasoning_content for reasoning models routed via OpenRouter.
			if ( ! empty( $message['reasoning'] ) ) {
				$normalized['reasoning_content'] = $message['reasoning'];
			} elseif ( ! empty( $message['reasoning_content'] ) ) {
				$normalized['reasoning_content'] = $message['reasoning_content'];
			}

			return $normalized;
		}
	}
}
