<?php
/**
 * Tool for editing Gemini images (Validated version).
 *
 * This is the Symfony Validator version of the edit_gemini_image tool.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../validators/class-wp-mcp-ai-validated-tool.php';
require_once __DIR__ . '/../validators/arguments/class-edit-gemini-image-arguments.php';
require_once __DIR__ . '/class-wp-mcp-ai-tool-edit-gemini-image.php';

/**
 * Edits images using Gemini with Symfony Validator.
 *
 * This class extends the original edit_gemini_image tool to use
 * Symfony Validator for argument validation.
 */
class WP_MCP_AI_Tool_Edit_Gemini_Image_Validated extends WP_MCP_AI_Validated_Tool implements WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Model_Requirements_Interface, WP_MCP_AI_Tool_Shortcuts_Interface, WP_MCP_AI_Tool_LLM_Sanitizer_Interface, WP_MCP_AI_Tool_Rules_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * The original edit_gemini_image tool instance for delegation.
	 *
	 * @var WP_MCP_AI_Tool_Edit_Gemini_Image
	 */
	protected $original_tool;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
		$this->original_tool = new WP_MCP_AI_Tool_Edit_Gemini_Image();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'edit_gemini_image_validated';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Edit Gemini Image (Nano Banana) (Validated)', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Edits an existing image using Gemini Nano Banana (text + image-to-image) and stores the result in the Media Library with Symfony Validator for argument validation.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Editing an existing Media Library image with Gemini Nano Banana and Symfony-validated arguments.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Generating new images; use generate_gemini_image. For DALL-E editing use edit_openai_image.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'edit_gemini_image', 'generate_gemini_image', 'edit_openai_image' ),
			'notes'           => __( 'Same prompt schema as edit_gemini_image; arguments are rejected before execution when invalid.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		// Use the same schema as the original tool.
		return $this->original_tool->get_parameters_schema();
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_validation_class() {
		return \WP_MCP_AI\Tools\Arguments\EditGeminiImageArguments::class;
	}

	/**
	 * Execute the tool with validated arguments.
	 *
	 * @param \WP_MCP_AI\Tools\Arguments\EditGeminiImageArguments $validated_args Validated arguments object.
	 * @param array                                               $context        Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	protected function execute_validated( $validated_args, $context ) {
		// Convert validated arguments object back to array format.
		$arguments = array(
			'prompt' => $validated_args->prompt,
		);

		// Add optional arguments if provided.
		if ( null !== $validated_args->attachment_id ) {
			$arguments['attachment_id'] = $validated_args->attachment_id;
		}

		if ( null !== $validated_args->image_url ) {
			$arguments['image_url'] = $validated_args->image_url;
		}

		if ( null !== $validated_args->image_data ) {
			$arguments['image_data'] = $validated_args->image_data;
		}

		if ( null !== $validated_args->source_mime_type ) {
			$arguments['source_mime_type'] = $validated_args->source_mime_type;
		}

		if ( null !== $validated_args->model ) {
			$arguments['model'] = $validated_args->model;
		}

		if ( null !== $validated_args->aspect_ratio ) {
			$arguments['aspect_ratio'] = $validated_args->aspect_ratio;
		}

		if ( null !== $validated_args->mime_type ) {
			$arguments['mime_type'] = $validated_args->mime_type;
		}

		if ( null !== $validated_args->file_name ) {
			$arguments['file_name'] = $validated_args->file_name;
		}

		if ( null !== $validated_args->timeout ) {
			$arguments['timeout'] = $validated_args->timeout;
		}

		// Delegate to the original tool's execute method.
		return $this->original_tool->execute( $arguments, $context );
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'content_publishing',

			'pattern_compatibility' => array( 'sequential' ),

			'profession_tags'       => array( 'graphic_designer', 'photographer' ),

			'risk_level'            => 'standard',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		// Delegate to the original tool.
		return $this->original_tool->get_capability_flags();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_model_requirements() {
		// Delegate to the original tool.
		return $this->original_tool->get_model_requirements();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_shortcut_tasks() {
		// Delegate to the original tool.
		return $this->original_tool->get_shortcut_tasks();
	}

	/**
	 * Sanitize result for LLM consumption.
	 *
	 * @param mixed $result The result to sanitize.
	 * @return mixed Sanitized result.
	 */
	public function sanitize_for_llm( $result ) {
		// Delegate to the original tool.
		return $this->original_tool->sanitize_for_llm( $result );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_tool_rules() {
		// Delegate to the original tool.
		return $this->original_tool->get_tool_rules();
	}
}
