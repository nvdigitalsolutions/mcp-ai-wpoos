<?php
/**
 * Tool for generating captions for videos using AI vision capabilities.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/traits/trait-wp-mcp-ai-attachment-file-resolver.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php';

/**
 * Generates descriptive captions for videos using AI vision models with video understanding.
 */
class WP_MCP_AI_Tool_Generate_Video_Caption implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Attachment_File_Resolver;
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_video_caption';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate Video Caption', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Generates concise, descriptive captions for videos to provide context and enhance accessibility using AI vision models with video understanding capabilities.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Writing a concise descriptive caption for an MP4 or QuickTime video from a URL or attachment.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Still-image captions; use generate_image_caption. For audio transcripts, use transcribe_openai_audio.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'generate_image_caption', 'analyze_video', 'transcribe_openai_audio' ),
			'notes'           => __( 'max_length is clamped to 50-500 characters and defaults to 200; a video-capable model is required.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'video_url'     => array(
					'type'        => 'string',
					'description' => __( 'URL of the video to caption. Supports MP4 and QuickTime formats.', 'nvdigital-open-operator-system-oos' ),
				),
				'url'           => $this->get_url_parameter_schema( 'video' ),
				'attachment_id' => array(
					'type'        => 'integer',
					'description' => __( 'WordPress attachment ID of the video to caption.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 1,
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
				),
				'file_id'       => $this->get_file_id_parameter_schema(),
				'context'       => array(
					'type'        => 'string',
					'description' => __( 'Optional context about the video to help generate more relevant captions.', 'nvdigital-open-operator-system-oos' ),
				),
				'max_length'    => array(
					'type'        => 'integer',
					'description' => __( 'Maximum caption length in characters. Default is 200.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 50,
					'maximum'     => 500,
					'default'     => 200,
				),
			),
			'required'             => array(),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		// Check user capabilities.
		if ( ! $user_id || ! user_can( $user_id, 'upload_files' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to generate video captions.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 403 )
			);
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error(
				'wp_mcp_ai_wrong_site',
				__( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 403 )
			);
		}

		// Get video source.
		$video_url     = '';
		$attachment_id = 0;

		// Try to resolve from attachment_id, file_id, or url first.
		if ( ! empty( $arguments['attachment_id'] ) || ! empty( $arguments['file_id'] ) || ! empty( $arguments['url'] ) ) {
			$resolved = $this->resolve_attachment_id( $arguments );

			// Handle remote URL case.
			if ( is_array( $resolved ) && isset( $resolved['url'] ) ) {
				$video_url = $resolved['url'];
			} elseif ( is_wp_error( $resolved ) ) {
				return $resolved;
			} elseif ( $resolved > 0 ) {
				$attachment_id = $resolved;
				$video_url     = wp_get_attachment_url( $attachment_id );

				if ( ! $video_url ) {
					return new WP_Error(
						'wp_mcp_ai_invalid_attachment',
						__( 'Invalid attachment ID provided.', 'nvdigital-open-operator-system-oos' ),
						array( 'status' => 400 )
					);
				}

				// Verify it's a video attachment.
				$mime_type = get_post_mime_type( $attachment_id );
				if ( ! $mime_type || false === strpos( $mime_type, 'video/' ) ) {
					return new WP_Error(
						'wp_mcp_ai_not_video',
						__( 'The provided attachment is not a video file.', 'nvdigital-open-operator-system-oos' ),
						array( 'status' => 400 )
					);
				}
			}
		}

		// Fallback to legacy video_url parameter.
		if ( '' === $video_url && ! empty( $arguments['video_url'] ) ) {
			$video_url = esc_url_raw( $arguments['video_url'] );
		}

		// Validate we have a video source.
		if ( '' === $video_url ) {
			return new WP_Error(
				'wp_mcp_ai_missing_video',
				__( 'You must provide video_url, url, attachment_id, or file_id.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 400 )
			);
		}

		// Get parameters.
		$max_length   = isset( $arguments['max_length'] ) ? absint( $arguments['max_length'] ) : 200;
		$max_length   = max( 50, min( 500, $max_length ) ); // Clamp between 50-500.
		$user_context = isset( $arguments['context'] ) ? sanitize_text_field( $arguments['context'] ) : '';

		// Get settings.
		$settings         = get_option( 'wp_mcp_ai_settings', array() );
		$default_provider = isset( $settings['default_provider'] ) ? $settings['default_provider'] : 'gemini';

		// Build prompt.
		$prompt = $this->build_prompt( $max_length, $user_context );

		// Call video-capable vision model.
		$attachment_id_for_video = $attachment_id > 0 ? $attachment_id : null;
		$api_response            = $this->call_video_model( $video_url, $prompt, $default_provider, $attachment_id_for_video );

		if ( is_wp_error( $api_response ) ) {
			return $api_response;
		}

		// Extract caption and metadata.
		$caption  = is_array( $api_response ) && isset( $api_response['text'] ) ? $api_response['text'] : $api_response;
		$usage    = is_array( $api_response ) && isset( $api_response['usage'] ) ? $api_response['usage'] : null;
		$model    = is_array( $api_response ) && isset( $api_response['model'] ) ? $api_response['model'] : '';
		$provider = is_array( $api_response ) && isset( $api_response['provider'] ) ? $api_response['provider'] : $default_provider;

		// Clean and truncate caption if needed.
		$caption = trim( $caption );
		if ( strlen( $caption ) > $max_length ) {
			$caption = substr( $caption, 0, $max_length - 3 ) . '...';
		}

		$message = __( 'Successfully generated video caption.', 'nvdigital-open-operator-system-oos' );

		$result = array(
			'caption' => $caption,
			'text'    => $message,
			'message' => $message,
			'success' => true,
		);

		// Include provider/model/usage metadata for accurate cost tracking.
		if ( $provider ) {
			$result['provider'] = $provider;
		}

		if ( $model ) {
			$result['model'] = $model;
		}

		if ( $usage ) {
			$result['usage'] = $usage;
		}

		return $result;
	}

	/**
	 * Build the caption generation prompt.
	 *
	 * @param int    $max_length   Maximum caption length.
	 * @param string $user_context Additional context.
	 * @return string
	 */
	protected function build_prompt( $max_length, $user_context ) {
		$prompt = sprintf(
			/* translators: %d: maximum caption length */
			__(
				'Generate a concise, descriptive caption for this video in %d characters or less. The caption should briefly describe what happens in the video, including main subjects, actions, and setting. Make it engaging and informative.',
				'nvdigital-open-operator-system-oos'
			),
			$max_length
		);

		if ( ! empty( $user_context ) ) {
			$prompt = sprintf(
				/* translators: 1: context, 2: prompt */
				__( 'Context: %1$s\n\n%2$s', 'nvdigital-open-operator-system-oos' ),
				$user_context,
				$prompt
			);
		}

		return $prompt;
	}

	/**
	 * Call a video-capable vision model.
	 *
	 * Delegates to the Video Analysis Service for proper SoC.
	 *
	 * @param string   $video_url     URL of the video to analyze.
	 * @param string   $prompt        Caption prompt.
	 * @param string   $provider      AI provider to use.
	 * @param int|null $attachment_id WordPress attachment ID if available.
	 * @return array|WP_Error Response with text, usage, model, and provider.
	 */
	protected function call_video_model( $video_url, $prompt, $provider, $attachment_id = null ) {
		require_once WP_MCP_AI_PATH . 'includes/services/class-wp-mcp-ai-video-analysis-service.php';

		$service = new WP_MCP_AI_Video_Analysis_Service();

		$result = $service->analyze_video(
			array(
				'video_url'     => $video_url,
				'attachment_id' => $attachment_id,
				'prompt'        => $prompt,
				'provider'      => $provider,
			)
		);

		return $result;
	}

	/**
	 * Check if a Gemini model supports video.
	 *
	 * @param string $model Model identifier.
	 * @return bool
	 */
	protected function is_video_capable_gemini_model( $model ) {
		// Gemini 2.0 and later support video (2025 models).
		// Based on Google's 2025 model lineup - all Gemini 1.x models are deprecated.
		// Note: Experimental models with -exp suffix are being deprecated in favor of stable versions.
		$video_capable_models = array(
			// Gemini 3.1 series (February 2026 flagship).
			'gemini-3.1-pro-preview',

			// Gemini 3 series (latest - 2025).
			'gemini-3-pro-preview',
			'gemini-3-flash-preview',

			// Gemini 2.5 series (production - 2025).
			'gemini-2.5-pro',
			'gemini-2.5-flash',
			'gemini-2.5-flash-lite',
			'gemini-2.5-flash-preview-09-2025',
			'gemini-live-2.5-flash-preview',

			// Gemini 2.0 series (stable - use these instead of -exp variants).
			'gemini-2.0-flash',
			'gemini-2.0-flash-lite',

			// Experimental models (still available but may be deprecated).
			'gemini-exp-1206',
			'gemini-exp-1121',
		);

		return in_array( $model, $video_capable_models, true );
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'content_publishing',

			'pattern_compatibility' => array( 'sequential' ),

			'profession_tags'       => array( 'video_producer', 'content_creator' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'requires-credentials', // Requires AI provider API key.
			'requires-video-model', // Requires video-capable AI model.
			'read-only',            // Only reads/analyzes data.
			'external-api',         // Makes external API requests.
			'network-dependent',    // Requires internet connection.
			'consumes-tokens',      // Uses AI tokens/credits.
			'model-dependent',      // Behavior varies by model.
			'async',                // May take significant time.
			'rate-limited',         // Subject to API rate limits.
		);
	}
}
