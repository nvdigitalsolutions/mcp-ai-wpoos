<?php
/**
 * Rate Limiter for Federation Directory REST API endpoints.
 *
 * Prevents enumeration attacks on public peer discovery endpoints.
 *
 * @package WP_MCP_AI
 * @since 1.1.1
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Federation Rate Limiter Class
 *
 * Implements IP-based rate limiting using WordPress transients
 * specifically for public Federation Directory endpoints.
 */
class WP_MCP_AI_Federation_Rate_Limiter {

	/**
	 * Default rate limit: 60 requests per minute.
	 */
	const DEFAULT_LIMIT = 60;

	/**
	 * Default time window in seconds.
	 */
	const DEFAULT_WINDOW = 60;

	/**
	 * Check if request should be rate limited.
	 *
	 * @param string $endpoint The endpoint being accessed.
	 * @param int    $limit    Request limit per window (default 60).
	 * @param int    $window   Time window in seconds (default 60).
	 * @return bool|WP_Error True if allowed, WP_Error if rate limited.
	 */
	public function check_rate_limit( $endpoint, $limit = self::DEFAULT_LIMIT, $window = self::DEFAULT_WINDOW ) {
		// Allow admins to bypass rate limiting.
		if ( wp_mcp_ai_user_can_manage_fleet() ) {
			return true;
		}

		// Get client IP address.
		$ip = $this->get_client_ip();

		// Create unique transient key.
		$transient_key = 'wp_mcp_ai_fed_rate_limit_' . md5( $endpoint . '_' . $ip );

		// Get current request count.
		$requests = get_transient( $transient_key );

		if ( false === $requests ) {
			// First request in this window.
			set_transient( $transient_key, 1, $window );
			return true;
		}

		if ( $requests >= $limit ) {
			// Rate limit exceeded.
			return new WP_Error(
				'wp_mcp_ai_rate_limit_exceeded',
				sprintf(
					/* translators: %1$d: rate limit, %2$d: time window in seconds */
					__( 'Rate limit exceeded. You are limited to %1$d requests per %2$d seconds. Please try again later.', 'nvdigital-open-operator-system-oos' ),
					$limit,
					$window
				),
				array(
					'status'        => 429,
					'retry_after'   => $window,
					'limit'         => $limit,
					'window'        => $window,
					'requests_made' => $requests,
				)
			);
		}

		// Increment request count.
		set_transient( $transient_key, $requests + 1, $window );

		return true;
	}

	/**
	 * Get client IP address.
	 *
	 * @return string Client IP address.
	 */
	private function get_client_ip() {
		return wp_mcp_ai_get_client_ip();
	}

	/**
	 * Add rate limit headers to response.
	 *
	 * @param WP_REST_Response $response REST response object.
	 * @param string           $endpoint Endpoint being accessed.
	 * @param int              $limit    Rate limit.
	 * @param int              $window   Time window.
	 * @return WP_REST_Response Modified response with rate limit headers.
	 */
	public function add_rate_limit_headers( $response, $endpoint, $limit, $window ) {
		$ip            = $this->get_client_ip();
		$transient_key = 'wp_mcp_ai_fed_rate_limit_' . md5( $endpoint . '_' . $ip );
		$requests      = get_transient( $transient_key );
		$requests      = ( false === $requests ) ? 0 : $requests;
		$remaining     = max( 0, $limit - $requests );

		$response->header( 'X-RateLimit-Limit', (string) $limit );
		$response->header( 'X-RateLimit-Remaining', (string) $remaining );
		$response->header( 'X-RateLimit-Reset', (string) ( time() + $window ) );

		return $response;
	}
}
