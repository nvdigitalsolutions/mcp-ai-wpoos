<?php
/**
 * REST API: Approval Queue Controller.
 *
 * Exposes HITL approval management endpoints. All routes require
 * `manage_options` unless the requester is the original approval requester,
 * in which case they can read their own approvals.
 *
 * Routes:
 *   GET  /mcp-ai/v1/approvals           — list pending approvals (manage_options)
 *   GET  /mcp-ai/v1/approvals/{id}      — get single approval
 *   POST /mcp-ai/v1/approvals/{id}/approve — approve
 *   POST /mcp-ai/v1/approvals/{id}/deny   — deny
 *
 * @package WP_MCP_AI
 * @since 1.5.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST controller for the HITL approval queue.
 *
 * @since 1.5.0
 */
class WP_MCP_AI_REST_Approval_Controller extends WP_REST_Controller {

	/**
	 * REST namespace.
	 */
	const NAMESPACE = 'mcp-ai/v1';

	/**
	 * Route base.
	 */
	const BASE = 'approvals';

	/**
	 * Register routes.
	 */
	public function register_routes() {
		register_rest_route(
			self::NAMESPACE,
			'/' . self::BASE,
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
					'args'                => array(
						'assistant_id' => array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'default'           => 0,
						),
						'session_id'   => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'default'           => '',
						),
						'limit'        => array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'default'           => 20,
						),
						'offset'       => array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'default'           => 0,
						),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/' . self::BASE . '/(?P<id>[\d]+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'id' => array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'required'          => true,
						),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/' . self::BASE . '/(?P<id>[\d]+)/approve',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'approve_item' ),
					'permission_callback' => array( $this, 'resolve_permissions_check' ),
					'args'                => array(
						'id'   => array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'required'          => true,
						),
						'note' => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_textarea_field',
							'default'           => '',
						),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/' . self::BASE . '/(?P<id>[\d]+)/deny',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'deny_item' ),
					'permission_callback' => array( $this, 'resolve_permissions_check' ),
					'args'                => array(
						'id'   => array(
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
							'required'          => true,
						),
						'note' => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_textarea_field',
							'default'           => '',
						),
					),
				),
			)
		);
	}

	/**
	 * GET /approvals — list pending approvals (paginated).
	 *
	 * `total` is the full pending-queue depth for the caller's scope, not the
	 * length of the returned page — the console pager needs the real count to
	 * render page numbers and the "showing X of Y" label.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items( $request ) {
		$queue   = WP_MCP_AI_Approval_Queue::get_instance();
		$limit   = min( 100, max( 1, (int) $request['limit'] ) );
		$offset  = max( 0, (int) $request['offset'] );
		$filters = array(
			'assistant_id' => (int) $request['assistant_id'],
			'session_id'   => (string) $request['session_id'],
		);

		$items = $queue->get_pending(
			array_merge(
				$filters,
				array(
					'limit'  => $limit,
					'offset' => $offset,
				)
			)
		);

		return rest_ensure_response(
			array(
				'approvals' => $items,
				'total'     => $queue->count_pending( $filters ),
				'limit'     => $limit,
				'offset'    => $offset,
			)
		);
	}

	/**
	 * GET /approvals/{id}
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_item( $request ) {
		$queue  = WP_MCP_AI_Approval_Queue::get_instance();
		$record = $queue->get( (int) $request['id'] );

		if ( null === $record ) {
			return new WP_Error( 'approval_not_found', __( 'Approval not found.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 404 ) );
		}

		return rest_ensure_response( $record );
	}

	/**
	 * POST /approvals/{id}/approve
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function approve_item( $request ) {
		$queue  = WP_MCP_AI_Approval_Queue::get_instance();
		$result = $queue->approve(
			(int) $request['id'],
			get_current_user_id(),
			(string) $request['note']
		);

		if ( is_wp_error( $result ) ) {
			return new WP_Error(
				$result->get_error_code(),
				$result->get_error_message(),
				array( 'status' => 400 )
			);
		}

		return rest_ensure_response(
			array(
				'success'     => true,
				'approval_id' => (int) $request['id'],
				'status'      => 'approved',
			)
		);
	}

	/**
	 * POST /approvals/{id}/deny
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function deny_item( $request ) {
		$queue  = WP_MCP_AI_Approval_Queue::get_instance();
		$result = $queue->deny(
			(int) $request['id'],
			get_current_user_id(),
			(string) $request['note']
		);

		if ( is_wp_error( $result ) ) {
			return new WP_Error(
				$result->get_error_code(),
				$result->get_error_message(),
				array( 'status' => 400 )
			);
		}

		return rest_ensure_response(
			array(
				'success'     => true,
				'approval_id' => (int) $request['id'],
				'status'      => 'denied',
			)
		);
	}

	/**
	 * Permission check: list approvals requires manage_options or a valid
	 * assistant credential (scoped to the credential's assistant).
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return bool|WP_Error
	 */
	public function get_items_permissions_check( $request ) {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		// Assistant credentials (bearer) authenticate the queue reader without
		// a WordPress user.  Scope the listing to the assistant the credential
		// was issued for so a credential can never enumerate other assistants'
		// approvals.
		$credential = $this->get_request_credential( $request );
		if ( null !== $credential ) {
			if ( is_wp_error( $credential ) ) {
				return $credential;
			}

			$credential_assistant = absint( isset( $credential['assistant_id'] ) ? $credential['assistant_id'] : 0 );
			$requested_assistant  = absint( $request->get_param( 'assistant_id' ) );

			if ( $credential_assistant && $requested_assistant && $requested_assistant !== $credential_assistant ) {
				return new WP_Error(
					'rest_forbidden',
					__( 'This credential cannot view approvals for that assistant.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => rest_authorization_required_code() )
				);
			}

			// Default the listing scope to the credential's own assistant.
			if ( $credential_assistant && ! $requested_assistant ) {
				$request->set_param( 'assistant_id', $credential_assistant );
			}

			return true;
		}

		return new WP_Error(
			'rest_forbidden',
			__( 'You do not have permission to view the approval queue.', 'nvdigital-open-operator-system-oos' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * Permission check: reading a single approval.
	 * Admin, the original requester, or the assistant credential the approval
	 * was raised for can read it.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return bool|WP_Error
	 */
	public function get_item_permissions_check( $request ) {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		// Assistant credentials can read approvals raised for the assistant
		// they were issued for.
		$credential = $this->get_request_credential( $request );
		if ( null !== $credential ) {
			if ( is_wp_error( $credential ) ) {
				return $credential;
			}

			$credential_assistant = absint( isset( $credential['assistant_id'] ) ? $credential['assistant_id'] : 0 );
			$queue                = WP_MCP_AI_Approval_Queue::get_instance();
			$record               = $queue->get( (int) $request['id'] );

			if ( $credential_assistant && $record && $credential_assistant === (int) $record['assistant_id'] ) {
				return true;
			}
		}

		// Check if current user is the requester.
		$queue  = WP_MCP_AI_Approval_Queue::get_instance();
		$record = $queue->get( (int) $request['id'] );
		if ( $record && get_current_user_id() === (int) $record['requester_id'] ) {
			return true;
		}

		return new WP_Error(
			'rest_forbidden',
			__( 'You do not have permission to view this approval.', 'nvdigital-open-operator-system-oos' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * Permission check: resolve (approve/deny) requires manage_options.
	 *
	 * Assistant credentials are deliberately NOT granted resolve rights:
	 * they are query-only for the approvals they raised, so the human-in-the
	 * loop gate cannot be bypassed with a leaked credential.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return bool|WP_Error
	 */
	public function resolve_permissions_check( $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'You do not have permission to resolve approvals.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}
		return true;
	}

	/**
	 * Resolve a valid assistant credential from the request, if present.
	 *
	 * Mirrors the main REST layer's credential handling: the token may arrive
	 * as "Authorization: Bearer cred_xxxxx.SECRET" or as a raw credential
	 * header.  Returns the credential metadata on success, a WP_Error for a
	 * rejected credential, or null when no credential is presented.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return array|WP_Error|null
	 */
	private function get_request_credential( $request ) {
		$header = $request->get_header( 'Authorization' );

		$token = '';
		if ( ! empty( $header ) && preg_match( '/^Bearer\s+(.*)$/i', $header, $matches ) ) {
			$token = trim( $matches[1] );
		} elseif ( ! empty( $header ) ) {
			$accept_raw_credential = apply_filters( 'wp_mcp_ai_accept_raw_credential_header', true );
			if ( $accept_raw_credential ) {
				$token = trim( $header );
			}
		}

		if ( '' === $token || ! WP_MCP_AI_Credentials::is_token_format( $token ) ) {
			return null;
		}

		return WP_MCP_AI_Credentials::validate_token( $token, absint( $request->get_param( 'assistant_id' ) ) );
	}
}
