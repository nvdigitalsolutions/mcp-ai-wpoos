<?php
/**
 * Trait for SVG vectorization capabilities.
 *
 * Provides reusable methods for converting raster images to SVG vector format
 * using @neplex/vectorizer. Can be used by any image generation or manipulation tool.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trait providing SVG vectorization functionality for image tools.
 *
 * This trait requires:
 * - WP_MCP_AI_NodeJS_Subprocess trait
 * - WordPress file functions (wp_tempnam, wp_delete_file, etc.)
 */
trait WP_MCP_AI_SVG_Vectorizer {
	use WP_MCP_AI_Media_Worker_Client;

	/**
	 * Convert a raster image to SVG format using vectorization.
	 *
	 * @param array $storage    Stored raster image data with 'file', 'bytes', etc.
	 * @param array $arguments  Tool arguments for vectorization options.
	 * @return array|WP_Error SVG storage data or error.
	 */
	protected function convert_to_svg( array $storage, array $arguments ) {
		// Check if Node.js is available (or the Media Worker sidecar).
		if ( ! $this->is_nodejs_available() && ! $this->is_sidecar_upload_supported() ) {
			return new WP_Error(
				'wp_mcp_ai_nodejs_required',
				__( 'Node.js is required for SVG vectorization but was not found on the system. Configure the Media Worker sidecar or install Node.js.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$file_path = isset( $storage['file'] ) ? $storage['file'] : '';

		if ( '' === $file_path || ! file_exists( $file_path ) ) {
			return new WP_Error(
				'wp_mcp_ai_file_not_found',
				__( 'Generated image file not found for SVG conversion.', 'nvdigital-open-operator-system-oos' )
			);
		}

		// Prepare SVG output file.
		$temp_output = wp_tempnam( 'svg-convert-' );
		if ( ! $temp_output ) {
			return new WP_Error( 'wp_mcp_ai_temp_file_error', __( 'Failed to create temporary SVG output file.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Add .svg extension.
		$temp_output_svg = $temp_output . '.svg';
		rename( $temp_output, $temp_output_svg ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Direct filesystem operation required; WP_Filesystem not available in this execution context.
		$temp_output = $temp_output_svg;

		// Prepare vectorization options with sensible defaults.
		$vectorization_options = array(
			'colorMode'      => 'color',
			'colorPrecision' => isset( $arguments['color_precision'] ) ? absint( $arguments['color_precision'] ) : 6,
			'filterSpeckle'  => isset( $arguments['filter_speckle'] ) ? absint( $arguments['filter_speckle'] ) : 4,
			'mode'           => isset( $arguments['mode'] ) ? sanitize_text_field( $arguments['mode'] ) : 'spline',
			'hierarchical'   => isset( $arguments['hierarchical'] ) ? sanitize_text_field( $arguments['hierarchical'] ) : 'stacked',
		);

		// Try the Media Worker sidecar first (opt-in routing — fails fast
		// when no sidecar URL is configured or the health check fails). The
		// string options mirror the local bin/vectorize-image.js contract;
		// the worker maps them to the numeric v0.0.5 config enums.
		$vectorize_result = null;
		if ( $this->is_sidecar_upload_supported() ) {
			$sidecar = $this->sidecar_upload(
				'/api/image/vectorize',
				$file_path,
				array( 'options' => wp_json_encode( $vectorization_options ) ),
				120
			);
			if ( ! is_wp_error( $sidecar ) && ! empty( $sidecar['svg'] ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Writing the worker-returned SVG into the temp output file consumed by the shared save flow.
				if ( false !== file_put_contents( $temp_output, $sidecar['svg'] ) ) {
					$vectorize_result = array( 'success' => true );
				}
			}
		}

		// Fall back to the local vectorization script.
		if ( null === $vectorize_result ) {
			$script_path = WP_MCP_AI_PATH . 'bin/vectorize-image.js';
			$script_args = array(
				$file_path,
				$temp_output,
				wp_json_encode( $vectorization_options ),
			);

			$vectorize_result = $this->execute_nodejs_script(
				$script_path,
				$script_args,
				array(
					'timeout'    => 60,
					'parse_json' => true,
				)
			);
		}

		if ( is_wp_error( $vectorize_result ) ) {
			wp_delete_file( $temp_output );
			return $vectorize_result;
		}

		if ( ! isset( $vectorize_result['success'] ) || ! $vectorize_result['success'] ) {
			wp_delete_file( $temp_output );
			return new WP_Error(
				'wp_mcp_ai_vectorization_failed',
				isset( $vectorize_result['error'] ) ? $vectorize_result['error'] : __( 'SVG vectorization failed.', 'nvdigital-open-operator-system-oos' )
			);
		}

		// Read SVG file.
		$svg_data = file_get_contents( $temp_output ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; WP_Filesystem not available in this context.
		if ( false === $svg_data || '' === $svg_data ) {
			wp_delete_file( $temp_output );
			return new WP_Error( 'wp_mcp_ai_read_error', __( 'Failed to read vectorized SVG file.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Cleanup temporary output file.
		wp_delete_file( $temp_output );

		// Save as WordPress attachment.
		$svg_storage = $this->save_svg_as_attachment( $svg_data, $arguments );
		if ( is_wp_error( $svg_storage ) ) {
			return $svg_storage;
		}

		// Add vectorization metadata.
		$svg_storage['vectorized']  = true;
		$svg_storage['svg_size']    = isset( $vectorize_result['output_size'] ) ? $vectorize_result['output_size'] : $svg_storage['bytes'];
		$svg_storage['source_size'] = isset( $vectorize_result['input_size'] ) ? $vectorize_result['input_size'] : $storage['bytes'];
		$svg_storage['duration_ms'] = isset( $vectorize_result['duration_ms'] ) ? $vectorize_result['duration_ms'] : 0;

		return $svg_storage;
	}

	/**
	 * Save SVG data as WordPress attachment.
	 *
	 * @param string $svg_data  SVG file content.
	 * @param array  $arguments Tool arguments for naming.
	 * @return array|WP_Error Attachment data or error.
	 */
	protected function save_svg_as_attachment( $svg_data, array $arguments ) {
		// Generate file name.
		$base_name = isset( $arguments['file_name'] ) ? sanitize_file_name( $arguments['file_name'] ) : 'image';
		if ( empty( $base_name ) ) {
			$base_name = 'image';
		}

		// Remove extension if present.
		$base_name = preg_replace( '/\.(png|jpg|jpeg|gif|webp)$/i', '', $base_name );
		$file_name = $base_name . '-svg-' . gmdate( 'Ymd-His' ) . '.svg';

		// Upload SVG file. WordPress rejects image/svg+xml by default (an
		// XSS surface for arbitrary uploads), so allow it for this single
		// call only — producing an SVG attachment is the entire purpose
		// of this helper. The filter is removed immediately after.
		if ( ! function_exists( 'wp_upload_bits' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$allow_svg_mime = static function ( $mimes ) {
			if ( ! is_array( $mimes ) ) {
				$mimes = array();
			}
			$mimes['svg'] = 'image/svg+xml';
			return $mimes;
		};
		add_filter( 'upload_mimes', $allow_svg_mime );
		$upload = wp_upload_bits( $file_name, null, $svg_data );
		remove_filter( 'upload_mimes', $allow_svg_mime );

		if ( ! empty( $upload['error'] ) ) {
			return new WP_Error( 'wp_mcp_ai_upload_failed', __( 'Failed to save SVG file.', 'nvdigital-open-operator-system-oos' ), array( 'error' => $upload['error'] ) );
		}

		$file_path = isset( $upload['file'] ) ? $upload['file'] : '';

		if ( '' === $file_path || ! file_exists( $file_path ) ) {
			return new WP_Error( 'wp_mcp_ai_upload_failed', __( 'Failed to write SVG file to disk.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Create attachment.
		$attachment = array(
			'post_mime_type' => 'image/svg+xml',
			'post_title'     => sanitize_text_field( __( 'SVG Image', 'nvdigital-open-operator-system-oos' ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);

		$attachment_id = wp_insert_attachment( $attachment, $file_path );

		if ( is_wp_error( $attachment_id ) ) {
			wp_delete_file( $file_path );
			return new WP_Error( 'wp_mcp_ai_attachment_error', __( 'Failed to register SVG as an attachment.', 'nvdigital-open-operator-system-oos' ), array( 'error' => $attachment_id ) );
		}

		$bytes = file_exists( $file_path ) ? filesize( $file_path ) : 0;

		// Get attachment URL.
		$attachment_url = wp_get_attachment_url( $attachment_id );
		if ( false === $attachment_url ) {
			// Use a fallback URL if possible.
			$upload_dir     = wp_upload_dir();
			$attachment_url = str_replace( $upload_dir['basedir'], $upload_dir['baseurl'], $file_path );
		}

		return array(
			'attachment_id' => (int) $attachment_id,
			'file'          => $file_path,
			'file_name'     => wp_basename( $file_path ),
			'url'           => $attachment_url,
			'download_url'  => $attachment_url,
			'mime_type'     => 'image/svg+xml',
			'bytes'         => $bytes ? (int) $bytes : 0,
			'title'         => get_the_title( $attachment_id ),
		);
	}

	/**
	 * Get output format parameter schema for tool parameters.
	 *
	 * @return array Parameter schema for output_format.
	 */
	protected function get_output_format_parameter_schema() {
		return array(
			'output_format' => array(
				'type'        => 'string',
				'description' => __( 'Output format for the generated/edited image. Use "svg" to vectorize the raster output. Default is raster format.', 'nvdigital-open-operator-system-oos' ),
				'enum'        => array( 'default', 'svg' ),
				'default'     => 'default',
			),
		);
	}

	/**
	 * Add vectorization metadata to result if SVG output was used.
	 *
	 * @param array  $result_data Result data array.
	 * @param array  $storage     Storage data from save_svg_as_attachment.
	 * @param string $output_format Output format selected.
	 * @return array Updated result data.
	 */
	protected function add_vectorization_metadata( array $result_data, array $storage, $output_format ) {
		if ( 'svg' === $output_format && isset( $storage['vectorized'] ) ) {
			$result_data['vectorized']  = true;
			$result_data['svg_size']    = isset( $storage['svg_size'] ) ? $storage['svg_size'] : $storage['bytes'];
			$result_data['source_size'] = isset( $storage['source_size'] ) ? $storage['source_size'] : 0;
			$result_data['duration_ms'] = isset( $storage['duration_ms'] ) ? $storage['duration_ms'] : 0;
		}

		return $result_data;
	}
}
