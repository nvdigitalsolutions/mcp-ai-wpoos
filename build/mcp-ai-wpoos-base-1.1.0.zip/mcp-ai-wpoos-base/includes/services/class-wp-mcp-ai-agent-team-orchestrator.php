<?php
/**
 * Agent Team Orchestrator
 *
 * Manages team composition and coordinated execution for multi-agent workflows.
 * Inspired by DeepSeek V4's multi-agent coordination patterns.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Agent Team Orchestrator class
 *
 * Handles:
 * - Team composition based on task requirements
 * - Coordinated workflow execution
 * - Team performance tracking
 * - Dynamic team adjustment
 *
 * @since 1.1.0
 */
class WP_MCP_AI_Agent_Team_Orchestrator {

	/**
	 * Communication service instance
	 *
	 * @var WP_MCP_AI_Agent_Communication_Service
	 */
	protected $communication_service;

	/**
	 * Load monitor instance
	 *
	 * @var WP_MCP_AI_Tool_Load_Monitor|null
	 */
	protected $load_monitor;

	/**
	 * Tool execution orchestrator instance
	 *
	 * @var WP_MCP_AI_Tool_Execution_Orchestrator|null
	 */
	protected $tool_orchestrator;

	/**
	 * Predefined team templates
	 *
	 * @var array
	 */
	protected $team_templates = array();

	/**
	 * Constructor
	 *
	 * @param WP_MCP_AI_Agent_Communication_Service|null $communication_service Communication service.
	 * @param WP_MCP_AI_Tool_Load_Monitor|null          $load_monitor Load monitor instance.
	 * @param WP_MCP_AI_Tool_Execution_Orchestrator|null $tool_orchestrator Tool orchestrator instance.
	 */
	public function __construct( $communication_service = null, $load_monitor = null, $tool_orchestrator = null ) {
		$this->communication_service = $communication_service ?? new WP_MCP_AI_Agent_Communication_Service();
		$this->load_monitor          = $load_monitor;
		$this->tool_orchestrator     = $tool_orchestrator;
		$this->init_team_templates();
	}

	/**
	 * Compose a team for a specific task
	 *
	 * @param array $task_requirements Task requirements and constraints.
	 * @return array|WP_Error Team composition or error.
	 */
	public function compose_team( $task_requirements ) {
		if ( empty( $task_requirements['task_type'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_missing_task_type',
				__( 'Task type is required for team composition.', 'mcp-ai-wpoos' )
			);
		}

		$task_type = sanitize_key( $task_requirements['task_type'] );

		// Check system capacity before composing team (Phase 2.3).
		$capacity_check = $this->check_system_capacity_for_team( $task_requirements );
		if ( is_wp_error( $capacity_check ) ) {
			return $capacity_check;
		}

		// Get team template for task type.
		$template = $this->get_team_template( $task_type );
		if ( ! $template ) {
			// Use generic team for unknown types.
			$template = $this->get_team_template( 'generic' );
		}

		// Find available agents for each role.
		$team_members = $this->find_agents_for_roles( $template['roles'], $task_requirements );

		if ( empty( $team_members ) ) {
			return new WP_Error(
				'wp_mcp_ai_no_agents_available',
				__( 'No suitable agents available for team composition.', 'mcp-ai-wpoos' )
			);
		}

		// Create team structure.
		$team = array(
			'team_id'      => $this->generate_team_id(),
			'task_type'    => $task_type,
			'template'     => $template['name'],
			'members'      => $team_members,
			'workflow'     => $template['workflow'],
			'created_at'   => current_time( 'mysql' ),
			'status'       => 'assembled',
			'requirements' => $task_requirements,
		);

		// Store team configuration.
		$this->store_team( $team );

		$this->log_team_action( $team['team_id'], 'composed', array( 'member_count' => count( $team_members ) ) );

		return $team;
	}

	/**
	 * Execute a team workflow
	 *
	 * @param array $team Team configuration.
	 * @param array $task Task to execute.
	 * @param array $context Execution context.
	 * @return array|WP_Error Workflow result or error.
	 */
	public function execute_team_workflow( $team, $task, $context = array() ) {
		if ( empty( $team['team_id'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_team',
				__( 'Invalid team configuration.', 'mcp-ai-wpoos' )
			);
		}

		$team_id  = $team['team_id'];
		$workflow = isset( $team['workflow'] ) ? $team['workflow'] : array();

		$this->log_team_action( $team_id, 'execution_started' );

		$execution_start = microtime( true );
		$results         = array();

		// Execute workflow steps.
		foreach ( $workflow as $step ) {
			$step_result = $this->execute_workflow_step( $team, $step, $task, $context, $results );

			if ( is_wp_error( $step_result ) ) {
				$this->log_team_action(
					$team_id,
					'step_failed',
					array(
						'step'  => $step['name'],
						'error' => $step_result->get_error_message(),
					)
				);

				// Handle failure based on criticality.
				if ( isset( $step['critical'] ) && $step['critical'] ) {
					return $step_result; // Stop on critical failure.
				}

				// Continue with non-critical failure.
				$results[ $step['name'] ] = array(
					'status' => 'failed',
					'error'  => $step_result,
				);
				continue;
			}

			$results[ $step['name'] ] = $step_result;
		}

		$execution_time = microtime( true ) - $execution_start;

		// Update team status.
		$team['status']         = 'completed';
		$team['execution_time'] = $execution_time;
		$this->store_team( $team );

		$this->log_team_action(
			$team_id,
			'execution_completed',
			array(
				'execution_time' => $execution_time,
				'steps'          => count( $workflow ),
			)
		);

		return array(
			'team_id'        => $team_id,
			'status'         => 'completed',
			'results'        => $results,
			'execution_time' => $execution_time,
			'completed_at'   => current_time( 'mysql' ),
		);
	}

	/**
	 * Track team performance metrics
	 *
	 * @param string $team_id Team ID.
	 * @param array  $execution_data Execution metrics.
	 * @return bool Success status.
	 */
	public function track_team_metrics( $team_id, $execution_data ) {
		$metrics_key = 'wp_mcp_ai_team_metrics_' . sanitize_key( $team_id );

		$metrics = array(
			'team_id'        => $team_id,
			'execution_time' => isset( $execution_data['execution_time'] ) ? $execution_data['execution_time'] : 0,
			'success_rate'   => isset( $execution_data['success_rate'] ) ? $execution_data['success_rate'] : 0,
			'step_count'     => isset( $execution_data['step_count'] ) ? $execution_data['step_count'] : 0,
			'recorded_at'    => current_time( 'mysql' ),
		);

		return set_transient( $metrics_key, $metrics, DAY_IN_SECONDS );
	}

	/**
	 * Execute a single workflow step
	 *
	 * @param array $team Team configuration.
	 * @param array $step Workflow step definition.
	 * @param array $task Original task.
	 * @param array $context Execution context.
	 * @param array $previous_results Results from previous steps.
	 * @return mixed|WP_Error Step result or error.
	 */
	protected function execute_workflow_step( $team, $step, $task, $context, $previous_results ) {
		$step_type = isset( $step['type'] ) ? $step['type'] : 'execute';
		$role      = isset( $step['role'] ) ? $step['role'] : null;

		// Find agent with required role.
		$agent = $this->find_team_member_by_role( $team, $role );
		if ( ! $agent ) {
			return new WP_Error(
				'wp_mcp_ai_no_agent_for_role',
				sprintf(
					/* translators: %s: role name */
					__( 'No agent available with role: %s', 'mcp-ai-wpoos' ),
					$role
				)
			);
		}

		// Execute based on step type.
		switch ( $step_type ) {
			case 'delegate':
				return $this->execute_delegation_step( $agent, $step, $task, $context );

			case 'aggregate':
				return $this->execute_aggregation_step( $previous_results, $step );

			case 'validate':
				return $this->execute_validation_step( $agent, $step, $previous_results );

			default:
				return $this->execute_generic_step( $agent, $step, $task, $context );
		}
	}

	/**
	 * Execute a delegation step
	 *
	 * Delegates a subtask to a specialized agent and executes it.
	 *
	 * @param array $agent Agent data.
	 * @param array $step Step definition.
	 * @param array $task Task data.
	 * @param array $context Context data.
	 * @return array|WP_Error Delegation result or error.
	 */
	protected function execute_delegation_step( $agent, $step, $task, $context ) {
		$subtask = isset( $step['subtask'] ) ? $step['subtask'] : $task;

		// Get agent role instance.
		$agent_role = null;
		if ( isset( $agent['id'] ) ) {
			$agent_role = wp_mcp_ai_get_assistant_role( $agent['id'] );
		}

		// Fallback to role type if assistant doesn't have a role set.
		if ( ! $agent_role && isset( $agent['role'] ) ) {
			$agent_role = wp_mcp_ai_get_agent_role( $agent['role'] );
		}

		if ( ! $agent_role ) {
			return new WP_Error(
				'wp_mcp_ai_no_agent_role',
				sprintf(
					/* translators: %d: agent ID */
					__( 'Agent %d does not have a valid role assigned.', 'mcp-ai-wpoos' ),
					$agent['id']
				)
			);
		}

		// Prepare task data for agent execution.
		$agent_task = array(
			'description' => isset( $subtask['description'] ) ? $subtask['description'] : ( isset( $task['description'] ) ? $task['description'] : '' ),
			'type'        => isset( $subtask['type'] ) ? $subtask['type'] : ( isset( $task['type'] ) ? $task['type'] : 'generic' ),
			'parameters'  => isset( $subtask['parameters'] ) ? $subtask['parameters'] : array(),
			'id'          => isset( $step['name'] ) ? $step['name'] : uniqid( 'subtask_', true ),
		);

		// Prepare execution context.
		$agent_context = array_merge(
			$context,
			array(
				'assistant_id' => $agent['id'],
				'delegated_by' => isset( $context['assistant_id'] ) ? $context['assistant_id'] : 0,
				'parent_task'  => isset( $task['id'] ) ? $task['id'] : null,
			)
		);

		// Execute the task using the agent's role.
		$result = $agent_role->execute_role_task( $agent_task, $agent_context );

		// Wrap result with delegation metadata.
		return array(
			'step_type'    => 'delegate',
			'agent_id'     => $agent['id'],
			'agent_role'   => $agent['role'],
			'subtask_id'   => $agent_task['id'],
			'subtask'      => $agent_task['description'],
			'status'       => is_wp_error( $result ) ? 'failed' : 'completed',
			'result'       => $result,
			'delegated_at' => current_time( 'mysql' ),
		);
	}

	/**
	 * Execute an aggregation step
	 *
	 * @param array $previous_results Previous step results.
	 * @param array $step Step definition.
	 * @return array|WP_Error Aggregation result or error.
	 */
	protected function execute_aggregation_step( $previous_results, $step ) {
		$strategy = isset( $step['strategy'] ) ? $step['strategy'] : 'consensus';

		// Extract results to aggregate.
		$results_to_aggregate = array();
		foreach ( $previous_results as $result ) {
			if ( isset( $result['result'] ) ) {
				$results_to_aggregate[] = $result;
			}
		}

		if ( empty( $results_to_aggregate ) ) {
			return array(
				'step_type' => 'aggregate',
				'strategy'  => $strategy,
				'result'    => null,
				'message'   => __( 'No results to aggregate', 'mcp-ai-wpoos' ),
			);
		}

		return $this->communication_service->aggregate_results( $results_to_aggregate, $strategy );
	}

	/**
	 * Execute a validation step
	 *
	 * Invokes a critic agent to validate previous results.
	 *
	 * @param array $agent Agent data.
	 * @param array $step Step definition.
	 * @param array $previous_results Previous step results.
	 * @return array|WP_Error Validation result or error.
	 */
	protected function execute_validation_step( $agent, $step, $previous_results ) {
		// Get critic agent role instance.
		$agent_role = null;
		if ( isset( $agent['id'] ) ) {
			$agent_role = wp_mcp_ai_get_assistant_role( $agent['id'] );
		}

		// Fallback to generic critic role.
		if ( ! $agent_role || $agent_role->get_role_type() !== 'critic' ) {
			$agent_role = wp_mcp_ai_get_agent_role( 'critic' );
		}

		if ( ! $agent_role ) {
			return new WP_Error(
				'wp_mcp_ai_no_critic_role',
				__( 'Critic agent role not available for validation.', 'mcp-ai-wpoos' )
			);
		}

		// Prepare validation task data.
		$validation_task = array(
			'description' => __( 'Validate the results from previous workflow steps', 'mcp-ai-wpoos' ),
			'type'        => 'validation',
			'parameters'  => array(
				'results_to_validate' => $previous_results,
				'validation_criteria' => isset( $step['criteria'] ) ? $step['criteria'] : array(),
			),
		);

		// Prepare context.
		$validation_context = array(
			'assistant_id'    => $agent['id'],
			'validation_step' => true,
		);

		// Execute validation.
		$result = $agent_role->execute_role_task( $validation_task, $validation_context );

		// Extract validation status.
		$validation_passes = true;
		$validation_score  = 0.85; // Default.

		if ( ! is_wp_error( $result ) ) {
			if ( isset( $result['validation'] ) && isset( $result['validation']['passes'] ) ) {
				$validation_passes = (bool) $result['validation']['passes'];
			}
			if ( isset( $result['overall_score'] ) ) {
				$validation_score = (float) $result['overall_score'];
			}
		}

		return array(
			'step_type'    => 'validate',
			'agent_id'     => $agent['id'],
			'agent_role'   => $agent['role'],
			'validation'   => array(
				'passes' => $validation_passes,
				'score'  => $validation_score,
				'result' => $result,
			),
			'validated_at' => current_time( 'mysql' ),
		);
	}

	/**
	 * Execute a generic step
	 *
	 * Executes a generic workflow step using the assigned agent.
	 *
	 * @param array $agent Agent data.
	 * @param array $step Step definition.
	 * @param array $task Task data.
	 * @param array $context Context data.
	 * @return array|WP_Error Step result or error.
	 */
	protected function execute_generic_step( $agent, $step, $task, $context ) {
		// Get agent role instance.
		$agent_role = null;
		if ( isset( $agent['id'] ) ) {
			$agent_role = wp_mcp_ai_get_assistant_role( $agent['id'] );
		}

		// Fallback to role type.
		if ( ! $agent_role && isset( $agent['role'] ) ) {
			$agent_role = wp_mcp_ai_get_agent_role( $agent['role'] );
		}

		// If no agent role, return placeholder.
		if ( ! $agent_role ) {
			return array(
				'step_type'  => 'execute',
				'agent_id'   => $agent['id'],
				'agent_role' => $agent['role'],
				'step_name'  => $step['name'] ?? 'unnamed',
				'status'     => 'no_role_assigned',
				'message'    => __( 'Agent does not have a role assigned', 'mcp-ai-wpoos' ),
			);
		}

		// Prepare task for agent.
		$agent_task = array(
			'description' => isset( $step['description'] ) ? $step['description'] : ( isset( $task['description'] ) ? $task['description'] : '' ),
			'type'        => isset( $step['type'] ) ? $step['type'] : 'generic',
			'parameters'  => isset( $step['parameters'] ) ? $step['parameters'] : array(),
		);

		// Prepare context.
		$agent_context = array_merge(
			$context,
			array(
				'assistant_id' => $agent['id'],
				'step_name'    => $step['name'] ?? 'unnamed',
			)
		);

		// Execute task with agent role.
		$result = $agent_role->execute_role_task( $agent_task, $agent_context );

		return array(
			'step_type'   => 'execute',
			'agent_id'    => $agent['id'],
			'agent_role'  => $agent['role'],
			'step_name'   => $step['name'] ?? 'unnamed',
			'status'      => is_wp_error( $result ) ? 'failed' : 'completed',
			'result'      => $result,
			'executed_at' => current_time( 'mysql' ),
		);
	}

	/**
	 * Find team member by role
	 *
	 * @param array  $team Team configuration.
	 * @param string $role Role identifier.
	 * @return array|null Agent data or null if not found.
	 */
	protected function find_team_member_by_role( $team, $role ) {
		if ( empty( $team['members'] ) || ! $role ) {
			return null;
		}

		foreach ( $team['members'] as $member ) {
			if ( isset( $member['role'] ) && $member['role'] === $role ) {
				return $member;
			}
		}

		return null;
	}

	/**
	 * Find available agents for required roles
	 *
	 * @param array $roles Required role identifiers.
	 * @return array Array of agent data.
	 */
	protected function find_agents_for_roles( $roles ) {
		$agents = array();

		foreach ( $roles as $role ) {
			// Query for assistants with this role.
			$query = new WP_Query(
				array(
					'post_type'      => 'mcp_ai_assistant',
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'meta_query'     => array(
						array(
							'key'     => '_wp_mcp_ai_agent_role',
							'value'   => $role,
							'compare' => '=',
						),
					),
				)
			);

			if ( $query->have_posts() ) {
				$agent_post = $query->posts[0];
				$agents[]   = array(
					'id'    => $agent_post->ID,
					'title' => $agent_post->post_title,
					'role'  => $role,
				);
			} else {
				// Try to find a generic agent if role-specific not found.
				$generic_query = new WP_Query(
					array(
						'post_type'      => 'mcp_ai_assistant',
						'post_status'    => 'publish',
						'posts_per_page' => 1,
						'orderby'        => 'rand',
					)
				);

				if ( $generic_query->have_posts() ) {
					$agent_post = $generic_query->posts[0];
					$agents[]   = array(
						'id'    => $agent_post->ID,
						'title' => $agent_post->post_title,
						'role'  => 'generalist',
					);
				}
			}

			wp_reset_postdata();
		}

		return $agents;
	}

	/**
	 * Initialize team templates
	 */
	protected function init_team_templates() {
		$this->team_templates = array(
			'research'    => array(
				'name'     => __( 'Research Team', 'mcp-ai-wpoos' ),
				'roles'    => array( 'planner', 'executor', 'critic' ),
				'workflow' => array(
					array(
						'name'     => 'plan',
						'type'     => 'delegate',
						'role'     => 'planner',
						'critical' => true,
					),
					array(
						'name'     => 'execute',
						'type'     => 'delegate',
						'role'     => 'executor',
						'critical' => true,
					),
					array(
						'name'     => 'validate',
						'type'     => 'validate',
						'role'     => 'critic',
						'critical' => false,
					),
				),
			),
			'content'     => array(
				'name'     => __( 'Content Creation Team', 'mcp-ai-wpoos' ),
				'roles'    => array( 'executor', 'critic' ),
				'workflow' => array(
					array(
						'name' => 'create',
						'type' => 'delegate',
						'role' => 'executor',
					),
					array(
						'name' => 'review',
						'type' => 'validate',
						'role' => 'critic',
					),
				),
			),
			'ecommerce'   => array(
				'name'     => __( 'E-commerce Team', 'mcp-ai-wpoos' ),
				'roles'    => array( 'planner', 'executor', 'critic' ),
				'workflow' => array(
					array(
						'name' => 'analyze',
						'type' => 'delegate',
						'role' => 'planner',
					),
					array(
						'name' => 'implement',
						'type' => 'delegate',
						'role' => 'executor',
					),
					array(
						'name' => 'validate',
						'type' => 'validate',
						'role' => 'critic',
					),
				),
			),
			'development' => array(
				'name'     => __( 'Development Team', 'mcp-ai-wpoos' ),
				'roles'    => array( 'planner', 'executor', 'critic' ),
				'workflow' => array(
					array(
						'name' => 'architect',
						'type' => 'delegate',
						'role' => 'planner',
					),
					array(
						'name' => 'code',
						'type' => 'delegate',
						'role' => 'executor',
					),
					array(
						'name' => 'review',
						'type' => 'validate',
						'role' => 'critic',
					),
				),
			),
			'generic'     => array(
				'name'     => __( 'Generic Team', 'mcp-ai-wpoos' ),
				'roles'    => array( 'executor' ),
				'workflow' => array(
					array(
						'name' => 'execute',
						'type' => 'delegate',
						'role' => 'executor',
					),
				),
			),
		);

		/**
		 * Filters team templates.
		 *
		 * @param array $templates Team templates.
		 */
		$this->team_templates = apply_filters( 'wp_mcp_ai_team_templates', $this->team_templates );
	}

	/**
	 * Get team template by type
	 *
	 * @param string $task_type Task type identifier.
	 * @return array|null Template data or null if not found.
	 */
	protected function get_team_template( $task_type ) {
		return isset( $this->team_templates[ $task_type ] ) ? $this->team_templates[ $task_type ] : null;
	}

	/**
	 * Store team configuration
	 *
	 * @param array $team Team data.
	 */
	protected function store_team( $team ) {
		$key = 'wp_mcp_ai_team_' . $team['team_id'];
		set_transient( $key, $team, DAY_IN_SECONDS );
	}

	/**
	 * Generate a unique team ID
	 *
	 * @return string Team ID.
	 */
	protected function generate_team_id() {
		return 'team_' . wp_generate_uuid4();
	}

	/**
	 * Log team action
	 *
	 * @param string $team_id Team ID.
	 * @param string $action Action performed.
	 * @param array  $data Additional data.
	 */
	protected function log_team_action( $team_id, $action, $data = array() ) {
		if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
			WP_MCP_AI_Logger::log(
				sprintf( 'Team %s: %s', $team_id, $action ),
				array_merge(
					array(
						'team_id' => $team_id,
						'action'  => $action,
					),
					$data
				),
				'info'
			);
		}
	}

	/**
	 * Check system capacity before composing team
	 *
	 * Ensures sufficient capacity available for multi-agent workflow.
	 * Phase 2.3: Multi-Agent Integration with capacity awareness.
	 *
	 * @param array $task_requirements Task requirements.
	 * @return true|WP_Error True if capacity sufficient, error otherwise.
	 */
	protected function check_system_capacity_for_team( $task_requirements ) {
		$monitor = $this->get_load_monitor();
		if ( ! $monitor ) {
			// Load monitor not available - allow team composition.
			return true;
		}

		// Get system capacity metrics.
		$system_metrics = $monitor->get_system_load_metrics();

		// Check if system is in critical state.
		if ( 'critical' === $system_metrics['health_status'] ) {
			// Check if this is a critical priority request.
			$is_critical = isset( $task_requirements['priority'] ) && 'critical' === $task_requirements['priority'];
			
			if ( ! $is_critical ) {
				return new WP_Error(
					'wp_mcp_ai_insufficient_capacity',
					sprintf(
						/* translators: %s: health status */
						__( 'System capacity is %s. Team workflow deferred to prevent overload.', 'mcp-ai-wpoos' ),
						$system_metrics['health_status']
					),
					array(
						'health_status'       => $system_metrics['health_status'],
						'available_capacity'  => $system_metrics['available_capacity'],
						'overall_utilization' => $system_metrics['overall_utilization'],
					)
				);
			}
		}

		// Log capacity check.
		$this->log_team_action(
			'capacity_check',
			'Team composition capacity check',
			array(
				'task_type'           => isset( $task_requirements['task_type'] ) ? $task_requirements['task_type'] : 'unknown',
				'health_status'       => $system_metrics['health_status'],
				'available_capacity'  => $system_metrics['available_capacity'],
			)
		);

		return true;
	}

	/**
	 * Find profession-based agent for role
	 *
	 * Queries profession CPT with agent_role metadata.
	 * Phase 2.3: Multi-Agent Integration.
	 *
	 * @param string $role Agent role (planner, executor, critic, etc.).
	 * @param array  $task_requirements Task requirements.
	 * @return array|null Agent data or null.
	 */
	protected function find_profession_agent_for_role( $role, $task_requirements = array() ) {
		// Query professions with agent_role meta.
		$args = array(
			'post_type'      => 'mcp_ai_profession',
			'post_status'    => 'publish',
			'posts_per_page' => 10,
			'meta_query'     => array(
				array(
					'key'     => '_agent_role',
					'value'   => $role,
					'compare' => '=',
				),
			),
		);

		$query = new WP_Query( $args );

		if ( ! $query->have_posts() ) {
			wp_reset_postdata();
			return null;
		}

		// Get first matching profession.
		$query->the_post();
		$post_id = get_the_ID();
		
		$profession_data = array(
			'id'         => $post_id,
			'role'       => $role,
			'type'       => 'profession',
			'profession' => get_post_field( 'post_name', $post_id ),
			'name'       => get_the_title(),
			'tools'      => get_post_meta( $post_id, '_tool_slugs', true ),
			'config'     => get_post_meta( $post_id, '_orchestration_config', true ),
		);

		wp_reset_postdata();
		
		return $profession_data;
	}

	/**
	 * Find generic agent for role (fallback)
	 *
	 * @param string $role Agent role.
	 * @return array|null Agent data or null.
	 */
	protected function find_generic_agent_for_role( $role ) {
		// Get generic agent by role.
		$agent_role = wp_mcp_ai_get_agent_role( $role );
		
		if ( ! $agent_role ) {
			return null;
		}

		return array(
			'id'   => 'generic_' . $role,
			'role' => $role,
			'type' => 'generic',
			'name' => ucfirst( $role ) . ' Agent',
		);
	}

	/**
	 * Get load monitor instance
	 *
	 * @return WP_MCP_AI_Tool_Load_Monitor|null
	 */
	protected function get_load_monitor() {
		if ( null === $this->load_monitor && class_exists( 'WP_MCP_AI_Tool_Load_Monitor' ) ) {
			$this->load_monitor = new WP_MCP_AI_Tool_Load_Monitor();
		}
		return $this->load_monitor;
	}

	/**
	 * Get tool orchestrator instance
	 *
	 * @return WP_MCP_AI_Tool_Execution_Orchestrator|null
	 */
	protected function get_tool_orchestrator() {
		if ( null === $this->tool_orchestrator && class_exists( 'WP_MCP_AI_Tool_Execution_Orchestrator' ) ) {
			$this->tool_orchestrator = new WP_MCP_AI_Tool_Execution_Orchestrator();
		}
		return $this->tool_orchestrator;
	}

	/**
	 * Get system capacity metrics for team
	 *
	 * Public method for external capacity queries.
	 * Phase 2.3: Multi-Agent Integration.
	 *
	 * @return array|null Capacity metrics or null.
	 */
	public function get_team_capacity_metrics() {
		$monitor = $this->get_load_monitor();
		if ( ! $monitor ) {
			return null;
		}

		return $monitor->get_system_load_metrics();
	}
}
