<?php
/**
 * Elementor Integration Admin Page
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Admin_Elementor_Integration' ) ) {
	/**
	 * Manages the Elementor integration admin page.
	 */
	class WP_MCP_AI_Admin_Elementor_Integration {
		const PAGE_SLUG = 'wp-mcp-ai-elementor';

		/**
		 * Page hook suffix.
		 *
		 * @var string
		 */
		private $page_hook = '';

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_action( 'admin_menu', array( $this, 'register_page' ) );
			add_action( 'admin_post_wp_mcp_ai_save_elementor_settings', array( $this, 'handle_save_settings' ) );
		}

		/**
		 * Handle settings save.
		 *
		 * @deprecated No longer needed as widgets are automatically enabled.
		 */
		public function handle_save_settings() {
			// Settings save no longer needed - widgets are automatically enabled when Elementor is active.
			// Redirect back to the page.
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'    => self::PAGE_SLUG,
						'updated' => 'true',
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		/**
		 * Register the integration page under the NV oOS menu.
		 */
		public function register_page() {
			$this->page_hook = add_submenu_page(
				'wp-mcp-ai-dashboard',
				__( 'Elementor Integration - NV oOS', 'mcp-ai-wpoos' ),
				__( 'Elementor', 'mcp-ai-wpoos' ),
				'manage_options',
				self::PAGE_SLUG,
				array( $this, 'render_page' )
			);
		}

		/**
		 * Render the integration page.
		 */
		public function render_page() {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			$elementor_active = defined( 'ELEMENTOR_VERSION' );
			$settings         = get_option( WP_MCP_AI_Admin_Settings::OPTION_NAME, array() );
			?>
			<div class="wrap">
				<h1><?php esc_html_e( 'Elementor Integration', 'mcp-ai-wpoos' ); ?></h1>

				<div style="background: <?php echo esc_attr( $elementor_active ? '#d5f0db' : '#f0f0f1' ); ?>; border-left: 4px solid <?php echo esc_attr( $elementor_active ? '#0a5f1a' : '#646970' ); ?>; padding: 1.5rem; margin: 1.5rem 0;">
					<?php if ( $elementor_active ) : ?>
						<h2 style="margin-top: 0; color: #0a5f1a;">✓ <?php esc_html_e( 'Elementor Active - Widgets Automatically Enabled', 'mcp-ai-wpoos' ); ?></h2>
						<p><?php esc_html_e( 'Elementor is installed and active. All AI Chat widgets are automatically available in the Elementor editor.', 'mcp-ai-wpoos' ); ?></p>
						<p><strong><?php esc_html_e( 'Version:', 'mcp-ai-wpoos' ); ?></strong> <?php echo esc_html( ELEMENTOR_VERSION ); ?></p>
					<?php else : ?>
						<h2 style="margin-top: 0; color: #646970;"><?php esc_html_e( 'Elementor Not Active', 'mcp-ai-wpoos' ); ?></h2>
						<p><?php esc_html_e( 'Elementor is not installed or not active.', 'mcp-ai-wpoos' ); ?></p>
						<p><strong><?php esc_html_e( 'To enable Elementor integration:', 'mcp-ai-wpoos' ); ?></strong></p>
						<ol>
							<li><?php esc_html_e( 'Install Elementor from WordPress.org', 'mcp-ai-wpoos' ); ?></li>
							<li><?php esc_html_e( 'Activate the plugin', 'mcp-ai-wpoos' ); ?></li>
							<li><?php esc_html_e( 'Widgets will be automatically available in Elementor editor', 'mcp-ai-wpoos' ); ?></li>
						</ol>
					<?php endif; ?>
				</div>

				<?php if ( $elementor_active ) : ?>
					<h2><?php esc_html_e( 'Available Elementor Widgets', 'mcp-ai-wpoos' ); ?></h2>
					<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; margin-top: 1rem;">
						<div style="background: #fff; border: 1px solid #dcdcde; padding: 1.5rem; border-radius: 4px;">
							<h3 style="margin-top: 0;"><?php esc_html_e( 'NV oOS Chat', 'mcp-ai-wpoos' ); ?></h3>
							<p><?php esc_html_e( 'Interactive AI chat interface with streaming responses', 'mcp-ai-wpoos' ); ?></p>
							<ul style="margin-left: 1.5rem;">
								<li><?php esc_html_e( 'Real-time SSE streaming', 'mcp-ai-wpoos' ); ?></li>
								<li><?php esc_html_e( 'Customizable styling', 'mcp-ai-wpoos' ); ?></li>
								<li><?php esc_html_e( 'Tool execution feedback', 'mcp-ai-wpoos' ); ?></li>
								<li><?php esc_html_e( 'Markdown rendering', 'mcp-ai-wpoos' ); ?></li>
							</ul>
						</div>

						<div style="background: #fff; border: 1px solid #dcdcde; padding: 1.5rem; border-radius: 4px;">
							<h3 style="margin-top: 0;"><?php esc_html_e( 'Assistant Selector', 'mcp-ai-wpoos' ); ?></h3>
							<p><?php esc_html_e( 'Dropdown to switch between available assistants', 'mcp-ai-wpoos' ); ?></p>
							<ul style="margin-left: 1.5rem;">
								<li><?php esc_html_e( 'Dynamic assistant list', 'mcp-ai-wpoos' ); ?></li>
								<li><?php esc_html_e( 'Role-based filtering', 'mcp-ai-wpoos' ); ?></li>
								<li><?php esc_html_e( 'Seamless switching', 'mcp-ai-wpoos' ); ?></li>
							</ul>
						</div>

						<div style="background: #fff; border: 1px solid #dcdcde; padding: 1.5rem; border-radius: 4px;">
							<h3 style="margin-top: 0;"><?php esc_html_e( 'Chat History', 'mcp-ai-wpoos' ); ?></h3>
							<p><?php esc_html_e( 'Display conversation history with filtering', 'mcp-ai-wpoos' ); ?></p>
							<ul style="margin-left: 1.5rem;">
								<li><?php esc_html_e( 'Persistent transcripts', 'mcp-ai-wpoos' ); ?></li>
								<li><?php esc_html_e( 'Date filtering', 'mcp-ai-wpoos' ); ?></li>
								<li><?php esc_html_e( 'Export functionality', 'mcp-ai-wpoos' ); ?></li>
							</ul>
						</div>
					</div>

					<?php
					// Debug information to help diagnose configuration issues.
					// Check if integrations (including Elementor) should be loaded.
					// This returns true when either in full version mode OR when Pro addon is active.
					$integrations_enabled = wp_mcp_ai_should_load_integrations();
					$is_base_version      = wp_mcp_ai_is_base_version();
					$is_pro_active        = defined( 'WP_MCP_AI_PRO_VERSION' );
						$constant_defined     = defined( 'WP_MCP_AI_BASE_VERSION' );
						$constant_value       = $constant_defined ? WP_MCP_AI_BASE_VERSION : 'not defined';
						?>

						<div style="background: #f0f6fc; border-left: 4px solid #2271b1; padding: 1rem; margin-top: 1.5rem;">
							<p style="margin: 0;"><strong><?php esc_html_e( 'Current Configuration:', 'mcp-ai-wpoos' ); ?></strong></p>
							<ul style="margin: 0.5rem 0 0 1.5rem;">
								<li>
									<strong>WP_MCP_AI_BASE_VERSION constant:</strong>
									<?php
									if ( $constant_defined ) {
										echo '<code>' . esc_html( $constant_value ? 'true' : 'false' ) . '</code>';
									} else {
										echo '<code>not defined</code> (defaults to full version)';
									}
									?>
								</li>
								<?php if ( $is_pro_active ) : ?>
									<li><strong>Pro Addon:</strong> <code>active</code></li>
								<?php endif; ?>
								<li>
									<strong>Integration Mode:</strong>
									<?php
									if ( $integrations_enabled ) {
										if ( $is_base_version && $is_pro_active ) {
											echo wp_kses_post( '<strong style="color: #0a5f1a;">Base + Pro</strong> (Elementor widgets enabled via Pro addon)' );
										} else {
											echo wp_kses_post( '<strong style="color: #0a5f1a;">Full Version</strong> (Elementor widgets enabled)' );
										}
									} else {
										echo wp_kses_post( '<strong style="color: #8b6c00;">Base Version</strong> (Elementor widgets disabled)' );
									}
									?>
								</li>
							</ul>
						</div>

						<?php if ( ! $integrations_enabled ) : ?>
							<div style="background: #fef7e0; border-left: 4px solid #8b6c00; padding: 1rem; margin-top: 1.5rem;">
								<p style="margin: 0;"><strong><?php esc_html_e( 'To Enable Elementor Widgets:', 'mcp-ai-wpoos' ); ?></strong></p>
								<p style="margin: 0.5rem 0;">
									<?php esc_html_e( 'You have two options:', 'mcp-ai-wpoos' ); ?>
								</p>
								<p style="margin: 0.5rem 0 0 0;">
									<strong>1.</strong> <?php esc_html_e( 'Set full version mode by adding to wp-config.php:', 'mcp-ai-wpoos' ); ?><br>
									<code style="background: #fff; padding: 0.25rem 0.5rem; display: inline-block; margin-top: 0.5rem;">define( 'WP_MCP_AI_BASE_VERSION', false );</code>
								</p>
								<p style="margin: 0.5rem 0 0 0;">
									<strong>2.</strong> <?php esc_html_e( 'Or install the Pro addon which enables integrations in base version mode.', 'mcp-ai-wpoos' ); ?>
								</p>
								<p style="margin: 0.5rem 0 0 0; font-size: 0.9em; color: #646970;">
									<?php esc_html_e( 'After making changes, refresh this page to verify.', 'mcp-ai-wpoos' ); ?>
								</p>
							</div>
						<?php else : ?>
							<div style="background: #d5f0db; border-left: 4px solid #0a5f1a; padding: 1rem; margin-top: 1.5rem;">
								<p style="margin: 0;"><strong style="color: #0a5f1a;">✓ <?php esc_html_e( 'Elementor Widgets Enabled', 'mcp-ai-wpoos' ); ?></strong></p>
								<p style="margin: 0.5rem 0 0 0;">
									<?php esc_html_e( 'Integration mode is active. All Elementor widgets are available in the editor.', 'mcp-ai-wpoos' ); ?>
								</p>
							</div>
						<?php endif; ?>

						<?php submit_button( __( 'Save Elementor Settings', 'mcp-ai-wpoos' ) ); ?>
					</form>

					<div style="background: #f0f6fc; border-left: 4px solid #2271b1; padding: 1.5rem; margin-top: 2rem;">
						<h3 style="margin-top: 0;"><?php esc_html_e( 'Using Widgets in Elementor', 'mcp-ai-wpoos' ); ?></h3>
						<ol>
							<li><?php esc_html_e( 'Edit a page with Elementor', 'mcp-ai-wpoos' ); ?></li>
							<li><?php esc_html_e( 'Search for "NV oOS" in the widget panel', 'mcp-ai-wpoos' ); ?></li>
							<li><?php esc_html_e( 'Drag the desired widget to your page', 'mcp-ai-wpoos' ); ?></li>
							<li><?php esc_html_e( 'Configure widget settings in the left panel', 'mcp-ai-wpoos' ); ?></li>
							<li><?php esc_html_e( 'Publish or update your page', 'mcp-ai-wpoos' ); ?></li>
						</ol>
					</div>
				<?php endif; ?>
			</div>
			<?php
		}
	}
}
