<?php
declare(strict_types=1);

namespace NvoosContentGraphAiPlatform;

final class Plugin {

	private static ?self $instance = null;

	private function __construct() {}

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function register(): void {
		// Loud degradation notice when subsystems have no implementation
		// (base plugin absent, or greenfield subsystems not yet built).
		RuntimeMode::register();

		// Post types register on init — must be hooked before admin_menu fires.
		$this->registerPostTypes();

		if ( is_admin() ) {
			$this->registerAdmin();
		}

		$this->registerAgents();
		$this->registerSkills();
		$this->registerSlashCommands();
		$this->registerHarness();
		$this->registerMeasurement();
		$this->registerProfessions();
		$this->registerTeams();
		$this->registerA2A();
		$this->registerACP();
		$this->registerFederation();
		$this->registerBlueprints();
	}

	private function registerAdmin(): void {
		// 1. Own top-level "NV Platform" menu + tabbed dashboard.
		if ( class_exists( __NAMESPACE__ . '\Admin\PlatformDashboard' ) ) {
			( new \NvoosContentGraphAiPlatform\Admin\PlatformDashboard() )->register();
		}

		// 2. Built-in dashboard sections (Overview + General).
		$this->registerBuiltinSections();

		// 3. (Optional) Keep Content Graph tab-injection as courtesy.
		if ( class_exists( __NAMESPACE__ . '\Admin\PlatformSettings' ) ) {
			( new \NvoosContentGraphAiPlatform\Admin\PlatformSettings() )->register();
		}
	}

	/**
	 * Register built-in dashboard sections.
	 *
	 * Overview and General are core sections that always render.
	 * Subsystem sections self-register via the
	 * `nvoos_content_graph_ai_platform_admin_register_sections` action.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function registerBuiltinSections(): void {
		add_action(
			'nvoos_content_graph_ai_platform_admin_register_sections',
			static function (): void {
				if ( class_exists( 'NvoosContentGraphAiPlatform\Admin\Sections\OverviewSection' ) ) {
					\NvoosContentGraphAiPlatform\Admin\PlatformSettingsRegistry::register_section(
						new \NvoosContentGraphAiPlatform\Admin\Sections\OverviewSection()
					);
				}
				if ( class_exists( 'NvoosContentGraphAiPlatform\Admin\Sections\GeneralSection' ) ) {
					\NvoosContentGraphAiPlatform\Admin\PlatformSettingsRegistry::register_section(
						new \NvoosContentGraphAiPlatform\Admin\Sections\GeneralSection()
					);
				}
			}
		);
	}

	/**
	 * Register custom post types owned by the Platform addon.
	 *
	 * All CPTs appear under the "NV Platform" admin menu.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function registerPostTypes(): void {
		if ( class_exists( __NAMESPACE__ . '\PostTypes\ProjectCpt' ) ) {
			( new \NvoosContentGraphAiPlatform\PostTypes\ProjectCpt() )->register();
		}
		if ( class_exists( __NAMESPACE__ . '\PostTypes\ResourceCpt' ) ) {
			( new \NvoosContentGraphAiPlatform\PostTypes\ResourceCpt() )->register();
		}
		if ( class_exists( __NAMESPACE__ . '\PostTypes\TemplateCpt' ) ) {
			( new \NvoosContentGraphAiPlatform\PostTypes\TemplateCpt() )->register();
		}
	}

	private function registerAgents(): void {
		if ( class_exists( __NAMESPACE__ . '\Agents\Agents' ) ) {
			\NvoosContentGraphAiPlatform\Agents\Agents::instance()->register();
		}
	}

	private function registerSkills(): void {
		if ( class_exists( __NAMESPACE__ . '\Skills\SkillService' ) ) {
			\NvoosContentGraphAiPlatform\Skills\SkillService::instance()->register();
		}
	}

	private function registerSlashCommands(): void {
		if ( class_exists( __NAMESPACE__ . '\SlashCommands\SlashCommandService' ) ) {
			\NvoosContentGraphAiPlatform\SlashCommands\SlashCommandService::instance()->register();
		}
	}

	private function registerHarness(): void {
		if ( class_exists( __NAMESPACE__ . '\Harness\HarnessService' ) ) {
			\NvoosContentGraphAiPlatform\Harness\HarnessService::instance()->register();
		}
	}

	private function registerMeasurement(): void {
		if ( class_exists( __NAMESPACE__ . '\Measurement\MeasurementService' ) ) {
			\NvoosContentGraphAiPlatform\Measurement\MeasurementService::instance()->register();
		}
	}

	private function registerProfessions(): void {
		if ( class_exists( __NAMESPACE__ . '\Professions\ProfessionService' ) ) {
			\NvoosContentGraphAiPlatform\Professions\ProfessionService::instance()->register();
		}
	}

	private function registerTeams(): void {
		if ( class_exists( __NAMESPACE__ . '\Teams\TeamsService' ) ) {
			\NvoosContentGraphAiPlatform\Teams\TeamsService::instance()->register();
		}
	}

	private function registerA2A(): void {
		if ( class_exists( __NAMESPACE__ . '\A2A\A2AService' ) ) {
			\NvoosContentGraphAiPlatform\A2A\A2AService::instance()->register();
		}
	}

	private function registerACP(): void {
		if ( class_exists( __NAMESPACE__ . '\ACP\ACPService' ) ) {
			\NvoosContentGraphAiPlatform\ACP\ACPService::instance()->register();
		}
	}

	private function registerFederation(): void {
		if ( class_exists( __NAMESPACE__ . '\Federation\FederationService' ) ) {
			\NvoosContentGraphAiPlatform\Federation\FederationService::instance()->register();
		}
	}

	private function registerBlueprints(): void {
		if ( class_exists( __NAMESPACE__ . '\Blueprints\BlueprintService' ) ) {
			\NvoosContentGraphAiPlatform\Blueprints\BlueprintService::instance()->register();
		}
	}

	private function __clone() {}
}
