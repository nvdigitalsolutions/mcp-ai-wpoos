<?php
/**
 * Tool that manages product data in Flowhub API (create/update).
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent parse errors on PHP < 7.4 by exiting before class definition.
if ( version_compare( PHP_VERSION, '7.4.0', '<' ) ) {
	return;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-flowhub-client.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-logger.php';

/**
 * Provides a tool for creating and updating products in Flowhub.
 */
class WP_MCP_AI_Tool_Flowhub_Manage_Product implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'flowhub_manage_product';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Flowhub Manage Product', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Create or update cannabis products in Flowhub dispensary system. Supports managing product details, pricing, THC/CBD content, categories, and compliance information.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'connection_id' => array(
					'type'        => 'string',
					'description' => __( 'Optional Remote Sites connection ID for Flowhub. If not provided, will use settings-based configuration.', 'nvdigital-open-operator-system-oos' ),
				),
				'action'        => array(
					'type'        => 'string',
					'description' => __( 'Action to perform: "create" or "update".', 'nvdigital-open-operator-system-oos' ),
					'enum'        => array( 'create', 'update' ),
				),
				'product_id'    => array(
					'type'        => 'string',
					'description' => __( 'Product ID (required for update action).', 'nvdigital-open-operator-system-oos' ),
				),
				'name'          => array(
					'type'        => 'string',
					'description' => __( 'Product name.', 'nvdigital-open-operator-system-oos' ),
				),
				'description'   => array(
					'type'        => 'string',
					'description' => __( 'Product description.', 'nvdigital-open-operator-system-oos' ),
				),
				'category'      => array(
					'type'        => 'string',
					'description' => __( 'Product category (e.g., "flower", "concentrate", "edible").', 'nvdigital-open-operator-system-oos' ),
				),
				'price'         => array(
					'type'        => 'number',
					'description' => __( 'Product price.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 0,
				),
				'thc_percent'   => array(
					'type'        => 'number',
					'description' => __( 'THC percentage content.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 0,
					'maximum'     => 100,
				),
				'cbd_percent'   => array(
					'type'        => 'number',
					'description' => __( 'CBD percentage content.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 0,
					'maximum'     => 100,
				),
				'strain_type'   => array(
					'type'        => 'string',
					'description' => __( 'Strain type (e.g., "indica", "sativa", "hybrid").', 'nvdigital-open-operator-system-oos' ),
					'enum'        => array( 'indica', 'sativa', 'hybrid', 'cbd' ),
				),
				'brand'         => array(
					'type'        => 'string',
					'description' => __( 'Product brand name.', 'nvdigital-open-operator-system-oos' ),
				),
				'sku'           => array(
					'type'        => 'string',
					'description' => __( 'Product SKU/barcode.', 'nvdigital-open-operator-system-oos' ),
				),
				'timeout'       => array(
					'type'        => 'integer',
					'description' => __( 'Request timeout in seconds (5-60).', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 5,
					'maximum'     => 60,
					'default'     => 30,
				),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Check whether the tool can be registered.
	 *
	 * @since 1.1.22
	 * @return bool
	 */
	public static function is_available() {
		return class_exists( 'WP_MCP_AI_Flowhub_Client' );
	}

	/**
	 * Provide a message explaining why the tool is unavailable.
	 *
	 * @since 1.1.22
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'Flowhub client is not available. The Flowhub integration requires API credentials to be configured.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id   = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : 0;
		$has_token = ! empty( $context['token_authenticated'] );

		if ( ! $user_id && ! $has_token ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You must be authenticated to manage Flowhub products.', 'nvdigital-open-operator-system-oos' ), array( 'status' => rest_authorization_required_code() ) );
		}

		if ( $user_id ) {
			// Require manage_woocommerce or manage_options capability.
			if ( ! user_can( $user_id, 'manage_woocommerce' ) && ! user_can( $user_id, 'manage_options' ) ) {
				return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to manage product data.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
				return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
			}
		}

		$action = isset( $arguments['action'] ) ? sanitize_text_field( $arguments['action'] ) : '';

		if ( ! in_array( $action, array( 'create', 'update' ), true ) ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_action',
				__( 'Action must be either "create" or "update".', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 400 )
			);
		}

		if ( 'update' === $action && empty( $arguments['product_id'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_missing_product_id',
				__( 'A product_id is required for update action.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 400 )
			);
		}

		// Get connection_id if provided.
		$connection_id = isset( $arguments['connection_id'] ) ? sanitize_key( $arguments['connection_id'] ) : null;

		// Validate connection if provided.
		if ( ! empty( $connection_id ) && class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
			$connection = WP_MCP_AI_Pro_Remote_Site_Manager::get_connection( $connection_id );

			if ( null === $connection ) {
				return new WP_Error(
					'wp_mcp_ai_pro_connection_not_found',
					__( 'Connection not found. Please check the connection ID.', 'nvdigital-open-operator-system-oos' )
				);
			}

			// Validate connection type.
			if ( empty( $connection['connection_type'] ) || 'flowhub' !== $connection['connection_type'] ) {
				return new WP_Error(
					'wp_mcp_ai_pro_wrong_connection_type',
					__( 'This connection is not a Flowhub connection.', 'nvdigital-open-operator-system-oos' )
				);
			}

			// Check if connection is enabled.
			if ( empty( $connection['enabled'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_pro_connection_disabled',
					__( 'This connection is disabled. Please enable it in Remote Sites settings.', 'nvdigital-open-operator-system-oos' )
				);
			}
		}

		// Resolve credentials explicitly from connection or settings.
		$client_id   = '';
		$api_key     = '';
		$location_id = '';
		if ( ! empty( $connection_id ) && class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
			$connection_data = WP_MCP_AI_Pro_Remote_Site_Manager::get_connection( $connection_id );
			$client_id       = isset( $connection_data['client_id'] ) ? $connection_data['client_id'] : '';
			$api_key         = isset( $connection_data['api_key'] ) ? WP_MCP_AI_Pro_Remote_Site_Manager::decrypt_value( $connection_data['api_key'] ) : '';
			$location_id     = isset( $connection_data['location_id'] ) ? $connection_data['location_id'] : '';
		} else {
			$settings    = get_option( 'wp_mcp_ai_flowhub_toolkit_settings', array() );
			$client_id   = isset( $settings['client_id'] ) ? wp_unslash( $settings['client_id'] ) : '';
			$api_key     = isset( $settings['api_key'] ) ? wp_unslash( $settings['api_key'] ) : '';
			$location_id = isset( $settings['location_id'] ) ? wp_unslash( $settings['location_id'] ) : '';
		}

		if ( empty( $client_id ) || empty( $api_key ) ) {
			return new WP_Error(
				'wp_mcp_ai_flowhub_missing_credentials',
				__( 'FlowHub API credentials are not configured.', 'nvdigital-open-operator-system-oos' )
			);
		}

		// Use the base client class, passing connection_id for lazy credential resolution.
		if ( ! class_exists( 'WP_MCP_AI_Flowhub_Client' ) ) {
			require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-flowhub-client.php';
		}
		$client       = new WP_MCP_AI_Flowhub_Client( $connection_id );
		$product_data = array();

		if ( isset( $arguments['name'] ) ) {
			$product_data['name'] = sanitize_text_field( $arguments['name'] );
		}
		if ( isset( $arguments['description'] ) ) {
			$product_data['description'] = sanitize_textarea_field( $arguments['description'] );
		}
		if ( isset( $arguments['category'] ) ) {
			$product_data['category'] = sanitize_text_field( $arguments['category'] );
		}
		if ( isset( $arguments['price'] ) ) {
			$product_data['price'] = floatval( $arguments['price'] );
		}
		if ( isset( $arguments['thc_percent'] ) ) {
			$product_data['thc_percent'] = floatval( $arguments['thc_percent'] );
		}
		if ( isset( $arguments['cbd_percent'] ) ) {
			$product_data['cbd_percent'] = floatval( $arguments['cbd_percent'] );
		}
		if ( isset( $arguments['strain_type'] ) ) {
			$product_data['strain_type'] = sanitize_text_field( $arguments['strain_type'] );
		}
		if ( isset( $arguments['brand'] ) ) {
			$product_data['brand'] = sanitize_text_field( $arguments['brand'] );
		}
		if ( isset( $arguments['sku'] ) ) {
			$product_data['sku'] = sanitize_text_field( $arguments['sku'] );
		}

		$options = array();
		if ( isset( $arguments['timeout'] ) ) {
			$options['timeout'] = max( 5, min( 60, absint( $arguments['timeout'] ) ) );
		}

		if ( 'create' === $action ) {
			$result = $client->create_product( $product_data, $options );
		} else {
			$product_id = sanitize_text_field( $arguments['product_id'] );
			$result     = $client->update_product( $product_id, $product_data, $options );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Add summary for frontend display.
		$product_id = isset( $result['id'] ) ? $result['id'] : '';
		$summary    = sprintf(
			/* translators: 1: action, 2: product ID */
			__( 'Successfully %1$s product: %2$s', 'nvdigital-open-operator-system-oos' ),
			'create' === $action ? __( 'created', 'nvdigital-open-operator-system-oos' ) : __( 'updated', 'nvdigital-open-operator-system-oos' ),
			$product_id
		);

		$result = array_merge(
			array(
				'message' => $summary, // Chat client.
				'summary' => $summary, // Backward compatibility.
			),
			$result
		);

		/**
		 * Allow third parties to filter the Flowhub manage product result.
		 *
		 * @param array $result    Final response payload.
		 * @param array $arguments Original tool arguments.
		 * @param array $context   Invocation context.
		 */
		$result = apply_filters( 'wp_mcp_ai_flowhub_manage_product_result', $result, $arguments, $context );

		return $result;
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'ecommerce_business',

			'pattern_compatibility' => array( 'orchestrator' ),

			'profession_tags'       => array( 'product_manager', 'inventory_specialist' ),

			'risk_level'            => 'standard',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro tier tool.
			'external-api',         // Makes external API calls.
			'requires-credentials', // Requires Flowhub API credentials.
			'requires-capability',  // Requires user capabilities.
			'write',                // Creates or modifies data.
			'state-changing',       // Modifies external system state.
			'rate-limited',         // Subject to Flowhub API rate limits.
		);
	}
}
