<?php
/**
 * Product Research Tool
 *
 * Provides AI-powered product research capabilities for WooCommerce products.
 * Helps gather and structure product information before creating products.
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tool for researching product information.
 *
 * This tool assists in gathering structured product data including:
 * - Product name, brand, and reference/SKU
 * - Pricing information
 * - Descriptions and specifications
 * - Images and media
 * - Categories and tags
 * - Attributes and variations
 *
 * @since 1.0.0
 */
class WP_MCP_AI_Tool_Research_Product implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface {

	/**
	 * Check if this tool is available.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if WooCommerce is active.
	 */
	public static function is_available() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Get the reason why this tool is unavailable.
	 *
	 * @since 1.0.0
	 *
	 * @return string Reason message.
	 */
	public static function get_unavailable_reason() {
		return __( 'Product research tool requires WooCommerce to be installed and activated.', 'mcp-ai-pro' );
	}

	/**
	 * Get the tool slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'research_product';
	}

	/**
	 * Get the tool name.
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'Research Product', 'mcp-ai-pro' );
	}

	/**
	 * Get the tool description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Research and gather structured information about a product before creating it in WooCommerce. Returns product data that can be used with the Create WooCommerce Product Draft tool.', 'mcp-ai-pro' );
	}

	/**
	 * Get the parameters schema.
	 *
	 * @return array
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'query'               => array(
					'type'        => 'string',
					'description' => __( 'The product to research (e.g., "Nike Air Max 270", "Apple MacBook Pro 16-inch M3").', 'mcp-ai-pro' ),
				),
				'include_pricing'     => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to include pricing information in the research.', 'mcp-ai-pro' ),
					'default'     => true,
				),
				'include_images'      => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to include image URLs in the research.', 'mcp-ai-pro' ),
					'default'     => true,
				),
				'include_specs'       => array(
					'type'        => 'boolean',
					'description' => __( 'Whether to include product specifications and attributes.', 'mcp-ai-pro' ),
					'default'     => true,
				),
				'suggested_reference' => array(
					'type'        => 'string',
					'description' => __( 'Optional SKU or reference identifier to use for the product.', 'mcp-ai-pro' ),
				),
			),
			'required'   => array( 'query' ),
		);
	}

	/**
	 * Get capability flags.
	 *
	 * @return array<string>
	 */
	public function get_capability_flags() {
		return array(
			'pro',              // Pro tier tool.
			'read-only',        // Research only, doesn't modify data.
			'requires-plugin',  // Requires WooCommerce.
			'local-only',       // No external API calls.
		);
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return mixed|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Check if WooCommerce is active.
		if ( ! self::is_available() ) {
			return new WP_Error(
				'woocommerce_not_active',
				__( 'WooCommerce is not installed or activated.', 'mcp-ai-pro' )
			);
		}

		// Validate query parameter.
		if ( empty( $arguments['query'] ) ) {
			return new WP_Error(
				'missing_query',
				__( 'Product query is required.', 'mcp-ai-pro' )
			);
		}

		$query = sanitize_text_field( $arguments['query'] );

		// Build research context.
		$include_pricing = isset( $arguments['include_pricing'] ) ? (bool) $arguments['include_pricing'] : true;
		$include_images  = isset( $arguments['include_images'] ) ? (bool) $arguments['include_images'] : true;
		$include_specs   = isset( $arguments['include_specs'] ) ? (bool) $arguments['include_specs'] : true;

		// Generate suggested reference if not provided.
		$reference = isset( $arguments['suggested_reference'] ) && ! empty( $arguments['suggested_reference'] )
			? sanitize_text_field( $arguments['suggested_reference'] )
			: $this->generate_reference( $query );

		// Build research guidance.
		$guidance = $this->build_research_guidance( $query, $include_pricing, $include_images, $include_specs );

		// Return research structure and guidance.
		return array(
			'status'         => 'research_initiated',
			'query'          => $query,
			'reference'      => $reference,
			'guidance'       => $guidance,
			'structure'      => $this->get_product_structure(),
			'next_steps'     => array(
				__( 'Use the research guidance to gather product information from available sources.', 'mcp-ai-pro' ),
				__( 'Structure the gathered information according to the provided schema.', 'mcp-ai-pro' ),
				__( 'Once you have complete product data, use the "Create WooCommerce Product Draft" tool.', 'mcp-ai-pro' ),
			),
			'create_tool'    => 'create_woo_product',
			'tool_arguments' => array(
				'reference' => $reference,
				'title'     => sprintf( __( 'Replace with actual product name for: %s', 'mcp-ai-pro' ), $query ),
				'brand'     => __( 'Replace with actual brand name', 'mcp-ai-pro' ),
				// Additional fields to be filled based on research.
			),
		);
	}

	/**
	 * Generate a reference/SKU from the query.
	 *
	 * @param string $query Product query.
	 * @return string Generated reference.
	 */
	protected function generate_reference( $query ) {
		// Create a simple reference from the query.
		$reference = strtoupper( preg_replace( '/[^a-zA-Z0-9]/', '-', $query ) );
		$reference = preg_replace( '/-+/', '-', $reference ); // Remove multiple dashes.
		$reference = trim( $reference, '-' );

		// Limit length.
		if ( strlen( $reference ) > 50 ) {
			$reference = substr( $reference, 0, 50 );
		}

		return $reference;
	}

	/**
	 * Build research guidance for the AI.
	 *
	 * @param string $query          Product query.
	 * @param bool   $include_pricing Include pricing guidance.
	 * @param bool   $include_images  Include image guidance.
	 * @param bool   $include_specs   Include specifications guidance.
	 * @return string Research guidance.
	 */
	protected function build_research_guidance( $query, $include_pricing, $include_images, $include_specs ) {
		$guidance = sprintf(
			__( 'Research the following product: %s', 'mcp-ai-pro' ),
			$query
		) . "\n\n";

		$guidance .= __( 'Gather the following information:', 'mcp-ai-pro' ) . "\n";
		$guidance .= __( '1. Product name and brand', 'mcp-ai-pro' ) . "\n";
		$guidance .= __( '2. Full product description (features, benefits, use cases)', 'mcp-ai-pro' ) . "\n";
		$guidance .= __( '3. Short description for product summary', 'mcp-ai-pro' ) . "\n";

		if ( $include_pricing ) {
			$guidance .= __( '4. Regular price in local currency', 'mcp-ai-pro' ) . "\n";
			$guidance .= __( '5. Sale price if available', 'mcp-ai-pro' ) . "\n";
		}

		if ( $include_images ) {
			$guidance .= __( '6. Product image URLs (at least 2-3 high-quality images)', 'mcp-ai-pro' ) . "\n";
		}

		if ( $include_specs ) {
			$guidance .= __( '7. Product specifications and attributes (size, color, material, etc.)', 'mcp-ai-pro' ) . "\n";
			$guidance .= __( '8. Technical specifications if applicable', 'mcp-ai-pro' ) . "\n";
		}

		$guidance .= __( '9. Suggested product categories and tags', 'mcp-ai-pro' ) . "\n";
		$guidance .= __( '10. Product type (simple, variable, grouped, external)', 'mcp-ai-pro' ) . "\n";

		return $guidance;
	}

	/**
	 * Get the expected product data structure.
	 *
	 * @return array Product structure schema.
	 */
	protected function get_product_structure() {
		return array(
			'reference'             => __( 'Product SKU/reference identifier (required)', 'mcp-ai-pro' ),
			'title'                 => __( 'Product name (required)', 'mcp-ai-pro' ),
			'brand'                 => __( 'Brand name', 'mcp-ai-pro' ),
			'product_type'          => __( 'Product type: simple or variable (default: simple)', 'mcp-ai-pro' ),
			'description'           => __( 'Full product description with HTML formatting', 'mcp-ai-pro' ),
			'description_secondary' => __( 'Short description or excerpt', 'mcp-ai-pro' ),
			'local_price'           => __( 'Regular price (number or string)', 'mcp-ai-pro' ),
			'sale_price'            => __( 'Sale price if on sale (number or string)', 'mcp-ai-pro' ),
			'image_urls'            => __( 'Array of product image URLs (2-10 images)', 'mcp-ai-pro' ),
			'categories'            => __( 'Array of category names or IDs', 'mcp-ai-pro' ),
			'tags'                  => __( 'Array of tag names or IDs', 'mcp-ai-pro' ),
			'attributes'            => __( 'Array of product attributes with name and options', 'mcp-ai-pro' ),
			'stock_status'          => __( 'Stock status: instock, outofstock, or onbackorder', 'mcp-ai-pro' ),
			'manage_stock'          => __( 'Enable stock management (boolean)', 'mcp-ai-pro' ),
			'stock_quantity'        => __( 'Stock quantity if manage_stock is true', 'mcp-ai-pro' ),
			'weight'                => __( 'Product weight for shipping', 'mcp-ai-pro' ),
			'dimensions'            => __( 'Product dimensions (length, width, height)', 'mcp-ai-pro' ),
			'virtual'               => __( 'Is virtual product (boolean)', 'mcp-ai-pro' ),
			'downloadable'          => __( 'Is downloadable product (boolean)', 'mcp-ai-pro' ),
		);
	}
}
