<?php
/**
 * E-commerce Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * E-commerce Toolkit Settings Page Class
 */
class WP_MCP_AI_Ecommerce_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'ecommerce';
		$this->toolkit_name     = __( 'E-commerce Toolkit', 'mcp-ai-pro' );
		$this->option_name      = 'wp_mcp_ai_ecommerce_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-ecommerce-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-cart';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'E-commerce Toolkit Overview', 'mcp-ai-pro' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Advanced WooCommerce integration toolkit providing 20 powerful tools for managing products, orders, inventory, and customers.', 'mcp-ai-pro' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'mcp-ai-pro' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Product Management: Create, update, import, and export products in bulk', 'mcp-ai-pro' ); ?></li>
				<li><?php esc_html_e( 'Order Processing: Process orders, generate invoices, and manage workflows', 'mcp-ai-pro' ); ?></li>
				<li><?php esc_html_e( 'Inventory Tracking: Monitor stock levels, forecast demand, and automate alerts', 'mcp-ai-pro' ); ?></li>
				<li><?php esc_html_e( 'Customer Management: Segment customers, analyze lifetime value, and export data', 'mcp-ai-pro' ); ?></li>
				<li><?php esc_html_e( 'Analytics & Reporting: Sales performance dashboards and order analytics', 'mcp-ai-pro' ); ?></li>
				<li><?php esc_html_e( 'Marketing: Abandoned cart recovery, discount campaigns, and upsell recommendations', 'mcp-ai-pro' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Requirements', 'mcp-ai-pro' ); ?></h3>
			<ul>
				<li><strong><?php esc_html_e( 'WooCommerce:', 'mcp-ai-pro' ); ?></strong> <?php echo class_exists( 'WooCommerce' ) ? '<span style="color: green;">✓ Active</span>' : '<span style="color: red;">✗ Not Installed</span>'; ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'E-commerce Toolkit Configuration', 'mcp-ai-pro' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Currency', 'mcp-ai-pro' ); ?></th>
					<td>
						<input type="text" name="default_currency" value="USD" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Default currency for pricing and reports', 'mcp-ai-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Low Stock Threshold', 'mcp-ai-pro' ); ?></th>
					<td>
						<input type="number" name="low_stock_threshold" value="5" min="0" class="small-text" />
						<p class="description"><?php esc_html_e( 'Trigger alerts when inventory falls below this level', 'mcp-ai-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Multi-Store Sync', 'mcp-ai-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_multistore" value="1" />
							<?php esc_html_e( 'Synchronize inventory across multiple stores (requires Remote Sites)', 'mcp-ai-pro' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'create_product_advanced'     => __( 'Create Product (Advanced)', 'mcp-ai-pro' ),
			'bulk_update_products'        => __( 'Bulk Update Products', 'mcp-ai-pro' ),
			'import_products_csv'         => __( 'Import Products from CSV', 'mcp-ai-pro' ),
			'export_products_report'      => __( 'Export Products Report', 'mcp-ai-pro' ),
			'sync_product_inventory'      => __( 'Sync Product Inventory', 'mcp-ai-pro' ),
			'process_order_workflow'      => __( 'Process Order Workflow', 'mcp-ai-pro' ),
			'bulk_order_status_update'    => __( 'Bulk Order Status Update', 'mcp-ai-pro' ),
			'refund_order_advanced'       => __( 'Refund Order (Advanced)', 'mcp-ai-pro' ),
			'generate_invoice_pdf'        => __( 'Generate Invoice PDF', 'mcp-ai-pro' ),
			'get_order_analytics'         => __( 'Get Order Analytics', 'mcp-ai-pro' ),
			'track_inventory_movement'    => __( 'Track Inventory Movement', 'mcp-ai-pro' ),
			'low_stock_alert_automation'  => __( 'Low Stock Alert Automation', 'mcp-ai-pro' ),
			'inventory_forecast'          => __( 'Inventory Forecast', 'mcp-ai-pro' ),
			'segment_customers'           => __( 'Segment Customers', 'mcp-ai-pro' ),
			'customer_lifetime_value'     => __( 'Customer Lifetime Value', 'mcp-ai-pro' ),
			'export_customer_data'        => __( 'Export Customer Data', 'mcp-ai-pro' ),
			'sales_performance_dashboard' => __( 'Sales Performance Dashboard', 'mcp-ai-pro' ),
			'abandoned_cart_recovery'     => __( 'Abandoned Cart Recovery', 'mcp-ai-pro' ),
			'create_discount_campaign'    => __( 'Create Discount Campaign', 'mcp-ai-pro' ),
			'upsell_recommendations'      => __( 'Upsell Recommendations', 'mcp-ai-pro' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_Ecommerce_Settings_Page();
}
