<?php
/**
 * Architectural Design Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * Architectural Design Toolkit Settings Page Class
 */
class WP_MCP_AI_Architectural_Design_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'architectural_design';
		$this->toolkit_name     = __( 'Architectural Design Toolkit', 'nvdigital-open-operator-system-oos' );
		$this->option_name      = 'wp_mcp_ai_architectural_design_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-architectural-design-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-admin-multisite';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'Architectural Design Toolkit Overview', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'AI-powered architectural design toolkit with 16 professional tools for floor plan generation, 3D modeling, blueprint creation, code compliance, sustainability analysis, and cost estimation.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'AI Floor Plan Generation: Create floor plans from natural language descriptions', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Space Optimization: AI-powered layout optimization for functionality and flow', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( '3D Visualization: Generate 3D models and photorealistic renderings', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Blueprint Automation: Create professional construction drawing sets', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Code Compliance: Automated building code and zoning validation', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Sustainability Analysis: LEED scoring and energy efficiency calculations', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Cost Estimation: AI-powered material takeoffs and cost projections', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Multi-format Export: PDF blueprints, DWG, IFC, and 3D model formats', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Tool Categories', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<div class="tool-categories">
				<div class="tool-category">
					<h4><?php esc_html_e( 'Floor Planning & Space Design (4 tools)', 'nvdigital-open-operator-system-oos' ); ?></h4>
					<p><?php esc_html_e( 'AI-powered floor plan generation, layout optimization, and sketch conversion', 'nvdigital-open-operator-system-oos' ); ?></p>
				</div>
				<div class="tool-category">
					<h4><?php esc_html_e( '3D Modeling & Visualization (3 tools)', 'nvdigital-open-operator-system-oos' ); ?></h4>
					<p><?php esc_html_e( '3D model generation, photorealistic rendering, and virtual tours', 'nvdigital-open-operator-system-oos' ); ?></p>
				</div>
				<div class="tool-category">
					<h4><?php esc_html_e( 'Documentation & Blueprints (3 tools)', 'nvdigital-open-operator-system-oos' ); ?></h4>
					<p><?php esc_html_e( 'Construction drawings, detail sheets, and multi-format export', 'nvdigital-open-operator-system-oos' ); ?></p>
				</div>
				<div class="tool-category">
					<h4><?php esc_html_e( 'Analysis & Compliance (3 tools)', 'nvdigital-open-operator-system-oos' ); ?></h4>
					<p><?php esc_html_e( 'Building code validation, structural analysis, and sustainability metrics', 'nvdigital-open-operator-system-oos' ); ?></p>
				</div>
				<div class="tool-category">
					<h4><?php esc_html_e( 'Estimation & Scheduling (3 tools)', 'nvdigital-open-operator-system-oos' ); ?></h4>
					<p><?php esc_html_e( 'Material scheduling, cost estimation, and project timelines', 'nvdigital-open-operator-system-oos' ); ?></p>
				</div>
			</div>

			<h3><?php esc_html_e( 'Use Cases', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><strong><?php esc_html_e( 'Architects:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Rapid concept generation and client presentations', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Designers:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Space planning and interior layouts', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Contractors:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Material takeoffs and cost estimation', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Developers:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Feasibility studies and code compliance', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><strong><?php esc_html_e( 'Students:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php esc_html_e( 'Learning tool and portfolio projects', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'Architectural Design Toolkit Configuration', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Unit System', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<select name="default_unit_system" class="regular-text">
							<option value="imperial"><?php esc_html_e( 'Imperial (feet, inches)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="metric"><?php esc_html_e( 'Metric (meters, centimeters)', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Default measurement system for floor plans and dimensions', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Building Code Standard', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<select name="building_code_standard" class="regular-text">
							<option value="ibc"><?php esc_html_e( 'International Building Code (IBC)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="irc"><?php esc_html_e( 'International Residential Code (IRC)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="local"><?php esc_html_e( 'Local/Custom', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Primary building code for compliance validation', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Export Format', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<select name="default_export_format" class="regular-text">
							<option value="pdf"><?php esc_html_e( 'PDF (Universal)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="dwg"><?php esc_html_e( 'DWG (AutoCAD)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="ifc"><?php esc_html_e( 'IFC (BIM Standard)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="svg"><?php esc_html_e( 'SVG (Vector)', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Default format for exporting architectural documents', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Rendering Quality', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<select name="rendering_quality" class="regular-text">
							<option value="draft"><?php esc_html_e( 'Draft (Fast)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="standard"><?php esc_html_e( 'Standard (Balanced)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="high"><?php esc_html_e( 'High (Photorealistic)', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Default quality for 3D renderings and visualizations', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable GPU Rendering', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_gpu_rendering" value="1" />
							<?php esc_html_e( 'Use GPU acceleration for faster rendering (requires remote sites)', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Sustainability Framework', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<select name="sustainability_framework" class="regular-text">
							<option value="leed"><?php esc_html_e( 'LEED (Leadership in Energy and Environmental Design)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="breeam"><?php esc_html_e( 'BREEAM (Building Research Establishment Environmental Assessment Method)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="energy_star"><?php esc_html_e( 'Energy Star', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="passive_house"><?php esc_html_e( 'Passive House', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Framework for sustainability analysis and scoring', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'generate_floor_plan'              => __( 'Generate Floor Plan', 'nvdigital-open-operator-system-oos' ),
			'optimize_space_layout'            => __( 'Optimize Space Layout', 'nvdigital-open-operator-system-oos' ),
			'create_floor_plan_variations'     => __( 'Create Floor Plan Variations', 'nvdigital-open-operator-system-oos' ),
			'convert_sketch_to_floor_plan'     => __( 'Convert Sketch to Floor Plan', 'nvdigital-open-operator-system-oos' ),
			'generate_3d_model'                => __( 'Generate 3D Model', 'nvdigital-open-operator-system-oos' ),
			'render_architectural_view'        => __( 'Render Architectural View', 'nvdigital-open-operator-system-oos' ),
			'create_walkthrough_animation'     => __( 'Create Walkthrough Animation', 'nvdigital-open-operator-system-oos' ),
			'generate_construction_drawings'   => __( 'Generate Construction Drawings', 'nvdigital-open-operator-system-oos' ),
			'generate_detail_drawings'         => __( 'Generate Detail Drawings', 'nvdigital-open-operator-system-oos' ),
			'export_architectural_documents'   => __( 'Export Architectural Documents', 'nvdigital-open-operator-system-oos' ),
			'check_building_code_compliance'   => __( 'Check Building Code Compliance', 'nvdigital-open-operator-system-oos' ),
			'analyze_structural_feasibility'   => __( 'Analyze Structural Feasibility', 'nvdigital-open-operator-system-oos' ),
			'calculate_sustainability_metrics' => __( 'Calculate Sustainability Metrics', 'nvdigital-open-operator-system-oos' ),
			'generate_material_schedule'       => __( 'Generate Material Schedule', 'nvdigital-open-operator-system-oos' ),
			'estimate_construction_cost'       => __( 'Estimate Construction Cost', 'nvdigital-open-operator-system-oos' ),
			'generate_construction_timeline'   => __( 'Generate Construction Timeline', 'nvdigital-open-operator-system-oos' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_Architectural_Design_Settings_Page();
}
