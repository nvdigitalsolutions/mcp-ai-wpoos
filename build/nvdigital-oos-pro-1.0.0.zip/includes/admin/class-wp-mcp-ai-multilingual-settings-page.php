<?php
/**
 * Multilingual Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * Multilingual Toolkit Settings Page Class
 */
class WP_MCP_AI_Multilingual_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'multilingual';
		$this->toolkit_name     = __( 'Multilingual Toolkit', 'nvdigital-open-operator-system-oos' );
		$this->option_name      = 'wp_mcp_ai_multilingual_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-multilingual-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-translation';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'Multilingual Toolkit Overview', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Comprehensive multilingual management toolkit with 10 tools for translation, localization, and global content management.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'AI Translation: Translate content using AI with context preservation', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Translation Memory: Build and leverage translation databases', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Glossary Management: Maintain terminology consistency across languages', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Bulk Operations: Translate multiple posts and detect languages automatically', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Quality Assurance: Validate translations and check localization', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'WPML Integration: Seamless integration with WPML plugin', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Supported Languages', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<p><?php esc_html_e( '100+ languages supported including:', 'nvdigital-open-operator-system-oos' ); ?></p>
			<ul>
				<li><?php esc_html_e( 'European: Spanish, French, German, Italian, Portuguese, Russian', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Asian: Chinese (Simplified & Traditional), Japanese, Korean, Hindi', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Middle Eastern: Arabic, Hebrew, Persian', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'Multilingual Toolkit Configuration', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Target Language', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<select name="default_target_language">
							<option value="es"><?php esc_html_e( 'Spanish', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="fr"><?php esc_html_e( 'French', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="de"><?php esc_html_e( 'German', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="zh"><?php esc_html_e( 'Chinese', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Default language for translations', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Translation Provider', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<select name="translation_provider">
							<option value="openai"><?php esc_html_e( 'OpenAI GPT-4', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="google"><?php esc_html_e( 'Google Translate', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="deepl"><?php esc_html_e( 'DeepL', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Translation Memory', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_translation_memory" value="1" checked />
							<?php esc_html_e( 'Store and reuse previous translations', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'translate_content_ai'       => __( 'Translate Content (AI)', 'nvdigital-open-operator-system-oos' ),
			'bulk_translate_posts'       => __( 'Bulk Translate Posts', 'nvdigital-open-operator-system-oos' ),
			'detect_content_language'    => __( 'Detect Content Language', 'nvdigital-open-operator-system-oos' ),
			'manage_translation_memory'  => __( 'Manage Translation Memory', 'nvdigital-open-operator-system-oos' ),
			'sync_language_versions'     => __( 'Sync Language Versions', 'nvdigital-open-operator-system-oos' ),
			'validate_translations'      => __( 'Validate Translations', 'nvdigital-open-operator-system-oos' ),
			'export_translation_package' => __( 'Export Translation Package', 'nvdigital-open-operator-system-oos' ),
			'glossary_management'        => __( 'Glossary Management', 'nvdigital-open-operator-system-oos' ),
			'wpml_integration'           => __( 'WPML Integration', 'nvdigital-open-operator-system-oos' ),
			'localization_checker'       => __( 'Localization Checker', 'nvdigital-open-operator-system-oos' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_Multilingual_Settings_Page();
}
