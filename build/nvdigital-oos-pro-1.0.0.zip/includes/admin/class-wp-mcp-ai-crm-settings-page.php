<?php
/**
 * CRM & Email Marketing Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * CRM & Email Marketing Toolkit Settings Page Class
 */
class WP_MCP_AI_CRM_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'crm';
		$this->toolkit_name     = __( 'CRM & Email Marketing Toolkit', 'nvdigital-open-operator-system-oos' );
		$this->option_name      = 'wp_mcp_ai_crm_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-crm-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = false;
		$this->icon             = 'dashicons-email';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'CRM & Email Marketing Toolkit Overview', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Comprehensive customer relationship management and email marketing toolkit powered by modern NPM packages. Includes contact management, email campaigns, lead tracking, and marketing automation.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Contact Management: Create, import, export, and manage CRM contacts with validation', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Email Campaigns: Create and send responsive email campaigns with MJML templates', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Lead Tracking: Score leads, track conversions, and manage sales pipeline', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Email Validation: RFC 5322 compliance, MX record checking, disposable email detection', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'CSV Import/Export: Bulk contact operations with auto-field mapping', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'SMTP Integration: Advanced email sending with nodemailer (OAuth2, attachments)', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Phone Validation: International phone number validation and formatting', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Calendar Integration: Generate .ics calendar files for campaign events', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'NPM Packages Integrated', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><strong>nodemailer</strong> (6M/week): Advanced SMTP email sending</li>
				<li><strong>validator</strong> (14M/week): Comprehensive input validation</li>
				<li><strong>csv-parse/stringify</strong> (8M/week): Contact import/export</li>
				<li><strong>email-validator</strong> (600K/week): Email validation</li>
				<li><strong>libphonenumber-js</strong> (4M/week): Phone validation</li>
				<li><strong>mailparser</strong> (1M/week): Email parsing</li>
				<li><strong>ical-generator</strong> (300K/week): Calendar generation</li>
			</ul>

			<h3><?php esc_html_e( 'Requirements', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><strong><?php esc_html_e( 'Node.js:', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php echo $this->check_nodejs_available() ? '<span style="color: green;">✓ Available</span>' : '<span style="color: orange;">⚠ Optional (PHP fallbacks available)</span>'; ?></li>
				<li><strong><?php esc_html_e( 'JetEngine (Optional):', 'nvdigital-open-operator-system-oos' ); ?></strong> <?php echo function_exists( 'jet_engine' ) ? '<span style="color: green;">✓ Active (CCT storage available)</span>' : '<span style="color: blue;">○ Not installed (CPT storage will be used)</span>'; ?></li>
			</ul>

			<h3><?php esc_html_e( 'Documentation', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<p><?php esc_html_e( 'For detailed integration guide, architecture patterns, and best practices, see:', 'nvdigital-open-operator-system-oos' ); ?></p>
			<ul>
				<li><code>addons/pro/CRM_EMAIL_MARKETING_GUIDE.md</code> - Comprehensive integration guide</li>
				<li><code>addons/pro/NPM_PACKAGE_OPPORTUNITIES.md</code> - Package documentation</li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'CRM & Email Marketing Configuration', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Lead Score', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<input type="number" name="default_lead_score" value="0" min="0" max="100" class="small-text" />
						<p class="description"><?php esc_html_e( 'Initial lead score for new contacts (0-100)', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Email Validation', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_email_validation" value="1" checked />
							<?php esc_html_e( 'Validate email addresses (RFC 5322, MX records)', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Phone Validation', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_phone_validation" value="1" checked />
							<?php esc_html_e( 'Validate phone numbers (international format)', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Block Disposable Emails', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="block_disposable_emails" value="1" />
							<?php esc_html_e( 'Block disposable/temporary email addresses', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'SMTP Configuration', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<p><?php esc_html_e( 'Configure SMTP settings for nodemailer integration:', 'nvdigital-open-operator-system-oos' ); ?></p>
						<input type="text" name="smtp_host" placeholder="smtp.example.com" class="regular-text" /><br />
						<input type="number" name="smtp_port" placeholder="587" class="small-text" min="1" max="65535" />
						<p class="description"><?php esc_html_e( 'SMTP host and port for email sending', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Storage Backend', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<?php
						$storage_type = class_exists( 'WP_MCP_AI_Toolkit_Data_Store_Factory' )
							? WP_MCP_AI_Toolkit_Data_Store_Factory::get_storage_type()
							: 'cpt';
						?>
						<p>
							<strong><?php echo 'cct' === $storage_type ? __( 'JetEngine CCT', 'nvdigital-open-operator-system-oos' ) : __( 'WordPress CPT', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<?php if ( 'cct' === $storage_type ) : ?>
								<br /><span style="color: green;">✓ Using JetEngine Custom Content Types for enhanced performance</span>
							<?php else : ?>
								<br /><span style="color: blue;">○ Using WordPress Custom Post Types (standard storage)</span>
							<?php endif; ?>
						</p>
						<p class="description"><?php esc_html_e( 'Storage backend is automatically selected based on JetEngine availability', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'manage_crm_contact'       => __( 'Manage CRM Contact', 'nvdigital-open-operator-system-oos' ),
			'import_contacts_csv'      => __( 'Import Contacts from CSV (Coming Soon)', 'nvdigital-open-operator-system-oos' ),
			'export_contacts_csv'      => __( 'Export Contacts to CSV (Coming Soon)', 'nvdigital-open-operator-system-oos' ),
			'validate_email'           => __( 'Validate Email Address (Service)', 'nvdigital-open-operator-system-oos' ),
			'validate_phone'           => __( 'Validate Phone Number (Service)', 'nvdigital-open-operator-system-oos' ),
			'send_email_nodemailer'    => __( 'Send Email via Nodemailer (Service)', 'nvdigital-open-operator-system-oos' ),
			'generate_email_template'  => __( 'Generate Email Template (MJML)', 'nvdigital-open-operator-system-oos' ),
			'create_email_campaign'    => __( 'Create Email Campaign (Coming Soon)', 'nvdigital-open-operator-system-oos' ),
			'segment_contacts'         => __( 'Segment Contacts (Coming Soon)', 'nvdigital-open-operator-system-oos' ),
			'calculate_lead_score'     => __( 'Calculate Lead Score (Coming Soon)', 'nvdigital-open-operator-system-oos' ),
			'track_email_engagement'   => __( 'Track Email Engagement (Coming Soon)', 'nvdigital-open-operator-system-oos' ),
			'generate_calendar_invite' => __( 'Generate Calendar Invite (Service)', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * Check if Node.js is available
	 *
	 * @return bool
	 */
	private function check_nodejs_available() {
		// Check if nodemailer package exists.
		$nodemailer = WP_MCP_AI_PRO_PATH . 'node_modules/nodemailer';
		return file_exists( $nodemailer );
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_CRM_Settings_Page();
}
