<?php
/**
 * DJ Management Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * DJ Management Toolkit Settings Page Class
 */
class WP_MCP_AI_DJ_Management_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'dj_management';
		$this->toolkit_name     = __( 'DJ Management Toolkit', 'nvdigital-open-operator-system-oos' );
		$this->option_name      = 'wp_mcp_ai_dj_management_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-dj-management-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-controls-play';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'DJ Management Toolkit Overview', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<div class="notice notice-info">
				<p><strong><?php esc_html_e( 'Coming Soon - Phase 2.7', 'nvdigital-open-operator-system-oos' ); ?></strong></p>
				<p><?php esc_html_e( 'This toolkit is planned for implementation in Phase 2.7. Tools and features are subject to change.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Professional DJ business management toolkit with 15-18 tools for equipment tracking, playlist management, event scheduling, and client management.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Equipment Inventory: Track gear, maintenance schedules, and replacement needs', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Playlist Builder: Create, organize, and share playlists with clients', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Event Calendar: Schedule gigs, block dates, and manage bookings', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Client Database: Store client preferences, song requests, and contact info', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Music Library: Organize tracks by genre, BPM, energy level, and era', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Contract Management: Generate contracts, track deposits, and manage payments', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'DJ Management Toolkit Configuration', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<div class="notice notice-warning">
				<p><?php esc_html_e( 'Configuration options will be available when this toolkit is implemented in Phase 2.7.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'DJ Business Name', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<input type="text" name="business_name" value="" class="regular-text" disabled />
						<p class="description"><?php esc_html_e( 'Your DJ business name for contracts and invoices', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Event Duration (Hours)', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<input type="number" name="default_event_duration" value="4" min="1" max="24" class="small-text" disabled />
						<p class="description"><?php esc_html_e( 'Default duration for new events', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Music Library Sync', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_music_sync" value="1" disabled />
							<?php esc_html_e( 'Sync with Spotify, Apple Music, or local music library', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'add_equipment'               => __( 'Add Equipment', 'nvdigital-open-operator-system-oos' ),
			'track_equipment_maintenance' => __( 'Track Equipment Maintenance', 'nvdigital-open-operator-system-oos' ),
			'equipment_inventory_report'  => __( 'Equipment Inventory Report', 'nvdigital-open-operator-system-oos' ),
			'create_playlist'             => __( 'Create Playlist', 'nvdigital-open-operator-system-oos' ),
			'update_playlist'             => __( 'Update Playlist', 'nvdigital-open-operator-system-oos' ),
			'share_playlist_with_client'  => __( 'Share Playlist with Client', 'nvdigital-open-operator-system-oos' ),
			'schedule_event'              => __( 'Schedule Event', 'nvdigital-open-operator-system-oos' ),
			'update_event_details'        => __( 'Update Event Details', 'nvdigital-open-operator-system-oos' ),
			'block_dates'                 => __( 'Block Dates', 'nvdigital-open-operator-system-oos' ),
			'add_client'                  => __( 'Add Client', 'nvdigital-open-operator-system-oos' ),
			'store_client_preferences'    => __( 'Store Client Preferences', 'nvdigital-open-operator-system-oos' ),
			'manage_song_requests'        => __( 'Manage Song Requests', 'nvdigital-open-operator-system-oos' ),
			'organize_music_library'      => __( 'Organize Music Library', 'nvdigital-open-operator-system-oos' ),
			'search_tracks_by_criteria'   => __( 'Search Tracks by Criteria', 'nvdigital-open-operator-system-oos' ),
			'generate_contract'           => __( 'Generate Contract', 'nvdigital-open-operator-system-oos' ),
			'track_payments'              => __( 'Track Payments', 'nvdigital-open-operator-system-oos' ),
			'generate_invoice'            => __( 'Generate Invoice', 'nvdigital-open-operator-system-oos' ),
			'event_performance_report'    => __( 'Event Performance Report', 'nvdigital-open-operator-system-oos' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_DJ_Management_Settings_Page();
}
