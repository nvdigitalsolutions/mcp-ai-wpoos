<?php
/**
 * Video Production Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * Video Production Toolkit Settings Page Class
 */
class WP_MCP_AI_Video_Production_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'video_production';
		$this->toolkit_name     = __( 'Video Production Toolkit', 'nvdigital-open-operator-system-oos' );
		$this->option_name      = 'wp_mcp_ai_video_production_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-video-production-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-video-alt3';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'Video Production Toolkit Overview', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Professional video production toolkit with 12 AI-powered tools for video editing, transcription, subtitles, and media optimization.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Video Editing: Trim, split, merge, and apply effects to videos', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Transcription: Generate automatic transcriptions and subtitles', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Voice-Over: Text-to-speech synthesis for narration', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Optimization: Compress videos, convert formats, and optimize for platforms', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'AI Enhancement: Auto-generate thumbnails, highlight reels, and scene detection', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Collaboration: Share preview links and distribute videos to platforms', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Supported Formats', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'MP4, MOV, AVI, WebM, MKV', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'H.264, H.265, VP9 codecs', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Up to 4K resolution', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'Video Production Toolkit Configuration', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Output Format', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<select name="default_output_format">
							<option value="mp4" selected><?php esc_html_e( 'MP4 (H.264)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="webm"><?php esc_html_e( 'WebM (VP9)', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="mov"><?php esc_html_e( 'MOV (ProRes)', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Default format for exported videos', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Transcription Language', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<select name="transcription_language">
							<option value="auto"><?php esc_html_e( 'Auto-detect', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="en"><?php esc_html_e( 'English', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="es"><?php esc_html_e( 'Spanish', 'nvdigital-open-operator-system-oos' ); ?></option>
							<option value="fr"><?php esc_html_e( 'French', 'nvdigital-open-operator-system-oos' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Distributed Rendering', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_distributed_rendering" value="1" />
							<?php esc_html_e( 'Use remote sites for faster video processing', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'edit_video'                   => __( 'Edit Video', 'nvdigital-open-operator-system-oos' ),
			'trim_video'                   => __( 'Trim Video', 'nvdigital-open-operator-system-oos' ),
			'merge_videos'                 => __( 'Merge Videos', 'nvdigital-open-operator-system-oos' ),
			'generate_video_transcription' => __( 'Generate Video Transcription', 'nvdigital-open-operator-system-oos' ),
			'add_subtitles_to_video'       => __( 'Add Subtitles to Video', 'nvdigital-open-operator-system-oos' ),
			'generate_voice_over'          => __( 'Generate Voice-Over', 'nvdigital-open-operator-system-oos' ),
			'compress_video'               => __( 'Compress Video', 'nvdigital-open-operator-system-oos' ),
			'convert_video_format'         => __( 'Convert Video Format', 'nvdigital-open-operator-system-oos' ),
			'generate_video_thumbnail'     => __( 'Generate Video Thumbnail', 'nvdigital-open-operator-system-oos' ),
			'create_highlight_reel'        => __( 'Create Highlight Reel', 'nvdigital-open-operator-system-oos' ),
			'share_video_preview'          => __( 'Share Video Preview', 'nvdigital-open-operator-system-oos' ),
			'distribute_video'             => __( 'Distribute Video', 'nvdigital-open-operator-system-oos' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_Video_Production_Settings_Page();
}
