<?php
/**
 * Financial Planner Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * Financial Planner Toolkit Settings Page Class
 */
class WP_MCP_AI_Financial_Planner_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'financial_planner';
		$this->toolkit_name     = __( 'Financial Planner Toolkit', 'nvdigital-open-operator-system-oos' );
		$this->option_name      = 'wp_mcp_ai_financial_planner_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-financial-planner-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-money-alt';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'Financial Planner Toolkit Overview', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Comprehensive financial planning toolkit with 24 powerful tools for retirement planning, budgeting, portfolio management, and financial analysis.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Retirement Planning: Calculate retirement needs, optimize social security, and plan withdrawals', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Budget Management: Track expenses, analyze cash flow, and plan savings goals', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Investment Analysis: Visualize portfolios, plan asset allocation, and track rebalancing', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Debt Management: Calculate payoff strategies, track mortgage amortization', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Tax Planning: Estimate taxes, track tax-loss harvesting opportunities', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Financial Health: Calculate net worth, analyze financial health score, plan insurance needs', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'Financial Planner Toolkit Configuration', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Currency', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<input type="text" name="default_currency" value="USD" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Default currency for financial calculations', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Interest Rate', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<input type="number" name="default_interest_rate" value="7" step="0.1" min="0" max="100" class="small-text" />
						<span>%</span>
						<p class="description"><?php esc_html_e( 'Default annual interest rate for investment calculations', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Inflation Rate', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<input type="number" name="default_inflation_rate" value="3" step="0.1" min="0" max="100" class="small-text" />
						<span>%</span>
						<p class="description"><?php esc_html_e( 'Default annual inflation rate for future value calculations', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Bank Account Sync', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_bank_sync" value="1" />
							<?php esc_html_e( 'Allow syncing with bank accounts via third-party services', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'retirement_calculator'        => __( 'Retirement Calculator', 'nvdigital-open-operator-system-oos' ),
			'ira_roth_comparison'          => __( 'IRA/Roth Comparison', 'nvdigital-open-operator-system-oos' ),
			'withdrawal_strategy_planner'  => __( 'Withdrawal Strategy Planner', 'nvdigital-open-operator-system-oos' ),
			'social_security_optimizer'    => __( 'Social Security Optimizer', 'nvdigital-open-operator-system-oos' ),
			'pension_analyzer'             => __( 'Pension Analyzer', 'nvdigital-open-operator-system-oos' ),
			'budget_planner'               => __( 'Budget Planner', 'nvdigital-open-operator-system-oos' ),
			'expense_tracker'              => __( 'Expense Tracker', 'nvdigital-open-operator-system-oos' ),
			'net_worth_calculator'         => __( 'Net Worth Calculator', 'nvdigital-open-operator-system-oos' ),
			'cash_flow_analyzer'           => __( 'Cash Flow Analyzer', 'nvdigital-open-operator-system-oos' ),
			'bank_account_sync'            => __( 'Bank Account Sync', 'nvdigital-open-operator-system-oos' ),
			'portfolio_visualizer'         => __( 'Portfolio Visualizer', 'nvdigital-open-operator-system-oos' ),
			'asset_allocation_planner'     => __( 'Asset Allocation Planner', 'nvdigital-open-operator-system-oos' ),
			'investment_return_calculator' => __( 'Investment Return Calculator', 'nvdigital-open-operator-system-oos' ),
			'rebalancing_analyzer'         => __( 'Rebalancing Analyzer', 'nvdigital-open-operator-system-oos' ),
			'tax_loss_harvesting_tracker'  => __( 'Tax Loss Harvesting Tracker', 'nvdigital-open-operator-system-oos' ),
			'debt_payoff_calculator'       => __( 'Debt Payoff Calculator', 'nvdigital-open-operator-system-oos' ),
			'mortgage_calculator'          => __( 'Mortgage Calculator', 'nvdigital-open-operator-system-oos' ),
			'credit_score_tracker'         => __( 'Credit Score Tracker', 'nvdigital-open-operator-system-oos' ),
			'savings_goal_planner'         => __( 'Savings Goal Planner', 'nvdigital-open-operator-system-oos' ),
			'emergency_fund_calculator'    => __( 'Emergency Fund Calculator', 'nvdigital-open-operator-system-oos' ),
			'financial_health_score'       => __( 'Financial Health Score', 'nvdigital-open-operator-system-oos' ),
			'tax_estimator'                => __( 'Tax Estimator', 'nvdigital-open-operator-system-oos' ),
			'college_savings_calculator'   => __( 'College Savings Calculator', 'nvdigital-open-operator-system-oos' ),
			'insurance_needs_analyzer'     => __( 'Insurance Needs Analyzer', 'nvdigital-open-operator-system-oos' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_Financial_Planner_Settings_Page();
}
