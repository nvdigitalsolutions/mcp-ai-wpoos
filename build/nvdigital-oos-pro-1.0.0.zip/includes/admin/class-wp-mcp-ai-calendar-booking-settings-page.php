<?php
/**
 * Calendar Booking Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * Calendar Booking Toolkit Settings Page Class
 */
class WP_MCP_AI_Calendar_Booking_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'calendar_booking';
		$this->toolkit_name     = __( 'Calendar Booking Toolkit', 'nvdigital-open-operator-system-oos' );
		$this->option_name      = 'wp_mcp_ai_calendar_booking_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-calendar-booking-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-calendar-alt';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'Calendar Booking Toolkit Overview', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<div class="notice notice-info">
				<p><strong><?php esc_html_e( 'Coming Soon - Phase 2.6', 'nvdigital-open-operator-system-oos' ); ?></strong></p>
				<p><?php esc_html_e( 'This toolkit is planned for implementation in Phase 2.6. Tools and features are subject to change.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'Comprehensive booking and scheduling system with 12-15 tools for appointment management, availability tracking, and calendar synchronization.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Online Booking: Accept appointments and reservations through WordPress', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Availability Management: Define schedules, block times, and manage resources', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Calendar Sync: Two-way sync with Google Calendar, Outlook, and iCal', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Automated Reminders: Send email and SMS reminders to reduce no-shows', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Resource Scheduling: Manage rooms, equipment, and staff availability', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Payment Integration: Collect deposits or full payment at booking', 'nvdigital-open-operator-system-oos' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'Calendar Booking Toolkit Configuration', 'nvdigital-open-operator-system-oos' ); ?></h2>
			
			<div class="notice notice-warning">
				<p><?php esc_html_e( 'Configuration options will be available when this toolkit is implemented in Phase 2.6.', 'nvdigital-open-operator-system-oos' ); ?></p>
			</div>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Timezone', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<input type="text" name="default_timezone" value="America/New_York" class="regular-text" disabled />
						<p class="description"><?php esc_html_e( 'Default timezone for appointments', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Booking Window (Days)', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<input type="number" name="booking_window" value="30" min="1" class="small-text" disabled />
						<p class="description"><?php esc_html_e( 'How far in advance customers can book', 'nvdigital-open-operator-system-oos' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Calendar Sync', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enable_calendar_sync" value="1" disabled />
							<?php esc_html_e( 'Sync appointments with external calendars', 'nvdigital-open-operator-system-oos' ); ?>
						</label>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'create_appointment'        => __( 'Create Appointment', 'nvdigital-open-operator-system-oos' ),
			'update_appointment'        => __( 'Update Appointment', 'nvdigital-open-operator-system-oos' ),
			'cancel_appointment'        => __( 'Cancel Appointment', 'nvdigital-open-operator-system-oos' ),
			'check_availability'        => __( 'Check Availability', 'nvdigital-open-operator-system-oos' ),
			'set_availability_schedule' => __( 'Set Availability Schedule', 'nvdigital-open-operator-system-oos' ),
			'block_time_slot'           => __( 'Block Time Slot', 'nvdigital-open-operator-system-oos' ),
			'sync_google_calendar'      => __( 'Sync Google Calendar', 'nvdigital-open-operator-system-oos' ),
			'sync_outlook_calendar'     => __( 'Sync Outlook Calendar', 'nvdigital-open-operator-system-oos' ),
			'send_booking_reminder'     => __( 'Send Booking Reminder', 'nvdigital-open-operator-system-oos' ),
			'manage_resources'          => __( 'Manage Resources', 'nvdigital-open-operator-system-oos' ),
			'generate_booking_report'   => __( 'Generate Booking Report', 'nvdigital-open-operator-system-oos' ),
			'export_calendar_ical'      => __( 'Export Calendar (iCal)', 'nvdigital-open-operator-system-oos' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_Calendar_Booking_Settings_Page();
}
