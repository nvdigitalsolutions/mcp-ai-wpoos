=== NV Digital Open Operator System (oOS) - Pro Add-on ===
Contributors: nvdigitalsolutions
Tags: ai, pro, woocommerce, social-media, automation
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: Proprietary
License URI: https://nvdigitalsolutions.com/wpoos-pro/license

Professional add-on for NV Digital Open Operator System. Adds 70+ advanced tools.

== Description ==

**REQUIRES BASE PLUGIN**

This is the Pro add-on for NV Digital Open Operator System (oOS). You must have the base plugin installed first.

Get the base plugin from:
- WordPress.org: https://wordpress.org/plugins/nvdigital-open-operator-system-oos/
- GitHub: https://github.com/nvdigitalsolutions/mcp-ai-wpoos

= Pro Features =

**70+ Additional Tools:**

* WooCommerce Integration (3 tools)
* Social Media Analytics (Facebook, LinkedIn, Twitter)
* GitHub Integration (repository management, code search)
* Google Services (Drive, Sheets, Calendar, Analytics)
* FFmpeg Video Processing
* Multi-Agent Orchestration
* Advanced Document Generation (PDF, Word, Excel)
* Email Marketing Integration
* CRM Integration
* And much more...

= Installation =

1. Install and activate the base plugin first
2. Upload this Pro add-on
3. Activate the Pro add-on
4. Pro tools will appear in your assistant tool list

= Support =

For support, please visit: https://nvdigitalsolutions.com/support

= License =

This is proprietary software. All rights reserved.
Patent Pending (Application #19/410,504).

