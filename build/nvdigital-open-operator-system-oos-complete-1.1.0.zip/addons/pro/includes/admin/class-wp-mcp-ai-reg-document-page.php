<?php
/**
 * Document Management Page for Regulatory Registration Toolkit.
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Document Management Page class.
 */
class WP_MCP_AI_Reg_Document_Page {
	/**
	 * Initialize the class.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu_page' ), 23 );
	}

	/**
	 * Add menu page.
	 */
	public static function add_menu_page() {
		add_submenu_page(
			'wp-mcp-ai',
			__( 'Document Management', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Documents', 'nvdigital-open-operator-system-oos-pro' ),
			'edit_posts',
			'wp-mcp-ai-reg-documents',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Render the document page.
	 */
	public static function render_page() {
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Document Management', 'nvdigital-open-operator-system-oos-pro' ); ?></h1>
			<p><?php echo esc_html__( 'Manage documents, track expiry dates, and monitor compliance.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
		</div>
		<?php
	}
}

WP_MCP_AI_Reg_Document_Page::init();
