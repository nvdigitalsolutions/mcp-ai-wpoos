=== NV oOS Docs Hub ===
Contributors: vsamtani
Tags: documentation, markdown, github
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.5.3
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Self-contained docs browser for WordPress. Publish Markdown you upload, or optionally import from public GitHub repos.

== Description ==

NV oOS Docs Hub discovers, indexes, and renders Markdown documentation in a
GitBook-style single-page app: sidebar navigation, content area, and a
per-page table of contents. Embed it anywhere on your WordPress site via a
shortcode or Gutenberg block.

Out of the box it publishes documentation you upload yourself: drop
Markdown (`.md`) or text (`.txt`) files into
`wp-content/uploads/nvoos-docs-hub/content/` (subfolders become sections),
rebuild the index, and they appear in the browser. No remote services are
involved.

**Optional GitHub import (opt-in, off by default).** Enable *Remote
Repositories* in the settings to import Markdown from **any public GitHub
repository** — no GitHub account required. This is a documentation-import
service: the plugin fetches files server-side, over HTTPS, and only from
`api.github.com` and `raw.githubusercontent.com`, then stores them in a
local cache on your server. No requests are made unless you enable the
setting, configure a repository, and trigger a rebuild. All scripts,
styles, fonts, and images are bundled locally — nothing is loaded from a
remote server. See **External Services** below for the full disclosure.

**Key features:**

* Publish Markdown uploaded to `wp-content/uploads/nvoos-docs-hub/content/` — zero configuration, zero remote calls
* Optional import from public GitHub repositories with per-repo file/folder selection
* Full-text search via the REST API with FlexSearch client-side fallback
* GitHub Flavored Markdown: tables, task lists, fenced code blocks
* Custom `:::note`, `:::tip`, `:::warning`, `:::danger` callout blocks
* Syntax-highlighted code blocks, last-modified dates, and "Edit on GitHub" links
* Broken-link detection with one-click fix suggestions (local sources)
* Light and dark themes with CSS custom properties
* Two-layer cache (filesystem + WordPress transients)
* Async chunked rebuilds with a live progress panel — no more long single-request builds
* WP-CLI support: `wp nvoos-docs rebuild / clear / status`
* Nightly cron rebuild; also triggered on plugin activate/deactivate
* Indexed pages included in the WordPress sitemap
* `[nvoos_docs]` shortcode and `nvoos/docs-hub` Gutenberg block

**Optional NV oOS integration.** If the NV oOS base plugin
(https://github.com/nvdigitalsolutions/mcp-ai-wpoos) is active, the addon
additionally auto-discovers the `docs/` folders of the base plugin and every
installed addon, and surfaces rebuild progress in the base plugin's cron-status
drawer.

== Installation ==

1. Upload the `nvoos-docs-hub` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** admin screen.
3. Add your Markdown files to `wp-content/uploads/nvoos-docs-hub/content/` (created automatically), go to **Settings → NV oOS Docs Hub**, and click **Rebuild Index**.
4. Add `[nvoos_docs]` to any page to display the documentation browser.

To import documentation from a public GitHub repository instead, go to
**Settings → NV oOS Docs Hub → Remote Repositories**, enable the setting,
and add your repositories.

To also index local NV oOS documentation, activate the NV oOS base plugin and
enable the `base`, `addons`, or `root` sources under **Settings → NV oOS Docs
Hub → Advanced — local filesystem (legacy)**.

== Shortcode ==

    [nvoos_docs section="base" theme="light" search="1" sidebar="1"]

Attributes:

* `section` – Filter to one source: `base`, `addons`, or an addon slug.
* `theme` – `light`, `dark`, or `auto` (follows OS preference).
* `search` – Set to `0` to disable the search box.
* `sidebar` – Set to `0` to hide the left sidebar.
* `home` – Slug of the default landing page.

== WP-CLI ==

    wp nvoos-docs rebuild            # Chunked rebuild (default, runs across WP-Cron ticks)
    wp nvoos-docs rebuild --sync     # Inline rebuild in a single request (legacy)
    wp nvoos-docs sync               # Back-compat alias for --sync
    wp nvoos-docs rebuild --resume   # Resume a stalled or failed rebuild
    wp nvoos-docs rebuild --cancel   # Cancel an in-flight rebuild
    wp nvoos-docs clear              # Clear all cached data
    wp nvoos-docs status             # Show index statistics and rebuild phase

== Frequently Asked Questions ==

= Does this plugin require the NV oOS base plugin? =

No. Out of the box it publishes Markdown files from
`wp-content/uploads/nvoos-docs-hub/content/`. If the NV oOS base plugin is
active, additional local sources (the base plugin's `docs/` folder and
installed addons) are discovered automatically.

= Can I index docs from a GitHub repository? =

Yes. First enable **Remote Repositories** under **Settings → NV oOS Docs
Hub**, then add a repository and either index the whole repository,
restrict it to a folder prefix, or use the "Browse files in repo…" picker
to select individual files and folders.

= Which file types are indexed? =

Only `.md` and `.txt` files up to 2 MB in size (local sources) or 4 MB (remote
sources).

= How do I exclude specific files? =

Use the `nvoos_docs_hub_excluded_globs` filter to return an array of glob
patterns (relative to each source root) that should be excluded.

= Can I restrict public access to the docs? =

Yes. Use the `nvoos_docs_hub_can_read_section` filter. Return a `WP_Error` or
`false` to block unauthenticated REST access. You can also restrict at the
shortcode level with the `nvoos_docs_hub_can_render` filter. Alternatively,
turn off **Allow Public (Guest) Access** in the settings to require a
WordPress login for all docs.

= How is the cache invalidated? =

Automatically when any plugin is activated or deactivated, after NV oOS plugin
updates, on a nightly scheduled cron job, and via a version-mismatch guard that
rebuilds when the installed plugin versions no longer match the cached index.
You can also rebuild manually from the settings page, via WP-CLI, or via the
REST API (requires `manage_options`).

== Source Code ==

The complete, human-readable source code for this plugin — including the
TypeScript/React source for the bundled `assets/dist/docs-hub.js` bundle — is
publicly available in the plugin's GitHub repository:

https://github.com/nvdigitalsolutions/nvoos-docs-hub

The frontend bundle is generated from the `src/` directory with esbuild:

1. `npm install` — installs the frontend dependencies (React, esbuild, etc.).
2. `npm run build` — runs `node esbuild.config.js --prod` and writes the
   minified `assets/dist/docs-hub.js` and `assets/dist/docs-hub.css`.

The repository also contains the WordPress.org packaging and CI pipeline
(`.github/workflows/`, `bin/`), the PHPUnit test suite (`tests/`), and the
`.wordpress-org/` listing assets.

== Third-Party Libraries ==

The bundled `assets/dist/docs-hub.js` frontend is built from TypeScript/React
sources in the public repository and includes the following open-source
libraries (all GPL-compatible licenses; MIT unless noted):

* React and React DOM (MIT) — https://react.dev
* React Markdown (MIT) — https://github.com/remarkjs/react-markdown
* React Router (MIT) — https://reactrouter.com
* FlexSearch (Apache-2.0) — https://github.com/nextapps-de/flexsearch
* Lowlight and highlight.js language grammars (MIT / BSD-3-Clause)
* The unified/remark/rehype ecosystem: remark-gfm, remark-directive,
  remark-frontmatter, rehype-slug, rehype-autolink-headings,
  rehype-highlight, unist-util-visit (MIT) and github-slugger (ISC)

Build and test tooling (esbuild, ESLint, TypeScript, Vitest) is not shipped
in the distribution ZIP. The complete dependency graph and its licenses are
listed in `package.json` and `package-lock.json` in the public repository.

== Screenshots ==

1. Settings — documentation index status and rebuild panel.
2. Settings — remote repositories with the GitHub file/folder tree picker.
3. Frontend `[nvoos_docs]` embed — sidebar, content, and table of contents.
4. Frontend `[nvoos_docs]` embed — full-text search.
5. Settings — Save button and the "Get NV oOS Complete" upsell card.

== External Services ==

This plugin provides an optional **documentation-import service**, disabled
by default: remote requests happen only after an administrator enables
*Remote Repositories* in the settings, configures at least one repository,
and triggers a rebuild. When enabled, the plugin fetches Markdown files
from public GitHub repositories, stores them locally in the uploads cache,
and renders them in the documentation browser. Fetched content is cached
on your server, so visitors are served from the local cache, not from
GitHub.

All requests are made **server-side only, over HTTPS**, and only to the two
hosts listed below. Every request is restricted to these hosts (all other
hosts are rejected, including private and reserved IP addresses), carries a
bounded timeout and a 4 MB response-size cap, and only happens after an
administrator has enabled the Remote Repositories setting, configured a
repository, and a rebuild is triggered — manually, via WP-CLI, by the
nightly cron, or automatically when the cache is invalidated (a related
plugin is activated, deactivated, or updated).
No requests are made unless the Remote Repositories setting is enabled and
a repository is configured.

**No account is required** for public repositories. An optional GitHub
personal access token can be saved in the settings to raise GitHub's API
rate limits; it is stored server-side and sent only to the two hosts below.

* `api.github.com` — repository and tree metadata used by the file/folder
  picker and the indexer.
* `raw.githubusercontent.com` — raw Markdown file content fetched during
  index rebuilds.

The plugin does not send any personal data to these services — it only
fetches the public repository content exactly as GitHub serves it. Rendered
documentation pages display the repository content as authored, which may
include links and images pointing at `github.com`,
`raw.githubusercontent.com`, or `user-images.githubusercontent.com`; those
are loaded by the visitor's browser directly from the source repository,
not through the plugin or your server.

GitHub Terms of Service:
https://docs.github.com/en/site-policy/github-terms/github-terms-of-service
GitHub Privacy Statement:
https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement

This plugin also offers an **optional, opt-in checkout for the NV oOS
Complete bundle** — the full NV oOS plugin (base + Pro), which is a
separate plugin sold off-directory by NV Digital Unlocked LLC (the seller
of record, under license from NV Digital Solutions). The checkout opens
**only when an administrator clicks "Get NV oOS Complete"** on this
plugin's own settings page; nothing runs in the background and the free
plugin is complete without it. No Stripe keys ship in this plugin — the
vendor's own checkout server creates and verifies payments, and Stripe.js
is loaded from `js.stripe.com` only when the purchase modal opens.

All checkout requests are **user-initiated, server-side only, over
HTTPS**, and only to:

* `nvdigitalsolutions.com` — the vendor checkout API
  (`/wp-json/nvoos-checkout/v1/`): creates the Stripe payment session and
  verifies the completed payment, issuing the license key and a signed,
  expiring download URL. Sent: product name, site URL, Stripe payment
  intent ID, buyer email, buyer country, Terms-consent timestamp.
* `js.stripe.com` — Stripe's payment form (loaded by the browser when the
  modal opens). Card details are entered in Stripe's own iframe; this
  plugin never sees them.
* `github.com` — only an HTTPS download of the purchased ZIP (a signed
  vendor URL, or the public release asset fallback); no data sent.

Purchases require explicit agreement to the Terms of Service and Refund
Policy (consent timestamp recorded with the purchase) and a buyer email
address for the receipt. The Terms of Service and Refund Policy for the
vendor service are published at https://nvdigitalsolutions.com/terms-of-service
and https://nvdigitalsolutions.com/refund-policy.

== Changelog ==

= 0.5.3 =
* Changed: settings saves and plugin updates no longer wipe the documentation index while the rebuild runs — the previous index keeps serving until the new build is promoted atomically, so a stalled background rebuild can never leave the docs empty.
* Fixed: standalone installs (base plugin not active) with WP-Cron disabled could stall the background rebuild — each settings save or admin visit now advances it.

= 0.5.2 =
* Added: optional "Get NV oOS Complete" upsell on the settings page (shown only while the Complete bundle is not active) with an in-dashboard Stripe checkout — payment sessions are created and verified by the vendor checkout service at `nvdigitalsolutions.com`; no Stripe keys ship in the plugin, and the purchase modal opens only on click.
* Added: after a purchase, the license key is stored locally and the bundle is offered for automatic install (manual ZIP download is always available); the installer refuses when another copy of NV oOS already exists.
* Added: admin-only `payments/session`, `payments/verify`, and `payments/health` REST routes under `/wp-json/nvoos-docs/v1/`, with per-user rate limiting.
* Added: new filters — `nvoos_docs_hub_checkout_*` (vendor URL, price, versions, legal URLs, EU country list).

= 0.5.1 =
* Changed: the uploads content folder moved from `wp-content/uploads/docs/` to `wp-content/uploads/nvoos-docs-hub/content/` — nested inside the plugin's slug-named uploads directory, per the WordPress.org plugin guidelines. Existing content is migrated automatically on activation or first admin visit.
* Added: automatic one-time migration of the pre-0.5.1 `wp-content/uploads/docs/` folder (best-effort, never overwrites existing files, symlinks are never followed).

= 0.5.0 =
* Added: local-first default — the plugin now publishes Markdown files dropped into `wp-content/uploads/docs/` out of the box, with zero remote calls.
* Added: "Enable Remote Repositories" opt-in setting (off by default). Remote GitHub import now requires enabling the setting, configuring a repository, and triggering a rebuild. Existing installs that already use remote repositories keep them enabled automatically.
* Security: the local-source scanner now resolves symlinks before its containment check, so a symlinked subfolder cannot leak files from outside the docs folder.
* Changed: remote import is gated server-side (scanner and file-picker endpoint) whenever the setting is off.

= 0.4.8 =
* Changed: the readme Description now explains the documentation-import service up front — the servers contacted (`api.github.com`, `raw.githubusercontent.com`), that no account is required, that requests happen only on administrator-configured rebuilds, and that no plugin assets are loaded remotely.
* Changed: the remote-repository fetcher's host allowlist and fetch code now reference the readme's External Services disclosure.

= 0.4.7 =
* Fixed: removed the "Tested up to" line from the plugin headers — it is declared only in the readme.
* Fixed: the daily rebuild cron is now scheduled on `init` instead of `plugins_loaded`, which prevented "translation loading triggered too early" notices on WordPress 6.7+ when other plugins register translated cron schedules.
* Changed: rebuild cron events are cleared when the plugin is deactivated, and deactivating the plugin no longer enqueues a rebuild that could never run.
* Changed: the readme now discloses the bundled third-party libraries and their licenses and lists every automatic rebuild trigger in the External Services section.

= 0.4.6 =
* Added: bundled GPLv3 license file (LICENSE) at the plugin root.

= 0.4.5 =
* Security: a symlinked cache directory can no longer redirect deletion — the uninstall routine removes only the link and leaves the external target untouched, and the cache class replaces a symlinked cache directory with a real one before writing.
* Changed: the External Services section now explains the documentation-import service, the servers it contacts, and that no account is required for public repositories.

= 0.4.4 =
* Security: search results and the WordPress sitemap no longer expose context-source (`.context/`) content to non-admin users.
* Security: GitHub personal access tokens are no longer localized into the settings-page scripts (they were stripped only on export before).
* Security: staged rebuilds no longer read or write live page transients, page transients are invalidated when the cache is promoted or cleared, and recursive cache deletion is hardened against symlink traversal.
* Changed: the base-plugin notice is scoped to the Docs Hub settings page, and the redundant `load_plugin_textdomain()` call was removed.
* Changed: readme now documents the public source repository and the frontend build steps; the bundled `docs-hub.js` and `docs-hub.css` carry source banners.

= 0.4.3 =
* Added: WordPress.org listing screenshots and a Playwright capture script (`bin/capture-nvoos-docs-hub-screenshots.js`).
* Added: WordPress.org submission preparation — External Services section in the readme, a translation template (languages/nvoos-docs-hub.pot), and a WordPress.org Plugin Check gate in CI.
* Changed: settings-page scripts moved to a static asset (no inline <script> blocks), text-domain consistency fix, dev files excluded from distribution ZIPs.
* Changed: readme tags trimmed to directory-standard tags.

= 0.4.2 =
* Fixed: clicking internal links on local pages left the SPA — links now resolve to `#/slug` hash routes with heading anchors preserved.
* Fixed: "On this page" TOC anchors now match rendered headings exactly (github-slugger parity verified across ~63,000 headings).
* Fixed: "Accept fix" suggestions now resolve targets relative to the source page and validate the resolved destination against plugin/content roots.
* Fixed: sync rebuilds (`wp nvoos-docs sync`, `POST /rebuild?sync=1`) now report an error when the atomic staging-cache swap fails.
* Fixed: skipped broken-link rows in the settings table now show the server-provided reason; remote-sourced rows explain they must be fixed upstream.

= 0.4.1 =
* Fixed: index went stale after in-place NV oOS plugin updates — cache now invalidates on the new `wp_mcp_ai_plugin_updated` action plus an `admin_init` version-mismatch guard.
* Fixed: broken-link detection on remote-only indexes no longer flags repo-relative links; fix suggestions are case-insensitive with clamped confidence.

= 0.4.0 =
* Fixed: "Unexpected token '<'" errors when page-caching plugins serve HTML for REST requests — clients now send `Accept: application/json` and validate the response content type.
* Fixed: non-404 page-load failures no longer masquerade as "404 Page Not Found"; they show a diagnostic error block.

= 0.3.9 =
* Fixed: fatal error during WordPress sitemap provider registration (now hooked into `wp_sitemaps_init`).
* Added: `fnmatch()` polyfill for Windows PHP environments.

= 0.3.8 =
* Added: syntax highlighting via `rehype-highlight` with a scoped light/dark theme.
* Added: last-modified footer date and "Edit on GitHub" links.
* Added: indexed docs pages included in the WordPress sitemap.
* Added: admin repo-picker script extracted to a static, CSP-friendly asset.

= 0.3.7 =
* Added: accessibility improvements — ARIA region for the SPA, skip-link to main content, `prefers-reduced-motion` support, RTL layout mirroring.

= 0.3.6 =
* Fixed: fatal error on the settings page with malformed `remote_repos` rows.
* Added: hardened SSRF protection for remote GitHub fetches (IPv6-aware resolution, per-record validation).
* Added: force-refresh clears the per-file remote content cache.

= 0.3.2 =
* Fixed: PHPCS compliance pass (96 errors / 38 warnings resolved).

= 0.3.1 =
* Fixed: admin rebuild panel 404 (wrong REST namespace).
* Changed: remote-repositories settings section now explains the tree-picker workflow.

= 0.3.0 =
* Changed: fresh installs default to remote-first sources (`remote` only); local filesystem sources moved under "Advanced — local filesystem (legacy)".
* Added: lookup-and-select tree picker for remote repositories with per-repo selection modes (`all`, `prefix`, `selected`).
* Added: admin REST endpoint `GET /remote/tree`.

= 0.2.0 =
* Chunked, async-by-default rebuild pipeline (`scan` → `pages` → `links` → `search` → `finalize`) driven by self-rescheduling WP-Cron ticks. Per-tick wall-clock + memory budgets prevent the historical "single 60 s+ PHP request crashes on a large repo" failure mode.
* Atomic staging-cache swap. A failed rebuild leaves the previous index intact instead of wiping the docs and leaving the SPA blank.
* Built-in vendor / dependency exclusion (`vendor/`, `node_modules/`, `bower_components/`, `.git/`, `.github/`, `dist/`, `build/`, `coverage/`, `tests/fixtures/`) applied during recursive scan to prune subdirectories before recursion. New `nvoos_docs_hub_force_include_globs` filter allow-lists specific vendored docs.
* Plugin-root `README.md` / `CHANGELOG.md` / `CONTRIBUTING.md` / `SECURITY.md` are now indexed unconditionally when the `root` source is enabled (no longer gated behind `WP_DEBUG`). `.context/*.md` remains gated behind `context_enabled` + `manage_options`.
* New source-priority (`root` > `base` > `addons` > `context` > `remote`) ensures the plugin-root README wins the canonical `readme` slug; addon READMEs receive suffixed slugs.
* New REST endpoints: `GET /rebuild/status`, `POST /rebuild/cancel`, `POST /rebuild/resume`. `POST /rebuild` returns HTTP 202 by default; pass `?sync=1` for the legacy inline behaviour.
* New WP-CLI command: `wp nvoos-docs rebuild [--async|--sync|--resume|--cancel]`.
* Admin UI: live progress panel polls `/rebuild/status` with start / resume / cancel buttons.
* New filters: `nvoos_docs_hub_force_include_globs`, `nvoos_docs_hub_pruned_dir_names`, `nvoos_docs_hub_source_priority`, `nvoos_docs_hub_rebuild_chunk_size`, `nvoos_docs_hub_rebuild_tick_budget`, `nvoos_docs_hub_max_files_total`. New action: `nvoos_docs_hub_rebuild_phase`.
* New setting: "Include per-addon README/CHANGELOG" (default on).
* Performance: `build_search_index()` now reuses cached page payloads instead of re-reading every file.

= 0.1.0 =
* Initial release.

== Upgrade Notice ==

= 0.5.3 =
Reliability release — the docs index no longer goes blank while a rebuild runs after a settings save or plugin update. Recommended for all users.

= 0.5.2 =
Adds an optional "Get NV oOS Complete" upsell on the settings page. The plugin remains fully functional without a purchase — nothing is locked behind it.

= 0.5.1 =
The uploads content folder moved from `wp-content/uploads/docs/` to `wp-content/uploads/nvoos-docs-hub/content/`. Existing content is migrated automatically — no action needed.

= 0.5.0 =
New local-first default: Markdown dropped into `wp-content/uploads/docs/` is published with zero remote calls, and GitHub import is now opt-in. Existing installs using remote repositories keep them enabled automatically. Recommended for all users.

= 0.4.7 =
Compatibility release — fixes activation-time notices on WordPress 6.7+ and cleans up cron events on deactivation. Recommended for all users.

= 0.4.6 =
Packaging-only release — bundles the GPLv3 license file. No functional changes.

= 0.4.5 =
Security hardening release — uninstall and cache cleanup are symlink-safe. Recommended for all users.

= 0.4.4 =
Security hardening release — context-source content can no longer leak through search or the sitemap. Recommended for all users.

= 0.4.3 =
WordPress.org submission hardening — no functional changes for existing sites. Recommended for all users.

= 0.4.2 =
Local-page links and TOC anchors now navigate inside the SPA, and broken-link fix suggestions resolve relative to the source page. Recommended for all users.

= 0.4.1 =
Cache invalidation after plugin updates is fixed; the index no longer goes stale. Recommended for all users.

= 0.2.0 =
Asynchronous chunked rebuilds + vendor exclusion. The "Rebuild Documentation Index" button is now non-blocking; long rebuilds run across WP-Cron ticks. Default exclusions for `vendor/` and `node_modules/` mean third-party READMEs no longer pollute your docs.
