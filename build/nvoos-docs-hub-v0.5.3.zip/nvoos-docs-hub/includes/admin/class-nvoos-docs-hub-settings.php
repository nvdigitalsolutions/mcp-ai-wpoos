<?php
/**
 * NV oOS Docs Hub — Admin Settings Page
 *
 * Provides the WordPress admin settings page for the Docs Hub addon,
 * including a "Rebuild Documentation Index" action button.
 *
 * @package NV_oOS_Docs_Hub
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin settings page handler for the Docs Hub addon.
 *
 * @since 1.0.0
 */
class NV_oOS_Docs_Hub_Settings {

	/**
	 * Register hooks.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_rebuild_action' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'wp_ajax_nvoos_docs_hub_import_settings', array( __CLASS__, 'ajax_import_settings' ) );
	}

	/**
	 * Enqueue admin-page-specific scripts and localize the repo-picker config.
	 *
	 * @since 0.3.8
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public static function enqueue_admin_assets( $hook_suffix ) {
		// Only load on our own settings page.
		if ( false === strpos( $hook_suffix, 'nvoos-docs-hub' ) ) {
			return;
		}

		wp_enqueue_script(
			'nvoos-dh-repo-picker',
			NVOOS_DOCS_HUB_URL . 'assets/admin/repo-picker.js',
			array(),
			NVOOS_DOCS_HUB_VERSION,
			true
		);

		wp_localize_script(
			'nvoos-dh-repo-picker',
			'NVOOS_DH_REPO_PICKER',
			array(
				'restBase'  => esc_url_raw( rest_url( NV_oOS_Docs_Hub_REST::NAMESPACE . '/remote/tree' ) ),
				'restNonce' => wp_create_nonce( 'wp_rest' ),
				'i18n'      => array(
					'enterOwnerRepo' => __( 'Enter owner and repo first.', 'nvoos-docs-hub' ),
					/* translators: Loading indicator text. */
					'loading'        => __( 'Loading…', 'nvoos-docs-hub' ),
					'filesFound'     => __( 'files found.', 'nvoos-docs-hub' ),
					'noFilesFound'   => __( 'No Markdown files found in this ref / path.', 'nvoos-docs-hub' ),
				),
			)
		);

		// Static script for the rebuild panel, dirty-state tracking, broken-link
		// fixes, and JSON export/import. Kept out of the page markup so the
		// settings page ships no inline <script> blocks (wp.org review feedback).
		wp_enqueue_script(
			'nvoos-dh-settings-page',
			NVOOS_DOCS_HUB_URL . 'assets/admin/settings-page.js',
			array(),
			NVOOS_DOCS_HUB_VERSION,
			true
		);

		wp_localize_script(
			'nvoos-dh-settings-page',
			'NVOOS_DH_SETTINGS_PAGE',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'importNonce' => wp_create_nonce( 'nvoos_docs_hub_import_settings' ),
				// Tokens are stripped server-side: GitHub personal access
				// tokens must never be localized into the page DOM. The
				// settings-page script only needs token-free settings for the
				// JSON export flow.
				'settings'    => self::settings_without_tokens(),
				'i18n'        => array(
					/* translators: Loading indicator text. */
					'importing'           => __( 'Importing…', 'nvoos-docs-hub' ),
					'imported'            => __( 'Imported. A rebuild will run automatically.', 'nvoos-docs-hub' ),
					'importFailed'        => __( 'Import failed.', 'nvoos-docs-hub' ),
					'importRequestFailed' => __( 'Import request failed.', 'nvoos-docs-hub' ),
					'invalidJson'         => __( 'Invalid JSON file.', 'nvoos-docs-hub' ),
				),
			)
		);

		// NV oOS Complete purchase modal. Stripe.js itself is NOT enqueued
		// here — docs-hub-checkout.js injects https://js.stripe.com/v3/ on
		// demand when the user opens the purchase modal, so Stripe is never
		// contacted by merely visiting this settings page.
		wp_enqueue_script(
			'nvoos-dh-checkout',
			NVOOS_DOCS_HUB_URL . 'assets/admin/docs-hub-checkout.js',
			array(),
			NVOOS_DOCS_HUB_VERSION,
			true
		);

		wp_enqueue_style(
			'nvoos-dh-checkout',
			NVOOS_DOCS_HUB_URL . 'assets/admin/docs-hub-checkout.css',
			array(),
			NVOOS_DOCS_HUB_VERSION
		);

		// Checkout config. No Stripe keys live in this plugin — the
		// publishable key is returned per-session by the vendor checkout
		// API. The vendor's session response may also override the
		// legal-document URLs; these are the client-side defaults that keep
		// the consent links present.
		wp_localize_script(
			'nvoos-dh-checkout',
			'NVOOS_DH_CHECKOUT',
			self::checkout_script_config()
		);
	}

	/**
	 * Build the checkout script configuration (localize payload).
	 *
	 * @since 0.5.2
	 *
	 * @return array<string,mixed>
	 */
	private static function checkout_script_config() {
		return array(
			'rest_url'          => esc_url_raw( rest_url( NV_oOS_Docs_Hub_REST::NAMESPACE ) ),
			'nonce'             => wp_create_nonce( 'wp_rest' ),
			'price_label'       => NV_oOS_Docs_Hub_Checkout::price_label(),
			'fallback_url'      => esc_url_raw( NV_oOS_Docs_Hub_Checkout::fallback_product_url() ),
			'terms_url'         => esc_url_raw( NV_oOS_Docs_Hub_Checkout::terms_url() ),
			'refund_policy_url' => esc_url_raw( NV_oOS_Docs_Hub_Checkout::refund_policy_url() ),
			'roadmap_url'       => esc_url_raw( NV_oOS_Docs_Hub_Checkout::roadmap_url() ),
			'changelog_url'     => esc_url_raw( NV_oOS_Docs_Hub_Checkout::changelog_url() ),
			'base_version_url'  => esc_url_raw( NV_oOS_Docs_Hub_Checkout::base_version_url() ),
			'buyer_email'       => sanitize_email( (string) wp_get_current_user()->user_email ),
			'eu_countries'      => NV_oOS_Docs_Hub_Checkout::eu_country_codes(),
			'i18n'              => array(
				'title'                        => __( 'Get NV oOS Complete', 'nvoos-docs-hub' ),
				'pay'                          => __( 'Pay', 'nvoos-docs-hub' ),
				'cancel'                       => __( 'Cancel', 'nvoos-docs-hub' ),
				'close'                        => __( 'Close', 'nvoos-docs-hub' ),
				'secure_note'                  => __( 'Payments are processed securely by Stripe. Your card never touches this server.', 'nvoos-docs-hub' ),
				'stripe_setup_error'           => __( 'The payment form could not be started. Please reload the page and try again.', 'nvoos-docs-hub' ),
				'payment_loading'              => __( 'Loading secure payment form…', 'nvoos-docs-hub' ),
				'free_option'                  => __( 'Get the free NV oOS base version — no payment required', 'nvoos-docs-hub' ),
				'dev_status'                   => __( 'NV oOS is still in active development and testing. Your purchase includes updates and email support — and is covered by our 30-day money-back guarantee.', 'nvoos-docs-hub' ),
				'price_one_time'               => __( 'One-time payment — no subscription', 'nvoos-docs-hub' ),
				'price_subject_change'         => __( 'Introductory price — prices are subject to change.', 'nvoos-docs-hub' ),
				'price_vat_note'               => __( 'VAT may be added at checkout based on your country.', 'nvoos-docs-hub' ),
				'price_license_scope'          => __( 'Includes 1 year of updates and email support on this site.', 'nvoos-docs-hub' ),
				'trust_guarantee'              => __( 'Try it risk-free — 30-day money-back guarantee', 'nvoos-docs-hub' ),
				'trust_instant'                => __( 'Instant download and automatic install', 'nvoos-docs-hub' ),
				'includes_title'               => __( 'Included in NV oOS Complete', 'nvoos-docs-hub' ),
				'includes_full'                => __( 'The full NV oOS plugin — base + Pro', 'nvoos-docs-hub' ),
				'includes_updates'             => __( '1 year of updates', 'nvoos-docs-hub' ),
				'includes_support'             => __( 'Email support directly from the developer', 'nvoos-docs-hub' ),
				'includes_roadmap'             => __( 'Access to the NV oOS ecosystem when it launches — included at no extra cost', 'nvoos-docs-hub' ),
				'roadmap_funded'               => __( 'Your purchase directly funds the next features. Owners like you shape the roadmap — tell us what to build next.', 'nvoos-docs-hub' ),
				'roadmap_link_label'           => __( 'Share your ideas', 'nvoos-docs-hub' ),
				'terms_eu_withdrawal'          => __( 'Delivery starts immediately. By downloading, you acknowledge that you lose your EU right of withdrawal for this digital content.', 'nvoos-docs-hub' ),
				'success_steps_title'          => __( 'What happens next', 'nvoos-docs-hub' ),
				'success_step_receipt'         => __( 'A receipt is on its way to your email.', 'nvoos-docs-hub' ),
				'success_step_installed'       => __( 'NV oOS Complete is installed and activated.', 'nvoos-docs-hub' ),
				'success_step_license'         => __( 'Your license key is saved — keep it safe.', 'nvoos-docs-hub' ),
				'success_step_roadmap'         => __( 'Watch the changelog for updates — your NV oOS ecosystem access arrives with the launch, at no extra cost.', 'nvoos-docs-hub' ),
				'changelog_link'               => __( 'View changelog', 'nvoos-docs-hub' ),
				'support_line'                 => sprintf(
					/* translators: %s: support email address. */
					__( 'Questions? Email %s', 'nvoos-docs-hub' ),
					NV_oOS_Docs_Hub_Checkout::support_email()
				),
				'generic_error'                => __( 'Something went wrong. Please try again.', 'nvoos-docs-hub' ),
				'stripe_load_error'            => __( 'Stripe failed to load. Check your network connection and try again.', 'nvoos-docs-hub' ),
				'installing'                   => __( 'Recording your license and installing NV oOS Complete…', 'nvoos-docs-hub' ),
				'success_title'                => __( 'You’re all set!', 'nvoos-docs-hub' ),
				'refresh'                      => __( 'Reload page', 'nvoos-docs-hub' ),
				'license_label'                => __( 'License key', 'nvoos-docs-hub' ),
				'test_mode'                    => __( 'Test mode — no real payment will be taken.', 'nvoos-docs-hub' ),
				'pending_retry'                => __( 'Check again', 'nvoos-docs-hub' ),
				'pending_new'                  => __( 'Start a new purchase', 'nvoos-docs-hub' ),
				'fallback_note'                => __( 'The checkout service is unavailable right now. Redirecting you to the product page to complete your purchase…', 'nvoos-docs-hub' ),
				'verify'                       => __( 'Verify', 'nvoos-docs-hub' ),
				'payment_processing'           => __( 'Payment is still processing. Click Verify once it completes.', 'nvoos-docs-hub' ),
				'payment_incomplete'           => __( 'Payment did not complete. Status: ', 'nvoos-docs-hub' ),
				'download_zip'                 => __( 'Download ZIP manually', 'nvoos-docs-hub' ),
				'terms_consent'                => __( 'I have read and agree to the Terms of Service and the Refund Policy, including the 30-day money-back guarantee.', 'nvoos-docs-hub' ),
				'terms_link'                   => __( 'Terms of Service', 'nvoos-docs-hub' ),
				'refund_link'                  => __( 'Refund Policy', 'nvoos-docs-hub' ),
				'terms_required'               => __( 'Please agree to the Terms of Service and Refund Policy to continue.', 'nvoos-docs-hub' ),
				'email_label'                  => __( 'Email for receipt and refunds', 'nvoos-docs-hub' ),
				'email_placeholder'            => __( 'you@example.com', 'nvoos-docs-hub' ),
				'email_invalid'                => __( 'Please enter a valid email address for your receipt.', 'nvoos-docs-hub' ),
				'manual_install_note'          => __( 'Prefer to install manually? Download the ZIP and upload it via Plugins → Add New Plugin → Upload Plugin.', 'nvoos-docs-hub' ),
				'country_label'                => __( 'Country (for VAT records)', 'nvoos-docs-hub' ),
				'country_other'                => __( 'Other / Non-EU', 'nvoos-docs-hub' ),
				'address_line1_label'          => __( 'Street address', 'nvoos-docs-hub' ),
				'address_city_label'           => __( 'City', 'nvoos-docs-hub' ),
				'address_postal_label'         => __( 'Postal code (optional)', 'nvoos-docs-hub' ),
				'address_required'             => __( 'EU purchases require a billing address. Please complete the address fields.', 'nvoos-docs-hub' ),
				// Never rendered for docs-hub (no legacy addon artifact);
				// kept as an empty string so the shared JS is identical to
				// the Content Graph original.
				'success_step_installed_addon' => '',
			),
		);
	}

	/**
	 * Return the plugin settings with all repository tokens removed.
	 *
	 * Used when localizing settings for the admin scripts so sensitive
	 * GitHub personal access tokens never land in the page markup.
	 *
	 * @since 0.4.4
	 *
	 * @return array
	 */
	private static function settings_without_tokens() {
		$settings = NV_oOS_Docs_Hub_Plugin::get_settings();

		if ( isset( $settings['remote_repos'] ) && is_array( $settings['remote_repos'] ) ) {
			foreach ( $settings['remote_repos'] as &$repo_row ) {
				if ( is_array( $repo_row ) ) {
					unset( $repo_row['token'] );
				}
			}
			unset( $repo_row );
		}

		return $settings;
	}

	/**
	 * Add the settings page under Settings menu.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function add_menu() {
		add_submenu_page(
			'options-general.php',
			__( 'NV oOS Docs Hub', 'nvoos-docs-hub' ),
			__( 'NV oOS Docs Hub', 'nvoos-docs-hub' ),
			'manage_options',
			'nvoos-docs-hub',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Register settings fields.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function register_settings() {
		register_setting(
			'nvoos_docs_hub_settings_group',
			NV_oOS_Docs_Hub_Plugin::OPTION_KEY,
			array(
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
				'default'           => array(),
			)
		);

		// General section.
		add_settings_section(
			'nvoos_docs_hub_general',
			__( 'General Settings', 'nvoos-docs-hub' ),
			'__return_false',
			'nvoos-docs-hub'
		);

		add_settings_field(
			'enabled',
			__( 'Enable Addon', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_checkbox' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_general',
			array(
				'id'          => 'enabled',
				'description' => __( 'Enable the Docs Hub documentation browser.', 'nvoos-docs-hub' ),
			)
		);

		add_settings_field(
			'public_access',
			__( 'Allow Public (Guest) Access', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_checkbox' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_general',
			array(
				'id'          => 'public_access',
				'description' => __( 'When enabled, the documentation browser is accessible to all visitors without logging in. Disable to require a WordPress account.', 'nvoos-docs-hub' ),
			)
		);

		add_settings_field(
			'default_theme',
			__( 'Default Theme', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_select' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_general',
			array(
				'id'      => 'default_theme',
				'options' => array(
					'auto'  => __( 'Auto (system preference)', 'nvoos-docs-hub' ),
					'light' => __( 'Light', 'nvoos-docs-hub' ),
					'dark'  => __( 'Dark', 'nvoos-docs-hub' ),
				),
			)
		);

		add_settings_field(
			'search_enabled',
			__( 'Enable Search', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_checkbox' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_general',
			array(
				'id'          => 'search_enabled',
				'description' => __( 'Show the search box in the documentation browser.', 'nvoos-docs-hub' ),
			)
		);

		add_settings_field(
			'sidebar_enabled',
			__( 'Enable Sidebar', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_checkbox' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_general',
			array(
				'id'          => 'sidebar_enabled',
				'description' => __( 'Show the navigation sidebar.', 'nvoos-docs-hub' ),
			)
		);

		add_settings_field(
			'include_addon_readmes',
			__( 'Include per-addon README/CHANGELOG', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_checkbox' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_general',
			array(
				'id'          => 'include_addon_readmes',
				'description' => __( 'Index each addon\'s top-level README.md and CHANGELOG.md alongside its docs/ tree. Disable to surface only the plugin-root files.', 'nvoos-docs-hub' ),
			)
		);

		add_settings_field(
			'default_home',
			__( 'Home Page Slug', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_text' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_general',
			array(
				'id'          => 'default_home',
				'description' => __( 'Slug of the page shown by default (e.g. "readme").', 'nvoos-docs-hub' ),
			)
		);

		add_settings_field(
			'github_repo_url',
			__( 'GitHub Repository URL', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_text' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_general',
			array(
				'id'          => 'github_repo_url',
				'description' => __( 'Base URL for "Edit on GitHub" links (e.g. https://github.com/org/repo/blob/main).', 'nvoos-docs-hub' ),
			)
		);

		add_settings_field(
			'uploads_docs_dir_help',
			__( 'Uploaded Docs Folder', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_uploads_docs_help' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_general',
			array()
		);

		// Sources section.
		add_settings_section(
			'nvoos_docs_hub_sources',
			__( 'Documentation Sources', 'nvoos-docs-hub' ),
			'__return_false',
			'nvoos-docs-hub'
		);

		add_settings_field(
			'sources',
			__( 'Enabled Sources', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_sources_checkboxes' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_sources',
			array()
		);

		add_settings_field(
			'context_enabled',
			__( 'Include .context/ Files', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_checkbox' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_sources',
			array(
				'id'          => 'context_enabled',
				'description' => __( 'Include .context/*.md files. Warning: these are only visible to users with manage_options capability.', 'nvoos-docs-hub' ),
			)
		);

		// Remote repositories section.
		add_settings_section(
			'nvoos_docs_hub_remote',
			__( 'Remote Repositories', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_remote_section_intro' ),
			'nvoos-docs-hub'
		);

		add_settings_field(
			'enable_remote_repos',
			__( 'Enable Remote Repositories', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_enable_remote_repos' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_remote',
			array()
		);

		add_settings_field(
			'remote_repos',
			__( 'Public GitHub Repositories', 'nvoos-docs-hub' ),
			array( __CLASS__, 'render_remote_repos' ),
			'nvoos-docs-hub',
			'nvoos_docs_hub_remote',
			array()
		);
	}

	/**
	 * Render a first-run notice when the settings option has never been
	 * saved (i.e. nothing has been configured yet).
	 *
	 * @since 0.3.0
	 *
	 * @return void
	 */
	public static function maybe_render_first_run_notice() {
		if ( false !== get_option( NV_oOS_Docs_Hub_Plugin::OPTION_KEY, false ) ) {
			return;
		}
		?>
		<div class="notice notice-info" style="margin-top:12px;">
			<p>
				<strong><?php esc_html_e( 'Welcome to NV oOS Docs Hub.', 'nvoos-docs-hub' ); ?></strong>
				<?php
				printf(
					/* translators: %s: absolute path to the uploads content folder. */
					esc_html__( 'Drop Markdown files into %s, then rebuild the index to publish them. To import documentation from public GitHub repositories instead, enable Remote Repositories below.', 'nvoos-docs-hub' ),
					esc_html( NV_oOS_Docs_Hub_Plugin::uploads_docs_dir() )
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Render a one-time, dismissible notice for installs that have all the
	 * legacy local sources enabled and zero remote repos configured —
	 * pointing them to the new tree picker.
	 *
	 * Dismissal is stored per-user in user meta.
	 *
	 * @since 0.3.0
	 *
	 * @return void
	 */
	public static function maybe_render_legacy_only_notice() {
		$user_id = get_current_user_id();
		if ( $user_id && get_user_meta( $user_id, 'nvoos_docs_hub_legacy_notice_dismissed', true ) ) {
			return;
		}

		$settings = NV_oOS_Docs_Hub_Plugin::get_settings();
		$sources  = isset( $settings['sources'] ) ? (array) $settings['sources'] : array();
		$repos    = isset( $settings['remote_repos'] ) ? (array) $settings['remote_repos'] : array();

		$has_all_legacy = in_array( 'base', $sources, true )
			&& in_array( 'addons', $sources, true )
			&& in_array( 'root', $sources, true );

		if ( ! $has_all_legacy || ! empty( $repos ) ) {
			return;
		}

		// Handle dismiss action.
		if ( ! empty( $_GET['nvoos_dh_dismiss_legacy'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- non-state-changing dismissal.
			&& isset( $_GET['_wpnonce'] )
			&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'nvoos_dh_dismiss_legacy' )
		) {
			update_user_meta( $user_id, 'nvoos_docs_hub_legacy_notice_dismissed', 1 );
			return;
		}

		$dismiss_url = wp_nonce_url(
			add_query_arg( 'nvoos_dh_dismiss_legacy', '1' ),
			'nvoos_dh_dismiss_legacy'
		);
		?>
		<div class="notice notice-warning" style="margin-top:12px;">
			<p>
				<strong><?php esc_html_e( 'Heads up:', 'nvoos-docs-hub' ); ?></strong>
				<?php
				printf(
					/* translators: %s: absolute path to the uploads content folder. */
					esc_html__( 'You are indexing only legacy local filesystem sources. Most installations should use the Uploaded docs folder instead (%s), or enable Remote Repositories above to import from GitHub.', 'nvoos-docs-hub' ),
					esc_html( NV_oOS_Docs_Hub_Plugin::uploads_docs_dir() )
				);
				?>
				<a href="<?php echo esc_url( $dismiss_url ); ?>" style="margin-left:8px;">
					<?php esc_html_e( 'Dismiss', 'nvoos-docs-hub' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Handle the rebuild action button form submission.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	/**
	 * AJAX handler: import settings from a JSON file.
	 *
	 * Accepts a `data` field containing the JSON string. Runs the
	 * same sanitize_settings pipeline as a normal save so invalid
	 * values are dropped. Tokens are stripped by the exporter, so
	 * the imported repos have blank tokens that the admin must re-enter.
	 *
	 * @since 1.3.0
	 *
	 * @return void
	 */
	public static function ajax_import_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'nvoos-docs-hub' ) ), 403 );
		}

		check_ajax_referer( 'nvoos_docs_hub_import_settings' );

		$raw_json = isset( $_POST['data'] ) ? wp_unslash( $_POST['data'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON will be validated below.
		if ( '' === $raw_json ) {
			wp_send_json_error( array( 'message' => __( 'No data received.', 'nvoos-docs-hub' ) ) );
		}

		$imported = json_decode( $raw_json, true );
		if ( ! is_array( $imported ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid JSON structure.', 'nvoos-docs-hub' ) ) );
		}

		// Run through the same sanitization pipeline as the settings form.
		$sanitized = self::sanitize_settings( $imported );

		// Preserve existing tokens for repos that match by owner/repo.
		$existing        = NV_oOS_Docs_Hub_Plugin::get_settings();
		$existing_repos  = isset( $existing['remote_repos'] ) ? (array) $existing['remote_repos'] : array();
		$sanitized_repos = isset( $sanitized['remote_repos'] ) ? (array) $sanitized['remote_repos'] : array();
		$new_repos       = array();
		foreach ( $sanitized_repos as $sr ) {
			if ( ! is_array( $sr ) || empty( $sr['owner'] ) || empty( $sr['repo'] ) ) {
				$new_repos[] = $sr;
				continue;
			}
			// If the imported token is blank, look up existing token.
			if ( empty( $sr['token'] ) ) {
				$key = strtolower( (string) $sr['owner'] ) . '|' . strtolower( (string) $sr['repo'] );
				foreach ( $existing_repos as $er ) {
					if ( ! is_array( $er ) ) {
						continue;
					}
					$ek = strtolower( (string) ( $er['owner'] ?? '' ) ) . '|' . strtolower( (string) ( $er['repo'] ?? '' ) );
					if ( $key === $ek && ! empty( $er['token'] ) ) {
						$sr['token'] = (string) $er['token'];
						break;
					}
				}
			}
			$new_repos[] = $sr;
		}
		$sanitized['remote_repos'] = $new_repos;

		update_option( NV_oOS_Docs_Hub_Plugin::OPTION_KEY, $sanitized );

		$repo_count = count( $sanitized['remote_repos'] );
		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %d: number of remote repos imported */
					_n(
						'Imported %d remote repository. A rebuild will run automatically. Refresh the page to see the changes.',
						'Imported %d remote repositories. A rebuild will run automatically. Refresh the page to see the changes.',
						$repo_count,
						'nvoos-docs-hub'
					),
					$repo_count
				),
			)
		);
	}

	/**
	 * Handle the synchronous rebuild form submission.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function handle_rebuild_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( empty( $_POST['nvoos_docs_hub_rebuild'] ) ) {  // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}

		check_admin_referer( 'nvoos_docs_hub_rebuild_action', 'nvoos_docs_hub_rebuild_nonce' );

		$result = NV_oOS_Docs_Hub_Rebuild_Job::run();

		if ( $result['success'] ) {
			add_action(
				'admin_notices',
				function () use ( $result ) {
					echo '<div class="notice notice-success is-dismissible"><p>';
					echo esc_html(
						sprintf(
							/* translators: 1: page count, 2: broken link count */
							__( 'Documentation rebuilt successfully. %1$d pages indexed, %2$d broken links found.', 'nvoos-docs-hub' ),
							$result['pages'],
							$result['broken_links']
						)
					);
					echo '</p></div>';
				}
			);
		} else {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error is-dismissible"><p>';
					esc_html_e( 'Documentation rebuild failed. Please check PHP error logs.', 'nvoos-docs-hub' );
					echo '</p></div>';
				}
			);
		}
	}

	/**
	 * Sanitize settings on save.
	 *
	 * @since 1.0.0
	 *
	 * @param array $input Raw input values.
	 * @return array Sanitized values.
	 */
	public static function sanitize_settings( $input ) {
		$sanitized = array();

		$sanitized['enabled']               = ! empty( $input['enabled'] );
		$sanitized['public_access']         = ! empty( $input['public_access'] );
		$sanitized['search_enabled']        = ! empty( $input['search_enabled'] );
		$sanitized['sidebar_enabled']       = ! empty( $input['sidebar_enabled'] );
		$sanitized['context_enabled']       = ! empty( $input['context_enabled'] );
		$sanitized['include_addon_readmes'] = ! empty( $input['include_addon_readmes'] );
		$sanitized['default_home']          = sanitize_text_field( $input['default_home'] ?? 'readme' );
		$sanitized['github_repo_url']       = esc_url_raw( $input['github_repo_url'] ?? '' );

		$allowed_themes             = array( 'auto', 'light', 'dark' );
		$raw_theme                  = sanitize_text_field( $input['default_theme'] ?? 'auto' );
		$sanitized['default_theme'] = in_array( $raw_theme, $allowed_themes, true ) ? $raw_theme : 'auto';

		$allowed_sources      = array( 'base', 'addons', 'root', 'context', 'uploads', 'remote' );
		$raw_sources          = isset( $input['sources'] ) && is_array( $input['sources'] ) ? $input['sources'] : array();
		$sanitized['sources'] = array_values(
			array_filter(
				$raw_sources,
				function ( $s ) use ( $allowed_sources ) {
					return in_array( $s, $allowed_sources, true );
				}
			)
		);

		$sanitized['enable_remote_repos'] = ! empty( $input['enable_remote_repos'] );

		// Keep the dedicated toggle and the 'remote' source key in sync so
		// saved settings can never diverge (the scanner gates on both).
		if ( $sanitized['enable_remote_repos'] ) {
			if ( ! in_array( 'remote', $sanitized['sources'], true ) ) {
				$sanitized['sources'][] = 'remote';
			}
		} else {
			$sanitized['sources'] = array_values(
				array_filter(
					$sanitized['sources'],
					static function ( $s ) {
						return 'remote' !== $s;
					}
				)
			);
		}

		// Sanitize remote repos.
		// Build a lookup map of existing tokens keyed by owner|repo so token
		// preservation survives row reordering (add/remove) that would otherwise
		// cause tokens to silently transfer between repos when matched by index.
		$existing_settings  = NV_oOS_Docs_Hub_Plugin::get_settings();
		$existing_repos     = isset( $existing_settings['remote_repos'] ) ? (array) $existing_settings['remote_repos'] : array();
		$existing_token_map = array();
		foreach ( $existing_repos as $er ) {
			if ( ! is_array( $er ) || empty( $er['owner'] ) || empty( $er['repo'] ) ) {
				continue;
			}
			$key = strtolower( trim( (string) $er['owner'] ) ) . '|' . strtolower( trim( (string) $er['repo'] ) );
			if ( ! empty( $er['token'] ) ) {
				$existing_token_map[ $key ] = (string) $er['token'];
			}
		}

		$sanitized['remote_repos']   = array();
		$raw_repos                   = isset( $input['remote_repos'] ) && is_array( $input['remote_repos'] ) ? $input['remote_repos'] : array();
		$dropped_empty               = 0;
		$dropped_invalid_chars       = 0;
		$dropped_invalid_chars_label = '';

		foreach ( $raw_repos as $i => $repo ) {
			if ( ! is_array( $repo ) ) {
				++$dropped_empty;
				continue;
			}
			$owner     = sanitize_text_field( $repo['owner'] ?? '' );
			$repo_name = sanitize_text_field( $repo['repo'] ?? '' );
			if ( '' === $owner || '' === $repo_name ) {
				++$dropped_empty;
				continue;
			}
			// Enforce safe characters: letters, digits, hyphens, underscores, dots only.
			if ( ! preg_match( '/^[a-zA-Z0-9_.\-]+$/', $owner ) || ! preg_match( '/^[a-zA-Z0-9_.\-]+$/', $repo_name ) ) {
				++$dropped_invalid_chars;
				if ( '' === $dropped_invalid_chars_label ) {
					$dropped_invalid_chars_label = $owner . '/' . $repo_name;
				}
				continue;
			}

			$new_token = sanitize_text_field( $repo['token'] ?? '' );
			// When the token field is submitted blank, preserve the existing token
			// for this specific owner/repo pair (matched by key, not array index).
			if ( '' === $new_token ) {
				$lookup_key = strtolower( $owner ) . '|' . strtolower( $repo_name );
				if ( isset( $existing_token_map[ $lookup_key ] ) ) {
					$new_token = $existing_token_map[ $lookup_key ];
				}
			}

			// Selection mode values: all (default), prefix, or selected.
			$raw_mode       = sanitize_text_field( $repo['selection_mode'] ?? 'all' );
			$selection_mode = in_array( $raw_mode, array( 'all', 'prefix', 'selected' ), true ) ? $raw_mode : 'all';

			// Selected / excluded paths arrays. Both follow the same path safety rules:
			// - Allowed chars: letters, digits, underscore, dot, slash, hyphen.
			// - No '..' segments, no leading slash.
			// - Trailing '/' = directory (recursive include/exclude).
			$selected_paths = self::sanitize_path_list( $repo['selected_paths'] ?? array() );
			$excluded_paths = self::sanitize_path_list( $repo['excluded_paths'] ?? array() );

			$sanitized['remote_repos'][] = array(
				'owner'          => $owner,
				'repo'           => $repo_name,
				'ref'            => sanitize_text_field( $repo['ref'] ?? 'HEAD' ),
				'label'          => sanitize_text_field( $repo['label'] ?? $owner . '/' . $repo_name ),
				'path'           => sanitize_text_field( $repo['path'] ?? '' ),
				'token'          => $new_token,
				'selection_mode' => $selection_mode,
				'selected_paths' => $selected_paths,
				'excluded_paths' => $excluded_paths,
			);
		}

		// Surface sanitization warnings via WordPress settings errors so the
		// admin gets feedback when repo rows were silently dropped.
		$total_dropped = $dropped_empty + $dropped_invalid_chars;
		if ( $total_dropped > 0 ) {
			$messages = array();
			if ( $dropped_empty > 0 ) {
				$messages[] = sprintf(
					/* translators: %d: number of rows dropped */
					_n(
						'%d remote repository row was dropped because owner or repo was empty.',
						'%d remote repository rows were dropped because owner or repo was empty.',
						$dropped_empty,
						'nvoos-docs-hub'
					),
					$dropped_empty
				);
			}
			if ( $dropped_invalid_chars > 0 ) {
				$messages[] = sprintf(
					/* translators: 1: number of rows, 2: example owner/repo label */
					_n(
						'%1$d remote repository row (e.g. "%2$s") was dropped because the owner or repo name contains invalid characters. Only letters, digits, hyphens, underscores, and dots are allowed.',
						'%1$d remote repository rows (e.g. "%2$s") were dropped because the owner or repo name contains invalid characters. Only letters, digits, hyphens, underscores, and dots are allowed.',
						$dropped_invalid_chars,
						'nvoos-docs-hub'
					),
					$dropped_invalid_chars,
					$dropped_invalid_chars_label
				);
			}
			foreach ( $messages as $msg ) {
				add_settings_error(
					'nvoos_docs_hub_settings_group',
					'nvoos_docs_hub_dropped_rows',
					$msg,
					'warning'
				);
			}
		}

		return $sanitized;
	}

	/**
	 * Coerce a stored path-list value into a flat array of strings.
	 *
	 * Tolerates bad input shapes that may arrive from third-party migrations:
	 * arrays of arrays, scalars, or newline-delimited strings.
	 *
	 * @since 0.3.6
	 *
	 * @param mixed $raw Stored value.
	 * @return string[] Array of single-line path strings.
	 */
	public static function coerce_path_list( $raw ) {
		if ( is_string( $raw ) ) {
			$raw = preg_split( '/\r\n|\r|\n/', $raw );
		}
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out = array();
		foreach ( $raw as $entry ) {
			if ( is_array( $entry ) ) {
				continue; // Nested arrays are dropped — settings save will normalise.
			}
			$line = trim( (string) $entry );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Sanitize a list of repo-relative paths (newline string or array).
	 *
	 * Allowed chars: A-Z a-z 0-9 _ . / -. Rejects entries containing '..'
	 * or leading '/'. Trailing '/' is preserved (signals "directory").
	 *
	 * @since 0.3.0
	 *
	 * @param mixed $raw Raw input (textarea string or array).
	 * @return string[] Sanitized paths.
	 */
	public static function sanitize_path_list( $raw ) {
		if ( is_string( $raw ) ) {
			$raw = preg_split( '/\r\n|\r|\n/', $raw );
		}
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out = array();
		foreach ( $raw as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line ) {
				continue;
			}
			// No leading slash.
			if ( '/' === $line[0] ) {
				continue;
			}
			// Reject '..' as a path segment (e.g. '..', 'a/..', '../b', 'a/../b'),
			// but allow filenames that merely contain consecutive dots ('..hidden.md').
			if ( preg_match( '#(^|/)\.\.(/|$)#', $line ) ) {
				continue;
			}
			// Allow common filename characters. The '..' check above prevents
			// path traversal independently of this character class, so we can
			// be permissive for legitimate repo filenames.
			if ( ! preg_match( '#^[A-Za-z0-9_./\- @(){}\[\]\'"!,;+]+/?$#', $line ) ) {
					continue;
			}
			$out[] = $line;
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		self::maybe_render_first_run_notice();
		self::maybe_render_legacy_only_notice();

		$cache         = new NV_oOS_Docs_Hub_Cache();
		$last_built    = $cache->get_last_built();
		$manifest      = $cache->get_manifest();
		$total_pages   = is_array( $manifest ) ? ( $manifest['total_pages'] ?? 0 ) : 0;
		$broken_links  = is_array( $manifest ) ? count( $manifest['broken_links'] ?? array() ) : 0;
		$rebuild_state = NV_oOS_Docs_Hub_Rebuild_State::to_summary();
		$rest_base     = esc_url_raw( rest_url( NV_oOS_Docs_Hub_REST::NAMESPACE ) );
		$rest_nonce    = wp_create_nonce( 'wp_rest' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'NV oOS Docs Hub Settings', 'nvoos-docs-hub' ); ?></h1>

			<div class="card" style="max-width: 600px; margin-bottom: 20px; padding: 15px;">
				<h2 style="margin-top: 0;"><?php esc_html_e( 'Documentation Index Status', 'nvoos-docs-hub' ); ?></h2>
				<p>
					<strong><?php esc_html_e( 'Last Built:', 'nvoos-docs-hub' ); ?></strong>
					<?php
					if ( $last_built > 0 ) {
						echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $last_built ) );
					} else {
						esc_html_e( 'Never', 'nvoos-docs-hub' );
					}
					?>
				</p>
				<p>
					<strong><?php esc_html_e( 'Total Pages:', 'nvoos-docs-hub' ); ?></strong>
					<?php echo esc_html( $total_pages ); ?>
				</p>
				<p>
					<strong><?php esc_html_e( 'Broken Links:', 'nvoos-docs-hub' ); ?></strong>
					<?php echo esc_html( $broken_links ); ?>
					<?php if ( $broken_links > 0 && is_array( $manifest ) && ! empty( $manifest['broken_links'] ) ) : ?>
						<a href="#nvoos-docs-hub-broken-links-table" style="margin-left: 8px;"><?php esc_html_e( 'View details &amp; fix', 'nvoos-docs-hub' ); ?> ↓</a>
					<?php endif; ?>
				</p>

				<div id="nvoos-docs-hub-rebuild-panel" data-rest-base="<?php echo esc_attr( $rest_base ); ?>" data-rest-nonce="<?php echo esc_attr( $rest_nonce ); ?>" data-initial-state="<?php echo esc_attr( wp_json_encode( $rebuild_state ) ); ?>">
					<p class="nvoos-rebuild-status" style="margin-top: 12px;">
						<strong><?php esc_html_e( 'Rebuild status:', 'nvoos-docs-hub' ); ?></strong>
						<span class="nvoos-rebuild-phase"><?php echo esc_html( $rebuild_state['phase'] ); ?></span>
						—
						<span class="nvoos-rebuild-progress">
							<?php
							echo esc_html(
								sprintf(
								/* translators: 1: processed, 2: total, 3: percentage */
									__( '%1$d / %2$d (%3$d%%)', 'nvoos-docs-hub' ),
									(int) $rebuild_state['processed'],
									(int) $rebuild_state['total'],
									(int) $rebuild_state['percentage']
								)
							);
							?>
						</span>
					</p>
					<p class="nvoos-rebuild-error" style="display:<?php echo empty( $rebuild_state['last_error'] ) ? 'none' : 'block'; ?>; color:#a00;">
						<strong><?php esc_html_e( 'Last error:', 'nvoos-docs-hub' ); ?></strong>
						<span class="nvoos-rebuild-error-msg"><?php echo esc_html( $rebuild_state['last_error'] ); ?></span>
					</p>
					<p>
						<button type="button" class="button button-primary nvoos-rebuild-start"<?php echo $rebuild_state['is_running'] ? ' disabled' : ''; ?>>
							<?php esc_html_e( 'Rebuild Documentation Index', 'nvoos-docs-hub' ); ?>
						</button>
						<button type="button" class="button nvoos-rebuild-resume"<?php echo $rebuild_state['is_running'] ? ' disabled' : ''; ?>>
							<?php esc_html_e( 'Resume', 'nvoos-docs-hub' ); ?>
						</button>
						<button type="button" class="button nvoos-rebuild-cancel"<?php echo $rebuild_state['is_running'] ? '' : ' disabled'; ?>>
							<?php esc_html_e( 'Cancel', 'nvoos-docs-hub' ); ?>
						</button>
					</p>
				</div>

				<!-- Sync fallback for environments without JavaScript / WP-Cron. -->
				<form method="post" action="" style="margin-top: 8px;">
					<?php wp_nonce_field( 'nvoos_docs_hub_rebuild_action', 'nvoos_docs_hub_rebuild_nonce' ); ?>
					<input type="submit"
						name="nvoos_docs_hub_rebuild"
						class="button"
						value="<?php esc_attr_e( 'Rebuild now (synchronous)', 'nvoos-docs-hub' ); ?>" />
				</form>
			</div>

		<?php
		// Broken links detail table.
		$broken_list = is_array( $manifest ) && ! empty( $manifest['broken_links'] ) ? (array) $manifest['broken_links'] : array();
		if ( ! empty( $broken_list ) ) :
			?>
		<div id="nvoos-docs-hub-broken-links-table" class="card" style="max-width: 960px; margin-bottom: 20px; padding: 15px;">
			<h2 style="margin-top: 0;"><?php esc_html_e( 'Broken Link Details', 'nvoos-docs-hub' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'These internal documentation links could not be resolved. Accept a suggestion to fix the link in the source file, or run a rebuild to refresh the manifest.', 'nvoos-docs-hub' ); ?>
			</p>

			<p style="margin-bottom: 8px;">
				<button type="button" id="nvoos-dh-fix-all" class="button button-primary">
					<?php esc_html_e( 'Accept All Suggestions', 'nvoos-docs-hub' ); ?>
				</button>
				<span id="nvoos-dh-fix-status" style="margin-left: 10px; font-style: italic;"></span>
			</p>

			<table class="wp-list-table widefat fixed striped" style="margin-top: 12px;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Source Page', 'nvoos-docs-hub' ); ?></th>
						<th><?php esc_html_e( 'Broken Target', 'nvoos-docs-hub' ); ?></th>
						<th><?php esc_html_e( 'Best Suggestion', 'nvoos-docs-hub' ); ?></th>
						<th><?php esc_html_e( 'Confidence', 'nvoos-docs-hub' ); ?></th>
						<th><?php esc_html_e( 'Method', 'nvoos-docs-hub' ); ?></th>
						<th><?php esc_html_e( 'Action', 'nvoos-docs-hub' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $broken_list as $i => $link ) :
						$src       = isset( $link['source'] ) ? (string) $link['source'] : '';
						$tgt       = isset( $link['target'] ) ? (string) $link['target'] : '';
						$src_slug  = isset( $link['slug'] ) ? (string) $link['slug'] : '';
						$src_type  = isset( $link['source_type'] ) ? (string) $link['source_type'] : '';
						$is_remote = ( 'remote' === $src_type );
						$suggs     = isset( $link['suggestions'] ) ? (array) $link['suggestions'] : array();
						$best      = ! empty( $suggs ) ? $suggs[0] : null;
						$has_fix   = null !== $best && isset( $best['target'] );
						?>
						<tr data-index="<?php echo esc_attr( $i ); ?>"
							data-source="<?php echo esc_attr( $src ); ?>"
							data-slug="<?php echo esc_attr( $src_slug ); ?>"
							data-source-type="<?php echo esc_attr( $src_type ); ?>"
							data-old-target="<?php echo esc_attr( $tgt ); ?>"
							data-new-target="<?php echo ( $has_fix && ! $is_remote ) ? esc_attr( $best['target'] ) : ''; ?>">
							<td><code><?php echo esc_html( $src ); ?></code></td>
							<td><code style="color: #a00;"><?php echo esc_html( $tgt ); ?></code></td>
							<td>
								<?php if ( $best ) : ?>
									<code style="color: #007017;"><?php echo esc_html( $best['target'] ); ?></code>
								<?php else : ?>
									<span style="color: #999;">—</span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( $best ) : ?>
									<?php echo esc_html( (int) round( (float) $best['confidence'] * 100 ) . '%' ); ?>
								<?php else : ?>
									<span style="color: #999;">—</span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( $best ) : ?>
									<code><?php echo esc_html( $best['method'] ); ?></code>
								<?php else : ?>
									<span style="color: #999;">—</span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( $is_remote ) : ?>
									<span style="color: #999;"><?php esc_html_e( 'Remote source — fix in the source repository', 'nvoos-docs-hub' ); ?></span>
								<?php elseif ( $has_fix ) : ?>
									<button type="button" class="button button-small nvoos-dh-accept-fix">
										<?php esc_html_e( 'Accept fix', 'nvoos-docs-hub' ); ?>
									</button>
								<?php else : ?>
									<span style="color: #999;">—</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<p style="margin-top: 12px;">
				<em>
					<?php
					echo wp_kses_post(
						sprintf(
							/* translators: %s: CLI command */
							__( 'To fix links interactively, run: %s', 'nvoos-docs-hub' ),
							'<code>wp nvoos-docs fix-links</code>'
						)
					);
					?>
				</em>
			</p>
		</div>
		<?php endif; ?>

			<!-- Page scripts (rebuild panel, dirty-state tracking, broken-link fixes) are enqueued as assets/admin/settings-page.js. -->

					<form method="post" action="options.php">
				<?php
					settings_fields( 'nvoos_docs_hub_settings_group' );
				try {
					do_settings_sections( 'nvoos-docs-hub' );
				} catch ( \Throwable $e ) {
					echo '<div class="notice notice-error"><p>';
					echo esc_html(
						sprintf(
							/* translators: %s: error message */
							__( 'Error rendering settings sections: %s', 'nvoos-docs-hub' ),
							$e->getMessage()
						)
					);
					echo '</p></div>';
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- intentional diagnostic
					error_log(
						sprintf(
							'[NV oOS Docs Hub] do_settings_sections fatal: %s in %s:%d',
							$e->getMessage(),
							$e->getFile(),
							$e->getLine()
						)
					);
				}
					submit_button();
				?>
				</form>

			<?php self::render_checkout_upsell(); ?>

				<hr />

				<h2><?php esc_html_e( 'Export / Import Settings', 'nvoos-docs-hub' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'Download your Docs Hub configuration as JSON or restore a previously exported file. Importing overwrites the current settings (a rebuild will be triggered automatically).', 'nvoos-docs-hub' ); ?>
				</p>

				<p>
					<button type="button" id="nvoos-dh-export-settings" class="button">
						<?php esc_html_e( 'Export Settings (JSON)', 'nvoos-docs-hub' ); ?>
					</button>
				</p>

				<p>
					<label for="nvoos-dh-import-file" class="button" style="cursor:pointer;">
						<?php esc_html_e( 'Import Settings (JSON)', 'nvoos-docs-hub' ); ?>
					</label>
					<input type="file"
						id="nvoos-dh-import-file"
						accept=".json,application/json"
						style="display:none;" />
					<span id="nvoos-dh-import-status" style="margin-left:8px; color:#646970; font-style:italic;"></span>
				</p>

			<!-- Export / Import settings scripts are enqueued as assets/admin/settings-page.js. -->

				<p class="description">
					<?php
					esc_html_e( 'Note: Exported files do NOT include Personal Access Tokens. After importing, re-enter your tokens and save. If your server runs Nginx, add a location rule to deny direct access to the cache directory:', 'nvoos-docs-hub' );
					?>
					<br />
					<code style="display:inline-block; margin-top:4px; background:#f0f0f1; padding:4px 8px;">
						location /wp-content/uploads/nvoos-docs-hub/ { deny all; return 403; }
					</code>
				</p>

			</div>
			<?php
	}

	/**
	 * Render the NV oOS Complete upsell card after the settings form.
	 *
	 * Shown only while the Complete bundle is not active, pointing users
	 * at the AI features they can unlock. The "Get NV oOS Complete"
	 * button opens the checkout modal (assets/admin/docs-hub-checkout.js)
	 * which talks to the vendor checkout API — no Stripe keys live in
	 * this plugin.
	 *
	 * @since 0.5.2
	 *
	 * @return void
	 */
	private static function render_checkout_upsell() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// The purchase artifact is the Complete bundle; once it is active
		// the upsell no longer applies.
		if ( NV_oOS_Docs_Hub_Checkout_Installer::is_bundle_active() ) {
			return;
		}
		?>
		<div class="nvoos-docs-hub-upsell-card" style="background:#f0f6fc;border:1px solid #c5d9ed;border-left:4px solid #0073aa;padding:12px 16px;margin-top:16px;max-width:700px;">
			<p style="margin:0 0 8px;">
				<strong><?php esc_html_e( 'Unlock AI-powered features', 'nvoos-docs-hub' ); ?></strong>
			</p>
			<p style="margin:0 0 8px;">
				<?php esc_html_e( 'Install the NV oOS Complete bundle to enable semantic extraction, AI chat, embeddings, and agent memory for your documentation site. Supports 13 AI providers with a single API key.', 'nvoos-docs-hub' ); ?>
			</p>
			<p style="margin:0;">
				<button type="button" class="button button-primary nvoos-docs-hub-buy-complete">
					<?php esc_html_e( 'Get NV oOS Complete', 'nvoos-docs-hub' ); ?>
				</button>
				<a href="https://github.com/nvdigitalsolutions/mcp-ai-wpoos" class="button button-link" target="_blank" rel="noopener">
					<?php esc_html_e( 'Learn more', 'nvoos-docs-hub' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

		/**
		 * Render a checkbox field.
		 *
		 * @since 1.0.0
		 *
		 * @param array $args Field arguments.
		 * @return void
		 */
	public static function render_checkbox( $args ) {
		$settings = NV_oOS_Docs_Hub_Plugin::get_settings();
		$value    = ! empty( $settings[ $args['id'] ] );
		?>
		<label>
			<input type="checkbox"
				name="<?php echo esc_attr( NV_oOS_Docs_Hub_Plugin::OPTION_KEY . '[' . $args['id'] . ']' ); ?>"
				value="1"
				<?php checked( $value ); ?> />
			<?php echo esc_html( $args['description'] ?? '' ); ?>
		</label>
		<?php
	}

	/**
	 * Render a text input field.
	 *
	 * @since 1.0.0
	 *
	 * @param array $args Field arguments.
	 * @return void
	 */
	public static function render_text( $args ) {
		$settings = NV_oOS_Docs_Hub_Plugin::get_settings();
		$value    = $settings[ $args['id'] ] ?? '';
		?>
		<input type="text"
			name="<?php echo esc_attr( NV_oOS_Docs_Hub_Plugin::OPTION_KEY . '[' . $args['id'] . ']' ); ?>"
			value="<?php echo esc_attr( $value ); ?>"
			class="regular-text" />
		<?php if ( ! empty( $args['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $args['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render a select dropdown field.
	 *
	 * @since 1.0.0
	 *
	 * @param array $args Field arguments.
	 * @return void
	 */
	public static function render_select( $args ) {
		$settings = NV_oOS_Docs_Hub_Plugin::get_settings();
		$value    = $settings[ $args['id'] ] ?? '';
		?>
		<select name="<?php echo esc_attr( NV_oOS_Docs_Hub_Plugin::OPTION_KEY . '[' . $args['id'] . ']' ); ?>">
			<?php foreach ( $args['options'] as $key => $label ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $value, $key ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	/**
	 * Render the sources multi-checkbox field.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function render_sources_checkboxes() {
		$settings = NV_oOS_Docs_Hub_Plugin::get_settings();
		$enabled  = isset( $settings['sources'] ) ? (array) $settings['sources'] : array( 'uploads' );

		// Primary (recommended) source.
		$primary = array(
			'uploads' => sprintf(
				/* translators: %s: absolute path to the uploads content folder, wrapped in <code>. */
				__( 'Uploaded docs folder (%s) <em>(recommended)</em>', 'nvoos-docs-hub' ),
				'<code>' . esc_html( NV_oOS_Docs_Hub_Plugin::uploads_docs_dir() ) . '</code>'
			),
		);

		// Legacy local-filesystem sources. Functional, but most users
		// should leave these off — see the "Advanced" notice below.
		$legacy = array(
			'base'    => __( 'Base Plugin (<code>mcp-ai-wpoos/docs/</code>)', 'nvoos-docs-hub' ),
			'addons'  => __( 'Addons (<code>addons/*/docs/</code> and <code>README.md</code>)', 'nvoos-docs-hub' ),
			'root'    => __( 'Repository root files (<code>README.md</code>, <code>CHANGELOG.md</code>, etc.)', 'nvoos-docs-hub' ),
			'context' => __( 'Context files (<code>.context/*.md</code>) — only visible to manage_options users', 'nvoos-docs-hub' ),
		);

		$kses_allowed = array(
			'code' => array(),
			'em'   => array(),
		);

		foreach ( $primary as $key => $label ) :
			?>
			<label style="display: block; margin-bottom: 6px;">
				<input type="checkbox"
					name="<?php echo esc_attr( NV_oOS_Docs_Hub_Plugin::OPTION_KEY . '[sources][]' ); ?>"
					value="<?php echo esc_attr( $key ); ?>"
					<?php checked( in_array( $key, $enabled, true ) ); ?> />
				<?php echo wp_kses( $label, $kses_allowed ); ?>
			</label>
			<?php
		endforeach;
		?>

		<details style="margin-top:10px; padding:10px; border:1px solid #ccd0d4; border-radius:4px; background:#f6f7f7;">
			<summary style="cursor:pointer; font-weight:600;">
				<?php esc_html_e( 'Advanced — local filesystem sources (legacy)', 'nvoos-docs-hub' ); ?>
			</summary>
			<p class="description" style="margin-top:8px;">
				<?php
				esc_html_e(
					'These sources index Markdown from the local plugin install. Most installations should leave them OFF and use the Uploaded docs folder above. They are kept available for local development and monorepo setups.',
					'nvoos-docs-hub'
				);
				?>
			</p>
			<?php foreach ( $legacy as $key => $label ) : ?>
				<label style="display: block; margin-bottom: 6px;">
					<input type="checkbox"
						name="<?php echo esc_attr( NV_oOS_Docs_Hub_Plugin::OPTION_KEY . '[sources][]' ); ?>"
						value="<?php echo esc_attr( $key ); ?>"
						<?php checked( in_array( $key, $enabled, true ) ); ?> />
					<?php echo wp_kses( $label, $kses_allowed ); ?>
				</label>
			<?php endforeach; ?>
		</details>
		<?php
	}

	/**
	 * Render help text for the uploads content folder.
	 *
	 * @since 0.5.0
	 *
	 * @return void
	 */
	public static function render_uploads_docs_help() {
		$dir  = NV_oOS_Docs_Hub_Plugin::uploads_docs_dir();
		$path = '<code>' . esc_html( $dir ) . '</code>';
		echo '<p class="description" style="margin-top:0;">';
		echo wp_kses(
			sprintf(
				/* translators: %s: absolute path to the uploads docs folder. */
				__( 'Drop Markdown (<code>.md</code>) or text (<code>.txt</code>) files into %s — subfolders become sections. Rebuild the index to publish them.', 'nvoos-docs-hub' ),
				$path
			),
			array( 'code' => array() )
		);
		echo '</p>';
	}

	/**
	 * Render the "Enable Remote Repositories" opt-in toggle.
	 *
	 * Remote import is off by default. It must be enabled here AND at least
	 * one repository configured below before the plugin makes any request.
	 *
	 * @since 0.5.0
	 *
	 * @return void
	 */
	public static function render_enable_remote_repos() {
		$settings = NV_oOS_Docs_Hub_Plugin::get_settings();
		$enabled  = ! empty( $settings['enable_remote_repos'] );
		?>
		<label>
			<input type="checkbox" id="nvoos-dh-enable-remote-repos"
				name="<?php echo esc_attr( NV_oOS_Docs_Hub_Plugin::OPTION_KEY . '[enable_remote_repos]' ); ?>"
				value="1"
				<?php checked( $enabled ); ?> />
			<?php esc_html_e( 'Import Markdown from public GitHub repositories', 'nvoos-docs-hub' ); ?>
		</label>
		<p class="description" style="margin-top:4px; max-width:720px;">
			<?php
			esc_html_e(
				'Off by default — leave it off to run the plugin 100% locally. When enabled, the plugin contacts api.github.com and raw.githubusercontent.com (server-side, over HTTPS) to fetch repository files, and only after you configure at least one repository below and trigger a rebuild. No GitHub account is required.',
				'nvoos-docs-hub'
			);
			?>
		</p>
		<?php
	}

	/**
	 * Render introductory text for the Remote Repositories section.
	 *
	 * @since 1.1.0
	 *
	 * @return void
	 */
	public static function render_remote_section_intro() {
		echo '<p>';
		esc_html_e(
			'Import Markdown documentation from public GitHub repositories. Remote import is opt-in: enable it above, then add repositories below. Files are fetched from the GitHub API over HTTPS and cached locally for 24 hours. Only public repos (or private repos accessible with a Personal Access Token) are supported.',
			'nvoos-docs-hub'
		);
		echo '</p>';
		echo '<p style="background:#fff8e5; border-left:4px solid #f0b849; padding:8px 12px; margin:8px 0;">';
		echo '<strong>' . esc_html__( 'Pick exactly which files to index:', 'nvoos-docs-hub' ) . '</strong> ';
		esc_html_e(
			'After entering an Owner and Repository, click "Browse files in repo…" to load the file tree, then check the files or folders you want indexed. Switch "File selection" to "Selected files / folders only" to limit indexing to just those entries.',
			'nvoos-docs-hub'
		);
		echo '</p>';
	}

	/**
	 * Render the remote repositories repeatable list UI.
	 *
	 * @since 1.1.0
	 *
	 * @return void
	 */
	public static function render_remote_repos() {
		$settings = NV_oOS_Docs_Hub_Plugin::get_settings();
		$repos    = isset( $settings['remote_repos'] ) && is_array( $settings['remote_repos'] ) ? $settings['remote_repos'] : array();
		$enabled  = ! empty( $settings['enable_remote_repos'] );

		// The rows are always rendered (so saving never wipes configured
		// repos) but hidden until the opt-in toggle is checked.
		if ( ! $enabled ) {
			echo '<p class="description" id="nvoos-dh-remote-disabled-hint" style="margin:0 0 8px;">';
			esc_html_e( 'Remote import is currently disabled. Enable "Remote Repositories" above to add GitHub repositories.', 'nvoos-docs-hub' );
			echo '</p>';
		}

		// Always render at least one (empty) row so the UI is usable.
		if ( empty( $repos ) ) {
			$repos = array(
				array(
					'owner'          => '',
					'repo'           => '',
					'ref'            => 'HEAD',
					'label'          => '',
					'path'           => '',
					'token'          => '',
					'selection_mode' => 'all',
					'selected_paths' => array(),
					'excluded_paths' => array(),
				),
			);
		}

		$option_key = NV_oOS_Docs_Hub_Plugin::OPTION_KEY;

		echo '<div id="nvoos-dh-remote-repos-wrap"' . ( $enabled ? '' : ' style="display:none;"' ) . '>';

		try {
			foreach ( $repos as $i => $r ) :
				// Defensive: a malformed (string/null/scalar) row from a partial migration must
				// not fatal the settings page. Coerce to an array and surface an inline notice.
				if ( ! is_array( $r ) ) {
					$r = array();
					echo '<div class="notice notice-warning inline" style="margin:0 0 10px 0;"><p>';
					printf(
					/* translators: %d: 1-based row index */
						esc_html__( 'NV oOS Docs Hub: remote repository row #%d was stored in an unexpected shape and has been reset to defaults. Please re-enter the values and save.', 'nvoos-docs-hub' ),
						(int) ( $i + 1 )
					);
					echo '</p></div>';
				}
				$owner = esc_attr( is_string( $r['owner'] ?? '' ) ? $r['owner'] : '' );
				$repo  = esc_attr( is_string( $r['repo'] ?? '' ) ? $r['repo'] : '' );
				$ref   = esc_attr( is_string( $r['ref'] ?? 'HEAD' ) ? $r['ref'] : 'HEAD' );
				$label = esc_attr( is_string( $r['label'] ?? '' ) ? $r['label'] : '' );
				$path  = esc_attr( is_string( $r['path'] ?? '' ) ? $r['path'] : '' );
				// Token: never echo saved token back for security — show placeholder.
				$has_token      = ! empty( $r['token'] );
				$selection_mode = isset( $r['selection_mode'] ) && in_array( $r['selection_mode'], array( 'all', 'prefix', 'selected' ), true )
				? $r['selection_mode']
				: 'all';
				// Coerce path lists defensively. A flat string (from older migrations) is
				// split on newlines so the textarea round-trips correctly.
				$selected_paths = self::coerce_path_list( $r['selected_paths'] ?? array() );
				$excluded_paths = self::coerce_path_list( $r['excluded_paths'] ?? array() );
				$selected_text  = esc_textarea( implode( "\n", $selected_paths ) );
				$excluded_text  = esc_textarea( implode( "\n", $excluded_paths ) );
				?>
			<div class="nvoos-dh-remote-repo-row" style="border:1px solid #ccd0d4; border-radius:4px; padding:12px; margin-bottom:10px; background:#fafafa;">
				<table class="widefat" style="background:transparent; border:none;">
					<tr>
						<td style="width:110px; font-weight:600; padding:4px 8px 4px 0;"><?php esc_html_e( 'Owner *', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<input type="text"
								name="<?php echo esc_attr( "{$option_key}[remote_repos][{$i}][owner]" ); ?>"
								value="<?php echo $owner; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already esc_attr'd ?>"
								placeholder="e.g. nvdigitalsolutions"
								class="regular-text" required />
						</td>
					</tr>
					<tr>
						<td style="font-weight:600; padding:4px 8px 4px 0;"><?php esc_html_e( 'Repository *', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<input type="text"
								name="<?php echo esc_attr( "{$option_key}[remote_repos][{$i}][repo]" ); ?>"
								value="<?php echo $repo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already esc_attr'd ?>"
								placeholder="e.g. mcp-ai-wpoos"
								class="regular-text" required />
						</td>
					</tr>
					<tr>
						<td style="padding:4px 8px 4px 0;"><?php esc_html_e( 'Branch / Tag', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<input type="text"
								name="<?php echo esc_attr( "{$option_key}[remote_repos][{$i}][ref]" ); ?>"
								value="<?php echo $ref; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already esc_attr'd ?>"
								placeholder="HEAD"
								class="regular-text" />
							<p class="description"><?php esc_html_e( 'Branch name, tag, or commit SHA. Default: HEAD (latest commit on default branch).', 'nvoos-docs-hub' ); ?></p>
						</td>
					</tr>
					<tr>
						<td style="padding:4px 8px 4px 0;"><?php esc_html_e( 'Label', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<input type="text"
								name="<?php echo esc_attr( "{$option_key}[remote_repos][{$i}][label]" ); ?>"
								value="<?php echo $label; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already esc_attr'd ?>"
								placeholder="<?php esc_attr_e( 'e.g. My Plugin Docs', 'nvoos-docs-hub' ); ?>"
								class="regular-text" />
							<p class="description"><?php esc_html_e( 'Human-readable name shown in the sidebar.', 'nvoos-docs-hub' ); ?></p>
						</td>
					</tr>
					<tr>
						<td style="padding:4px 8px 4px 0;"><?php esc_html_e( 'Path prefix', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<input type="text"
								name="<?php echo esc_attr( "{$option_key}[remote_repos][{$i}][path]" ); ?>"
								value="<?php echo $path; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already esc_attr'd ?>"
								placeholder="e.g. docs"
								class="regular-text" />
							<p class="description"><?php esc_html_e( 'Optional: restrict to a subdirectory (e.g. "docs"). Leave blank to index the whole repo.', 'nvoos-docs-hub' ); ?></p>
						</td>
					</tr>
					<tr>
						<td style="padding:4px 8px 4px 0;"><?php esc_html_e( 'Access Token', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<input type="password"
								name="<?php echo esc_attr( "{$option_key}[remote_repos][{$i}][token]" ); ?>"
								value=""
								placeholder="<?php echo $has_token ? esc_attr__( '(saved — enter new value to change)', 'nvoos-docs-hub' ) : esc_attr__( 'Optional GitHub PAT', 'nvoos-docs-hub' ); ?>"
								class="regular-text"
								autocomplete="new-password" />
							<p class="description">
								<?php esc_html_e( 'Optional GitHub Personal Access Token. Raises the rate limit from 60 to 5000 req/hr. Required for private repositories.', 'nvoos-docs-hub' ); ?>
							</p>
						</td>
					</tr>
					<tr>
						<td style="padding:4px 8px 4px 0; vertical-align:top;"><?php esc_html_e( 'File selection', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<?php $name_mode = "{$option_key}[remote_repos][{$i}][selection_mode]"; ?>
							<label style="display:block; margin-bottom:4px;">
								<input type="radio"
									name="<?php echo esc_attr( $name_mode ); ?>"
									value="all"
									<?php checked( $selection_mode, 'all' ); ?> />
								<?php esc_html_e( 'All Markdown / .txt files', 'nvoos-docs-hub' ); ?>
								<span class="description"><?php esc_html_e( '— index everything (with optional excludes below).', 'nvoos-docs-hub' ); ?></span>
							</label>
							<label style="display:block; margin-bottom:4px;">
								<input type="radio"
									name="<?php echo esc_attr( $name_mode ); ?>"
									value="prefix"
									<?php checked( $selection_mode, 'prefix' ); ?> />
								<?php esc_html_e( 'Path prefix only', 'nvoos-docs-hub' ); ?>
								<span class="description"><?php esc_html_e( '— restrict to the "Path prefix" field above.', 'nvoos-docs-hub' ); ?></span>
							</label>
							<label style="display:block; margin-bottom:4px;">
								<input type="radio"
									name="<?php echo esc_attr( $name_mode ); ?>"
									value="selected"
									<?php checked( $selection_mode, 'selected' ); ?> />
								<?php esc_html_e( 'Selected files / folders only', 'nvoos-docs-hub' ); ?>
								<span class="description"><?php esc_html_e( '— pick exactly which files to index.', 'nvoos-docs-hub' ); ?></span>
							</label>
						</td>
					</tr>
					<tr class="nvoos-dh-picker-row">
						<td style="padding:4px 8px 4px 0; vertical-align:top;"><?php esc_html_e( 'Browse files', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<button type="button"
								class="button nvoos-dh-browse-btn"
								data-row-index="<?php echo esc_attr( (string) $i ); ?>">
								<?php esc_html_e( 'Browse files in repo…', 'nvoos-docs-hub' ); ?>
							</button>
							<button type="button"
								class="button nvoos-dh-refresh-btn"
								data-row-index="<?php echo esc_attr( (string) $i ); ?>"
								title="<?php esc_attr_e( 'Bypass the 10-minute cache and re-fetch from GitHub', 'nvoos-docs-hub' ); ?>">
								<?php esc_html_e( 'Refresh', 'nvoos-docs-hub' ); ?>
							</button>
							<button type="button"
								class="button nvoos-dh-test-btn"
								data-row-index="<?php echo esc_attr( (string) $i ); ?>"
								title="<?php esc_attr_e( 'Verify the owner, repo, and ref are reachable without saving', 'nvoos-docs-hub' ); ?>">
								<?php esc_html_e( 'Test', 'nvoos-docs-hub' ); ?>
							</button>
							<span class="nvoos-dh-picker-status" style="margin-left:8px; color:#646970; font-style:italic;"></span>
							<div class="nvoos-dh-picker-tree"
								style="display:none; margin-top:8px; max-height:340px; overflow:auto; padding:8px; border:1px solid #ccd0d4; border-radius:4px; background:#fff;">
							</div>
							<p class="description" style="margin-top:6px;">
								<?php esc_html_e( 'Tree results are cached for 10 minutes. Click "Refresh" to bypass the cache.', 'nvoos-docs-hub' ); ?>
							</p>
						</td>
					</tr>
					<tr>
						<td style="padding:4px 8px 4px 0; vertical-align:top;"><?php esc_html_e( 'Selected paths', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<textarea
								name="<?php echo esc_attr( "{$option_key}[remote_repos][{$i}][selected_paths]" ); ?>"
								class="large-text code nvoos-dh-selected-paths"
								rows="4"
								placeholder="docs/intro.md&#10;guides/&#10;README.md"><?php echo $selected_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already esc_textarea'd ?></textarea>
							<p class="description">
								<?php esc_html_e( 'One repo-relative path per line. Trailing "/" includes everything beneath that directory. Used only when "Selected files / folders only" is chosen above.', 'nvoos-docs-hub' ); ?>
							</p>
						</td>
					</tr>
					<tr>
						<td style="padding:4px 8px 4px 0; vertical-align:top;"><?php esc_html_e( 'Excluded paths', 'nvoos-docs-hub' ); ?></td>
						<td style="padding:4px 0;">
							<textarea
								name="<?php echo esc_attr( "{$option_key}[remote_repos][{$i}][excluded_paths]" ); ?>"
								class="large-text code"
								rows="3"
								placeholder="docs/internal/&#10;CHANGELOG.md"><?php echo $excluded_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already esc_textarea'd ?></textarea>
							<p class="description">
								<?php esc_html_e( 'Optional. One repo-relative path per line. Always applied — useful with "All Markdown / .txt files" mode.', 'nvoos-docs-hub' ); ?>
							</p>
						</td>
					</tr>
					<tr>
						<td></td>
						<td style="padding:4px 0;">
							<button type="button" class="button nvoos-dh-remove-repo" style="color:#a00;">
								<?php esc_html_e( '✕ Remove this repository', 'nvoos-docs-hub' ); ?>
							</button>
						</td>
					</tr>
				</table>
			</div>
				<?php
		endforeach;
		} catch ( \Throwable $e ) {
			echo '<div class="notice notice-error inline" style="margin:10px 0;"><p>';
			echo esc_html(
				sprintf(
					/* translators: %s: error message */
					__( 'Error rendering remote repository settings: %s', 'nvoos-docs-hub' ),
					$e->getMessage()
				)
			);
			echo '</p></div>';
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- intentional diagnostic
			error_log(
				sprintf(
					'[NV oOS Docs Hub] render_remote_repos fatal: %s in %s:%d',
					$e->getMessage(),
					$e->getFile(),
					$e->getLine()
				)
			);
		}

		echo '</div><!-- #nvoos-dh-remote-repos-wrap -->';
		echo '<p>';
		echo '<button type="button" id="nvoos-dh-add-repo" class="button">' . esc_html__( '+ Add Repository', 'nvoos-docs-hub' ) . '</button>';
		echo '</p>';
		echo '<p class="description">';
		esc_html_e(
			'Fetched files are cached for 24 hours. Click "Rebuild Documentation Index" after adding or removing repos to refresh immediately.',
			'nvoos-docs-hub'
		);
		echo '</p>';

		// The repo-picker script is enqueued and localized in enqueue_admin_assets().
	}
}

// Initialize.
NV_oOS_Docs_Hub_Settings::init();
