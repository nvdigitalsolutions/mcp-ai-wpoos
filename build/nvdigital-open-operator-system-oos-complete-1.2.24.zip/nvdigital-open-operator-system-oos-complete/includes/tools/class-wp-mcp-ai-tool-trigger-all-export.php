<?php
/**
 * Tool for triggering WP All Export.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent parse errors on PHP < 8.1 by exiting before class definition.
if ( version_compare( PHP_VERSION, '8.1.0', '<' ) ) {
	return;
}

/**
 * Triggers a WP All Export template to execute.
 */
class WP_MCP_AI_Tool_Trigger_All_Export implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * Determine whether WP All Export is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return class_exists( 'PMXE_Plugin' ) || defined( 'PMXE_VERSION' );
	}

	/**
	 * Message explaining why the tool is unavailable.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'The WP All Export tool is disabled because WP All Export plugin is not active.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'trigger_all_export';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Trigger WP All Export', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Triggers a WP All Export template to execute and generate export file. Requires WP All Export plugin.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Kicking off an existing WP All Export template by ID and getting back the generated export file path and URL.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Importing data; use trigger_all_import for WP All Import templates instead.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'trigger_all_import' ),
			'notes'           => __( 'Requires the WP All Export plugin and manage_options; export_id must reference a pmxe_exports post.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'export_id' => array(
					'type'        => 'integer',
					'description' => __( 'The ID of the export template to trigger.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 1,
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
				),
			),
			'required'             => array( 'export_id' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! self::is_available() ) {
			return new WP_Error( 'wp_mcp_ai_all_export_missing', __( 'WP All Export is not active on this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You must be logged in to trigger exports.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to trigger exports.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( empty( $arguments['export_id'] ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_param', __( 'Export ID is required.', 'nvdigital-open-operator-system-oos' ) );
		}

		$export_id = absint( $arguments['export_id'] );

		// Verify export exists.
		$export = get_post( $export_id );
		if ( ! $export || 'pmxe_exports' !== $export->post_type ) {
			return new WP_Error( 'wp_mcp_ai_invalid_export', __( 'Invalid export ID.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Check if PMXE_Export_Record class exists.
		if ( ! class_exists( 'PMXE_Export_Record' ) ) {
			return new WP_Error( 'wp_mcp_ai_class_missing', __( 'PMXE_Export_Record class not found. WP All Export may not be properly installed.', 'nvdigital-open-operator-system-oos' ) );
		}

		// Load and trigger the export using PMXE API.
		try {
			$export_record = new PMXE_Export_Record();
			$export_record->getById( $export_id );

			if ( ! $export_record->id ) {
				return new WP_Error( 'wp_mcp_ai_export_not_found', __( 'Export record not found.', 'nvdigital-open-operator-system-oos' ) );
			}

			// Trigger the export process.
			$export_record->process();
			$export_record->execute();

			$file_path = $export_record->options['current_filepath'] ?? '';
			$file_url  = '';

			if ( $file_path && file_exists( $file_path ) ) {
				$upload_dir = wp_upload_dir();
				$file_url   = str_replace( $upload_dir['basedir'], $upload_dir['baseurl'], $file_path );
			}

			return array(
				'success'     => true,
				'message'     => __( 'Export triggered successfully.', 'nvdigital-open-operator-system-oos' ),
				'export_id'   => $export_id,
				'export_name' => $export->post_title,
				'file_path'   => $file_path,
				'file_url'    => $file_url,
			);

		} catch ( Exception $e ) {
			return new WP_Error(
				'wp_mcp_ai_export_failed',
				sprintf(
					/* translators: %s: error message */
					__( 'Export failed: %s', 'nvdigital-open-operator-system-oos' ),
					$e->getMessage()
				)
			);
		}
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'workflow_automation',

			'pattern_compatibility' => array( 'hierarchical' ),

			'profession_tags'       => array( 'systems_administrator', 'data_engineer' ),

			'risk_level'            => 'standard',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'requires-plugin',     // Requires WP All Export plugin.
			'state-changing',      // Modifies state by generating export files.
			'local-only',          // No external API calls.
			'requires-capability', // Requires 'manage_options' capability.
		);
	}
}
