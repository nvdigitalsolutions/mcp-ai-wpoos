<?php
/**
 * Chat Client Settings Section
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Section_Chat_Client' ) ) {
	/**
	 * Chat Client settings section.
	 */
	class WP_MCP_AI_Section_Chat_Client extends WP_MCP_AI_Settings_Section {
		/**
		 * Get section ID.
		 *
		 * @return string
		 */
		public function get_id() {
			return 'chat_client';
		}

		/**
		 * Get section title.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Chat Client', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * Get tab ID.
		 *
		 * @return string
		 */
		public function get_tab() {
			return 'general';
		}

		/**
		 * Get section priority.
		 *
		 * @return int
		 */
		public function get_priority() {
			return 15;
		}

		/**
		 * Get section description.
		 *
		 * @return string
		 */
		public function get_description() {
			return __( 'Configure chat interface settings, behavior, and features for the frontend chat client.', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * Get documentation URL for this section.
		 *
		 * @return string
		 */
		public function get_documentation_url() {
			return 'https://github.com/nvdigitalsolutions/mcp-ai-wpoos/blob/main/docs/user-guides/chat/chat-client-settings.md';
		}

		/**
		 * Build a list of published assistants for use in select dropdowns.
		 *
		 * @return array<int, string> Assistant ID => title pairs, keyed with 0 as "None".
		 */
		private function get_assistant_options() {
			$options = array(
				0 => __( 'None (use default)', 'nvdigital-open-operator-system-oos' ),
			);

			$assistants = get_posts(
				array(
					'post_type'      => 'mcp_ai_assistant',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'orderby'        => 'title',
					'order'          => 'ASC',
				)
			);

			if ( ! empty( $assistants ) ) {
				foreach ( $assistants as $assistant ) {
					$options[ $assistant->ID ] = $assistant->post_title;
				}
			}

			return $options;
		}

		/**
		 * Get field definitions.
		 *
		 * @return array
		 */
		public function get_fields() {
			return array(
				// Settings subtab fields.
				'chat_theme'                        => array(
					'type'        => 'select',
					'label'       => __( 'Chat Theme', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Select the visual theme for the chat interface.', 'nvdigital-open-operator-system-oos' ),
					'options'     => array(
						'light' => __( 'Light', 'nvdigital-open-operator-system-oos' ),
						'dark'  => __( 'Dark', 'nvdigital-open-operator-system-oos' ),
						'auto'  => __( 'Auto (System Preference)', 'nvdigital-open-operator-system-oos' ),
					),
					'default'     => 'light',
				),
				'chat_primary_color'                => array(
					'type'        => 'text',
					'label'       => __( 'Primary Color', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'HEX color code for primary UI elements (e.g., #0073aa). Leave empty for default.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => '#0073aa',
				),
				'chat_user_bubble_color'            => array(
					'type'        => 'text',
					'label'       => __( 'User Message Bubble Color', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'HEX color code for user message bubbles. Leave empty for default.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => '#E3F2FD',
				),
				'chat_assistant_bubble_color'       => array(
					'type'        => 'text',
					'label'       => __( 'Assistant Message Bubble Color', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'HEX color code for assistant message bubbles. Leave empty for default.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => '#F5F5F5',
				),
				'chat_border_radius'                => array(
					'type'        => 'number',
					'label'       => __( 'Border Radius (px)', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Border radius for chat bubbles in pixels. Higher values create more rounded corners.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 12,
					'placeholder' => '12',
					'min'         => 0,
					'max'         => 50,
				),
				'chat_font_size'                    => array(
					'type'        => 'number',
					'label'       => __( 'Font Size (px)', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Base font size for chat messages in pixels. Leave empty for default (14px).', 'nvdigital-open-operator-system-oos' ),
					'default'     => 14,
					'placeholder' => '14',
					'min'         => 10,
					'max'         => 24,
				),
				'chat_show_timestamps'              => array(
					'type'           => 'checkbox',
					'label'          => __( 'Show Timestamps', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Display timestamps on messages', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Shows the time each message was sent below the message bubble.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_show_avatars'                 => array(
					'type'           => 'checkbox',
					'label'          => __( 'Show Avatars', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Display user and assistant avatars', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Shows avatar images next to messages in the chat interface.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_compact_mode'                 => array(
					'type'           => 'checkbox',
					'label'          => __( 'Compact Mode', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Use compact message spacing', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Reduces spacing between messages for a more condensed view.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'chat_colors'                       => array(
					'type'    => 'html',
					'content' => $this->get_chat_colors_html(),
				),
				// Behavior subtab fields.
				'chat_max_history_display'          => array(
					'type'        => 'number',
					'label'       => __( 'Max History Messages to Display', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Maximum number of messages to display in the chat history. Older messages will be collapsed.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 50,
					'placeholder' => '50',
					'min'         => 10,
					'max'         => 200,
				),
				'chat_message_delay'                => array(
					'type'        => 'number',
					'label'       => __( 'Message Animation Delay (ms)', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Delay in milliseconds for message appearance animation. Set to 0 to disable.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 300,
					'placeholder' => '300',
					'min'         => 0,
					'max'         => 2000,
				),
				'chat_enable_typing_indicator'      => array(
					'type'           => 'checkbox',
					'label'          => __( 'Typing Indicator', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Show typing indicator while assistant is responding', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Displays animated "..." indicator when the assistant is processing a response.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_auto_scroll'                  => array(
					'type'           => 'checkbox',
					'label'          => __( 'Auto-Scroll', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Automatically scroll to newest messages', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Automatically scrolls the chat window to show the latest message when new messages arrive.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_markdown'              => array(
					'type'           => 'checkbox',
					'label'          => __( 'Markdown Rendering', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable markdown formatting in messages', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Allows rendering of markdown syntax (bold, italic, links, code blocks) in messages.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_code_highlighting'     => array(
					'type'           => 'checkbox',
					'label'          => __( 'Code Syntax Highlighting', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable syntax highlighting for code blocks', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Applies syntax highlighting to code blocks in messages for better readability.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_persist_history'              => array(
					'type'           => 'checkbox',
					'label'          => __( 'Persist Chat History', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Save chat history to browser localStorage', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Automatically saves conversation history locally so users can resume their chats. History expires after 24 hours.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_welcome_message'              => array(
					'type'        => 'textarea',
					'label'       => __( 'Welcome Message', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Initial message displayed when chat loads. Leave empty to disable welcome message.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Hello! How can I help you today?', 'nvdigital-open-operator-system-oos' ),
					'rows'        => 3,
				),
				'chat_placeholder_text'             => array(
					'type'        => 'text',
					'label'       => __( 'Input Placeholder Text', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Placeholder text shown in the message input field.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Type your message...', 'nvdigital-open-operator-system-oos' ),
				),
				'chat_send_button_text'             => array(
					'type'        => 'text',
					'label'       => __( 'Send Button Text', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Text shown on the send button. Leave empty to use icon only.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Send', 'nvdigital-open-operator-system-oos' ),
				),
				'show_usage_costs'                  => array(
					'type'           => 'checkbox',
					'label'          => __( 'Show Usage Costs', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Display token usage and estimated costs in chat interface', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Shows small badges with total tokens and estimated cost (in USD) after each assistant response in the frontend chat. Helps users understand API usage and costs in real-time. Phase 7: Enhanced Token Tracking with Real-Time Cost Attribution.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'show_capability_flags'             => array(
					'type'           => 'checkbox',
					'label'          => __( 'Show Capability Flags', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Display tool capability flags in chat interface', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Shows badges indicating tool capabilities (e.g., "read-only", "external-api", "write", "local-only") after messages that use tools. Helps users understand what operations tools can perform.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				// Features subtab fields.
				'chat_enable_copy_button'           => array(
					'type'           => 'checkbox',
					'label'          => __( 'Copy Button', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable copy-to-clipboard button for messages', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Adds a copy button to each message, allowing users to copy message content to their clipboard.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_save_button'           => array(
					'type'           => 'checkbox',
					'label'          => __( 'Save Button', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable save button for individual messages', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Allows users to save individual messages to their local storage for later reference.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_delete_button'         => array(
					'type'           => 'checkbox',
					'label'          => __( 'Delete Button', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable delete button for messages', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Allows users to delete messages from their chat history.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_speech_button'         => array(
					'type'           => 'checkbox',
					'label'          => __( 'Text-to-Speech Button', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable text-to-speech audio playback for messages', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Adds a speech button to messages, allowing users to listen to assistant responses. Requires OpenAI TTS tool to be enabled.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_transcribe_button'     => array(
					'type'           => 'checkbox',
					'label'          => __( 'Voice Input (Transcription)', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable voice-to-text transcription for user input', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Allows users to record voice messages that are transcribed to text. Requires OpenAI Whisper tool to be enabled.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_file_upload'           => array(
					'type'           => 'checkbox',
					'label'          => __( 'File Upload', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable file attachment uploads in chat', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Allows users to upload files (images, documents) as attachments to their messages.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_tool_shortcuts'        => array(
					'type'           => 'checkbox',
					'label'          => __( 'Tool Shortcuts', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable quick access tool shortcut buttons', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Displays quick access buttons for frequently used tools in the chat interface.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_search'                => array(
					'type'           => 'checkbox',
					'label'          => __( 'Message Search', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable search functionality for chat history', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Allows users to search through their chat history to find specific messages or topics.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_export'                => array(
					'type'           => 'checkbox',
					'label'          => __( 'Export Conversation', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable export conversation to text/PDF', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Allows users to export their conversation history to a downloadable file.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_enable_regenerate'            => array(
					'type'           => 'checkbox',
					'label'          => __( 'Regenerate Response', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable regenerate button for assistant responses', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Allows users to request a new response from the assistant for the same query.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_allowed_file_types'           => array(
					'type'        => 'text',
					'label'       => __( 'Allowed File Types', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Comma-separated list of allowed file extensions (e.g., jpg,png,pdf,docx). Leave empty for default allowed types.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => 'jpg,png,pdf,docx',
				),
				'chat_max_file_size_mb'             => array(
					'type'        => 'number',
					'label'       => __( 'Max File Size (MB)', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Maximum file size for uploads in megabytes. Set to 0 to use server default.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 10,
					'placeholder' => '10',
					'min'         => 0,
					'max'         => 100,
				),
				'chat_inline_image_optimization'    => array(
					'type'           => 'checkbox',
					'label'          => __( 'Inline Image Optimization', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Downscale and compress images before sending them to AI providers', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Images attached in chat and via document tools are sent to the provider as inline data (never a URL to download). When enabled, oversized JPEG/PNG images are downscaled to 2048px and opaque PNGs are re-encoded as JPEG so requests stay lean and vision token costs stay low. Transparent PNGs, animated GIFs, and WebP are left untouched; your original uploads are never modified.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				// Presets subtab (no form fields, handled via custom rendering).
				'chat_preset_applied'               => array(
					'type'    => 'hidden',
					'label'   => '',
					'default' => '',
				),
				// LLM Sanitization subtab fields.
				'chat_llm_sanitize_level'           => array(
					'type'        => 'select',
					'label'       => __( 'LLM Response Sanitization Level', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Controls how strictly LLM responses are sanitized before display in the chat client.', 'nvdigital-open-operator-system-oos' ),
					'options'     => array(
						'none'     => __( 'None - Display raw LLM output', 'nvdigital-open-operator-system-oos' ),
						'basic'    => __( 'Basic - Strip harmful HTML/JavaScript', 'nvdigital-open-operator-system-oos' ),
						'moderate' => __( 'Moderate - Allow safe HTML, strip scripts and iframes', 'nvdigital-open-operator-system-oos' ),
						'strict'   => __( 'Strict - Convert all HTML to plain text', 'nvdigital-open-operator-system-oos' ),
					),
					'default'     => 'moderate',
				),
				'chat_llm_max_response_length'      => array(
					'type'        => 'number',
					'label'       => __( 'Max Response Length (characters)', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Maximum number of characters to display in a single LLM response. Longer responses will be truncated. Set to 0 for unlimited.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 0,
					'placeholder' => '0 (unlimited)',
					'min'         => 0,
					'max'         => 100000,
				),
				'chat_llm_show_3_results_buttons'   => array(
					'type'           => 'checkbox',
					'label'          => __( 'Show 3 Result Buttons', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Display 3 alternative result action buttons in chat client', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, shows 3 action buttons (e.g., Refine, Alternative, Expand) for each assistant response, allowing users to request variations of the answer.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'chat_llm_result_button_1_label'    => array(
					'type'        => 'text',
					'label'       => __( 'Result Button 1 Label', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Label for the first result action button. Default: "Refine"', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Refine', 'nvdigital-open-operator-system-oos' ),
				),
				'chat_llm_result_button_1_prompt'   => array(
					'type'        => 'textarea',
					'label'       => __( 'Result Button 1 Prompt', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'System prompt sent to LLM when button 1 is clicked. Use {original_response} placeholder for the original message.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Please refine your previous response: {original_response}', 'nvdigital-open-operator-system-oos' ),
				),
				'chat_llm_result_button_2_label'    => array(
					'type'        => 'text',
					'label'       => __( 'Result Button 2 Label', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Label for the second result action button. Default: "Alternative"', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Alternative', 'nvdigital-open-operator-system-oos' ),
				),
				'chat_llm_result_button_2_prompt'   => array(
					'type'        => 'textarea',
					'label'       => __( 'Result Button 2 Prompt', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'System prompt sent to LLM when button 2 is clicked. Use {original_response} placeholder for the original message.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Please provide an alternative approach to: {original_response}', 'nvdigital-open-operator-system-oos' ),
				),
				'chat_llm_result_button_3_label'    => array(
					'type'        => 'text',
					'label'       => __( 'Result Button 3 Label', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Label for the third result action button. Default: "Expand"', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Expand', 'nvdigital-open-operator-system-oos' ),
				),
				'chat_llm_result_button_3_prompt'   => array(
					'type'        => 'textarea',
					'label'       => __( 'Result Button 3 Prompt', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'System prompt sent to LLM when button 3 is clicked. Use {original_response} placeholder for the original message.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Please expand on your previous response with more detail: {original_response}', 'nvdigital-open-operator-system-oos' ),
				),
				// Chat Bubble subtab fields.
				'chat_bubble_enabled'               => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Chat Bubble', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Display a floating chat bubble on all pages', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, a floating chat bubble will appear on every public page of your site, allowing visitors to open an AI chat panel. No widget or block placement is required.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'chat_bubble_assistant_id'          => array(
					'type'        => 'select',
					'label'       => __( 'Chat Bubble Assistant', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'The assistant to use for the chat bubble. Select "None (use default)" to fall back to the Default Assistant configured in General → Core Settings.', 'nvdigital-open-operator-system-oos' ),
					'options'     => $this->get_assistant_options(),
					'default'     => 0,
				),
				'chat_bubble_allow_guests'          => array(
					'type'           => 'checkbox',
					'label'          => __( 'Allow Guests', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Allow non-logged-in visitors to use the chat bubble', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, visitors who are not logged in can still use the chat bubble.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'chat_bubble_save_transcript'       => array(
					'type'           => 'checkbox',
					'label'          => __( 'Save Transcript', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Save chat transcripts server-side', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, chat conversations will be saved server-side for later review.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_bubble_enable_streaming'      => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Streaming', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Stream assistant responses in real-time', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, responses will appear word-by-word as they are generated.', 'nvdigital-open-operator-system-oos' ),
					'default'        => true,
				),
				'chat_bubble_allow_sensitive_tools' => array(
					'type'           => 'checkbox',
					'label'          => __( 'Allow Sensitive Tools', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Allow the assistant to use sensitive/write tools via the bubble', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, the assistant may use tools that modify data. Disable for a read-only experience.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'chat_bubble_template'              => array(
					'type'        => 'select',
					'label'       => __( 'Chat Template', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Select the visual template for the chat interface inside the bubble panel.', 'nvdigital-open-operator-system-oos' ),
					'options'     => array(
						'compact'        => __( 'Compact', 'nvdigital-open-operator-system-oos' ),
						'classic'        => __( 'Classic', 'nvdigital-open-operator-system-oos' ),
						'speech-bubbles' => __( 'Speech Bubbles', 'nvdigital-open-operator-system-oos' ),
						'sidebar'        => __( 'Sidebar', 'nvdigital-open-operator-system-oos' ),
					),
					'default'     => 'compact',
				),
				'chat_bubble_position'              => array(
					'type'        => 'select',
					'label'       => __( 'Bubble Position', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Where the floating chat bubble appears on the screen.', 'nvdigital-open-operator-system-oos' ),
					'options'     => array(
						'bottom-right' => __( 'Bottom Right', 'nvdigital-open-operator-system-oos' ),
						'bottom-left'  => __( 'Bottom Left', 'nvdigital-open-operator-system-oos' ),
						'top-right'    => __( 'Top Right', 'nvdigital-open-operator-system-oos' ),
						'top-left'     => __( 'Top Left', 'nvdigital-open-operator-system-oos' ),
					),
					'default'     => 'bottom-right',
				),
				'chat_bubble_size'                  => array(
					'type'        => 'select',
					'label'       => __( 'Bubble Size', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Size of the floating chat bubble trigger button.', 'nvdigital-open-operator-system-oos' ),
					'options'     => array(
						'small'  => __( 'Small', 'nvdigital-open-operator-system-oos' ),
						'medium' => __( 'Medium', 'nvdigital-open-operator-system-oos' ),
						'large'  => __( 'Large', 'nvdigital-open-operator-system-oos' ),
					),
					'default'     => 'medium',
				),
				'chat_bubble_animation'             => array(
					'type'        => 'select',
					'label'       => __( 'Bubble Animation', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Animation effect for the chat bubble trigger button.', 'nvdigital-open-operator-system-oos' ),
					'options'     => array(
						'bounce' => __( 'Bounce', 'nvdigital-open-operator-system-oos' ),
						'pulse'  => __( 'Pulse', 'nvdigital-open-operator-system-oos' ),
						'none'   => __( 'None', 'nvdigital-open-operator-system-oos' ),
					),
					'default'     => 'bounce',
				),
				'chat_bubble_tooltip'               => array(
					'type'        => 'text',
					'label'       => __( 'Bubble Tooltip', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Tooltip text displayed when hovering over the chat bubble. Leave empty to disable.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( 'Chat with us!', 'nvdigital-open-operator-system-oos' ),
				),
				'chat_bubble_panel_title'           => array(
					'type'        => 'text',
					'label'       => __( 'Panel Title', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Title displayed in the header of the chat panel.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'Chat with AI',
					'placeholder' => __( 'Chat with AI', 'nvdigital-open-operator-system-oos' ),
				),
				'chat_bubble_panel_width'           => array(
					'type'        => 'number',
					'label'       => __( 'Panel Width (px)', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Width of the chat panel in pixels.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 400,
					'placeholder' => '400',
					'min'         => 250,
					'max'         => 800,
				),
				'chat_bubble_panel_height'          => array(
					'type'        => 'number',
					'label'       => __( 'Panel Height (px)', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Height of the chat panel in pixels.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 550,
					'placeholder' => '550',
					'min'         => 300,
					'max'         => 900,
				),
				'chat_bubble_auto_open_delay'       => array(
					'type'        => 'number',
					'label'       => __( 'Auto-Open Delay (seconds)', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Automatically open the chat panel after this many seconds. Set to 0 to disable auto-open.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 0,
					'placeholder' => '0',
					'min'         => 0,
					'max'         => 300,
				),
				'chat_bubble_remember_state'        => array(
					'type'           => 'checkbox',
					'label'          => __( 'Remember State', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Remember whether the chat panel was open or closed', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, the bubble remembers its open/closed state across page navigations using localStorage.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'chat_bubble_notification_badge'    => array(
					'type'           => 'checkbox',
					'label'          => __( 'Notification Badge', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Show a notification badge on the bubble', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Displays a small notification dot on the bubble to attract attention.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'chat_bubble_color'                 => array(
					'type'        => 'text',
					'label'       => __( 'Bubble Color', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Background color of the chat bubble trigger button (HEX).', 'nvdigital-open-operator-system-oos' ),
					'default'     => '#4f46e5',
					'placeholder' => '#4f46e5',
				),
				'chat_bubble_text_color'            => array(
					'type'        => 'text',
					'label'       => __( 'Bubble Text/Icon Color', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Color of the icon and text inside the chat bubble trigger button (HEX).', 'nvdigital-open-operator-system-oos' ),
					'default'     => '#ffffff',
					'placeholder' => '#ffffff',
				),
				'chat_bubble_header_background'     => array(
					'type'        => 'text',
					'label'       => __( 'Panel Header Background', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Background color of the chat panel header (HEX). Leave empty to use bubble color.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => '#4f46e5',
				),
				'chat_bubble_header_text_color'     => array(
					'type'        => 'text',
					'label'       => __( 'Panel Header Text Color', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Text color in the chat panel header (HEX).', 'nvdigital-open-operator-system-oos' ),
					'default'     => '#ffffff',
					'placeholder' => '#ffffff',
				),
				'chat_bubble_exclude_pages'         => array(
					'type'        => 'text',
					'label'       => __( 'Exclude Pages', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Comma-separated list of page/post IDs where the chat bubble should NOT appear. Leave empty to show on all pages.', 'nvdigital-open-operator-system-oos' ),
					'default'     => '',
					'placeholder' => __( '42, 123, 456', 'nvdigital-open-operator-system-oos' ),
				),
			);
		}

		/**
		 * Get sub-tab groups configuration.
		 *
		 * @return array
		 */
		protected function get_subtab_groups() {
			return array(
				'appearance'           => array(
					'id'     => 'appearance',
					'label'  => __( 'Appearance', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-admin-appearance',
					'fields' => array(
						'chat_theme',
						'chat_primary_color',
						'chat_user_bubble_color',
						'chat_assistant_bubble_color',
						'chat_border_radius',
						'chat_font_size',
						'chat_show_timestamps',
						'chat_show_avatars',
						'chat_compact_mode',
						'chat_colors',
					),
				),
				'behavior-chat-client' => array(
					'id'     => 'behavior-chat-client',
					'label'  => __( 'Behavior', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-performance',
					'fields' => array(
						'chat_max_history_display',
						'chat_message_delay',
						'chat_enable_typing_indicator',
						'chat_auto_scroll',
						'chat_enable_markdown',
						'chat_enable_code_highlighting',
						'chat_persist_history',
						'chat_welcome_message',
						'chat_placeholder_text',
						'chat_send_button_text',
						'show_usage_costs',
						'show_capability_flags',
					),
				),
				'features'             => array(
					'id'     => 'features',
					'label'  => __( 'Features', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-admin-tools',
					'fields' => array(
						'chat_enable_copy_button',
						'chat_enable_save_button',
						'chat_enable_delete_button',
						'chat_enable_speech_button',
						'chat_enable_transcribe_button',
						'chat_enable_file_upload',
						'chat_enable_tool_shortcuts',
						'chat_enable_search',
						'chat_enable_export',
						'chat_enable_regenerate',
						'chat_allowed_file_types',
						'chat_max_file_size_mb',
						'chat_inline_image_optimization',
					),
				),
				'llm_sanitization'     => array(
					'id'     => 'llm_sanitization',
					'label'  => __( 'LLM Sanitization', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-shield',
					'fields' => array(
						'chat_llm_sanitize_level',
						'chat_llm_max_response_length',
						'chat_llm_show_3_results_buttons',
						'chat_llm_result_button_1_label',
						'chat_llm_result_button_1_prompt',
						'chat_llm_result_button_2_label',
						'chat_llm_result_button_2_prompt',
						'chat_llm_result_button_3_label',
						'chat_llm_result_button_3_prompt',
					),
				),
				'chat_bubble'          => array(
					'id'          => 'chat_bubble',
					'label'       => __( 'Chat Bubble', 'nvdigital-open-operator-system-oos' ),
					'icon'        => 'dashicons-format-status',
					'description' => __( 'Enable a global floating chat bubble on your site. When enabled, the bubble appears on every page without needing to add a widget or block to your theme.', 'nvdigital-open-operator-system-oos' ),
					'fields'      => array(
						'chat_bubble_enabled',
						'chat_bubble_assistant_id',
						'chat_bubble_allow_guests',
						'chat_bubble_save_transcript',
						'chat_bubble_enable_streaming',
						'chat_bubble_allow_sensitive_tools',
						'chat_bubble_template',
						'chat_bubble_position',
						'chat_bubble_size',
						'chat_bubble_animation',
						'chat_bubble_tooltip',
						'chat_bubble_panel_title',
						'chat_bubble_panel_width',
						'chat_bubble_panel_height',
						'chat_bubble_auto_open_delay',
						'chat_bubble_remember_state',
						'chat_bubble_notification_badge',
						'chat_bubble_color',
						'chat_bubble_text_color',
						'chat_bubble_header_background',
						'chat_bubble_header_text_color',
						'chat_bubble_exclude_pages',
					),
				),
				'presets'              => array(
					'id'     => 'presets',
					'label'  => __( 'Presets', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-list-view',
					'fields' => array(), // No form fields, custom rendering.
				),
			);
		}

		/**
		 * Get active sub-tab.
		 *
		 * @return string
		 */
		protected function get_active_subtab() {
			$subtab_groups = $this->get_subtab_groups();
			$subtab        = '';

			// Check POST data first (when form is being submitted), then fall back to GET.
			// Use section-specific field name to avoid conflicts with other sections.
			// phpcs:disable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only parameter check for UI state.
			$subtab_field_name = 'subtab_' . $this->get_id();
			if ( isset( $_POST[ $subtab_field_name ] ) ) {
				$subtab = sanitize_key( wp_unslash( $_POST[ $subtab_field_name ] ) );
			} elseif ( isset( $_POST['subtab'] ) ) {
				// Fallback to legacy field name for backward compatibility.
				$subtab = sanitize_key( wp_unslash( $_POST['subtab'] ) );
			} elseif ( isset( $_GET['subtab'] ) ) {
				$subtab = sanitize_key( wp_unslash( $_GET['subtab'] ) );
			}
			// phpcs:enable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended

			// Default to 'appearance' if not set or invalid.
			if ( empty( $subtab ) || ! isset( $subtab_groups[ $subtab ] ) ) {
				$subtab = 'appearance';
			}

			return $subtab;
		}

		/**
		 * Render section fields.
		 */
		public function render() {
			$fields        = $this->get_fields();
			$subtab_groups = $this->get_subtab_groups();
			$active_subtab = $this->get_active_subtab();

			// Get the active group.
			if ( ! isset( $subtab_groups[ $active_subtab ] ) ) {
				return;
			}

			$active_group = $subtab_groups[ $active_subtab ];

			// Render fields for the active sub-tab.
			foreach ( $active_group['fields'] as $key ) {
				if ( isset( $fields[ $key ] ) ) {
					$this->render_field( $key, $fields[ $key ] );
				}
			}

			// Render presets UI if we're on the presets sub-tab.
			if ( 'presets' === $active_subtab ) {
				echo '</table>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Close the form table.
				$this->render_presets_ui();
				echo '<table class="form-table" role="presentation" style="display:none;">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag, Re-open hidden table for structure.
			}
		}

		/**
		 * Render the presets UI.
		 */
		private function render_presets_ui() {
			?>
			<div class="wp-mcp-ai-chat-presets" style="background: #fff; padding: 20px; border: 1px solid #ccd0d4; border-radius: 4px; margin-top: 20px;">
				<h3><?php esc_html_e( 'Chat Client Presets', 'nvdigital-open-operator-system-oos' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Quickly configure your chat client with pre-designed settings optimized for different use cases.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>

				<div class="wp-mcp-ai-presets-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin-top: 20px;">
					<!-- Minimal Preset -->
					<div class="preset-card" style="border: 1px solid #ddd; border-radius: 4px; padding: 15px;">
						<h4 style="margin-top: 0;">
							<span class="dashicons dashicons-minus" style="color: #0073aa;"></span>
							<?php esc_html_e( 'Minimal', 'nvdigital-open-operator-system-oos' ); ?>
						</h4>
						<p class="description">
							<?php esc_html_e( 'Clean, distraction-free interface with only essential features. Perfect for focused conversations.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
						<ul style="list-style: disc; margin-left: 20px; font-size: 13px;">
							<li><?php esc_html_e( 'Light theme', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Copy button only', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'No file uploads', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Basic markdown', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Moderate sanitization', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
						<button type="button" class="button button-secondary wp-mcp-ai-apply-preset"
							data-preset="minimal" style="margin-top: 10px; width: 100%;">
							<?php esc_html_e( 'Apply Preset', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
					</div>

					<!-- Full-Featured Preset -->
					<div class="preset-card" style="border: 1px solid #ddd; border-radius: 4px; padding: 15px;">
						<h4 style="margin-top: 0;">
							<span class="dashicons dashicons-plus" style="color: #46b450;"></span>
							<?php esc_html_e( 'Full-Featured', 'nvdigital-open-operator-system-oos' ); ?>
						</h4>
						<p class="description">
							<?php esc_html_e( 'All features enabled for maximum functionality. Best for power users and comprehensive interactions.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
						<ul style="list-style: disc; margin-left: 20px; font-size: 13px;">
							<li><?php esc_html_e( 'All features enabled', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'File uploads allowed', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Voice input/output', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Code highlighting', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Export & search', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
						<button type="button" class="button button-secondary wp-mcp-ai-apply-preset"
							data-preset="full_featured" style="margin-top: 10px; width: 100%;">
							<?php esc_html_e( 'Apply Preset', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
					</div>

					<!-- Professional Preset -->
					<div class="preset-card" style="border: 1px solid #ddd; border-radius: 4px; padding: 15px;">
						<h4 style="margin-top: 0;">
							<span class="dashicons dashicons-businessman" style="color: #826eb4;"></span>
							<?php esc_html_e( 'Professional', 'nvdigital-open-operator-system-oos' ); ?>
						</h4>
						<p class="description">
							<?php esc_html_e( 'Business-focused setup with document handling, exports, and strict sanitization for enterprise use.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
						<ul style="list-style: disc; margin-left: 20px; font-size: 13px;">
							<li><?php esc_html_e( 'Light/Dark theme', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'File uploads (docs)', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Export conversations', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Search enabled', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Strict sanitization', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
						<button type="button" class="button button-secondary wp-mcp-ai-apply-preset"
							data-preset="professional" style="margin-top: 10px; width: 100%;">
							<?php esc_html_e( 'Apply Preset', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
					</div>

					<!-- Accessible Preset -->
					<div class="preset-card" style="border: 1px solid #ddd; border-radius: 4px; padding: 15px;">
						<h4 style="margin-top: 0;">
							<span class="dashicons dashicons-universal-access" style="color: #f56e28;"></span>
							<?php esc_html_e( 'Accessible', 'nvdigital-open-operator-system-oos' ); ?>
						</h4>
						<p class="description">
							<?php esc_html_e( 'Optimized for accessibility with larger text, high contrast, and voice features for all users.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
						<ul style="list-style: disc; margin-left: 20px; font-size: 13px;">
							<li><?php esc_html_e( 'Large font size (18px)', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'High contrast colors', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Voice input/output', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Timestamps & avatars', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Clear visual feedback', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
						<button type="button" class="button button-secondary wp-mcp-ai-apply-preset"
							data-preset="accessible" style="margin-top: 10px; width: 100%;">
							<?php esc_html_e( 'Apply Preset', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
					</div>
				</div>

				<div class="wp-mcp-ai-preset-notice" style="background: #f0f6fc; border-left: 4px solid #0073aa; padding: 12px; margin-top: 20px; display: none;">
					<p style="margin: 0;">
						<strong><?php esc_html_e( 'Preset Applied!', 'nvdigital-open-operator-system-oos' ); ?></strong>
						<?php esc_html_e( 'Your settings have been updated. Click "Save Changes" below to apply them.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</div>
			</div>
			<?php
		}

		/**
		 * Override render_wrapper to include sub-tab navigation.
		 */
		public function render_wrapper() {
			$description       = $this->get_description();
			$documentation_url = $this->get_documentation_url();
			$subtab_groups     = $this->get_subtab_groups();
			$active_subtab     = $this->get_active_subtab();
			?>
			<div class="settings-section" id="section-<?php echo esc_attr( $this->get_id() ); ?>">
				<h2><?php echo esc_html( $this->get_title() ); ?></h2>
				<?php if ( $description ) : ?>
					<p class="section-description"><?php echo wp_kses_post( $description ); ?></p>
				<?php endif; ?>
				<?php if ( $documentation_url ) : ?>
					<p class="section-documentation">
						<span class="dashicons dashicons-book-alt" style="color: #2271b1;"></span>
						<a href="<?php echo esc_url( $documentation_url ); ?>" target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'View Documentation', 'nvdigital-open-operator-system-oos' ); ?>
							<span class="dashicons dashicons-external" style="font-size: 14px; text-decoration: none;"></span>
						</a>
					</p>
				<?php endif; ?>

				<div class="wp-mcp-ai-provider-subtabs">
					<nav class="wp-mcp-ai-subtab-nav" aria-label="<?php esc_attr_e( 'Chat client sub-tabs', 'nvdigital-open-operator-system-oos' ); ?>">
						<?php foreach ( $subtab_groups as $group ) : ?>
							<?php
							$subtab_url = add_query_arg(
								array(
									'page'   => 'wp-mcp-ai-dashboard',
									'tab'    => 'general',
									'subtab' => $group['id'],
								),
								admin_url( 'admin.php' )
							);
							$is_active  = ( $group['id'] === $active_subtab );
							?>
							<a href="<?php echo esc_url( $subtab_url ); ?>"
								class="wp-mcp-ai-subtab <?php echo esc_attr( $is_active ? 'wp-mcp-ai-subtab-active' : '' ); ?>"
								data-subtab="<?php echo esc_attr( $group['id'] ); ?>">
								<span class="dashicons <?php echo esc_attr( $group['icon'] ); ?>"></span>
								<?php echo esc_html( $group['label'] ); ?>
							</a>
						<?php endforeach; ?>
					</nav>

					<!-- Hidden field to preserve subtab during form submission -->
					<input type="hidden" name="subtab_<?php echo esc_attr( $this->get_id() ); ?>" value="<?php echo esc_attr( $active_subtab ); ?>" />

					<div class="wp-mcp-ai-subtab-content">
						<table class="form-table" role="presentation">
							<?php $this->render(); ?>
						</table>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Get chat colors HTML content.
		 *
		 * @return string
		 */
		private function get_chat_colors_html() {
			// Delegate to the legacy settings renderer if available.
			if ( class_exists( 'WP_MCP_AI_Admin_Settings' ) && method_exists( 'WP_MCP_AI_Admin_Settings', 'get_chat_color_definitions' ) ) {
				$settings    = WP_MCP_AI_Admin_Settings::get_settings();
				$colors      = isset( $settings['chat_colors'] ) && is_array( $settings['chat_colors'] ) ? $settings['chat_colors'] : WP_MCP_AI_Admin_Settings::get_default_chat_colors();
				$definitions = WP_MCP_AI_Admin_Settings::get_chat_color_definitions();
				$groups      = WP_MCP_AI_Admin_Settings::get_chat_color_groups();

				ob_start();
				echo '<div class="wp-mcp-ai-chat-colors">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
				echo '<p class="description">' . esc_html__( 'Customize the colors used throughout the chat interface. Leave fields empty to use default values.', 'nvdigital-open-operator-system-oos' ) . '</p>';

				foreach ( $groups as $group_key => $group_label ) {
					$group_colors = array();

					foreach ( $definitions as $color_key => $definition ) {
						if ( isset( $definition['group'] ) && $group_key === $definition['group'] ) {
							$group_colors[ $color_key ] = $definition;
						}
					}

					if ( empty( $group_colors ) ) {
						continue;
					}

					echo '<fieldset class="wp-mcp-ai-chat-colors__group">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
					echo '<legend>' . esc_html( $group_label ) . '</legend>';

					foreach ( $group_colors as $color_key => $definition ) {
						$input_id     = 'wp-mcp-ai-color-' . sanitize_html_class( $color_key );
						$value        = isset( $colors[ $color_key ] ) ? $colors[ $color_key ] : $definition['default'];
						$format       = isset( $definition['format'] ) ? strtolower( $definition['format'] ) : 'hex';
						$descriptions = array();

						if ( ! empty( $definition['description'] ) ) {
							$descriptions[] = $definition['description'];
						}

						if ( 'rgba' === $format ) {
							$descriptions[] = __( 'Enter a value in rgba(R, G, B, A) format.', 'nvdigital-open-operator-system-oos' );
						}

						echo '<div class="wp-mcp-ai-chat-colors__field">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
						echo '<label for="' . esc_attr( $input_id ) . '">' . esc_html( $definition['label'] ) . '</label>';
						echo '<input type="text" id="' . esc_attr( $input_id ) . '" class="regular-text wp-mcp-ai-color-field" name="wp_mcp_ai_settings[chat_colors][' . esc_attr( $color_key ) . ']" value="' . esc_attr( $value ) . '" data-format="' . esc_attr( $format ) . '" data-default-color="' . esc_attr( $definition['default'] ) . '" />';

						foreach ( $descriptions as $text ) {
							echo '<p class="description">' . esc_html( $text ) . '</p>';
						}

						echo '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
					}

					echo '</fieldset>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
				}

				echo '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static HTML tag.
				return ob_get_clean();
			}

			return '<div class="notice notice-warning inline"><p>' . esc_html__( 'Chat colors configuration is not available.', 'nvdigital-open-operator-system-oos' ) . '</p></div>';
		}
	}
}
