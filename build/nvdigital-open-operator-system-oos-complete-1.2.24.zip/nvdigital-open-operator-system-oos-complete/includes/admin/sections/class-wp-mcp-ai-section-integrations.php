<?php
/**
 * Integrations Settings Section
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Section_Integrations' ) ) {
	/**
	 * Integrations settings section - External Tools.
	 */
	class WP_MCP_AI_Section_Integrations extends WP_MCP_AI_Settings_Section {
		/**
		 * Get section ID.
		 *
		 * @return string
		 */
		public function get_id() {
			return 'integrations_gmail_crawl4ai';
		}

		/**
		 * Get section title.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'External Tools', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * Get tab ID.
		 *
		 * This section is integrated within the Tools tab under the Connections subtab.
		 *
		 * @return string
		 */
		public function get_tab() {
			return 'tools';
		}

		/**
		 * Get section description.
		 *
		 * @return string
		 */
		public function get_description() {
			return __( 'Configure third-party service integrations including search APIs, email services, cloud platforms, web crawlers, and social media.', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * Get documentation URL for this section.
		 *
		 * @return string
		 */
		public function get_documentation_url() {
			return 'https://github.com/nvdigitalsolutions/mcp-ai-wpoos/blob/main/docs/developer/architecture/integrations/oauth-settings-architecture.md';
		}

		/**
		 * Get section priority.
		 *
		 * @return int
		 */
		public function get_priority() {
			return 20;
		}

		/**
		 * Get field definitions.
		 *
		 * @return array
		 */
		public function get_fields() {
			// Note: Gmail and Drive support 1 connection in base, multiple in pro via Remote Sites.
			$gmail_notice = ' <em>' . __( '(Pro enables multiple connections via Remote Sites)', 'nvdigital-open-operator-system-oos' ) . '</em>';
			$drive_notice = ' <em>' . __( '(Pro enables multiple connections via Remote Sites)', 'nvdigital-open-operator-system-oos' ) . '</em>';

			// Google Calendar shares the same base/Pro cardinality split as Gmail and Drive.
			$calendar_notice = $drive_notice;

			require_once WP_MCP_AI_PATH . 'includes/google/class-wp-mcp-ai-google-calendar-scopes.php';
			require_once WP_MCP_AI_PATH . 'includes/google/class-wp-mcp-ai-google-calendar-credentials.php';

			$calendar_profiles   = WP_MCP_AI_Google_Calendar_Scopes::get_profile_options();
			$calendar_default_tz = WP_MCP_AI_Google_Calendar_Credentials::default_timezone();

			return array(
				// Gmail OAuth.
				'gmail_client_id'                     => array(
					'type'         => 'text',
					'label'        => __( 'Gmail OAuth Client ID', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client ID from Google Cloud Console for Gmail integration.', 'nvdigital-open-operator-system-oos' ) . $gmail_notice,
					'placeholder'  => '',
					'autocomplete' => 'off',
				),
				'gmail_client_secret'                 => array(
					'type'         => 'password',
					'label'        => __( 'Gmail OAuth Client Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client Secret from Google Cloud Console.', 'nvdigital-open-operator-system-oos' ) . $gmail_notice,
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Google Drive OAuth.
				'google_drive_client_id'              => array(
					'type'         => 'text',
					'label'        => __( 'Google Drive OAuth Client ID', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client ID from Google Cloud Console for Google Drive integration.', 'nvdigital-open-operator-system-oos' ) . $drive_notice,
					'placeholder'  => '',
					'autocomplete' => 'off',
				),
				'google_drive_client_secret'          => array(
					'type'         => 'password',
					'label'        => __( 'Google Drive OAuth Client Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client Secret from Google Cloud Console.', 'nvdigital-open-operator-system-oos' ) . $drive_notice,
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Google Calendar OAuth.
				'google_calendar_client_id'           => array(
					'type'         => 'text',
					'label'        => __( 'Google Calendar OAuth Client ID', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client ID from Google Cloud Console for Google Calendar integration.', 'nvdigital-open-operator-system-oos' ) . $calendar_notice,
					'placeholder'  => '',
					'autocomplete' => 'off',
				),
				'google_calendar_client_secret'       => array(
					'type'         => 'password',
					'label'        => __( 'Google Calendar OAuth Client Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OAuth 2.0 Client Secret from Google Cloud Console.', 'nvdigital-open-operator-system-oos' ) . $calendar_notice,
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'google_calendar_scope_profile'       => array(
					'type'        => 'select',
					'label'       => __( 'Permission Level', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Controls which Google Calendar permissions are requested. Changing this clears the existing authorisation — you must reconnect afterwards.', 'nvdigital-open-operator-system-oos' ),
					'options'     => $calendar_profiles,
					'default'     => WP_MCP_AI_Google_Calendar_Scopes::DEFAULT_PROFILE,
				),
				'google_calendar_default_calendar_id' => array(
					'type'         => 'text',
					'label'        => __( 'Default Calendar ID', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Calendar used when a tool does not specify one. Use "primary" for the account\'s main calendar, or paste a calendar ID from Google Calendar settings.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => 'primary',
					'autocomplete' => 'off',
				),
				'google_calendar_timezone'            => array(
					'type'         => 'text',
					'label'        => __( 'Default Time Zone', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'IANA time zone identifier applied to event times, for example "Europe/Zurich". Leave blank to use this site\'s time zone. UTC offsets such as "+02:00" are not accepted by the Calendar API.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => $calendar_default_tz,
					'autocomplete' => 'off',
				),

				// Crawl4AI.
				'crawl4ai_base_url'                   => array(
					'type'         => 'url',
					'label'        => __( 'Crawl4AI Base URL', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Base URL for Crawl4AI service (if using external crawler).', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => 'http://localhost:8000',
					'autocomplete' => 'url',
				),
				'crawl4ai_api_key'                    => array(
					'type'         => 'password',
					'label'        => __( 'Crawl4AI API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'API key for Crawl4AI service (if required).', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Brave Search.
				'brave_search_api_key'                => array(
					'type'         => 'password',
					'label'        => __( 'Brave Search API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to Brave Search API */
						__( 'API key for Brave Search integration. Get your API key from %s.', 'nvdigital-open-operator-system-oos' ),
						'<a href="https://brave.com/search/api/" target="_blank">Brave Search API</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'tavily_api_key'                      => array(
					'type'         => 'password',
					'label'        => __( 'Tavily API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to Tavily */
						__( 'API key for Tavily Search integration (AI-first provider optimised for agent workflows). Get your API key from %s.', 'nvdigital-open-operator-system-oos' ),
						'<a href="https://tavily.com/" target="_blank">tavily.com</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Mubert Music API.
				'mubert_api_key'                      => array(
					'type'         => 'password',
					'label'        => __( 'Mubert API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to Mubert contact */
						__( 'API key for Mubert music generation service. Request an API key from %s.', 'nvdigital-open-operator-system-oos' ),
						'<a href="mailto:business@mubert.com">business@mubert.com</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Cloudflare.
				'cloudflare_api_token'                => array(
					'type'         => 'password',
					'label'        => __( 'Cloudflare API Token', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'API token for Cloudflare integration. Create a token in your Cloudflare dashboard.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'cloudflare_zone_id'                  => array(
					'type'        => 'text',
					'label'       => __( 'Cloudflare Zone ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Cloudflare zone ID for cache management.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'enable_cloudflare_pro_toolkit'       => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Cloudflare Pro Toolkit', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable Cloudflare advanced features and integrations (Pro Version only)', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'Enables AI-powered Cloudflare integration toolkit including cache purging, zone management, DNS operations, and advanced CDN features. Provides additional tools for managing Cloudflare services through AI assistants. Requires Cloudflare API Token and Zone ID to be configured. This feature is only available in the Pro addon.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				// NOTE: enable_cloudflare_pro_toolkit is intentionally kept in the field
				// registry so that previously-saved values are sanitized correctly if the
				// Pro addon is later activated. The UI control is conditionally hidden via
				// get_subtabs() when Pro is not active (see below).

				// Cloudways.
				'cloudways_api_key'                   => array(
					'type'         => 'password',
					'label'        => __( 'Cloudways API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'API key for Cloudways hosting integration.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'cloudways_email'                     => array(
					'type'        => 'email',
					'label'       => __( 'Cloudways Account Email', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Email address associated with your Cloudways account.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => 'you@example.com',
				),
				'cloudways_server_id'                 => array(
					'type'        => 'text',
					'label'       => __( 'Cloudways Server ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Cloudways server identifier for server management operations. Find this in your Cloudways dashboard under Servers.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'cloudways_app_id'                    => array(
					'type'        => 'text',
					'label'       => __( 'Cloudways Application ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Cloudways application identifier for app-specific operations. Find this in your Cloudways dashboard under Applications.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),

				// remove.bg API.
				'removebg_api_key'                    => array(
					'type'         => 'password',
					'label'        => __( 'remove.bg API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to remove.bg API */
						__( 'API key for remove.bg background removal service. Get your API key from %s. Note: A free tier with Python rembg is also available without an API key.', 'nvdigital-open-operator-system-oos' ),
						'<a href="https://www.remove.bg/api" target="_blank">remove.bg API</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// OpenTelemetry (OTLP/HTTP span exporter).
				'otel_endpoint'                       => array(
					'type'         => 'url',
					'label'        => __( 'OTLP/HTTP Endpoint', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'OTLP/HTTP endpoint URL for exporting OpenTelemetry spans (e.g. http://localhost:4318/v1/traces). Leave blank to disable span export. The environment variable WP_MCP_AI_OTEL_ENDPOINT takes precedence when set.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => 'http://localhost:4318/v1/traces',
					'autocomplete' => 'url',
				),
				'otel_token'                          => array(
					'type'         => 'password',
					'label'        => __( 'OTLP Bearer Token', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Optional bearer token sent in the Authorization header with each export request. Leave blank if your collector does not require authentication.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// PayHare, Flowhub, iSAMS, and QuickBooks connections have been moved to Remote Sites.
				// These settings have been removed. Please use Remote Sites page to manage these connections.

				// ITA Tariff Rate API.
				'ita_tariff_api_key'                  => array(
					'type'         => 'password',
					'label'        => __( 'ITA Tariff Rate API Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to ITA API */
						__( 'API key for International Trade Administration Tariff Rate API. Get your API key from %s. Used for import/export tariff information and trade compliance.', 'nvdigital-open-operator-system-oos' ),
						'<a href="https://developer.trade.gov/" target="_blank">Trade.gov Developer Portal</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Meta.
				'meta_access_token'                   => array(
					'type'         => 'password',
					'label'        => __( 'Meta Access Token', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Long-lived access token for Meta Graph API. Used for Facebook, Instagram, and WhatsApp integrations.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'meta_app_id'                         => array(
					'type'        => 'text',
					'label'       => __( 'Meta App ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Meta (Facebook) App ID.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'meta_app_secret'                     => array(
					'type'         => 'password',
					'label'        => __( 'Meta App Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Your Meta (Facebook) App Secret.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'meta_business_account_id'            => array(
					'type'        => 'text',
					'label'       => __( 'Meta Business Account ID', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Your Meta Business Account ID (for WhatsApp Business API).', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'meta_connected_user_name'            => array(
					'type'        => 'hidden',
					'label'       => '',
					'description' => '',
				),
				'meta_connected_user_id'              => array(
					'type'        => 'hidden',
					'label'       => '',
					'description' => '',
				),

				// TikTok.
				'tiktok_access_token'                 => array(
					'type'         => 'password',
					'label'        => __( 'TikTok Access Token', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Access token for TikTok Open API with video.share scope.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),
				'tiktok_client_key'                   => array(
					'type'        => 'text',
					'label'       => __( 'TikTok Client Key', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Client Key from TikTok developer portal.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => '',
				),
				'tiktok_client_secret'                => array(
					'type'         => 'password',
					'label'        => __( 'TikTok Client Secret', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Client Secret from TikTok developer portal.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
				),

				// Plaid (Financial Services).
				'plaid_client_id'                     => array(
					'type'         => 'text',
					'label'        => __( 'Plaid Client ID', 'nvdigital-open-operator-system-oos' ),
					'description'  => sprintf(
						/* translators: %s: URL to Plaid Dashboard */
						__( 'Client ID from Plaid dashboard for financial account integration. Get your credentials from %s. Used for optional bank account sync in Financial Planner Toolkit.', 'nvdigital-open-operator-system-oos' ),
						'<a href="https://dashboard.plaid.com/" target="_blank">Plaid Dashboard</a>'
					),
					'placeholder'  => '',
					'autocomplete' => 'off',
					// Removed pro gating - WordPress.org compliance.
				),
				'plaid_secret'                        => array(
					'type'         => 'password',
					'label'        => __( 'Plaid Secret Key', 'nvdigital-open-operator-system-oos' ),
					'description'  => __( 'Secret key from Plaid dashboard. Keep this secure and never share publicly.', 'nvdigital-open-operator-system-oos' ),
					'placeholder'  => '',
					'autocomplete' => 'new-password',
					// Removed pro gating - WordPress.org compliance.
				),
				'plaid_environment'                   => array(
					'type'        => 'select',
					'label'       => __( 'Plaid Environment', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Select Plaid environment: Sandbox for testing, Development for development, Production for live use.', 'nvdigital-open-operator-system-oos' ),
					'options'     => array(
						'sandbox'     => __( 'Sandbox (Testing)', 'nvdigital-open-operator-system-oos' ),
						'development' => __( 'Development', 'nvdigital-open-operator-system-oos' ),
						'production'  => __( 'Production', 'nvdigital-open-operator-system-oos' ),
					),
					'default'     => 'sandbox',
					// Removed pro gating - WordPress.org compliance.
				),

				// iSAMS, PayHere, Flowhub, and QuickBooks have been moved to Remote Sites.
				// Use admin.php?page=wp-mcp-ai-remote-sites to manage these connections.
			);
		}

		/**
		 * Get sub-tab groups configuration.
		 *
		 * @return array
		 */
		protected function get_subtab_groups() {
			return array(
				'gmail'           => array(
					'id'     => 'gmail',
					'label'  => __( 'Gmail', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-email',
					'fields' => array( 'gmail_client_id', 'gmail_client_secret' ),
				),
				'google_drive'    => array(
					'id'     => 'google_drive',
					'label'  => __( 'Google Drive', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-cloud',
					'fields' => array( 'google_drive_client_id', 'google_drive_client_secret' ),
				),
				'google_calendar' => array(
					'id'     => 'google_calendar',
					'label'  => __( 'Google Calendar', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-calendar-alt',
					'fields' => array(
						'google_calendar_client_id',
						'google_calendar_client_secret',
						'google_calendar_scope_profile',
						'google_calendar_default_calendar_id',
						'google_calendar_timezone',
					),
				),
				'crawl4ai'        => array(
					'id'     => 'crawl4ai',
					'label'  => __( 'Crawl4AI', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-search',
					'fields' => array( 'crawl4ai_base_url', 'crawl4ai_api_key' ),
				),
				'brave_search'    => array(
					'id'     => 'brave_search',
					'label'  => __( 'Brave Search', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-search',
					'fields' => array( 'brave_search_api_key' ),
				),
				'tavily'          => array(
					'id'     => 'tavily',
					'label'  => __( 'Tavily', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-search',
					'fields' => array( 'tavily_api_key' ),
				),
				'mubert'          => array(
					'id'     => 'mubert',
					'label'  => __( 'Mubert', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-format-audio',
					'fields' => array( 'mubert_api_key' ),
				),
				// PayHere, Flowhub, iSAMS, and QuickBooks have been moved to Remote Sites.
				'removebg'        => array(
					'id'     => 'removebg',
					'label'  => __( 'remove.bg', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-format-image',
					'fields' => array( 'removebg_api_key' ),
				),
				'cloudflare'      => array(
					'id'     => 'cloudflare',
					'label'  => __( 'Cloudflare', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-cloud',
					// enable_cloudflare_pro_toolkit is only shown when the Pro addon is active.
					// Showing a non-functional "pro-only" toggle in the base plugin admin violates
					// WordPress.org Guideline 5 (no locked/non-functional feature controls).
					'fields' => defined( 'WP_MCP_AI_PRO_VERSION' )
						? array( 'cloudflare_api_token', 'cloudflare_zone_id', 'enable_cloudflare_pro_toolkit' )
						: array( 'cloudflare_api_token', 'cloudflare_zone_id' ),
				),
				'cloudways'       => array(
					'id'     => 'cloudways',
					'label'  => __( 'Cloudways', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-cloud-upload',
					'fields' => array( 'cloudways_api_key', 'cloudways_email', 'cloudways_server_id', 'cloudways_app_id' ),
				),
				'meta'            => array(
					'id'     => 'meta',
					'label'  => __( 'Meta', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-share',
					'fields' => array( 'meta_access_token', 'meta_app_id', 'meta_app_secret', 'meta_business_account_id', 'meta_connected_user_name', 'meta_connected_user_id' ),
				),
				'tiktok'          => array(
					'id'     => 'tiktok',
					'label'  => __( 'TikTok', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-video-alt3',
					'fields' => array( 'tiktok_access_token', 'tiktok_client_key', 'tiktok_client_secret' ),
				),
				'opentelemetry'   => array(
					'id'     => 'opentelemetry',
					'label'  => __( 'OpenTelemetry', 'nvdigital-open-operator-system-oos' ),
					'icon'   => 'dashicons-chart-area',
					'fields' => array( 'otel_endpoint', 'otel_token' ),
				),
				// iSAMS moved to Remote Sites.
			);
		}

		/**
		 * Get active sub-tab.
		 *
		 * @return string
		 */
		protected function get_active_subtab() {
			$subtab        = '';
			$subtab_groups = $this->get_subtab_groups();

			// Check POST data first (when form is being submitted), then fall back to GET.
			// Use section-specific field name to avoid conflicts with other sections.
			// phpcs:disable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended -- Read-only parameter check for UI state.
			$subtab_field_name = 'subtab_' . $this->get_id();
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
			if ( isset( $_POST[ $subtab_field_name ] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
				$subtab = sanitize_key( wp_unslash( $_POST[ $subtab_field_name ] ) );
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
			} elseif ( isset( $_POST['connection'] ) ) {
				// Legacy parameter for backwards compatibility.
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
				$subtab = sanitize_key( wp_unslash( $_POST['connection'] ) );
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			} elseif ( isset( $_GET['connection'] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
				$subtab = sanitize_key( wp_unslash( $_GET['connection'] ) );
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
			} elseif ( isset( $_POST['subtab'] ) ) {
				// Fallback to legacy field name for backward compatibility.
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only parameter check.
				$subtab = sanitize_key( wp_unslash( $_POST['subtab'] ) );
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			} elseif ( isset( $_GET['subtab'] ) ) {
				// Only use 'subtab' if it's one of our integration subtabs.

				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
				$potential_subtab = sanitize_key( wp_unslash( $_GET['subtab'] ) );
				if ( isset( $subtab_groups[ $potential_subtab ] ) ) {
					$subtab = $potential_subtab;
				}
			}
			// phpcs:enable WordPress.Security.NonceVerification.Missing,WordPress.Security.NonceVerification.Recommended

			// Default to 'gmail' if not set or invalid.
			if ( empty( $subtab ) || ! isset( $subtab_groups[ $subtab ] ) ) {
				$subtab = 'gmail';
			}

			return $subtab;
		}

		/**
		 * Render section fields.
		 */
		public function render() {
			$fields        = $this->get_fields();
			$subtab_groups = $this->get_subtab_groups();
			$active_subtab = $this->get_active_subtab();

			// Get the active group.
			if ( ! isset( $subtab_groups[ $active_subtab ] ) ) {
				return;
			}

			$active_group = $subtab_groups[ $active_subtab ];

			// Render fields for the active sub-tab.
			foreach ( $active_group['fields'] as $key ) {
				if ( isset( $fields[ $key ] ) ) {
					$this->render_field( $key, $fields[ $key ] );
				}
			}

			// Render additional content based on active sub-tab.
			$this->render_subtab_footer( $active_subtab );
		}

		/**
		 * Render footer content for specific sub-tabs.
		 *
		 * @param string $subtab Active sub-tab ID.
		 */
		private function render_subtab_footer( $subtab ) {
			switch ( $subtab ) {
				case 'gmail':
					$this->render_gmail_footer();
					break;
				case 'google_drive':
					$this->render_google_drive_footer();
					break;
				case 'google_calendar':
					$this->render_google_calendar_footer();
					break;
				case 'brave_search':
					$this->render_brave_search_footer();
					break;
				case 'tavily':
					$this->render_tavily_footer();
					break;
				case 'mubert':
					$this->render_mubert_footer();
					break;
				case 'yahoo_sports':
					$this->render_yahoo_sports_footer();
					break;
				case 'espn_sports':
					$this->render_espn_sports_footer();
					break;
				case 'removebg':
					$this->render_removebg_footer();
					break;
				// PayHere, Flowhub, QuickBooks, and iSAMS moved to Remote Sites.
				case 'meta':
					$this->render_meta_footer();
					break;
				case 'tiktok':
					$this->render_tiktok_footer();
					break;
				case 'opentelemetry':
					$this->render_opentelemetry_footer();
					break;
				// QuickBooks and iSAMS moved to Remote Sites.
				case 'cloudways':
					$this->render_cloudways_footer();
					break;
				case 'cloudflare':
					$this->render_cloudflare_footer();
					break;
				case 'mailjet':
					$this->render_mailjet_footer();
					break;
				// iSAMS moved to Remote Sites.
			}
		}

		/**
		 * Render Gmail footer content.
		 */
		private function render_gmail_footer() {
			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$gmail_connected = ! empty( $settings['gmail_refresh_token'] );
			$gmail_email     = isset( $settings['gmail_user_email'] ) ? $settings['gmail_user_email'] : '';
			$has_credentials = ! empty( $settings['gmail_client_id'] ) && ! empty( $settings['gmail_client_secret'] );
			$is_pro_active   = defined( 'WP_MCP_AI_PRO_VERSION' );

			// Pro Remote Sites connections: list them here so this page never
			// reports Gmail as unconfigured when a working named connection
			// exists. Gmail tools auto-resolve to those connections when the
			// settings-based credentials below are absent.
			$remote_gmail_connections = array();
			if ( $is_pro_active && class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
				$gmail_connection_types = array( 'gmail', 'google_workspace', 'email_imap' );
				$all_remote             = WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections();
				foreach ( $all_remote as $remote_connection ) {
					if ( is_array( $remote_connection ) && isset( $remote_connection['connection_type'] ) && in_array( $remote_connection['connection_type'], $gmail_connection_types, true ) ) {
						$remote_gmail_connections[] = $remote_connection;
					}
				}
			}

			$oauth_connect_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_gmail_oauth_start' ),
				'wp_mcp_ai_gmail_oauth_start'
			);
			$disconnect_url    = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_gmail_disconnect' ),
				'wp_mcp_ai_gmail_disconnect'
			);

			// Check for success or error messages.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$gmail_success = isset( $_GET['gmail_success'] ) ? sanitize_text_field( wp_unslash( $_GET['gmail_success'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$gmail_error = isset( $_GET['gmail_error'] ) ? sanitize_text_field( wp_unslash( $_GET['gmail_error'] ) ) : '';
			?>
			<?php if ( $gmail_success ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-success inline" style="margin: 0 0 15px;">
						<p><?php echo esc_html( $gmail_success ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
			<?php if ( $gmail_error ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-error inline" style="margin: 0 0 15px;">
						<p><?php echo esc_html( $gmail_error ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
			<?php if ( ! empty( $remote_gmail_connections ) ) : ?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Remote Sites Gmail Connections', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<div style="padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0 0 6px; color: #0c5460;">
							<span class="dashicons dashicons-admin-site-alt" style="color: #0c5460;"></span>
							<strong><?php esc_html_e( 'Gmail is configured via Remote Sites:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ul style="margin: 0 0 6px 20px; list-style: disc; color: #0c5460;">
							<?php foreach ( $remote_gmail_connections as $remote_connection ) : ?>
								<li>
									<strong><?php echo esc_html( isset( $remote_connection['name'] ) ? (string) $remote_connection['name'] : '' ); ?></strong>
									<?php if ( ! empty( $remote_connection['user_email'] ) ) : ?>
										<?php
										printf(
											/* translators: %s: Google account email address. */
											esc_html__( '— %s', 'nvdigital-open-operator-system-oos' ),
											esc_html( (string) $remote_connection['user_email'] )
										);
										?>
									<?php endif; ?>
									<?php if ( empty( $remote_connection['enabled'] ) ) : ?>
										<?php esc_html_e( '(disabled)', 'nvdigital-open-operator-system-oos' ); ?>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
						<p style="margin: 0; color: #0c5460;">
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-remote-sites' ) ); ?>">
								<?php esc_html_e( 'Manage Gmail connections in Remote Sites', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						</p>
					</div>
				</td>
			</tr>
			<?php endif; ?>
		<tr>
			<th scope="row"><?php esc_html_e( 'Gmail Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td>
				<?php if ( $gmail_connected ) : ?>
					<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #155724;">
							<span class="dashicons dashicons-yes" style="color: #155724;"></span>
							<strong><?php esc_html_e( 'Connected to Gmail', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<?php if ( $gmail_email ) : ?>
								<?php
								printf(
									/* translators: %s: Gmail email address */
									esc_html__( 'as %s', 'nvdigital-open-operator-system-oos' ),
									'<code>' . esc_html( $gmail_email ) . '</code>'
								);
								?>
							<?php endif; ?>
						</p>
					</div>
					<p>
						<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button">
							<?php esc_html_e( 'Reconnect Gmail Account', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
						<a href="<?php echo esc_url( $disconnect_url ); ?>" class="button" style="margin-left: 5px;">
							<?php esc_html_e( 'Disconnect', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</p>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'Your Gmail account is connected. You can now use Gmail integration tools to search and read emails.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
				<?php elseif ( $has_credentials ) : ?>
					<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #856404;">
							<span class="dashicons dashicons-warning" style="color: #856404;"></span>
							<strong><?php esc_html_e( 'Gmail Not Connected', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
					</div>
					<p>
						<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button button-primary">
							<?php esc_html_e( 'Connect Gmail Account', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</p>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'Click the button above to authorize WP MCP AI to access your Gmail account. You will be redirected to Google to grant permissions.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
					<p class="description">
						<strong><?php esc_html_e( 'Required Permissions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><code>gmail.readonly</code>: <?php esc_html_e( 'Read access to Gmail messages and settings', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
					<?php elseif ( ! empty( $remote_gmail_connections ) ) : ?>
						<div style="padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #0c5460;">
								<span class="dashicons dashicons-info" style="color: #0c5460;"></span>
								<strong><?php esc_html_e( 'No settings-based Gmail credentials — using the Remote Sites connection.', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'The Client ID and Client Secret fields above only control the settings-based default Gmail connection. Because no credentials are stored there, Gmail tools will use the Gmail connection configured under Remote Sites automatically.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php else : ?>
						<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #721c24;">
								<span class="dashicons dashicons-info" style="color: #721c24;"></span>
								<strong><?php esc_html_e( 'Gmail OAuth Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'To connect your Gmail account, first configure your Gmail OAuth Client ID and Client Secret in the fields above, then save your settings.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
					<p class="description">
						<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li>
							<?php
							printf(
								/* translators: %s: URL to Google Cloud Console */
								wp_kses_post( __( 'Go to <a href="%s" target="_blank">Google Cloud Console</a>', 'nvdigital-open-operator-system-oos' ) ),
								esc_url( 'https://console.cloud.google.com/' )
							);
							?>
						</li>
						<li><?php esc_html_e( 'Create a new project or select an existing one', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Enable the Gmail API for your project', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Create OAuth 2.0 credentials (Web application type)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li>
							<?php
							$gmail_redirect_uri = add_query_arg(
								array( 'wp_mcp_ai_oauth' => 'gmail_callback' ),
								admin_url( 'admin.php' )
							);
							printf(
								/* translators: %s: Callback URL */
								esc_html__( 'Set Authorized redirect URI to: %s', 'nvdigital-open-operator-system-oos' ),
								'<br><code>' . esc_html( $gmail_redirect_uri ) . '</code>'
							);
							?>
						</li>
						<li><?php esc_html_e( 'Copy the Client ID and Client Secret to the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Click the "Connect Gmail Account" button that will appear', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<th scope="row"></th>
			<td>
				<p class="description">
					<strong><?php esc_html_e( 'About Gmail Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				</p>
				<ul style="list-style: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'OAuth 2.0 credentials are obtained from Google Cloud Console', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Access tokens are automatically refreshed when expired', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Supports searching and reading Gmail messages', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Requires the restricted gmail.readonly scope — see the Google publishing status note below', 'nvdigital-open-operator-system-oos' ); ?></li>
				</ul>
			</td>
		</tr>
		<tr>
			<th scope="row"></th>
			<td>
				<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px;">
					<p style="margin: 0; color: #856404;">
						<strong><?php esc_html_e( 'Google publishing status:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						<?php esc_html_e( 'While your OAuth consent screen is "Testing", Google expires refresh tokens after 7 days and the connection breaks weekly. Publishing to "In production" stops the resets — but gmail.readonly is a restricted scope, so solo operators should claim the personal-use exception and Workspace teams should use an Internal consent screen. See the Google OAuth Production Verification Plan for the full checklist.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</div>
			</td>
		</tr>
			<?php
		}

		/**
		 * Render Google Drive footer content.
		 */
		private function render_google_drive_footer() {
			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$drive_connected = ! empty( $settings['google_drive_refresh_token'] );
			$drive_email     = isset( $settings['google_drive_user_email'] ) ? $settings['google_drive_user_email'] : '';
			$has_credentials = ! empty( $settings['google_drive_client_id'] ) && ! empty( $settings['google_drive_client_secret'] );
			$is_pro_active   = defined( 'WP_MCP_AI_PRO_VERSION' );

			// Pro Remote Sites connections: list them here so this page never
			// reports Drive as unconfigured when a working named connection
			// exists. Drive tools auto-resolve to those connections when the
			// settings-based credentials below are absent.
			$remote_drive_connections = array();
			if ( $is_pro_active && class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
				$all_remote = WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections();
				foreach ( $all_remote as $remote_connection ) {
					if ( is_array( $remote_connection ) && isset( $remote_connection['connection_type'] ) && 'google_drive' === $remote_connection['connection_type'] ) {
						$remote_drive_connections[] = $remote_connection;
					}
				}
			}

			$oauth_connect_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_google_drive_oauth_start' ),
				'wp_mcp_ai_google_drive_oauth_start'
			);
			$disconnect_url    = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_google_drive_disconnect' ),
				'wp_mcp_ai_google_drive_disconnect'
			);

			// Check for success or error messages.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$drive_success = isset( $_GET['drive_success'] ) ? sanitize_text_field( wp_unslash( $_GET['drive_success'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$drive_error = isset( $_GET['drive_error'] ) ? sanitize_text_field( wp_unslash( $_GET['drive_error'] ) ) : '';
			?>
			<?php if ( $drive_success ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-success inline" style="margin: 0 0 15px;">
						<p><?php echo esc_html( $drive_success ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
			<?php if ( $drive_error ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-error inline" style="margin: 0 0 15px;">
						<p><?php echo esc_html( $drive_error ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
			<?php if ( ! empty( $remote_drive_connections ) ) : ?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Remote Sites Drive Connections', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<div style="padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0 0 6px; color: #0c5460;">
							<span class="dashicons dashicons-admin-site-alt" style="color: #0c5460;"></span>
							<strong><?php esc_html_e( 'Google Drive is configured via Remote Sites:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ul style="margin: 0 0 6px 20px; list-style: disc; color: #0c5460;">
							<?php foreach ( $remote_drive_connections as $remote_connection ) : ?>
								<li>
									<strong><?php echo esc_html( isset( $remote_connection['name'] ) ? (string) $remote_connection['name'] : '' ); ?></strong>
									<?php if ( ! empty( $remote_connection['user_email'] ) ) : ?>
										<?php
										printf(
											/* translators: %s: Google account email address. */
											esc_html__( '— %s', 'nvdigital-open-operator-system-oos' ),
											esc_html( (string) $remote_connection['user_email'] )
										);
										?>
									<?php endif; ?>
									<?php if ( empty( $remote_connection['enabled'] ) ) : ?>
										<?php esc_html_e( '(disabled)', 'nvdigital-open-operator-system-oos' ); ?>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
						<p style="margin: 0; color: #0c5460;">
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-remote-sites' ) ); ?>">
								<?php esc_html_e( 'Manage Drive connections in Remote Sites', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						</p>
					</div>
				</td>
			</tr>
			<?php endif; ?>
		<tr>
			<th scope="row"><?php esc_html_e( 'Google Drive Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td>
				<?php if ( $drive_connected ) : ?>
					<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #155724;">
							<span class="dashicons dashicons-yes" style="color: #155724;"></span>
							<strong><?php esc_html_e( 'Connected to Google Drive', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<?php if ( $drive_email ) : ?>
								<?php
								printf(
									/* translators: %s: Google account email address */
									esc_html__( 'as %s', 'nvdigital-open-operator-system-oos' ),
									'<code>' . esc_html( $drive_email ) . '</code>'
								);
								?>
							<?php endif; ?>
						</p>
					</div>
					<p>
						<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button">
							<?php esc_html_e( 'Reconnect Google Drive Account', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
						<a href="<?php echo esc_url( $disconnect_url ); ?>" class="button" style="margin-left: 5px;">
							<?php esc_html_e( 'Disconnect', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</p>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'Your Google Drive account is connected. You can now use Google Drive integration tools to search and read files.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
				<?php elseif ( $has_credentials ) : ?>
					<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #856404;">
							<span class="dashicons dashicons-warning" style="color: #856404;"></span>
							<strong><?php esc_html_e( 'Google Drive Not Connected', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
					</div>
					<p>
						<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button button-primary">
							<?php esc_html_e( 'Connect Google Drive Account', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</p>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'Click the button above to authorize WP MCP AI to access your Google Drive account. You will be redirected to Google to grant permissions.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
					<p class="description">
						<strong><?php esc_html_e( 'Required Permissions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><code>drive.file</code>: <?php esc_html_e( 'Per-file access (files created by or shared with NV oOS). Non-sensitive — no Google verification needed.', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
					<?php elseif ( ! empty( $remote_drive_connections ) ) : ?>
						<div style="padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #0c5460;">
								<span class="dashicons dashicons-info" style="color: #0c5460;"></span>
								<strong><?php esc_html_e( 'No settings-based Drive credentials — using the Remote Sites connection.', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'The Client ID and Client Secret fields above only control the settings-based default Google Drive connection. Because no credentials are stored there, Drive tools will use the Google Drive connection configured under Remote Sites automatically.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php else : ?>
						<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #721c24;">
								<span class="dashicons dashicons-info" style="color: #721c24;"></span>
								<strong><?php esc_html_e( 'Google Drive OAuth Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'To connect your Google Drive account, first configure your Google Drive OAuth Client ID and Client Secret in the fields above, then save your settings.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
					<p class="description">
						<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li>
							<?php
							printf(
								/* translators: %s: URL to Google Cloud Console */
								wp_kses_post( __( 'Go to <a href="%s" target="_blank">Google Cloud Console</a>', 'nvdigital-open-operator-system-oos' ) ),
								esc_url( 'https://console.cloud.google.com/' )
							);
							?>
						</li>
						<li><?php esc_html_e( 'Create a new project or select an existing one', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Enable the Google Drive API for your project', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Create OAuth 2.0 credentials (Web application type)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li>
							<?php
							$drive_redirect_uri = add_query_arg(
								array( 'wp_mcp_ai_oauth' => 'google_drive_callback' ),
								admin_url( 'admin.php' )
							);
							printf(
								/* translators: %s: Callback URL */
								esc_html__( 'Set Authorized redirect URI to: %s', 'nvdigital-open-operator-system-oos' ),
								'<br><code>' . esc_html( $drive_redirect_uri ) . '</code>'
							);
							?>
						</li>
						<li><?php esc_html_e( 'Copy the Client ID and Client Secret to the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Click the "Connect Google Drive Account" button that will appear', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<th scope="row"></th>
			<td>
				<p class="description">
					<strong><?php esc_html_e( 'About Google Drive Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				</p>
				<ul style="list-style: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'OAuth 2.0 credentials are obtained from Google Cloud Console', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Access tokens are automatically refreshed when expired', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Supports searching and reading Drive files', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Uses the non-sensitive drive.file scope by default; full-Drive read scopes are opt-in via the wp_mcp_ai_google_drive_oauth_scope filter', 'nvdigital-open-operator-system-oos' ); ?></li>
						<?php if ( $is_pro_active ) : ?>
						<li><?php esc_html_e( 'Pro users can configure multiple Google Drive connections via Remote Sites', 'nvdigital-open-operator-system-oos' ); ?></li>
				<?php else : ?>
					<li><?php esc_html_e( 'Base version supports 1 connection. Upgrade to Pro for multiple connections', 'nvdigital-open-operator-system-oos' ); ?></li>
				<?php endif; ?>
			</ul>
		</td>
	</tr>
		<tr>
			<th scope="row"></th>
			<td>
				<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px;">
					<p style="margin: 0; color: #856404;">
						<strong><?php esc_html_e( 'Google publishing status:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						<?php esc_html_e( 'While your OAuth consent screen is "Testing", Google expires refresh tokens after 7 days. Publishing to "In production" stops the resets — the default drive.file scope is non-sensitive, so no Google review is required. If you opt back into full-Drive scopes via the wp_mcp_ai_google_drive_oauth_scope filter, restricted-scope verification (CASA) applies instead.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</div>
			</td>
		</tr>
				<?php
		}

		/**
		 * Render Google Calendar footer content.
		 *
		 * Renders the three-state connection UI (connected / credentials saved /
		 * credentials missing), the read-only authorised redirect URI, the granted
		 * scope readout, and the Google publishing-status warning.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		private function render_google_calendar_footer() {
			require_once WP_MCP_AI_PATH . 'includes/google/class-wp-mcp-ai-google-oauth-service.php';
			require_once WP_MCP_AI_PATH . 'includes/google/class-wp-mcp-ai-google-calendar-scopes.php';

			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$is_connected    = ! empty( $settings['google_calendar_refresh_token'] );
			$account_email   = isset( $settings['google_calendar_user_email'] ) ? (string) $settings['google_calendar_user_email'] : '';
			$has_credentials = ! empty( $settings['google_calendar_client_id'] ) && ! empty( $settings['google_calendar_client_secret'] );
			$is_pro_active   = defined( 'WP_MCP_AI_PRO_VERSION' );

			// Pro Remote Sites connections: list them here so this page never
			// reports Google Calendar as unconfigured when a working named
			// connection exists. Calendar tools auto-resolve to those
			// connections when the settings-based credentials below are absent.
			$remote_calendar_connections = array();
			if ( $is_pro_active && class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
				$all_remote = WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections();
				foreach ( $all_remote as $remote_connection ) {
					if ( is_array( $remote_connection ) && isset( $remote_connection['connection_type'] ) && 'google_calendar' === $remote_connection['connection_type'] ) {
						$remote_calendar_connections[] = $remote_connection;
					}
				}
			}

			$profile        = WP_MCP_AI_Google_Calendar_Scopes::normalise_profile(
				isset( $settings['google_calendar_scope_profile'] ) ? $settings['google_calendar_scope_profile'] : ''
			);
			$profile_scopes = WP_MCP_AI_Google_Calendar_Scopes::get_profile_scopes( $profile );
			$needs_review   = WP_MCP_AI_Google_Calendar_Scopes::profile_requires_verification( $profile );
			$granted_scopes = WP_MCP_AI_Google_Calendar_Scopes::parse_granted(
				isset( $settings['google_calendar_granted_scopes'] ) ? $settings['google_calendar_granted_scopes'] : ''
			);

			// Scopes requested by the active profile but not granted by the user.
			// Google's granular consent lets users approve a subset, so this is a
			// normal state that must be surfaced rather than discovered as a 403.
			$missing_scopes = array();

			if ( $is_connected && ! empty( $granted_scopes ) ) {
				foreach ( $profile_scopes as $needed ) {
					if ( ! WP_MCP_AI_Google_Calendar_Scopes::has_scope( implode( ' ', $granted_scopes ), $needed ) ) {
						$missing_scopes[] = $needed;
					}
				}
			}

			$connect_url    = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_google_calendar_oauth_start' ),
				'wp_mcp_ai_google_calendar_oauth_start'
			);
			$disconnect_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_google_calendar_disconnect' ),
				'wp_mcp_ai_google_calendar_disconnect'
			);

			$redirect_uri = WP_MCP_AI_Google_OAuth_Service::build_redirect_uri(
				WP_MCP_AI_Admin_Settings::GOOGLE_CALENDAR_OAUTH_CALLBACK_HANDLER
			);

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash message.
			$flash_success = isset( $_GET['calendar_success'] ) ? sanitize_text_field( wp_unslash( $_GET['calendar_success'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash message.
			$flash_error = isset( $_GET['calendar_error'] ) ? sanitize_text_field( wp_unslash( $_GET['calendar_error'] ) ) : '';
			?>
	<tr>
		<th scope="row"><?php esc_html_e( 'Authorized Redirect URI', 'nvdigital-open-operator-system-oos' ); ?></th>
		<td>
			<input type="text" readonly="readonly" value="<?php echo esc_url( $redirect_uri ); ?>" class="large-text code" onclick="this.select();" style="background-color: #f0f0f0;">
			<p class="description">
				<strong><?php esc_html_e( 'Important:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				<?php esc_html_e( 'Copy this exact URL into the "Authorized redirect URIs" list of your Google Cloud Console OAuth 2.0 client. It must match character for character, including the scheme.', 'nvdigital-open-operator-system-oos' ); ?>
				<br>
				<a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer">
					<?php esc_html_e( 'Open Google Cloud Console', 'nvdigital-open-operator-system-oos' ); ?>
					<span class="dashicons dashicons-external" style="font-size: 14px; vertical-align: text-top;"></span>
				</a>
			</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'Connection Status', 'nvdigital-open-operator-system-oos' ); ?></th>
		<td>
			<?php if ( '' !== $flash_success ) : ?>
				<div class="notice notice-success inline" style="margin: 0 0 12px;">
					<p><?php echo esc_html( $flash_success ); ?></p>
				</div>
			<?php endif; ?>
			<?php if ( '' !== $flash_error ) : ?>
				<div class="notice notice-error inline" style="margin: 0 0 12px;">
					<p><?php echo esc_html( $flash_error ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( $is_connected ) : ?>
				<p style="color: #46b450; font-weight: 600; margin-top: 0;">
					<span class="dashicons dashicons-yes-alt"></span>
					<?php
					if ( '' !== $account_email ) {
						printf(
							/* translators: %s: Google account email address. */
							esc_html__( 'Connected as %s', 'nvdigital-open-operator-system-oos' ),
							esc_html( $account_email )
						);
					} else {
						esc_html_e( 'Connected', 'nvdigital-open-operator-system-oos' );
					}
					?>
				</p>
				<p>
					<a href="<?php echo esc_url( $connect_url ); ?>" class="button">
						<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
						<?php esc_html_e( 'Reconnect', 'nvdigital-open-operator-system-oos' ); ?>
					</a>
					<a href="<?php echo esc_url( $disconnect_url ); ?>" class="button button-link-delete">
						<?php esc_html_e( 'Disconnect', 'nvdigital-open-operator-system-oos' ); ?>
					</a>
				</p>
				<p class="description">
					<?php esc_html_e( 'Disconnecting revokes the token at Google and clears it locally. Your Client ID and Client Secret are kept so you can reconnect without re-entering them.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
			<?php elseif ( $has_credentials ) : ?>
				<p style="color: #b26200; font-weight: 600; margin-top: 0;">
					<span class="dashicons dashicons-warning"></span>
					<?php esc_html_e( 'Credentials saved — not yet authorised', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
				<p>
					<a href="<?php echo esc_url( $connect_url ); ?>" class="button button-primary">
						<span class="dashicons dashicons-google" style="margin-top: 3px;"></span>
						<?php esc_html_e( 'Connect Google Calendar Account', 'nvdigital-open-operator-system-oos' ); ?>
					</a>
				</p>
			<?php elseif ( ! empty( $remote_calendar_connections ) ) : ?>
				<p style="color: #0c5460; font-weight: 600; margin-top: 0;">
					<span class="dashicons dashicons-info"></span>
					<?php esc_html_e( 'No settings-based Calendar credentials — using the Remote Sites connection.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
				<p class="description">
					<?php esc_html_e( 'The Client ID and Client Secret fields above only control the settings-based Google Calendar connection. Because no credentials are stored there, Calendar tools will use the Google Calendar connection configured under Remote Sites automatically.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
			<?php else : ?>
				<p style="color: #d63638; font-weight: 600; margin-top: 0;">
					<span class="dashicons dashicons-dismiss"></span>
					<?php esc_html_e( 'OAuth credentials required', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
				<p class="description">
					<?php esc_html_e( 'Enter and save the Client ID and Client Secret above, then a Connect button will appear here.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
			<?php endif; ?>
		</td>
	</tr>
			<?php if ( ! empty( $remote_calendar_connections ) ) : ?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Remote Sites Calendar Connections', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<div style="padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0 0 6px; color: #0c5460;">
							<span class="dashicons dashicons-admin-site-alt" style="color: #0c5460;"></span>
							<strong><?php esc_html_e( 'Google Calendar is configured via Remote Sites:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ul style="margin: 0 0 6px 20px; list-style: disc; color: #0c5460;">
							<?php foreach ( $remote_calendar_connections as $remote_connection ) : ?>
								<li>
									<strong><?php echo esc_html( isset( $remote_connection['name'] ) ? (string) $remote_connection['name'] : '' ); ?></strong>
									<?php if ( ! empty( $remote_connection['user_email'] ) ) : ?>
										<?php
										printf(
											/* translators: %s: Google account email address. */
											esc_html__( '— %s', 'nvdigital-open-operator-system-oos' ),
											esc_html( (string) $remote_connection['user_email'] )
										);
										?>
									<?php endif; ?>
									<?php if ( empty( $remote_connection['enabled'] ) ) : ?>
										<?php esc_html_e( '(disabled)', 'nvdigital-open-operator-system-oos' ); ?>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
						<p style="margin: 0; color: #0c5460;">
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-remote-sites' ) ); ?>">
								<?php esc_html_e( 'Manage Calendar connections in Remote Sites', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						</p>
					</div>
				</td>
			</tr>
			<?php endif; ?>
	<tr>
		<th scope="row"><?php esc_html_e( 'Granted Permissions', 'nvdigital-open-operator-system-oos' ); ?></th>
		<td>
			<p class="description" style="margin-top: 0;">
					<?php
					printf(
					/* translators: %s: scope profile label. */
						esc_html__( 'Active profile: %s', 'nvdigital-open-operator-system-oos' ),
						'<strong>' . esc_html( WP_MCP_AI_Google_Calendar_Scopes::get_profile_label( $profile ) ) . '</strong>'
					);
					?>
			</p>
			<p class="description"><?php echo esc_html( WP_MCP_AI_Google_Calendar_Scopes::get_profile_description( $profile ) ); ?></p>

				<?php if ( $is_connected && ! empty( $granted_scopes ) ) : ?>
				<p style="margin-bottom: 4px;"><strong><?php esc_html_e( 'Scopes granted by Google:', 'nvdigital-open-operator-system-oos' ); ?></strong></p>
				<ul style="list-style: disc; margin-left: 20px;">
					<?php foreach ( $granted_scopes as $scope ) : ?>
						<li><code><?php echo esc_html( $scope ); ?></code></li>
					<?php endforeach; ?>
				</ul>
			<?php elseif ( $is_connected ) : ?>
				<p class="description">
					<?php esc_html_e( 'This connection was authorised before permission tracking was added. Reconnect to record the granted scopes.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
			<?php endif; ?>

				<?php if ( ! empty( $missing_scopes ) ) : ?>
				<div class="notice notice-warning inline" style="margin: 12px 0 0;">
					<p>
						<strong><?php esc_html_e( 'Some requested permissions were declined.', 'nvdigital-open-operator-system-oos' ); ?></strong>
						<?php esc_html_e( 'Google lets you approve a subset of permissions. The following scopes were requested but not granted, so the matching features will fail:', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<?php foreach ( $missing_scopes as $scope ) : ?>
							<li><code><?php echo esc_html( $scope ); ?></code></li>
						<?php endforeach; ?>
					</ul>
					<p><?php esc_html_e( 'Click Reconnect and tick every Calendar permission on the Google consent screen.', 'nvdigital-open-operator-system-oos' ); ?></p>
				</div>
			<?php endif; ?>
		</td>
	</tr>
	<tr>
		<th scope="row"></th>
		<td>
			<div class="notice notice-info inline" style="margin: 0 0 12px;">
				<p>
					<strong><?php esc_html_e( 'Publish your Google Cloud app before relying on this connection.', 'nvdigital-open-operator-system-oos' ); ?></strong>
				</p>
				<p>
					<?php esc_html_e( 'While your OAuth consent screen publishing status is "Testing", Google issues refresh tokens that expire after 7 days. The connection will then break weekly until you set the publishing status to "In production".', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
				<?php if ( $needs_review ) : ?>
					<p>
						<?php esc_html_e( 'The selected permission level uses sensitive Google scopes, so publishing also requires OAuth app verification (typically 3-5 business days). To avoid verification entirely, switch the permission level to Minimal — NV oOS will then manage its own dedicated calendar instead of your existing ones.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				<?php else : ?>
					<p>
						<?php esc_html_e( 'The selected permission level uses only non-sensitive Google scopes, so no OAuth app verification is required.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				<?php endif; ?>
				<p>
					<a href="https://console.cloud.google.com/apis/credentials/consent" target="_blank" rel="noopener noreferrer">
						<?php esc_html_e( 'Open OAuth consent screen settings', 'nvdigital-open-operator-system-oos' ); ?>
						<span class="dashicons dashicons-external" style="font-size: 14px; vertical-align: text-top;"></span>
					</a>
				</p>
			</div>

			<p class="description">
				<strong><?php esc_html_e( 'About Google Calendar Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
			</p>
			<ul style="list-style: disc; margin-left: 20px;">
				<li><?php esc_html_e( 'Enable the Google Calendar API for your project in the Cloud Console before connecting', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Access tokens are minted from the stored refresh token and cached automatically', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Supports creating, reading, updating, and deleting events, plus availability lookups', 'nvdigital-open-operator-system-oos' ); ?></li>
				<li><?php esc_html_e( 'Time zones must be IANA identifiers such as "America/New_York" — UTC offsets are rejected by Google', 'nvdigital-open-operator-system-oos' ); ?></li>
				<?php if ( $is_pro_active ) : ?>
					<li><?php esc_html_e( 'Pro users can configure multiple Google Calendar connections via Remote Sites', 'nvdigital-open-operator-system-oos' ); ?></li>
				<?php else : ?>
					<li><?php esc_html_e( 'Base version supports 1 connection. Upgrade to Pro for multiple connections', 'nvdigital-open-operator-system-oos' ); ?></li>
				<?php endif; ?>
			</ul>
		</td>
	</tr>
			<?php
		}

		/**
		 * Render Brave Search footer content.
		 */
		private function render_brave_search_footer() {
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Brave Search Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-brave-search-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-brave-search-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your Brave Search API key in the field above, then click "Test Connection" to verify it works. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Tavily footer content.
		 */
		private function render_tavily_footer() {
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Tavily Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-tavily-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-tavily-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your Tavily API key in the field above, then click "Test Connection" to verify it works. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<div style="margin: 1rem 0;">
						<h4><?php esc_html_e( 'About Tavily Integration', 'nvdigital-open-operator-system-oos' ); ?></h4>
						<ul style="list-style: disc; margin-left: 20px;">
							<li><?php esc_html_e( 'Purpose-built for AI agents — returns rich, structured search results', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Supports freshness filtering, country/language targeting, and snippet grounding', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Get your API key from tavily.com', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Select "Tavily" as the web search provider in Tools → Configuration to activate', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
					</div>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Mubert footer content.
		 */
		private function render_mubert_footer() {
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Mubert Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-mubert-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-mubert-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your Mubert API key in the field above, then click "Test Connection" to verify it works. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'About Mubert Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Generate royalty-free background music with 150+ genres and 50+ moods', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Request an API key from business@mubert.com', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Used by the generate_music tool for AI-powered music creation', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Supports track durations from 15 seconds to 25 minutes', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Yahoo Sports footer content.
		 */
		private function render_yahoo_sports_footer() {
			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$user_id         = get_current_user_id();
			$yahoo_connected = ! empty( get_user_meta( $user_id, 'wp_mcp_ai_yahoo_access_token', true ) ) && ! empty( get_user_meta( $user_id, 'wp_mcp_ai_yahoo_refresh_token', true ) );
			$has_credentials = ! empty( $settings['yahoo_client_id'] ) && ! empty( $settings['yahoo_client_secret'] );
			$is_pro_active   = defined( 'WP_MCP_AI_PRO_VERSION' );

			// Generate OAuth state and build direct link to Yahoo OAuth (similar to Gmail).
			if ( $has_credentials ) {
				$state     = wp_generate_uuid4();
				$transient = 'wp_mcp_ai_yahoo_oauth_state_' . md5( $state );

				set_transient(
					$transient,
					array(
						'user_id' => $user_id,
						'time'    => time(),
					),
					10 * MINUTE_IN_SECONDS
				);

				// Build redirect URI.
				$base_url     = admin_url( 'admin.php' );
				$redirect_uri = add_query_arg(
					array( 'wp_mcp_ai_oauth' => 'yahoo_callback' ),
					$base_url
				);

				// Build Yahoo OAuth authorization URL.
				$oauth_connect_url = add_query_arg(
					array(
						'client_id'     => rawurlencode( $settings['yahoo_client_id'] ),
						'redirect_uri'  => rawurlencode( $redirect_uri ),
						'response_type' => 'code',
						'scope'         => 'fspt-r', // Fantasy Sports Read access - required for reading user's fantasy football leagues, rosters, and stats. Yahoo uses 'fspt-w' for write access if needed in the future.
						'state'         => $state,
					),
					'https://api.login.yahoo.com/oauth2/request_auth'
				);
			} else {
				$oauth_connect_url = '#';
			}

			// Check for success or error messages.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$yahoo_success = isset( $_GET['yahoo_success'] ) ? sanitize_text_field( wp_unslash( $_GET['yahoo_success'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$yahoo_error = isset( $_GET['yahoo_error'] ) ? sanitize_text_field( wp_unslash( $_GET['yahoo_error'] ) ) : '';
			?>
			<?php if ( $yahoo_success ) : ?>
		<tr>
			<th scope="row"></th>
			<td>
				<div class="notice notice-success inline" style="margin: 0 0 15px;">
					<p><?php echo esc_html( $yahoo_success ); ?></p>
				</div>
			</td>
		</tr>
	<?php endif; ?>
			<?php if ( $yahoo_error ) : ?>
		<tr>
			<th scope="row"></th>
			<td>
				<div class="notice notice-error inline" style="margin: 0 0 15px;">
					<p><?php echo esc_html( $yahoo_error ); ?></p>
				</div>
			</td>
		</tr>
	<?php endif; ?>
	<tr>
		<th scope="row"><?php esc_html_e( 'Yahoo Sports Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
		<td>
			<?php if ( $yahoo_connected ) : ?>
				<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
					<p style="margin: 0; color: #155724;">
						<span class="dashicons dashicons-yes" style="color: #155724;"></span>
						<strong><?php esc_html_e( 'Connected to Yahoo Sports', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
				</div>
				<p>
					<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button">
						<?php esc_html_e( 'Reconnect Yahoo Account', 'nvdigital-open-operator-system-oos' ); ?>
					</a>
				</p>
				<p class="description">
					<?php
					echo wp_kses_post(
						__(
							'Your Yahoo account is connected. You can now use Yahoo Fantasy Football tools to access your leagues.',
							'nvdigital-open-operator-system-oos'
						)
					);
					?>
				</p>
			<?php elseif ( $has_credentials && $is_pro_active ) : ?>
				<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
					<p style="margin: 0; color: #856404;">
						<span class="dashicons dashicons-warning" style="color: #856404;"></span>
						<strong><?php esc_html_e( 'Yahoo Sports Not Connected', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
				</div>
				<p>
					<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button button-primary">
						<?php esc_html_e( 'Connect Yahoo Account', 'nvdigital-open-operator-system-oos' ); ?>
					</a>
				</p>
				<p class="description">
					<?php
					echo wp_kses_post(
						__(
							'Click the button above to authorize access to your Yahoo Fantasy Football account.',
							'nvdigital-open-operator-system-oos'
						)
					);
					?>
				</p>
			<?php else : ?>
				<p class="description">
					<?php esc_html_e( 'Enter your Yahoo Client ID and Secret in the fields above and save to enable the Connect Yahoo Account button.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
			<?php endif; ?>
			<p>
				<button type="button" id="wp-mcp-ai-test-yahoo-connection" class="button button-secondary" <?php echo esc_attr( ! $is_pro_active ? 'disabled' : '' ); ?>>
					<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
				</button>
				<span id="wp-mcp-ai-yahoo-test-result" style="margin-left: 10px;"></span>
			</p>
			<p class="description">
				<?php esc_html_e( 'Enter your Yahoo Client ID and Secret in the fields above, then click "Test Connection" to verify they work. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
			</p>
		</td>
	</tr>
	<tr>
		<th scope="row"></th>
		<td>
			<div style="margin: 1rem 0;">
				<h4><?php esc_html_e( 'About Yahoo Sports Integration', 'nvdigital-open-operator-system-oos' ); ?></h4>
				<p class="description" style="margin-bottom: 10px;">
					<?php esc_html_e( 'Connect to Yahoo Fantasy Sports API to access your fantasy football leagues, rosters, and player statistics.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
				<p class="description">
					<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				</p>
				<ol style="margin-left: 20px;">
					<li>
						<?php
						echo wp_kses_post(
							sprintf(
								/* translators: %s: URL to Yahoo Developer Network */
								__( 'Create a Yahoo app at <a href="%s" target="_blank">Yahoo Developer Network</a>', 'nvdigital-open-operator-system-oos' ),
								'https://developer.yahoo.com/apps/'
							)
						);
						?>
					</li>
					<li><?php esc_html_e( 'Set the redirect URI to match your WordPress site', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Copy your Client ID (Consumer Key) and Client Secret (Consumer Secret)', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Paste them into the fields above and save', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Click "Connect Yahoo Account" to authenticate via OAuth', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Use the Yahoo Fantasy Football tools to access your leagues', 'nvdigital-open-operator-system-oos' ); ?></li>
				</ol>
				<?php if ( $is_pro_active ) : ?>
					<p class="description" style="margin-top: 1rem;">
						<strong><?php esc_html_e( 'Available Tools:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><strong>yahoo_ff_auth</strong> - <?php esc_html_e( 'Authenticate with Yahoo and manage authorization tokens', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>yahoo_ff_get_leagues</strong> - <?php esc_html_e( 'Get your fantasy football leagues and team information', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				<?php else : ?>
					<p class="description" style="margin-top: 1rem; padding: 10px; background: #fff3cd; border-left: 4px solid #ffc107;">
						<strong><?php esc_html_e( 'Pro Feature:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						<?php esc_html_e( 'Yahoo Sports integration requires the Pro addon to be active.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				<?php endif; ?>
			</div>
		</td>
	</tr>
			<?php
		}

		/**
		 * Render ESPN Sports footer content.
		 */
		private function render_espn_sports_footer() {
			$settings      = WP_MCP_AI_Admin_Settings::get_settings();
			$has_espn_s2   = ! empty( $settings['espn_fantasy_espn_s2'] );
			$has_swid      = ! empty( $settings['espn_fantasy_swid'] );
			$has_both      = $has_espn_s2 && $has_swid;
			$is_pro_active = defined( 'WP_MCP_AI_PRO_VERSION' );
			?>
		<tr>
			<th scope="row"><?php esc_html_e( 'ESPN Sports Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td>
				<?php if ( $has_both ) : ?>
					<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #155724;">
							<span class="dashicons dashicons-yes" style="color: #155724;"></span>
							<strong><?php esc_html_e( 'ESPN Credentials Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
					</div>
					<p class="description">
						<?php
						echo wp_kses_post(
							__(
								'Your ESPN S2 and SWID cookies are saved. ESPN Fantasy tools can now access private leagues.',
								'nvdigital-open-operator-system-oos'
							)
						);
						?>
					</p>
				<?php elseif ( $has_espn_s2 || $has_swid ) : ?>
					<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #856404;">
							<span class="dashicons dashicons-warning" style="color: #856404;"></span>
							<strong><?php esc_html_e( 'Incomplete ESPN Configuration', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
					</div>
					<p class="description">
						<?php esc_html_e( 'Both ESPN S2 and SWID cookies are required to access private leagues. Please provide both values.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				<?php else : ?>
					<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #856404;">
							<span class="dashicons dashicons-info" style="color: #856404;"></span>
							<strong><?php esc_html_e( 'ESPN Credentials Not Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
					</div>
					<p class="description">
						<?php esc_html_e( 'ESPN S2 and SWID cookies are only required for private leagues. Public leagues can be accessed without authentication.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<th scope="row"></th>
			<td>
				<div style="margin: 1rem 0;">
					<h4><?php esc_html_e( 'About ESPN Sports Integration', 'nvdigital-open-operator-system-oos' ); ?></h4>
					<p class="description" style="margin-bottom: 10px;">
						<?php esc_html_e( 'Connect to ESPN Fantasy Football API to access league information, team rosters, standings, and player statistics. Public leagues work without authentication; private leagues require ESPN S2 and SWID cookies.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
					<p class="description">
						<strong><?php esc_html_e( 'Setup Instructions for Private Leagues:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li><?php esc_html_e( 'Log in to ESPN Fantasy at fantasy.espn.com in your browser', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Open your browser\'s Developer Tools (F12)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Go to the Application/Storage tab and find Cookies', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Locate the "espn_s2" cookie and copy its value', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Locate the "SWID" cookie and copy its value (includes curly braces)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Paste both values into the fields above and save', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
					<?php if ( $is_pro_active ) : ?>
						<p class="description" style="margin-top: 1rem;">
							<strong><?php esc_html_e( 'Available Tools:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ul style="list-style: disc; margin-left: 20px;">
							<li><strong>espn_fantasy_get_league</strong> - <?php esc_html_e( 'Retrieve ESPN Fantasy Football league information', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><strong>espn_fantasy_get_teams</strong> - <?php esc_html_e( 'Get all teams in an ESPN league', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><strong>espn_fantasy_get_roster</strong> - <?php esc_html_e( 'Get a team\'s roster with player details', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><strong>espn_fantasy_get_standings</strong> - <?php esc_html_e( 'Get league standings with win/loss records', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><strong>espn_fantasy_analyze_lineup</strong> - <?php esc_html_e( 'Analyze optimal lineup configurations', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><strong>espn_fantasy_sync_league</strong> - <?php esc_html_e( 'Sync ESPN league data to WordPress', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
					<?php else : ?>
						<p class="description" style="margin-top: 1rem; padding: 10px; background: #fff3cd; border-left: 4px solid #ffc107;">
							<strong><?php esc_html_e( 'Pro Feature:', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<?php esc_html_e( 'ESPN Sports integration requires the Pro addon to be active.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
					<?php endif; ?>
				</div>
			</td>
		</tr>
			<?php
		}

		/**
		 * Render remove.bg footer content.
		 */
		private function render_removebg_footer() {
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'remove.bg Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-removebg-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-removebg-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your remove.bg API key in the field above, then click "Test Connection" to verify it works. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<div style="margin: 1rem 0;">
						<h4><?php esc_html_e( 'About remove.bg Integration', 'nvdigital-open-operator-system-oos' ); ?></h4>
						<p class="description" style="margin-bottom: 10px;">
							<?php esc_html_e( 'Automatically remove backgrounds from images using AI-powered background removal service.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
						<p class="description">
							<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ol style="margin-left: 20px;">
							<li>
								<?php
								echo wp_kses_post(
									sprintf(
										/* translators: %s: URL to remove.bg API */
										__( 'Get your API key from <a href="%s" target="_blank">remove.bg API</a>', 'nvdigital-open-operator-system-oos' ),
										'https://www.remove.bg/api'
									)
								);
								?>
							</li>
							<li><?php esc_html_e( 'Free tier includes 50 API calls per month', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Paste your API key into the field above and save', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Click "Test Connection" to verify your API key', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Use the background removal tools with your images', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ol>
						<p class="description" style="margin-top: 1rem;">
							<strong><?php esc_html_e( 'Features:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ul style="list-style: disc; margin-left: 20px;">
							<li><?php esc_html_e( 'AI-powered background removal for images', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Supports various image formats (PNG, JPG, etc.)', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Alternative: Free Python rembg library (no API key needed)', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
					</div>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render PayHere footer content.
		 */
		private function render_payhere_footer() {
			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$has_credentials = ! empty( $settings['payhere_app_id'] ) && ! empty( $settings['payhere_app_secret'] );
			$is_sandbox      = ! empty( $settings['payhere_sandbox_mode'] );
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'PayHere Configuration', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $has_credentials ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'PayHere Credentials Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
								<?php if ( $is_sandbox ) : ?>
									<span style="margin-left: 10px; padding: 2px 8px; background: #fff3cd; color: #856404; border-radius: 3px; font-size: 12px;">
										<?php esc_html_e( 'Sandbox Mode', 'nvdigital-open-operator-system-oos' ); ?>
									</span>
								<?php else : ?>
									<span style="margin-left: 10px; padding: 2px 8px; background: #d1ecf1; color: #0c5460; border-radius: 3px; font-size: 12px;">
										<?php esc_html_e( 'Live Mode', 'nvdigital-open-operator-system-oos' ); ?>
									</span>
								<?php endif; ?>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Your PayHere credentials are configured. AI assistants can now retrieve payment information using the PayHere API.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php else : ?>
						<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #721c24;">
								<span class="dashicons dashicons-info" style="color: #721c24;"></span>
								<strong><?php esc_html_e( 'PayHere Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'To enable PayHere payment retrieval tools, configure your PayHere App ID and App Secret in the fields above, then save your settings.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'About PayHere Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'API credentials are obtained from PayHere Merchant Dashboard', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Supports retrieving payment information by order ID or transaction ID', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Sandbox mode allows testing without affecting live transactions', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Always disable sandbox mode before going to production', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
					<p class="description">
						<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li>
							<?php
							printf(
								/* translators: %s: URL to PayHere Settings */
								wp_kses_post( __( 'Go to <a href="%s" target="_blank">PayHere Merchant Settings</a>', 'nvdigital-open-operator-system-oos' ) ),
								esc_url( 'https://www.payhere.lk/merchant/settings/api-keys' )
							);
							?>
						</li>
						<li><?php esc_html_e( 'Navigate to "API Keys" section', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Copy your App ID and App Secret', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Paste them into the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Enable sandbox mode for testing (optional)', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Flowhub footer content.
		 */
		private function render_flowhub_footer() {
			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$has_credentials = ! empty( $settings['flowhub_api_key'] ) && ! empty( $settings['flowhub_client_id'] );
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Flowhub Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-flowhub-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-flowhub-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your Flowhub credentials in the fields above, then click "Test Connection" to verify they work. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Flowhub Configuration', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $has_credentials ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'Flowhub Credentials Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Your Flowhub credentials are configured. AI assistants can now access inventory, orders, customers, and products using the Flowhub API.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php else : ?>
						<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #721c24;">
								<span class="dashicons dashicons-info" style="color: #721c24;"></span>
								<strong><?php esc_html_e( 'Flowhub Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'To enable Flowhub cannabis dispensary integration tools, configure your Flowhub API credentials in the fields above, then save your settings.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'About Flowhub Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Flowhub is a cannabis dispensary POS and inventory management system', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Supports retrieving inventory, orders, customers, and products', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Supports creating orders and managing customer/product data', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Each dispensary location requires separate credentials', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Uses OAuth2 authentication for secure API access', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
					<p class="description">
						<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li>
							<?php
							printf(
								/* translators: %s: URL to Flowhub API Request Form */
								wp_kses_post( __( 'Fill out the <a href="%s" target="_blank">Flowhub API Integration Request Form</a>', 'nvdigital-open-operator-system-oos' ) ),
								esc_url( 'https://flowhub.com/api-integration-request' )
							);
							?>
						</li>
						<li><?php esc_html_e( 'Wait for Flowhub support to provide your API credentials', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Copy your API Key, Client ID, Client Secret, and Location ID', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Paste them into the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'If you manage multiple locations, repeat the process for each location', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
					<p class="description">
						<strong><?php esc_html_e( 'Available Flowhub Tools:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><strong>flowhub_get_inventory</strong> - <?php esc_html_e( 'Retrieve inventory data with filtering and pagination', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_get_orders</strong> - <?php esc_html_e( 'Retrieve orders and transactions', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_create_order</strong> - <?php esc_html_e( 'Create new dispensary orders', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_get_customers</strong> - <?php esc_html_e( 'Retrieve customer profiles', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_manage_customer</strong> - <?php esc_html_e( 'Create or update customer information', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_get_products</strong> - <?php esc_html_e( 'Retrieve product catalog', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><strong>flowhub_manage_product</strong> - <?php esc_html_e( 'Create or update product details', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Meta footer content.
		 */
		private function render_meta_footer() {
			$settings          = WP_MCP_AI_Admin_Settings::get_settings();
			$meta_connected    = ! empty( $settings['meta_access_token'] );
			$meta_user_name    = isset( $settings['meta_connected_user_name'] ) ? $settings['meta_connected_user_name'] : '';
			$has_credentials   = ! empty( $settings['meta_app_id'] ) && ! empty( $settings['meta_app_secret'] );
			$oauth_connect_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_meta_oauth_start' ),
				'wp_mcp_ai_meta_oauth_start'
			);
			$disconnect_url    = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_meta_disconnect' ),
				'wp_mcp_ai_meta_disconnect'
			);

			// Check for disconnect notice.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$meta_disconnected = isset( $_GET['meta_disconnected'] ) ? sanitize_text_field( wp_unslash( $_GET['meta_disconnected'] ) ) : '';
			?>
			<?php if ( $meta_disconnected ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-success inline" style="margin: 0 0 15px;">
						<p><?php esc_html_e( 'Disconnected from Meta. Your app credentials remain saved for future connections.', 'nvdigital-open-operator-system-oos' ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Meta Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $meta_connected ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'Connected to Meta', 'nvdigital-open-operator-system-oos' ); ?></strong>
								<?php if ( $meta_user_name ) : ?>
									<?php
									printf(
										/* translators: %s: Meta user name */
										esc_html__( 'as %s', 'nvdigital-open-operator-system-oos' ),
										'<code>' . esc_html( $meta_user_name ) . '</code>'
									);
									?>
								<?php endif; ?>
							</p>
						</div>
						<p>
							<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button">
								<?php esc_html_e( 'Reconnect Meta Account', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
							<a href="<?php echo esc_url( $disconnect_url ); ?>" class="button" style="margin-left: 5px;">
								<?php esc_html_e( 'Disconnect', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						</p>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Your Meta account is connected. You can now use Meta integration tools to manage Facebook Pages, Instagram posts, and WhatsApp Business messaging.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					<?php elseif ( $has_credentials ) : ?>
						<div style="padding: 10px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #856404;">
								<span class="dashicons dashicons-warning" style="color: #856404;"></span>
								<strong><?php esc_html_e( 'Meta Not Connected', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p>
							<a href="<?php echo esc_url( $oauth_connect_url ); ?>" class="button button-primary">
								<?php esc_html_e( 'Connect Meta Account', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						</p>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'Click the button above to authorize WP MCP AI to access your Meta account. You will be redirected to Facebook to grant permissions.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
						<p class="description">
							<strong><?php esc_html_e( 'Required Permissions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ul style="list-style: disc; margin-left: 20px;">
							<?php
							// Get scopes from OAuth handler constant.
							$scopes             = WP_MCP_AI_Meta_OAuth_Handler::META_OAUTH_SCOPES;
							$scope_descriptions = array(
								'pages_manage_posts' => __( 'Manage Facebook Page posts', 'nvdigital-open-operator-system-oos' ),
								'instagram_basic'    => __( 'Access Instagram account information', 'nvdigital-open-operator-system-oos' ),
								'instagram_content_publish' => __( 'Publish Instagram content', 'nvdigital-open-operator-system-oos' ),
								'whatsapp_business_management' => __( 'Manage WhatsApp Business account', 'nvdigital-open-operator-system-oos' ),
								'whatsapp_business_messaging' => __( 'Send WhatsApp Business messages', 'nvdigital-open-operator-system-oos' ),
							);
							foreach ( explode( ',', $scopes ) as $scope ) {
								$scope       = trim( $scope );
								$description = isset( $scope_descriptions[ $scope ] ) ? $scope_descriptions[ $scope ] : $scope;
								echo '<li>' . esc_html( $description ) . '</li>';
							}
							?>
						</ul>
					<?php else : ?>
						<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #721c24;">
								<span class="dashicons dashicons-info" style="color: #721c24;"></span>
								<strong><?php esc_html_e( 'Meta App Credentials Required', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php esc_html_e( 'Enter your Meta App ID and App Secret in the fields above, then save settings. After that, you can connect your Meta account using the button that will appear here.', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'Meta Platform Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Access Token is used for Facebook Page posts and Instagram business posts', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Business Account ID is required for WhatsApp Business API', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Create a Meta App at developers.facebook.com to get credentials', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Request appropriate permissions for posting and messaging', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render TikTok footer content.
		 */
		private function render_tiktok_footer() {
			?>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'TikTok Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Register your app at developers.tiktok.com', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Request video.share scope for posting videos', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Access tokens expire and need to be refreshed periodically', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render OpenTelemetry connection footer.
		 */
		private function render_opentelemetry_footer() {
			$otel_enabled = class_exists( 'WP_MCP_AI_Otel_Span_Exporter' ) && WP_MCP_AI_Otel_Span_Exporter::is_enabled();
			$endpoint     = class_exists( 'WP_MCP_AI_Otel_Span_Exporter' )
				? WP_MCP_AI_Otel_Span_Exporter::get_endpoint()
				: '';
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Export Status', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $otel_enabled ) : ?>
						<p>
							<span class="dashicons dashicons-yes-alt" style="color:#46b450;"></span>
							<strong><?php esc_html_e( 'Active', 'nvdigital-open-operator-system-oos' ); ?></strong>
							<?php if ( '' !== $endpoint ) : ?>
								&mdash; <code><?php echo esc_html( $endpoint ); ?></code>
							<?php endif; ?>
						</p>
						<p class="description"><?php esc_html_e( 'Spans for chat turns, tool calls, and SSE streams are being exported.', 'nvdigital-open-operator-system-oos' ); ?></p>
					<?php else : ?>
						<p>
							<span class="dashicons dashicons-minus" style="color:#aaa;"></span>
							<strong><?php esc_html_e( 'Inactive', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<p class="description"><?php esc_html_e( 'Enter an OTLP/HTTP endpoint above and save to enable span export.', 'nvdigital-open-operator-system-oos' ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Mailjet footer content.
		 */
		private function render_mailjet_footer() {
			$settings        = WP_MCP_AI_Admin_Settings::get_settings();
			$has_credentials = ! empty( $settings['mailjet_api_key'] ) && ! empty( $settings['mailjet_api_secret'] );
			$webhook_url     = rest_url( 'mcp-ai/v1/webhooks/mailjet' );
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Mailjet Status', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $has_credentials ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
						<p style="margin: 0; color: #155724;">
						<span class="dashicons dashicons-yes" style="color: #155724;"></span>
						<strong><?php esc_html_e( 'Mailjet API Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						</div>
						<p class="description">
						<?php
							echo wp_kses_post(
								__(
									'Your Mailjet API credentials are configured. You can now use email sending and campaign management tools.',
									'nvdigital-open-operator-system-oos'
								)
							);
						?>
					</p>
				<?php else : ?>
					<div style="padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 10px;">
					<p style="margin: 0; color: #721c24;">
					<span class="dashicons dashicons-info" style="color: #721c24;"></span>
					<strong><?php esc_html_e( 'Mailjet Not Configured', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					</div>
<p class="description">
					<?php esc_html_e( 'Enter your Mailjet API Key and Secret Key in the fields above, then save settings.', 'nvdigital-open-operator-system-oos' ); ?>
</p>
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Webhook URL', 'nvdigital-open-operator-system-oos' ); ?></th>
			<td>
				<input type="text" readonly value="<?php echo esc_url( $webhook_url ); ?>" style="width: 100%; max-width: 500px;" id="mailjet_webhook_url" />
				<button type="button" class="button" onclick="(function(btn){try{var input=document.getElementById('mailjet_webhook_url');if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(input.value).then(function(){btn.textContent='<?php esc_attr_e( 'Copied!', 'nvdigital-open-operator-system-oos' ); ?>';setTimeout(function(){btn.textContent='<?php esc_attr_e( 'Copy', 'nvdigital-open-operator-system-oos' ); ?>';},2000);}).catch(function(){input.select();document.execCommand('copy');btn.textContent='<?php esc_attr_e( 'Copied!', 'nvdigital-open-operator-system-oos' ); ?>';setTimeout(function(){btn.textContent='<?php esc_attr_e( 'Copy', 'nvdigital-open-operator-system-oos' ); ?>';},2000);});}else{input.select();document.execCommand('copy');btn.textContent='<?php esc_attr_e( 'Copied!', 'nvdigital-open-operator-system-oos' ); ?>';setTimeout(function(){btn.textContent='<?php esc_attr_e( 'Copy', 'nvdigital-open-operator-system-oos' ); ?>';},2000);}}catch(e){console.error('Copy failed:',e);alert('<?php esc_attr_e( 'Failed to copy. Please copy manually.', 'nvdigital-open-operator-system-oos' ); ?>');}})(this);">
					<?php esc_html_e( 'Copy', 'nvdigital-open-operator-system-oos' ); ?>
</button>
				<p class="description">
					<?php esc_html_e( 'Use this URL to configure webhooks in your Mailjet account for receiving event notifications (opens, clicks, bounces, etc.).', 'nvdigital-open-operator-system-oos' ); ?>
</p>
			</td>
		</tr>
		<tr>
			<th scope="row"></th>
			<td>
				<p class="description">
					<strong><?php esc_html_e( 'Mailjet Integration Setup:', 'nvdigital-open-operator-system-oos' ); ?></strong>
				</p>
				<ul style="list-style: disc; margin-left: 20px;">
					<li><?php esc_html_e( 'Mailjet uses Basic Authentication (API Key + Secret Key) - no OAuth required', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Get your API credentials from Mailjet account under Account Settings → REST API → API Key Management', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Verify your "From Email" address in Mailjet before sending emails', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Configure webhooks in Mailjet to receive real-time event notifications', 'nvdigital-open-operator-system-oos' ); ?></li>
					<li><?php esc_html_e( 'Supports transactional emails, campaigns, and contact management', 'nvdigital-open-operator-system-oos' ); ?></li>
				</ul>
</td>
			</td>
		</tr>
			<?php
		}

		/**
		 * Render Cloudways footer content.
		 */
		private function render_cloudways_footer() {
			$settings            = WP_MCP_AI_Admin_Settings::get_settings();
			$cloudways_connected = ! empty( $settings['cloudways_connected'] );
			$disconnect_url      = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_cloudways_disconnect' ),
				'wp_mcp_ai_cloudways_disconnect'
			);

			// Check for disconnect notice.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$cloudways_disconnected = isset( $_GET['cloudways_disconnected'] ) ? sanitize_text_field( wp_unslash( $_GET['cloudways_disconnected'] ) ) : '';
			?>
			<?php if ( $cloudways_disconnected ) : ?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-success inline" style="margin: 0 0 15px;">
						<p><?php esc_html_e( 'Disconnected from Cloudways. Your API credentials remain saved for future connections.', 'nvdigital-open-operator-system-oos' ); ?></p>
					</div>
				</td>
			</tr>
		<?php endif; ?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Cloudways Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $cloudways_connected ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'Connected to Cloudways', 'nvdigital-open-operator-system-oos' ); ?></strong>
								<?php if ( ! empty( $settings['cloudways_account_name'] ) ) : ?>
									<?php
									printf(
										/* translators: %s: Cloudways account name */
										esc_html__( 'as %s', 'nvdigital-open-operator-system-oos' ),
										'<code>' . esc_html( $settings['cloudways_account_name'] ) . '</code>'
									);
									?>
								<?php endif; ?>
							</p>
						</div>
					<?php endif; ?>
					<p>
						<button type="button" id="wp-mcp-ai-test-cloudways-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<?php if ( $cloudways_connected ) : ?>
							<a href="<?php echo esc_url( $disconnect_url ); ?>" class="button" style="margin-left: 5px;">
								<?php esc_html_e( 'Disconnect', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						<?php endif; ?>
						<span id="wp-mcp-ai-cloudways-test-result" style="margin-left: 10px;"></span>
					</p>
					<div id="wp-mcp-ai-cloudways-account-info" style="margin-top: 10px;"></div>
					<p class="description">
						<?php esc_html_e( 'Enter your Cloudways email and API key in the fields above, then click "Test Connection" to verify they work. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'Cloudways Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Get your API key from your Cloudways account settings', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Server ID and App ID can be found in your Cloudways dashboard', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'OAuth tokens are automatically refreshed when expired', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Render Cloudflare footer content.
		 */
		private function render_cloudflare_footer() {
			$settings             = WP_MCP_AI_Admin_Settings::get_settings();
			$has_api_token        = ! empty( $settings['cloudflare_api_token'] );
			$has_zone_id          = ! empty( $settings['cloudflare_zone_id'] );
			$cloudflare_connected = ! empty( $settings['cloudflare_connected'] );
			$pro_toolkit_enabled  = ! empty( $settings['enable_cloudflare_pro_toolkit'] );
			$is_pro_active        = defined( 'WP_MCP_AI_PRO_VERSION' );
			$disconnect_url       = wp_nonce_url(
				admin_url( 'admin-post.php?action=wp_mcp_ai_cloudflare_disconnect' ),
				'wp_mcp_ai_cloudflare_disconnect'
			);
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Cloudflare Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<?php if ( $cloudflare_connected && $has_api_token && $has_zone_id ) : ?>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'Connected to Cloudflare', 'nvdigital-open-operator-system-oos' ); ?></strong>
								<?php if ( ! empty( $settings['cloudflare_zone_name'] ) ) : ?>
									<?php
									printf(
										/* translators: %s: Cloudflare zone name */
										esc_html__( '- Zone: %s', 'nvdigital-open-operator-system-oos' ),
										'<code>' . esc_html( $settings['cloudflare_zone_name'] ) . '</code>'
									);
									?>
								<?php endif; ?>
							</p>
						</div>
					<?php endif; ?>
					<p>
						<button type="button" id="wp-mcp-ai-test-cloudflare-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<?php if ( $cloudflare_connected ) : ?>
							<a href="<?php echo esc_url( $disconnect_url ); ?>" class="button" style="margin-left: 5px;">
								<?php esc_html_e( 'Disconnect', 'nvdigital-open-operator-system-oos' ); ?>
							</a>
						<?php endif; ?>
						<span id="wp-mcp-ai-cloudflare-test-result" style="margin-left: 10px;"></span>
					</p>
					<div id="wp-mcp-ai-cloudflare-zone-info" style="margin-top: 10px;"></div>
					<p class="description">
						<?php esc_html_e( 'Enter your Cloudflare API token and Zone ID in the fields above, then click "Test Connection" to verify they work. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<?php if ( $pro_toolkit_enabled && $is_pro_active ) : ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'Pro Toolkit Status', 'nvdigital-open-operator-system-oos' ); ?></th>
					<td>
						<div style="padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; margin-bottom: 10px;">
							<p style="margin: 0; color: #155724;">
								<span class="dashicons dashicons-yes" style="color: #155724;"></span>
								<strong><?php esc_html_e( 'Cloudflare Pro Toolkit Active', 'nvdigital-open-operator-system-oos' ); ?></strong>
							</p>
						</div>
						<p class="description">
							<?php
							echo wp_kses_post(
								__(
									'The Cloudflare Pro Toolkit is enabled. AI assistants can now use advanced Cloudflare features including cache purging, zone management, and DNS operations.',
									'nvdigital-open-operator-system-oos'
								)
							);
							?>
						</p>
					</td>
				</tr>
			<?php endif; ?>
			<tr>
				<th scope="row"></th>
				<td>
					<p class="description">
						<strong><?php esc_html_e( 'Cloudflare Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ul style="list-style: disc; margin-left: 20px;">
						<li><?php esc_html_e( 'Create an API token in your Cloudflare dashboard under "My Profile" > "API Tokens"', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Token needs "Zone.Cache Purge" permission for cache management', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Find your Zone ID in the Overview page of your domain', 'nvdigital-open-operator-system-oos' ); ?></li>
						<?php if ( $is_pro_active || $pro_toolkit_enabled ) : ?>
							<li><?php esc_html_e( 'Pro Toolkit enables additional permissions: DNS edit, Zone settings, and Analytics read', 'nvdigital-open-operator-system-oos' ); ?></li>
						<?php endif; ?>
					</ul>
				</td>
			</tr>
			<?php
		}

		/**
		 * Override render_wrapper to include sub-tab navigation.
		 * Only renders when the 'connections' subtab is active in the Tools tab.
		 */
		public function render_wrapper() {
			// Only render this section when the 'connections' subtab is active in Tools.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter check.
			$current_subtab = isset( $_GET['subtab'] ) ? sanitize_key( wp_unslash( $_GET['subtab'] ) ) : '';

			// This section is embedded within Tools > Connections subtab.
			// Don't render if we're not in the connections subtab.
			if ( 'connections' !== $current_subtab ) {
				return;
			}

			$description       = $this->get_description();
			$documentation_url = $this->get_documentation_url();
			$subtab_groups     = $this->get_subtab_groups();
			$active_subtab     = $this->get_active_subtab();
			?>
			<div class="settings-section" id="section-<?php echo esc_attr( $this->get_id() ); ?>">
				<h2><?php echo esc_html( $this->get_title() ); ?></h2>
				<?php if ( $description ) : ?>
					<p class="section-description"><?php echo wp_kses_post( $description ); ?></p>
				<?php endif; ?>
				<?php if ( $documentation_url ) : ?>
					<p class="section-documentation">
						<span class="dashicons dashicons-book-alt" style="color: #2271b1;"></span>
						<a href="<?php echo esc_url( $documentation_url ); ?>" target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'View Documentation', 'nvdigital-open-operator-system-oos' ); ?>
							<span class="dashicons dashicons-external" style="font-size: 14px; text-decoration: none;"></span>
						</a>
					</p>
				<?php endif; ?>

				<div class="wp-mcp-ai-provider-subtabs">
					<nav class="wp-mcp-ai-subtab-nav" aria-label="<?php esc_attr_e( 'External tools settings sub-tabs', 'nvdigital-open-operator-system-oos' ); ?>">
						<?php foreach ( $subtab_groups as $group ) : ?>
							<?php
							// When rendered within Tools > Connections, preserve the connections subtab.

							// Otherwise link directly to the integration subtab.

							// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter for URL construction.
							$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'tools';
							// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only parameter for URL construction.
							$current_parent_subtab = isset( $_GET['subtab'] ) ? sanitize_key( wp_unslash( $_GET['subtab'] ) ) : '';

							$url_args = array(
								'page' => 'wp-mcp-ai-dashboard',
								'tab'  => $current_tab,
							);

							// If we're in the connections subtab, add it to maintain context.

							if ( 'connections' === $current_parent_subtab ) {
								$url_args['subtab']     = 'connections';
								$url_args['connection'] = $group['id'];
							} else {
								$url_args['subtab'] = $group['id'];
							}

							$subtab_url = add_query_arg( $url_args, admin_url( 'admin.php' ) );
							$is_active  = ( $group['id'] === $active_subtab );
							?>
							<a href="<?php echo esc_url( $subtab_url ); ?>"
								class="wp-mcp-ai-subtab <?php echo esc_attr( $is_active ? 'wp-mcp-ai-subtab-active' : '' ); ?>"
								data-subtab="<?php echo esc_attr( $group['id'] ); ?>">
								<span class="dashicons <?php echo esc_attr( $group['icon'] ); ?>"></span>
								<?php echo esc_html( $group['label'] ); ?>
							</a>
						<?php endforeach; ?>
					</nav>

					<!-- Hidden field to preserve subtab during form submission -->
					<input type="hidden" name="subtab_<?php echo esc_attr( $this->get_id() ); ?>" value="<?php echo esc_attr( $active_subtab ); ?>" />
					
					<?php
					// If accessed via connection parameter (e.g., from Tools > Connections),
					// preserve it for redirect after save.
					// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI state parameter, not used for data modification.
					$connection_param = isset( $_GET['connection'] ) ? sanitize_key( wp_unslash( $_GET['connection'] ) ) : '';
					if ( '' !== $connection_param ) :
						?>
						<input type="hidden" name="connection" value="<?php echo esc_attr( $connection_param ); ?>" />
						<?php
					endif;
					?>

					<div class="wp-mcp-ai-subtab-content">
						<table class="form-table" role="presentation">
							<?php $this->render(); ?>
						</table>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Render iSAMS footer content.
		 */
		private function render_isams_footer() {
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'iSAMS Connection', 'nvdigital-open-operator-system-oos' ); ?></th>
				<td>
					<p>
						<button type="button" id="wp-mcp-ai-test-isams-connection" class="button button-secondary">
							<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
						<span id="wp-mcp-ai-isams-test-result" style="margin-left: 10px;"></span>
					</p>
					<p class="description">
						<?php esc_html_e( 'Enter your iSAMS API credentials in the fields above, then click "Test Connection" to verify they work. You can test before saving.', 'nvdigital-open-operator-system-oos' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<div style="margin: 1rem 0;">
						<h4><?php esc_html_e( 'Available iSAMS Tools', 'nvdigital-open-operator-system-oos' ); ?></h4>
						<p class="description" style="margin-bottom: 10px;">
							<?php esc_html_e( 'The following AI tools are available when iSAMS is properly configured:', 'nvdigital-open-operator-system-oos' ); ?>
						</p>
						<ul style="margin-left: 1.5rem;">
							<li><strong>isams_query</strong> - <?php esc_html_e( 'Query iSAMS for pupils, employees, departments, houses, terms, subjects, year groups, and admission applicants', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
						<p class="description" style="margin-top: 1rem;">
							<strong><?php esc_html_e( 'About iSAMS Integration:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ul style="list-style: disc; margin-left: 20px;">
							<li><?php esc_html_e( 'API credentials are obtained from your iSAMS administrator', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Supports read-only access to school management data', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Access tokens are automatically cached for 55 minutes', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Requires Pro addon to be active', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ul>
						<p class="description" style="margin-top: 1rem;">
							<strong><?php esc_html_e( 'Setup Instructions:', 'nvdigital-open-operator-system-oos' ); ?></strong>
						</p>
						<ol style="margin-left: 20px;">
							<li><?php esc_html_e( 'Contact your iSAMS administrator to obtain API credentials', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Enter the iSAMS instance URL (e.g., https://yourschool.isams.cloud/)', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Enter your API Key and API Secret in the fields above', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Save your settings', 'nvdigital-open-operator-system-oos' ); ?></li>
							<li><?php esc_html_e( 'Click "Test Connection" to verify credentials work', 'nvdigital-open-operator-system-oos' ); ?></li>
						</ol>
					</div>
				</td>
			</tr>
			<?php
		}

		/**
		 * Validate section input.
		 *
		 * @param array $input Raw input.
		 * @return array|WP_Error Validated input or error.
		 */
		public function validate( $input ) {
			$errors = array();

			// Validate Crawl4AI URL.
			if ( isset( $input['crawl4ai_base_url'] ) && ! empty( $input['crawl4ai_base_url'] ) ) {
				$result = WP_MCP_AI_Settings_Validator::validate_url( $input['crawl4ai_base_url'] );
				if ( is_wp_error( $result ) ) {
					$errors[] = __( 'Crawl4AI Base URL: ', 'nvdigital-open-operator-system-oos' ) . $result->get_error_message();
				}
			}

			if ( ! empty( $errors ) ) {
				return new WP_Error( 'validation_error', implode( ' ', $errors ) );
			}

			return $input;
		}
	}
}
