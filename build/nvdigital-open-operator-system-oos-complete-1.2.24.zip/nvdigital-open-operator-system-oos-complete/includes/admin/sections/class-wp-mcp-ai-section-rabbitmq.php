<?php
/**
 * RabbitMQ Settings Section for NV oOS.
 *
 * Provides admin UI for configuring RabbitMQ integration settings
 * when deployed on Cloudways with RabbitMQ enabled.
 *
 * @package WP_MCP_AI
 * @since 1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load abstract section class.
require_once WP_MCP_AI_PATH . 'includes/admin/sections/abstract-wp-mcp-ai-settings-section.php';

/**
 * RabbitMQ Settings Section class.
 */
class WP_MCP_AI_Section_RabbitMQ extends WP_MCP_AI_Settings_Section {

	/**
	 * Whether AJAX handlers have been registered.
	 *
	 * @var bool
	 */
	private static $ajax_registered = false;

	/**
	 * Constructor.
	 *
	 * Registers admin AJAX handlers exactly once per request. The section is
	 * instantiated both by the settings registry and by the Orchestration
	 * section's inline rabbitmq view, so a static guard prevents duplicate
	 * wp_ajax_* callbacks.
	 */
	public function __construct() {
		if ( ! self::$ajax_registered ) {
			self::$ajax_registered = true;
			$this->register_ajax_handlers();
		}
	}

	/**
	 * Whether the RabbitMQ integration is enabled.
	 *
	 * Reads the saved setting (with the wp_mcp_ai_rabbitmq_enabled constant
	 * fallback) via the settings registry. Note: this class has no local
	 * settings property, so direct reads from $this->settings would always
	 * be empty.
	 *
	 * @return bool True when the integration is enabled.
	 */
	private function is_integration_enabled() {
		if ( defined( 'WP_MCP_AI_RABBITMQ_ENABLED' ) && WP_MCP_AI_RABBITMQ_ENABLED ) {
			return true;
		}

		return ! empty( WP_MCP_AI_Settings_Registry::get_setting( 'rabbitmq_enabled', false ) );
	}

	/**
	 * Get section ID.
	 *
	 * @return string Section ID.
	 */
	public function get_id() {
		return 'rabbitmq';
	}

	/**
	 * Get section title.
	 *
	 * @return string Section title.
	 */
	public function get_title() {
		return __( 'RabbitMQ', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get tab ID.
	 *
	 * @return string Tab ID.
	 */
	public function get_tab() {
		return 'orchestration';
	}

	/**
	 * Get section description.
	 *
	 * @return string Section description.
	 */
	public function get_description() {
		return __( 'Configure RabbitMQ message broker integration for distributed queue-based tool execution and job orchestration.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get documentation URL for this section.
	 *
	 * @return string Documentation URL.
	 */
	public function get_documentation_url() {
		return 'https://github.com/nvdigitalsolutions/mcp-ai-wpoos/blob/main/docs/features/federation/RABBITMQ-CLOUDWAYS-INTEGRATION-PLAN.md';
	}

	/**
	 * Get section icon.
	 *
	 * @return string Section icon (dashicon class).
	 */
	public function get_icon() {
		return 'dashicons-networking';
	}

	/**
	 * Get section priority.
	 *
	 * @return int Section priority (lower = earlier).
	 */
	public function get_priority() {
		return 85;
	}

	/**
	 * Check if section should be visible.
	 *
	 * @return bool Whether section is visible.
	 */
	public function is_visible() {
		// Only show if AMQP extension is available or RabbitMQ is configured.
		return extension_loaded( 'amqp' ) || $this->is_integration_enabled();
	}

	/**
	 * Get section fields.
	 *
	 * @return array Section fields configuration.
	 */
	public function get_fields() {
		$fields = array(
			// Connection Settings.
			'rabbitmq_enabled'             => array(
				'type'        => 'checkbox',
				'label'       => __( 'Enable RabbitMQ Integration', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Enable message queue integration for improved agentic workflow processing.', 'nvdigital-open-operator-system-oos' ),
				'default'     => false,
			),
			'rabbitmq_host'                => array(
				'type'        => 'text',
				'label'       => __( 'RabbitMQ Host', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Hostname of the RabbitMQ server. Usually "localhost" on Cloudways.', 'nvdigital-open-operator-system-oos' ),
				'default'     => 'localhost',
				'placeholder' => 'localhost',
			),
			'rabbitmq_port'                => array(
				'type'        => 'number',
				'label'       => __( 'RabbitMQ Port', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'AMQP port (default: 5672).', 'nvdigital-open-operator-system-oos' ),
				'default'     => 5672,
				'min'         => 1,
				'max'         => 65535,
			),
			'rabbitmq_username'            => array(
				'type'         => 'text',
				'label'        => __( 'RabbitMQ Username', 'nvdigital-open-operator-system-oos' ),
				'description'  => __( 'Username for RabbitMQ authentication.', 'nvdigital-open-operator-system-oos' ),
				'default'      => 'guest',
				'autocomplete' => 'new-password',
			),
			'rabbitmq_password'            => array(
				'type'         => 'password',
				'label'        => __( 'RabbitMQ Password', 'nvdigital-open-operator-system-oos' ),
				'description'  => __( 'Password for RabbitMQ authentication. Check Cloudways for your credentials.', 'nvdigital-open-operator-system-oos' ),
				'default'      => '',
				'autocomplete' => 'new-password',
			),
			'rabbitmq_vhost'               => array(
				'type'        => 'text',
				'label'       => __( 'Virtual Host', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'RabbitMQ virtual host (default: /).', 'nvdigital-open-operator-system-oos' ),
				'default'     => '/',
			),

			// Queue Settings.
			'rabbitmq_queue_prefix'        => array(
				'type'        => 'text',
				'label'       => __( 'Queue Prefix', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Prefix for queue names (useful for multisite).', 'nvdigital-open-operator-system-oos' ),
				'default'     => 'wp_mcp_ai',
			),
			'rabbitmq_priority_queues'     => array(
				'type'        => 'checkbox',
				'label'       => __( 'Enable Priority Queues', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Use separate queues for high, normal, and async priority tools.', 'nvdigital-open-operator-system-oos' ),
				'default'     => true,
			),

			// Worker Settings.
			'rabbitmq_parallel_execution'  => array(
				'type'        => 'checkbox',
				'label'       => __( 'Enable Parallel Tool Execution', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Allow independent tools to execute in parallel during agentic workflows.', 'nvdigital-open-operator-system-oos' ),
				'default'     => false,
			),
			'rabbitmq_worker_timeout'      => array(
				'type'        => 'number',
				'label'       => __( 'Worker Timeout (seconds)', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Maximum time for a worker to process a single tool.', 'nvdigital-open-operator-system-oos' ),
				'default'     => 300,
				'min'         => 30,
				'max'         => 3600,
			),

			// Retry Settings.
			'rabbitmq_max_retries'         => array(
				'type'        => 'number',
				'label'       => __( 'Max Retry Attempts', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Number of times to retry a failed tool execution.', 'nvdigital-open-operator-system-oos' ),
				'default'     => 3,
				'min'         => 0,
				'max'         => 10,
			),
			'rabbitmq_retry_delay'         => array(
				'type'        => 'number',
				'label'       => __( 'Retry Delay (ms)', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Initial delay between retries (uses exponential backoff).', 'nvdigital-open-operator-system-oos' ),
				'default'     => 1000,
				'min'         => 100,
				'max'         => 60000,
			),

			// Dead Letter Settings.
			'rabbitmq_dead_letter_enabled' => array(
				'type'        => 'checkbox',
				'label'       => __( 'Enable Dead Letter Queue', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Store failed messages for debugging and manual processing.', 'nvdigital-open-operator-system-oos' ),
				'default'     => true,
			),
			'rabbitmq_dead_letter_ttl'     => array(
				'type'        => 'number',
				'label'       => __( 'Dead Letter TTL (seconds)', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'How long to keep failed messages (default: 24 hours).', 'nvdigital-open-operator-system-oos' ),
				'default'     => 86400,
				'min'         => 3600,
				'max'         => 604800, // 7 days.
			),
		);

		return $fields;
	}

	/**
	 * Get field groups configuration.
	 *
	 * @return array Field groups.
	 */
	public function get_field_groups() {
		return array(
			array(
				'id'          => 'connection',
				'title'       => __( 'Connection Settings', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Configure connection to your RabbitMQ server.', 'nvdigital-open-operator-system-oos' ),
				'fields'      => array(
					'rabbitmq_enabled',
					'rabbitmq_host',
					'rabbitmq_port',
					'rabbitmq_username',
					'rabbitmq_password',
					'rabbitmq_vhost',
				),
			),
			array(
				'id'          => 'queues',
				'title'       => __( 'Queue Settings', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Configure queue behavior and naming.', 'nvdigital-open-operator-system-oos' ),
				'fields'      => array(
					'rabbitmq_queue_prefix',
					'rabbitmq_priority_queues',
				),
			),
			array(
				'id'          => 'execution',
				'title'       => __( 'Execution Settings', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Configure how tools are executed via queues.', 'nvdigital-open-operator-system-oos' ),
				'fields'      => array(
					'rabbitmq_parallel_execution',
					'rabbitmq_worker_timeout',
				),
			),
			array(
				'id'          => 'reliability',
				'title'       => __( 'Reliability Settings', 'nvdigital-open-operator-system-oos' ),
				'description' => __( 'Configure retry and dead letter handling.', 'nvdigital-open-operator-system-oos' ),
				'fields'      => array(
					'rabbitmq_max_retries',
					'rabbitmq_retry_delay',
					'rabbitmq_dead_letter_enabled',
					'rabbitmq_dead_letter_ttl',
				),
			),
		);
	}

	/**
	 * Render section content.
	 *
	 * Outputs the status widget (AMQP extension check, connection test
	 * button) followed by the settings fields grouped into Connection,
	 * Queue, Execution, and Reliability sections.
	 */
	public function render() {
		$this->render_status_widget();

		$fields        = $this->get_fields();
		$field_groups  = $this->get_field_groups();
		$rendered_keys = array();

		foreach ( $field_groups as $group ) {
			// Render group heading as a full-width separator row.
			?>
			<tr class="wp-mcp-ai-settings-group-header">
				<td colspan="2">
					<h3><?php echo esc_html( $group['title'] ); ?></h3>
					<?php if ( ! empty( $group['description'] ) ) : ?>
						<p class="description"><?php echo esc_html( $group['description'] ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
			<?php

			foreach ( $group['fields'] as $key ) {
				if ( isset( $fields[ $key ] ) ) {
					$this->render_field( $key, $fields[ $key ] );
					$rendered_keys[] = $key;
				}
			}
		}

		// Render any fields not covered by a group (safety net).
		foreach ( $fields as $key => $field ) {
			if ( ! in_array( $key, $rendered_keys, true ) ) {
				$this->render_field( $key, $field );
			}
		}
	}

	/**
	 * Suppress standalone wrapper rendering.
	 *
	 * The RabbitMQ settings are rendered inline as a view inside the
	 * Orchestration section (see WP_MCP_AI_Section_Orchestration::
	 * render_rabbitmq_view()). This override prevents the dashboard from
	 * rendering a duplicate section block.
	 *
	 * The section is still registered with WP_MCP_AI_Settings_Registry
	 * so that its fields participate in the save/sanitize loop.
	 */
	public function render_wrapper() {
		// No-op: rendered inline by the Orchestration section.
	}

	/**
	 * Render connection status widget.
	 */
	private function render_status_widget() {
		$rabbitmq_available = class_exists( 'WP_MCP_AI_RabbitMQ_Client' );
		$extension_loaded   = extension_loaded( 'amqp' );
		$enabled            = $this->is_integration_enabled();

		?>
		<div class="wp-mcp-ai-status-widget" style="background: #f9f9f9; border: 1px solid #ddd; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
			<h3 style="margin-top: 0;"><?php esc_html_e( 'RabbitMQ Status', 'nvdigital-open-operator-system-oos' ); ?></h3>

			<table class="widefat" style="margin-bottom: 15px;">
				<tbody>
					<tr>
						<td><strong><?php esc_html_e( 'PHP AMQP Extension', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
						<td>
							<?php if ( $extension_loaded ) : ?>
								<span style="color: green;">✓ <?php esc_html_e( 'Loaded', 'nvdigital-open-operator-system-oos' ); ?></span>
							<?php else : ?>
								<span style="color: red;">✗ <?php esc_html_e( 'Not Loaded', 'nvdigital-open-operator-system-oos' ); ?></span>
								<br><small><?php esc_html_e( 'Enable RabbitMQ on your Cloudways server to install this extension.', 'nvdigital-open-operator-system-oos' ); ?></small>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<td><strong><?php esc_html_e( 'Integration Enabled', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
						<td>
							<?php if ( $enabled ) : ?>
								<span style="color: green;">✓ <?php esc_html_e( 'Enabled', 'nvdigital-open-operator-system-oos' ); ?></span>
							<?php else : ?>
								<span style="color: gray;">○ <?php esc_html_e( 'Disabled', 'nvdigital-open-operator-system-oos' ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
					<?php if ( $enabled && $rabbitmq_available && $extension_loaded ) : ?>
						<tr>
							<td><strong><?php esc_html_e( 'Connection Status', 'nvdigital-open-operator-system-oos' ); ?></strong></td>
							<td id="rabbitmq-connection-status">
								<span style="color: gray;">○ <?php esc_html_e( 'Checking...', 'nvdigital-open-operator-system-oos' ); ?></span>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>

			<?php if ( $enabled && $extension_loaded ) : ?>
				<button type="button" class="button" id="test-rabbitmq-connection">
					<?php esc_html_e( 'Test Connection', 'nvdigital-open-operator-system-oos' ); ?>
				</button>
				<button type="button" class="button" id="setup-rabbitmq-infrastructure">
					<?php esc_html_e( 'Setup Queues', 'nvdigital-open-operator-system-oos' ); ?>
				</button>
			<?php endif; ?>

			<?php if ( ! $extension_loaded ) : ?>
				<div class="notice notice-warning inline" style="margin: 10px 0 0 0;">
					<p>
						<strong><?php esc_html_e( 'How to Enable RabbitMQ on Cloudways:', 'nvdigital-open-operator-system-oos' ); ?></strong>
					</p>
					<ol style="margin-left: 20px;">
						<li><?php esc_html_e( 'Go to your Cloudways Platform', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Navigate to Server Management → Settings & Packages', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Enable RabbitMQ under Advanced Settings', 'nvdigital-open-operator-system-oos' ); ?></li>
						<li><?php esc_html_e( 'Note the credentials provided', 'nvdigital-open-operator-system-oos' ); ?></li>
					</ol>
					<p>
						<a href="https://support.cloudways.com/en/articles/8680154-how-to-enable-rabbitmq-on-cloudways" target="_blank" rel="noopener">
							<?php esc_html_e( 'View Cloudways Documentation →', 'nvdigital-open-operator-system-oos' ); ?>
						</a>
					</p>
				</div>
			<?php endif; ?>
		</div>

		<?php
		if ( $enabled && $extension_loaded ) :
			$admin_nonce_js      = wp_json_encode( wp_create_nonce( 'wp_mcp_ai_admin' ) );
			$setting_up_js       = wp_json_encode( __( 'Setting up...', 'nvdigital-open-operator-system-oos' ) );
			$setup_complete_js   = wp_json_encode( __( 'RabbitMQ infrastructure setup complete!', 'nvdigital-open-operator-system-oos' ) );
			$setup_failed_js     = wp_json_encode( __( 'Setup failed: ', 'nvdigital-open-operator-system-oos' ) );
			$request_failed_js   = wp_json_encode( __( 'Request failed. Please try again.', 'nvdigital-open-operator-system-oos' ) );
			$setup_queues_js     = wp_json_encode( __( 'Setup Queues', 'nvdigital-open-operator-system-oos' ) );
			$checking_js         = wp_json_encode( __( 'Checking...', 'nvdigital-open-operator-system-oos' ) );
			$connected_js        = wp_json_encode( __( 'Connected', 'nvdigital-open-operator-system-oos' ) );
			$conn_failed_js      = wp_json_encode( __( 'Connection failed', 'nvdigital-open-operator-system-oos' ) );
			$req_failed_short_js = wp_json_encode( __( 'Request failed', 'nvdigital-open-operator-system-oos' ) );
			ob_start();
			?>
			jQuery(document).ready(function($) {
				// Test connection on page load.
				checkRabbitMQConnection();

				$('#test-rabbitmq-connection').on('click', function() {
					checkRabbitMQConnection();
				});

				$('#setup-rabbitmq-infrastructure').on('click', function() {
					var $button = $(this);
					$button.prop('disabled', true).text(<?php echo wp_json_encode( __( 'Setting up...', 'nvdigital-open-operator-system-oos' ) ); ?>);

					$.ajax({
						url: ajaxurl,
						method: 'POST',
						data: {
							action: 'wp_mcp_ai_rabbitmq_setup',
							nonce: <?php echo wp_json_encode( wp_create_nonce( 'wp_mcp_ai_admin' ) ); ?>
						},
						success: function(response) {
							if (response.success) {
								alert(<?php echo wp_json_encode( __( 'RabbitMQ infrastructure setup complete!', 'nvdigital-open-operator-system-oos' ) ); ?>);
							} else {
								alert(<?php echo wp_json_encode( __( 'Setup failed: ', 'nvdigital-open-operator-system-oos' ) ); ?> + (response.data.message || 'Unknown error'));
							}
						},
						error: function() {
							alert(<?php echo wp_json_encode( __( 'Request failed. Please try again.', 'nvdigital-open-operator-system-oos' ) ); ?>);
						},
						complete: function() {
							$button.prop('disabled', false).text(<?php echo wp_json_encode( __( 'Setup Queues', 'nvdigital-open-operator-system-oos' ) ); ?>);
						}
					});
				});

				function checkRabbitMQConnection() {
					var $status = $('#rabbitmq-connection-status');
					$status.html('<span style="color: gray;">○ ' + <?php echo wp_json_encode( __( 'Checking...', 'nvdigital-open-operator-system-oos' ) ); ?> + '</span>');

					$.ajax({
						url: ajaxurl,
						method: 'POST',
						data: {
							action: 'wp_mcp_ai_rabbitmq_health',
							nonce: <?php echo wp_json_encode( wp_create_nonce( 'wp_mcp_ai_admin' ) ); ?>
						},
						success: function(response) {
							if (response.success && response.data.status === 'healthy') {
								$status.html('<span style="color: green;">✓ ' + <?php echo wp_json_encode( __( 'Connected', 'nvdigital-open-operator-system-oos' ) ); ?> + '</span>');
							} else {
								var error = response.data.error || response.data.message || <?php echo wp_json_encode( __( 'Connection failed', 'nvdigital-open-operator-system-oos' ) ); ?>;
								$status.html('<span style="color: red;">✗ ' + error + '</span>');
							}
						},
						error: function() {
							$status.html('<span style="color: red;">✗ ' + <?php echo wp_json_encode( __( 'Request failed', 'nvdigital-open-operator-system-oos' ) ); ?> + '</span>');
						}
					});
				}
			});
			<?php
			$js = ob_get_clean();
			wp_print_inline_script_tag( $js );
		endif;
	}

	/**
	 * Register AJAX handlers.
	 */
	protected function register_ajax_handlers() {
		add_action( 'wp_ajax_wp_mcp_ai_rabbitmq_health', array( $this, 'ajax_health_check' ) );
		add_action( 'wp_ajax_wp_mcp_ai_rabbitmq_setup', array( $this, 'ajax_setup_infrastructure' ) );
	}

	/**
	 * AJAX handler for health check.
	 */
	public function ajax_health_check() {
		check_ajax_referer( 'wp_mcp_ai_admin', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		if ( ! class_exists( 'WP_MCP_AI_RabbitMQ_Client' ) ) {
			wp_send_json_error( array( 'message' => __( 'RabbitMQ client not loaded.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		$client = WP_MCP_AI_RabbitMQ_Client::get_instance();
		$status = $client->health_check();

		wp_send_json_success( $status );
	}

	/**
	 * AJAX handler for infrastructure setup.
	 */
	public function ajax_setup_infrastructure() {
		check_ajax_referer( 'wp_mcp_ai_admin', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		if ( ! class_exists( 'WP_MCP_AI_RabbitMQ_Client' ) ) {
			wp_send_json_error( array( 'message' => __( 'RabbitMQ client not loaded.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		try {
			$client = WP_MCP_AI_RabbitMQ_Client::get_instance();
			$client->setup_infrastructure();
			wp_send_json_success( array( 'message' => __( 'Infrastructure setup complete.', 'nvdigital-open-operator-system-oos' ) ) );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}
}
