<?php
/**
 * Pro License Management System
 *
 * Handles Pro license validation, activation, and feature gating.
 *
 * @package WP_MCP_AI
 * @since 1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pro License Class
 */
class WP_MCP_AI_Pro_License {

	/**
	 * License server URL
	 *
	 * @var string
	 */
	private $license_server_url;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->license_server_url = apply_filters( 'wp_mcp_ai_license_server_url', 'https://nvdigitalsolutions.com/api/licenses' );

		add_action( 'admin_init', array( $this, 'handle_license_activation' ) );
		add_action( 'admin_notices', array( $this, 'license_notices' ) );
		add_action( 'wp_mcp_ai_check_license', array( $this, 'check_license_validity' ) );

		// Schedule daily license check.
		if ( ! wp_next_scheduled( 'wp_mcp_ai_check_license' ) ) {
			wp_schedule_event( time(), 'daily', 'wp_mcp_ai_check_license' );
		}
	}

	/**
	 * Check if Pro is active
	 *
	 * All features included in the base plugin are fully available without any
	 * license key requirement, in compliance with WordPress.org guidelines.
	 * The constant WP_MCP_AI_PRO_DASHBOARD_ENABLED (default: true) allows
	 * site administrators to optionally disable Pro Dashboard features.
	 *
	 * @return bool
	 */
	public static function is_pro_active() {
		// All built-in features are fully available without a license key.
		// The constant provides an opt-out mechanism for administrators.
		if ( defined( 'WP_MCP_AI_PRO_DASHBOARD_ENABLED' ) && ! WP_MCP_AI_PRO_DASHBOARD_ENABLED ) {
			return false;
		}

		// Allow override via filter for testing/development (backward compatibility).
		return apply_filters( 'wp_mcp_ai_pro_dashboard_available', true );
	}

	/**
	 * Get Pro plan
	 *
	 * @return string
	 */
	public static function get_pro_plan() {
		return get_option( 'wp_mcp_ai_pro_plan', 'compliance' );
	}

	/**
	 * Check if feature is available
	 *
	 * All features included in the base plugin are fully available.
	 * This method determines which features belong to which plan tier
	 * for informational purposes and future external add-on support.
	 *
	 * The plan → feature table lives in `Nvoos\Core` so the WordPress
	 * plugin and the Laravel adapter cannot drift apart
	 * (`ProPlanCatalog`, Proposal 090-B, Phase 5.1).
	 *
	 * @param string $feature Feature name.
	 * @return bool
	 */
	public static function has_feature( $feature ) {
		if ( ! class_exists( 'Nvoos\\Core\\Domain\\Service\\Entitlement\\ProPlanCatalog' ) ) {
			// Fail closed: a build without lib/core must not grant a paid surface.
			return false;
		}

		return \Nvoos\Core\Domain\Service\Entitlement\ProPlanCatalog::allows(
			self::get_pro_plan(),
			(string) $feature
		);
	}

	/**
	 * Handle license activation
	 *
	 * @return void
	 */
	public function handle_license_activation() {
		if ( ! isset( $_POST['wp_mcp_ai_activate_license'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		check_admin_referer( 'wp_mcp_ai_license_activation', 'wp_mcp_ai_license_nonce' );

		$license_key = isset( $_POST['wp_mcp_ai_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['wp_mcp_ai_license_key'] ) ) : '';

		if ( empty( $license_key ) ) {
			add_settings_error(
				'wp_mcp_ai_license',
				'empty_license',
				__( 'Please enter a license key.', 'nvdigital-open-operator-system-oos' ),
				'error'
			);
			return;
		}

		$result = $this->activate_license( $license_key );

		if ( ! is_wp_error( $result ) && ! empty( $result['success'] ) ) {
			update_option( 'wp_mcp_ai_pro_license_key', $license_key, false );
			update_option( 'wp_mcp_ai_pro_license_status', 'valid' );
			update_option( 'wp_mcp_ai_pro_plan', $result['plan'] ?? 'compliance' );
			update_option( 'wp_mcp_ai_pro_license_expires', $result['expires'] ?? '' );

			add_settings_error(
				'wp_mcp_ai_license',
				'license_activated',
				__( 'License activated successfully!', 'nvdigital-open-operator-system-oos' ),
				'success'
			);
		} else {
			add_settings_error(
				'wp_mcp_ai_license',
				'activation_failed',
				is_wp_error( $result ) ? $result->get_error_message() : ( $result['message'] ?? __( 'License activation failed.', 'nvdigital-open-operator-system-oos' ) ),
				'error'
			);
		}
	}

	/**
	 * Activate license with server
	 *
	 * @param string $license_key License key.
	 * @return array
	 */
	private function activate_license( $license_key ) {
		$site_url = get_site_url();

		$response = wp_remote_post(
			$this->license_server_url . '/activate',
			array(
				'timeout' => 15,
				'body'    => array(
					'license_key' => $license_key,
					'site_url'    => $site_url,
					'product'     => 'nvdigital-open-operator-system-oos-pro',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'wp_mcp_ai_error', $response->get_error_message() );
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! $data || ! isset( $data['success'] ) ) {
			return new WP_Error( 'wp_mcp_ai_error', __( 'Invalid response from license server.', 'nvdigital-open-operator-system-oos' ) );
		}

		return $data;
	}

	/**
	 * Check license validity
	 *
	 * @return void
	 */
	public function check_license_validity() {
		$license_key = get_option( 'wp_mcp_ai_pro_license_key', '' );

		if ( empty( $license_key ) ) {
			return;
		}

		$site_url = get_site_url();

		$response = wp_remote_post(
			$this->license_server_url . '/check',
			array(
				'timeout' => 15,
				'body'    => array(
					'license_key' => $license_key,
					'site_url'    => $site_url,
					'product'     => 'nvdigital-open-operator-system-oos-pro',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( $data && isset( $data['status'] ) ) {
			update_option( 'wp_mcp_ai_pro_license_status', $data['status'] );

			if ( 'valid' !== $data['status'] ) {
				update_option( 'wp_mcp_ai_pro_license_expires', '' );
			} elseif ( isset( $data['expires'] ) ) {
				update_option( 'wp_mcp_ai_pro_license_expires', $data['expires'] );
			}
		}
	}

	/**
	 * Deactivate license
	 *
	 * @return array
	 */
	public function deactivate_license() {
		$license_key = get_option( 'wp_mcp_ai_pro_license_key', '' );
		$site_url    = get_site_url();

		$response = wp_remote_post(
			$this->license_server_url . '/deactivate',
			array(
				'timeout' => 15,
				'body'    => array(
					'license_key' => $license_key,
					'site_url'    => $site_url,
					'product'     => 'nvdigital-open-operator-system-oos-pro',
				),
			)
		);

		delete_option( 'wp_mcp_ai_pro_license_key' );
		delete_option( 'wp_mcp_ai_pro_license_status' );
		delete_option( 'wp_mcp_ai_pro_plan' );
		delete_option( 'wp_mcp_ai_pro_license_expires' );

		return array( 'success' => true );
	}

	/**
	 * Display license notices
	 *
	 * @return void
	 */
	public function license_notices() {
		// Only show license notices on NV oOS admin pages to avoid noise on unrelated admin pages.
		$screen = get_current_screen();
		if ( ! $screen || false === strpos( $screen->id, 'mcp-ai' ) ) {
			return;
		}

		$license_status  = get_option( 'wp_mcp_ai_pro_license_status', '' );
		$license_expires = get_option( 'wp_mcp_ai_pro_license_expires', '' );

		// Expiring soon notice.
		if ( 'valid' === $license_status && ! empty( $license_expires ) ) {
			$expires_timestamp = strtotime( $license_expires );
			$days_until_expiry = floor( ( $expires_timestamp - time() ) / DAY_IN_SECONDS );

			if ( $days_until_expiry > 0 && $days_until_expiry <= 30 ) {
				?>
				<div class="notice notice-warning is-dismissible">
					<p>
						<?php
						printf(
							/* translators: %d: number of days */
							esc_html__( 'Your NV oOS Pro license expires in %d days. Please renew to continue using Pro features.', 'nvdigital-open-operator-system-oos' ),
							(int) $days_until_expiry
						);
						?>
					</p>
				</div>
				<?php
			}
		}

		// Expired license notice.
		if ( 'expired' === $license_status ) {
			?>
			<div class="notice notice-error is-dismissible">
				<p>
					<?php esc_html_e( 'Your NV oOS Pro license has expired. Pro features are disabled. Please renew your license.', 'nvdigital-open-operator-system-oos' ); ?>
					<a href="<?php echo esc_url( apply_filters( 'wp_mcp_ai_pro_upgrade_url', 'https://nvdigitalsolutions.com/renew' ) ); ?>" class="button button-primary" style="margin-left: 10px;">
						<?php esc_html_e( 'Renew License', 'nvdigital-open-operator-system-oos' ); ?>
					</a>
				</p>
			</div>
			<?php
		}

		// Invalid license notice.
		if ( 'invalid' === $license_status ) {
			?>
			<div class="notice notice-error is-dismissible">
				<p>
					<?php esc_html_e( 'Your NV oOS Pro license is invalid. Pro features are disabled.', 'nvdigital-open-operator-system-oos' ); ?>
				</p>
			</div>
			<?php
		}
	}

	/**
	 * Render license activation form
	 *
	 * @return void
	 */
	public static function render_license_form() {
		$license_key    = get_option( 'wp_mcp_ai_pro_license_key', '' );
		$license_status = get_option( 'wp_mcp_ai_pro_license_status', '' );
		$plan           = self::get_pro_plan();
		$expires        = get_option( 'wp_mcp_ai_pro_license_expires', '' );

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'NV oOS Pro License', 'nvdigital-open-operator-system-oos' ); ?></h1>

			<?php settings_errors( 'wp_mcp_ai_license' ); ?>

			<?php if ( 'valid' === $license_status ) : ?>
				<div class="notice notice-success inline">
					<p>
						<strong><?php esc_html_e( 'Pro License Active', 'nvdigital-open-operator-system-oos' ); ?></strong><br>
						<?php
						printf(
							wp_kses(
								/* translators: %s: plan name */
								__( 'Plan: %s', 'nvdigital-open-operator-system-oos' ),
								array( 'strong' => array() )
							),
							'<strong>' . esc_html( ucfirst( $plan ) ) . '</strong>'
						);
						?>
						<br>
						<?php
						if ( ! empty( $expires ) ) {
							printf(
								/* translators: %s: expiration date */
								esc_html__( 'Expires: %s', 'nvdigital-open-operator-system-oos' ),
								esc_html( date_i18n( get_option( 'date_format' ), strtotime( $expires ) ) )
							);
						}
						?>
					</p>
				</div>

				<form method="post" action="">
					<?php wp_nonce_field( 'wp_mcp_ai_license_deactivation', 'wp_mcp_ai_license_nonce' ); ?>
					<table class="form-table">
						<tr>
							<th scope="row"><?php esc_html_e( 'License Key', 'nvdigital-open-operator-system-oos' ); ?></th>
							<td>
								<code><?php echo esc_html( str_repeat( '*', strlen( $license_key ) - 8 ) . substr( $license_key, -8 ) ); ?></code>
							</td>
						</tr>
					</table>
					<p class="submit">
						<button type="submit" name="wp_mcp_ai_deactivate_license" class="button button-secondary">
							<?php esc_html_e( 'Deactivate License', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
					</p>
				</form>
			<?php else : ?>
				<form method="post" action="">
					<?php wp_nonce_field( 'wp_mcp_ai_license_activation', 'wp_mcp_ai_license_nonce' ); ?>
					<table class="form-table">
						<tr>
							<th scope="row">
								<label for="wp_mcp_ai_license_key"><?php esc_html_e( 'License Key', 'nvdigital-open-operator-system-oos' ); ?></label>
							</th>
							<td>
								<input type="text"
									id="wp_mcp_ai_license_key"
									name="wp_mcp_ai_license_key"
									class="regular-text"
									value="<?php echo esc_attr( $license_key ); ?>"
									placeholder="XXXX-XXXX-XXXX-XXXX" />
								<p class="description">
									<?php
									printf(
										/* translators: %s: purchase URL */
										wp_kses_post( __( 'Enter your license key. Don\'t have one? <a href="%s" target="_blank">Purchase a license</a>', 'nvdigital-open-operator-system-oos' ) ),
										esc_url( apply_filters( 'wp_mcp_ai_pro_upgrade_url', 'https://nvdigitalsolutions.com/pricing' ) )
									);
									?>
								</p>
							</td>
						</tr>
					</table>
					<p class="submit">
						<button type="submit" name="wp_mcp_ai_activate_license" class="button button-primary">
							<?php esc_html_e( 'Activate License', 'nvdigital-open-operator-system-oos' ); ?>
						</button>
					</p>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}
}

// Initialize license system.
new WP_MCP_AI_Pro_License();
