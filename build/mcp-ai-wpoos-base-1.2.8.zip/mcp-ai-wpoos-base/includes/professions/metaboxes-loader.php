<?php
/**
 * Metaboxes loader for Profession CPT.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load base metabox class.
require_once WP_MCP_AI_PATH . 'includes/professions/metaboxes/class-wp-mcp-ai-profession-metabox-base.php';

// Load metabox implementations.
require_once WP_MCP_AI_PATH . 'includes/professions/metaboxes/class-wp-mcp-ai-profession-metabox-details.php';
require_once WP_MCP_AI_PATH . 'includes/professions/metaboxes/class-wp-mcp-ai-profession-metabox-expertise.php';
require_once WP_MCP_AI_PATH . 'includes/professions/metaboxes/class-wp-mcp-ai-profession-metabox-base-knowledge.php';
require_once WP_MCP_AI_PATH . 'includes/professions/metaboxes/class-wp-mcp-ai-profession-metabox-defaults.php';
require_once WP_MCP_AI_PATH . 'includes/professions/metaboxes/class-wp-mcp-ai-profession-metabox-playbook.php';
require_once WP_MCP_AI_PATH . 'includes/professions/metaboxes/class-wp-mcp-ai-profession-metabox-datasets.php';
require_once WP_MCP_AI_PATH . 'includes/professions/metaboxes/class-wp-mcp-ai-profession-metabox-agent-orchestration.php';
