<?php
/**
 * Google Calendar credential resolution.
 *
 * Resolves Google Calendar credentials from, in priority order:
 *
 * 1. A Pro Remote Sites connection identified by `connection_id`.
 * 2. Base-plugin settings (`wp_mcp_ai_settings`), the single-connection surface.
 * 3. The legacy `wp_mcp_ai_google_calendar_*` filters, so any site already
 *    injecting a service account or a pre-minted access token keeps working.
 * 4. Auto-fallback to the only enabled Remote Sites `google_calendar`
 *    connection with complete credentials when none of the above resolve —
 *    mirroring the Drive/Gmail auto-fallback so an omitted `connection_id`
 *    never reports Calendar as unconfigured while a healthy named
 *    connection exists.
 *
 * Centralising this prevents the copy-paste divergence visible between the Gmail
 * and Drive tools, where the same resolution block is duplicated inline in each
 * `execute()` with slightly different error codes.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 * @since     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/google/class-wp-mcp-ai-google-oauth-service.php';
require_once WP_MCP_AI_PATH . 'includes/google/class-wp-mcp-ai-google-calendar-client.php';
require_once WP_MCP_AI_PATH . 'includes/google/class-wp-mcp-ai-google-calendar-scopes.php';

if ( ! class_exists( 'WP_MCP_AI_Google_Calendar_Credentials' ) ) {
	/**
	 * Resolves Google Calendar credentials and builds configured API clients.
	 */
	class WP_MCP_AI_Google_Calendar_Credentials {

		/**
		 * Credential source: Pro Remote Sites connection.
		 *
		 * @var string
		 */
		const SOURCE_CONNECTION = 'connection';

		/**
		 * Credential source: base-plugin settings.
		 *
		 * @var string
		 */
		const SOURCE_SETTINGS = 'settings';

		/**
		 * Credential source: `wp_mcp_ai_google_calendar_*` filters.
		 *
		 * @var string
		 */
		const SOURCE_FILTER = 'filter';

		/**
		 * Remote Sites connection type slug for Google Calendar.
		 *
		 * @var string
		 */
		const CONNECTION_TYPE = 'google_calendar';

		/**
		 * Resolve credentials for a Calendar request.
		 *
		 * @since 1.0.0
		 *
		 * @param string              $connection_id Optional Remote Sites connection ID.
		 * @param array<string,mixed> $context       Optional tool context, forwarded to filters.
		 * @param array<string,mixed> $arguments     Optional tool arguments, forwarded to filters.
		 * @return array<string,mixed>|WP_Error {
		 *     Resolved credentials on success.
		 *
		 *     @type string $source         One of the SOURCE_* constants.
		 *     @type string $connection_id  Remote Sites connection ID when resolved
		 *                                  from a connection, otherwise empty.
		 *     @type string $connection_name Human-readable connection name, when
		 *                                  resolved from a connection.
		 *     @type string $client_id      OAuth client ID.
		 *     @type string $client_secret  OAuth client secret (plaintext).
		 *     @type string $refresh_token  OAuth refresh token (plaintext).
		 *     @type string $access_token   Pre-minted access token, when supplied by filter.
		 *     @type string $user_email     Authorised account email.
		 *     @type string $calendar_id    Default calendar identifier.
		 *     @type string $granted_scopes Space-delimited granted scopes.
		 *     @type string $scope_profile  Scope profile slug.
		 *     @type string $timezone       IANA timezone identifier.
		 *     @type string $cache_key      Stable identity for the access-token cache.
		 *     @type array  $service_account Service-account credentials, when supplied by filter.
		 * }
		 */
		public static function resolve( $connection_id = '', array $context = array(), array $arguments = array() ) {
			$connection_id = is_string( $connection_id ) ? sanitize_key( $connection_id ) : '';

			// The literal "settings" is the documented way to force the
			// settings-based credentials, mirroring the Gmail client.
			if ( 'settings' === $connection_id ) {
				$connection_id = '';
			}

			if ( '' !== $connection_id ) {
				return self::resolve_from_connection( $connection_id, $context );
			}

			// A restricted assistant can only use its allowed Remote Sites
			// connections. Auto-resolve an omitted connection_id to the only
			// allowed Google Calendar connection with usable credentials; the
			// site-wide settings and filter surfaces are refused (a client
			// cannot widen its own grant).
			if ( null !== self::get_allowed_connection_ids( $context ) ) {
				$auto = self::resolve_auto_connection( $context );

				if ( is_wp_error( $auto ) ) {
					return $auto;
				}

				if ( is_array( $auto ) ) {
					return $auto;
				}

				return new WP_Error(
					'wp_mcp_ai_calendar_no_allowed_connection',
					__( 'None of the Google Calendar connections enabled for this assistant have usable credentials. Enable a Google Calendar connection in the assistant editor (Remote Site Connections) and complete its OAuth flow under Remote Sites.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 403 )
				);
			}

			$settings = self::resolve_from_settings();

			if ( ! is_wp_error( $settings ) ) {
				return $settings;
			}

			$filtered = self::resolve_from_filters( $context, $arguments );

			if ( ! is_wp_error( $filtered ) ) {
				return $filtered;
			}

			// Self-correcting fallback: when no connection was named and neither
			// the settings nor the legacy filter surface has credentials, resolve
			// to the only enabled Remote Sites Google Calendar connection instead
			// of failing. Pro sites commonly keep Calendar credentials only
			// inside a named connection, and an omitted connection_id must then
			// use that connection rather than report the integration as
			// unconfigured (which previously led assistants to disable or remove
			// the perfectly valid connection).
			$auto = self::resolve_auto_connection( $context );

			if ( is_wp_error( $auto ) || is_array( $auto ) ) {
				return $auto;
			}

			// Prefer the settings-level error: it is the actionable one for admins.
			return $settings;
		}

		/**
		 * Resolve credentials from a Pro Remote Sites connection.
		 *
		 * @since 1.0.0
		 *
		 * @param string $connection_id Connection ID.
		 * @param array  $context       Optional execution context (assistant_id is honoured).
		 * @return array<string,mixed>|WP_Error
		 */
		protected static function resolve_from_connection( $connection_id, array $context = array() ) {
			if ( ! class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
				if ( ! defined( 'WP_MCP_AI_PRO_PATH' ) ) {
					return new WP_Error(
						'wp_mcp_ai_calendar_pro_required',
						__( 'Remote Site connections require the NV oOS Pro addon. Configure Google Calendar in Tools → Connections instead.', 'nvdigital-open-operator-system-oos' ),
						array( 'status' => 400 )
					);
				}

				$manager_file = WP_MCP_AI_PRO_PATH . 'includes/class-wp-mcp-ai-pro-remote-site-manager.php';

				if ( ! file_exists( $manager_file ) ) {
					return new WP_Error(
						'wp_mcp_ai_calendar_pro_required',
						__( 'The Remote Site connection manager is unavailable.', 'nvdigital-open-operator-system-oos' ),
						array( 'status' => 500 )
					);
				}

				require_once $manager_file;
			}

			$connection = WP_MCP_AI_Pro_Remote_Site_Manager::get_connection( $connection_id );

			if ( empty( $connection ) ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_connection_not_found',
					sprintf(
						/* translators: %s: connection ID. */
						__( 'Google Calendar connection "%s" was not found. Check your Remote Sites configuration.', 'nvdigital-open-operator-system-oos' ),
						$connection_id
					),
					array( 'status' => 404 )
				);
			}

			$type = isset( $connection['connection_type'] ) ? (string) $connection['connection_type'] : '';

			if ( '' !== $type && self::CONNECTION_TYPE !== $type ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_wrong_connection_type',
					sprintf(
						/* translators: %s: connection type slug. */
						__( 'Connection "%s" is not a Google Calendar connection. Select a Google Calendar connection type.', 'nvdigital-open-operator-system-oos' ),
						$type
					),
					array( 'status' => 400 )
				);
			}

			// Assistant-level restriction: an assistant with a configured Remote
			// Site Connections list may only use connections from that list.
			if ( ! self::is_connection_enabled_for_assistant( $connection_id, $context ) ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_connection_not_enabled',
					sprintf(
						/* translators: %s: connection name. */
						__( 'Google Calendar connection "%s" is not enabled for this assistant. Ask the user to enable it in the assistant editor under Remote Site Connections.', 'nvdigital-open-operator-system-oos' ),
						isset( $connection['name'] ) ? (string) $connection['name'] : $connection_id
					),
					array( 'status' => 403 )
				);
			}

			if ( isset( $connection['enabled'] ) && ! $connection['enabled'] ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_connection_disabled',
					__( 'This Google Calendar connection is disabled.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			$client_id     = isset( $connection['client_id'] ) ? trim( (string) $connection['client_id'] ) : '';
			$client_secret = isset( $connection['client_secret'] ) ? trim( (string) $connection['client_secret'] ) : '';
			$refresh_token = isset( $connection['refresh_token'] ) ? trim( (string) $connection['refresh_token'] ) : '';

			if ( '' !== $client_secret ) {
				$client_secret = WP_MCP_AI_Pro_Remote_Site_Manager::decrypt_value( $client_secret );
			}

			if ( '' !== $refresh_token ) {
				$refresh_token = WP_MCP_AI_Pro_Remote_Site_Manager::decrypt_value( $refresh_token );
			}

			if ( '' === $client_id || '' === $client_secret || '' === $refresh_token ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_connection_incomplete',
					__( 'This Google Calendar connection is not fully authorised. Open the connection and complete the OAuth flow.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			return array(
				'source'          => self::SOURCE_CONNECTION,
				'connection_id'   => $connection_id,
				'connection_name' => isset( $connection['name'] ) ? trim( (string) $connection['name'] ) : '',
				'client_id'       => $client_id,
				'client_secret'   => $client_secret,
				'refresh_token'   => $refresh_token,
				'access_token'    => '',
				'user_email'      => isset( $connection['user_email'] ) ? trim( (string) $connection['user_email'] ) : '',
				'calendar_id'     => isset( $connection['calendar_id'] ) && '' !== trim( (string) $connection['calendar_id'] )
					? trim( (string) $connection['calendar_id'] )
					: 'primary',
				'granted_scopes'  => isset( $connection['granted_scopes'] ) ? (string) $connection['granted_scopes'] : '',
				'scope_profile'   => WP_MCP_AI_Google_Calendar_Scopes::normalise_profile(
					isset( $connection['scope_profile'] ) ? $connection['scope_profile'] : ''
				),
				'timezone'        => self::default_timezone(),
				'cache_key'       => 'connection:' . $connection_id,
				'service_account' => array(),
			);
		}

		/**
		 * Resolve the assistant's allowed connection IDs from the execution context.
		 *
		 * Returns null when unrestricted (no assistant context, or the assistant
		 * has no configured Remote Site Connections list) — mirroring the
		 * remote_wp_connection semantics — or the allowed connection IDs as strings.
		 *
		 * @param array $context Execution context.
		 * @return array|null Allowed connection IDs, or null when unrestricted.
		 */
		private static function get_allowed_connection_ids( array $context ) {
			$assistant_id = isset( $context['assistant_id'] ) ? absint( $context['assistant_id'] ) : 0;

			if ( ! $assistant_id ) {
				return null;
			}

			$enabled_connections = get_post_meta( $assistant_id, '_wp_mcp_ai_pro_remote_connections', true );

			if ( ! is_array( $enabled_connections ) ) {
				// Not configured — legacy behaviour allows all connections.
				return null;
			}

			return array_map( 'strval', $enabled_connections );
		}

		/**
		 * Whether a connection is enabled for the assistant in the execution context.
		 *
		 * @param string $connection_id Connection ID.
		 * @param array  $context       Execution context.
		 * @return bool True when allowed (or unrestricted), false otherwise.
		 */
		private static function is_connection_enabled_for_assistant( $connection_id, array $context ) {
			$allowed_ids = self::get_allowed_connection_ids( $context );

			if ( null === $allowed_ids ) {
				return true;
			}

			return in_array( (string) $connection_id, $allowed_ids, true );
		}

		/**
		 * Find the Remote Sites Google Calendar connection to use when no
		 * connection_id was given and the settings-based credentials are absent.
		 *
		 * Returns null when no usable connection exists, the single enabled
		 * connection when exactly one does, or a WP_Error listing the candidates
		 * when several are enabled (ambiguous — the caller must name one).
		 *
		 * When the context carries a restricted assistant, only connections from
		 * the assistant's Remote Site Connections list are considered.
		 *
		 * @since 1.0.0
		 *
		 * @param array $context Optional execution context (assistant_id is honoured).
		 * @return array<string,mixed>|null|WP_Error
		 */
		private static function resolve_auto_connection( array $context = array() ) {
			if ( ! class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
				if ( ! defined( 'WP_MCP_AI_PRO_PATH' ) ) {
					// Without the Pro addon there are no Remote Sites connections.
					return null;
				}

				$manager_file = WP_MCP_AI_PRO_PATH . 'includes/class-wp-mcp-ai-pro-remote-site-manager.php';

				if ( ! file_exists( $manager_file ) ) {
					return null;
				}

				require_once $manager_file;
			}

			$allowed_ids = self::get_allowed_connection_ids( $context );
			$candidates  = array();

			foreach ( WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections() as $candidate_id => $connection ) {
				if ( ! is_array( $connection ) ) {
					continue;
				}

				if ( null !== $allowed_ids && ! in_array( (string) $candidate_id, $allowed_ids, true ) ) {
					continue;
				}

				$connection_type = isset( $connection['connection_type'] ) ? sanitize_key( $connection['connection_type'] ) : '';

				if ( self::CONNECTION_TYPE !== $connection_type || empty( $connection['enabled'] ) ) {
					continue;
				}

				$candidate_client_id = isset( $connection['client_id'] ) ? trim( (string) $connection['client_id'] ) : '';
				$candidate_secret    = isset( $connection['client_secret'] ) ? trim( (string) $connection['client_secret'] ) : '';
				$candidate_refresh   = isset( $connection['refresh_token'] ) ? trim( (string) $connection['refresh_token'] ) : '';

				if ( '' === $candidate_client_id || '' === $candidate_secret || '' === $candidate_refresh ) {
					continue;
				}

				$candidates[ (string) $candidate_id ] = $connection;
			}

			if ( empty( $candidates ) ) {
				return null;
			}

			if ( count( $candidates ) > 1 ) {
				$labels = array();

				foreach ( $candidates as $candidate_id => $connection ) {
					$labels[] = sprintf(
						'%1$s (%2$s)',
						(string) $candidate_id,
						isset( $connection['name'] ) ? (string) $connection['name'] : (string) $candidate_id
					);
				}

				return new WP_Error(
					'wp_mcp_ai_calendar_ambiguous_connection',
					sprintf(
						/* translators: %s: comma-separated connection IDs and names. */
						__( 'Multiple Google Calendar connections are enabled and healthy, but no connection_id was given — the tool will not guess which calendar to use. Pass one of: %s. Their names and enabled state are listed under Remote Sites.', 'nvdigital-open-operator-system-oos' ),
						implode( ', ', $labels )
					)
				);
			}

			$auto_id         = (string) array_key_first( $candidates );
			$auto_connection = $candidates[ $auto_id ];

			return array(
				'source'          => self::SOURCE_CONNECTION,
				'connection_id'   => $auto_id,
				'connection_name' => isset( $auto_connection['name'] ) ? trim( (string) $auto_connection['name'] ) : $auto_id,
				'client_id'       => trim( (string) $auto_connection['client_id'] ),
				'client_secret'   => WP_MCP_AI_Pro_Remote_Site_Manager::decrypt_value( trim( (string) $auto_connection['client_secret'] ) ),
				'refresh_token'   => WP_MCP_AI_Pro_Remote_Site_Manager::decrypt_value( trim( (string) $auto_connection['refresh_token'] ) ),
				'access_token'    => '',
				'user_email'      => isset( $auto_connection['user_email'] ) ? trim( (string) $auto_connection['user_email'] ) : '',
				'calendar_id'     => isset( $auto_connection['calendar_id'] ) && '' !== trim( (string) $auto_connection['calendar_id'] )
					? trim( (string) $auto_connection['calendar_id'] )
					: 'primary',
				'granted_scopes'  => isset( $auto_connection['granted_scopes'] ) ? (string) $auto_connection['granted_scopes'] : '',
				'scope_profile'   => WP_MCP_AI_Google_Calendar_Scopes::normalise_profile(
					isset( $auto_connection['scope_profile'] ) ? $auto_connection['scope_profile'] : ''
				),
				'timezone'        => self::default_timezone(),
				'cache_key'       => 'connection:' . $auto_id,
				'service_account' => array(),
			);
		}

		/**
		 * Resolve credentials from base-plugin settings.
		 *
		 * @since 1.0.0
		 *
		 * @return array<string,mixed>|WP_Error
		 */
		protected static function resolve_from_settings() {
			if ( ! class_exists( 'WP_MCP_AI_Admin_Settings' ) ) {
				require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-admin-settings.php';
			}

			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			$client_id     = isset( $settings['google_calendar_client_id'] ) ? trim( (string) $settings['google_calendar_client_id'] ) : '';
			$client_secret = isset( $settings['google_calendar_client_secret'] ) ? trim( (string) $settings['google_calendar_client_secret'] ) : '';
			$refresh_token = isset( $settings['google_calendar_refresh_token'] ) ? trim( (string) $settings['google_calendar_refresh_token'] ) : '';

			if ( '' === $client_id || '' === $client_secret || '' === $refresh_token ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_missing_credentials',
					__( 'Google Calendar is not connected. Open Tools → Connections → Google Calendar, save your OAuth client ID and secret, then click Connect. Pro sites can also use a Google Calendar connection under Remote Sites.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			$calendar_id = isset( $settings['google_calendar_default_calendar_id'] )
				? trim( (string) $settings['google_calendar_default_calendar_id'] )
				: '';

			$timezone = isset( $settings['google_calendar_timezone'] ) ? trim( (string) $settings['google_calendar_timezone'] ) : '';

			return array(
				'source'          => self::SOURCE_SETTINGS,
				'connection_id'   => '',
				'connection_name' => '',
				'client_id'       => $client_id,
				'client_secret'   => $client_secret,
				'refresh_token'   => $refresh_token,
				'access_token'    => '',
				'user_email'      => isset( $settings['google_calendar_user_email'] ) ? trim( (string) $settings['google_calendar_user_email'] ) : '',
				'calendar_id'     => '' !== $calendar_id ? $calendar_id : 'primary',
				'granted_scopes'  => isset( $settings['google_calendar_granted_scopes'] ) ? (string) $settings['google_calendar_granted_scopes'] : '',
				'scope_profile'   => WP_MCP_AI_Google_Calendar_Scopes::normalise_profile(
					isset( $settings['google_calendar_scope_profile'] ) ? $settings['google_calendar_scope_profile'] : ''
				),
				'timezone'        => '' !== $timezone ? $timezone : self::default_timezone(),
				'cache_key'       => 'settings:' . get_current_blog_id(),
				'service_account' => array(),
			);
		}

		/**
		 * Resolve credentials from the legacy filter surface.
		 *
		 * Preserves backward compatibility with sites that supplied a pre-minted
		 * access token or a Google service account via filters before connections
		 * existed. Service accounts cannot be used with consumer `@gmail.com`
		 * accounts — domain-wide delegation is authorised only in the Google
		 * Workspace Admin console.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string,mixed> $context   Tool context.
		 * @param array<string,mixed> $arguments Tool arguments.
		 * @return array<string,mixed>|WP_Error
		 */
		protected static function resolve_from_filters( array $context = array(), array $arguments = array() ) {
			/**
			 * Filters a pre-minted Google Calendar access token.
			 *
			 * @since 1.0.0
			 *
			 * @param string $token     Access token. Default empty.
			 * @param array  $context   Tool context.
			 * @param array  $arguments Tool arguments.
			 */
			$token = apply_filters( 'wp_mcp_ai_google_calendar_access_token', '', $context, $arguments, null );
			$token = is_string( $token ) ? trim( $token ) : '';

			/**
			 * Filters Google service-account credentials for Calendar access.
			 *
			 * @since 1.0.0
			 *
			 * @param array $credentials Service-account credentials. Default empty.
			 * @param array $context     Tool context.
			 * @param array $arguments   Tool arguments.
			 */
			$service_account = apply_filters( 'wp_mcp_ai_google_calendar_service_account_credentials', array(), $context, $arguments, null );
			$service_account = is_array( $service_account ) ? $service_account : array();

			if ( '' === $token && empty( $service_account ) ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_missing_credentials',
					__( 'Google Calendar credentials were not provided.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			/**
			 * Filters the default Google Calendar identifier.
			 *
			 * @since 1.0.0
			 *
			 * @param string $calendar_id Calendar identifier. Default empty.
			 * @param array  $context     Tool context.
			 * @param array  $arguments   Tool arguments.
			 */
			$calendar_id = apply_filters( 'wp_mcp_ai_google_calendar_default_calendar_id', '', $context, $arguments, null );
			$calendar_id = is_string( $calendar_id ) ? sanitize_text_field( $calendar_id ) : '';

			return array(
				'source'          => self::SOURCE_FILTER,
				'connection_id'   => '',
				'connection_name' => '',
				'client_id'       => '',
				'client_secret'   => '',
				'refresh_token'   => '',
				'access_token'    => $token,
				'user_email'      => '',
				'calendar_id'     => '' !== $calendar_id ? $calendar_id : 'primary',
				// Filter-supplied credentials predate scope tracking; treat as unrestricted.
				'granted_scopes'  => '',
				'scope_profile'   => WP_MCP_AI_Google_Calendar_Scopes::DEFAULT_PROFILE,
				'timezone'        => self::default_timezone(),
				'cache_key'       => 'filter:' . get_current_blog_id(),
				'service_account' => $service_account,
			);
		}

		/**
		 * Build a configured Calendar API client from resolved credentials.
		 *
		 * The token provider is a closure so the access token is minted lazily and
		 * only when a request is actually made.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string,mixed> $credentials Output of `resolve()`.
		 * @param array<string,mixed> $options     Optional client options.
		 * @return WP_MCP_AI_Google_Calendar_Client|WP_Error
		 */
		public static function make_client( array $credentials, array $options = array() ) {
			$access_token    = isset( $credentials['access_token'] ) ? (string) $credentials['access_token'] : '';
			$service_account = isset( $credentials['service_account'] ) ? (array) $credentials['service_account'] : array();

			if ( '' !== $access_token ) {
				$provider = $access_token;
			} elseif ( ! empty( $service_account ) ) {
				$provider = static function () use ( $service_account, $credentials ) {
					return self::mint_service_account_token( $service_account, $credentials );
				};
			} else {
				$client_id     = isset( $credentials['client_id'] ) ? (string) $credentials['client_id'] : '';
				$client_secret = isset( $credentials['client_secret'] ) ? (string) $credentials['client_secret'] : '';
				$refresh_token = isset( $credentials['refresh_token'] ) ? (string) $credentials['refresh_token'] : '';
				$cache_key     = isset( $credentials['cache_key'] ) ? (string) $credentials['cache_key'] : '';

				if ( '' === $client_id || '' === $client_secret || '' === $refresh_token ) {
					return new WP_Error(
						'wp_mcp_ai_calendar_missing_credentials',
						__( 'Google Calendar credentials are incomplete.', 'nvdigital-open-operator-system-oos' ),
						array( 'status' => 400 )
					);
				}

				$provider = static function () use ( $client_id, $client_secret, $refresh_token, $cache_key ) {
					return WP_MCP_AI_Google_OAuth_Service::mint_access_token(
						array(
							'client_id'     => $client_id,
							'client_secret' => $client_secret,
							'refresh_token' => $refresh_token,
							'cache_key'     => $cache_key,
						)
					);
				};
			}

			// Attribute per-user quota to the impersonated account where known.
			if ( ! isset( $options['quota_user'] ) && ! empty( $credentials['user_email'] ) ) {
				$options['quota_user'] = (string) $credentials['user_email'];
			}

			return new WP_MCP_AI_Google_Calendar_Client( $provider, $options );
		}

		/**
		 * Mint an access token from Google service-account credentials.
		 *
		 * Uses the JWT bearer grant with an optional `sub` claim for domain-wide
		 * delegation.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string,mixed> $service_account Service-account credentials.
		 * @param array<string,mixed> $credentials     Resolved credential bundle.
		 * @return string|WP_Error Access token or WP_Error.
		 */
		protected static function mint_service_account_token( array $service_account, array $credentials ) {
			$client_email = isset( $service_account['client_email'] ) ? sanitize_email( $service_account['client_email'] ) : '';
			$private_key  = isset( $service_account['private_key'] ) ? trim( (string) $service_account['private_key'] ) : '';
			$token_uri    = isset( $service_account['token_uri'] ) ? esc_url_raw( $service_account['token_uri'] ) : '';
			$delegated    = isset( $service_account['delegated_email'] ) ? sanitize_email( $service_account['delegated_email'] ) : '';

			if ( '' === $client_email || '' === $private_key ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_invalid_credentials',
					__( 'Incomplete Google service account credentials.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 500 )
				);
			}

			if ( '' === $token_uri ) {
				$token_uri = WP_MCP_AI_Google_OAuth_Service::TOKEN_ENDPOINT;
			}

			$scopes = isset( $service_account['scopes'] ) ? $service_account['scopes'] : '';

			if ( is_array( $scopes ) ) {
				$scopes = implode( ' ', array_filter( array_map( 'trim', $scopes ) ) );
			} else {
				$scopes = trim( (string) $scopes );
			}

			if ( '' === $scopes ) {
				$profile = isset( $credentials['scope_profile'] ) ? (string) $credentials['scope_profile'] : '';
				$scopes  = WP_MCP_AI_Google_Calendar_Scopes::get_profile_scope_string( $profile );
			}

			$cache_key = 'sa:' . md5( $client_email . '|' . $delegated . '|' . $scopes );
			$transient = 'wp_mcp_ai_google_access_token_' . md5( $cache_key );
			$cached    = get_transient( $transient );

			if ( is_string( $cached ) && '' !== $cached ) {
				return $cached;
			}

			$now    = time();
			$claims = array(
				'iss'   => $client_email,
				'scope' => $scopes,
				'aud'   => $token_uri,
				'iat'   => $now,
				'exp'   => $now + 3600,
			);

			if ( '' !== $delegated ) {
				$claims['sub'] = $delegated;
			}

			$assertion = self::build_jwt_assertion( $claims, $private_key );

			if ( is_wp_error( $assertion ) ) {
				return $assertion;
			}

			$response = wp_remote_post(
				$token_uri,
				array(
					'timeout' => WP_MCP_AI_Google_OAuth_Service::DEFAULT_TIMEOUT,
					'headers' => array(
						'Content-Type' => 'application/x-www-form-urlencoded',
						'Accept'       => 'application/json',
					),
					'body'    => array(
						'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
						'assertion'  => $assertion,
					),
				)
			);

			if ( is_wp_error( $response ) ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_token_error',
					__( 'Unable to obtain a Google access token for the service account.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 500 )
				);
			}

			$status = (int) wp_remote_retrieve_response_code( $response );
			$data   = json_decode( wp_remote_retrieve_body( $response ), true );
			$data   = is_array( $data ) ? $data : array();

			if ( $status < 200 || $status >= 300 || empty( $data['access_token'] ) ) {
				$message = __( 'Google rejected the service account token request.', 'nvdigital-open-operator-system-oos' );

				if ( ! empty( $data['error_description'] ) ) {
					$message = sprintf( '%s %s', $message, (string) $data['error_description'] );
				}

				return new WP_Error(
					'wp_mcp_ai_calendar_token_error',
					$message,
					array(
						'status'   => $status,
						'response' => $data,
					)
				);
			}

			$access_token = (string) $data['access_token'];
			$expires_in   = isset( $data['expires_in'] ) ? absint( $data['expires_in'] ) : 3600;
			$ttl          = $expires_in - WP_MCP_AI_Google_OAuth_Service::TOKEN_CACHE_MARGIN;

			if ( $ttl > 0 ) {
				set_transient( $transient, $access_token, $ttl );
			}

			return $access_token;
		}

		/**
		 * Build a signed RS256 JWT assertion.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string,mixed> $claims      JWT claim set.
		 * @param string              $private_key PEM-encoded private key.
		 * @return string|WP_Error Assertion or WP_Error.
		 */
		protected static function build_jwt_assertion( array $claims, $private_key ) {
			if ( ! function_exists( 'openssl_sign' ) ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_signing_unavailable',
					__( 'The OpenSSL extension is required to sign Google service account assertions.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 500 )
				);
			}

			$segments = array(
				self::base64url_encode(
					wp_json_encode(
						array(
							'alg' => 'RS256',
							'typ' => 'JWT',
						)
					)
				),
				self::base64url_encode( wp_json_encode( $claims ) ),
			);

			$signature = '';

			if ( ! openssl_sign( implode( '.', $segments ), $signature, $private_key, 'sha256' ) ) {
				return new WP_Error(
					'wp_mcp_ai_calendar_signing_failed',
					__( 'Unable to sign the Google service account assertion.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 500 )
				);
			}

			$segments[] = self::base64url_encode( $signature );

			return implode( '.', $segments );
		}

		/**
		 * Base64url-encode a value without padding.
		 *
		 * @since 1.0.0
		 *
		 * @param string $data Raw data.
		 * @return string Encoded value.
		 */
		protected static function base64url_encode( $data ) {
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- JWT encoding, not obfuscation.
			return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
		}

		/**
		 * Resolve the site's IANA timezone identifier.
		 *
		 * Always sending an explicit `timeZone` avoids depending on the calendar's
		 * implicit default, which changes silently if the user edits their Google
		 * Calendar settings.
		 *
		 * @since 1.0.0
		 *
		 * @return string IANA timezone identifier.
		 */
		public static function default_timezone() {
			$timezone = wp_timezone_string();

			// `wp_timezone_string()` can return a UTC offset such as "+05:30",
			// which the Calendar API rejects — it requires an IANA name.
			if ( '' === $timezone || preg_match( '/^[+-]\d{2}:\d{2}$/', $timezone ) ) {
				return 'UTC';
			}

			return $timezone;
		}

		/**
		 * Assert that resolved credentials carry a required scope.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string,mixed> $credentials Resolved credentials.
		 * @param string              $required    Required scope URL.
		 * @return true|WP_Error True when satisfied, WP_Error otherwise.
		 */
		public static function require_scope( array $credentials, $required ) {
			$granted = isset( $credentials['granted_scopes'] ) ? (string) $credentials['granted_scopes'] : '';

			if ( WP_MCP_AI_Google_Calendar_Scopes::has_scope( $granted, $required ) ) {
				return true;
			}

			return WP_MCP_AI_Google_Calendar_Scopes::missing_scope_error( $required );
		}

		/**
		 * Resolve the effective calendar identifier for a request.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string,mixed> $credentials Resolved credentials.
		 * @param string              $override    Optional per-request calendar ID.
		 * @return string Calendar identifier.
		 */
		public static function resolve_calendar_id( array $credentials, $override = '' ) {
			$override = is_string( $override ) ? sanitize_text_field( trim( $override ) ) : '';

			if ( '' !== $override ) {
				return $override;
			}

			$configured = isset( $credentials['calendar_id'] ) ? trim( (string) $credentials['calendar_id'] ) : '';

			return '' !== $configured ? $configured : 'primary';
		}
	}
}
