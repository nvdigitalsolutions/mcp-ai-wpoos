/**
 * WP MCP AI Assistant Builder Blocks for Gutenberg
 *
 * Registers blocks for the AI Assistant Builder in the Gutenberg editor.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

( function ( blocks, element, blockEditor, components, i18n ) {
	'use strict';

	const el = element.createElement;
	const __ = i18n.__;
	const InspectorControls = blockEditor.InspectorControls;
	const PanelBody = components.PanelBody;
	const SelectControl = components.SelectControl;
	const ToggleControl = components.ToggleControl;
	const TextControl = components.TextControl;
	const RangeControl = components.RangeControl;

	// Get localized data.
	const data = window.wpMcpAiBlocks || {};
	const assistants = data.assistants || [];
	const toolGroups = data.toolGroups || [];
	const translations = data.i18n || {};

	/**
	 * Build assistant options for SelectControl.
	 *
	 * @return {Array} Options array.
	 */
	function getAssistantOptions() {
		const options = [ { value: 0, label: translations.selectAssistant || '— Select an assistant —' } ];
		assistants.forEach( function ( assistant ) {
			options.push( { value: assistant.id, label: assistant.title } );
		} );
		return options;
	}

	/**
	 * Format tool count display.
	 *
	 * @param {number} count Tool count.
	 * @return {string} Formatted string.
	 */
	function formatToolCount( count ) {
		return count + ' ' + ( translations.toolsSelected || 'tools selected' );
	}

	/* =========================================================================
	   Chat Block
	   ========================================================================= */

	blocks.registerBlockType( 'mcp-ai-wpoos/chat', {
		title: __( 'AI Chat', 'nvdigital-open-operator-system-oos' ),
		description: __( 'Display an AI chat interface powered by WP oOS.', 'nvdigital-open-operator-system-oos' ),
		icon: 'format-chat',
		category: 'nvdigital-open-operator-system-oos',
		keywords: [ 'ai', 'chat', 'assistant', 'conversation' ],
		attributes: {
			assistantId: { type: 'number', default: 0 },
			allowGuests: { type: 'boolean', default: false },
			saveTranscript: { type: 'boolean', default: true },
			enableStreaming: { type: 'boolean', default: true },
			allowSensitiveTools: { type: 'boolean', default: false },
			showBuildButton: { type: 'boolean', default: false },
			placeholder: { type: 'string', default: '' },
			template: { type: 'string', default: 'classic' }
		},
		supports: {
			align: [ 'wide', 'full' ],
			anchor: true,
			html: false
		},
		edit: function ( props ) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;

			const selectedAssistant = assistants.find( function ( a ) {
				return a.id === attributes.assistantId;
			} );

			return el( element.Fragment, {},
				el( InspectorControls, {},
					el( PanelBody, { title: __( 'Chat Settings', 'nvdigital-open-operator-system-oos' ), initialOpen: true },
						el( SelectControl, {
							label: __( 'Assistant', 'nvdigital-open-operator-system-oos' ),
							value: attributes.assistantId,
							options: getAssistantOptions(),
							onChange: function ( val ) {
								setAttributes( { assistantId: parseInt( val, 10 ) } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Allow Guests', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Allow non-logged-in users to use the chat.', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.allowGuests,
							onChange: function ( val ) {
								setAttributes( { allowGuests: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Save Transcript', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.saveTranscript,
							onChange: function ( val ) {
								setAttributes( { saveTranscript: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Enable Streaming', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.enableStreaming,
							onChange: function ( val ) {
								setAttributes( { enableStreaming: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Allow Sensitive Tools', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Allow tools that modify content.', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.allowSensitiveTools,
							onChange: function ( val ) {
								setAttributes( { allowSensitiveTools: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Show Build Button', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Display a build button for assistant creation.', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showBuildButton,
							onChange: function ( val ) {
								setAttributes( { showBuildButton: val } );
							}
						} ),
						el( SelectControl, {
							label: __( 'Chat Template', 'nvdigital-open-operator-system-oos' ),
							value: attributes.template || 'classic',
							options: [
								{ label: __( 'Classic', 'nvdigital-open-operator-system-oos' ), value: 'classic' },
								{ label: __( 'Speech Bubbles', 'nvdigital-open-operator-system-oos' ), value: 'speech-bubbles' },
								{ label: __( 'Compact', 'nvdigital-open-operator-system-oos' ), value: 'compact' },
								{ label: __( 'Sidebar', 'nvdigital-open-operator-system-oos' ), value: 'sidebar' }
							],
							onChange: function ( val ) {
								setAttributes( { template: val } );
							}
						} ),
						el( TextControl, {
							label: __( 'Placeholder Text', 'nvdigital-open-operator-system-oos' ),
							value: attributes.placeholder,
							onChange: function ( val ) {
								setAttributes( { placeholder: val } );
							}
						} )
					)
				),
				el( 'div', { className: 'wp-mcp-ai-block-preview wp-mcp-ai-chat-block-preview' },
					el( 'p', {},
						el( 'strong', {}, __( 'AI Chat', 'nvdigital-open-operator-system-oos' ) ),
						selectedAssistant ? ' — ' + selectedAssistant.title : ''
					),
					el( 'p', {}, __( 'Chat interface will display on the frontend.', 'nvdigital-open-operator-system-oos' ) )
				)
			);
		},
		save: function () {
			// Dynamic block - rendered via PHP.
			return null;
		}
	} );

	/* =========================================================================
	   Assistant Selector Block
	   ========================================================================= */

	blocks.registerBlockType( 'mcp-ai-wpoos/assistant-selector', {
		title: __( 'Assistant Selector', 'nvdigital-open-operator-system-oos' ),
		description: __( 'A dropdown to select from available AI assistants.', 'nvdigital-open-operator-system-oos' ),
		icon: 'admin-users',
		category: 'nvdigital-open-operator-system-oos',
		keywords: [ 'ai', 'assistant', 'selector', 'dropdown' ],
		attributes: {
			defaultAssistantId: { type: 'number', default: 0 },
			label: { type: 'string', default: '' },
			showStartButton: { type: 'boolean', default: true },
			startButtonText: { type: 'string', default: '' }
		},
		supports: { anchor: true, html: false },
		edit: function ( props ) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;

			return el( element.Fragment, {},
				el( InspectorControls, {},
					el( PanelBody, { title: __( 'Selector Settings', 'nvdigital-open-operator-system-oos' ), initialOpen: true },
						el( SelectControl, {
							label: __( 'Default Assistant', 'nvdigital-open-operator-system-oos' ),
							value: attributes.defaultAssistantId,
							options: getAssistantOptions(),
							onChange: function ( val ) {
								setAttributes( { defaultAssistantId: parseInt( val, 10 ) } );
							}
						} ),
						el( TextControl, {
							label: __( 'Label', 'nvdigital-open-operator-system-oos' ),
							placeholder: __( 'Select an Assistant:', 'nvdigital-open-operator-system-oos' ),
							value: attributes.label,
							onChange: function ( val ) {
								setAttributes( { label: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Show Start Button', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showStartButton,
							onChange: function ( val ) {
								setAttributes( { showStartButton: val } );
							}
						} ),
						attributes.showStartButton && el( TextControl, {
							label: __( 'Start Button Text', 'nvdigital-open-operator-system-oos' ),
							placeholder: __( 'Start Chat', 'nvdigital-open-operator-system-oos' ),
							value: attributes.startButtonText,
							onChange: function ( val ) {
								setAttributes( { startButtonText: val } );
							}
						} )
					)
				),
				el( 'div', { className: 'wp-mcp-ai-block-preview' },
					el( 'label', {},
						attributes.label || translations.assistantSelector || __( 'Select an Assistant:', 'nvdigital-open-operator-system-oos' )
					),
					el( 'select', { disabled: true, style: { marginLeft: '10px', minWidth: '200px' } },
						el( 'option', {}, translations.selectAssistant || __( '— Select an assistant —', 'nvdigital-open-operator-system-oos' ) )
					),
					attributes.showStartButton && el( 'button', {
						className: 'button',
						disabled: true,
						style: { marginLeft: '10px' }
					}, attributes.startButtonText || __( 'Start Chat', 'nvdigital-open-operator-system-oos' ) )
				)
			);
		},
		save: function () {
			return null;
		}
	} );

	/* =========================================================================
	   Tools Grid Block
	   ========================================================================= */

	blocks.registerBlockType( 'mcp-ai-wpoos/tools-grid', {
		title: __( 'AI Tools Grid', 'nvdigital-open-operator-system-oos' ),
		description: __( 'Display a grid of available AI tools that users can enable/disable.', 'nvdigital-open-operator-system-oos' ),
		icon: 'admin-tools',
		category: 'nvdigital-open-operator-system-oos',
		keywords: [ 'ai', 'tools', 'grid', 'capabilities' ],
		attributes: {
			title: { type: 'string', default: '' },
			description: { type: 'string', default: '' },
			showDescriptions: { type: 'boolean', default: true },
			startCollapsed: { type: 'boolean', default: true },
			showActions: { type: 'boolean', default: true },
			selectedTools: { type: 'array', default: [] }
		},
		supports: { anchor: true, html: false },
		edit: function ( props ) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;

			// Count total tools.
			const totalTools = toolGroups.reduce( function ( sum, group ) {
				return sum + group.tools.length;
			}, 0 );

			return el( element.Fragment, {},
				el( InspectorControls, {},
					el( PanelBody, { title: __( 'Grid Settings', 'nvdigital-open-operator-system-oos' ), initialOpen: true },
						el( TextControl, {
							label: __( 'Title', 'nvdigital-open-operator-system-oos' ),
							placeholder: __( 'Available Tools', 'nvdigital-open-operator-system-oos' ),
							value: attributes.title,
							onChange: function ( val ) {
								setAttributes( { title: val } );
							}
						} ),
						el( TextControl, {
							label: __( 'Description', 'nvdigital-open-operator-system-oos' ),
							value: attributes.description,
							onChange: function ( val ) {
								setAttributes( { description: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Show Tool Descriptions', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showDescriptions,
							onChange: function ( val ) {
								setAttributes( { showDescriptions: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Start Collapsed', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.startCollapsed,
							onChange: function ( val ) {
								setAttributes( { startCollapsed: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Show Select/Deselect All', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showActions,
							onChange: function ( val ) {
								setAttributes( { showActions: val } );
							}
						} )
					)
				),
				el( 'div', { className: 'wp-mcp-ai-block-preview wp-mcp-ai-tools-grid-preview' },
					el( 'p', {},
						el( 'strong', {}, attributes.title || translations.availableTools || __( 'Available Tools', 'nvdigital-open-operator-system-oos' ) )
					),
					el( 'p', {}, totalTools + ' ' + __( 'tools in', 'nvdigital-open-operator-system-oos' ) + ' ' + toolGroups.length + ' ' + __( 'groups', 'nvdigital-open-operator-system-oos' ) ),
					attributes.selectedTools.length > 0 && el( 'p', {}, formatToolCount( attributes.selectedTools.length ) )
				)
			);
		},
		save: function () {
			return null;
		}
	} );

	/* =========================================================================
	   Knowledge Base Block
	   ========================================================================= */

	blocks.registerBlockType( 'mcp-ai-wpoos/knowledge-base', {
		title: __( 'Knowledge Base Upload', 'nvdigital-open-operator-system-oos' ),
		description: __( 'Upload files to include in an AI assistant\'s knowledge base.', 'nvdigital-open-operator-system-oos' ),
		icon: 'media-document',
		category: 'nvdigital-open-operator-system-oos',
		keywords: [ 'ai', 'knowledge', 'upload', 'files', 'documents' ],
		attributes: {
			title: { type: 'string', default: '' },
			description: { type: 'string', default: '' },
			allowedTypes: { type: 'string', default: '.pdf,.txt,.md,.doc,.docx,.csv,.json' },
			maxFiles: { type: 'number', default: 10 },
			maxFileSizeMB: { type: 'number', default: 10 },
			showPreview: { type: 'boolean', default: true },
			uploadedFileIds: { type: 'array', default: [] }
		},
		supports: { anchor: true, html: false },
		edit: function ( props ) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;

			return el( element.Fragment, {},
				el( InspectorControls, {},
					el( PanelBody, { title: __( 'Knowledge Base Settings', 'nvdigital-open-operator-system-oos' ), initialOpen: true },
						el( TextControl, {
							label: __( 'Title', 'nvdigital-open-operator-system-oos' ),
							placeholder: __( 'Knowledge Base', 'nvdigital-open-operator-system-oos' ),
							value: attributes.title,
							onChange: function ( val ) {
								setAttributes( { title: val } );
							}
						} ),
						el( TextControl, {
							label: __( 'Description', 'nvdigital-open-operator-system-oos' ),
							value: attributes.description,
							onChange: function ( val ) {
								setAttributes( { description: val } );
							}
						} ),
						el( TextControl, {
							label: __( 'Allowed File Types', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Comma-separated list of file extensions.', 'nvdigital-open-operator-system-oos' ),
							value: attributes.allowedTypes,
							onChange: function ( val ) {
								setAttributes( { allowedTypes: val } );
							}
						} ),
						el( RangeControl, {
							label: __( 'Max Files', 'nvdigital-open-operator-system-oos' ),
							value: attributes.maxFiles,
							min: 1,
							max: 50,
							onChange: function ( val ) {
								setAttributes( { maxFiles: val } );
							}
						} ),
						el( RangeControl, {
							label: __( 'Max File Size (MB)', 'nvdigital-open-operator-system-oos' ),
							value: attributes.maxFileSizeMB,
							min: 1,
							max: 100,
							onChange: function ( val ) {
								setAttributes( { maxFileSizeMB: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Show File Preview', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showPreview,
							onChange: function ( val ) {
								setAttributes( { showPreview: val } );
							}
						} )
					)
				),
				el( 'div', { className: 'wp-mcp-ai-block-preview' },
					el( 'p', {},
						el( 'strong', {}, attributes.title || translations.knowledgeBase || __( 'Knowledge Base', 'nvdigital-open-operator-system-oos' ) )
					),
					el( 'p', {},
						__( 'Drop files here or click to upload', 'nvdigital-open-operator-system-oos' )
					),
					el( 'p', { style: { fontSize: '12px', color: '#666' } },
						__( 'Max', 'nvdigital-open-operator-system-oos' ) + ' ' + attributes.maxFiles + ' ' + __( 'files', 'nvdigital-open-operator-system-oos' ) + ', ' +
						attributes.maxFileSizeMB + 'MB ' + __( 'each', 'nvdigital-open-operator-system-oos' )
					)
				)
			);
		},
		save: function () {
			return null;
		}
	} );

	/* =========================================================================
	   Assistant Builder Block
	   ========================================================================= */

	blocks.registerBlockType( 'mcp-ai-wpoos/assistant-builder', {
		title: __( 'AI Assistant Builder', 'nvdigital-open-operator-system-oos' ),
		description: __( 'A complete interface for building new AI assistants.', 'nvdigital-open-operator-system-oos' ),
		icon: 'hammer',
		category: 'nvdigital-open-operator-system-oos',
		keywords: [ 'ai', 'assistant', 'builder', 'create', 'tools', 'chat' ],
		attributes: {
			showAssistantSelector: { type: 'boolean', default: true },
			showToolsGrid: { type: 'boolean', default: true },
			showKnowledgeBase: { type: 'boolean', default: true },
			showBuildButton: { type: 'boolean', default: true },
			defaultAssistantId: { type: 'number', default: 0 },
			layout: { type: 'string', default: 'stacked' },
			toolsCollapsed: { type: 'boolean', default: true },
			showToolDescriptions: { type: 'boolean', default: true },
			enableStreaming: { type: 'boolean', default: true },
			chatPlaceholder: { type: 'string', default: '' },
			allowedFileTypes: { type: 'string', default: '.pdf,.txt,.md,.doc,.docx,.csv,.json' },
			maxFiles: { type: 'number', default: 10 },
			maxFileSizeMB: { type: 'number', default: 10 }
		},
		supports: {
			align: [ 'wide', 'full' ],
			anchor: true,
			html: false
		},
		edit: function ( props ) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;

			return el( element.Fragment, {},
				el( InspectorControls, {},
					el( PanelBody, { title: __( 'Layout', 'nvdigital-open-operator-system-oos' ), initialOpen: true },
						el( SelectControl, {
							label: __( 'Layout Style', 'nvdigital-open-operator-system-oos' ),
							value: attributes.layout,
							options: [
								{ value: 'stacked', label: __( 'Stacked', 'nvdigital-open-operator-system-oos' ) },
								{ value: 'side-by-side', label: __( 'Side by Side', 'nvdigital-open-operator-system-oos' ) }
							],
							onChange: function ( val ) {
								setAttributes( { layout: val } );
							}
						} )
					),
					el( PanelBody, { title: __( 'Components', 'nvdigital-open-operator-system-oos' ), initialOpen: true },
						el( ToggleControl, {
							label: __( 'Show Assistant Selector', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showAssistantSelector,
							onChange: function ( val ) {
								setAttributes( { showAssistantSelector: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Show Tools Grid', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showToolsGrid,
							onChange: function ( val ) {
								setAttributes( { showToolsGrid: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Show Knowledge Base', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showKnowledgeBase,
							onChange: function ( val ) {
								setAttributes( { showKnowledgeBase: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Show Build Button', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showBuildButton,
							onChange: function ( val ) {
								setAttributes( { showBuildButton: val } );
							}
						} )
					),
					el( PanelBody, { title: __( 'Assistant Selector', 'nvdigital-open-operator-system-oos' ), initialOpen: false },
						el( SelectControl, {
							label: __( 'Default Assistant', 'nvdigital-open-operator-system-oos' ),
							value: attributes.defaultAssistantId,
							options: getAssistantOptions(),
							onChange: function ( val ) {
								setAttributes( { defaultAssistantId: parseInt( val, 10 ) } );
							}
						} )
					),
					el( PanelBody, { title: __( 'Tools Grid', 'nvdigital-open-operator-system-oos' ), initialOpen: false },
						el( ToggleControl, {
							label: __( 'Start Collapsed', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.toolsCollapsed,
							onChange: function ( val ) {
								setAttributes( { toolsCollapsed: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Show Tool Descriptions', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.showToolDescriptions,
							onChange: function ( val ) {
								setAttributes( { showToolDescriptions: val } );
							}
						} )
					),
					el( PanelBody, { title: __( 'Chat', 'nvdigital-open-operator-system-oos' ), initialOpen: false },
						el( ToggleControl, {
							label: __( 'Enable Streaming', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.enableStreaming,
							onChange: function ( val ) {
								setAttributes( { enableStreaming: val } );
							}
						} ),
						el( TextControl, {
							label: __( 'Chat Placeholder', 'nvdigital-open-operator-system-oos' ),
							placeholder: translations.chatPlaceholder || __( 'Describe the assistant you want to create...', 'nvdigital-open-operator-system-oos' ),
							value: attributes.chatPlaceholder,
							onChange: function ( val ) {
								setAttributes( { chatPlaceholder: val } );
							}
						} )
					),
					el( PanelBody, { title: __( 'Knowledge Base', 'nvdigital-open-operator-system-oos' ), initialOpen: false },
						el( TextControl, {
							label: __( 'Allowed File Types', 'nvdigital-open-operator-system-oos' ),
							value: attributes.allowedFileTypes,
							onChange: function ( val ) {
								setAttributes( { allowedFileTypes: val } );
							}
						} ),
						el( RangeControl, {
							label: __( 'Max Files', 'nvdigital-open-operator-system-oos' ),
							value: attributes.maxFiles,
							min: 1,
							max: 50,
							onChange: function ( val ) {
								setAttributes( { maxFiles: val } );
							}
						} ),
						el( RangeControl, {
							label: __( 'Max File Size (MB)', 'nvdigital-open-operator-system-oos' ),
							value: attributes.maxFileSizeMB,
							min: 1,
							max: 100,
							onChange: function ( val ) {
								setAttributes( { maxFileSizeMB: val } );
							}
						} )
					)
				),
				el( 'div', { className: 'wp-mcp-ai-block-preview wp-mcp-ai-builder-preview' },
					el( 'p', {},
						el( 'strong', {}, __( 'AI Assistant Builder', 'nvdigital-open-operator-system-oos' ) ),
						' — ',
						attributes.layout === 'side-by-side' ? __( 'Side by Side', 'nvdigital-open-operator-system-oos' ) : __( 'Stacked', 'nvdigital-open-operator-system-oos' )
					),
					el( 'ul', {},
						attributes.showAssistantSelector && el( 'li', {}, '✓ ' + __( 'Assistant Selector', 'nvdigital-open-operator-system-oos' ) ),
						attributes.showToolsGrid && el( 'li', {}, '✓ ' + __( 'Tools Grid', 'nvdigital-open-operator-system-oos' ) ),
						attributes.showKnowledgeBase && el( 'li', {}, '✓ ' + __( 'Knowledge Base', 'nvdigital-open-operator-system-oos' ) ),
						attributes.showBuildButton && el( 'li', {}, '✓ ' + __( 'Build Button', 'nvdigital-open-operator-system-oos' ) )
					),
					el( 'p', { style: { color: '#666', fontSize: '12px' } },
						__( 'Complete builder interface will display on the frontend.', 'nvdigital-open-operator-system-oos' )
					)
				)
			);
		},
		save: function () {
			return null;
		}
	} );

}(
	window.wp.blocks,
	window.wp.element,
	window.wp.blockEditor,
	window.wp.components,
	window.wp.i18n
) );
