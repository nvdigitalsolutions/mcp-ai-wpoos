=== NV oOS Content Graph ===

Contributors: vsamtani
Tags: knowledge graph, content visualization, cytoscape, content strategy, semantic web
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.0.7
License: GPL-3.0-or-later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Map your WordPress content into an interactive knowledge graph. See relationships between posts, terms, and authors. No API keys required.

== Description ==

NV oOS Content Graph transforms your WordPress content into a visual knowledge graph — organized, searchable, and interactive. Every post, page, category, tag, and author becomes a node; every relationship becomes an edge.

**No API keys. No AI required.** The core graph engine runs entirely on your WordPress server using your existing content. Optional remote sources (like Wikidata) are opt-in — see External services below.



### What You Get

= One-Click Graph Builder =
Click "Build Graph" and ~10-30 seconds later, your entire site becomes a visual graph. Supports incremental rebuilds and scheduled cron updates.

= Interactive Graph Explorer =
Explore your content visually using Cytoscape.js. Search for nodes by label, click for details, zoom and pan. Color-coded by content type (posts, pages, terms, users).

= Visual Theming & Styling =
Style the graph to match your brand from the new Appearance tab: dark, light, auto, and WordPress-admin themes; per-type colors and icons (colorblind-safe defaults with automatic WCAG 2.2 contrast correction); color-by-type/community/degree modes; an interactive legend; edge style presets; layout presets; a minimap; keyboard navigation; and theme-aware PNG export. See `docs/visual-theming.md`.

= Content Gap Analysis =
Discover orphan content (no internal links), thin topic clusters, and missing link opportunities. Generate actionable content strategy recommendations.

= Six Export Formats =
Download your graph as JSON (NetworkX), GraphML (Gephi/yEd), CSV, Neo4j Cypher, Obsidian vault, or standalone HTML page.

= Schema.org JSON-LD =
Automatic structured data injection for SEO — taxonomy terms as `about` and internal links as `relatedLink`.

= Related Content Widget =
Appends graph-neighbor posts to your content based on knowledge graph proximity.

= REST API =
Full programmatic access with 18 endpoints. Read endpoints require the `read` capability (all logged-in users) or a valid guest token (guest tokens are provided by the NV oOS base plugin when installed); write endpoints require `manage_options`.

= Extensible Tool System =
14 built-in tools for graph operations: query, search, traverse, analyze, export. Addon plugins can register their own tools.

### Addon Ecosystem (all optional)

- **nvoos-content-graph-ai** — AI chat assistant with 13 AI providers, AI tools, embeddings, RAG, and agent memory
- **nvoos-content-graph-ai-platform** — agents, skills, slash-commands, professions, A2A, ACP, and federation

== Installation ==

1. Upload the `nvoos-content-graph` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu
3. Go to **Knowledge Graph → Settings**
4. Click "Build Graph"

That's it. Your content is now a knowledge graph.

== Frequently Asked Questions ==

= Do I need an API key? =

No. The core graph engine works with zero external dependencies. AI features require their respective addon plugins and API keys.

= How long does a build take? =

~10-30 seconds for a typical WordPress site (100-500 posts). Large sites (10,000+ posts) may take 1-2 minutes.

= Can I build incrementally? =

Yes. Enable "Incremental Builds" in settings to only process content changed since the last build.

= Is this compatible with my theme? =

Yes. The graph explorer, shortcode, related content widget, and schema.org injection work with any theme. The shortcode `[nvoos_graph]` embeds wherever you place it.

= Does it work with custom post types? =

Yes. Any public post type (including JetEngine CPTs) is automatically detected. You can configure which post types to index in Settings.

= Does it work with JetEngine Custom Content Types (CCTs)? =

Yes. JetEngine CCTs are detected and indexed by default, and the Settings → Sources tab lists every registered CCT with include/exclude checkboxes (including CCTs registered by the NV oOS base+Pro plugin). Uncheck a CCT to exclude it from the next graph build.

= Does the plugin connect to external services? =

The core graph engine runs entirely on your server. The optional "Resolve External Entity" tool queries Wikidata (wikidata.org) when you explicitly ask it to look up a QID. Remote source drivers connect to user-configured endpoints (REST APIs, RSS feeds, SPARQL, etc.) only when you set them up in Settings. See the External services section below for full details.

= Do I have to pay for the NV oOS Complete bundle? =

No. This plugin is complete and fully functional for free. The NV oOS Complete bundle (the full NV oOS plugin, base + Pro) is an optional, separately installed paid product, sold off-directory by NV Digital Unlocked LLC under license from NV Digital Solutions. Purchases are covered by a 30-day money-back guarantee; see the vendor's Terms of Service and Refund Policy linked in the checkout.

= Does it work on multisite? =

Yes. The plugin supports WordPress multisite with per-site configuration.

= What happens if I deactivate? =

Cron schedules are cleared. Your data stays intact — reactivate at any time.

= What happens if I uninstall? =

All custom tables and options are removed (see `uninstall.php`). Export your graph first if you want to keep it.

== Privacy Notice ==

This plugin does not collect, store, or transmit any personal data by default. The core graph engine runs entirely on your WordPress server using your existing content.

**Remote Sources (opt-in only):** When you explicitly configure a remote source driver (e.g. Wikidata, REST API, RSS feed), the plugin sends HTTP requests to the URLs you provide. No data is sent off-site without your explicit setup. Remote source credentials (API keys, tokens, passwords) are stored in the database encrypted with AES-256-GCM via the OpenSSL PHP extension, falling back to base64 encoding with an admin warning when OpenSSL is unavailable.

**Optional AI Addons:** The companion plugin `nvoos-content-graph-ai` (not included in this plugin) sends content to third-party AI providers (OpenAI, Google Gemini, etc.) when configured. Refer to that addon's documentation for its privacy policies.

== External services ==

This plugin does not require any external service for its core functionality. All graph data is computed and stored on your own WordPress server.

**Wikidata (wikidata.org)**

The optional "Resolve External Entity" tool and the Wikidata remote-source driver query the Wikidata API (`https://www.wikidata.org/w/api.php`) — only when you explicitly request an entity lookup by QID (e.g. Q42) or configure a Wikidata source.

- **What is sent:** the QID or entity identifier you provide, plus standard HTTP request metadata (your server's IP address, user agent).
- **When:** only on your explicit request; never automatically or in the background.
- **What it is used for:** fetching the entity's label, description, and sitelinks so it can be ingested as a graph node.
- **Service provider:** Wikimedia Foundation — Terms of Use: https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use — Privacy Policy: https://foundation.wikimedia.org/wiki/Policy:Privacy_policy

**User-configured remote sources (opt-in only)**

When you configure a remote source driver (REST API, RSS/Sitemap feed, SPARQL endpoint, webhook receiver, etc.) in Settings, the plugin sends HTTP requests to the URLs you provide. What is sent depends entirely on the endpoint you configure. These requests happen only when you manually trigger a sync, schedule one, or receive a webhook. Remote source credentials (API keys, tokens, passwords) are stored in the database encrypted with AES-256-GCM via the OpenSSL PHP extension.

**Stripe payments (opt-in only)**

The "Get NV oOS Complete" buttons on the plugin's settings page open an optional checkout for the NV oOS Complete plugin bundle — the full NV oOS plugin (base + Pro) installed as a separate plugin. Card and payment details are entered directly on Stripe's servers (`js.stripe.com` iframe); the plugin never stores or transmits card data. Stripe.js is loaded only when the purchase modal is opened — merely visiting the settings page contacts no third party. The checkout is created and verified by the vendor's own server, operated by NV Digital Solutions on behalf of NV Digital Unlocked LLC (the seller of record); this plugin only sends the product name, your site URL, the Stripe payment ID, the purchasing administrator's email address, the buyer's declared country, and a timestamp recording your agreement to the Terms of Service to that service. For buyers in the EU, a billing address (street, city, optional postal code) is collected in the modal, attached to the payment for VAT records, and shown to the vendor on the license. A local purchase record (license key, payment ID, price paid, the purchasing administrator's email address, country, and the consent timestamp) is stored after the vendor confirms the payment. Payment is entirely optional — the core plugin is fully functional without it.

- **Service provider:** Stripe, Inc. — Privacy Policy: https://stripe.com/privacy

**Installing the NV oOS Complete bundle (manual install is the primary path)**

After a successful purchase you can download the NV oOS Complete ZIP and install it manually via **Plugins → Add New Plugin → Upload Plugin** — this is the recommended, fully transparent path. The plugin also offers an optional automatic installation (a convenience that downloads the ZIP and runs WordPress' built-in installer for you). Either way, the ZIP comes from a signed, short-lived URL provided by the vendor's checkout service (which serves the package from the project's GitHub release page, `github.com`). No data is sent to GitHub.

== Third-Party Libraries ==

This plugin bundles the following open-source libraries:

* **Cytoscape.js** v3.28.1 — MIT License — https://github.com/cytoscape/cytoscape.js
* **cytoscape-fcose** v2.2.0 — MIT License — https://github.com/iVis-at-Bilkent/cytoscape.js-fcose
* **layout-base** v2.0.1 — MIT License — https://github.com/iVis-at-Bilkent/layout-base
* **cose-base** v2.2.0 — MIT License — https://github.com/iVis-at-Bilkent/cose-base

All libraries are served locally from `assets/vendor/` and never loaded from third-party CDNs. Each library's license text ships alongside it (`assets/vendor/<name>/LICENSE`).

== Screenshots ==

1. Knowledge Graph — main explorer view
2. Settings — build schedule, auto-rebuild, and display options
3. Remote Sources — connect external data (Wikidata, REST APIs, RSS)
4. Sources — choose which post types and content types are indexed
5. Frontend embed — the [nvoos_graph] shortcode on any page
6. Graph Explorer — interactive Cytoscape.js visualization with search and node details

== Changelog ==

= 1.0.7 — 2026-09-09 =
* Checkout consent checkbox (Terms of Service + 30-day refund policy) and buyer-email collection with Stripe receipt delivery
* Buyer country and conditional EU billing address (VAT records) collected in the purchase modal
* Manual ZIP download offered after purchase alongside the automatic installer; manual install documented as the primary path
* Roadmap link in the purchase modal; release-notes link and support email on the purchase success screen
* Updated privacy disclosures (buyer email, country, EU billing address, and Terms consent timestamp sent to the checkout service)

= 1.0.6 — 2026-09-08 =
* Checkout now delivers the NV oOS Complete plugin bundle (base + Pro as a separate plugin) instead of the companion AI addon
* The installer refuses to create a second copy of NV oOS when the base plugin is already installed on the site
* Updated privacy disclosures for the checkout flow

= 1.0.5 — 2026-09-08 =
* Agent Memory Bridge: memories stored by the NV oOS base+Pro plugin (`wp_mcp_ai_memory_stored`) are now projected into the knowledge graph as `memory:*` nodes with agent/wing/room edges
* Graph-ranked memory retrieval seam for the NV oOS `wake_up_context` tool (`wp_mcp_ai_wake_up_context_graph_retriever` filter)
* New `Db::tablesInstalled()` schema probe; PHPUnit coverage for the bridge and its schema-absent degradation

= 1.0.4 — 2026-09-05 =
* New Appearance tab: themes (dark/light/auto/admin), per-type color and icon overrides, WCAG contrast report, and one-click style presets
* Icon glyphs and legend panel in the graph explorer; color-by type/community/degree/monochrome modes
* Relationship-aware edge styling (color families, arrowheads, tapered, haystack density mode) and edge labels
* Minimap, zoom controls, layout presets, keyboard navigation, reduced-motion support, view persistence, and theme-aware PNG export
* New `GET /edges` REST endpoint; front-end shortcode/block visual attributes (`theme`, `color_by`, `show_legend`, `show_icons`, `show_edges`, `edge_style`)
* Stripe checkout for the AI addon (payments via the vendor checkout API; no Stripe keys ship in the plugin; Stripe.js loads only when the purchase modal opens)

= 1.0.3 — 2026-08-20 =
* Encrypt remote-source credentials (AES-256-GCM) before storing them
* Fix `[nvoos_graph]` shortcode and block embed (invalid inline script)
* Wire the Scheduled Rebuild setting to WP-Cron (new "Never" option)
* Fix the admin Test button and REST /test endpoint (now use per-source credentials)
* Reject unknown drivers and sanitize config in both source-creation paths
* Re-validate redirects against the SSRF guard
* Preserve external_id, source_slug, confidence, and expires_at on node updates
* Remote Sources modal now renders schema field types correctly
* Remove the unregistered Graph Explorer admin page (embedded in Settings)
* Ship the Composer autoloader intact in distribution builds
* Restrict tool-level auto-ingest to administrators
* Add WordPress.org screenshot assets (.wordpress-org/assets)

= 1.0.2 — 2026-08-18 =
* Renamed from "NV oOS Graphify" to "NV oOS Content Graph" (new slug `nvoos-content-graph`)
* Hardened Schema.org JSON-LD output against script-tag breakout
* Restricted REST `/resolve` auto-ingest to administrators
* Replaced inline admin JavaScript with enqueued asset
* Added external-services disclosure (Wikidata terms and privacy policy)
* Field-map validation is now self-contained (no legacy addon dependency)
* Embeddings reindexing bridges to the AI addon's embedding service

= 1.0.0 — 2026-06-05 =
* Initial standalone release
* PSR-4 architecture: `NvoosContentGraph\` namespace
* 5 custom database tables with dbDelta() migrations
* 14 built-in tools implementing `NvoosContentGraph\Contracts\Tool`
* 14 REST API endpoints at `/wp-json/nvoos-content-graph/v1/`
* Cytoscape.js graph explorer (admin + frontend)
* Tabbed settings page with per-tab sanitisation
* 6 export formats (JSON, GraphML, CSV, Neo4j, Obsidian, HTML)
* Schema.org JSON-LD injection for SEO
* Related content widget based on graph proximity
* Louvain community detection + content gap analysis
* `[nvoos_graph]` shortcode + Gutenberg block
* JetEngine Custom Content Type (CCT) support
* WordPress multisite compatible
* PHP 8.1+, WordPress 6.5+, GPL-3.0-or-later
