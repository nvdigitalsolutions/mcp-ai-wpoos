<?php
/**
 * Tool: Schedule Maintenance
 *
 * Allows AI assistants to schedule a maintenance window.
 *
 * @package   WP_MCP_AI_Pro
 * @since     1.4.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Schedule_Maintenance' ) ) {
	/**
	 * Schedule Maintenance tool.
	 *
	 * @since 1.4.0
	 */
	class WP_MCP_AI_Tool_Schedule_Maintenance implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

		use WP_MCP_AI_Tool_Default_Capability;

		/**
		 * {@inheritdoc}
		 */
		public function get_slug(): string {
			return 'schedule_maintenance';
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_name(): string {
			return __( 'Schedule Maintenance', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_description(): string {
			return __( 'Schedule a new maintenance window.', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_required_capability(): string {
			return 'manage_options';
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_definition(): array {
			return array(
				'name'                => __( 'Schedule Maintenance', 'nvdigital-open-operator-system-oos' ),
				'description'         => __( 'Schedule a new maintenance window.', 'nvdigital-open-operator-system-oos' ),
				'required_capability' => 'manage_options',
				'parameters'          => $this->get_parameters_schema(),
			);
		}

		/**
		 * Get usage guidance for the tool.
		 *
		 * @return array
		 */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Scheduling a maintenance window with ISO 8601 start and end times and affected service slugs.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Reporting live outages (use create_incident) or checking component health (use get_service_status).', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'create_incident', 'get_service_status', 'update_incident' ),
				'notes'           => __( 'End must be after start; the window is stored as scheduled and enables a maintenance banner.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_capability_flags(): array {
			return array(
				'state_changing' => true,
				'risk_level'     => 'low',
			);
		}

		/**
		 * Get parameters schema.
		 *
		 * @return array
		 */
		public function get_parameters_schema(): array {
			return array(
				'title'    => array(
					'type'        => 'string',
					'description' => __( 'Title of the maintenance window.', 'nvdigital-open-operator-system-oos' ),
					'required'    => true,
				),
				'message'  => array(
					'type'        => 'string',
					'description' => __( 'Description of the maintenance activities.', 'nvdigital-open-operator-system-oos' ),
				),
				'start'    => array(
					'type'        => 'string',
					'description' => __( 'Start time in ISO 8601 format (e.g. 2026-08-01T02:00:00Z).', 'nvdigital-open-operator-system-oos' ),
					'required'    => true,
				),
				'end'      => array(
					'type'        => 'string',
					'description' => __( 'End time in ISO 8601 format.', 'nvdigital-open-operator-system-oos' ),
					'required'    => true,
				),
				'services' => array(
					'type'        => 'array',
					'description' => __( 'Affected service component slugs.', 'nvdigital-open-operator-system-oos' ),
					'items'       => array( 'type' => 'string' ),
				),
			);
		}

		/**
		 * Execute the tool.
		 *
		 * @since 1.4.0
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Execution context.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$title    = isset( $arguments['title'] ) ? sanitize_text_field( $arguments['title'] ) : '';
			$start    = isset( $arguments['start'] ) ? sanitize_text_field( $arguments['start'] ) : '';
			$end      = isset( $arguments['end'] ) ? sanitize_text_field( $arguments['end'] ) : '';
			$message  = isset( $arguments['message'] ) ? sanitize_text_field( $arguments['message'] ) : '';
			$services = isset( $arguments['services'] ) && is_array( $arguments['services'] )
				? array_map( 'sanitize_text_field', $arguments['services'] )
				: array();

			if ( '' === $title ) {
				return new WP_Error(
					'wp_mcp_ai_missing_title',
					__( 'A maintenance window title is required.', 'nvdigital-open-operator-system-oos' )
				);
			}

			if ( ! class_exists( 'WP_MCP_AI_Maintenance_CPT' ) ) {
				return new WP_Error(
					'wp_mcp_ai_unavailable',
					__( 'The maintenance system is not available.', 'nvdigital-open-operator-system-oos' )
				);
			}

			$start_ts = strtotime( $start );
			$end_ts   = strtotime( $end );

			if ( false === $start_ts || false === $end_ts ) {
				return new WP_Error(
					'wp_mcp_ai_invalid_date',
					__( 'Start and end must be valid ISO 8601 dates.', 'nvdigital-open-operator-system-oos' )
				);
			}

			if ( $end_ts <= $start_ts ) {
				return new WP_Error(
					'wp_mcp_ai_invalid_range',
					__( 'End time must be after start time.', 'nvdigital-open-operator-system-oos' )
				);
			}

			$post_id = wp_insert_post(
				array(
					'post_type'    => WP_MCP_AI_Maintenance_CPT::POST_TYPE,
					'post_title'   => $title,
					'post_content' => $message,
					'post_status'  => 'publish',
					'meta_input'   => array(
						'_mcp_ai_maintenance_status'   => WP_MCP_AI_Maintenance_CPT::STATUS_SCHEDULED,
						'_mcp_ai_maintenance_start'    => $start,
						'_mcp_ai_maintenance_end'      => $end,
						'_mcp_ai_maintenance_services' => $services,
						'_mcp_ai_maintenance_banner_enabled' => true,
						'_mcp_ai_maintenance_reminder_sent' => false,
					),
				),
				true
			);

			if ( is_wp_error( $post_id ) ) {
				return $post_id;
			}

			/** Fires when a maintenance window is scheduled. @since 1.3.0 */
			do_action( 'wp_mcp_ai_maintenance_scheduled', $post_id, $arguments );

			return array(
				'window_id' => $post_id,
				'title'     => esc_html( $title ),
				'start'     => esc_html( $start ),
				'end'       => esc_html( $end ),
				'message'   => esc_html__( 'Maintenance window scheduled successfully.', 'nvdigital-open-operator-system-oos' ),
			);
		}
	}
}
