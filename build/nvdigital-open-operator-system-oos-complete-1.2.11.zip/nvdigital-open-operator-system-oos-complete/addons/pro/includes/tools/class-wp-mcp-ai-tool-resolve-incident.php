<?php
/**
 * Tool: Resolve Incident
 *
 * Allows AI assistants to resolve an operational incident.
 *
 * @package   WP_MCP_AI_Pro
 * @since     1.4.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Resolve_Incident' ) ) {
	/**
	 * Resolve Incident tool.
	 *
	 * @since 1.4.0
	 */
	class WP_MCP_AI_Tool_Resolve_Incident implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

		use WP_MCP_AI_Tool_Default_Capability;

		/**
		 * {@inheritdoc}
		 */
		public function get_slug(): string {
			return 'resolve_incident';
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_name(): string {
			return __( 'Resolve Incident', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_description(): string {
			return __( 'Mark an operational incident as resolved.', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_required_capability(): string {
			return 'manage_options';
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_definition(): array {
			return array(
				'name'                => __( 'Resolve Incident', 'nvdigital-open-operator-system-oos' ),
				'description'         => __( 'Mark an operational incident as resolved.', 'nvdigital-open-operator-system-oos' ),
				'required_capability' => 'manage_options',
				'parameters'          => $this->get_parameters_schema(),
			);
		}

		/**
		 * Get usage guidance for the tool.
		 *
		 * @return array
		 */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Closing an operational incident by transitioning it to the resolved phase with a resolution message.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Creating incidents (use create_incident) or moving through intermediate phases (use update_incident).', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'create_incident', 'update_incident', 'get_service_status' ),
				'notes'           => __( 'Fails when the incident cannot transition from its current phase; message defaults to a generic resolution.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/**
		 * {@inheritdoc}
		 */
		public function get_capability_flags(): array {
			return array(
				'state_changing' => true,
				'risk_level'     => 'low',
			);
		}

		/**
		 * Get parameters schema.
		 *
		 * @return array
		 */
		public function get_parameters_schema(): array {
			return array(
				'incident_id' => array(
					'type'        => 'integer',
					'description' => __( 'The ID of the incident to resolve.', 'nvdigital-open-operator-system-oos' ),
					'required'    => true,
				),
				'message'     => array(
					'type'        => 'string',
					'description' => __( 'Resolution message.', 'nvdigital-open-operator-system-oos' ),
				),
			);
		}

		/**
		 * Execute the tool.
		 *
		 * @since 1.4.0
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Execution context.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$incident_id = isset( $arguments['incident_id'] ) ? absint( $arguments['incident_id'] ) : 0;
			$message     = isset( $arguments['message'] ) ? sanitize_text_field( $arguments['message'] ) : '';

			if ( ! class_exists( 'WP_MCP_AI_Incident_CPT' ) ) {
				return new WP_Error(
					'wp_mcp_ai_unavailable',
					__( 'The incident management system is not available.', 'nvdigital-open-operator-system-oos' )
				);
			}

			$post = get_post( $incident_id );
			if ( ! $post || WP_MCP_AI_Incident_CPT::POST_TYPE !== $post->post_type ) {
				return new WP_Error(
					'wp_mcp_ai_not_found',
					__( 'Incident not found.', 'nvdigital-open-operator-system-oos' )
				);
			}

			if ( '' === $message ) {
				$message = __( 'This incident has been resolved.', 'nvdigital-open-operator-system-oos' );
			}

			$success = WP_MCP_AI_Incident_CPT::transition_phase(
				$incident_id,
				WP_MCP_AI_Incident_CPT::PHASE_RESOLVED,
				$message
			);

			if ( ! $success ) {
				return new WP_Error(
					'wp_mcp_ai_invalid_transition',
					__( 'Cannot resolve this incident in its current state.', 'nvdigital-open-operator-system-oos' )
				);
			}

			return array(
				'incident_id' => $incident_id,
				'title'       => esc_html( $post->post_title ),
				'phase'       => esc_html( WP_MCP_AI_Incident_CPT::PHASE_RESOLVED ),
				'message'     => esc_html__( 'Incident resolved successfully.', 'nvdigital-open-operator-system-oos' ),
			);
		}
	}
}
