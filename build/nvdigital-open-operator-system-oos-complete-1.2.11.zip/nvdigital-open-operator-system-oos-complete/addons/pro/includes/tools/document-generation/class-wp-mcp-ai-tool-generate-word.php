<?php
/**
 * Generate Word Tool - Simplified Word document generation.
 *
 * Simplified interface for Word document generation that delegates to the Pro Word tool.
 * Provides a simpler API for common Word generation use cases.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.2.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load the chat and document response traits from base plugin.
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-document-response.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php';

// Load the Pro Word tool.
require_once __DIR__ . '/class-wp-mcp-ai-tool-pro-word.php';

/**
 * Simplified Word document generation tool.
 *
 * Provides a simpler interface for Word generation by delegating
 * to the more powerful Pro Word tool with sensible defaults.
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Tool_Generate_Word implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Tool_Document_Response;

	/**
	 * Pro Word tool instance.
	 *
	 * @var WP_MCP_AI_Tool_Pro_Word
	 */
	protected $pro_word_tool;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->pro_word_tool = new WP_MCP_AI_Tool_Pro_Word();
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_word';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate Word', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Generate Word documents from content. Simplified interface for creating .docx files with basic formatting. For advanced features, use Pro Word Document tool.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Turning plain content into a simple .docx file that the user can edit in Word.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'When you need advanced Word formatting or provider-based generation; use pro_word_document.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'pro_word_document', 'generate_pdf', 'generate_email_template' ),
			'notes'           => __( 'Delegates to pro_word_document with simplified arguments and writes the .docx to the media library.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'content' => array(
					'type'        => 'string',
					'description' => __( 'Content to include in the Word document.', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'title'   => array(
					'type'        => 'string',
					'description' => __( 'Document title.', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),
			'required'   => array( 'content' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'requires-capability',
			'requires-model',
			'consumes-tokens',
			'write',
			'state-changing',
		);
	}

	/**
	 * Get required capability.
	 *
	 * @return string
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Delegate to Pro Word tool with simplified parameters.
		$pro_arguments = array(
			'operation' => 'generate',
			'content'   => $arguments['content'] ?? '',
			'title'     => $arguments['title'] ?? 'Document',
		);

		return $this->pro_word_tool->execute( $pro_arguments, $context );
	}
}
