<?php
/**
 * Tool: Update Incident
 *
 * Allows AI assistants to update incident phase and add timeline entries.
 *
 * @package   WP_MCP_AI_Pro
 * @since     1.4.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Update_Incident' ) ) {
	/**
	 * Update Incident tool.
	 *
	 * @since 1.4.0
	 */
	class WP_MCP_AI_Tool_Update_Incident implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

		use WP_MCP_AI_Tool_Default_Capability;

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_slug(): string {
			return 'update_incident';
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_name(): string {
			return __( 'Update Incident', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_description(): string {
			return __( 'Update the phase of an existing incident and add a timeline entry.', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_required_capability(): string {
			return 'manage_options';
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_definition(): array {
			return array(
				'name'                => __( 'Update Incident', 'nvdigital-open-operator-system-oos' ),
				'description'         => __( 'Update the phase of an existing incident and add a timeline entry.', 'nvdigital-open-operator-system-oos' ),
				'required_capability' => 'manage_options',
				'parameters'          => $this->get_parameters_schema(),
			);
		}

		/**
		 * Get usage guidance for the tool.
		 *
		 * @return array
		 */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Moving an incident through phases (investigating, identified, monitoring) or appending a timeline message.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Creating new incidents (use create_incident); use resolve_incident to close an incident for good.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'create_incident', 'resolve_incident', 'get_service_status' ),
				'notes'           => __( 'Phase is optional; with only a message, a timeline entry is appended under the current phase.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/**
		 * {@inheritdoc}
		 *
		 * @since 1.4.0
		 */
		public function get_capability_flags(): array {
			return array(
				'state_changing' => true,
				'risk_level'     => 'low',
			);
		}

		/**
		 * Get parameters schema.
		 *
		 * @since 1.4.0
		 *
		 * @return array
		 */
		public function get_parameters_schema(): array {
			return array(
				'incident_id' => array(
					'type'        => 'integer',
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
					'description' => __( 'The ID of the incident to update.', 'nvdigital-open-operator-system-oos' ),
					'required'    => true,
				),
				'phase'       => array(
					'type'        => 'string',
					'description' => __( 'The new phase for the incident.', 'nvdigital-open-operator-system-oos' ),
					'enum'        => array( 'investigating', 'identified', 'monitoring', 'resolved' ),
				),
				'message'     => array(
					'type'        => 'string',
					'description' => __( 'Update message describing the progress.', 'nvdigital-open-operator-system-oos' ),
				),
			);
		}

		/**
		 * Execute the tool.
		 *
		 * @since 1.4.0
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Execution context.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$incident_id = isset( $arguments['incident_id'] ) ? absint( $arguments['incident_id'] ) : 0;
			$phase       = isset( $arguments['phase'] ) ? sanitize_text_field( $arguments['phase'] ) : '';
			$message     = isset( $arguments['message'] ) ? sanitize_text_field( $arguments['message'] ) : '';

			if ( ! class_exists( 'WP_MCP_AI_Incident_CPT' ) ) {
				return new WP_Error(
					'wp_mcp_ai_unavailable',
					__( 'The incident management system is not available.', 'nvdigital-open-operator-system-oos' )
				);
			}

			$post = get_post( $incident_id );
			if ( ! $post || WP_MCP_AI_Incident_CPT::POST_TYPE !== $post->post_type ) {
				return new WP_Error(
					'wp_mcp_ai_not_found',
					__( 'Incident not found.', 'nvdigital-open-operator-system-oos' )
				);
			}

			if ( '' !== $phase ) {
				$success = WP_MCP_AI_Incident_CPT::transition_phase( $incident_id, $phase, $message );

				if ( ! $success ) {
					return new WP_Error(
						'wp_mcp_ai_invalid_transition',
						__( 'Invalid phase transition for this incident.', 'nvdigital-open-operator-system-oos' )
					);
				}
			} elseif ( '' !== $message ) {
				$current = get_post_meta( $incident_id, '_mcp_ai_incident_phase', true );
				WP_MCP_AI_Incident_CPT::append_timeline_entry( $incident_id, $current, $message );
			}

			$post = get_post( $incident_id );

			return array(
				'incident_id' => $incident_id,
				'title'       => esc_html( $post->post_title ),
				'phase'       => esc_html( get_post_meta( $incident_id, '_mcp_ai_incident_phase', true ) ),
				'message'     => esc_html__( 'Incident updated successfully.', 'nvdigital-open-operator-system-oos' ),
			);
		}
	}
}
