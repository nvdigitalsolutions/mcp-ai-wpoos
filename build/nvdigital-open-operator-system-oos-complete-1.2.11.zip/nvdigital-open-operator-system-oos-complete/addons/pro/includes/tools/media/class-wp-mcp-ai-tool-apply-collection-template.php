<?php
/**
 * Tool for applying templates to a media collection.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Apply one or more templates to all items in a media collection.
 */
class WP_MCP_AI_Tool_Apply_Collection_Template implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'apply_collection_template';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Apply Collection Template', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Apply one or more templates to all items in a media collection. This is a convenience method that assigns templates to the collection and then processes it. Returns processing results and updates collection configuration.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Assigning and running templates across every item in an existing media collection in one call.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Processing a single image; use apply_media_template. Assigning only; set process=false here instead.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'process_collection', 'apply_media_template', 'create_media_collection' ),
			'notes'           => __( 'Set append=false to replace existing templates; process=false assigns templates without running the batch.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'collection_id' => array(
					'type'        => 'integer',
					'description' => __( 'ID of the media collection', 'nvdigital-open-operator-system-oos-pro' ),
					'minimum'     => 1,
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
				),
				'template_ids'  => array(
					'type'        => 'array',
					'description' => __( 'Array of template IDs to assign and apply', 'nvdigital-open-operator-system-oos-pro' ),
					'items'       => array(
						'type'    => 'integer',
						'minimum' => 1,
					),
				),
				'append'        => array(
					'type'        => 'boolean',
					'description' => __( 'If true, append to existing templates. If false, replace existing templates. Default: false', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => false,
				),
				'process'       => array(
					'type'        => 'boolean',
					'description' => __( 'If true, immediately process the collection. If false, only assign templates. Default: true', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => true,
				),
			),
			'required'   => array( 'collection_id', 'template_ids' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'upload_files';
	}

	/**
	 * {@inheritdoc}
	 */
	public function requires_base_pro() {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */

	/**
	 * Get extended tool definition including toolkit metadata.
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {
		return array(
			'name'                  => $this->get_name(),
			'description'           => $this->get_description(),
			'toolkit'               => 'media_content',
			'post_type'             => 'mcp_ai_media_coll',
			'pattern_compatibility' => array( 'orchestrator', 'sequential' ),
			'profession_tags'       => array( 'content_creator', 'designer' ),
			'risk_level'            => 'standard',
		);
	}

		/**
		 * Get capability flags for this tool.
		 *
		 * @return array
		 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro tier tool.
			'write',                // Modifies collection configuration and media items.
			'state-changing',       // Updates collection templates and statistics.
			'local-only',           // No external API calls (uses internal tools).
			'requires-capability',  // Requires upload_files capability.
			'async',                // May take significant time to process collections.
			'long-running',         // Processing multiple items can take minutes.
			'reversible',           // Changes can be undone via WordPress.
			'consumes-tokens',      // Uses AI via process_collection tool.
		);
	}

	/**
	 * {@inheritdoc}
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Check if media toolkit is enabled.
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		if ( empty( $settings['enable_media_toolkit'] ) ) {
			return new WP_Error(
				'tool_error',
				__( 'Media Toolkit is not enabled. Please enable it in Settings → NV oOS → Tools & Features.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		// Validate arguments.
		$collection_id = isset( $arguments['collection_id'] ) ? absint( $arguments['collection_id'] ) : 0;
		$template_ids  = isset( $arguments['template_ids'] ) && is_array( $arguments['template_ids'] ) ? array_map( 'absint', $arguments['template_ids'] ) : array();
		$append        = isset( $arguments['append'] ) ? (bool) $arguments['append'] : false;
		$process       = isset( $arguments['process'] ) ? (bool) $arguments['process'] : true;

		if ( empty( $collection_id ) ) {
			return new WP_Error(
				'tool_error',
				__( 'Collection ID is required.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		if ( empty( $template_ids ) ) {
			return new WP_Error(
				'tool_error',
				__( 'At least one template ID is required.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		// Verify collection exists.
		$collection = get_post( $collection_id );
		if ( ! $collection || 'mcp_ai_media_coll' !== $collection->post_type || 'publish' !== $collection->post_status ) {
			return new WP_Error(
				'tool_error',
				__( 'Invalid collection ID or collection is not published.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		// Verify all templates exist.
		foreach ( $template_ids as $template_id ) {
			$template = get_post( $template_id );
			if ( ! $template || 'mcp_ai_media_tpl' !== $template->post_type || 'publish' !== $template->post_status ) {
				return new WP_Error(
					'tool_error',
					sprintf(
						/* translators: %d: template ID */
						__( 'Invalid template ID %d or template is not published.', 'nvdigital-open-operator-system-oos-pro' ),
						$template_id
					)
				);
			}
		}

		// Get existing templates if appending.
		$final_template_ids = $template_ids;
		if ( $append ) {
			$existing = get_post_meta( $collection_id, '_mcp_ai_collection_templates', true );
			if ( is_array( $existing ) && ! empty( $existing ) ) {
				$final_template_ids = array_unique( array_merge( $existing, $template_ids ) );
			}
		}

		// Update collection templates.
		update_post_meta( $collection_id, '_mcp_ai_collection_templates', $final_template_ids );

		// Build response base.
		$response = array(
			'success'    => true,
			'collection' => array(
				'id'                 => $collection_id,
				'title'              => $collection->post_title,
				'template_ids'       => $final_template_ids,
				'templates_assigned' => count( $final_template_ids ),
			),
			'message'    => sprintf(
				/* translators: 1: number of templates, 2: collection title */
				__( 'Assigned %1$d template(s) to collection "%2$s".', 'nvdigital-open-operator-system-oos-pro' ),
				count( $final_template_ids ),
				$collection->post_title
			),
		);

		// Process collection if requested.
		if ( $process ) {
			$registry     = WP_MCP_AI_Tool_Registry::get_instance();
			$process_tool = $registry->get_tool( 'process_collection' );

			if ( ! $process_tool ) {
				$response['warning'] = __( 'Templates assigned but could not process collection: Process Collection tool is not available.', 'nvdigital-open-operator-system-oos-pro' );
				return $response;
			}

			// Execute process_collection tool.
			$process_result = $process_tool->execute(
				array(
					'collection_id' => $collection_id,
				),
				$context
			);

			// Merge process results.
			if ( is_wp_error( $process_result ) ) {
				$response['warning'] = sprintf(
					/* translators: %s: error message */
					__( 'Templates assigned but processing failed: %s', 'nvdigital-open-operator-system-oos-pro' ),
					$process_result->get_error_message()
				);
			} elseif ( ! empty( $process_result['success'] ) ) {
				$response['processing'] = array(
					'statistics' => isset( $process_result['statistics'] ) ? $process_result['statistics'] : array(),
					'results'    => isset( $process_result['results'] ) ? $process_result['results'] : array(),
				);
				$response['message']   .= ' ' . ( isset( $process_result['message'] ) ? $process_result['message'] : __( 'Collection processed.', 'nvdigital-open-operator-system-oos-pro' ) );
			} else {
				$response['warning'] = sprintf(
					/* translators: %s: error message */
					__( 'Templates assigned but processing failed: %s', 'nvdigital-open-operator-system-oos-pro' ),
					isset( $process_result['error'] ) ? $process_result['error'] : __( 'Unknown error', 'nvdigital-open-operator-system-oos-pro' )
				);
			}
		}

		return $response;
	}
}
