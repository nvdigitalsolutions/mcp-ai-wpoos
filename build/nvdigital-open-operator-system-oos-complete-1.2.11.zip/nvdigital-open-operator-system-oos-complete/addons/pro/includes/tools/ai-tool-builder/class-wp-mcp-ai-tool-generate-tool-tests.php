<?php
/**
 * Tool for generating PHPUnit tests for AI tools.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @phase Phase 2.9
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generate comprehensive PHPUnit tests for AI tools.
 *
 * This tool analyzes tool implementations and generates complete test suites
 * including unit tests, integration tests, edge cases, and mocking for
 * external dependencies.
 *
 * @since 1.1.0
 */
class WP_MCP_AI_Tool_Generate_Tool_Tests implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'generate_tool_tests';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Generate Tool Tests', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Generate comprehensive PHPUnit test suites for AI tools. Creates unit tests, integration tests, edge case coverage, and mocking for external dependencies. Follows WordPress and PHPUnit best practices.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Creating PHPUnit coverage for a tool class after its logic is implemented.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Fixing failing tests or refactoring code; use refactor_tool_code. Writing the tool itself; use generate_tool_logic.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'generate_tool_logic', 'generate_tool_scaffold', 'benchmark_tool_performance' ),
			'notes'           => __( 'Requires tool_class; mocks external dependencies by default and targets 80 percent coverage.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'tool_class'        => array(
					'type'        => 'string',
					'description' => __( 'Tool class name to generate tests for', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'tool_file'         => array(
					'type'        => 'string',
					'description' => __( 'Path to tool file (for analysis)', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'test_types'        => array(
					'type'        => 'array',
					'description' => __( 'Types of tests to generate', 'nvdigital-open-operator-system-oos-pro' ),
					'items'       => array(
						'type' => 'string',
						'enum' => array( 'unit', 'integration', 'edge-cases', 'security', 'performance' ),
					),
					'default'     => array( 'unit', 'integration', 'edge-cases' ),
				),
				'mock_dependencies' => array(
					'type'        => 'boolean',
					'description' => __( 'Generate mocks for external dependencies', 'nvdigital-open-operator-system-oos-pro' ),
					'default'     => true,
				),
				'coverage_goal'     => array(
					'type'        => 'integer',
					'description' => __( 'Target code coverage percentage', 'nvdigital-open-operator-system-oos-pro' ),
					'minimum'     => 50,
					'maximum'     => 100,
					'default'     => 80,
				),
				'output_path'       => array(
					'type'        => 'string',
					'description' => __( 'Custom output path for test file', 'nvdigital-open-operator-system-oos-pro' ),
				),
				'model'             => array(
					'type'        => 'string',
					'description' => __( 'AI model to use for test generation', 'nvdigital-open-operator-system-oos-pro' ),
				),
			),
			'required'   => array( 'tool_class' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',
			'write',
			'requires-capability',
			'consumes-tokens',
			'model-dependent',
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array|WP_Error Execution result.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Validate required parameters.
		if ( empty( $arguments['tool_class'] ) ) {
			return new WP_Error(
				'tool_error',
				__( 'Tool class name is required.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		$tool_class        = sanitize_text_field( $arguments['tool_class'] );
		$tool_file_raw     = isset( $arguments['tool_file'] ) ? sanitize_text_field( $arguments['tool_file'] ) : '';
		$test_types        = isset( $arguments['test_types'] ) ? array_map( 'sanitize_text_field', (array) $arguments['test_types'] ) : array( 'unit', 'integration', 'edge-cases' );
		$mock_dependencies = isset( $arguments['mock_dependencies'] ) ? (bool) $arguments['mock_dependencies'] : true;
		$coverage_goal     = isset( $arguments['coverage_goal'] ) ? absint( $arguments['coverage_goal'] ) : 80;

		// Load tool code for analysis.
		$tool_code = '';
		if ( ! empty( $tool_file_raw ) ) {
			// Security: Resolve canonical path and restrict to the WordPress content.
			// directory to prevent reading arbitrary server files.
			$resolved_tool = realpath( $tool_file_raw );
			if ( false !== $resolved_tool &&
				defined( 'WP_CONTENT_DIR' ) &&
				0 === strpos( wp_normalize_path( $resolved_tool ), trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ) ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading local PHP tool file; path validated against WP_CONTENT_DIR.
				$tool_code = file_get_contents( $resolved_tool );
			}
		}

		// Analyze tool structure.
		$tool_analysis = $this->analyze_tool( $tool_class, $tool_code );

		// Build test generation prompt.
		$prompt = $this->build_test_generation_prompt( $tool_class, $tool_analysis, $test_types, $mock_dependencies, $coverage_goal );

		// Get AI service.
		$ai_service = $this->get_ai_service( $arguments, $context );
		if ( is_wp_error( $ai_service ) ) {
			return new WP_Error(
				'tool_error',
				$ai_service->get_error_message()
			);
		}

		// Generate tests using AI.
		$ai_response = $ai_service->generate( $prompt );

		if ( is_wp_error( $ai_response ) ) {
			return new WP_Error(
				'tool_error',
				sprintf(
					/* translators: %s: error message */
					__( 'Test generation failed: %s', 'nvdigital-open-operator-system-oos-pro' ),
					$ai_response->get_error_message()
				)
			);
		}

		// Extract test code.
		$test_code = $this->extract_php_code( $ai_response );

		if ( is_wp_error( $test_code ) ) {
			return new WP_Error(
				'tool_error',
				$test_code->get_error_message()
			);
		}

		// Determine output path.
		$output_path = $this->determine_output_path( $tool_class, $arguments );

		// Propagate path validation errors.
		if ( is_wp_error( $output_path ) ) {
			return new WP_Error(
				'tool_error',
				$output_path->get_error_message()
			);
		}

		// Write test file.
		$bytes_written = file_put_contents( $output_path, $test_code );

		if ( false === $bytes_written ) {
			return new WP_Error(
				'tool_error',
				__( 'Failed to write test file.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		// Count test methods.
		$test_count = substr_count( $test_code, 'public function test_' );

		return array(
			'success'    => true,
			'message'    => __( 'Test suite generated successfully.', 'nvdigital-open-operator-system-oos-pro' ),
			'test_file'  => $output_path,
			'test_count' => $test_count,
			'test_types' => $test_types,
			'file_size'  => $bytes_written,
			'next_steps' => array(
				'1' => sprintf(
					/* translators: %s: test file output path */
					__( 'Run: vendor/bin/phpunit %s', 'nvdigital-open-operator-system-oos-pro' ),
					$output_path
				),
				'2' => __( 'Review test coverage', 'nvdigital-open-operator-system-oos-pro' ),
				'3' => __( 'Add tool-specific assertions', 'nvdigital-open-operator-system-oos-pro' ),
			),
		);
	}

	/**
	 * Analyze tool structure and methods.
	 *
	 * @param string $tool_class Tool class name.
	 * @param string $tool_code  Tool source code.
	 * @return array Analysis results.
	 */
	private function analyze_tool( $tool_class, $tool_code ) {
		$analysis = array(
			'class_name'   => $tool_class,
			'methods'      => array(),
			'parameters'   => array(),
			'dependencies' => array(),
		);

		if ( empty( $tool_code ) ) {
			return $analysis;
		}

		// Extract methods.
		preg_match_all( '/public function (\w+)\(/', $tool_code, $method_matches );
		if ( ! empty( $method_matches[1] ) ) {
			$analysis['methods'] = $method_matches[1];
		}

		// Check for external dependencies.
		if ( strpos( $tool_code, 'wp_remote_' ) !== false ) {
			$analysis['dependencies'][] = 'wp_http';
		}
		if ( strpos( $tool_code, 'WP_Query' ) !== false ) {
			$analysis['dependencies'][] = 'wp_query';
		}

		return $analysis;
	}

	/**
	 * Build test generation prompt.
	 *
	 * @param string $tool_class       Tool class name.
	 * @param array  $tool_analysis    Tool analysis results.
	 * @param array  $test_types       Test types to generate.
	 * @param bool   $mock_dependencies Mock dependencies flag.
	 * @param int    $coverage_goal    Coverage goal percentage.
	 * @return string AI prompt.
	 */
	private function build_test_generation_prompt( $tool_class, $tool_analysis, $test_types, $mock_dependencies, $coverage_goal ) {
		$prompt = "Generate a comprehensive PHPUnit test suite for WordPress AI tool: {$tool_class}\n\n";

		$prompt .= "Test Requirements:\n";
		$prompt .= "- Extend WP_UnitTestCase\n";
		$prompt .= "- Target {$coverage_goal}% code coverage\n";
		$prompt .= "- Follow WordPress testing best practices\n";

		if ( ! empty( $tool_analysis['methods'] ) ) {
			$prompt .= "\nMethods to test:\n";
			foreach ( $tool_analysis['methods'] as $method ) {
				$prompt .= "- {$method}()\n";
			}
		}

		$prompt .= "\nInclude these test types:\n";
		foreach ( $test_types as $type ) {
			switch ( $type ) {
				case 'unit':
					$prompt .= "- Unit tests for individual methods\n";
					break;
				case 'integration':
					$prompt .= "- Integration tests for end-to-end workflows\n";
					break;
				case 'edge-cases':
					$prompt .= "- Edge case tests (empty input, invalid data, etc.)\n";
					break;
				case 'security':
					$prompt .= "- Security tests (capability checks, sanitization)\n";
					break;
				case 'performance':
					$prompt .= "- Performance tests (timing assertions)\n";
					break;
			}
		}

		if ( $mock_dependencies && ! empty( $tool_analysis['dependencies'] ) ) {
			$prompt .= "\nMock these dependencies:\n";
			foreach ( $tool_analysis['dependencies'] as $dep ) {
				$prompt .= "- {$dep}\n";
			}
		}

		$prompt .= "\nGenerate complete test class with:\n";
		$prompt .= "1. setUp() and tearDown() methods\n";
		$prompt .= "2. Test methods with assertions\n";
		$prompt .= "3. Helper methods if needed\n";
		$prompt .= "4. PHPDoc blocks\n\n";
		$prompt .= 'Output only PHP code.';

		return $prompt;
	}

	/**
	 * Get AI service instance.
	 *
	 * @param array $arguments Tool arguments.
	 *
	 * @param array $context   Execution context.
	 * @return object|WP_Error AI service or error.
	 */
	private function get_ai_service( $arguments, $context ) {
		$model = isset( $arguments['model'] ) ? sanitize_text_field( $arguments['model'] ) : '';

		if ( empty( $model ) && isset( $context['assistant_model'] ) ) {
			$model = $context['assistant_model'];
		}

		if ( ! class_exists( 'WP_MCP_AI_Client' ) ) {
			return new WP_Error(
				'wp_mcp_ai_service_unavailable',
				__( 'AI service is not available.', 'nvdigital-open-operator-system-oos-pro' )
			);
		}

		return new WP_MCP_AI_Client( $model );
	}

	/**
	 * Extract PHP code from AI response.
	 *
	 * @param string $response AI response.
	 * @return string|WP_Error PHP code or error.
	 */
	private function extract_php_code( $response ) {
		$php_pattern = '/```php\s*(.*?)\s*```/s';
		if ( preg_match( $php_pattern, $response, $matches ) ) {
			return trim( $matches[1] );
		}

		$code_pattern = '/```\s*(.*?)\s*```/s';
		if ( preg_match( $code_pattern, $response, $matches ) ) {
			return trim( $matches[1] );
		}

		if ( strpos( $response, 'class Test_' ) !== false ) {
			return trim( $response );
		}

		return new WP_Error(
			'wp_mcp_ai_no_code_found',
			__( 'Could not extract test code from AI response.', 'nvdigital-open-operator-system-oos-pro' )
		);
	}

	/**
	 * Determine output path for test file.
	 *
	 * @param string $tool_class Tool class name.
	 * @param array  $arguments  Tool arguments.
	 * @return string Output path.
	 */
	private function determine_output_path( $tool_class, $arguments ) {
		if ( isset( $arguments['output_path'] ) && ! empty( $arguments['output_path'] ) ) {
			$output_path = sanitize_text_field( $arguments['output_path'] );

			// Security: Restrict to the WordPress content directory to prevent.
			// writing PHP files to arbitrary server paths.
			$resolved = realpath( dirname( $output_path ) );
			if ( false === $resolved ) {
				return new WP_Error(
					'invalid_output_path',
					__( 'Invalid output path: parent directory does not exist.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( ! defined( 'WP_CONTENT_DIR' ) ) {
				return new WP_Error(
					'invalid_output_path',
					__( 'WordPress content directory is not defined.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}
			if ( 0 !== strpos( wp_normalize_path( $resolved ), trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ) ) ) {
				return new WP_Error(
					'invalid_output_path',
					__( 'Output path must be within the WordPress content directory.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			return $output_path;
		}

		$test_name = 'test-' . str_replace( '_', '-', strtolower( str_replace( 'WP_MCP_AI_Tool_', '', $tool_class ) ) ) . '.php';
		return WP_MCP_AI_PRO_PATH . 'tests/tools/' . $test_name;
	}
}
