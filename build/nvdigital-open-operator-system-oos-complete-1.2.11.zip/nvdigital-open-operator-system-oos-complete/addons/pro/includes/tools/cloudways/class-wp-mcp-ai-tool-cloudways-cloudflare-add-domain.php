<?php
/**
 * Cloudways Cloudflare Add Domain Tool
 *
 * Add a domain to Cloudflare CDN for an application.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_Cloudflare_Add_Domain' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_Cloudflare_Add_Domain extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_cloudflare_add_domain';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Cloudflare Add Domain', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Add a domain to Cloudflare CDN for an application.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Putting a new domain behind Cloudflare CDN for an existing application.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Checking CDN status or configuration; use cloudways_cloudflare_details to review first.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_cloudflare_details', 'cloudways_get_app', 'cloudways_dns_list_domains' ),
				'notes'           => __( 'Requires server_id, app_id, and domain; DNS must resolve correctly for the CDN to serve traffic.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'app_id'    => array(
						'type'        => 'integer',
						'description' => __( 'The application ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'domain'    => array(
						'type'        => 'string',
						'description' => __( 'The domain name to add.', 'nvdigital-open-operator-system-oos-pro' ),
						'minLength'   => 1,
					),
				),
				'required'   => array( 'server_id', 'app_id', 'domain' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$app_id    = $this->sanitize_app_id( $arguments );
			$domain    = isset( $arguments['domain'] ) ? sanitize_text_field( $arguments['domain'] ) : '';

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( 0 === $app_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_app_id',
					__( 'A valid app ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( '' === $domain ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_domain',
					__( 'A domain name is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/app/' . $server_id . '/' . $app_id . '/cloudflare/domain';
			$body   = array( 'domain' => $domain );
			$result = $this->client()->post( $path, $body );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return $this->success(
				sprintf(
					/* translators: %s: domain name */
					__( 'Domain "%s" added to Cloudflare CDN.', 'nvdigital-open-operator-system-oos-pro' ),
					esc_html( $domain )
				),
				$result
			);
		}
	}
}
