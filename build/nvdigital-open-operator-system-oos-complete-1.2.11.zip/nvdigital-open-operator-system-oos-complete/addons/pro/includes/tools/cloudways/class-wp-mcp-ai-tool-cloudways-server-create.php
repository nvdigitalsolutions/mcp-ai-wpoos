<?php
/**
 * Cloudways Create Server Tool
 *
 * Create a new server on DigitalOcean, AWS, GCE, Vultr, or Linode
 * with an initial application.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.16
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_Server_Create' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_Server_Create extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_server_create';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Create Server', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Create a new server on DigitalOcean, AWS, GCE, Vultr, or Linode with an initial application.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Provisioning a brand new server with an initial app on digitalocean, aws, gce, vultr, or linode.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Copying an existing server; use cloudways_server_clone instead.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_server_clone', 'cloudways_list_servers', 'cloudways_get_server', 'cloudways_get_operation_status' ),
				'notes'           => __( 'Starts recurring billing immediately; double-check cloud, size, region, app, and label values first.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'cloud'  => array(
						'type'        => 'string',
						'description' => __( 'The cloud provider.', 'nvdigital-open-operator-system-oos-pro' ),
						'enum'        => array( 'digitalocean', 'aws', 'gce', 'vultr', 'linode' ),
					),
					'size'   => array(
						'type'        => 'string',
						'description' => __( 'The server size (e.g. "2GB").', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'region' => array(
						'type'        => 'string',
						'description' => __( 'The deployment region.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'app'    => array(
						'type'        => 'string',
						'description' => __( 'The initial application type.', 'nvdigital-open-operator-system-oos-pro' ),
						'enum'        => array( 'wordpress', 'woocommerce', 'laravel', 'magento', 'php' ),
					),
					'label'  => array(
						'type'        => 'string',
						'description' => __( 'The server label.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'cloud', 'size', 'region', 'app', 'label' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing', 'reversible' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$cloud  = isset( $arguments['cloud'] ) ? sanitize_text_field( $arguments['cloud'] ) : '';
			$size   = isset( $arguments['size'] ) ? sanitize_text_field( $arguments['size'] ) : '';
			$region = isset( $arguments['region'] ) ? sanitize_text_field( $arguments['region'] ) : '';
			$app    = isset( $arguments['app'] ) ? sanitize_text_field( $arguments['app'] ) : '';
			$label  = $this->sanitize_label( $arguments );

			$valid_clouds = array( 'digitalocean', 'aws', 'gce', 'vultr', 'linode' );
			if ( '' === $cloud || ! in_array( $cloud, $valid_clouds, true ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_cloud',
					__( 'A valid cloud provider is required (digitalocean, aws, gce, vultr, linode).', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( '' === $size ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_size',
					__( 'A valid server size is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( '' === $region ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_region',
					__( 'A valid region is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$valid_apps = array( 'wordpress', 'woocommerce', 'laravel', 'magento', 'php' );
			if ( '' === $app || ! in_array( $app, $valid_apps, true ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_app',
					__( 'A valid application type is required (WordPress, woocommerce, laravel, magento, php).', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( '' === $label ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_label',
					__( 'A valid label is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/server';
			$body   = array(
				'cloud'  => $cloud,
				'size'   => $size,
				'region' => $region,
				'app'    => $app,
				'label'  => $label,
			);
			$result = $this->client()->post( $path, $body );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return $this->success(
				__( 'Server creation initiated.', 'nvdigital-open-operator-system-oos-pro' ),
				$result
			);
		}
	}
}
