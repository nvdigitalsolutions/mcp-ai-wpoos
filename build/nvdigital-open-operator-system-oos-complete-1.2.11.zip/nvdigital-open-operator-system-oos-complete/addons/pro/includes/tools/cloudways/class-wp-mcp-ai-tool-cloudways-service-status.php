<?php
/**
 * Cloudways Service Status Tool
 *
 * Check the status of all services (nginx, mysql, php-fpm, varnish, redis)
 * on a server.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_Service_Status' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_Service_Status extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_service_status';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Check Service Status', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Check the status of all services (nginx, mysql, php-fpm, varnish, redis) on a server.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Checking whether nginx, mysql, php-fpm, varnish, and redis are running on a server during incident triage.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Restarting anything or checking capacity; use cloudways_restart_service or cloudways_server_monitor_summary.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_restart_service', 'cloudways_server_monitor_summary', 'cloudways_get_server' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'read-only', 'cacheable' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/service/' . $server_id;
			$result = $this->client()->get( $path );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! isset( $result['services'] ) || ! is_array( $result['services'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_response',
					__( 'Cloudways returned an unexpected response format.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$services = array();
			foreach ( $result['services'] as $service ) {
				$services[] = array(
					'name'   => sanitize_text_field( $service['name'] ),
					'status' => sanitize_text_field( $service['status'] ),
				);
			}

			return $this->success(
				sprintf(
					/* translators: %d: server ID */
					__( 'Service status retrieved for server %d.', 'nvdigital-open-operator-system-oos-pro' ),
					$server_id
				),
				array( 'services' => $services )
			);
		}
	}
}
