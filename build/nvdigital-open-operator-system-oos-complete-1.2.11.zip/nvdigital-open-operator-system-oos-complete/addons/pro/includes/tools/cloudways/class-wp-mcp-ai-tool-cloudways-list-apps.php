<?php
/**
 * Cloudways List Apps Tool
 *
 * List all applications on a specific Cloudways server.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_List_Apps' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_List_Apps extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_list_apps';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'List Cloudways Applications', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'List all applications on a specific Cloudways server.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Discovering app IDs, labels, and types on a known server before app-level operations.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Finding servers or one app\'s details; use cloudways_list_servers or cloudways_get_app.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_list_servers', 'cloudways_get_app', 'cloudways_get_server' ),
				'notes'           => __( 'Requires a server_id; app IDs from this list feed tools like cloudways_get_app and cloudways_purge_app_cache.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'read-only', 'cacheable' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/app';
			$query  = array( 'server_id' => $server_id );
			$result = $this->client()->get( $path, $query );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! isset( $result['apps'] ) || ! is_array( $result['apps'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_response',
					__( 'Cloudways returned an unexpected response format.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$apps = array();
			foreach ( $result['apps'] as $app ) {
				$apps[] = array(
					'id'       => absint( $app['id'] ),
					'label'    => sanitize_text_field( $app['label'] ),
					'app_type' => sanitize_text_field( $app['app_type'] ),
					'status'   => sanitize_text_field( $app['status'] ),
				);
			}

			return $this->success(
				sprintf(
					/* translators: 1: number of apps, 2: server ID */
					_n( 'Found %1$d app on server %2$d.', 'Found %1$d apps on server %2$d.', count( $apps ), 'nvdigital-open-operator-system-oos-pro' ),
					count( $apps ),
					$server_id
				),
				array( 'apps' => $apps )
			);
		}
	}
}
