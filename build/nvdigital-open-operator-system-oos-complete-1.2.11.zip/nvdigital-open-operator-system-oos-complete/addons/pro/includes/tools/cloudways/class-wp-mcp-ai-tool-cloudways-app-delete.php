<?php
/**
 * Cloudways Delete App Tool
 *
 * Permanently delete an application and its data.
 * THIS ACTION IS IRREVERSIBLE.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.16
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_App_Delete' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_App_Delete extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_app_delete';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Delete App', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Permanently delete an application and its data. THIS ACTION IS IRREVERSIBLE.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Permanently removing an application after the user has explicitly confirmed deletion.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Temporary changes or stoppages; verify the target with cloudways_get_app first.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_get_app', 'cloudways_create_app_backup', 'cloudways_list_apps' ),
				'notes'           => __( 'Requires confirm=true. Deletion is irreversible and removes all app data; take a backup first.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'app_id'    => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The application ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'confirm'   => array(
						'type'        => 'boolean',
						'description' => __( 'Set to true to confirm this irreversible action.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id', 'app_id', 'confirm' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing', 'non-reversible' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$app_id    = $this->sanitize_app_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( 0 === $app_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_app_id',
					__( 'A valid app ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( ! $this->sanitize_confirm( $arguments ) ) {
				return new WP_Error(
					'cloudways_confirm_required',
					__( 'You must set confirm to true to perform this destructive action.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/app/' . $server_id . '/' . $app_id;
			$result = $this->client()->delete( $path, array() );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return $this->success(
				__( 'Application permanently deleted.', 'nvdigital-open-operator-system-oos-pro' ),
				$result
			);
		}
	}
}
