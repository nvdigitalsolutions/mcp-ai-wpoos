<?php
/**
 * Cloudways Rollback Restore Tool
 *
 * Roll back the last backup restore action.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.16
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_App_Restore_Rollback' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_App_Restore_Rollback extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_app_restore_rollback';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Rollback Restore', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Roll back the last backup restore action.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Reversing the last backup restore when the restored state was wrong.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Restoring to a backup in the first place; use cloudways_app_restore.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_app_restore', 'cloudways_create_app_backup', 'cloudways_get_operation_status' ),
				'notes'           => __( 'Only undoes the most recent restore; check cloudways_get_operation_status if state is unclear.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'app_id'    => array(
						'type'        => 'integer',
						'description' => __( 'The application ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id', 'app_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing', 'reversible' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$app_id    = $this->sanitize_app_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( 0 === $app_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_app_id',
					__( 'A valid app ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/app/' . $server_id . '/' . $app_id . '/restore/rollback';
			$result = $this->client()->post( $path, array() );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return $this->success(
				__( 'Restore rollback initiated.', 'nvdigital-open-operator-system-oos-pro' ),
				$result
			);
		}
	}
}
