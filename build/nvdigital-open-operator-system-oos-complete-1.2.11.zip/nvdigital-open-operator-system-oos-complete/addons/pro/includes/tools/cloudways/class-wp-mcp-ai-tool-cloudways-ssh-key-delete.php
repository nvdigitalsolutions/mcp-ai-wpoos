<?php
/**
 * Cloudways SSH Key Delete Tool
 *
 * Delete a previously added SSH key by its ID.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_SSH_Key_Delete' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_SSH_Key_Delete extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_ssh_key_delete';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Delete SSH Key', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Delete a previously added SSH key by its ID.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Revoking access by removing an SSH key that is no longer trusted, identified by its key ID.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Discovering key IDs or removing all access; run cloudways_ssh_key_list first.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_ssh_key_list', 'cloudways_ssh_key_create' ),
				'notes'           => __( 'Permanent: deleting a key immediately revokes access for everyone using it and cannot be undone.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'ssh_key_id' => array(
						'type'        => 'integer',
						'description' => __( 'The SSH key ID to delete.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'ssh_key_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing', 'non-reversible' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$ssh_key_id = isset( $arguments['ssh_key_id'] ) ? absint( $arguments['ssh_key_id'] ) : 0;

			if ( 0 === $ssh_key_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_ssh_key_id',
					__( 'A valid SSH key ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/ssh-key/' . $ssh_key_id;
			$result = $this->client()->delete( $path, array() );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return $this->success(
				sprintf(
					/* translators: %d: SSH key ID */
					__( 'SSH key %d deleted successfully.', 'nvdigital-open-operator-system-oos-pro' ),
					$ssh_key_id
				),
				$result
			);
		}
	}
}
