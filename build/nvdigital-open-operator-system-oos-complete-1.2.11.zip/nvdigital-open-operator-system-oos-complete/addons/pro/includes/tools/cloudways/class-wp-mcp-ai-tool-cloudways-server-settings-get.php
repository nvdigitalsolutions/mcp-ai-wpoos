<?php
/**
 * Cloudways Server Settings Get Tool
 *
 * View server and PHP/MySQL configuration.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_Server_Settings_Get' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_Server_Settings_Get extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_server_settings_get';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Get Server Settings', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'View server and PHP/MySQL configuration.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Viewing PHP, MySQL, and nginx versions and settings for one server before tuning or troubleshooting.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Runtime service health or capacity; use cloudways_service_status or cloudways_server_monitor_summary.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_get_server', 'cloudways_service_status', 'cloudways_restart_service' ),
				'notes'           => __( 'Requires a server_id from cloudways_list_servers; read-only and safe to call.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'read-only', 'cacheable' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/server/' . $server_id . '/settings';
			$result = $this->client()->get( $path );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! isset( $result['settings'] ) || ! is_array( $result['settings'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_response',
					__( 'Cloudways returned an unexpected response format.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$settings = $result['settings'];

			$data = array(
				'php_version'   => isset( $settings['php_version'] ) ? sanitize_text_field( $settings['php_version'] ) : '',
				'mysql_version' => isset( $settings['mysql_version'] ) ? sanitize_text_field( $settings['mysql_version'] ) : '',
				'nginx_version' => isset( $settings['nginx_version'] ) ? sanitize_text_field( $settings['nginx_version'] ) : '',
			);

			return $this->success(
				sprintf(
					/* translators: %d: server ID */
					__( 'Settings retrieved for server %d.', 'nvdigital-open-operator-system-oos-pro' ),
					$server_id
				),
				array( 'settings' => $data )
			);
		}
	}
}
