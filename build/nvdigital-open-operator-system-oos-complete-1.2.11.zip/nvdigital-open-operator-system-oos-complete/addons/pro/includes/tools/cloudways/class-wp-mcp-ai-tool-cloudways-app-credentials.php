<?php
/**
 * Cloudways App Credentials Tool
 *
 * Get SSH/SFTP credentials for an application.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_App_Credentials' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_App_Credentials extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_app_credentials';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Get App Credentials', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Get SSH/SFTP credentials for an application.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Fetching the SSH or SFTP host, username, and port for a known application.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Listing SSH keys on a server; use cloudways_ssh_key_list for key management context.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_get_app', 'cloudways_ssh_key_list', 'cloudways_list_apps' ),
				'notes'           => __( 'Returns host, username, and port only; key material stays managed by the Cloudways platform.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'app_id'    => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The application ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id', 'app_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing', 'reversible' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$app_id    = $this->sanitize_app_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( 0 === $app_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_app_id',
					__( 'A valid app ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/app/' . $server_id . '/' . $app_id . '/credentials';
			$result = $this->client()->get( $path );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! isset( $result['credentials'] ) || ! is_array( $result['credentials'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_response',
					__( 'Cloudways returned an unexpected response format.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$credentials = $result['credentials'];

			$data = array(
				'host'     => isset( $credentials['host'] ) ? sanitize_text_field( $credentials['host'] ) : '',
				'username' => isset( $credentials['username'] ) ? sanitize_text_field( $credentials['username'] ) : '',
				'port'     => isset( $credentials['port'] ) ? absint( $credentials['port'] ) : 22,
			);

			return $this->success(
				sprintf(
					/* translators: %d: app ID */
					__( 'Credentials retrieved for app %d.', 'nvdigital-open-operator-system-oos-pro' ),
					$app_id
				),
				array( 'credentials' => $data )
			);
		}
	}
}
