<?php
/**
 * Cloudways Scale Server Tool
 *
 * Upgrade or downgrade server size (CPU/RAM).
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.16
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_Server_Scale' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_Server_Scale extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_server_scale';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Scale Server', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Upgrade or downgrade server size (CPU/RAM).', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Changing CPU/RAM size to match sustained load changes or to adjust hosting cost.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Disk space shortages; use cloudways_server_scale_volume instead.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_server_scale_volume', 'cloudways_server_monitor_summary', 'cloudways_get_server', 'cloudways_get_operation_status' ),
				'notes'           => __( 'Billing changes with the new size; the resize runs async, so verify with cloudways_get_operation_status.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'size'      => array(
						'type'        => 'string',
						'description' => __( 'The desired server size (e.g. "2GB").', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id', 'size' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing', 'reversible', 'performance-impact' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$size      = isset( $arguments['size'] ) ? sanitize_text_field( $arguments['size'] ) : '';

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( '' === $size ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_size',
					__( 'A valid server size is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/server/' . $server_id . '/scale';
			$body   = array( 'size' => $size );
			$result = $this->client()->put( $path, $body );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return $this->success(
				/* translators: %s: server size */
				sprintf( __( 'Server scaling initiated.', 'nvdigital-open-operator-system-oos-pro' ), esc_html( $size ) ),
				$result
			);
		}
	}
}
