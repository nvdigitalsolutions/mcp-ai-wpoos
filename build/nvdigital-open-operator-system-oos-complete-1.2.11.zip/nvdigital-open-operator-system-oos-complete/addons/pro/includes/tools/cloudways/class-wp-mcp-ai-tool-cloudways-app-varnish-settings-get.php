<?php
/**
 * Cloudways App Varnish Settings Get Tool
 *
 * Retrieve Varnish configuration (TTL, cacheable paths, exclusions) for an application.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_App_Varnish_Settings_Get' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_App_Varnish_Settings_Get extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_app_varnish_settings_get';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Get App Varnish Settings', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Retrieve Varnish configuration (TTL, cacheable paths, exclusions) for an application.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Reviewing current Varnish TTL, enabled state, cacheable paths, and exclusions for an app.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Changing cache behavior; use cloudways_app_varnish_settings_update to write new values.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_app_varnish_settings_update', 'cloudways_purge_app_cache', 'cloudways_get_app' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'app_id'    => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The application ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id', 'app_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'read-only', 'cacheable' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$app_id    = $this->sanitize_app_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( 0 === $app_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_app_id',
					__( 'A valid app ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/app/' . $server_id . '/' . $app_id . '/varnish/settings';
			$result = $this->client()->get( $path );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! isset( $result['varnish_settings'] ) || ! is_array( $result['varnish_settings'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_response',
					__( 'Cloudways returned an unexpected response format.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$vs               = $result['varnish_settings'];
			$varnish_settings = array(
				'ttl'             => isset( $vs['ttl'] ) ? absint( $vs['ttl'] ) : 0,
				'enabled'         => isset( $vs['enabled'] ) ? (bool) $vs['enabled'] : false,
				'cacheable_paths' => isset( $vs['cacheable_paths'] ) ? sanitize_text_field( $vs['cacheable_paths'] ) : '',
				'exclusions'      => isset( $vs['exclusions'] ) ? sanitize_text_field( $vs['exclusions'] ) : '',
			);

			return $this->success(
				__( 'Varnish settings retrieved.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'varnish_settings' => $varnish_settings )
			);
		}
	}
}
