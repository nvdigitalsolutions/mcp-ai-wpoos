<?php
/**
 * Cloudways Update Server Label Tool
 *
 * Rename a server.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_Update_Server_Label' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_Update_Server_Label extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_update_server_label';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Update Server Label', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Rename a server.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Renaming a server in the Cloudways console for clearer identification and organization.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Renaming apps or changing server configuration; use cloudways_update_app_label.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_update_app_label', 'cloudways_list_servers', 'cloudways_get_server' ),
				'notes'           => __( 'Requires a server_id from cloudways_list_servers; the label is cosmetic and does not affect services.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'label'     => array(
						'type'        => 'string',
						'description' => __( 'The new server label.', 'nvdigital-open-operator-system-oos-pro' ),
						'minLength'   => 1,
					),
				),
				'required'   => array( 'server_id', 'label' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing', 'reversible' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$label     = $this->sanitize_label( $arguments, 'label' );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( '' === $label ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_label',
					__( 'A label is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/server/' . $server_id . '/label';
			$body   = array( 'label' => $label );
			$result = $this->client()->put( $path, $body );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return $this->success(
				sprintf(
					/* translators: 1: new label, 2: server ID */
					__( 'Server renamed to "%1$s" (ID: %2$d).', 'nvdigital-open-operator-system-oos-pro' ),
					esc_html( $label ),
					$server_id
				),
				$result
			);
		}
	}
}
