<?php
/**
 * Cloudways App Cron List Get Tool
 *
 * Retrieve the list of cron jobs for an application.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_App_Cron_List_Get' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_App_Cron_List_Get extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_app_cron_list_get';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Get App Cron List', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'Retrieve the list of cron jobs for an application.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Listing the scheduled cron jobs for a known application along with their commands.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Creating or deleting cron jobs; this tool is read-only, so manage them in the Cloudways console.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_list_apps', 'cloudways_get_app' ),
				'notes'           => __( 'Requires server_id and app_id; discover them with the list tools first.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'app_id'    => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The application ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id', 'app_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing', 'reversible' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$app_id    = $this->sanitize_app_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( 0 === $app_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_app_id',
					__( 'A valid app ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/app/' . $server_id . '/' . $app_id . '/cron';
			$result = $this->client()->get( $path );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! isset( $result['cron_jobs'] ) || ! is_array( $result['cron_jobs'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_response',
					__( 'Cloudways returned an unexpected response format.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$cron_jobs = array();
			foreach ( $result['cron_jobs'] as $job ) {
				$cron_jobs[] = array(
					'id'       => isset( $job['id'] ) ? absint( $job['id'] ) : 0,
					'schedule' => isset( $job['schedule'] ) ? sanitize_text_field( $job['schedule'] ) : '',
					'command'  => isset( $job['command'] ) ? sanitize_text_field( $job['command'] ) : '',
				);
			}

			return $this->success(
				sprintf(
					/* translators: %d: number of cron jobs */
					_n( 'Found %d cron job.', 'Found %d cron jobs.', count( $cron_jobs ), 'nvdigital-open-operator-system-oos-pro' ),
					count( $cron_jobs )
				),
				array( 'cron_jobs' => $cron_jobs )
			);
		}
	}
}
