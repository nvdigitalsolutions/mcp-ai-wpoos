<?php
/**
 * Cloudways Update App CNAME Tool
 *
 * Update an application's primary domain (CNAME).
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.16
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_App_CNAME_Update' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_App_CNAME_Update extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_app_cname_update';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Update App CNAME', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( "Update an application's primary domain (CNAME).", 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Changing an application primary domain or CNAME after the new DNS is ready.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Creating or removing DNS records; use cloudways_dns_add_record or cloudways_dns_delete_record.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_get_app', 'cloudways_dns_add_record', 'cloudways_list_apps' ),
				'notes'           => __( 'Requires server_id and app_id; updating the CNAME before DNS resolves can take the app offline.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'app_id'    => array(
						'type'        => 'integer',
						'description' => __( 'The application ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'cname'     => array(
						'type'        => 'string',
						'description' => __( 'The new primary domain (CNAME).', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id', 'app_id', 'cname' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'write', 'state-changing', 'reversible' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$app_id    = $this->sanitize_app_id( $arguments );
			$cname     = isset( $arguments['cname'] ) ? sanitize_text_field( $arguments['cname'] ) : '';

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( 0 === $app_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_app_id',
					__( 'A valid app ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( '' === $cname ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_cname',
					__( 'A valid CNAME is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/app/' . $server_id . '/' . $app_id . '/cname';
			$body   = array( 'cname' => $cname );
			$result = $this->client()->put( $path, $body );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return $this->success(
				/* translators: %s: CNAME value */
				sprintf( __( 'CNAME updated.', 'nvdigital-open-operator-system-oos-pro' ), esc_html( $cname ) ),
				$result
			);
		}
	}
}
