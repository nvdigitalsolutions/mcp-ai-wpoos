<?php
/**
 * Cloudways Server Monitor Summary Tool
 *
 * View server bandwidth and disk usage metrics.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_Server_Monitor_Summary' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_Server_Monitor_Summary extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_server_monitor_summary';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'Server Monitoring Summary', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'View server bandwidth and disk usage metrics.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Checking bandwidth and disk usage for one server when investigating capacity or overage concerns.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'App-level metrics or service health; use cloudways_app_monitor_summary or cloudways_service_status.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_get_server', 'cloudways_service_status', 'cloudways_server_scale_volume' ),
				'notes'           => __( 'Requires a server_id from cloudways_list_servers.', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'read-only', 'cacheable' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/server/' . $server_id . '/monitor/summary';
			$result = $this->client()->get( $path );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! isset( $result['summary'] ) || ! is_array( $result['summary'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_response',
					__( 'Cloudways returned an unexpected response format.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$summary = $result['summary'];

			$data = array(
				'bandwidth' => isset( $summary['bandwidth'] ) ? sanitize_text_field( $summary['bandwidth'] ) : '',
				'disk'      => isset( $summary['disk'] ) ? sanitize_text_field( $summary['disk'] ) : '',
			);

			return $this->success(
				sprintf(
					/* translators: %d: server ID */
					__( 'Monitoring summary retrieved for server %d.', 'nvdigital-open-operator-system-oos-pro' ),
					$server_id
				),
				array( 'summary' => $data )
			);
		}
	}
}
