<?php
/**
 * Cloudways App Monitor Summary Tool
 *
 * View application-level usage metrics.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Cloudways_Toolkit
 * @since      1.1.15
 * @author     NV Digital Solutions
 * @copyright  Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license    Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Tool_Cloudways_App_Monitor_Summary' ) ) {

	/**
	 * {@inheritdoc}
	 */
	class WP_MCP_AI_Tool_Cloudways_App_Monitor_Summary extends WP_MCP_AI_Tool_Cloudways_Base implements WP_MCP_AI_Tool_Usage_Guidance_Interface {

		/** {@inheritdoc} */

		/** {@inheritdoc} */
		public function get_slug() {
			return 'cloudways_app_monitor_summary';
		}

		/** {@inheritdoc} */
		public function get_name() {
			return __( 'App Monitoring Summary', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_description() {
			return __( 'View application-level usage metrics.', 'nvdigital-open-operator-system-oos-pro' );
		}

		/** {@inheritdoc} */
		public function get_usage_guidance() {
			return array(
				'when_to_use'     => __( 'Getting a quick overview of requests and bandwidth usage for a known application.', 'nvdigital-open-operator-system-oos-pro' ),
				'when_not_to_use' => __( 'Server-wide metrics; use cloudways_server_monitor_summary for the whole server.', 'nvdigital-open-operator-system-oos-pro' ),
				'related_tools'   => array( 'cloudways_server_monitor_summary', 'cloudways_app_traffic_analytics', 'cloudways_get_app' ),
			);
		}

		/** {@inheritdoc} */
		public function get_parameters_schema() {
			return array(
				'type'       => 'object',
				'properties' => array(
					'server_id' => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The server ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
					'app_id'    => array(
						'type'        => 'integer',
						'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
						'description' => __( 'The application ID.', 'nvdigital-open-operator-system-oos-pro' ),
					),
				),
				'required'   => array( 'server_id', 'app_id' ),
			);
		}

		/** {@inheritdoc} */
		public function get_capability_flags() {
			return array_merge( parent::get_capability_flags(), array( 'read-only', 'cacheable' ) );
		}

		/**
		 * {@inheritdoc}
		 *
		 * @param array $arguments Tool arguments.
		 * @param array $context   Contextual data.
		 * @return array|WP_Error
		 */
		public function execute( array $arguments = array(), array $context = array() ) {
			$server_id = $this->sanitize_server_id( $arguments );
			$app_id    = $this->sanitize_app_id( $arguments );

			if ( 0 === $server_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_server_id',
					__( 'A valid server ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			if ( 0 === $app_id ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_missing_app_id',
					__( 'A valid app ID is required.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$path   = '/app/' . $server_id . '/' . $app_id . '/monitor/summary';
			$result = $this->client()->get( $path );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! isset( $result['summary'] ) || ! is_array( $result['summary'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_cloudways_invalid_response',
					__( 'Cloudways returned an unexpected response format.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$summary = $result['summary'];

			$data = array(
				'requests'  => isset( $summary['requests'] ) ? sanitize_text_field( $summary['requests'] ) : '',
				'bandwidth' => isset( $summary['bandwidth'] ) ? sanitize_text_field( $summary['bandwidth'] ) : '',
			);

			return $this->success(
				sprintf(
					/* translators: %d: app ID */
					__( 'Monitoring summary retrieved for app %d.', 'nvdigital-open-operator-system-oos-pro' ),
					$app_id
				),
				array( 'summary' => $data )
			);
		}
	}
}
