<?php
/**
 * WP MCP AI - Main Plugin File
 *
 * This file contains the core plugin functionality and is included by the
 * main plugin entry point (mcp-ai-wpoos-base.php for base version,
 * or mcp-ai-wpoos.php itself for the combined version).
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prevent double-loading of the plugin.
 * This check must come before any constants are defined to ensure we exit early
 * if the plugin has already been loaded through another entry point.
 */
if ( function_exists( 'wp_mcp_ai_core_loaded' ) ) {
	return;
}

/**
 * WP_MCP_AI_FILE must be defined here — it is tied to __FILE__ in this specific file.
 * All other plugin constants are centralised in includes/bootstrap/constants.php.
 */
if ( ! defined( 'WP_MCP_AI_FILE' ) ) {
	define( 'WP_MCP_AI_FILE', __FILE__ );
}

/**
 * Check PHP version compatibility before loading any classes.
 *
 * This plugin requires PHP 7.4 or later. On older PHP versions, class files
 * will fail to parse with syntax errors. We check the version early to provide
 * a clear error message instead of cryptic parse errors.
 */
if ( version_compare( PHP_VERSION, '7.4.0', '<' ) ) {
	/**
	 * Display admin notice for PHP version incompatibility.
	 */
	function wp_mcp_ai_php_version_notice() {
		$message = sprintf(
			'<strong>Open Operator System</strong> requires PHP version %2$s or higher. You are running PHP version %1$s. Please contact your hosting provider to upgrade PHP.',
			PHP_VERSION,
			'7.4.0'
		);
		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			wp_kses_post( $message )
		);
	}

	/**
	 * Prevent plugin activation on incompatible PHP versions.
	 */
	function wp_mcp_ai_deactivate_self() {
		deactivate_plugins( plugin_basename( WP_MCP_AI_FILE ) );
	}

	add_action( 'admin_notices', 'wp_mcp_ai_php_version_notice' );
	add_action( 'admin_init', 'wp_mcp_ai_deactivate_self' );

	return;
}

// Load bootstrap files in dependency order.
require_once __DIR__ . '/includes/bootstrap/constants.php';
require_once __DIR__ . '/includes/bootstrap/autoload.php';
require_once __DIR__ . '/includes/bootstrap/helpers.php';
require_once __DIR__ . '/includes/bootstrap/cron.php';
require_once __DIR__ . '/includes/bootstrap/hooks.php';
require_once __DIR__ . '/includes/bootstrap/loader.php';
require_once __DIR__ . '/includes/bootstrap/activation.php';
require_once __DIR__ . '/includes/class-wp-mcp-ai-plugin.php';

// Register lifecycle hooks (must reference WP_MCP_AI_FILE, defined above).
register_activation_hook( WP_MCP_AI_FILE, 'wp_mcp_ai_activate' );
register_deactivation_hook( WP_MCP_AI_FILE, 'wp_mcp_ai_deactivate' );
register_uninstall_hook( WP_MCP_AI_FILE, 'wp_mcp_ai_uninstall' );

// Boot the plugin on plugins_loaded.
if ( ! has_action( 'plugins_loaded', 'wp_mcp_ai_bootstrap' ) ) {
	add_action( 'plugins_loaded', 'wp_mcp_ai_bootstrap', 20 );
}
