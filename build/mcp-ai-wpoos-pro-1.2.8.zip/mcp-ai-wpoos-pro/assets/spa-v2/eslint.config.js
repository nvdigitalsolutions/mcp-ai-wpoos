/**
 * ESLint flat config — NV oOS Pro SPA v2.
 *
 * Enforces jsx-a11y rules (WCAG 2.1 AA baseline) on all React TSX/JSX sources.
 *
 * @see https://github.com/jsx-eslint/eslint-plugin-jsx-a11y
 */
// @ts-check
import tsParser from '@typescript-eslint/parser';
import jsxA11y from 'eslint-plugin-jsx-a11y';

/** @type {import('eslint').Linter.Config[]} */
export default [
	{
		...jsxA11y.flatConfigs.recommended,
		files: [ 'src/**/*.{ts,tsx,js,jsx}' ],
		ignores: [ 'src/features/knowledge-graph/upstream/**' ],
		languageOptions: {
			parser: tsParser,
			parserOptions: {
				ecmaFeatures: { jsx: true },
			},
		},
		linterOptions: {
			reportUnusedDisableDirectives: 'off',
		},
	},
];
