<?php
/**
 * Tools & Admin Controller for REST API
 *
 * Handles tools, file downloads, and admin-related endpoints including
 * tool listing, tool execution, file downloads, and cron status.
 *
 * Updated to support POST requests for SSE endpoints, enabling secure
 * authentication via headers instead of query parameters.
 *
 * @package WP_MCP_AI
 * @since 1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tools & Admin Controller Class
 *
 * Manages all tools and admin-related REST API endpoints:
 * - /tools (GET - list tools, POST - execute tool)
 * - /files/{file_id}/download (GET - file download)
 * - /cron-status (GET/POST - cron job status for admin dashboard)
 *
 * This controller follows industry standards by implementing self-contained
 * endpoint handlers with proper fallback mechanisms. It can operate independently
 * or delegate to the main REST controller for backward compatibility.
 */
class WP_MCP_AI_REST_Tools_Controller extends WP_MCP_AI_REST_Controller_Base {
	/**
	 * Reference to the main REST controller for shared functionality.
	 *
	 * @var WP_MCP_AI_REST|null
	 */
	private $main_controller;

	/**
	 * Tool registry instance.
	 *
	 * @var WP_MCP_AI_Tool_Registry|null
	 */
	private $registry;

	/**
	 * Constructor.
	 *
	 * @param WP_MCP_AI_REST|null               $main_controller Main REST controller (optional).
	 * @param WP_MCP_AI_REST_Authenticator|null $authenticator   Authentication handler (optional, for DI).
	 * @param WP_MCP_AI_REST_Validator|null     $validator       Request validator (optional, for DI).
	 */
	public function __construct( $main_controller = null, $authenticator = null, $validator = null ) {
		parent::__construct( $authenticator, $validator );
		$this->main_controller = $main_controller;
		$this->registry        = null;
	}

	/**
	 * Get the tool registry instance.
	 *
	 * Uses lazy loading to get the registry from the container.
	 * Validates the returned instance implements the expected interface.
	 *
	 * @return WP_MCP_AI_Tool_Registry|null Tool registry instance or null if unavailable.
	 */
	private function get_registry() {
		if ( null === $this->registry ) {
			if ( function_exists( 'wp_mcp_ai_container' ) ) {
				$container = wp_mcp_ai_container();
				if ( $container && method_exists( $container, 'get' ) ) {
					try {
						$registry = $container->get( 'tool.registry' );
						// Validate the returned instance is the expected type.
						if ( $registry instanceof WP_MCP_AI_Tool_Registry ) {
							$this->registry = $registry;
						}
					} catch ( Exception $e ) {
						// Registry not available, will be handled by callers.
						$this->registry = null;
					}
				}
			}
		}
		return $this->registry;
	}

	/**
	 * Get the cron status service instance.
	 *
	 * Loads the service class if not already available.
	 *
	 * @return WP_MCP_AI_Cron_Status_Service Cron status service instance.
	 */
	private function get_cron_status_service() {
		if ( ! class_exists( 'WP_MCP_AI_Cron_Status_Service' ) ) {
			require_once WP_MCP_AI_PATH . 'includes/services/class-wp-mcp-ai-cron-status-service.php';
		}
		return new WP_MCP_AI_Cron_Status_Service();
	}

	/**
	 * Get lightweight system status for chat client display.
	 *
	 * Provides async health and orchestration health status for the chat UI's
	 * status bar. This is a lightweight version suitable for frequent polling.
	 *
	 * @since 1.9.1
	 * @return array System status data with async and health information.
	 */
	private function get_system_status_for_chat() {
		$status = array(
			'async'  => array(
				'status'       => 'unknown',
				'stuck_jobs'   => 0,
				'long_running' => 0,
			),
			'health' => array(
				'status' => 'unknown',
				'label'  => 'Unknown',
			),
		);

		// Get async health status if monitor is available.
		if ( class_exists( 'WP_MCP_AI_Async_Health_Monitor' ) ) {
			try {
				$async_health    = WP_MCP_AI_Async_Health_Monitor::check_async_health();
				$status['async'] = array(
					'status'       => isset( $async_health['status'] ) ? $async_health['status'] : 'unknown',
					'stuck_jobs'   => isset( $async_health['stuck_jobs'] ) ? $async_health['stuck_jobs'] : 0,
					'long_running' => isset( $async_health['long_running'] ) ? $async_health['long_running'] : 0,
				);
			} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- Intentionally silent: async health monitoring is optional and should not break REST API response.
				// Silently fail - status monitoring should not break the chat.
			}
		}

		// Get orchestration health status if service is available.
		if ( class_exists( 'WP_MCP_AI_Orchestration_Health_Service' ) ) {
			try {
				$health_status    = WP_MCP_AI_Orchestration_Health_Service::get_health_status();
				$status['health'] = array(
					'status' => isset( $health_status['status'] ) ? $health_status['status'] : 'unknown',
					'label'  => isset( $health_status['label'] ) ? $health_status['label'] : 'Unknown',
				);
			} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- Intentionally silent: orchestration health monitoring is optional and should not break REST API response.
				// Silently fail.
			}
		}

		return $status;
	}

	/**
	 * Register tools and admin routes.
	 *
	 * Registers REST API endpoints for tool management and administration:
	 * - GET /tools: List available tools for an assistant or all tools
	 * - POST /tools: Execute a specific tool with provided arguments
	 * - GET /files/{file_id}/download: Download files generated by tools
	 * - GET/POST /cron-status: Get status of background cron jobs (POST for secure header auth)
	 *
	 * Tool execution endpoint supports:
	 * - Direct tool invocation with validation
	 * - Assistant context for scoped tool access
	 * - Capability checking (required_capability per tool)
	 * - Tool output sanitization and budget constraints
	 *
	 * File download endpoint provides:
	 * - Secure file access with permission checks
	 * - Support for both OpenAI file IDs and WordPress attachment IDs
	 * - Custom download filenames and Content-Disposition headers
	 * - Query string nonce support for in-browser file previews
	 *
	 * Cron status endpoint returns:
	 * - Recent job status summaries for authenticated users
	 * - Job counts by status (pending, running, completed, failed)
	 * - Admin-only access to site-wide cron statistics
	 *
	 * @since 1.0.0
	 */
	public function register_routes() {
		// /tools - Tool listing and execution.
		register_rest_route(
			self::REST_NAMESPACE,
			'/tools',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'permission_callback' => array( $this, 'permissions_check' ),
					'callback'            => array( $this, 'handle_tools_list' ),
					'args'                => array(
						'assistant_id' => array(
							'description'       => __( 'ID of the assistant to list tools for. Returns all tools if omitted.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'integer',
							'required'          => false,
							'sanitize_callback' => 'absint',
						),
						'_fields'      => array(
							'description'       => __( 'Comma-separated list of tool fields to include in each item (name, description, inputSchema). Defaults to all fields.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( $this, 'permissions_check' ),
					'callback'            => array( $this, 'handle_tool_request' ),
					'args'                => array(
						'assistant_id' => array(
							'description'       => __( 'ID of the assistant context for tool execution.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'integer',
							'required'          => false,
							'sanitize_callback' => 'absint',
						),
						'tool'         => array(
							'description'       => __( 'Slug of the tool to execute.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_key',
						),
						'arguments'    => array(
							'description' => __( 'Arguments to pass to the tool execution.', 'nvdigital-open-operator-system-oos' ),
							'type'        => 'object',
							'required'    => false,
							'default'     => array(),
						),
					),
				),
			),
			true
		);

		// /files/{file_id}/download - File download with permission checks.
		register_rest_route(
			self::REST_NAMESPACE,
			'/files/(?P<file_id>[^/]+)/download',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'permission_callback' => array( $this, 'download_file_permissions_check' ),
					'callback'            => array( $this, 'handle_file_download' ),
					'args'                => array(
						'assistant_id'  => array(
							'description'       => __( 'ID of the assistant context for file access.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'integer',
							'required'          => false,
							'sanitize_callback' => 'absint',
						),
						'file_id'       => array(
							'description'       => __( 'ID or identifier of the file to download.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'download_name' => array(
							'description'       => __( 'Optional custom filename for the download.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_file_name',
						),
						'disposition'   => array(
							'description'       => __( 'Content-Disposition header value (attachment or inline).', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'string',
							'required'          => false,
							'default'           => 'attachment',
							'enum'              => array( 'attachment', 'inline' ),
							'sanitize_callback' => 'sanitize_key',
						),
					),
				),
			),
			true
		);

		// /cron-status - Lightweight cron job status for admin dashboard and chat widgets.
		// Supports SSE streaming for real-time updates.
		// Now supports both GET and POST methods for enhanced SSE with custom headers.
		register_rest_route(
			self::REST_NAMESPACE,
			'/cron-status',
			array(
				array(
					'methods'             => array( WP_REST_Server::READABLE, WP_REST_Server::CREATABLE ),
					'permission_callback' => array( $this, 'permissions_check_cron_status' ),
					'callback'            => array( $this, 'handle_cron_status_request' ),
					'args'                => array(
						'assistant_id' => array(
							'description'       => __( 'Filter jobs by assistant ID for multi-widget isolation. Can be an integer assistant ID or a string like "unified_team_123" for unified team chats.', 'nvdigital-open-operator-system-oos' ),
							'type'              => array( 'integer', 'string' ),
							'required'          => false,
							'sanitize_callback' => array( 'WP_MCP_AI_REST_Tools_Controller', 'sanitize_assistant_id' ),
						),
						'limit'        => array(
							'description'       => __( 'Maximum number of jobs to return.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'integer',
							'required'          => false,
							'default'           => 10,
							'sanitize_callback' => 'absint',
							'minimum'           => 1,
							'maximum'           => 50,
						),
						'stream'       => array(
							'description' => __( 'Enable Server-Sent Events streaming for real-time updates.', 'nvdigital-open-operator-system-oos' ),
							'type'        => 'boolean',
							'required'    => false,
							'default'     => false,
						),
					),
				),
			),
			true
		);

		// /cron-status/(?P<job_id>[a-zA-Z0-9_.]+) - Get details for a specific cron job.
		// Updated regex to support dots in job IDs (e.g., veo_69203b5b2388f5.11575461 from uniqid).
		// Now supports both GET and POST methods for enhanced SSE with custom headers.
		register_rest_route(
			self::REST_NAMESPACE,
			'/cron-status/(?P<job_id>[a-zA-Z0-9_.]+)',
			array(
				array(
					'methods'             => array( WP_REST_Server::READABLE, WP_REST_Server::CREATABLE ),
					'permission_callback' => array( $this, 'permissions_check_cron_status' ),
					'callback'            => array( $this, 'handle_cron_job_details_request' ),
					'args'                => array(
						'job_id' => array(
							'description'       => __( 'Cron job identifier.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => array( $this, 'sanitize_job_id' ),
						),
						'stream' => array(
							'description' => __( 'Enable Server-Sent Events streaming for real-time updates.', 'nvdigital-open-operator-system-oos' ),
							'type'        => 'boolean',
							'required'    => false,
							'default'     => false,
						),
					),
				),
			),
			true
		);

		// /attachments/prepare - Pre-register a WordPress attachment with the AI provider.
		// This enables the multi-step attachment pipeline in the chat client:
		// step 1 uploads to WordPress, step 2 pre-registers with the AI Files API.
		register_rest_route(
			self::REST_NAMESPACE,
			'/attachments/prepare',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( $this, 'permissions_check' ),
					'callback'            => array( $this, 'handle_attachment_prepare' ),
					'args'                => array(
						'attachment_id' => array(
							'description'       => __( 'WordPress attachment ID to prepare for the AI provider.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
						'assistant_id'  => array(
							'description'       => __( 'Assistant ID used to detect the AI provider and model.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'integer',
							'required'          => false,
							'default'           => 0,
							'sanitize_callback' => 'absint',
						),
						'usage'         => array(
							'description'       => __( 'Usage context: "image" for image attachments, "file" for all other files.', 'nvdigital-open-operator-system-oos' ),
							'type'              => 'string',
							'required'          => false,
							'default'           => 'file',
							'enum'              => array( 'image', 'file' ),
							'sanitize_callback' => 'sanitize_key',
						),
					),
				),
			),
			true
		);
	}

	/**
	 * General permission check for authenticated endpoints.
	 *
	 * Supports multiple authentication methods:
	 * - WordPress nonce (for same-origin requests)
	 * - Bearer token (for API access)
	 * - Guest token (for public chat surfaces)
	 *
	 * Falls back to base class authentication if main controller is unavailable.
	 *
	 * @param WP_REST_Request $request REST request instance.
	 * @return bool|WP_Error True if authorized, WP_Error otherwise.
	 */
	public function permissions_check( WP_REST_Request $request ) {
		// Try main controller first for full functionality.
		if ( null !== $this->main_controller && method_exists( $this->main_controller, 'permissions_check' ) ) {
			return $this->main_controller->permissions_check( $request );
		}

		// Fallback: Use base class authentication.
		return $this->permissions_check_authenticated( $request );
	}

	/**
	 * Permission check for file download endpoint.
	 *
	 * Handles nonce parameter extraction before delegating to main permission check.
	 * Supports query string nonce for in-browser file previews.
	 *
	 * @param WP_REST_Request $request REST request instance.
	 * @return bool|WP_Error True if authorized, WP_Error otherwise.
	 */
	public function download_file_permissions_check( WP_REST_Request $request ) {
		// Try main controller first for full functionality.
		if ( null !== $this->main_controller && method_exists( $this->main_controller, 'download_file_permissions_check' ) ) {
			return $this->main_controller->download_file_permissions_check( $request );
		}

		// Fallback: Use base class authentication.
		return $this->permissions_check_authenticated( $request );
	}

	/**
	 * Permission check for cron status endpoint.
	 *
	 * Supports mesh keys, bearer tokens, guest tokens, and WordPress nonces.
	 *
	 * @param WP_REST_Request $request REST request instance.
	 * @return bool|WP_Error True if authorized, WP_Error otherwise.
	 */
	public function permissions_check_cron_status( WP_REST_Request $request ) {
		// Try main controller first for full functionality.
		if ( null !== $this->main_controller && method_exists( $this->main_controller, 'permissions_check_cron_status' ) ) {
			return $this->main_controller->permissions_check_cron_status( $request );
		}

		// Fallback: Use base class authentication.
		return $this->permissions_check_authenticated( $request );
	}

	/**
	 * Handle GET /tools request - List available tools.
	 *
	 * Returns a list of available tools, optionally filtered by assistant.
	 * If no assistant_id is provided, returns all registered tools.
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function handle_tools_list( WP_REST_Request $request ) {
		// Delegate to main controller if available.
		if ( null !== $this->main_controller && method_exists( $this->main_controller, 'handle_tools_list' ) ) {
			return $this->main_controller->handle_tools_list( $request );
		}

		// Self-contained fallback implementation.
		$registry = $this->get_registry();
		if ( null === $registry ) {
			return $this->error(
				'wp_mcp_ai_registry_unavailable',
				__( 'Tool registry is not available. Please ensure the plugin is properly configured.', 'nvdigital-open-operator-system-oos' ),
				503
			);
		}

		$assistant_id = absint( $request->get_param( 'assistant_id' ) );

		if ( ! $assistant_id ) {
			// Return all registered tools.
			$tools = $registry->get_tools();
		} else {
			// Get tools allowed for this assistant.
			if ( ! class_exists( 'WP_MCP_AI_Assistant_CPT' ) ) {
				return $this->error(
					'wp_mcp_ai_assistant_cpt_unavailable',
					__( 'Assistant configuration is not available.', 'nvdigital-open-operator-system-oos' ),
					503
				);
			}

			$assistant_config = WP_MCP_AI_Assistant_CPT::get_assistant_configuration( $assistant_id );
			$allowed_tools    = isset( $assistant_config['tools'] ) ? $assistant_config['tools'] : array();

			$tools = array();
			foreach ( $allowed_tools as $tool_slug ) {
				$tool = $registry->get_tool( $tool_slug );
				if ( $tool ) {
					$tools[] = $tool;
				}
			}
		}

		// Convert tools to response format.
		$tools_list = array();
		foreach ( $tools as $tool ) {
			try {
				$schema = $tool->get_parameters_schema();

				// Validate schema is a valid array.
				if ( ! is_array( $schema ) ) {
					continue;
				}

				$tools_list[] = array(
					'name'        => $tool->get_slug(),
					'description' => $tool->get_description(),
					'inputSchema' => $schema,
				);
			} catch ( Exception $e ) {
				// Skip tools with invalid schemas.
				continue;
			} catch ( Error $e ) {
				// Skip tools with PHP errors.
				continue;
			}
		}

		return $this->success( array( 'tools' => $tools_list ) );
	}

	/**
	 * Handle POST /tools request - Execute a tool.
	 *
	 * Executes a specific tool with the provided arguments.
	 * Validates assistant access and tool permissions before execution.
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function handle_tool_request( WP_REST_Request $request ) {
		// Delegate to main controller if available (preferred for full functionality).
		if ( null !== $this->main_controller && method_exists( $this->main_controller, 'handle_tool_request' ) ) {
			return $this->main_controller->handle_tool_request( $request );
		}

		// Self-contained fallback implementation.
		$registry = $this->get_registry();
		if ( null === $registry ) {
			return $this->error(
				'wp_mcp_ai_registry_unavailable',
				__( 'Tool registry is not available. Please ensure the plugin is properly configured.', 'nvdigital-open-operator-system-oos' ),
				503
			);
		}

		$assistant_id = absint( $request->get_param( 'assistant_id' ) );
		$tool_slug    = sanitize_key( $request->get_param( 'tool' ) );
		$arguments    = $request->get_param( 'arguments' );

		if ( ! $assistant_id ) {
			return $this->error(
				'wp_mcp_ai_missing_assistant',
				__( 'No assistant was provided and no default assistant is configured.', 'nvdigital-open-operator-system-oos' ),
				400
			);
		}

		if ( empty( $tool_slug ) ) {
			return $this->error(
				'wp_mcp_ai_missing_tool',
				__( 'Tool slug is required.', 'nvdigital-open-operator-system-oos' ),
				400
			);
		}

		// Get assistant configuration.
		if ( ! class_exists( 'WP_MCP_AI_Assistant_CPT' ) ) {
			return $this->error(
				'wp_mcp_ai_assistant_cpt_unavailable',
				__( 'Assistant configuration is not available.', 'nvdigital-open-operator-system-oos' ),
				503
			);
		}

		$assistant_config = WP_MCP_AI_Assistant_CPT::get_assistant_configuration( $assistant_id );
		$allowed_tools    = isset( $assistant_config['tools'] ) ? $assistant_config['tools'] : array();

		// Auto-enable utility tools that provide essential chat client functionality.
		// These tools (speech synthesis, audio transcription) are always available.
		// to ensure chat client features work without requiring explicit configuration.
		if ( class_exists( 'WP_MCP_AI_REST' ) && defined( 'WP_MCP_AI_REST::AUTO_ENABLED_UTILITY_TOOLS' ) ) {
			$utility_tools = WP_MCP_AI_REST::AUTO_ENABLED_UTILITY_TOOLS;
		} else {
			// Fallback if main REST class is not loaded.
			$utility_tools = array( 'generate_openai_speech', 'transcribe_openai_audio' );
		}

		if ( in_array( $tool_slug, $utility_tools, true ) && ! in_array( $tool_slug, $allowed_tools, true ) ) {
			$allowed_tools[] = $tool_slug;
		}

		// Check if tool is allowed for this assistant.
		if ( ! in_array( $tool_slug, $allowed_tools, true ) ) {
			return $this->error(
				'wp_mcp_ai_tool_forbidden',
				__( 'This assistant is not allowed to execute the requested tool.', 'nvdigital-open-operator-system-oos' ),
				403
			);
		}

		// Get the tool instance.
		$tool = $registry->get_tool( $tool_slug );
		if ( ! $tool ) {
			return $this->error(
				'wp_mcp_ai_tool_missing',
				__( 'The requested tool is not registered.', 'nvdigital-open-operator-system-oos' ),
				404
			);
		}

		// Build execution context.
		$user_id = $this->get_current_user_id();
		$context = array(
			'user_id'          => $user_id,
			'assistant_id'     => $assistant_id,
			'request'          => $request,
			'assistant_config' => $assistant_config,
		);

		// Validate user is authenticated.
		if ( empty( $user_id ) && ! $this->is_guest_request() ) {
			return $this->error(
				'wp_mcp_ai_anonymous_user',
				__( 'You must be logged in to execute tools.', 'nvdigital-open-operator-system-oos' ),
				rest_authorization_required_code()
			);
		}

		// Execute the tool.
		$prepared_arguments = is_array( $arguments ) ? $arguments : array();

		try {
			/**
			 * Fires immediately before executing a registered tool.
			 *
			 * @param string $tool_slug          Tool identifier.
			 * @param array  $prepared_arguments Arguments passed in the request.
			 * @param array  $context            Execution context.
			 */
			do_action( 'wp_mcp_ai_before_tool_execution', $tool_slug, $prepared_arguments, $context );

			$result = $tool->execute( $prepared_arguments, $context );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			/**
			 * Filter the tool output before returning.
			 *
			 * @param mixed  $result             Tool execution result.
			 * @param string $tool_slug          Tool identifier.
			 * @param array  $prepared_arguments Arguments passed in the request.
			 * @param array  $context            Execution context.
			 */
			$result = apply_filters( 'wp_mcp_ai_tool_output', $result, $tool_slug, $prepared_arguments, $context );

			/**
			 * Fires immediately after executing a registered tool.
			 *
			 * @param string $tool_slug          Tool identifier.
			 * @param array  $prepared_arguments Arguments passed in the request.
			 * @param array  $context            Execution context.
			 * @param mixed  $result             Tool execution result.
			 */
			do_action( 'wp_mcp_ai_after_tool_execution', $tool_slug, $prepared_arguments, $context, $result );

			return $this->success( array( 'result' => $result ) );
		} catch ( Exception $e ) {
			return $this->error(
				'wp_mcp_ai_tool_execution_error',
				$e->getMessage(),
				500
			);
		}
	}

	/**
	 * Handle GET /files/{file_id}/download request.
	 *
	 * Downloads a file from OpenAI and streams it to the client.
	 * Supports both OpenAI file IDs and WordPress attachment IDs.
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function handle_file_download( WP_REST_Request $request ) {
		// Delegate to main controller if available (preferred for full functionality).
		if ( null !== $this->main_controller && method_exists( $this->main_controller, 'handle_file_download' ) ) {
			return $this->main_controller->handle_file_download( $request );
		}

		// Self-contained fallback - basic file download implementation.
		$file_id       = sanitize_text_field( $request->get_param( 'file_id' ) );
		$download_name = $request->get_param( 'download_name' );
		$disposition   = $request->get_param( 'disposition' ) ? $request->get_param( 'disposition' ) : 'attachment';

		if ( empty( $file_id ) ) {
			return $this->error(
				'wp_mcp_ai_missing_file_id',
				__( 'File ID is required.', 'nvdigital-open-operator-system-oos' ),
				400
			);
		}

		// Check if file_id is a WordPress attachment ID.
		$attachment_id = absint( $file_id );
		if ( $attachment_id > 0 ) {
			$file_path = get_attached_file( $attachment_id );
			if ( $file_path && file_exists( $file_path ) ) {
				$file_url = wp_get_attachment_url( $attachment_id );
				return $this->success(
					array(
						'url'       => $file_url,
						'file_path' => $file_path,
						'file_name' => wp_basename( $file_path ),
					)
				);
			}
		}

		return $this->error(
			'wp_mcp_ai_file_not_found',
			__( 'The requested file was not found.', 'nvdigital-open-operator-system-oos' ),
			404
		);
	}

	/**
	 * Handle GET/POST /cron-status request.
	 *
	 * Returns lightweight cron job status information for the admin dashboard.
	 * Includes job status summaries and counts by status.
	 *
	 * Supports both GET (legacy, auth via query params) and POST (enhanced, auth via headers).
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function handle_cron_status_request( WP_REST_Request $request ) {
		// Delegate to main controller if available.
		if ( null !== $this->main_controller && method_exists( $this->main_controller, 'handle_cron_status_request' ) ) {
			return $this->main_controller->handle_cron_status_request( $request );
		}

		// Self-contained fallback implementation.
		$service = $this->get_cron_status_service();
		$user_id = $this->get_current_user_id();

		$limit        = absint( $request->get_param( 'limit' ) ) ? absint( $request->get_param( 'limit' ) ) : 10;
		$assistant_id = $request->get_param( 'assistant_id' );

		// Sanitize assistant_id: keep as string if it's a unified team ID, otherwise convert to int.
		if ( $assistant_id ) {
			$assistant_id = self::sanitize_assistant_id( $assistant_id );
		}

		$jobs   = $service->get_status_summary( $user_id, $limit, $assistant_id ? $assistant_id : null );
		$counts = $service->get_status_counts( $user_id, $assistant_id ? $assistant_id : null );

		$response = array(
			'jobs'          => $jobs,
			'counts'        => $counts,
			'system_status' => $this->get_system_status_for_chat(),
		);

		if ( $assistant_id ) {
			$response['assistant_id'] = $assistant_id;
		}

		return $this->success( $response );
	}

	/**
	 * Handle GET/POST /cron-status/{job_id} request.
	 *
	 * Returns detailed information about a specific cron job.
	 * Follows SOC by delegating to cron status service.
	 *
	 * Supports both GET (legacy, auth via query params) and POST (enhanced, auth via headers).
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error Response object.
	 */
	public function handle_cron_job_details_request( WP_REST_Request $request ) {
		// Delegate to main controller if available (preferred for full SSE support).
		if ( null !== $this->main_controller && method_exists( $this->main_controller, 'handle_cron_job_details_request' ) ) {
			return $this->main_controller->handle_cron_job_details_request( $request );
		}

		// Self-contained fallback implementation.
		$service = $this->get_cron_status_service();
		$user_id = $this->get_current_user_id();
		$job_id  = $this->sanitize_job_id( $request->get_param( 'job_id' ) );

		$job_details = $service->get_job_details( $job_id, $user_id );

		if ( is_wp_error( $job_details ) ) {
			return $job_details;
		}

		return $this->success( $job_details );
	}

	/**
	 * Sanitize job ID parameter.
	 *
	 * Job IDs are generated using uniqid() with more_entropy=true, which produces
	 * IDs like 'veo_69203b5b2388f5_11575461'. This sanitization function preserves
	 * dots and underscores while blocking path traversal and other malicious input.
	 *
	 * Note: Dots in job IDs have been replaced with underscores to avoid filename
	 * confusion (e.g., veo-video-id_suffix.mp4 instead of veo-video-id.suffix.mp4).
	 *
	 * @param string $job_id Job ID to sanitize.
	 * @return string Sanitized job ID.
	 */
	public function sanitize_job_id( $job_id ) {
		// Remove any characters that aren't alphanumeric, underscore, dot, or hyphen.
		$sanitized = preg_replace( '/[^a-zA-Z0-9_.\-]/', '', $job_id );

		// Remove path traversal attempts (2 or more consecutive dots).
		// This runs after removing slashes because '../../../' becomes '......' after slash removal.
		$sanitized = preg_replace( '/\.{2,}/', '', $sanitized );

		return $sanitized;
	}

	/**
	 * Sanitize assistant ID parameter.
	 *
	 * Assistant IDs can be either:
	 * - Integer post IDs (e.g., 8901)
	 * - Unified team IDs (e.g., "unified_team_8901")
	 * - Profession test IDs (e.g., "profession_123")
	 *
	 * This sanitization preserves string identifiers while converting numeric strings to integers.
	 *
	 * @param mixed $assistant_id Assistant ID to sanitize.
	 * @return int|string|null Sanitized assistant ID (int for numeric, string for prefixed IDs).
	 */
	public static function sanitize_assistant_id( $assistant_id ) {
		if ( empty( $assistant_id ) ) {
			return null;
		}

		// If it's already an integer, return it.
		if ( is_int( $assistant_id ) ) {
			return $assistant_id;
		}

		// If it's a string, check if it's a special identifier.
		if ( is_string( $assistant_id ) ) {
			$sanitized = sanitize_text_field( $assistant_id );

			// Check for unified team or profession prefix.
			if ( 0 === strpos( $sanitized, 'unified_team_' ) || 0 === strpos( $sanitized, 'profession_' ) ) {
				return $sanitized;
			}

			// If it's a numeric string, convert to integer.
			if ( is_numeric( $sanitized ) ) {
				return absint( $sanitized );
			}

			// Otherwise return the sanitized string (defensive fallback).
			return $sanitized;
		}

		// Fallback for unexpected types - try to convert to int.
		return absint( $assistant_id );
	}

	/**
	 * Handle POST /attachments/prepare request.
	 *
	 * Pre-registers a WordPress attachment with the AI provider's Files API so it is
	 * ready before the user sends their chat message. This is step 2 of the multi-step
	 * attachment pipeline: step 1 uploads the file to WordPress, step 2 calls this
	 * endpoint to process the file and register it with the provider, and step 3 sends
	 * the message with the pre-registered file_id so no extra upload is needed at
	 * chat-send time.
	 *
	 * @param WP_REST_Request $request REST request object.
	 * @return WP_REST_Response|WP_Error Response with prepared attachment data or error.
	 */
	public function handle_attachment_prepare( WP_REST_Request $request ) {
		$attachment_id = absint( $request->get_param( 'attachment_id' ) );
		$assistant_id  = absint( $request->get_param( 'assistant_id' ) );
		$usage         = $request->get_param( 'usage' ) ? $request->get_param( 'usage' ) : 'file';

		if ( $attachment_id <= 0 ) {
			return new WP_Error(
				'wp_mcp_ai_invalid_attachment_id',
				__( 'A valid attachment ID is required.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 400 )
			);
		}

		// Determine provider and model from the assistant configuration.
		$provider = 'openai';
		$model    = '';

		if ( $assistant_id > 0 ) {
			if ( ! class_exists( 'WP_MCP_AI_Assistant_CPT' ) ) {
				require_once WP_MCP_AI_PATH . 'includes/assistants/class-wp-mcp-ai-assistant-cpt.php';
			}

			$config   = WP_MCP_AI_Assistant_CPT::get_assistant_configuration( $assistant_id );
			$provider = isset( $config['provider'] ) ? sanitize_key( $config['provider'] ) : 'openai';
			$model    = isset( $config['model'] ) ? sanitize_text_field( $config['model'] ) : '';
		}

		if ( ! class_exists( 'WP_MCP_AI_Message_Attachments' ) ) {
			require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-message-attachments.php';
		}

		$helper = new WP_MCP_AI_Message_Attachments( $provider, $model );
		$result = $helper->prepare_attachment( $attachment_id, $usage );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response( $result );
	}
}
