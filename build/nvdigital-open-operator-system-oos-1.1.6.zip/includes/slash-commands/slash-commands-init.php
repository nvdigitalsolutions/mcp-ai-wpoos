<?php
/**
 * Slash Commands Initialization
 *
 * Loads slash command infrastructure and registers default commands.
 *
 * @package WP_MCP_AI
 * @subpackage Slash_Commands
 * @since 1.2.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Initialize slash commands system
 *
 * @since 1.2.0
 */
function wp_mcp_ai_init_slash_commands() {
	// Load audit logger.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/class-wp-mcp-ai-slash-command-audit.php';

	// Load parser.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/class-wp-mcp-ai-slash-command-parser.php';

	// Load handler.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/class-wp-mcp-ai-slash-command-handler.php';

	// Initialize global handler instance.
	global $wp_mcp_ai_slash_command_handler;
	$wp_mcp_ai_slash_command_handler = new WP_MCP_AI_Slash_Command_Handler();

	// Load default commands.
	wp_mcp_ai_load_default_slash_commands();

	// Load toolkit-specific commands.
	wp_mcp_ai_load_toolkit_slash_commands();

	// Register JavaScript files.
	wp_mcp_ai_register_slash_command_scripts();

	/**
	 * Fires after slash commands are initialized
	 *
	 * @since 1.2.0
	 *
	 * @param WP_MCP_AI_Slash_Command_Handler $handler Command handler instance.
	 */
	do_action( 'wp_mcp_ai_slash_commands_initialized', $wp_mcp_ai_slash_command_handler );
}
add_action( 'init', 'wp_mcp_ai_init_slash_commands', 20 );

/**
 * Load default slash commands
 *
 * @since 1.2.0
 */
function wp_mcp_ai_load_default_slash_commands() {
	global $wp_mcp_ai_slash_command_handler;

	if ( ! $wp_mcp_ai_slash_command_handler ) {
		return;
	}

	// Load help command.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/commands/class-wp-mcp-ai-slash-command-help.php';

	// Register /help command.
	$help_command = new WP_MCP_AI_Slash_Command_Help( $wp_mcp_ai_slash_command_handler );
	$wp_mcp_ai_slash_command_handler->register(
		'help',
		array(
			'handler'     => array( $help_command, 'execute' ),
			'description' => __( 'Display help information about available commands', 'nvdigital-open-operator-system-oos' ),
			'usage'       => '/help [command] [--detailed|-d]',
			'capability'  => 'read',
			'aliases'     => array( 'h', '?' ),
			'parameters'  => array(
				'command'    => array(
					'description' => __( 'Specific command to get help for', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--detailed' => array(
					'description' => __( 'Show detailed information for all commands', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
			),
		)
	);

	// Load next-task command.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/commands/class-wp-mcp-ai-slash-command-next-task.php';

	// Register /next-task command.
	$next_task_command = new WP_MCP_AI_Slash_Command_Next_Task();
	$wp_mcp_ai_slash_command_handler->register(
		'next-task',
		array(
			'handler'     => array( $next_task_command, 'execute' ),
			'description' => __( 'Autonomous task discovery and execution for WordPress content', 'nvdigital-open-operator-system-oos' ),
			'usage'       => '/next-task [--filter=<type>] [--type=<task-type>] [--limit=<number>] [--dry-run|-n] [--auto|-a]',
			'capability'  => 'edit_posts',
			'aliases'     => array( 'next' ),
			'parameters'  => array(
				'--filter'  => array(
					'description' => __( 'Filter tasks by type (all, drafts, seo, updates)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--type'    => array(
					'description' => __( 'Specific task type to focus on', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--limit'   => array(
					'description' => __( 'Maximum number of tasks to process (default: 5)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--dry-run' => array(
					'description' => __( 'Show what would be done without making changes', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--auto'    => array(
					'description' => __( 'Execute without waiting for approval', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
			),
		)
	);

	// Load ship command.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/commands/class-wp-mcp-ai-slash-command-ship.php';

	// Register /ship command.
	$ship_command = new WP_MCP_AI_Slash_Command_Ship();
	$wp_mcp_ai_slash_command_handler->register(
		'ship',
		array(
			'handler'     => array( $ship_command, 'execute' ),
			'description' => __( 'Automated content review, optimization, and publishing workflow', 'nvdigital-open-operator-system-oos' ),
			'usage'       => '/ship [post_id...] [--dry-run|-n] [--publish|-p] [--schedule=<date>] [--skip-checks|-s] [--skip-seo] [--skip-images] [--skip-links]',
			'capability'  => 'publish_posts',
			'parameters'  => array(
				'post_id'       => array(
					'description' => __( 'Post ID(s) to ship. If omitted, finds draft posts ready to ship.', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--dry-run'     => array(
					'description' => __( 'Preview checks without publishing', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--publish'     => array(
					'description' => __( 'Automatically publish posts that pass checks (70%+ score)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--schedule'    => array(
					'description' => __( 'Schedule publication for a future date (YYYY-MM-DD HH:MM)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--skip-checks' => array(
					'description' => __( 'Skip all pre-flight, SEO, and quality checks', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--skip-seo'    => array(
					'description' => __( 'Skip SEO verification checks', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--skip-images' => array(
					'description' => __( 'Skip image optimization checks', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--skip-links'  => array(
					'description' => __( 'Skip internal linking suggestions', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
			),
		)
	);

	// Load clean-content command.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/commands/class-wp-mcp-ai-slash-command-clean-content.php';

	// Register /clean-content command.
	$clean_content_command = new WP_MCP_AI_Slash_Command_Clean_Content();
	$wp_mcp_ai_slash_command_handler->register(
		'clean-content',
		array(
			'handler'     => array( $clean_content_command, 'execute' ),
			'description' => __( 'Content quality assurance with 3-phase detection (HIGH/MEDIUM/LOW certainty)', 'nvdigital-open-operator-system-oos' ),
			'usage'       => '/clean-content [post_id|recent|all] [--phase=<1-3>] [--limit=<number>] [--dry-run|-n] [--auto-fix|-a] [--post-type=<type>] [--verbose|-v]',
			'capability'  => 'edit_posts',
			'aliases'     => array( 'clean' ),
			'parameters'  => array(
				'target'      => array(
					'description' => __( 'Post ID, "recent" (default), or "all"', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--phase'     => array(
					'description' => __( 'Run specific phase only: 1 (regex), 2 (analysis), 3 (AI review)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--limit'     => array(
					'description' => __( 'Maximum number of posts to check (default: 10)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--dry-run'   => array(
					'description' => __( 'Show issues without making changes', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--auto-fix'  => array(
					'description' => __( 'Automatically fix HIGH certainty issues', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--post-type' => array(
					'description' => __( 'Post type to check (default: post)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--verbose'   => array(
					'description' => __( 'Show detailed output', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
			),
		)
	);

	// Load optimize-perf command.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/commands/class-wp-mcp-ai-slash-command-optimize-perf.php';

	// Register /optimize-perf command.
	$optimize_perf_command = new WP_MCP_AI_Slash_Command_Optimize_Perf();
	$wp_mcp_ai_slash_command_handler->register(
		'optimize-perf',
		array(
			'handler'     => array( $optimize_perf_command, 'execute' ),
			'description' => __( 'Automated performance analysis and optimization for WordPress sites', 'nvdigital-open-operator-system-oos' ),
			'usage'       => '/optimize-perf [--phases=<1-10>] [--url=<url>] [--dry-run|-n] [--auto-apply|-a] [--detailed|-v]',
			'capability'  => 'manage_options',
			'aliases'     => array( 'perf' ),
			'parameters'  => array(
				'--phases'     => array(
					'description' => __( 'Comma-separated phase numbers to run (1-10, default: all)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--url'        => array(
					'description' => __( 'URL to analyze (default: home page)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--dry-run'    => array(
					'description' => __( 'Analyze without applying optimizations', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--auto-apply' => array(
					'description' => __( 'Automatically apply safe optimizations', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--detailed'   => array(
					'description' => __( 'Show detailed analysis output', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
			),
		)
	);

	// Load sync-docs command.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/commands/class-wp-mcp-ai-slash-command-sync-docs.php';

	// Register /sync-docs command.
	$sync_docs_command = new WP_MCP_AI_Slash_Command_Sync_Docs();
	$wp_mcp_ai_slash_command_handler->register(
		'sync-docs',
		array(
			'handler'     => array( $sync_docs_command, 'execute' ),
			'description' => __( 'Documentation drift detection and synchronization', 'nvdigital-open-operator-system-oos' ),
			'usage'       => '/sync-docs [--type=<all|posts|pages|readme>] [--dry-run|-n] [--auto-fix|-a] [--skip-links] [--skip-code]',
			'capability'  => 'edit_posts',
			'aliases'     => array( 'docs' ),
			'parameters'  => array(
				'--type'       => array(
					'description' => __( 'Type of documentation to sync (all, posts, pages, readme)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--dry-run'    => array(
					'description' => __( 'Check without making changes', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--auto-fix'   => array(
					'description' => __( 'Automatically fix detected issues', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--skip-links' => array(
					'description' => __( 'Skip broken link checking', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--skip-code'  => array(
					'description' => __( 'Skip code example validation', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
			),
		)
	);

	// Load workflow command.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/commands/class-wp-mcp-ai-slash-command-workflow.php';

	// Register /workflow command.
	$workflow_command = new WP_MCP_AI_Slash_Command_Workflow();
	$wp_mcp_ai_slash_command_handler->register(
		'workflow',
		array(
			'handler'     => array( $workflow_command, 'execute' ),
			'description' => __( 'Execute and manage custom automation workflows', 'nvdigital-open-operator-system-oos' ),
			'usage'       => '/workflow <name> [--action=<run|list|show>] [--dry-run|-n] [--list|-l] [--show|-s]',
			'capability'  => 'edit_posts',
			'parameters'  => array(
				'name'      => array(
					'description' => __( 'Workflow name to execute', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--action'  => array(
					'description' => __( 'Action to perform: run, list, show (default: run)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--dry-run' => array(
					'description' => __( 'Preview workflow without executing steps', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--list'    => array(
					'description' => __( 'List available workflows', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--show'    => array(
					'description' => __( 'Show workflow definition', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
			),
		)
	);

	// Load compact command.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/commands/class-wp-mcp-ai-slash-command-compact.php';

	// Register /compact command.
	$compact_command = new WP_MCP_AI_Slash_Command_Compact();
	$wp_mcp_ai_slash_command_handler->register(
		'compact',
		array(
			'handler'     => array( $compact_command, 'execute' ),
			'description' => __( 'Proactive context compaction — summarize conversation history to free token budget', 'nvdigital-open-operator-system-oos' ),
			'usage'       => '/compact [--strategy=<summarize|trim-tools|keep-recent|full>] [--keep=<number>]',
			'capability'  => 'read',
			'parameters'  => array(
				'--strategy' => array(
					'description' => __( 'Compaction strategy: summarize (default), trim-tools, keep-recent, full', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
				'--keep'     => array(
					'description' => __( 'Number of recent messages to preserve (default: 6)', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
			),
		)
	);

	// Load context command.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/commands/class-wp-mcp-ai-slash-command-context.php';

	// Register /context command.
	$context_command = new WP_MCP_AI_Slash_Command_Context();
	$wp_mcp_ai_slash_command_handler->register(
		'context',
		array(
			'handler'     => array( $context_command, 'execute' ),
			'description' => __( 'Show context budget status — token usage, message count, and capacity remaining', 'nvdigital-open-operator-system-oos' ),
			'usage'       => '/context [--verbose|-v]',
			'capability'  => 'read',
			'aliases'     => array( 'ctx' ),
			'parameters'  => array(
				'--verbose' => array(
					'description' => __( 'Show detailed token breakdown', 'nvdigital-open-operator-system-oos' ),
					'required'    => false,
				),
			),
		)
	);

	/**
	 * Fires after default slash commands are loaded
	 *
	 * Allows plugins to register additional commands.
	 *
	 * @since 1.2.0
	 *
	 * @param WP_MCP_AI_Slash_Command_Handler $handler Command handler instance.
	 */
	do_action( 'wp_mcp_ai_default_slash_commands_loaded', $wp_mcp_ai_slash_command_handler );
}

/**
 * Load toolkit-specific slash commands
 *
 * Initializes toolkit command manager and registers toolkit commands.
 *
 * @since 1.3.0
 */
function wp_mcp_ai_load_toolkit_slash_commands() {
	global $wp_mcp_ai_slash_command_handler;

	if ( ! $wp_mcp_ai_slash_command_handler ) {
		return;
	}

	// Ensure toolkit registry is loaded.
	if ( ! class_exists( 'WP_MCP_AI_Toolkit_Registry' ) ) {
		require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-toolkit-registry.php';
	}

	// Load toolkit manager.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/class-wp-mcp-ai-slash-command-toolkit-manager.php';

	// Load validator (industry best practices).
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/class-wp-mcp-ai-slash-command-validator.php';

	// Load workflow orchestrator.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/class-wp-mcp-ai-slash-command-workflow-orchestrator.php';

	// Load cache adapter (Redis/Memcached support).
	if ( file_exists( WP_MCP_AI_PATH . 'includes/cache/class-wp-mcp-ai-cache-adapter.php' ) ) {
		require_once WP_MCP_AI_PATH . 'includes/cache/class-wp-mcp-ai-cache-adapter.php';
	}

	// Load performance optimizer.
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/class-wp-mcp-ai-slash-command-performance-optimizer.php';

	// Initialize toolkit manager (singleton pattern).
	WP_MCP_AI_Slash_Command_Toolkit_Manager::get_instance();

	/**
	 * Fires after toolkit slash commands are loaded
	 *
	 * Allows plugins to register additional toolkit commands.
	 *
	 * @since 1.3.0
	 *
	 * @param WP_MCP_AI_Slash_Command_Handler $handler Command handler instance.
	 */
	do_action( 'wp_mcp_ai_toolkit_slash_commands_loaded', $wp_mcp_ai_slash_command_handler );
}

/**
 * Get global slash command handler instance
 *
 * @since 1.2.0
 *
 * @return WP_MCP_AI_Slash_Command_Handler|null Handler instance or null if not initialized.
 */
function wp_mcp_ai_get_slash_command_handler() {
	global $wp_mcp_ai_slash_command_handler;
	return $wp_mcp_ai_slash_command_handler;
}

/**
 * Execute a slash command
 *
 * Helper function to execute slash commands from anywhere in the plugin.
 *
 * @since 1.2.0
 *
 * @param string $input   Command input (e.g., "/help").
 * @param array  $context Execution context.
 * @return mixed Command result or WP_Error.
 */
function wp_mcp_ai_execute_slash_command( $input, $context = array() ) {
	$handler = wp_mcp_ai_get_slash_command_handler();

	if ( ! $handler ) {
		return new WP_Error(
			'slash_commands_not_initialized',
			__( 'Slash commands system not initialized.', 'nvdigital-open-operator-system-oos' )
		);
	}

	return $handler->execute( $input, $context );
}

/**
 * Register a custom slash command
 *
 * Helper function for other plugins/themes to register commands.
 *
 * @since 1.2.0
 *
 * @param string $command Command name (without leading slash).
 * @param array  $config  Command configuration.
 * @return bool True on success, false on failure.
 */
function wp_mcp_ai_register_slash_command( $command, $config ) {
	$handler = wp_mcp_ai_get_slash_command_handler();

	if ( ! $handler ) {
		return false;
	}

	return $handler->register( $command, $config );
}

/**
 * Check if a slash command exists
 *
 * @since 1.2.0
 *
 * @param string $command Command name.
 * @return bool True if command exists.
 */
function wp_mcp_ai_slash_command_exists( $command ) {
	$handler = wp_mcp_ai_get_slash_command_handler();

	if ( ! $handler ) {
		return false;
	}

	return $handler->command_exists( $command );
}

/**
 * Get all registered slash commands
 *
 * @since 1.2.0
 *
 * @param bool $filter_by_capability Filter by current user capability.
 * @return array Registered commands.
 */
function wp_mcp_ai_get_slash_commands( $filter_by_capability = false ) {
	$handler = wp_mcp_ai_get_slash_command_handler();

	if ( ! $handler ) {
		return array();
	}

	return $handler->get_commands( $filter_by_capability );
}

/**
 * Register slash command JavaScript files
 *
 * @since 1.2.0
 */
function wp_mcp_ai_register_slash_command_scripts() {
	// Register autocomplete script.
	wp_register_script(
		'mcp-ai-command-autocomplete',
		WP_MCP_AI_URL . 'assets/js/command-autocomplete.js',
		array(),
		WP_MCP_AI_VERSION,
		true
	);

	// Register slash commands integration script.
	wp_register_script(
		'mcp-ai-slash-commands',
		WP_MCP_AI_URL . 'assets/js/slash-commands.js',
		array( 'mcp-ai-command-autocomplete' ),
		WP_MCP_AI_VERSION,
		true
	);

	// Localize script with REST API data.
	// Build endpoint URLs by providing complete, pre-built URLs to JavaScript.
	// This prevents any client-side URL construction issues and ensures consistency.

	// Strategy: Build each endpoint as a complete absolute URL.
	// We DON'T pass the namespace to rest_url() to avoid filter-based duplication.
	// Instead, we get the REST root and manually append the namespace + endpoint path.
	$rest_root = rest_url(); // e.g., https://example.com/wp-json/.
	$namespace = WP_MCP_AI_REST::REST_NAMESPACE; // mcp-ai/v1.

	// Build complete URLs for each endpoint.
	$rest_url_base               = trailingslashit( $rest_root ) . trailingslashit( $namespace );
	$slash_command_endpoint      = $rest_url_base . 'slash-command';
	$slash_command_list_endpoint = $rest_url_base . 'slash-command/list';

	wp_localize_script(
		'mcp-ai-slash-commands',
		'mcpAiData',
		array(
			'restUrl'                  => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( $rest_url_base ) ),
			'slashCommandEndpoint'     => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( $slash_command_endpoint ) ),
			'slashCommandListEndpoint' => esc_url_raw( WP_MCP_AI_Request_Context::normalise_rest_url( $slash_command_list_endpoint ) ),
			'nonce'                    => wp_create_nonce( 'wp_rest' ),
		)
	);

	// Note: Slash command scripts are enqueued by the shortcode renderer
	// when the chat interface is loaded. This ensures proper loading order
	// and compatibility with all AI providers including OpenAI, Gemini, and Ollama.
}

/**
 * Get workflow orchestrator instance.
 *
 * @since 1.3.0
 *
 * @return WP_MCP_AI_Slash_Command_Workflow_Orchestrator Orchestrator instance.
 */
function wp_mcp_ai_get_workflow_orchestrator() {
	static $orchestrator = null;

	if ( null === $orchestrator ) {
		$handler = wp_mcp_ai_get_slash_command_handler();
		if ( class_exists( 'WP_MCP_AI_Slash_Command_Workflow_Orchestrator' ) ) {
			$orchestrator = new WP_MCP_AI_Slash_Command_Workflow_Orchestrator( $handler );
		}
	}

	return $orchestrator;
}

/**
 * Get performance optimizer instance.
 *
 * @since 1.3.0
 *
 * @return WP_MCP_AI_Slash_Command_Performance_Optimizer Optimizer instance.
 */
function wp_mcp_ai_get_performance_optimizer() {
	static $optimizer = null;

	if ( null === $optimizer && class_exists( 'WP_MCP_AI_Slash_Command_Performance_Optimizer' ) ) {
		$optimizer = new WP_MCP_AI_Slash_Command_Performance_Optimizer();
	}

	return $optimizer;
}

/**
 * Execute a workflow.
 *
 * Helper function to execute workflows from anywhere in the plugin.
 *
 * @since 1.3.0
 *
 * @param string $workflow_name Workflow name.
 * @param array  $params Workflow parameters.
 * @param array  $context Execution context.
 * @return array Workflow result.
 */
function wp_mcp_ai_execute_workflow( $workflow_name, $params = array(), $context = array() ) {
	$orchestrator = wp_mcp_ai_get_workflow_orchestrator();

	if ( ! $orchestrator ) {
		return array(
			'success' => false,
			'error'   => 'orchestrator_not_available',
			'message' => __( 'Workflow orchestrator not available.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	return $orchestrator->execute_workflow( $workflow_name, $params, $context );
}


/**
 * Create audit table on plugin activation
 *
 * @since 1.2.0
 */
function wp_mcp_ai_create_slash_command_audit_table() {
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/class-wp-mcp-ai-slash-command-audit.php';

	$audit = new WP_MCP_AI_Slash_Command_Audit();
	$audit->create_table();
}

/**
 * Schedule cleanup of old audit logs
 *
 * @since 1.2.0
 */
function wp_mcp_ai_schedule_audit_cleanup() {
	if ( ! wp_next_scheduled( 'wp_mcp_ai_cleanup_slash_audit' ) ) {
		wp_schedule_event( time(), 'daily', 'wp_mcp_ai_cleanup_slash_audit' );
	}
}
add_action( 'init', 'wp_mcp_ai_schedule_audit_cleanup' );

/**
 * Clean old audit logs (runs daily)
 *
 * @since 1.2.0
 */
function wp_mcp_ai_cleanup_slash_audit() {
	require_once WP_MCP_AI_PATH . 'includes/slash-commands/class-wp-mcp-ai-slash-command-audit.php';

	$audit = new WP_MCP_AI_Slash_Command_Audit();

	// Keep 90 days of audit logs by default.
	$days_to_keep = apply_filters( 'wp_mcp_ai_slash_audit_retention_days', 90 );
	$deleted      = $audit->clean_old_logs( $days_to_keep );

	if ( $deleted && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_log used as a diagnostic fallback logger; active only when WP_DEBUG is enabled or as last-resort error capture in catch blocks.
		error_log( sprintf( '[SlashCommands:AUDIT] Cleaned %d old audit log entries (older than %d days)', $deleted, $days_to_keep ) );
	}
}
add_action( 'wp_mcp_ai_cleanup_slash_audit', 'wp_mcp_ai_cleanup_slash_audit' );
