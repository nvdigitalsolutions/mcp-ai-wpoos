<?php
/**
 * Settings Dashboard Initialization
 *
 * Loads the modular settings dashboard system.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load base classes for settings sections.
// Note: Settings Registry and Validator are loaded in the main plugin file.
// Note: abstract-wp-mcp-ai-settings-section.php is now loaded early in main plugin file
// (before Pro addon loads) to prevent fatal errors when Pro sections extend it during activation.

// Load custom filters applicator.
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-custom-filters-applicator.php';

// Load orchestration renderer.
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-orchestration-renderer.php';

// Load dashboard controller.
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-settings-dashboard.php';

// Load onboarding wizard.
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-onboarding-wizard.php';

// Load simple settings saver (for optimized flat settings page).
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-simple-settings-saver.php';

// Load simple settings page (Settings menu diagnostic page).
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-simple-settings-page.php';

// Register autoloader for settings sections (lazy loading).
// This loads section class files only when they are actually instantiated,
// significantly improving admin page load performance.
spl_autoload_register(
	function ( $class_name ) {
		// Map of section class names to their file paths.
		$section_files = array(
			// Base sections.
			'WP_MCP_AI_Section_Overview'            => 'includes/admin/sections/class-wp-mcp-ai-section-overview.php',
			'WP_MCP_AI_Section_General'             => 'includes/admin/sections/class-wp-mcp-ai-section-general.php',
			'WP_MCP_AI_Section_Chat_Client'         => 'includes/admin/sections/class-wp-mcp-ai-section-chat-client.php',
			'WP_MCP_AI_Section_Custom_Filters'      => 'includes/admin/sections/class-wp-mcp-ai-section-custom-filters.php',
			'WP_MCP_AI_Section_Providers'           => 'includes/admin/sections/class-wp-mcp-ai-section-providers.php',
			'WP_MCP_AI_Section_Authentication'      => 'includes/admin/sections/class-wp-mcp-ai-section-authentication.php',
			'WP_MCP_AI_Section_Tools'               => 'includes/admin/sections/class-wp-mcp-ai-section-tools.php',
			'WP_MCP_AI_Section_Orchestration'       => 'includes/admin/sections/class-wp-mcp-ai-section-orchestration.php',
			'WP_MCP_AI_Section_Integrations'        => 'includes/admin/sections/class-wp-mcp-ai-section-integrations.php',
			'WP_MCP_AI_Section_Plugins_Integration' => 'includes/admin/sections/class-wp-mcp-ai-section-plugins-integration.php',
			'WP_MCP_AI_Section_Token_Manager'       => 'includes/admin/sections/class-wp-mcp-ai-section-token-manager.php',
			'WP_MCP_AI_Section_Security'            => 'includes/admin/sections/class-wp-mcp-ai-section-security.php',
			'WP_MCP_AI_Section_Advanced'            => 'includes/admin/sections/class-wp-mcp-ai-section-advanced.php',
			'WP_MCP_AI_Section_Media'               => 'includes/admin/sections/class-wp-mcp-ai-section-media.php',
			'WP_MCP_AI_Section_Comments'            => 'includes/admin/sections/class-wp-mcp-ai-section-comments.php',
		);

		// Add Pro sections if Pro addon is loaded.
		// Pro sections are only available when WP_MCP_AI_PRO_VERSION is defined.
		if ( defined( 'WP_MCP_AI_PRO_VERSION' ) && defined( 'WP_MCP_AI_PRO_PATH' ) ) {
			$section_files['WP_MCP_AI_Section_Performance']       = WP_MCP_AI_PRO_PATH . 'includes/admin/sections/class-wp-mcp-ai-section-performance.php';
			$section_files['WP_MCP_AI_Section_Pro_Providers']     = WP_MCP_AI_PRO_PATH . 'includes/admin/sections/class-wp-mcp-ai-section-pro-providers.php';
			$section_files['WP_MCP_AI_Section_Pro_Integrations']  = WP_MCP_AI_PRO_PATH . 'includes/admin/sections/class-wp-mcp-ai-section-pro-integrations.php';
			$section_files['WP_MCP_AI_Section_Schedule_Manager']  = WP_MCP_AI_PRO_PATH . 'includes/admin/sections/class-wp-mcp-ai-section-schedule-manager.php';
		}

		// Check if this is a section class we should autoload.
		if ( isset( $section_files[ $class_name ] ) ) {
			$file = $section_files[ $class_name ];

			// Handle both absolute paths (Pro sections) and relative paths (base sections).
			// Check if path is already absolute (cross-platform compatible).
			$is_absolute = (
				// Already contains the base path (Pro sections with WP_MCP_AI_PRO_PATH).
				0 === strpos( $file, WP_MCP_AI_PATH ) ||
				// Unix/Linux absolute path.
				0 === strpos( $file, '/' ) ||
				// Windows drive letter (e.g., C:\ or C:/).
				( strlen( $file ) >= 3 && ':' === $file[1] && ( '\\' === $file[2] || '/' === $file[2] ) ) ||
				// Windows UNC path (e.g., \\server\share).
				0 === strpos( $file, '\\\\' )
			);

			if ( ! $is_absolute ) {
				$file = WP_MCP_AI_PATH . $file;
			}

			if ( file_exists( $file ) ) {
				require_once $file;
			}
		}
	}
);

// Load integration admin pages.
// These need to be loaded eagerly as they register admin menus and hooks.
// Note: Plugin integrations (JetEngine, WooCommerce, Elementor) now use sections instead of standalone page.
// Note: External tools integration (Gmail, Crawl4AI, etc.) now uses sections instead of standalone page.
// require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-admin-plugins.php';.

// require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-admin-gmail-crawl.php';.


/**
 * Initialize the settings dashboard system.
 *
 * Note: This is the primary settings dashboard system. The legacy monolithic
 * settings page (class-wp-mcp-ai-admin-settings.php) is no longer registered
 * but the class remains for backward compatibility with its static methods.
 */
function wp_mcp_ai_init_settings_dashboard() {
	// Only initialize once.
	static $initialized = false;
	if ( $initialized ) {
		return;
	}
	$initialized = true;

	// Log initialization attempt for debugging — only active when WP_DEBUG is enabled.
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Diagnostic init trace gated behind WP_DEBUG; no-op in production.
		error_log( '[NV oOS] Initializing settings dashboard system...' );
	}

	// Wrap initialization in try-catch to prevent silent failures.
	try {
		// Get container for dependency management.
		$container = wp_mcp_ai_container();

		// Register all sections with the registry using container.
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.overview' ) );
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.general' ) );
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.chat_client' ) );
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.custom_filters' ) );
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.providers' ) );
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.authentication' ) );
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.tools' ) );
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.orchestration' ) );
		// External Tools (Gmail, Crawl4AI, Brave, Cloudflare, etc.) are now consolidated in integrations section.
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.integrations' ) );
		// Plugin integrations (JetEngine, WooCommerce, Elementor) are now consolidated in a single section.
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.plugins_integration' ) );
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.token_manager' ) );
		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.security' ) );

		// Performance section is only available with Pro addon.
		$performance_section = $container->get( 'section.performance' );
		if ( null !== $performance_section ) {
			WP_MCP_AI_Settings_Registry::register_section( $performance_section );
		}

		// Pro Providers section is NOT registered as a standalone section.
		// Its subtabs are merged into the base Providers section instead.
		// The class is still loaded and instantiated by the container for subtab merging.
		// $pro_providers_section = $container->get( 'section.pro_providers' );
		// if ( null !== $pro_providers_section ) {
		// WP_MCP_AI_Settings_Registry::register_section( $pro_providers_section );
		// }.

		// Pro Integrations section is only available with Pro addon.
		$pro_integrations_section = $container->get( 'section.pro_integrations' );
		if ( null !== $pro_integrations_section ) {
			WP_MCP_AI_Settings_Registry::register_section( $pro_integrations_section );
		}

		// Pro Schedule Manager section is only available with Pro addon.
		// Instantiate via container so that its AJAX handlers remain registered,
		// but do NOT register it with the Settings Registry — it has its own
		// dedicated page at nvoos-pro-schedule-manager.
		$container->get( 'section.schedule_manager' );

		WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.advanced' ) );
		// Media, Comments, and Site Creator sections are now integrated as sub-tabs within the Tools section.
		// WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.media' ) );.

		// WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.comments' ) );.

		// WP_MCP_AI_Settings_Registry::register_section( $container->get( 'section.site_creator' ) );.

		// Initialize the dashboard controller.
		// This creates the top-level "NV oOS" menu item.
		// Store the instance globally for potential access by other code.
		$GLOBALS['wp_mcp_ai_settings_dashboard'] = $container->get( 'admin.settings_dashboard' );
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Diagnostic init trace gated behind WP_DEBUG; no-op in production.
			error_log( '[NV oOS] Settings dashboard controller initialized successfully.' );
		}

		// Initialize simple settings page (Settings menu).
		// This provides a flat diagnostic view of all saved settings.
		$GLOBALS['wp_mcp_ai_simple_settings_page'] = new WP_MCP_AI_Simple_Settings_Page();

		// Initialize onboarding wizard.
		// Registers the "Getting Started" sub-menu, handles activation redirect,
		// and renders the welcome notice for new installs.
		$GLOBALS['wp_mcp_ai_onboarding_wizard'] = new WP_MCP_AI_Onboarding_Wizard();

		// Initialize integration admin pages.
		// Note: Plugin integrations (JetEngine, WooCommerce, Elementor) now use sections instead of standalone page.
		// Note: External tools integration (Gmail, Crawl4AI, etc.) now uses sections instead of standalone page.
		// $GLOBALS['wp_mcp_ai_admin_plugins']     = $container->get( 'admin.plugins_integration' );.

		// $GLOBALS['wp_mcp_ai_admin_gmail_crawl'] = $container->get( 'admin.gmail_crawl_integration' );.

		// Initialize the custom filters applicator.
		// This applies saved filter values to WordPress filters.
		$GLOBALS['wp_mcp_ai_custom_filters_applicator'] = $container->get( 'admin.custom_filters_applicator' );

		// Initialize workflow editor page (Phase 1 feature).
		if ( file_exists( WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-workflow-editor-page.php' ) ) {
			require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-workflow-editor-page.php';
		}
	} catch ( Throwable $e ) {
		// Log the error if logging is enabled.
		if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
			WP_MCP_AI_Logger::log_event(
				'error',
				'Failed to initialize settings dashboard: ' . $e->getMessage(),
				array(
					'file'  => $e->getFile(),
					'line'  => $e->getLine(),
					'trace' => $e->getTraceAsString(),
				)
			);
		}

		// Show admin notice about the error.
		add_action(
			'admin_notices',
			function () use ( $e ) {
				?>
				<div class="notice notice-error">
					<p>
						<strong>NV oOS Settings Dashboard Error:</strong>
						<?php echo esc_html( $e->getMessage() ); ?>
					</p>
					<p>
						<em>Please check the error log for more details or contact support.</em>
					</p>
				</div>
				<?php
			}
		);
	}
}

// Initialize immediately when this file is loaded.
// This ensures the dashboard is instantiated before the admin_menu hook fires.
// This file is only loaded when is_admin() is true, so we don't need to check again.
wp_mcp_ai_init_settings_dashboard();
