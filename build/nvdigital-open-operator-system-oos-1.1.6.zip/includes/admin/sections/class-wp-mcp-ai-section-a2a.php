<?php
/**
 * A2A Protocol Settings Section.
 *
 * Admin settings for the Agent-to-Agent (A2A) protocol integration,
 * including server/client configuration, exposed assistants, and security.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Section_A2A' ) ) {
	/**
	 * A2A protocol settings section.
	 */
	class WP_MCP_AI_Section_A2A extends WP_MCP_AI_Settings_Section {

		/**
		 * Get section ID.
		 *
		 * @return string
		 */
		public function get_id() {
			return 'a2a';
		}

		/**
		 * Get section title.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'A2A Protocol', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * Get tab ID.
		 *
		 * @return string
		 */
		public function get_tab() {
			return 'a2a';
		}

		/**
		 * Get section priority.
		 *
		 * @return int
		 */
		public function get_priority() {
			return 10;
		}

		/**
		 * Get section description.
		 *
		 * @return string
		 */
		public function get_description() {
			return __( 'Configure the Agent-to-Agent (A2A) protocol to enable inter-agent communication. A2A allows your assistants to be discovered by and collaborate with external AI agents. Complements MCP (agent-to-tool) with agent-to-agent capabilities.', 'nvdigital-open-operator-system-oos' );
		}

		/**
		 * Get documentation URL.
		 *
		 * @return string
		 */
		public function get_documentation_url() {
			return 'https://a2a-protocol.org/latest/specification/';
		}

		/**
		 * Get field definitions.
		 *
		 * @return array
		 */
		public function get_fields() {
			return array(
				// ========================================
				// A2A SERVER SETTINGS
				// ========================================
				'_heading_a2a_server'           => array(
					'type'  => 'heading',
					'label' => __( 'A2A Server', 'nvdigital-open-operator-system-oos' ),
				),
				'enable_a2a_server'             => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable A2A Server', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Enable A2A protocol endpoints and agent discovery', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, your site will serve an Agent Card at <code>/.well-known/agent.json</code> and accept A2A JSON-RPC requests at <code>/wp-json/mcp-ai/v1/a2a</code>. External agents can discover and communicate with your assistants.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'a2a_exposed_assistants'        => array(
					'type'        => 'text',
					'label'       => __( 'Exposed Assistants', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Comma-separated list of assistant post IDs to expose via A2A. Leave empty to expose the default assistant only. Each exposed assistant will have its own Agent Card.', 'nvdigital-open-operator-system-oos' ),
					'placeholder' => __( 'e.g., 42, 87, 156', 'nvdigital-open-operator-system-oos' ),
				),

				// ========================================
				// PUSH NOTIFICATIONS
				// ========================================
				'_heading_a2a_push'             => array(
					'type'  => 'heading',
					'label' => __( 'Push Notifications', 'nvdigital-open-operator-system-oos' ),
				),
				'a2a_enable_push_notifications' => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable Push Notifications', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Allow clients to register webhooks for task updates', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, A2A clients can register webhook URLs to receive push notifications when tasks change state. The agent will deliver task updates via HTTP POST to registered endpoints with retry logic.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),

				// ========================================
				// A2A CLIENT SETTINGS
				// ========================================
				'_heading_a2a_client'           => array(
					'type'  => 'heading',
					'label' => __( 'A2A Client (Outbound)', 'nvdigital-open-operator-system-oos' ),
				),
				'enable_a2a_client'             => array(
					'type'           => 'checkbox',
					'label'          => __( 'Enable A2A Client', 'nvdigital-open-operator-system-oos' ),
					'checkbox_label' => __( 'Allow assistants to delegate tasks to remote A2A agents', 'nvdigital-open-operator-system-oos' ),
					'description'    => __( 'When enabled, the "Delegate to A2A Agent" tool becomes available, allowing your assistants to discover and communicate with external A2A-compliant agents. This enables cross-organizational agent collaboration.', 'nvdigital-open-operator-system-oos' ),
					'default'        => false,
				),
				'a2a_default_auth_type'         => array(
					'type'        => 'select',
					'label'       => __( 'Default Authentication Type', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Default authentication method when connecting to remote A2A agents.', 'nvdigital-open-operator-system-oos' ),
					'options'     => array(
						'none'   => __( 'None', 'nvdigital-open-operator-system-oos' ),
						'bearer' => __( 'Bearer Token', 'nvdigital-open-operator-system-oos' ),
						'apiKey' => __( 'API Key', 'nvdigital-open-operator-system-oos' ),
					),
					'default'     => 'none',
				),
				'a2a_default_auth_token'        => array(
					'type'        => 'password',
					'label'       => __( 'Default Auth Token / API Key', 'nvdigital-open-operator-system-oos' ),
					'description' => __( 'Default authentication credential for outbound A2A requests. Can be overridden per-request by the tool.', 'nvdigital-open-operator-system-oos' ),
				),
			);
		}

		/**
		 * Render the settings section content.
		 */
		public function render() {
			// Render the A2A settings form using the standard rendering approach.
			// The parent class handles the field rendering.
		}
	}
}
