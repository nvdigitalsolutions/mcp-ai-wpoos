<?php
/**
 * REST Controller for MCP Apps management.
 *
 * Provides REST API endpoints for testing MCP App connections,
 * discovering available tools from remote MCP servers, and managing
 * OAuth 2.0 web login authentication.
 *
 * @package WP_MCP_AI_Pro
 * @since   1.8.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST API controller for MCP Apps.
 *
 * @since 1.8.0
 */
class WP_MCP_AI_REST_MCP_Apps_Controller {

	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	const NAMESPACE = 'mcp-ai/v1';

	/**
	 * Transient key prefix for OAuth flow state.
	 *
	 * @var string
	 */
	const OAUTH_STATE_TRANSIENT = 'wp_mcp_ai_mcp_app_oauth_state_';

	/**
	 * OAuth state transient TTL (10 minutes).
	 *
	 * @var int
	 */
	const OAUTH_STATE_TTL = 600;

	/**
	 * Register REST routes.
	 *
	 * @since 1.8.0
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			self::NAMESPACE,
			'/mcp-apps/test',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'test_connection' ),
					'permission_callback' => array( $this, 'check_admin_permissions' ),
					'args'                => array(
						'server_url'   => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'esc_url_raw',
							'description'       => __( 'Remote MCP server endpoint URL.', 'nvdigital-open-operator-system-oos-pro' ),
						),
						'assistant_id' => array(
							'type'              => 'integer',
							'required'          => false,
							'sanitize_callback' => 'absint',
							'default'           => 0,
							'description'       => __( 'Assistant ID to persist the connection status against.', 'nvdigital-open-operator-system-oos-pro' ),
						),
						'auth_type'    => array(
							'type'              => 'string',
							'default'           => 'none',
							'enum'              => array( 'none', 'bearer', 'basic', 'header', 'oauth' ),
							'sanitize_callback' => 'sanitize_key',
						),
						'token'        => array(
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'header_name'  => array(
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'timeout'      => array(
							'type'    => 'integer',
							'default' => 30,
							'minimum' => 1,
							'maximum' => 120,
						),
						'verify_ssl'   => array(
							'type'    => 'boolean',
							'default' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/mcp-apps/discover',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'discover_tools' ),
					'permission_callback' => array( $this, 'check_admin_permissions' ),
					'args'                => array(
						'server_url'   => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'esc_url_raw',
						),
						'assistant_id' => array(
							'type'              => 'integer',
							'required'          => false,
							'sanitize_callback' => 'absint',
							'default'           => 0,
						),
						'auth_type'    => array(
							'type'              => 'string',
							'default'           => 'none',
							'enum'              => array( 'none', 'bearer', 'basic', 'header', 'oauth' ),
							'sanitize_callback' => 'sanitize_key',
						),
						'token'        => array(
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'header_name'  => array(
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'timeout'      => array(
							'type'    => 'integer',
							'default' => 30,
							'minimum' => 1,
							'maximum' => 120,
						),
						'verify_ssl'   => array(
							'type'    => 'boolean',
							'default' => true,
						),
						'refresh'      => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => __( 'Bypass the cached tool discovery result.', 'nvdigital-open-operator-system-oos-pro' ),
						),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/mcp-apps/(?P<assistant_id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_assistant_apps' ),
					'permission_callback' => array( $this, 'check_admin_permissions' ),
					'args'                => array(
						'assistant_id' => array(
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
					),
				),
			)
		);

		// OAuth: probe whether a remote server supports OAuth web login.
		register_rest_route(
			self::NAMESPACE,
			'/mcp-apps/oauth/probe',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'probe_oauth' ),
					'permission_callback' => array( $this, 'check_admin_permissions' ),
					'args'                => array(
						'server_url' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'esc_url_raw',
						),
					),
				),
			)
		);

		// OAuth: initiate the authorization flow (returns redirect URL).
		register_rest_route(
			self::NAMESPACE,
			'/mcp-apps/oauth/init',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'initiate_oauth' ),
					'permission_callback' => array( $this, 'check_admin_permissions' ),
					'args'                => array(
						'server_url'     => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'esc_url_raw',
						),
						'assistant_id'   => array(
							'type'              => 'integer',
							'required'          => false,
							'sanitize_callback' => 'absint',
							'default'           => 0,
						),
						'scope'          => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'connection_ref' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_key',
							'description'       => __( 'Optional central Remote Sites connection ID; tokens persist to its encrypted store instead of assistant meta.', 'nvdigital-open-operator-system-oos-pro' ),
						),
					),
				),
			)
		);

		// OAuth: complete a manual loopback flow. Providers such as Upwork only
		// accept localhost redirect URIs, so the admin pastes the callback URL
		// (copied from the browser address bar) back into the admin UI.
		register_rest_route(
			self::NAMESPACE,
			'/mcp-apps/oauth/complete',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'complete_oauth' ),
					'permission_callback' => array( $this, 'check_admin_permissions' ),
					'args'                => array(
						'state'        => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'callback_url' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'esc_url_raw',
							'description'       => __( 'The full localhost callback URL copied from the browser address bar.', 'nvdigital-open-operator-system-oos-pro' ),
						),
					),
				),
			)
		);

		// OAuth callback — handles redirect from remote authorization server.
		// Public endpoint because the remote server redirects the browser here.
		register_rest_route(
			self::NAMESPACE,
			'/mcp-apps/oauth/callback',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'handle_oauth_callback' ),
					'permission_callback' => '__return_true',
					'args'                => array(
						// Deliberately NOT required: authorization servers redirect
						// back with only ?error=...&error_description=... on denial,
						// and the handler renders a human-facing page for that case.
						// Marking them required would make REST validation reject the
						// request before the handler runs, showing a raw JSON error.
						'code'  => array(
							'type' => 'string',
						),
						'state' => array(
							'type' => 'string',
						),
					),
				),
			)
		);

		// OAuth: refresh an existing OAuth token.
		register_rest_route(
			self::NAMESPACE,
			'/mcp-apps/oauth/refresh',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'refresh_oauth_token' ),
					'permission_callback' => array( $this, 'check_admin_permissions' ),
					'args'                => array(
						'server_url'    => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'esc_url_raw',
						),
						'refresh_token' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		// OAuth: revoke a token.
		register_rest_route(
			self::NAMESPACE,
			'/mcp-apps/oauth/revoke',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'revoke_oauth_token' ),
					'permission_callback' => array( $this, 'check_admin_permissions' ),
					'args'                => array(
						'server_url' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'esc_url_raw',
						),
						'token'      => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);
	}

	/**
	 * Permission callback for admin-only endpoints.
	 *
	 * @since 1.8.0
	 * @return bool|WP_Error
	 */
	public function check_admin_permissions() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'wp_mcp_ai_forbidden',
				__( 'You do not have permission to manage MCP Apps.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Test connection to a remote MCP server.
	 *
	 * @since 1.8.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function test_connection( WP_REST_Request $request ) {
		$server_url   = $request->get_param( 'server_url' );
		$assistant_id = (int) $request->get_param( 'assistant_id' );

		// SSRF protection: validate URL before any outbound HTTP.
		$url_check = wp_mcp_ai_validate_url( $server_url );
		if ( is_wp_error( $url_check ) ) {
			return $url_check;
		}

		// Validate URL against the allowlist before issuing any outbound HTTP.
		$allowed = WP_MCP_AI_MCP_App_Registry::is_url_allowed( $server_url );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$config = array(
			'server_url'  => $server_url,
			'auth_type'   => $request->get_param( 'auth_type' ),
			'token'       => $request->get_param( 'token' ),
			'header_name' => $request->get_param( 'header_name' ),
			'timeout'     => $request->get_param( 'timeout' ),
			'verify_ssl'  => $request->get_param( 'verify_ssl' ),
		);
		$config = $this->resolve_stored_token( $assistant_id, $config );

		$registry = WP_MCP_AI_MCP_App_Registry::get_instance();
		$result   = $registry->test_connection( $config, $assistant_id );

		if ( $assistant_id ) {
			if ( is_wp_error( $result ) ) {
				$registry->record_app_status(
					$assistant_id,
					$config,
					array(
						'last_status' => 'error',
						'last_error'  => $result->get_error_message(),
					)
				);
			} else {
				$registry->record_app_status(
					$assistant_id,
					$config,
					array(
						'last_status' => 'ok',
						'last_error'  => isset( $result['tool_error'] ) ? $result['tool_error'] : '',
						'tool_count'  => isset( $result['tool_count'] ) ? $result['tool_count'] : null,
						'protocol'    => isset( $result['protocol'] ) ? $result['protocol'] : '',
						'server_name' => isset( $result['server_info']['name'] ) ? $result['server_info']['name'] : '',
						'latency_ms'  => isset( $result['latency_ms'] ) ? $result['latency_ms'] : null,
					)
				);
			}
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Help the UI flag same-server (loopback) connections.
		$result['same_origin'] = $this->is_same_origin( $server_url );

		return rest_ensure_response( $result );
	}

	/**
	 * Check whether a server URL points at this WordPress site (loopback).
	 *
	 * @since 1.9.1
	 * @param string $server_url Remote MCP server URL.
	 * @return bool True when the host matches the site's own host.
	 */
	protected function is_same_origin( $server_url ) {
		$remote_host = strtolower( (string) wp_parse_url( $server_url, PHP_URL_HOST ) );
		$site_host   = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );

		return '' !== $remote_host && $remote_host === $site_host;
	}

	/**
	 * Resolve an omitted token from the assistant's saved apps.
	 *
	 * The metabox masks stored credentials, so its test requests may omit the
	 * token. When the submitted URL matches a saved app for the same
	 * assistant, reuse the stored credential — mirroring the save-time
	 * "leave blank to keep" semantics.
	 *
	 * @since 1.9.1
	 * @param int   $assistant_id Assistant post ID.
	 * @param array $config       Connection config from the request.
	 * @return array Config with the stored token restored when applicable.
	 */
	protected function resolve_stored_token( $assistant_id, array $config ) {
		if ( ! $assistant_id ) {
			return $config;
		}

		$registry = WP_MCP_AI_MCP_App_Registry::get_instance();
		foreach ( $registry->get_apps( $assistant_id ) as $saved ) {
			if ( ! isset( $saved['server_url'] ) || $saved['server_url'] !== $config['server_url'] ) {
				continue;
			}

			// Bearer/basic/header credentials are masked in the UI, so a test
			// payload may omit them. Restore the stored token when the caller
			// did not submit one.
			if ( empty( $config['token'] ) && ! empty( $saved['token'] ) ) {
				$config['token'] = $saved['token'];
			}

			// OAuth apps keep their credentials in oauth_data, which is never
			// sent back to the browser. Restore the stored OAuth blob so the
			// OAuth client can resolve an access token (and refresh it when
			// expired) instead of failing with "no access token available".
			if ( empty( $config['oauth_data'] ) && ! empty( $saved['oauth_data']['access_token'] ) ) {
				$config['oauth_data'] = $saved['oauth_data'];
				if ( empty( $config['token'] ) ) {
					$config['token'] = $saved['oauth_data']['access_token'];
				}
			}

			break;
		}

		return $config;
	}

	/**
	 * Discover tools from a remote MCP server.
	 *
	 * @since 1.8.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function discover_tools( WP_REST_Request $request ) {
		$server_url   = $request->get_param( 'server_url' );
		$assistant_id = (int) $request->get_param( 'assistant_id' );
		$refresh      = (bool) $request->get_param( 'refresh' );

		// SSRF protection: validate URL before any outbound HTTP.
		$url_check = wp_mcp_ai_validate_url( $server_url );
		if ( is_wp_error( $url_check ) ) {
			return $url_check;
		}

		$config = array(
			'server_url'  => $server_url,
			'auth_type'   => $request->get_param( 'auth_type' ),
			'token'       => $request->get_param( 'token' ),
			'header_name' => $request->get_param( 'header_name' ),
			'timeout'     => $request->get_param( 'timeout' ),
			'verify_ssl'  => $request->get_param( 'verify_ssl' ),
		);
		$config = $this->resolve_stored_token( $assistant_id, $config );

		$registry = WP_MCP_AI_MCP_App_Registry::get_instance();
		$tools    = $registry->discover_tools( $config, $refresh, $assistant_id );

		if ( is_wp_error( $tools ) ) {
			if ( $assistant_id ) {
				$registry->record_app_status(
					$assistant_id,
					$config,
					array(
						'last_status' => 'error',
						'last_error'  => $tools->get_error_message(),
					)
				);
			}
			return $tools;
		}

		if ( $assistant_id ) {
			$registry->record_app_status(
				$assistant_id,
				$config,
				array(
					'last_status' => 'ok',
					'last_error'  => '',
					'tool_count'  => count( $tools ),
				)
			);
		}

		// Format tools for display.
		$formatted = array();
		foreach ( $tools as $tool ) {
			$formatted_tool = array(
				'name'        => isset( $tool['name'] ) ? $tool['name'] : '',
				'description' => isset( $tool['description'] ) ? $tool['description'] : '',
				'has_ui'      => ! empty( $tool['_meta']['ui']['resourceUri'] ) || ! empty( $tool['_meta']['ui/resourceUri'] ),
			);

			if ( isset( $tool['inputSchema'] ) ) {
				$formatted_tool['parameters'] = $tool['inputSchema'];
			}

			$formatted[] = $formatted_tool;
		}

		return rest_ensure_response(
			array(
				'success'    => true,
				'tool_count' => count( $formatted ),
				'tools'      => $formatted,
			)
		);
	}

	/**
	 * Get MCP Apps configured for an assistant.
	 *
	 * @since 1.8.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_assistant_apps( WP_REST_Request $request ) {
		$assistant_id = $request->get_param( 'assistant_id' );

		$post = get_post( $assistant_id );
		if ( ! $post || 'mcp_ai_assistant' !== $post->post_type ) {
			return new WP_Error(
				'wp_mcp_ai_not_found',
				__( 'Assistant not found.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 404 )
			);
		}

		$registry = WP_MCP_AI_MCP_App_Registry::get_instance();
		$apps     = $registry->get_apps( $assistant_id );

		// Mask tokens in response.
		$safe_apps = array();
		foreach ( $apps as $app ) {
			$app_copy = $app;
			if ( ! empty( $app_copy['token'] ) ) {
				$token_length      = strlen( $app_copy['token'] );
				$app_copy['token'] = ( $token_length > 8 )
					? '••••••••' . substr( $app_copy['token'], -4 )
					: '••••••••';
			}
			// Mask OAuth tokens too.
			if ( ! empty( $app_copy['oauth_data']['access_token'] ) ) {
				$app_copy['oauth_data']['access_token'] = '••••••••';
			}
			if ( ! empty( $app_copy['oauth_data']['refresh_token'] ) ) {
				$app_copy['oauth_data']['refresh_token'] = '••••••••';
			}
			$safe_apps[] = $app_copy;
		}

		return rest_ensure_response(
			array(
				'success'      => true,
				'assistant_id' => $assistant_id,
				'apps'         => $safe_apps,
				'app_count'    => count( $safe_apps ),
			)
		);
	}

	// -----------------------------------------------------------------------
	// OAuth Endpoint Handlers
	// -----------------------------------------------------------------------

	/**
	 * Lazy-load the Remote Site Manager class.
	 *
	 * OAuth flow requests are standalone REST calls, so the admin bootstrap
	 * may not have loaded the manager yet.
	 *
	 * @since 1.1.94
	 * @return bool True when the class is available.
	 */
	protected function load_remote_site_manager() {
		if ( ! class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
			$manager_file = defined( 'WP_MCP_AI_PRO_PATH' )
				? WP_MCP_AI_PRO_PATH . 'includes/class-wp-mcp-ai-pro-remote-site-manager.php'
				: dirname( __DIR__, 2 ) . '/includes/class-wp-mcp-ai-pro-remote-site-manager.php';
			if ( file_exists( $manager_file ) ) {
				require_once $manager_file;
			}
		}

		return class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' );
	}

	/**
	 * Map a central Remote Sites connection onto an MCP App client config.
	 *
	 * Mirrors {@see WP_MCP_AI_MCP_App_Registry::resolve_connection_ref()}: only
	 * MCP-capable connections map, and the result carries the connection's
	 * proxy (FlowHub MCP mode), timeout, and SSL settings.
	 *
	 * @since 1.1.94
	 * @param array $connection Stored Remote Sites connection.
	 * @return array MCP App client config (empty when not MCP-capable).
	 */
	protected function map_connection_to_app_config( $connection ) {
		$type = isset( $connection['connection_type'] ) ? $connection['connection_type'] : '';

		if ( 'flowhub' === $type && 'mcp' === ( isset( $connection['flowhub_mode'] ) ? $connection['flowhub_mode'] : '' ) ) {
			return WP_MCP_AI_Pro_Remote_Site_Manager::build_flowhub_mcp_app_config( $connection );
		}

		if ( 'upwork' === $type && 'mcp' === ( isset( $connection['upwork_mode'] ) ? $connection['upwork_mode'] : '' ) ) {
			return WP_MCP_AI_Pro_Remote_Site_Manager::build_upwork_mcp_app_config( $connection );
		}

		if ( 'mcp_server' === $type ) {
			return WP_MCP_AI_Pro_Remote_Site_Manager::build_mcp_app_config_from_connection( $connection );
		}

		return array();
	}

	/**
	 * Resolve a central connection ID onto an MCP App client config.
	 *
	 * @since 1.1.94
	 * @param string $connection_ref Remote Sites connection ID.
	 * @return array MCP App client config (empty when unresolvable).
	 */
	protected function resolve_connection_app_config( $connection_ref ) {
		if ( '' === $connection_ref || ! $this->load_remote_site_manager() ) {
			return array();
		}

		$connection = WP_MCP_AI_Pro_Remote_Site_Manager::get_connection( $connection_ref );
		if ( ! is_array( $connection ) ) {
			return array();
		}

		return $this->map_connection_to_app_config( $connection );
	}

	/**
	 * Locate a central connection whose gateway URL matches a server URL.
	 *
	 * Used when the OAuth flow is started without an explicit connection_ref
	 * (e.g. an inline MCP App row pointing at the FlowHub gateway). An exact
	 * URL match wins; otherwise the first connection sharing the same origin
	 * is used so proxy inheritance still applies.
	 *
	 * @since 1.1.94
	 * @param string $server_url MCP server URL.
	 * @return array MCP App client config (empty when no match).
	 */
	protected function find_connection_app_config_by_url( $server_url ) {
		if ( '' === $server_url || ! $this->load_remote_site_manager() ) {
			return array();
		}

		$normalized = strtolower( rtrim( $server_url, '/' ) );
		$origin     = wp_parse_url( $normalized, PHP_URL_SCHEME ) . '://' . wp_parse_url( $normalized, PHP_URL_HOST );
		$fallback   = null;

		foreach ( WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections() as $connection ) {
			if ( ! is_array( $connection ) ) {
				continue;
			}

			$type      = isset( $connection['connection_type'] ) ? $connection['connection_type'] : '';
			$candidate = '';

			if ( 'flowhub' === $type && 'mcp' === ( isset( $connection['flowhub_mode'] ) ? $connection['flowhub_mode'] : '' ) ) {
				$candidate = isset( $connection['flowhub_mcp_url'] ) && '' !== trim( (string) $connection['flowhub_mcp_url'] )
					? esc_url_raw( $connection['flowhub_mcp_url'] )
					: 'https://mcp.flowhub.com';
			} elseif ( 'upwork' === $type && 'mcp' === ( isset( $connection['upwork_mode'] ) ? $connection['upwork_mode'] : '' ) ) {
				$candidate = isset( $connection['upwork_mcp_url'] ) && '' !== trim( (string) $connection['upwork_mcp_url'] )
					? esc_url_raw( $connection['upwork_mcp_url'] )
					: 'https://mcp.upwork.com/mcp';
			} elseif ( 'mcp_server' === $type ) {
				$candidate = isset( $connection['url'] ) ? (string) $connection['url'] : '';
			}

			if ( '' === $candidate ) {
				continue;
			}

			$candidate_normalized = strtolower( rtrim( $candidate, '/' ) );
			if ( $candidate_normalized === $normalized ) {
				return $this->map_connection_to_app_config( $connection );
			}

			if ( null === $fallback ) {
				$candidate_origin = wp_parse_url( $candidate_normalized, PHP_URL_SCHEME ) . '://' . wp_parse_url( $candidate_normalized, PHP_URL_HOST );
				if ( $candidate_origin === $origin ) {
					$fallback = $connection;
				}
			}
		}

		return null === $fallback ? array() : $this->map_connection_to_app_config( $fallback );
	}

	/**
	 * Build OAuth client options for a server URL, inheriting proxy settings
	 * from a matching central Remote Sites connection.
	 *
	 * Geo-blocked gateways (e.g. FlowHub's MCP endpoint) require OAuth
	 * discovery, DCR, and token traffic to route through the connection's
	 * outbound proxy — the same proxy the Remote Sites connection test and
	 * the chat-time bridge use. Without it, OAuth web login fails with HTTP
	 * 403 outside allowed regions even though the connection itself tests
	 * fine.
	 *
	 * @since 1.1.94
	 * @param string $server_url     MCP server URL.
	 * @param string $connection_ref Optional central Remote Sites connection ID.
	 * @return array OAuth client options (timeout, verify_ssl, proxy_url, proxy_auth).
	 */
	protected function get_oauth_client_options( $server_url, $connection_ref = '' ) {
		$options = array(
			'timeout'    => 30,
			'verify_ssl' => true,
		);

		$config = array();
		if ( '' !== $connection_ref ) {
			$config = $this->resolve_connection_app_config( $connection_ref );
		}
		if ( empty( $config ) && '' !== $server_url ) {
			$config = $this->find_connection_app_config_by_url( $server_url );
		}

		if ( ! empty( $config['proxy_url'] ) ) {
			$options['proxy_url']  = (string) $config['proxy_url'];
			$options['proxy_auth'] = isset( $config['proxy_auth'] ) ? (string) $config['proxy_auth'] : '';
		}
		if ( isset( $config['timeout'] ) ) {
			$options['timeout'] = max( 1, min( 120, absint( $config['timeout'] ) ) );
		}
		if ( isset( $config['verify_ssl'] ) ) {
			$options['verify_ssl'] = (bool) $config['verify_ssl'];
		}

		return $options;
	}

	/**
	 * Rebuild OAuth client options from the flow state stored at initiation.
	 *
	 * @since 1.1.94
	 * @param array $flow_state Flow state stored in the OAuth state transient.
	 * @return array OAuth client options.
	 */
	protected function oauth_options_from_flow_state( $flow_state ) {
		$options = array(
			'timeout'    => ! empty( $flow_state['timeout'] ) ? absint( $flow_state['timeout'] ) : 30,
			'verify_ssl' => isset( $flow_state['verify_ssl'] ) ? (bool) $flow_state['verify_ssl'] : true,
		);

		if ( ! empty( $flow_state['proxy_url'] ) ) {
			$options['proxy_url']  = (string) $flow_state['proxy_url'];
			$options['proxy_auth'] = isset( $flow_state['proxy_auth'] ) ? (string) $flow_state['proxy_auth'] : '';
		}

		return $options;
	}

	/**
	 * Probe whether a remote MCP server supports OAuth web login.
	 *
	 * Attempts OAuth metadata discovery from the remote server and returns
	 * whether OAuth authentication is available.
	 *
	 * @since 1.9.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function probe_oauth( WP_REST_Request $request ) {
		$server_url = $request->get_param( 'server_url' );

		if ( ! class_exists( 'WP_MCP_AI_MCP_App_OAuth_Client' ) ) {
			return new WP_Error(
				'wp_mcp_ai_oauth_unavailable',
				__( 'OAuth client is not available.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 500 )
			);
		}

		$oauth_client = new WP_MCP_AI_MCP_App_OAuth_Client( $server_url, $this->get_oauth_client_options( $server_url ) );
		$metadata     = $oauth_client->discover_metadata();

		if ( is_wp_error( $metadata ) ) {
			$error_data = $metadata->get_error_data();
			$response   = array(
				'success'        => true,
				'supports_oauth' => false,
				'message'        => $metadata->get_error_message(),
			);

			// Surface per-attempt diagnostics (URL → status/transport error)
			// and the actionable hint so the UI can explain the failure.
			if ( is_array( $error_data ) ) {
				if ( ! empty( $error_data['attempts'] ) ) {
					$response['attempts'] = $error_data['attempts'];
				}
				if ( ! empty( $error_data['hint'] ) ) {
					$response['hint'] = $error_data['hint'];
				}
			}

			return rest_ensure_response( $response );
		}

		$scopes           = isset( $metadata['scopes_supported'] ) ? $metadata['scopes_supported'] : array();
		$has_registration = ! empty( $metadata['registration_endpoint'] );

		return rest_ensure_response(
			array(
				'success'                => true,
				'supports_oauth'         => true,
				'has_registration'       => $has_registration,
				'discovery_method'       => $oauth_client->get_metadata_source(),
				'scopes_supported'       => $scopes,
				'authorization_endpoint' => isset( $metadata['authorization_endpoint'] ) ? $metadata['authorization_endpoint'] : '',
				'metadata'               => array(
					'issuer' => isset( $metadata['issuer'] ) ? $metadata['issuer'] : '',
				),
			)
		);
	}

	/**
	 * Initiate the OAuth 2.0 authorization code flow for an MCP App.
	 *
	 * Generates PKCE challenge, registers as a dynamic client if needed,
	 * stores flow state in a transient, and returns the authorization URL
	 * that the admin should be redirected to.
	 *
	 * @since 1.9.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function initiate_oauth( WP_REST_Request $request ) {
		$server_url     = $request->get_param( 'server_url' );
		$assistant_id   = $request->get_param( 'assistant_id' );
		$scope          = $request->get_param( 'scope' );
		$connection_ref = $request->get_param( 'connection_ref' );

		if ( ! class_exists( 'WP_MCP_AI_MCP_App_OAuth_Client' ) ) {
			return new WP_Error(
				'wp_mcp_ai_oauth_unavailable',
				__( 'OAuth client is not available.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 500 )
			);
		}

		$oauth_options = $this->get_oauth_client_options( $server_url, $connection_ref );
		$oauth_client  = new WP_MCP_AI_MCP_App_OAuth_Client( $server_url, $oauth_options );

		// Check if OAuth is supported.
		$discovery = $oauth_client->discover_metadata();
		if ( is_wp_error( $discovery ) ) {
			$error_data = $discovery->get_error_data();
			$data       = array(
				'status'     => 400,
				'error_code' => $discovery->get_error_code(),
				'message'    => $discovery->get_error_message(),
			);

			// Pass the per-attempt diagnostics and hint through so the metabox
			// can show which discovery step failed and why.
			if ( is_array( $error_data ) ) {
				if ( ! empty( $error_data['attempts'] ) ) {
					$data['attempts'] = $error_data['attempts'];
				}
				if ( ! empty( $error_data['hint'] ) ) {
					$data['hint'] = $error_data['hint'];
				}
			}

			return new WP_Error(
				'wp_mcp_ai_mcp_app_oauth_not_supported',
				sprintf(
					/* translators: 1: Server URL, 2: Error message. */
					__( 'OAuth 2.0 discovery failed for %1$s: %2$s', 'nvdigital-open-operator-system-oos-pro' ),
					$server_url,
					$discovery->get_error_message()
				),
				$data
			);
		}

		// Register client if supported. Some providers (e.g. Upwork) only
		// accept loopback redirect URIs, so when the registration rejects the
		// site's callback URL we fall back to a manual loopback flow in which
		// the admin pastes the localhost callback URL back into the UI.
		$reg_result    = $oauth_client->register_client();
		$redirect_mode = 'redirect';

		if ( is_wp_error( $reg_result ) ) {
			$error_data = $reg_result->get_error_data();
			$oauth_code = is_array( $error_data ) && ! empty( $error_data['oauth_error'] ) ? $error_data['oauth_error'] : '';

			if ( 'invalid_redirect_uri' !== $oauth_code ) {
				return $reg_result;
			}

			// Re-register with a loopback redirect URI (RFC 8252 §7.3 style).
			// The port is arbitrary — nothing listens there; the admin copies
			// the resulting callback URL from the browser address bar.
			$oauth_client->set_redirect_uri( 'http://localhost:' . wp_rand( 1024, 49151 ) . '/callback' );
			$reg_result = $oauth_client->register_client();
			if ( is_wp_error( $reg_result ) ) {
				return $reg_result;
			}
			$redirect_mode = 'manual_loopback';
		}

		// Generate PKCE and state.
		$pkce  = $oauth_client->generate_pkce();
		$state = $oauth_client->generate_state();

		// Build authorization URL.
		$auth_url = $oauth_client->get_authorization_url( $scope );
		if ( is_wp_error( $auth_url ) ) {
			return $auth_url;
		}

		// Store flow state in a transient for the callback.
		$flow_state = array(
			'server_url'     => $server_url,
			'assistant_id'   => absint( $assistant_id ),
			'connection_ref' => ! empty( $connection_ref ) ? sanitize_key( $connection_ref ) : '',
			'code_verifier'  => $oauth_client->get_code_verifier(),
			'client_id'      => $oauth_client->get_client_id(),
			'redirect_uri'   => $oauth_client->get_redirect_uri(),
			'redirect_mode'  => $redirect_mode,
			'state'          => $state,
			'scope'          => $scope,
			'created_at'     => time(),
			// Carry the resolved outbound proxy so the token exchange (a
			// separate request) routes through it too — geo-blocked gateways
			// such as FlowHub otherwise reject the token call with 403.
			'proxy_url'      => isset( $oauth_options['proxy_url'] ) ? $oauth_options['proxy_url'] : '',
			'proxy_auth'     => isset( $oauth_options['proxy_auth'] ) ? $oauth_options['proxy_auth'] : '',
			'timeout'        => isset( $oauth_options['timeout'] ) ? $oauth_options['timeout'] : 30,
			'verify_ssl'     => isset( $oauth_options['verify_ssl'] ) ? $oauth_options['verify_ssl'] : true,
		);

		set_transient( self::OAUTH_STATE_TRANSIENT . $state, $flow_state, self::OAUTH_STATE_TTL );

		return rest_ensure_response(
			array(
				'success'           => true,
				'authorization_url' => $auth_url,
				'state'             => $state,
				'client_id'         => $oauth_client->get_client_id(),
				'redirect_mode'     => $redirect_mode,
			)
		);
	}

	/**
	 * Handle the OAuth callback from the remote authorization server.
	 *
	 * The remote server redirects the user's browser here after they
	 * authorize the MCP App. We exchange the authorization code for
	 * tokens, store them, and display a success page.
	 *
	 * @since 1.9.0
	 * @param WP_REST_Request $request Request object.
	 * @return void
	 */
	public function handle_oauth_callback( WP_REST_Request $request ) {
		$code  = $request->get_param( 'code' );
		$state = $request->get_param( 'state' );

		if ( empty( $code ) || empty( $state ) ) {
			// Check for error from authorization server.
			$error = $request->get_param( 'error' );
			if ( ! empty( $error ) ) {
				$error_desc = $request->get_param( 'error_description' );
				wp_die(
					esc_html(
						sprintf(
						/* translators: 1: Error code, 2: Error description. */
							__( 'OAuth authorization failed: %1$s — %2$s', 'nvdigital-open-operator-system-oos-pro' ),
							$error,
							$error_desc ? $error_desc : __( 'No description.', 'nvdigital-open-operator-system-oos-pro' )
						)
					),
					esc_html__( 'OAuth Error', 'nvdigital-open-operator-system-oos-pro' ),
					array( 'response' => 400 )
				);
			}

			wp_die(
				esc_html__( 'Invalid OAuth callback: missing code or state parameter.', 'nvdigital-open-operator-system-oos-pro' ),
				esc_html__( 'OAuth Error', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'response' => 400 )
			);
		}

		// Retrieve flow state from transient.
		$flow_state = get_transient( self::OAUTH_STATE_TRANSIENT . $state );
		if ( ! is_array( $flow_state ) ) {
			wp_die(
				esc_html__( 'OAuth state has expired or is invalid. Please try again.', 'nvdigital-open-operator-system-oos-pro' ),
				esc_html__( 'OAuth Error', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'response' => 400 )
			);
		}

		// Clean up the transient immediately.
		delete_transient( self::OAUTH_STATE_TRANSIENT . $state );

		// Exchange the authorization code for tokens. Restore the flow-specific
		// redirect URI, CSRF state, and outbound proxy options, all of which
		// the fresh request has lost.
		$oauth_client = new WP_MCP_AI_MCP_App_OAuth_Client( $flow_state['server_url'], $this->oauth_options_from_flow_state( $flow_state ) );
		$oauth_client->set_client_id( $flow_state['client_id'] );
		$oauth_client->set_redirect_uri( ! empty( $flow_state['redirect_uri'] ) ? $flow_state['redirect_uri'] : $oauth_client->get_redirect_uri() );
		$oauth_client->set_state( $state );

		$token_result = $oauth_client->exchange_code( $code, $state, $flow_state['code_verifier'] );

		if ( is_wp_error( $token_result ) ) {
			wp_die(
				esc_html(
					sprintf(
					/* translators: %s: Error message. */
						__( 'Failed to exchange authorization code: %s', 'nvdigital-open-operator-system-oos-pro' ),
						$token_result->get_error_message()
					)
				),
				esc_html__( 'OAuth Error', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'response' => 400 )
			);
		}

		// If an assistant ID was provided, auto-save the OAuth config.
		$this->finalize_oauth_flow( $flow_state, $token_result );

		// Render success page and terminate (browser-facing callback).
		$this->render_oauth_success_page( $flow_state['server_url'], $token_result, absint( $flow_state['assistant_id'] ) );
	}

	/**
	 * Persist the OAuth token data onto the assistant's MCP App config.
	 *
	 * Shared by the browser-redirect callback and the manual loopback
	 * completion endpoint.
	 *
	 * @since 1.9.0
	 * @param array $flow_state  Flow state stored at initiation time.
	 * @param array $token_data  Token response from the token endpoint.
	 * @return void
	 */
	protected function finalize_oauth_flow( $flow_state, $token_data ) {
		$registry = WP_MCP_AI_MCP_App_Registry::get_instance();

		// Upwork MCP tokens persist the dynamic client ID so auto-refresh can
		// identify itself (providers such as Upwork reject refresh requests
		// that lack it).
		$token_data = array_merge(
			$token_data,
			array(
				'client_id' => isset( $flow_state['client_id'] ) ? $flow_state['client_id'] : '',
			)
		);

		// Centrally managed connections (Remote Sites, e.g. an Upwork
		// freelance-marketplace connection in MCP mode) persist to the
		// encrypted central store via their connection_ref.
		if ( ! empty( $flow_state['connection_ref'] ) ) {
			$registry->update_app_oauth_data( 0, $flow_state['server_url'], $token_data, $flow_state['connection_ref'] );

			// When the login was started from the assistant editor, persist the
			// reference entry itself too (mirrors the inline path below) so it
			// survives the page reload that follows the loopback completion.
			$ref_assistant_id = absint( $flow_state['assistant_id'] );
			if ( $ref_assistant_id ) {
				$ref = $flow_state['connection_ref'];

				$ref_label = '';
				if ( class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
					$ref_connection = WP_MCP_AI_Pro_Remote_Site_Manager::get_connection( $ref );
					if ( is_array( $ref_connection ) && ! empty( $ref_connection['name'] ) ) {
						$ref_label = $ref_connection['name'];
					}
				}
				if ( '' === $ref_label ) {
					$ref_label = (string) wp_parse_url( $flow_state['server_url'], PHP_URL_HOST );
				}

				$existing = $registry->get_apps( $ref_assistant_id );
				$updated  = false;
				foreach ( $existing as $i => $app ) {
					if ( isset( $app['connection_ref'] ) && $app['connection_ref'] === $ref ) {
						$existing[ $i ]['enabled'] = true;
						$updated                   = true;
						break;
					}
				}
				if ( ! $updated ) {
					$existing[] = array(
						'label'          => $ref_label,
						'connection_ref' => $ref,
						'enabled'        => true,
					);
				}
				$registry->save_apps( $ref_assistant_id, $existing );
			}

			return;
		}

		// If an assistant ID was provided, auto-save the OAuth config.
		$assistant_id = absint( $flow_state['assistant_id'] );
		if ( ! $assistant_id ) {
			return;
		}

		$existing = $registry->get_apps( $assistant_id );

		// Build app config with OAuth data.
		$new_app = array(
			'label'      => wp_parse_url( $flow_state['server_url'], PHP_URL_HOST ),
			'server_url' => $flow_state['server_url'],
			'auth_type'  => 'oauth',
			'enabled'    => true,
			'timeout'    => 30,
			'verify_ssl' => true,
			'oauth_data' => $token_data,
		);

		// Check for existing app with same URL to update.
		$updated = false;
		foreach ( $existing as $i => $app ) {
			if ( isset( $app['server_url'] ) && $app['server_url'] === $flow_state['server_url'] ) {
				$existing[ $i ] = array_merge( $app, $new_app );
				$updated        = true;
				break;
			}
		}
		if ( ! $updated ) {
			$existing[] = $new_app;
		}

		$registry->save_apps( $assistant_id, $existing );
	}

	/**
	 * Complete a manual loopback OAuth flow.
	 *
	 * For providers that reject non-localhost redirect URIs (e.g. Upwork),
	 * the browser is sent to a localhost callback URL that never loads. The
	 * admin copies that URL — which carries the authorization code and state
	 * — back into the admin UI, and this endpoint exchanges it.
	 *
	 * @since 1.9.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function complete_oauth( WP_REST_Request $request ) {
		if ( ! class_exists( 'WP_MCP_AI_MCP_App_OAuth_Client' ) ) {
			return new WP_Error(
				'wp_mcp_ai_oauth_unavailable',
				__( 'OAuth client is not available.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 500 )
			);
		}

		$callback_url = $request->get_param( 'callback_url' );
		$state_arg    = $request->get_param( 'state' );

		$query  = wp_parse_url( $callback_url, PHP_URL_QUERY );
		$params = array();
		if ( $query ) {
			wp_parse_str( $query, $params );
		}

		// The pasted URL must be the loopback callback the flow was built for.
		$host = wp_parse_url( $callback_url, PHP_URL_HOST );
		if ( ! in_array( $host, array( 'localhost', '127.0.0.1' ), true ) ) {
			return new WP_Error(
				'wp_mcp_ai_mcp_app_oauth_bad_callback',
				__( 'This does not look like the localhost callback URL. Copy the full address from the browser bar of the tab that opened after login.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( ! empty( $params['error'] ) ) {
			return new WP_Error(
				'wp_mcp_ai_mcp_app_oauth_authorization_error',
				sprintf(
					/* translators: 1: Error code, 2: Error description. */
					__( 'OAuth authorization failed: %1$s — %2$s', 'nvdigital-open-operator-system-oos-pro' ),
					sanitize_text_field( $params['error'] ),
					! empty( $params['error_description'] ) ? sanitize_text_field( $params['error_description'] ) : __( 'No description.', 'nvdigital-open-operator-system-oos-pro' )
				),
				array( 'status' => 400 )
			);
		}

		$code  = isset( $params['code'] ) ? sanitize_text_field( $params['code'] ) : '';
		$state = isset( $params['state'] ) ? sanitize_text_field( $params['state'] ) : '';

		if ( empty( $code ) || empty( $state ) ) {
			return new WP_Error(
				'wp_mcp_ai_mcp_app_oauth_missing_params',
				__( 'The pasted URL is missing the code or state parameter. Copy the full address from the browser bar.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 400 )
			);
		}

		// The state embedded in the URL and the requested state must agree,
		// and must identify a manual loopback flow.
		if ( $state !== $state_arg ) {
			return new WP_Error(
				'wp_mcp_ai_mcp_app_oauth_state_mismatch',
				__( 'OAuth state mismatch. Please start the connection again.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 400 )
			);
		}

		$flow_state = get_transient( self::OAUTH_STATE_TRANSIENT . $state );
		if ( ! is_array( $flow_state ) ) {
			return new WP_Error(
				'wp_mcp_ai_mcp_app_oauth_state_expired',
				__( 'This login link has expired or is no longer valid. Click "Connect via Web Login" again and paste the new callback URL from the login tab.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( empty( $flow_state['redirect_mode'] ) || 'manual_loopback' !== $flow_state['redirect_mode'] ) {
			return new WP_Error(
				'wp_mcp_ai_mcp_app_oauth_wrong_flow',
				__( 'This connection does not use the manual login flow. Please try again.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 400 )
			);
		}

		// Clean up the transient immediately.
		delete_transient( self::OAUTH_STATE_TRANSIENT . $state );

		$oauth_client = new WP_MCP_AI_MCP_App_OAuth_Client( $flow_state['server_url'], $this->oauth_options_from_flow_state( $flow_state ) );
		$oauth_client->set_client_id( $flow_state['client_id'] );
		$oauth_client->set_redirect_uri( ! empty( $flow_state['redirect_uri'] ) ? $flow_state['redirect_uri'] : $oauth_client->get_redirect_uri() );
		$oauth_client->set_state( $state );

		$token_result = $oauth_client->exchange_code( $code, $state, $flow_state['code_verifier'] );
		if ( is_wp_error( $token_result ) ) {
			return new WP_Error(
				'wp_mcp_ai_mcp_app_oauth_token_error',
				sprintf(
					/* translators: %s: Error message. */
					__( 'Failed to exchange authorization code: %s', 'nvdigital-open-operator-system-oos-pro' ),
					$token_result->get_error_message()
				),
				array( 'status' => 400 )
			);
		}

		$this->finalize_oauth_flow( $flow_state, $token_result );

		return rest_ensure_response(
			array(
				'success' => true,
				'message' => __( 'MCP App connected successfully.', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);
	}

	/**
	 * Refresh an OAuth access token.
	 *
	 * @since 1.9.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function refresh_oauth_token( WP_REST_Request $request ) {
		$server_url    = $request->get_param( 'server_url' );
		$refresh_token = $request->get_param( 'refresh_token' );

		if ( ! class_exists( 'WP_MCP_AI_MCP_App_OAuth_Client' ) ) {
			return new WP_Error(
				'wp_mcp_ai_oauth_unavailable',
				__( 'OAuth client is not available.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 500 )
			);
		}

		$oauth_client = new WP_MCP_AI_MCP_App_OAuth_Client( $server_url, $this->get_oauth_client_options( $server_url ) );
		$result       = $oauth_client->refresh_token( $refresh_token );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			array(
				'success'    => true,
				'token_data' => $result,
			)
		);
	}

	/**
	 * Revoke an OAuth token with the remote server.
	 *
	 * @since 1.9.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function revoke_oauth_token( WP_REST_Request $request ) {
		$server_url = $request->get_param( 'server_url' );
		$token      = $request->get_param( 'token' );

		if ( ! class_exists( 'WP_MCP_AI_MCP_App_OAuth_Client' ) ) {
			return new WP_Error(
				'wp_mcp_ai_oauth_unavailable',
				__( 'OAuth client is not available.', 'nvdigital-open-operator-system-oos-pro' ),
				array( 'status' => 500 )
			);
		}

		$oauth_client = new WP_MCP_AI_MCP_App_OAuth_Client( $server_url, $this->get_oauth_client_options( $server_url ) );
		$success      = $oauth_client->revoke_token( $token );

		return rest_ensure_response(
			array(
				'success' => $success,
			)
		);
	}

	/**
	 * Render the OAuth success page after callback.
	 *
	 * Displays a brief HTML page confirming successful authentication
	 * and providing next steps.
	 *
	 * @since 1.9.0
	 * @param string $server_url   The remote MCP server URL.
	 * @param array  $token_data   The token response data.
	 * @param int    $assistant_id Optional assistant ID where the app was saved.
	 * @return void
	 */
	protected function render_oauth_success_page( $server_url, $token_data, $assistant_id = 0 ) {
		$expires_in = isset( $token_data['expires_in'] ) ? absint( $token_data['expires_in'] ) : 3600;
		$scope      = isset( $token_data['scope'] ) ? esc_html( $token_data['scope'] ) : __( 'default', 'nvdigital-open-operator-system-oos-pro' );

		header( 'Content-Type: text/html; charset=utf-8' );
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php esc_html_e( 'MCP App Connected', 'nvdigital-open-operator-system-oos-pro' ); ?></title>
			<style>
				body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 40px auto; max-width: 600px; padding: 0 20px; color: #333; }
				.success-icon { font-size: 48px; text-align: center; margin-bottom: 20px; }
				h1 { font-size: 24px; text-align: center; margin-bottom: 10px; }
				p { font-size: 16px; line-height: 1.5; text-align: center; color: #666; }
				.info-box { background: #f0f6fc; border: 1px solid #c5d9ed; border-radius: 8px; padding: 16px; margin: 20px 0; }
				.info-box dt { font-weight: 600; margin-top: 8px; }
				.info-box dd { margin-left: 0; color: #555; }
				.actions { text-align: center; margin-top: 24px; }
				.btn { display: inline-block; padding: 10px 24px; background: #2271b1; color: #fff; text-decoration: none; border-radius: 4px; font-size: 14px; }
				.btn:hover { background: #135e96; }
			</style>
		</head>
		<body>
			<div class="success-icon">✅</div>
			<h1><?php esc_html_e( 'MCP App Connected!', 'nvdigital-open-operator-system-oos-pro' ); ?></h1>
			<p><?php esc_html_e( 'Your MCP App has been successfully authenticated via web login.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

			<div class="info-box">
				<dl>
					<dt><?php esc_html_e( 'Server', 'nvdigital-open-operator-system-oos-pro' ); ?></dt>
					<dd><?php echo esc_html( $server_url ); ?></dd>

					<dt><?php esc_html_e( 'Scope', 'nvdigital-open-operator-system-oos-pro' ); ?></dt>
					<dd><?php echo esc_html( $scope ); ?></dd>

					<dt><?php esc_html_e( 'Token Expires', 'nvdigital-open-operator-system-oos-pro' ); ?></dt>
					<dd><?php echo esc_html( human_time_diff( time() + $expires_in ) ); ?></dd>
				</dl>
			</div>

			<p class="description">
				<?php esc_html_e( 'The access token will be automatically refreshed when needed. You can close this window now.', 'nvdigital-open-operator-system-oos-pro' ); ?>
			</p>

			<?php if ( $assistant_id ) : ?>
				<div class="actions">
					<a class="btn" href="<?php echo esc_url( admin_url( 'post.php?post=' . $assistant_id . '&action=edit' ) ); ?>">
						<?php esc_html_e( 'Back to Assistant Settings', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</a>
				</div>
			<?php endif; ?>
		</body>
		</html>
		<?php
		exit;
	}
}
