<?php

/**
 * AgentRequest — payload of the agent/request waterfall.
 *
 * @package Nvoos\Core
 * @since   1.3.0
 * @license MIT
 *
 * SPDX-License-Identifier: MIT
 */

declare(strict_types=1);

namespace Nvoos\Core\Domain\Event;

final class AgentRequest
{
    /**
     * @param array<string, mixed> $options
     */
    public function __construct(
        public readonly array $options,
        public readonly int $assistantId,
        public readonly int $iteration,
    ) {
    }
}
