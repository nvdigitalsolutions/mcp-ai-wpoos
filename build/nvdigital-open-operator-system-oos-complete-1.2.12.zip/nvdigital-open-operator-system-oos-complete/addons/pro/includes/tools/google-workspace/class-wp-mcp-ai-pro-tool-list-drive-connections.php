<?php
/**
 * Tool that lists configured Google Drive connections.
 *
 * Lets an agent discover valid connection_id values for search_drive and
 * get_drive_file instead of guessing. Credentials are never exposed — only
 * id, name, type, enabled state, the configured user email, and the optional
 * scoped folder ID are returned.
 *
 * @package WP_MCP_AI_Pro
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-envelope.php';
require_once WP_MCP_AI_PATH . 'includes/admin/class-wp-mcp-ai-admin-settings.php';

/**
 * Provides an assistant tool for discovering Google Drive connections.
 */
class WP_MCP_AI_Pro_Tool_List_Drive_Connections implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	use WP_MCP_AI_Tool_Envelope;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'list_drive_connections';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'List Google Drive Connections', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Lists configured Google Drive connections (Remote Sites roster plus the settings-based fallback) with their connection IDs, names, enabled state, user emails, and optional scoped folder IDs. Use the returned IDs as connection_id for search_drive and get_drive_file. Credentials are never returned.', 'nvdigital-open-operator-system-oos-pro' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Discovering valid connection_id values and enabled state before calling search_drive or get_drive_file.', 'nvdigital-open-operator-system-oos-pro' ),
			'when_not_to_use' => __( 'Reading or searching Drive content; use search_drive or get_drive_file. Listing Gmail connections; use list_gmail_connections.', 'nvdigital-open-operator-system-oos-pro' ),
			'related_tools'   => array( 'search_drive', 'get_drive_file', 'list_gmail_connections' ),
			'notes'           => __( 'Credentials are never returned. The settings-based fallback appears as the "settings" row when no connection_id is passed.', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			// An empty stdClass encodes as `{}`; an empty PHP array would
			// encode as `[]`, which strict providers (DeepSeek) reject with
			// "[] is not of type 'object'" when MCP clients forward the schema.
			'properties'           => new stdClass(),
			'required'             => array(),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'manage_options';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments (none).
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = ! empty( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		$required_capability = apply_filters( 'wp_mcp_ai_list_drive_connections_capability', 'manage_options', $context, $arguments, $this );

		if ( $required_capability && ( ! $user_id || ! user_can( $user_id, $required_capability ) ) ) { // phpcs:ignore WordPress.WP.Capabilities.Undetermined -- Capability resolved via the wp_mcp_ai_list_drive_connections_capability filter (default manage_options).
			return new WP_Error( 'wp_mcp_ai_drive_forbidden', __( 'You do not have permission to list Google Drive connections.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		if ( is_multisite() && $user_id && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_drive_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$connections = array();

		if ( class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
			$all_connections = WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections();

			if ( is_array( $all_connections ) ) {
				foreach ( $all_connections as $conn_id => $connection ) {
					if ( ! is_array( $connection ) ) {
						continue;
					}

					$conn_type = isset( $connection['connection_type'] ) ? sanitize_key( $connection['connection_type'] ) : '';
					if ( 'google_drive' !== $conn_type ) {
						continue;
					}

					// Redacted by construction: credentials are never copied out.
					$connections[] = array(
						'id'              => (string) $conn_id,
						'name'            => isset( $connection['name'] ) ? (string) $connection['name'] : (string) $conn_id,
						'connection_type' => $conn_type,
						'enabled'         => ! empty( $connection['enabled'] ),
						'user_email'      => isset( $connection['user_email'] ) ? (string) $connection['user_email'] : '',
						'folder_id'       => isset( $connection['folder_id'] ) ? (string) $connection['folder_id'] : '',
					);
				}
			}
		}

		// Settings-based fallback: represents the Drive account used when connection_id is omitted.
		$settings = WP_MCP_AI_Admin_Settings::get_settings();
		if ( ! empty( $settings['google_drive_client_id'] ) && ! empty( $settings['google_drive_refresh_token'] ) ) {
			$connections[] = array(
				'id'              => 'settings',
				'name'            => __( 'NV oOS Google Drive settings (default connection)', 'nvdigital-open-operator-system-oos-pro' ),
				'connection_type' => 'google_drive',
				'enabled'         => true,
				'user_email'      => isset( $settings['google_drive_user_email'] ) ? (string) $settings['google_drive_user_email'] : '',
				'folder_id'       => '',
			);
		}

		$data = array(
			'connections' => $connections,
			'note'        => __( 'Credentials are never included in this list. Omit connection_id to use the settings-based default; when no settings credentials are configured, the only enabled connection is used automatically. If several connections are enabled, pass the connection_id explicitly — Drive tools will not guess between them.', 'nvdigital-open-operator-system-oos-pro' ),
		);

		return $this->format_success_response(
			__( 'Google Drive connections listed.', 'nvdigital-open-operator-system-oos-pro' ),
			array( 'data' => $data )
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'pro',                  // Pro tier tool.
			'read-only',            // Only reads configuration, does not modify state.
			'local-only',           // No external API calls.
			'requires-capability',  // Requires user capabilities.
		);
	}
}
