<?php
/**
 * Tool that searches WordPress content with taxonomy and meta filters.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/traits/trait-wp-mcp-ai-relevance-search.php';

/**
 * Searches published content using WP_Query with optional filters
 * and TF-IDF relevance ranking.
 *
 * @since 2.4.0 Added configurable orderby/order and TF-IDF relevance.
 */
class WP_MCP_AI_Tool_Search_Content implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Ability_Interface {
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Relevance_Search;

	/**
	 * Allowed orderby values for content search.
	 *
	 * @since 2.4.0
	 * @var string[]
	 */
	const ORDERBY_OPTIONS = array( 'relevance', 'date', 'title' );

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'search_content';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Search Content', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Search published posts by keyword, post type, taxonomy terms, and metadata. Supports configurable sort order (date, title) and TF-IDF relevance ranking via orderby=relevance.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		$settings  = get_option( 'wp_mcp_ai_settings', array() );
		$max_limit = isset( $settings['query_posts_limit'] ) && $settings['query_posts_limit'] > 0 ? absint( $settings['query_posts_limit'] ) : 50;
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'search_term'       => array(
					'type'        => 'string',
					'description' => __( 'Keyword or phrase to search for.', 'nvdigital-open-operator-system-oos' ),
				),
				'post_type'         => array(
					'type'        => 'string',
					'description' => __( 'Limit results to a specific post type. Use "any" to search across public types.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'any',
				),
				'limit'             => array(
					'type'        => 'integer',
					'description' => __( 'Maximum number of results to return.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 1,
					'maximum'     => $max_limit,
					'default'     => 10,
				),
				'taxonomy_filters'  => array(
					'type'        => 'array',
					'description' => __( 'Optional taxonomy filters. Each filter requires a taxonomy name and one or more terms.', 'nvdigital-open-operator-system-oos' ),
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'taxonomy', 'terms' ),
						'properties'           => array(
							'taxonomy' => array(
								'type'        => 'string',
								'description' => __( 'Taxonomy to filter by (e.g. category, post_tag).', 'nvdigital-open-operator-system-oos' ),
							),
							'terms'    => array(
								'type'        => 'array',
								'items'       => array(
									'type' => 'string',
								),
								'minItems'    => 1,
								'description' => __( 'List of terms to match. Accepts slugs by default.', 'nvdigital-open-operator-system-oos' ),
							),
							'operator' => array(
								'type'        => 'string',
								'enum'        => array( 'IN', 'NOT IN', 'AND', 'EXISTS', 'NOT EXISTS' ),
								'description' => __( 'Comparison operator.', 'nvdigital-open-operator-system-oos' ),
								'default'     => 'IN',
							),
							'field'    => array(
								'type'        => 'string',
								'enum'        => array( 'slug', 'name', 'term_id', 'term_taxonomy_id' ),
								'description' => __( 'Term field to query against.', 'nvdigital-open-operator-system-oos' ),
								'default'     => 'slug',
							),
						),
						'additionalProperties' => false,
					),
				),
				'taxonomy_relation' => array(
					'type'        => 'string',
					'enum'        => array( 'AND', 'OR' ),
					'description' => __( 'Logical relation between multiple taxonomy filters.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'AND',
				),
				'meta_filters'      => array(
					'type'        => 'array',
					'description' => __( 'Optional post meta filters.', 'nvdigital-open-operator-system-oos' ),
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'key', 'value' ),
						'properties'           => array(
							'key'     => array(
								'type'        => 'string',
								'description' => __( 'Meta key to compare.', 'nvdigital-open-operator-system-oos' ),
							),
							'value'   => array(
								'type'        => 'string',
								'description' => __( 'Meta value to compare. Can be a string or JSON-encoded array for IN/NOT IN comparisons.', 'nvdigital-open-operator-system-oos' ),
							),
							'compare' => array(
								'type'        => 'string',
								'enum'        => array( '=', '!=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'EXISTS', 'NOT EXISTS' ),
								'description' => __( 'Meta comparison operator.', 'nvdigital-open-operator-system-oos' ),
								'default'     => '=',
							),
							'type'    => array(
								'type'        => 'string',
								'enum'        => array( 'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED' ),
								'description' => __( 'Data type to cast the meta value for comparisons.', 'nvdigital-open-operator-system-oos' ),
							),
						),
						'additionalProperties' => false,
					),
				),
				'meta_relation'     => array(
					'type'        => 'string',
					'enum'        => array( 'AND', 'OR' ),
					'description' => __( 'Logical relation between multiple meta filters.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'AND',
				),
				'orderby'           => array(
					'type'        => 'string',
					'enum'        => self::ORDERBY_OPTIONS,
					'description' => __( 'Sort results by this field. Use "relevance" for TF-IDF scored results (requires search_term).', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'date',
				),
				'order'             => array(
					'type'        => 'string',
					'enum'        => array( 'ASC', 'DESC' ),
					'description' => __( 'Sort direction: ASC (ascending) or DESC (descending).', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'DESC',
				),
				'search_type'       => array(
					'type'        => 'string',
					'enum'        => array( 'keyword', 'semantic', 'hybrid' ),
					'description' => __( 'Search mode. "keyword" uses MySQL full-text (default). "semantic" uses embedding vector similarity. "hybrid" combines both via reciprocal rank fusion for best results.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'keyword',
				),
				'min_similarity'    => array(
					'type'        => 'number',
					'description' => __( 'Minimum cosine similarity threshold for semantic results (0-1). Lower values return more results but may be less relevant.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 0,
					'maximum'     => 1,
					'default'     => 0.5,
				),
			),
			'required'             => array( 'search_term' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'read' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to search content.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		$search_term = isset( $arguments['search_term'] ) ? sanitize_text_field( $arguments['search_term'] ) : '';
		$search_type = isset( $arguments['search_type'] ) ? sanitize_key( $arguments['search_type'] ) : 'keyword';
		if ( ! in_array( $search_type, array( 'keyword', 'semantic', 'hybrid' ), true ) ) {
			$search_type = 'keyword';
		}

		$min_similarity = isset( $arguments['min_similarity'] ) ? (float) $arguments['min_similarity'] : 0.5;
		$min_similarity = max( 0.0, min( 1.0, $min_similarity ) );

		$post_type = isset( $arguments['post_type'] ) ? sanitize_key( $arguments['post_type'] ) : 'any';
		$settings  = get_option( 'wp_mcp_ai_settings', array() );
		$max_limit = isset( $settings['query_posts_limit'] ) && $settings['query_posts_limit'] > 0 ? absint( $settings['query_posts_limit'] ) : 50;
		$limit     = isset( $arguments['limit'] ) ? absint( $arguments['limit'] ) : 10;
		$limit     = $limit > 0 ? min( $limit, $max_limit ) : 10;

		// Branch: semantic or hybrid search when embeddings are available.
		$can_embed = class_exists( 'WP_MCP_AI_Vector_Context_Service' )
			&& class_exists( 'WP_MCP_AI_Content_Embedding_Store' )
			&& '' !== $search_term;

		if ( ( 'semantic' === $search_type || 'hybrid' === $search_type ) && $can_embed ) {
			$order = isset( $arguments['order'] ) && 'ASC' === strtoupper( $arguments['order'] ) ? 'ASC' : 'DESC';
			return $this->execute_semantic_search( $search_term, $post_type, $limit, $min_similarity, $order, $search_type );
		}

		// Fall through to keyword search (original behaviour).

		$orderby      = $this->sanitise_orderby(
			isset( $arguments['orderby'] ) ? $arguments['orderby'] : 'date',
			'date',
			self::ORDERBY_OPTIONS
		);
		$order        = isset( $arguments['order'] ) && 'ASC' === strtoupper( $arguments['order'] ) ? 'ASC' : 'DESC';
		$algorithm    = isset( $arguments['search_algorithm'] ) && 'bm25' === $arguments['search_algorithm'] ? 'bm25' : 'tfidf';
		$is_relevance = ( 'relevance' === $orderby && '' !== $search_term );

		$taxonomy_filters = $this->prepare_taxonomy_filters( $arguments );
		$meta_filters     = $this->prepare_meta_filters( $arguments );

		if ( '' === $search_term && empty( $taxonomy_filters ) && empty( $meta_filters ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_criteria', __( 'Provide a search term, taxonomy filter, or meta filter to narrow the results.', 'nvdigital-open-operator-system-oos' ) );
		}

		$query_args = array(
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $is_relevance ? 500 : $limit,
			'ignore_sticky_posts'    => true,
			'suppress_filters'       => false,
			'no_found_rows'          => ! $is_relevance,  // Performance: skip when not paginating.
			'update_post_term_cache' => false,
			'update_post_meta_cache' => true,
		);

		// Dynamic orderby — date/title handled here; relevance applied post-query.
		if ( ! $is_relevance ) {
			if ( 'title' === $orderby ) {
				$query_args['orderby'] = 'title';
			} else {
				$query_args['orderby'] = 'date';
			}
			$query_args['order'] = $order;
		} else {
			$query_args['orderby'] = 'date';
			$query_args['order']   = 'DESC';
		}

		if ( '' !== $search_term ) {
			$query_args['s'] = $search_term;
		}

		if ( ! empty( $taxonomy_filters ) ) {
			$query_args['tax_query'] = $taxonomy_filters; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- tax_query required for taxonomy-based content filtering; no alternative index-based query available.
		}

		if ( ! empty( $meta_filters ) ) {
			$query_args['meta_query'] = $meta_filters; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- meta_query required for user-defined content search filters; no alternative index-based query available.
		}

		$query = new WP_Query( $query_args );

		$results = array();
		foreach ( $query->posts as $post ) {
			$post_id = $post instanceof WP_Post ? $post->ID : $post;

			$results[] = array(
				'ID'        => $post_id,
				'title'     => get_the_title( $post_id ),
				'permalink' => get_permalink( $post_id ),
				'excerpt'   => wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ), 30 ),
				'date'      => get_the_date( DATE_W3C, $post_id ),
				'post_type' => get_post_type( $post_id ),
			);
		}

		// Apply TF-IDF relevance ranking when orderby=relevance with a search term.
		if ( $is_relevance ) {
			$field_weights = array(
				'title'   => 3.0,
				'content' => 2.0,
				'excerpt' => 1.0,
			);
			$results       = $this->rank_by_relevance( $results, $search_term, $field_weights, $algorithm );
			$results       = array_slice( $results, 0, $limit );
		}

		// Use trait method to ensure proper message field for chat client.
		return $this->format_collection_response(
			$results,
			sprintf(
				/* translators: 1: number of results, 2: search term */
				__( 'Found %1$d result(s) for "%2$s"', 'nvdigital-open-operator-system-oos' ),
				count( $results ),
				$search_term
			)
		);
	}

	/**
	 * Prepare a tax_query argument from tool inputs.
	 *
	 * @param array $arguments Tool arguments.
	 * @return array
	 */
	protected function prepare_taxonomy_filters( array $arguments ) {
		if ( empty( $arguments['taxonomy_filters'] ) || ! is_array( $arguments['taxonomy_filters'] ) ) {
			return array();
		}

		$relation = 'AND';
		if ( ! empty( $arguments['taxonomy_relation'] ) ) {
			$requested_relation = strtoupper( sanitize_text_field( $arguments['taxonomy_relation'] ) );
			if ( in_array( $requested_relation, array( 'AND', 'OR' ), true ) ) {
				$relation = $requested_relation;
			}
		}

		$tax_query = array();

		foreach ( $arguments['taxonomy_filters'] as $filter ) {
			if ( ! is_array( $filter ) ) {
				continue;
			}

			$taxonomy = isset( $filter['taxonomy'] ) ? sanitize_key( $filter['taxonomy'] ) : '';
			if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}

			$terms = array();
			if ( isset( $filter['terms'] ) && is_array( $filter['terms'] ) ) {
				$terms = $filter['terms'];
			}

			$operator = isset( $filter['operator'] ) ? strtoupper( sanitize_text_field( $filter['operator'] ) ) : 'IN';
			$field    = isset( $filter['field'] ) ? sanitize_key( $filter['field'] ) : 'slug';

			if ( ! in_array( $operator, array( 'IN', 'NOT IN', 'AND', 'EXISTS', 'NOT EXISTS' ), true ) ) {
				$operator = 'IN';
			}

			if ( ! in_array( $field, array( 'slug', 'name', 'term_id', 'term_taxonomy_id' ), true ) ) {
				$field = 'slug';
			}

			$sanitized_terms = array();
			foreach ( $terms as $term ) {
				if ( in_array( $field, array( 'term_id', 'term_taxonomy_id' ), true ) ) {
					$sanitized_terms[] = absint( $term );
				} else {
					$sanitized_terms[] = sanitize_text_field( $term );
				}
			}

			$sanitized_terms = array_filter(
				$sanitized_terms,
				static function ( $value ) {
					if ( is_string( $value ) ) {
						return '' !== $value;
					}

					return null !== $value;
				}
			);

			$clause = array(
				'taxonomy' => $taxonomy,
				'field'    => $field,
				'operator' => $operator,
			);

			if ( ! in_array( $operator, array( 'EXISTS', 'NOT EXISTS' ), true ) ) {
				if ( empty( $sanitized_terms ) ) {
					continue;
				}

				$clause['terms'] = array_values( $sanitized_terms );
			}

			$tax_query[] = $clause;
		}

		if ( empty( $tax_query ) ) {
			return array();
		}

		if ( count( $tax_query ) > 1 || 'AND' !== $relation ) {
			array_unshift( $tax_query, array( 'relation' => $relation ) );
		}

		return $tax_query;
	}

	/**
	 * Prepare a meta_query argument from tool inputs.
	 *
	 * @param array $arguments Tool arguments.
	 * @return array
	 */
	protected function prepare_meta_filters( array $arguments ) {
		if ( empty( $arguments['meta_filters'] ) || ! is_array( $arguments['meta_filters'] ) ) {
			return array();
		}

		$relation = 'AND';
		if ( ! empty( $arguments['meta_relation'] ) ) {
			$requested_relation = strtoupper( sanitize_text_field( $arguments['meta_relation'] ) );
			if ( in_array( $requested_relation, array( 'AND', 'OR' ), true ) ) {
				$relation = $requested_relation;
			}
		}

		$meta_query = array();

		foreach ( $arguments['meta_filters'] as $filter ) {
			if ( ! is_array( $filter ) ) {
				continue;
			}

			$key = isset( $filter['key'] ) ? sanitize_key( $filter['key'] ) : '';
			if ( '' === $key ) {
				continue;
			}

			$compare = isset( $filter['compare'] ) ? strtoupper( sanitize_text_field( $filter['compare'] ) ) : '=';
			if ( ! in_array( $compare, array( '=', '!=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'EXISTS', 'NOT EXISTS' ), true ) ) {
				$compare = '=';
			}

			$value = isset( $filter['value'] ) ? $filter['value'] : '';
			if ( in_array( $compare, array( 'IN', 'NOT IN' ), true ) ) {
				$value = is_array( $value ) ? $value : array( $value );
				$value = array_filter( array_map( 'sanitize_text_field', array_map( 'strval', $value ) ) );
				if ( empty( $value ) ) {
					continue;
				}
			} elseif ( in_array( $compare, array( 'EXISTS', 'NOT EXISTS' ), true ) ) {
				$value = null;
			} else {
				$value = sanitize_text_field( (string) $value );
				if ( '' === $value ) {
					continue;
				}
			}

			$clause = array(
				'key'     => $key,
				'compare' => $compare,
			);

			if ( null !== $value ) {
				$clause['value'] = $value;
			}

			if ( ! empty( $filter['type'] ) ) {
				$type = strtoupper( sanitize_text_field( $filter['type'] ) );
				if ( in_array( $type, array( 'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED' ), true ) ) {
					$clause['type'] = $type;
				}
			}

			$meta_query[] = $clause;
		}

		if ( empty( $meta_query ) ) {
			return array();
		}

		if ( count( $meta_query ) > 1 || 'AND' !== $relation ) {
			array_unshift( $meta_query, array( 'relation' => $relation ) );
		}

		return $meta_query;
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'content_publishing',

			'pattern_compatibility' => array( 'orchestrator', 'peer_to_peer' ),

			'profession_tags'       => array( 'writer', 'researcher', 'editor' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',            // Only reads data, does not modify state.
			'local-only',           // No external API calls.
			'requires-capability',  // Requires 'read' capability.
			'cacheable',            // Results can be cached.
		);
	}

	/**
	 * Execute semantic or hybrid vector search against content embeddings.
	 *
	 * @since 1.9.0
	 *
	 * @param string $search_term    Search query.
	 * @param string $post_type      Post type filter ('any' for all).
	 * @param int    $limit          Max results.
	 * @param float  $min_similarity Minimum cosine similarity (0-1).
	 * @param string $order          Sort direction.
	 * @param string $mode           'semantic' or 'hybrid'.
	 * @return array|WP_Error Results or error.
	 */
	protected function execute_semantic_search( $search_term, $post_type, $limit, $min_similarity, $order, $mode ) {
		try {
			$svc = WP_MCP_AI_Vector_Context_Service::get_instance();
		} catch ( \Throwable $e ) {
			return new WP_Error(
				'wp_mcp_ai_vector_unavailable',
				__( 'Vector search is not available.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$query_vec = $svc->embed_context( $search_term );
		if ( is_wp_error( $query_vec ) ) {
			return new WP_Error(
				'wp_mcp_ai_embedding_failed',
				sprintf(
					/* translators: %s: error message */
					__( 'Failed to generate query embedding: %s', 'nvdigital-open-operator-system-oos' ),
					$query_vec->get_error_message()
				)
			);
		}

		$provider    = $svc->get_embedding_provider();
		$provider_id = is_wp_error( $provider ) ? 'openai' : $provider->get_id();
		$model       = is_wp_error( $provider ) ? 'text-embedding-3-small' : $provider->get_model();

		if ( 'any' === $post_type ) {
			$post_types = get_post_types( array( 'public' => true ) );
		} else {
			$post_types = array( $post_type );
		}

		$candidates = array();
		foreach ( $post_types as $pt ) {
			$rows = WP_MCP_AI_Content_Embedding_Store::get_all_for_type( $pt, $provider_id, $model );
			foreach ( $rows as $row ) {
				$candidates[ $row['post_id'] ] = $row['vector'];
			}
		}

		if ( empty( $candidates ) ) {
			return $this->format_collection_response(
				array(),
				sprintf(
					/* translators: %s: search term */
					__( 'No indexed content found for "%s".', 'nvdigital-open-operator-system-oos' ),
					$search_term
				)
			);
		}

		// Two-stage: HNSW pre-filter when beneficial (>500 candidates).
		$hnsw_available = function_exists( 'wp_mcp_ai_hnsw_ensure_loaded' ) && wp_mcp_ai_hnsw_ensure_loaded();
		$use_hnsw       = $hnsw_available && count( $candidates ) > 500;

		$vector_scores = array();
		if ( $use_hnsw ) {
			$hnsw = WP_MCP_AI_HNSW_Index::get_instance();
			$hnsw->clear();
			$hnsw->set_params( 16, 200, max( 50, $limit * 4 ) );
			$hnsw->insert_batch( $candidates );
			$top = $hnsw->search( $query_vec, $limit * 4 );
			foreach ( $top as $post_id => $score ) {
				$sim = $svc->cosine_similarity( $query_vec, $candidates[ $post_id ] );
				if ( $sim >= $min_similarity ) {
					$vector_scores[ $post_id ] = $sim;
				}
			}
		} else {
			foreach ( $candidates as $post_id => $stored_vec ) {
				$sim = $svc->cosine_similarity( $query_vec, $stored_vec );
				if ( $sim >= $min_similarity ) {
					$vector_scores[ $post_id ] = $sim;
				}
			}
		}

		arsort( $vector_scores, SORT_NUMERIC );

		if ( 'hybrid' === $mode ) {
			$kw_results    = $this->get_keyword_post_ids( $search_term, $post_type, max( $limit * 3, 50 ) );
			$vector_scores = $this->rrf_fuse_simple( $vector_scores, $kw_results, $limit );
		}

		$top_ids = array_slice( array_keys( $vector_scores ), 0, $limit, true );

		$results = array();
		foreach ( $top_ids as $pid ) {
			$pid       = absint( $pid );
			$results[] = array(
				'ID'         => $pid,
				'title'      => get_the_title( $pid ),
				'permalink'  => get_permalink( $pid ),
				'excerpt'    => wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $pid ) ), 30 ),
				'date'       => get_the_date( DATE_W3C, $pid ),
				'post_type'  => get_post_type( $pid ),
				'similarity' => isset( $vector_scores[ $pid ] ) ? round( (float) $vector_scores[ $pid ], 4 ) : 0,
			);
		}

		return $this->format_collection_response(
			$results,
			sprintf(
				/* translators: 1: count, 2: search term, 3: mode */
				__( 'Found %1\$d result(s) for "%2\$s" using %3\$s search', 'nvdigital-open-operator-system-oos' ),
				count( $results ),
				$search_term,
				'hybrid' === $mode ? __( 'hybrid', 'nvdigital-open-operator-system-oos' ) : __( 'semantic', 'nvdigital-open-operator-system-oos' )
			)
		);
	}

	/**
	 * Get post IDs matching a keyword search term.
	 *
	 * @param string $search_term The search term.
	 * @param string $post_type   The post type.
	 * @param int    $limit       Maximum number of results.
	 * @return int[] Array of post IDs.
	 */
	private function get_keyword_post_ids( $search_term, $post_type, $limit ) {
		$q = new WP_Query(
			array(
				'post_type'           => $post_type,
				'post_status'         => 'publish',
				'posts_per_page'      => $limit,
				's'                   => $search_term,
				'orderby'             => 'relevance',
				'order'               => 'DESC',
				'fields'              => 'ids',
				'no_found_rows'       => true,
				'ignore_sticky_posts' => true,
			)
		);
		return $q->posts;
	}

	/**
	 * Fuse vector scores with keyword results using Reciprocal Rank Fusion.
	 *
	 * @param array $vector_scores Associative array of post IDs to similarity scores.
	 * @param array $keyword_ids   Array of post IDs from keyword search.
	 * @param int   $limit         Maximum number of results.
	 * @return array Fused scores.
	 */
	private function rrf_fuse_simple( array $vector_scores, array $keyword_ids, $limit ) {
		$k     = 60;
		$fused = array();
		foreach ( $vector_scores as $pid => $sim ) {
			$fused[ $pid ] = (float) $sim;
		}
		$rank = 0;
		foreach ( $keyword_ids as $pid ) {
			$pid = absint( $pid );
			if ( ! isset( $fused[ $pid ] ) ) {
				$fused[ $pid ] = 0.0;
			}
			$fused[ $pid ] += 1.0 / ( $k + $rank + 1 );
			++$rank;
		}
		arsort( $fused, SORT_NUMERIC );
		return $fused;
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function get_ability_identifier() {
		return 'search-content';
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function get_ability_category() {
		return 'nvoos-content';
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 2.0.0
	 * @return array
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'results'     => array(
					'type'        => 'array',
					'description' => 'Array of matching post objects.',
					'items'       => array(
						'type'       => 'object',
						'properties' => array(
							'ID'        => array(
								'type'        => 'integer',
								'description' => 'The post ID.',
							),
							'title'     => array(
								'type'        => 'string',
								'description' => 'The post title.',
							),
							'post_type' => array(
								'type'        => 'string',
								'description' => 'The post type.',
							),
							'excerpt'   => array(
								'type'        => 'string',
								'description' => 'The post excerpt.',
							),
							'permalink' => array(
								'type'        => 'string',
								'description' => 'The post URL.',
							),
							'date'      => array(
								'type'        => 'string',
								'description' => 'The post date.',
							),
						),
					),
				),
				'total_count' => array(
					'type'        => 'integer',
					'description' => 'Total number of results.',
				),
				'message'     => array(
					'type'        => 'string',
					'description' => 'Human-readable summary.',
				),
			),
		);
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 2.0.0
	 * @return bool
	 */
	public function is_public_ability() {
		return true;
	}
}
