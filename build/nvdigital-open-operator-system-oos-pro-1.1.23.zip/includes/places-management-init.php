<?php
/**
 * Places Management Custom Post Type Registration
 *
 * Registers custom post type for managing places (attractions, businesses, locations).
 * Integrates with Google Maps/Places API for enhanced geospatial capabilities.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register places management custom post type.
 */
function wp_mcp_ai_register_places_management_post_type() {
	// Only register if places management is enabled and not base version, unless Pro addon is active.
	if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() && ! defined( 'WP_MCP_AI_PRO_VERSION' ) ) {
		return;
	}

	// Check if places management is enabled in settings.
	$settings = get_option( 'wp_mcp_ai_settings', array() );
	if ( empty( $settings['enable_places_management'] ) ) {
		return;
	}

	// Register Place CPT.
	register_post_type(
		'mcp_ai_place',
		array(
			'labels'             => array(
				'name'               => __( 'Places', 'nvdigital-open-operator-system-oos-pro' ),
				'singular_name'      => __( 'Place', 'nvdigital-open-operator-system-oos-pro' ),
				'add_new'            => __( 'Add New', 'nvdigital-open-operator-system-oos-pro' ),
				'add_new_item'       => __( 'Add New Place', 'nvdigital-open-operator-system-oos-pro' ),
				'edit_item'          => __( 'Edit Place', 'nvdigital-open-operator-system-oos-pro' ),
				'new_item'           => __( 'New Place', 'nvdigital-open-operator-system-oos-pro' ),
				'view_item'          => __( 'View Place', 'nvdigital-open-operator-system-oos-pro' ),
				'search_items'       => __( 'Search Places', 'nvdigital-open-operator-system-oos-pro' ),
				'not_found'          => __( 'No places found', 'nvdigital-open-operator-system-oos-pro' ),
				'not_found_in_trash' => __( 'No places found in trash', 'nvdigital-open-operator-system-oos-pro' ),
			),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'show_in_rest'       => true,
			'has_archive'        => false,
			'rewrite'            => false,
			'capability_type'    => 'post',
			'supports'           => array( 'title', 'editor', 'thumbnail', 'author' ),
			'menu_icon'          => 'dashicons-location-alt',
			'taxonomies'         => array( 'mcp_ai_place_type', 'mcp_ai_place_tag' ),
		)
	);

	// Register Place Type taxonomy.
	register_taxonomy(
		'mcp_ai_place_type',
		'mcp_ai_place',
		array(
			'labels'            => array(
				'name'          => __( 'Place Types', 'nvdigital-open-operator-system-oos-pro' ),
				'singular_name' => __( 'Place Type', 'nvdigital-open-operator-system-oos-pro' ),
				'search_items'  => __( 'Search Place Types', 'nvdigital-open-operator-system-oos-pro' ),
				'all_items'     => __( 'All Place Types', 'nvdigital-open-operator-system-oos-pro' ),
				'edit_item'     => __( 'Edit Place Type', 'nvdigital-open-operator-system-oos-pro' ),
				'update_item'   => __( 'Update Place Type', 'nvdigital-open-operator-system-oos-pro' ),
				'add_new_item'  => __( 'Add New Place Type', 'nvdigital-open-operator-system-oos-pro' ),
				'new_item_name' => __( 'New Place Type Name', 'nvdigital-open-operator-system-oos-pro' ),
				'menu_name'     => __( 'Place Types', 'nvdigital-open-operator-system-oos-pro' ),
			),
			'hierarchical'      => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'query_var'         => true,
			'rewrite'           => false,
		)
	);

	// Register Place Tag taxonomy.
	register_taxonomy(
		'mcp_ai_place_tag',
		'mcp_ai_place',
		array(
			'labels'            => array(
				'name'          => __( 'Place Tags', 'nvdigital-open-operator-system-oos-pro' ),
				'singular_name' => __( 'Place Tag', 'nvdigital-open-operator-system-oos-pro' ),
				'search_items'  => __( 'Search Place Tags', 'nvdigital-open-operator-system-oos-pro' ),
				'all_items'     => __( 'All Place Tags', 'nvdigital-open-operator-system-oos-pro' ),
				'edit_item'     => __( 'Edit Place Tag', 'nvdigital-open-operator-system-oos-pro' ),
				'update_item'   => __( 'Update Place Tag', 'nvdigital-open-operator-system-oos-pro' ),
				'add_new_item'  => __( 'Add New Place Tag', 'nvdigital-open-operator-system-oos-pro' ),
				'new_item_name' => __( 'New Place Tag Name', 'nvdigital-open-operator-system-oos-pro' ),
				'menu_name'     => __( 'Place Tags', 'nvdigital-open-operator-system-oos-pro' ),
			),
			'hierarchical'      => false,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'query_var'         => true,
			'rewrite'           => false,
		)
	);

	// Register default place types if they don't exist.
	$default_types = array(
		'restaurant'    => __( 'Restaurant', 'nvdigital-open-operator-system-oos-pro' ),
		'cafe'          => __( 'Cafe', 'nvdigital-open-operator-system-oos-pro' ),
		'hotel'         => __( 'Hotel', 'nvdigital-open-operator-system-oos-pro' ),
		'attraction'    => __( 'Attraction', 'nvdigital-open-operator-system-oos-pro' ),
		'museum'        => __( 'Museum', 'nvdigital-open-operator-system-oos-pro' ),
		'park'          => __( 'Park', 'nvdigital-open-operator-system-oos-pro' ),
		'shopping'      => __( 'Shopping', 'nvdigital-open-operator-system-oos-pro' ),
		'entertainment' => __( 'Entertainment', 'nvdigital-open-operator-system-oos-pro' ),
		'business'      => __( 'Business', 'nvdigital-open-operator-system-oos-pro' ),
		'service'       => __( 'Service', 'nvdigital-open-operator-system-oos-pro' ),
	);

	foreach ( $default_types as $slug => $name ) {
		if ( ! term_exists( $slug, 'mcp_ai_place_type' ) ) {
			wp_insert_term( $name, 'mcp_ai_place_type', array( 'slug' => $slug ) );
		}
	}
}
add_action( 'init', 'wp_mcp_ai_register_places_management_post_type' );

// Load Place CPT admin enhancements.
require_once WP_MCP_AI_PRO_PATH . 'includes/class-wp-mcp-ai-place-cpt.php';

// Load Place Research & Add page.
if ( is_admin() ) {
	// Check if places management is enabled and not in base version (unless Pro addon is active).
	$settings      = get_option( 'wp_mcp_ai_settings', array() );
	$is_enabled    = ! empty( $settings['enable_places_management'] );
	$is_base       = function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version();
	$is_pro_active = defined( 'WP_MCP_AI_PRO_VERSION' );

	if ( $is_enabled && ( ! $is_base || $is_pro_active ) ) {
		require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-place-research-page.php';
		require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-place-settings-page.php';
	}
}
