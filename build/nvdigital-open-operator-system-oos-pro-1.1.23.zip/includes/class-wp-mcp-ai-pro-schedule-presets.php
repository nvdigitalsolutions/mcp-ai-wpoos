<?php
/**
 * Pro Schedule Presets
 *
 * Provides pre-configured schedule presets for the Pro Schedule Manager.
 * Each toolkit includes curated presets that can be installed with a single
 * click, automatically creating the corresponding scheduled task, workflow,
 * assistant run, or channel broadcast.
 *
 * Supported schedule types:
 * - task:              Fires a WordPress action hook on a cron interval.
 * - workflow:          Executes a sequence of tool calls.
 * - assistant_run:     Sends a message to a user-selected AI assistant.
 * - channel_broadcast: Broadcasts a message to chat channels.
 * - workflow_builder:  Runs a saved Pro Workflow Builder DAG.
 *
 * @package    WP_MCP_AI_Pro
 * @subpackage Schedule_Presets
 * @since      1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Pro_Schedule_Presets' ) ) {

	/**
	 * Class WP_MCP_AI_Pro_Schedule_Presets
	 *
	 * Registry of pre-built schedule presets organised by toolkit.
	 * All methods are static so the class can be used without instantiation.
	 *
	 * @since 1.0.0
	 */
	class WP_MCP_AI_Pro_Schedule_Presets {

		// ------------------------------------------------------------------
		// Preset retrieval
		// ------------------------------------------------------------------

		/**
		 * Get every available schedule preset.
		 *
		 * Presets are grouped internally by toolkit but returned as a flat
		 * associative array keyed by preset ID.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Associative array of preset definitions.
		 */
		public static function get_presets() {
			$presets = array_merge(
				self::get_ecommerce_presets(),
				self::get_social_media_presets(),
				self::get_analytics_presets(),
				self::get_advanced_analytics_presets(),
				self::get_multilingual_presets(),
				self::get_video_production_presets(),
				self::get_financial_planner_presets(),
				self::get_dj_management_presets(),
				self::get_image_production_presets(),
				self::get_ai_tool_builder_presets(),
				self::get_architect_agent_presets(),
				self::get_architectural_design_presets(),
				self::get_site_creator_presets(),
				self::get_document_generation_presets(),
				self::get_crm_presets(),
				self::get_regulatory_registration_presets(),
				self::get_chat_channels_presets(),
				self::get_media_presets(),
				self::get_calendar_booking_presets(),
				self::get_health_wellness_presets(),
				self::get_upwork_freelancer_presets()
			);

			return $presets;
		}

		/**
		 * Get a single preset by its ID.
		 *
		 * @since  1.0.0
		 * @param  string $preset_id The unique preset identifier.
		 * @return array|null Preset definition array, or null if not found.
		 */
		public static function get_preset( $preset_id ) {
			$presets = self::get_presets();

			return isset( $presets[ $preset_id ] ) ? $presets[ $preset_id ] : null;
		}

		/**
		 * Get all presets belonging to a specific toolkit.
		 *
		 * @since  1.0.0
		 * @param  string $toolkit Toolkit slug (e.g. 'ecommerce', 'crm').
		 * @return array<string, array> Filtered preset definitions.
		 */
		public static function get_presets_by_toolkit( $toolkit ) {
			$toolkit = sanitize_key( $toolkit );

			return array_filter(
				self::get_presets(),
				function ( $preset ) use ( $toolkit ) {
					return isset( $preset['toolkit'] ) && $preset['toolkit'] === $toolkit;
				}
			);
		}

		/**
		 * Get all presets matching a given category.
		 *
		 * @since  1.0.0
		 * @param  string $category Category slug (e.g. 'content', 'monitoring').
		 * @return array<string, array> Filtered preset definitions.
		 */
		public static function get_presets_by_category( $category ) {
			$category = sanitize_key( $category );

			return array_filter(
				self::get_presets(),
				function ( $preset ) use ( $category ) {
					return isset( $preset['category'] ) && $preset['category'] === $category;
				}
			);
		}

		/**
		 * Get the list of available preset categories.
		 *
		 * @since  1.0.0
		 * @return array<string, string> Slug => label pairs.
		 */
		public static function get_categories() {
			return array(
				'content'       => __( 'Content Creation & Management', 'nvdigital-open-operator-system-oos-pro' ),
				'monitoring'    => __( 'Site Monitoring & Health Checks', 'nvdigital-open-operator-system-oos-pro' ),
				'reporting'     => __( 'Reports & Analytics', 'nvdigital-open-operator-system-oos-pro' ),
				'communication' => __( 'Messaging & Notifications', 'nvdigital-open-operator-system-oos-pro' ),
				'maintenance'   => __( 'Site Maintenance & Cleanup', 'nvdigital-open-operator-system-oos-pro' ),
				'marketing'     => __( 'Marketing Automation', 'nvdigital-open-operator-system-oos-pro' ),
				'business'      => __( 'Business Operations', 'nvdigital-open-operator-system-oos-pro' ),
			);
		}

		// ------------------------------------------------------------------
		// Preset installation
		// ------------------------------------------------------------------

		/**
		 * Install a preset as a live schedule.
		 *
		 * Resolves the preset definition, merges it into the format expected
		 * by {@see WP_MCP_AI_Pro_Schedule_Manager::create_schedule()}, and
		 * creates the schedule entry.
		 *
		 * The optional `$overrides` array allows callers to supply values that
		 * are not part of the static preset definition but are required by the
		 * Schedule Manager at creation time.  Supported keys:
		 *
		 *  - `assistant_id`  (int)   – injected into `assistant_config` for
		 *                               `assistant_run`-type presets.
		 *  - `credentials`   (array) – injected into `broadcast_config` for
		 *                               `channel_broadcast`-type presets.
		 *
		 * @since  1.0.0
		 * @param  string $preset_id The unique preset identifier.
		 * @param  int    $user_id   WordPress user ID performing the install.
		 * @param  array  $overrides Optional runtime values to merge into the
		 *                           schedule data (e.g. assistant_id, credentials).
		 * @return string|\WP_Error  Schedule ID on success, WP_Error on failure.
		 */
		public static function install_preset( $preset_id, $user_id, array $overrides = array() ) {
			$preset = self::get_preset( $preset_id );

			if ( null === $preset ) {
				return new \WP_Error(
					'invalid_preset',
					/* translators: %s: preset identifier */
					sprintf( __( 'Schedule preset "%s" does not exist.', 'nvdigital-open-operator-system-oos-pro' ), sanitize_key( $preset_id ) )
				);
			}

			if ( ! class_exists( 'WP_MCP_AI_Pro_Schedule_Manager' ) ) {
				return new \WP_Error(
					'missing_dependency',
					__( 'The Pro Schedule Manager is not available.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$user_id = absint( $user_id );
			if ( 0 === $user_id ) {
				return new \WP_Error(
					'invalid_user',
					__( 'A valid user ID is required to install a preset.', 'nvdigital-open-operator-system-oos-pro' )
				);
			}

			$schedule_data = self::build_schedule_data( $preset, $overrides );

			return WP_MCP_AI_Pro_Schedule_Manager::create_schedule( $schedule_data, $user_id );
		}

		// ------------------------------------------------------------------
		// Internal helpers
		// ------------------------------------------------------------------

		/**
		 * Convert a preset definition into the data array expected by the
		 * Schedule Manager's create_schedule() method.
		 *
		 * Runtime overrides (supplied by the user at install time) are merged
		 * into the type-specific configuration so that values the preset
		 * intentionally omits (e.g. assistant_id, channel credentials) can be
		 * provided without hard-coding them into the preset definition.
		 *
		 * @since  1.0.0
		 * @param  array $preset    Preset definition.
		 * @param  array $overrides Optional runtime values. Recognised keys:
		 *                          `assistant_id` (int), `credentials` (array).
		 * @return array Schedule data suitable for create_schedule().
		 */
		private static function build_schedule_data( array $preset, array $overrides = array() ) {
			$data = array(
				'name'          => isset( $preset['name'] ) ? $preset['name'] : '',
				'description'   => isset( $preset['description'] ) ? $preset['description'] : '',
				'schedule_type' => isset( $preset['schedule_type'] ) ? $preset['schedule_type'] : 'task',
				'schedule'      => isset( $preset['schedule'] ) ? $preset['schedule'] : 'daily',
				'tags'          => isset( $preset['tags'] ) ? $preset['tags'] : array(),
				'enabled'       => true,
			);

			$schedule_data = isset( $preset['schedule_data'] ) ? $preset['schedule_data'] : array();

			switch ( $data['schedule_type'] ) {
				case 'task':
					if ( isset( $schedule_data['hook'] ) ) {
						$data['hook'] = $schedule_data['hook'];
					}
					break;

				case 'workflow':
					if ( isset( $schedule_data['workflow_steps'] ) ) {
						$data['workflow_steps'] = $schedule_data['workflow_steps'];
					}
					break;

				case 'assistant_run':
					if ( isset( $schedule_data['assistant_config'] ) ) {
						$data['assistant_config'] = $schedule_data['assistant_config'];
					}
					// Merge assistant_id from overrides when the preset omits it.
					if ( ! empty( $overrides['assistant_id'] ) ) {
						if ( ! isset( $data['assistant_config'] ) ) {
							$data['assistant_config'] = array();
						}
						$data['assistant_config']['assistant_id'] = absint( $overrides['assistant_id'] );
					}
					break;

				case 'channel_broadcast':
					if ( isset( $schedule_data['broadcast_config'] ) ) {
						$data['broadcast_config'] = $schedule_data['broadcast_config'];
					}
					// Merge credentials from overrides when the preset omits them.
					if ( ! empty( $overrides['credentials'] ) && is_array( $overrides['credentials'] ) ) {
						if ( ! isset( $data['broadcast_config'] ) ) {
							$data['broadcast_config'] = array();
						}
						$data['broadcast_config']['credentials'] = $overrides['credentials'];
					}
					break;

				case 'workflow_builder':
					if ( isset( $schedule_data['workflow_builder_id'] ) ) {
						$data['workflow_builder_id'] = $schedule_data['workflow_builder_id'];
					}
					break;
			}

			return $data;
		}

		// ------------------------------------------------------------------
		// E-Commerce presets
		// ------------------------------------------------------------------

		/**
		 * Get E-Commerce toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_ecommerce_presets() {
			return array(
				'inventory_check'         => array(
					'name'          => __( 'Inventory Level Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Periodically checks product inventory levels and flags items that are low in stock or out of stock.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ecommerce',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-products',
					'schedule_type' => 'task',
					'schedule'      => 'hourly',
					'tags'          => array( 'ecommerce', 'inventory', 'monitoring' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_ecommerce_inventory_check',
					),
				),
				'daily_sales_report'      => array(
					'name'          => __( 'Daily Sales Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates a comprehensive daily sales summary including revenue, top products, and order volume.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ecommerce',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-bar',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'ecommerce', 'sales', 'reports' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a daily sales report covering total revenue, number of orders, average order value, top-selling products, and comparison with the previous day.',
						),
					),
				),
				'abandoned_cart_followup' => array(
					'name'          => __( 'Abandoned Cart Follow-up', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Identifies abandoned carts and triggers a follow-up workflow to recover lost sales.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ecommerce',
					'category'      => 'marketing',
					'icon'          => 'dashicons-cart',
					'schedule_type' => 'workflow',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'ecommerce', 'cart', 'recovery', 'marketing' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_abandoned_carts',
								'arguments' => array(
									'since' => '30 minutes ago',
								),
								'label'     => __( 'Fetch abandoned carts', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'send_cart_recovery_email',
								'arguments' => array(),
								'label'     => __( 'Send recovery emails', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'price_monitoring'        => array(
					'name'          => __( 'Product Price Monitor', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Monitors product prices for unexpected changes and validates sale pricing is applied correctly.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ecommerce',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-money-alt',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_15_minutes',
					'tags'          => array( 'ecommerce', 'pricing', 'monitoring' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_ecommerce_price_monitor',
					),
				),
				'order_status_broadcast'  => array(
					'name'          => __( 'Order Status Broadcast', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Broadcasts a daily summary of pending, processing, and completed orders to your team channels.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ecommerce',
					'category'      => 'communication',
					'icon'          => 'dashicons-megaphone',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'ecommerce', 'orders', 'broadcast' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Daily order status summary: review pending, processing, and completed orders for today.',
							'channels' => array( 'slack' ),
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Social Media presets
		// ------------------------------------------------------------------

		/**
		 * Get Social Media toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_social_media_presets() {
			return array(
				'daily_content_scheduler' => array(
					'name'          => __( 'Daily Content Scheduler', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Queues the day\'s social media posts across all connected platforms using your content calendar.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'social_media',
					'category'      => 'content',
					'icon'          => 'dashicons-share',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'social', 'content', 'scheduling' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_content_calendar',
								'arguments' => array(
									'date' => 'today',
								),
								'label'     => __( 'Fetch today\'s content calendar', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'schedule_social_posts',
								'arguments' => array(),
								'label'     => __( 'Queue posts to platforms', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'engagement_report'       => array(
					'name'          => __( 'Daily Engagement Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Compiles a summary of likes, shares, comments, and follower growth across social channels.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'social_media',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-line',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'social', 'engagement', 'reports' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a daily social media engagement report including likes, shares, comments, follower growth, and top-performing posts across all connected platforms.',
						),
					),
				),
				'trending_topics_monitor' => array(
					'name'          => __( 'Trending Topics Monitor', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Scans trending topics and hashtags relevant to your industry for timely content opportunities.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'social_media',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-trending',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'social', 'trends', 'monitoring' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_social_trending_monitor',
					),
				),
				'social_analytics_digest' => array(
					'name'          => __( 'Weekly Social Analytics Digest', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Produces a weekly deep-dive into social media performance with actionable recommendations.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'social_media',
					'category'      => 'reporting',
					'icon'          => 'dashicons-analytics',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'social', 'analytics', 'weekly' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Create a weekly social media analytics digest covering reach, engagement rate, audience demographics, best posting times, and strategic recommendations for the coming week.',
						),
					),
				),
				'cross_platform_post'     => array(
					'name'          => __( 'Cross-Platform Post Syndicator', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Publishes new blog posts to all connected social media platforms with optimised captions per channel.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'social_media',
					'category'      => 'content',
					'icon'          => 'dashicons-share-alt',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'social', 'syndication', 'content' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_recent_posts',
								'arguments' => array(
									'since'  => '24 hours ago',
									'status' => 'publish',
								),
								'label'     => __( 'Fetch recently published posts', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'generate_social_captions',
								'arguments' => array(),
								'label'     => __( 'Generate platform-specific captions', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'publish_to_social',
								'arguments' => array(),
								'label'     => __( 'Publish to social platforms', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Analytics presets
		// ------------------------------------------------------------------

		/**
		 * Get Analytics toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_analytics_presets() {
			return array(
				'daily_traffic_report'      => array(
					'name'          => __( 'Daily Traffic Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Summarises daily website traffic including page views, unique visitors, bounce rate, and traffic sources.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'analytics',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-area',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'analytics', 'traffic', 'reports' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a daily website traffic report covering page views, unique visitors, bounce rate, average session duration, and top traffic sources compared to yesterday.',
						),
					),
				),
				'weekly_performance_digest' => array(
					'name'          => __( 'Weekly Performance Digest', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Compiles a week-over-week comparison of key performance indicators and growth trends.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'analytics',
					'category'      => 'reporting',
					'icon'          => 'dashicons-performance',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'analytics', 'performance', 'weekly' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Create a weekly performance digest comparing this week to last week for page views, conversions, revenue, top landing pages, and user engagement metrics.',
						),
					),
				),
				'realtime_alert_monitor'    => array(
					'name'          => __( 'Real-Time Traffic Alert Monitor', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Monitors traffic in near-real-time and fires alerts when unusual spikes or drops are detected.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'analytics',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-warning',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_5_minutes',
					'tags'          => array( 'analytics', 'realtime', 'alerts' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_analytics_realtime_alert',
					),
				),
				'conversion_funnel_report'  => array(
					'name'          => __( 'Conversion Funnel Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Analyses the full conversion funnel from landing page to purchase, highlighting drop-off points.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'analytics',
					'category'      => 'reporting',
					'icon'          => 'dashicons-filter',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'analytics', 'conversion', 'funnel' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Analyse the conversion funnel for the past week. Identify each stage from landing page visit through to completed purchase, calculate conversion rates between stages, and highlight the biggest drop-off points with improvement suggestions.',
						),
					),
				),
				'seo_ranking_check'         => array(
					'name'          => __( 'SEO Ranking Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks search engine ranking positions for tracked keywords and logs changes over time.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'analytics',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-search',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'analytics', 'seo', 'rankings' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_analytics_seo_ranking_check',
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Advanced Analytics presets
		// ------------------------------------------------------------------

		/**
		 * Get Advanced Analytics toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_advanced_analytics_presets() {
			return array(
				'predictive_trend_report' => array(
					'name'          => __( 'Predictive Trend Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Uses historical data to predict upcoming traffic and conversion trends for the next week.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'advanced_analytics',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-line',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'analytics', 'predictions', 'trends' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Analyse historical traffic and conversion data to generate a predictive trend report for the coming week. Include expected traffic volumes, conversion rate forecasts, and confidence intervals.',
						),
					),
				),
				'anomaly_detection_scan'  => array(
					'name'          => __( 'Anomaly Detection Scan', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Scans analytics data for statistical anomalies that may indicate issues or opportunities.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'advanced_analytics',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-visibility',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_15_minutes',
					'tags'          => array( 'analytics', 'anomaly', 'monitoring' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_advanced_analytics_anomaly_scan',
					),
				),
				'cohort_analysis_weekly'  => array(
					'name'          => __( 'Weekly Cohort Analysis', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Segments users into weekly cohorts and analyses retention, engagement, and lifetime value patterns.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'advanced_analytics',
					'category'      => 'reporting',
					'icon'          => 'dashicons-groups',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'analytics', 'cohorts', 'retention' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Perform a weekly cohort analysis. Segment users by their first visit week, then analyse retention rates, repeat engagement, and estimated lifetime value for each cohort over the past 8 weeks.',
						),
					),
				),
				'ab_test_monitor'         => array(
					'name'          => __( 'A/B Test Monitor', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks running A/B tests for statistical significance and alerts when results are conclusive.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'advanced_analytics',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-randomize',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'analytics', 'ab-test', 'experiments' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_advanced_analytics_ab_test_monitor',
					),
				),
				'revenue_forecast'        => array(
					'name'          => __( 'Monthly Revenue Forecast', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Projects monthly revenue based on current run rate, seasonality patterns, and pipeline data.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'advanced_analytics',
					'category'      => 'reporting',
					'icon'          => 'dashicons-money-alt',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'wp_mcp_ai_monthly',
					'tags'          => array( 'analytics', 'revenue', 'forecast' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a monthly revenue forecast. Analyse current month-to-date revenue, compare with previous months, factor in seasonal trends, and project end-of-month revenue with optimistic and conservative scenarios.',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Multilingual presets
		// ------------------------------------------------------------------

		/**
		 * Get Multilingual toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_multilingual_presets() {
			return array(
				'translation_queue_check'    => array(
					'name'          => __( 'Translation Queue Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks for content awaiting translation and prioritises the queue by publication date and traffic.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'multilingual',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-translation',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'multilingual', 'translation', 'queue' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_multilingual_translation_queue_check',
					),
				),
				'language_coverage_report'   => array(
					'name'          => __( 'Language Coverage Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Reports on translation completeness for each configured locale across all content types.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'multilingual',
					'category'      => 'reporting',
					'icon'          => 'dashicons-admin-site-alt3',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'multilingual', 'coverage', 'reports' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a language coverage report. For each configured locale, list the percentage of posts, pages, and custom post types that have been translated, and highlight the highest-priority untranslated content.',
						),
					),
				),
				'translation_memory_sync'    => array(
					'name'          => __( 'Translation Memory Sync', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Synchronises the translation memory database with the latest approved translations.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'multilingual',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-update',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'multilingual', 'translation-memory', 'sync' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_multilingual_tm_sync',
					),
				),
				'locale_content_audit'       => array(
					'name'          => __( 'Locale Content Audit', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Audits localised content for quality issues such as broken formatting, placeholder mismatches, or outdated translations.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'multilingual',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-editor-spellcheck',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'multilingual', 'audit', 'quality' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Audit all localised content for quality issues. Check for broken HTML formatting, mismatched placeholders, translations that are significantly longer or shorter than the source, and content that has not been updated since the source was revised.',
						),
					),
				),
				'untranslated_content_alert' => array(
					'name'          => __( 'Untranslated Content Alert', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends a daily notification listing content published without translations in required locales.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'multilingual',
					'category'      => 'communication',
					'icon'          => 'dashicons-flag',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'multilingual', 'alerts', 'untranslated' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Daily untranslated content alert: the following recently published content is missing translations in one or more required locales.',
							'channels' => array( 'slack' ),
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Video Production presets
		// ------------------------------------------------------------------

		/**
		 * Get Video Production toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_video_production_presets() {
			return array(
				'video_render_queue_check'   => array(
					'name'          => __( 'Video Render Queue Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Monitors the video render queue and alerts when jobs are stalled, failed, or completed.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'video_production',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-video-alt3',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_15_minutes',
					'tags'          => array( 'video', 'render', 'queue', 'monitoring' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_video_render_queue_check',
					),
				),
				'daily_upload_scheduler'     => array(
					'name'          => __( 'Daily Video Upload Scheduler', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Processes queued videos and uploads them to configured video hosting platforms on a daily schedule.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'video_production',
					'category'      => 'content',
					'icon'          => 'dashicons-upload',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'video', 'upload', 'scheduling' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_queued_videos',
								'arguments' => array(
									'status' => 'ready',
								),
								'label'     => __( 'Fetch videos ready for upload', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'upload_video_batch',
								'arguments' => array(),
								'label'     => __( 'Upload to hosting platforms', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'video_analytics_report'     => array(
					'name'          => __( 'Weekly Video Analytics Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Compiles a weekly report on video views, watch time, engagement, and audience retention metrics.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'video_production',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-pie',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'video', 'analytics', 'reports' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a weekly video analytics report covering total views, average watch time, audience retention curves, engagement rate, and top-performing videos with recommendations for content improvement.',
						),
					),
				),
				'thumbnail_generation_batch' => array(
					'name'          => __( 'Thumbnail Generation Batch', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates optimised thumbnails for videos that are missing custom thumbnail images.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'video_production',
					'category'      => 'content',
					'icon'          => 'dashicons-format-image',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'video', 'thumbnails', 'batch' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_videos_without_thumbnails',
								'arguments' => array(),
								'label'     => __( 'Find videos missing thumbnails', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'generate_video_thumbnails',
								'arguments' => array(
									'count' => 3,
								),
								'label'     => __( 'Generate thumbnail candidates', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'video_transcription_batch'  => array(
					'name'          => __( 'Video Transcription Batch', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Transcribes videos that lack captions or transcripts, improving accessibility and SEO.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'video_production',
					'category'      => 'content',
					'icon'          => 'dashicons-text',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'video', 'transcription', 'accessibility' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_videos_without_transcripts',
								'arguments' => array(),
								'label'     => __( 'Find videos missing transcripts', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'transcribe_video',
								'arguments' => array(),
								'label'     => __( 'Transcribe and attach captions', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Financial Planner presets
		// ------------------------------------------------------------------

		/**
		 * Get Financial Planner toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_financial_planner_presets() {
			return array(
				'daily_market_brief'           => array(
					'name'          => __( 'Daily Market Brief', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates a morning market brief covering major indices, sector performance, and notable market news.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'financial_planner',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-bar',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'financial', 'market', 'daily-brief' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a morning market brief covering major stock indices, bond yields, commodity prices, notable sector performance, and key financial news for today.',
						),
					),
				),
				'portfolio_performance_report' => array(
					'name'          => __( 'Weekly Portfolio Performance Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Analyses portfolio holdings and returns over the past week with benchmark comparisons.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'financial_planner',
					'category'      => 'reporting',
					'icon'          => 'dashicons-portfolio',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'financial', 'portfolio', 'performance' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a weekly portfolio performance report. Include total return, asset allocation breakdown, top and bottom performers, benchmark comparison, and rebalancing recommendations if allocations have drifted.',
						),
					),
				),
				'expense_categorization'       => array(
					'name'          => __( 'Daily Expense Categorisation', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Categorises new financial transactions and reconciles them against budget allocations.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'financial_planner',
					'category'      => 'business',
					'icon'          => 'dashicons-money-alt',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'financial', 'expenses', 'budgeting' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_uncategorised_transactions',
								'arguments' => array(),
								'label'     => __( 'Fetch uncategorised transactions', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'categorise_transactions',
								'arguments' => array(),
								'label'     => __( 'Auto-categorise against budget', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'tax_deadline_reminder'        => array(
					'name'          => __( 'Tax Deadline Reminder', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Broadcasts upcoming tax filing and payment deadlines to relevant team channels.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'financial_planner',
					'category'      => 'communication',
					'icon'          => 'dashicons-calendar-alt',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'financial', 'tax', 'deadlines', 'reminders' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Tax deadline reminder: check for upcoming tax filing and payment deadlines within the next 30 days.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'investment_rebalance_alert'   => array(
					'name'          => __( 'Investment Rebalance Alert', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Alerts the team when portfolio allocations drift beyond defined thresholds and rebalancing is needed.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'financial_planner',
					'category'      => 'communication',
					'icon'          => 'dashicons-image-rotate',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'weekly',
					'tags'          => array( 'financial', 'investment', 'rebalance' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Investment rebalance check: portfolio allocations have been reviewed. Any drifts beyond target thresholds are flagged for rebalancing action.',
							'channels' => array( 'slack' ),
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// DJ Management presets
		// ------------------------------------------------------------------

		/**
		 * Get DJ Management toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_dj_management_presets() {
			return array(
				'gig_reminder_broadcast'      => array(
					'name'          => __( 'Gig Reminder Broadcast', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends daily reminders for upcoming gigs including venue details, load-in times, and set requirements.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'dj_management',
					'category'      => 'communication',
					'icon'          => 'dashicons-microphone',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'dj', 'gigs', 'reminders' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Daily gig reminder: here are your upcoming gigs for the next 48 hours with venue details, load-in times, and set length requirements.',
							'channels' => array( 'slack', 'telegram' ),
						),
					),
				),
				'playlist_rotation_update'    => array(
					'name'          => __( 'Playlist Rotation Update', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Rotates and refreshes playlists weekly based on trending tracks, audience preferences, and venue style.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'dj_management',
					'category'      => 'content',
					'icon'          => 'dashicons-playlist-audio',
					'schedule_type' => 'workflow',
					'schedule'      => 'weekly',
					'tags'          => array( 'dj', 'playlists', 'music' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_trending_tracks',
								'arguments' => array(),
								'label'     => __( 'Fetch trending tracks', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'update_playlist_rotation',
								'arguments' => array(),
								'label'     => __( 'Update playlist rotation', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'venue_availability_check'    => array(
					'name'          => __( 'Venue Availability Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks partner venue availability for upcoming booking windows and flags open slots.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'dj_management',
					'category'      => 'business',
					'icon'          => 'dashicons-building',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'dj', 'venues', 'availability' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_dj_venue_availability_check',
					),
				),
				'equipment_maintenance_alert' => array(
					'name'          => __( 'Equipment Maintenance Alert', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Alerts the team when DJ equipment is due for maintenance or calibration based on usage hours.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'dj_management',
					'category'      => 'communication',
					'icon'          => 'dashicons-admin-tools',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'weekly',
					'tags'          => array( 'dj', 'equipment', 'maintenance' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Weekly equipment maintenance check: review equipment usage hours and flag any gear due for maintenance, calibration, or replacement.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'setlist_generation'          => array(
					'name'          => __( 'AI Setlist Generation', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates suggested setlists for upcoming gigs based on venue type, audience demographics, and event theme.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'dj_management',
					'category'      => 'content',
					'icon'          => 'dashicons-format-audio',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'dj', 'setlist', 'ai' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate suggested setlists for upcoming gigs this week. Consider the venue type, expected audience demographics, event theme, and time slot. Include warm-up, peak, and cooldown segments with BPM progression.',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Image Production presets
		// ------------------------------------------------------------------

		/**
		 * Get Image Production toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_image_production_presets() {
			return array(
				'batch_image_optimization'  => array(
					'name'          => __( 'Batch Image Optimisation', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Optimises uncompressed images in the media library by applying lossless compression and WebP conversion.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'image_production',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-images-alt2',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'images', 'optimisation', 'performance' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_unoptimised_images',
								'arguments' => array(
									'limit' => 50,
								),
								'label'     => __( 'Find unoptimised images', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'optimise_images_batch',
								'arguments' => array(
									'format' => 'webp',
								),
								'label'     => __( 'Compress and convert to WebP', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'daily_media_library_audit' => array(
					'name'          => __( 'Daily Media Library Audit', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Audits the media library for oversized images, missing metadata, and duplicate files.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'image_production',
					'category'      => 'reporting',
					'icon'          => 'dashicons-format-gallery',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'images', 'media-library', 'audit' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Audit the WordPress media library. Report on oversized images exceeding 2 MB, images missing alt text or title metadata, potential duplicates, and overall storage usage with cleanup recommendations.',
						),
					),
				),
				'image_alt_text_generation' => array(
					'name'          => __( 'Image Alt Text Generation', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Uses AI to generate descriptive alt text for images that are missing accessibility attributes.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'image_production',
					'category'      => 'content',
					'icon'          => 'dashicons-edit',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'images', 'alt-text', 'accessibility' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_images_without_alt',
								'arguments' => array(
									'limit' => 25,
								),
								'label'     => __( 'Find images without alt text', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'generate_image_alt_text',
								'arguments' => array(),
								'label'     => __( 'Generate and save alt text', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'watermark_batch_process'   => array(
					'name'          => __( 'Watermark Batch Process', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Applies configured watermarks to newly uploaded images that match the watermark criteria.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'image_production',
					'category'      => 'content',
					'icon'          => 'dashicons-lock',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'images', 'watermark', 'batch' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_unwatermarked_images',
								'arguments' => array(),
								'label'     => __( 'Find images needing watermarks', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'apply_watermark_batch',
								'arguments' => array(),
								'label'     => __( 'Apply watermarks', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'image_cdn_sync'            => array(
					'name'          => __( 'Image CDN Sync', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Synchronises newly uploaded or modified images with the configured CDN for faster global delivery.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'image_production',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-cloud-upload',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'images', 'cdn', 'sync' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_image_cdn_sync',
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// AI Tool Builder presets
		// ------------------------------------------------------------------

		/**
		 * Get AI Tool Builder toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_ai_tool_builder_presets() {
			return array(
				'tool_health_check'          => array(
					'name'          => __( 'Tool Health Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Pings every registered AI tool to verify availability, response time, and error rates.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ai_tool_builder',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-heart',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_15_minutes',
					'tags'          => array( 'tools', 'health', 'monitoring' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_tool_builder_health_check',
					),
				),
				'tool_usage_report'          => array(
					'name'          => __( 'Weekly Tool Usage Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Reports on tool invocation counts, success rates, average execution time, and most active users.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ai_tool_builder',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-bar',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'tools', 'usage', 'reports' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a weekly AI tool usage report. Include total invocations per tool, success and failure rates, average execution time, most active users, and recommendations for tools that may need attention or deprecation.',
						),
					),
				),
				'tool_schema_validation'     => array(
					'name'          => __( 'Tool Schema Validation', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Validates all registered tool schemas against the MCP specification to catch definition errors.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ai_tool_builder',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-yes-alt',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'tools', 'schema', 'validation' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_tool_builder_schema_validation',
					),
				),
				'deprecated_tool_scan'       => array(
					'name'          => __( 'Deprecated Tool Scan', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Identifies tools marked as deprecated that are still being invoked and recommends migration paths.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ai_tool_builder',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-dismiss',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'tools', 'deprecated', 'cleanup' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Scan for deprecated AI tools that are still receiving invocations. List each deprecated tool, its recent usage count, the recommended replacement tool, and a migration plan for each.',
						),
					),
				),
				'tool_performance_benchmark' => array(
					'name'          => __( 'Tool Performance Benchmark', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Benchmarks tool execution times and resource consumption to identify performance bottlenecks.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'ai_tool_builder',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-performance',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'tools', 'performance', 'benchmark' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_tool_builder_performance_benchmark',
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Architect Agent presets
		// ------------------------------------------------------------------

		/**
		 * Get Architect Agent toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_architect_agent_presets() {
			return array(
				'code_quality_scan'             => array(
					'name'          => __( 'Code Quality Scan', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Runs automated code quality checks including linting, complexity analysis, and coding standards compliance.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architect_agent',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-editor-code',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'code', 'quality', 'linting' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_architect_code_quality_scan',
					),
				),
				'dependency_update_check'       => array(
					'name'          => __( 'Dependency Update Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks Composer and npm dependencies for available updates, prioritising security patches.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architect_agent',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-update',
					'schedule_type' => 'task',
					'schedule'      => 'weekly',
					'tags'          => array( 'dependencies', 'updates', 'security' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_architect_dependency_update_check',
					),
				),
				'security_vulnerability_scan'   => array(
					'name'          => __( 'Security Vulnerability Scan', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Scans the codebase and dependencies for known security vulnerabilities and generates a risk report.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architect_agent',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-shield',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'security', 'vulnerabilities', 'scanning' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_architect_security_scan',
					),
				),
				'api_endpoint_monitor'          => array(
					'name'          => __( 'API Endpoint Monitor', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Monitors REST API endpoints for availability, response time, and error rates.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architect_agent',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-rest-api',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_15_minutes',
					'tags'          => array( 'api', 'endpoints', 'uptime' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_architect_api_endpoint_monitor',
					),
				),
				'documentation_freshness_check' => array(
					'name'          => __( 'Documentation Freshness Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Reviews documentation for staleness by comparing last-updated dates against related code changes.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architect_agent',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-media-document',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'documentation', 'freshness', 'review' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Review all documentation files for freshness. Compare each document\'s last-updated date against recent code changes in related files. Flag any documentation that may be outdated and list the specific code changes that may require documentation updates.',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Architectural Design presets
		// ------------------------------------------------------------------

		/**
		 * Get Architectural Design toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_architectural_design_presets() {
			return array(
				'project_milestone_check'  => array(
					'name'          => __( 'Project Milestone Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Reviews active design projects against their milestones and flags approaching or overdue deadlines.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architectural_design',
					'category'      => 'business',
					'icon'          => 'dashicons-flag',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'architecture', 'milestones', 'deadlines' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_arch_design_milestone_check',
					),
				),
				'material_price_update'    => array(
					'name'          => __( 'Material Price Update', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Fetches latest pricing for tracked building materials and updates project cost estimates.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architectural_design',
					'category'      => 'business',
					'icon'          => 'dashicons-money-alt',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'architecture', 'materials', 'pricing' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_arch_design_material_price_update',
					),
				),
				'design_revision_reminder' => array(
					'name'          => __( 'Design Revision Reminder', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Notifies team members about pending design revisions that need review or client approval.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architectural_design',
					'category'      => 'communication',
					'icon'          => 'dashicons-edit',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'architecture', 'revisions', 'reminders' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Design revision reminder: the following design revisions are pending review or client approval. Please address them at your earliest convenience.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'permit_deadline_alert'    => array(
					'name'          => __( 'Permit Deadline Alert', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Alerts the team about upcoming building permit submission deadlines and required documentation.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architectural_design',
					'category'      => 'communication',
					'icon'          => 'dashicons-clipboard',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'architecture', 'permits', 'deadlines' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Permit deadline alert: review upcoming building permit deadlines within the next 14 days and ensure all required documentation is prepared.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'client_progress_report'   => array(
					'name'          => __( 'Client Progress Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates a client-ready progress report summarising design phase completion, next steps, and timeline.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'architectural_design',
					'category'      => 'reporting',
					'icon'          => 'dashicons-businessman',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'architecture', 'clients', 'reports' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a client-facing progress report for all active architectural design projects. Include current phase completion percentage, completed milestones, upcoming deliverables, timeline adherence, and any risks or blockers.',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Site Creator presets
		// ------------------------------------------------------------------

		/**
		 * Get Site Creator toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_site_creator_presets() {
			return array(
				'site_health_monitor'     => array(
					'name'          => __( 'Site Health Monitor', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Runs WordPress Site Health checks and monitors critical site metrics at regular intervals.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'site_creator',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-heart',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_15_minutes',
					'tags'          => array( 'site', 'health', 'monitoring' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_site_creator_health_monitor',
					),
				),
				'plugin_update_check'     => array(
					'name'          => __( 'Plugin Update Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks for available plugin and theme updates, prioritising those with security fixes.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'site_creator',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-update',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'site', 'plugins', 'updates' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_site_creator_plugin_update_check',
					),
				),
				'broken_link_scan'        => array(
					'name'          => __( 'Broken Link Scan', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Crawls the site for broken internal and external links and generates a report with fix suggestions.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'site_creator',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-admin-links',
					'schedule_type' => 'task',
					'schedule'      => 'weekly',
					'tags'          => array( 'site', 'links', 'seo' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_site_creator_broken_link_scan',
					),
				),
				'performance_benchmark'   => array(
					'name'          => __( 'Performance Benchmark', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Measures page load times, TTFB, and Core Web Vitals across key pages and tracks changes over time.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'site_creator',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-performance',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'site', 'performance', 'speed' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_site_creator_performance_benchmark',
					),
				),
				'ssl_certificate_monitor' => array(
					'name'          => __( 'SSL Certificate Monitor', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Monitors SSL certificate expiry dates and alerts well in advance of expiration.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'site_creator',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-lock',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'site', 'ssl', 'security' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_site_creator_ssl_monitor',
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Document Generation presets
		// ------------------------------------------------------------------

		/**
		 * Get Document Generation toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_document_generation_presets() {
			return array(
				'daily_report_generation'    => array(
					'name'          => __( 'Daily Report Generation', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates daily operational reports from configured data sources and saves them as downloadable documents.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'reporting',
					'icon'          => 'dashicons-media-document',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'documents', 'reports', 'generation' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate the daily operational report. Compile data from all configured sources, format it according to the standard report template, and save the completed document for download.',
						),
					),
				),
				'invoice_batch_process'      => array(
					'name'          => __( 'Invoice Batch Process', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates and sends invoices for completed orders or services that have not yet been invoiced.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'business',
					'icon'          => 'dashicons-money-alt',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'documents', 'invoices', 'billing' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_uninvoiced_orders',
								'arguments' => array(),
								'label'     => __( 'Fetch uninvoiced orders', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'generate_invoice_batch',
								'arguments' => array(),
								'label'     => __( 'Generate and send invoices', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'contract_renewal_reminder'  => array(
					'name'          => __( 'Contract Renewal Reminder', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends daily notifications for contracts approaching their renewal or expiry date.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'communication',
					'icon'          => 'dashicons-media-text',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'documents', 'contracts', 'renewals' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Contract renewal reminder: the following contracts are approaching renewal or expiry within the next 30 days. Please review and take action.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'document_archive_cleanup'   => array(
					'name'          => __( 'Document Archive Cleanup', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Archives old documents past their retention period and cleans up temporary or draft documents.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-archive',
					'schedule_type' => 'workflow',
					'schedule'      => 'weekly',
					'tags'          => array( 'documents', 'archive', 'cleanup' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_expired_documents',
								'arguments' => array(
									'retention_days' => 90,
								),
								'label'     => __( 'Find documents past retention', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'archive_documents',
								'arguments' => array(),
								'label'     => __( 'Archive and clean up', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'template_update_check'      => array(
					'name'          => __( 'Template Update Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Validates document templates are current and flags any that reference outdated data fields or branding.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-layout',
					'schedule_type' => 'task',
					'schedule'      => 'weekly',
					'tags'          => array( 'documents', 'templates', 'validation' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_docgen_template_update_check',
					),
				),

				// -- Document Management & Sharing (ISO 9001 / GDPR best-practice patterns).

				'new_document_notification'  => array(
					'name'          => __( 'New Document Notification', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Monitors for newly created or uploaded documents and sends role-based notifications to relevant team members. Follows document control best practices for timely awareness and review.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'communication',
					'icon'          => 'dashicons-media-document',
					'schedule_type' => 'workflow',
					'schedule'      => 'hourly',
					'tags'          => array( 'documents', 'notifications', 'new', 'sharing' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'search_attachments',
								'arguments' => array(
									'date_query' => 'last_hour',
									'orderby'    => 'date',
									'order'      => 'DESC',
								),
								'label'     => __( 'Find documents added in the last hour', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'send_group_email',
								'arguments' => array(
									'subject' => 'New documents added — review required',
								),
								'label'     => __( 'Notify team of new documents', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'document_sharing_audit'     => array(
					'name'          => __( 'Document Sharing Audit', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Reviews document access and sharing activity to ensure compliance with data governance policies. Identifies documents shared externally or with unexpected recipients for security review.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-lock',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'documents', 'sharing', 'audit', 'security' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Perform a weekly document sharing audit. List all documents shared or made public in the past 7 days. Identify any files shared with external users or outside approved distribution groups. Flag documents lacking proper access controls or missing classification metadata. Provide a summary with recommended corrective actions for each finding.',
						),
					),
				),
				'document_version_review'    => array(
					'name'          => __( 'Document Version Review', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks for outdated document versions still in active use and identifies documents with pending draft revisions that have not been published. Supports version control best practices.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-backup',
					'schedule_type' => 'workflow',
					'schedule'      => 'weekly',
					'tags'          => array( 'documents', 'versions', 'review', 'compliance' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'track_document_version',
								'arguments' => array(
									'action' => 'list_outdated',
								),
								'label'     => __( 'Find documents with outdated versions in use', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'validate_document_checklist',
								'arguments' => array(),
								'label'     => __( 'Validate document completeness checklist', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'document_approval_reminder' => array(
					'name'          => __( 'Document Approval Reminder', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends daily reminders for documents awaiting approval or review. Prevents bottlenecks in document workflows by alerting approvers of pending items and upcoming deadlines.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'communication',
					'icon'          => 'dashicons-yes-alt',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'documents', 'approval', 'reminders', 'workflow' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Document approval reminder: the following documents are awaiting review or approval. Please action pending items to avoid workflow delays.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'document_compliance_check'  => array(
					'name'          => __( 'Document Compliance Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Validates documents against retention policies and regulatory requirements. Flags expired documents, missing mandatory metadata, and items approaching retention deadlines for proactive compliance management.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'document_generation',
					'category'      => 'business',
					'icon'          => 'dashicons-shield',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'documents', 'compliance', 'retention', 'regulatory' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_docgen_compliance_check',
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// CRM presets
		// ------------------------------------------------------------------

		/**
		 * Get CRM toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_crm_presets() {
			return array(
				'lead_followup_reminder'      => array(
					'name'          => __( 'Lead Follow-up Reminder', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends daily reminders for leads that are due for follow-up based on their pipeline stage and last contact date.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'communication',
					'icon'          => 'dashicons-phone',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'crm', 'leads', 'followup' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Lead follow-up reminder: the following leads are due for contact today based on their pipeline stage and last interaction date.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'contact_engagement_score'    => array(
					'name'          => __( 'Contact Engagement Scoring', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Recalculates engagement scores for all contacts based on recent interactions, email opens, and site visits.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'business',
					'icon'          => 'dashicons-star-filled',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'crm', 'engagement', 'scoring' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_contact_interactions',
								'arguments' => array(
									'since' => '24 hours ago',
								),
								'label'     => __( 'Fetch recent interactions', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'recalculate_engagement_scores',
								'arguments' => array(),
								'label'     => __( 'Recalculate engagement scores', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'pipeline_status_report'      => array(
					'name'          => __( 'Daily Pipeline Status Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates a daily snapshot of the sales pipeline showing deals by stage, value, and probability.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-bar',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'crm', 'pipeline', 'sales' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a daily sales pipeline report. Show deals grouped by stage with total value, win probability, expected close dates, and highlight deals that have been stagnant for more than 7 days.',
						),
					),
				),
				'customer_birthday_alerts'    => array(
					'name'          => __( 'Customer Birthday Alerts', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends daily alerts for customer birthdays coming up in the next 7 days for personalised outreach.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'communication',
					'icon'          => 'dashicons-buddicons-friends',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'crm', 'birthdays', 'engagement' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Customer birthday alert: the following customers have birthdays in the next 7 days. Consider sending personalised greetings or offers.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'crm_data_cleanup'            => array(
					'name'          => __( 'CRM Data Cleanup', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Identifies and cleans duplicate contacts, invalid emails, and stale records in the CRM database.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-database',
					'schedule_type' => 'workflow',
					'schedule'      => 'weekly',
					'tags'          => array( 'crm', 'data', 'cleanup' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'scan_duplicate_contacts',
								'arguments' => array(),
								'label'     => __( 'Scan for duplicate contacts', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'validate_contact_data',
								'arguments' => array(),
								'label'     => __( 'Validate emails and phone numbers', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'archive_stale_contacts',
								'arguments' => array(
									'inactive_days' => 365,
								),
								'label'     => __( 'Archive stale contacts', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),

				// -- CRM Email Correspondence (industry-standard HubSpot / Salesforce patterns).

				'email_correspondence_audit'  => array(
					'name'          => __( 'Email Correspondence Audit', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Searches CRM contacts for customer emails that need follow-up, categorises correspondence by type (support, sales, escalated), and flags overdue responses following enterprise CRM standards.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-email-alt',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'crm', 'email', 'correspondence', 'followup' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'crm_email_search_correspondence',
								'arguments' => array(
									'action'              => 'search',
									'correspondence_type' => 'needs_followup',
									'category'            => 'all',
									'days_since_contact'  => 3,
								),
								'label'     => __( 'Find contacts needing email follow-up', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'crm_email_search_correspondence',
								'arguments' => array(
									'action'              => 'search',
									'correspondence_type' => 'overdue',
									'category'            => 'all',
								),
								'label'     => __( 'Identify overdue correspondence', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'email_sla_breach_monitor'    => array(
					'name'          => __( 'Email SLA Breach Monitor', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Monitors customer email response times and alerts when SLA thresholds are breached. Checks for escalated or support emails awaiting reply beyond the configured window.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-warning',
					'schedule_type' => 'workflow',
					'schedule'      => 'hourly',
					'tags'          => array( 'crm', 'email', 'sla', 'monitoring' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'crm_email_search_correspondence',
								'arguments' => array(
									'action'          => 'search',
									'sla_breach_only' => true,
									'category'        => 'support',
								),
								'label'     => __( 'Check for SLA-breached support emails', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'crm_email_search_correspondence',
								'arguments' => array(
									'action'          => 'search',
									'sla_breach_only' => true,
									'category'        => 'escalated',
								),
								'label'     => __( 'Check for SLA-breached escalations', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'lead_nurture_email_digest'   => array(
					'name'          => __( 'Lead Nurture Email Digest', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates a daily digest of new leads from email inquiries and scores them for sales readiness using industry-standard lead qualification criteria (demographic, firmographic, behavioural signals).', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'reporting',
					'icon'          => 'dashicons-admin-users',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'crm', 'email', 'leads', 'nurture', 'scoring' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Search for new email leads received in the last 24 hours using crm_email_search_leads with status "new_inquiry". Score each lead for sales readiness based on demographic, firmographic, and behavioural signals. Generate a prioritised digest showing lead name, email, score, recommended action, and suggested follow-up timeline.',
						),
					),
				),
				'customer_reengagement_check' => array(
					'name'          => __( 'Customer Re-engagement Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Identifies inactive customers who have not engaged via email in 30+ days and triggers re-engagement outreach following multi-touch CRM best practices.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'marketing',
					'icon'          => 'dashicons-megaphone',
					'schedule_type' => 'workflow',
					'schedule'      => 'weekly',
					'tags'          => array( 'crm', 'email', 'reengagement', 'marketing' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'crm_email_search_correspondence',
								'arguments' => array(
									'action'              => 'search',
									'correspondence_type' => 'never_contacted',
									'days_since_contact'  => 30,
								),
								'label'     => __( 'Find inactive customers (30+ days)', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'manage_crm_contact',
								'arguments' => array(
									'action' => 'list',
									'tag'    => 'needs-reengagement',
								),
								'label'     => __( 'Tag contacts for re-engagement', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'email_deliverability_report' => array(
					'name'          => __( 'Email Deliverability Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Weekly analysis of email deliverability metrics including bounce rates, open rates, and spam complaints, with actionable recommendations to maintain sender reputation.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'crm',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-area',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'crm', 'email', 'deliverability', 'analytics' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a weekly email deliverability report. Analyse bounce rates, open rates, click-through rates, spam complaints, and unsubscribe trends. Compare against industry benchmarks (20-25% open rate, <2% bounce rate, <0.1% spam complaint rate). Identify contacts with repeated bounces for list hygiene. Provide actionable recommendations to improve sender reputation and deliverability.',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Regulatory Registration presets
		// ------------------------------------------------------------------

		/**
		 * Get Regulatory Registration toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_regulatory_registration_presets() {
			return array(
				'compliance_deadline_check'  => array(
					'name'          => __( 'Compliance Deadline Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks for upcoming regulatory compliance deadlines and ensures all required submissions are on track.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'regulatory_registration',
					'category'      => 'business',
					'icon'          => 'dashicons-clipboard',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'regulatory', 'compliance', 'deadlines' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_regulatory_compliance_deadline_check',
					),
				),
				'registration_renewal_alert' => array(
					'name'          => __( 'Registration Renewal Alert', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Alerts the team about business registrations, licences, and certifications approaching their renewal date.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'regulatory_registration',
					'category'      => 'communication',
					'icon'          => 'dashicons-warning',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'regulatory', 'registration', 'renewals' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Registration renewal alert: the following registrations, licences, or certifications are approaching renewal within the next 60 days.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'audit_log_review'           => array(
					'name'          => __( 'Weekly Audit Log Review', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Reviews system audit logs for compliance-relevant activities and generates a summary for the compliance team.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'regulatory_registration',
					'category'      => 'reporting',
					'icon'          => 'dashicons-list-view',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'regulatory', 'audit', 'logs' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Review the system audit logs from the past week. Identify any compliance-relevant activities including data access, permission changes, export operations, and user account modifications. Summarise findings and flag any anomalies.',
						),
					),
				),
				'policy_update_notification' => array(
					'name'          => __( 'Policy Update Notification', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Notifies stakeholders when internal policies or compliance documents are updated or due for review.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'regulatory_registration',
					'category'      => 'communication',
					'icon'          => 'dashicons-media-text',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'weekly',
					'tags'          => array( 'regulatory', 'policies', 'notifications' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Policy update notification: review internal policies that have been updated this week or are due for their scheduled review.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'regulatory_change_monitor'  => array(
					'name'          => __( 'Regulatory Change Monitor', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Monitors for changes in relevant regulations and standards that may affect business operations.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'regulatory_registration',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-visibility',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'regulatory', 'changes', 'monitoring' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_regulatory_change_monitor',
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Chat Channels presets
		// ------------------------------------------------------------------

		/**
		 * Get Chat Channels toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_chat_channels_presets() {
			return array(
				'daily_standup_reminder'      => array(
					'name'          => __( 'Daily Standup Reminder', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends a daily standup reminder prompting team members to share their status updates.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'chat_channels',
					'category'      => 'communication',
					'icon'          => 'dashicons-groups',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'chat', 'standup', 'team' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Good morning, team! Time for the daily standup. Please share: 1) What you completed yesterday, 2) What you are working on today, 3) Any blockers.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'channel_activity_digest'     => array(
					'name'          => __( 'Channel Activity Digest', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Compiles a daily digest of activity across all chat channels with key highlights and action items.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'chat_channels',
					'category'      => 'reporting',
					'icon'          => 'dashicons-format-chat',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'chat', 'activity', 'digest' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a daily digest of chat channel activity. Summarise the key discussions, decisions made, action items identified, and unresolved questions across all active channels.',
						),
					),
				),
				'welcome_message_scheduler'   => array(
					'name'          => __( 'Welcome Message Scheduler', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks for newly joined channel members and sends personalised welcome messages with onboarding links.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'chat_channels',
					'category'      => 'communication',
					'icon'          => 'dashicons-admin-users',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'chat', 'welcome', 'onboarding' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_chat_welcome_message_scheduler',
					),
				),
				'support_queue_alert'         => array(
					'name'          => __( 'Support Queue Alert', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Monitors the support queue and broadcasts alerts when response times exceed defined SLA thresholds.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'chat_channels',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-sos',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'wp_mcp_ai_every_15_minutes',
					'tags'          => array( 'chat', 'support', 'sla' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Support queue alert: there are unresolved support requests approaching or exceeding SLA response time thresholds. Immediate attention required.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'team_announcement_broadcast' => array(
					'name'          => __( 'Weekly Team Announcement', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Broadcasts a weekly team-wide announcement covering company updates, wins, and upcoming events.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'chat_channels',
					'category'      => 'communication',
					'icon'          => 'dashicons-megaphone',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'weekly',
					'tags'          => array( 'chat', 'announcements', 'team' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Weekly team update: here is a summary of this week\'s highlights, upcoming events, and important announcements for the team.',
							'channels' => array( 'slack', 'discord' ),
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Media presets
		// ------------------------------------------------------------------

		/**
		 * Get Media toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_media_presets() {
			return array(
				'media_library_cleanup'     => array(
					'name'          => __( 'Media Library Cleanup', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Removes orphaned media files, clears broken attachment records, and reclaims storage space.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'media',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-trash',
					'schedule_type' => 'workflow',
					'schedule'      => 'weekly',
					'tags'          => array( 'media', 'cleanup', 'storage' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'scan_orphaned_media',
								'arguments' => array(),
								'label'     => __( 'Scan for orphaned media', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'cleanup_orphaned_media',
								'arguments' => array(
									'dry_run' => false,
								),
								'label'     => __( 'Remove orphaned files', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'unused_media_scan'         => array(
					'name'          => __( 'Unused Media Scan', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Identifies media files that are not referenced in any post, page, or widget content.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'media',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-search',
					'schedule_type' => 'task',
					'schedule'      => 'weekly',
					'tags'          => array( 'media', 'unused', 'audit' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_media_unused_scan',
					),
				),
				'media_optimization_report' => array(
					'name'          => __( 'Weekly Media Optimisation Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Reports on media library health including total storage, compression savings, and files needing optimisation.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'media',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-pie',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'media', 'optimisation', 'reports' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a weekly media optimisation report. Include total media library size, number of files by type, compression savings achieved, files still needing optimisation, and recommendations for reducing storage usage.',
						),
					),
				),
				'media_backup_check'        => array(
					'name'          => __( 'Media Backup Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Verifies that all media files are included in the latest backup and flags any files missing from backup sets.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'media',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-cloud-saved',
					'schedule_type' => 'task',
					'schedule'      => 'daily',
					'tags'          => array( 'media', 'backup', 'verification' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_media_backup_check',
					),
				),
				'media_usage_audit'         => array(
					'name'          => __( 'Monthly Media Usage Audit', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Comprehensive monthly audit of media usage patterns, storage growth trends, and bandwidth consumption.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'media',
					'category'      => 'reporting',
					'icon'          => 'dashicons-analytics',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'wp_mcp_ai_monthly',
					'tags'          => array( 'media', 'audit', 'usage' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Perform a comprehensive monthly media usage audit. Analyse storage growth trends, most-accessed media files, bandwidth consumption by file type, upload patterns, and provide recommendations for media management improvements.',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Calendar Booking presets
		// ------------------------------------------------------------------

		/**
		 * Get Calendar Booking toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_calendar_booking_presets() {
			return array(
				'daily_appointment_reminder' => array(
					'name'          => __( 'Daily Appointment Reminder', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends daily reminders for upcoming appointments including time, participant details, and meeting links.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'calendar_booking',
					'category'      => 'communication',
					'icon'          => 'dashicons-calendar-alt',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'calendar', 'appointments', 'reminders' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Daily appointment reminder: here are your scheduled appointments for today with times, participants, and meeting links.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'availability_sync'          => array(
					'name'          => __( 'Availability Sync', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Synchronises availability across connected calendars to prevent double bookings and conflicts.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'calendar_booking',
					'category'      => 'maintenance',
					'icon'          => 'dashicons-update',
					'schedule_type' => 'task',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'calendar', 'availability', 'sync' ),
					'schedule_data' => array(
						'hook' => 'wp_mcp_ai_calendar_availability_sync',
					),
				),
				'no_show_followup'           => array(
					'name'          => __( 'No-Show Follow-up', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Identifies no-show appointments and triggers a follow-up workflow to reschedule or collect feedback.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'calendar_booking',
					'category'      => 'business',
					'icon'          => 'dashicons-dismiss',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'calendar', 'no-show', 'followup' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_no_show_appointments',
								'arguments' => array(
									'since' => '24 hours ago',
								),
								'label'     => __( 'Identify no-show appointments', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'send_reschedule_invitation',
								'arguments' => array(),
								'label'     => __( 'Send reschedule invitations', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'booking_confirmation_batch' => array(
					'name'          => __( 'Booking Confirmation Batch', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Processes new bookings and sends confirmation messages with calendar invites and preparation details.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'calendar_booking',
					'category'      => 'business',
					'icon'          => 'dashicons-yes',
					'schedule_type' => 'workflow',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'calendar', 'bookings', 'confirmations' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_unconfirmed_bookings',
								'arguments' => array(),
								'label'     => __( 'Fetch unconfirmed bookings', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'send_booking_confirmations',
								'arguments' => array(),
								'label'     => __( 'Send confirmation messages', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'weekly_schedule_digest'     => array(
					'name'          => __( 'Weekly Schedule Digest', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates a weekly overview of the upcoming schedule with booking statistics and capacity analysis.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'calendar_booking',
					'category'      => 'reporting',
					'icon'          => 'dashicons-schedule',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'calendar', 'schedule', 'digest' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a weekly schedule digest for the coming week. Include total appointments by day, available slots, booking utilisation rate, most popular time slots, and any scheduling conflicts that need attention.',
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Health & Wellness presets
		// ------------------------------------------------------------------

		/**
		 * Get Health & Wellness toolkit presets.
		 *
		 * @since  1.0.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_health_wellness_presets() {
			return array(
				'daily_vitals_reminder'      => array(
					'name'          => __( 'Daily Vitals Reminder', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends daily reminders to log vital signs such as blood pressure, heart rate, and weight.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'health_wellness',
					'category'      => 'communication',
					'icon'          => 'dashicons-heart',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'health', 'vitals', 'reminders' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Daily vitals reminder: please take a moment to log your vital signs including blood pressure, heart rate, and weight.',
							'channels' => array( 'telegram' ),
						),
					),
				),
				'medication_schedule_alert'  => array(
					'name'          => __( 'Medication Schedule Alert', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Sends medication reminders based on configured schedules to help maintain adherence.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'health_wellness',
					'category'      => 'communication',
					'icon'          => 'dashicons-plus-alt',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'health', 'medication', 'reminders' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Medication reminder: it is time to take your scheduled medication. Please confirm once completed.',
							'channels' => array( 'telegram' ),
						),
					),
				),
				'wellness_check_broadcast'   => array(
					'name'          => __( 'Daily Wellness Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Broadcasts a daily wellness check-in prompt encouraging users to log mood, energy, and activity levels.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'health_wellness',
					'category'      => 'communication',
					'icon'          => 'dashicons-smiley',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'daily',
					'tags'          => array( 'health', 'wellness', 'check-in' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Daily wellness check-in: how are you feeling today? Please log your mood, energy level, sleep quality, and any physical activity completed.',
							'channels' => array( 'telegram' ),
						),
					),
				),
				'health_metrics_report'      => array(
					'name'          => __( 'Weekly Health Metrics Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Compiles a weekly report of health metrics with trend analysis and personalised wellness recommendations.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'health_wellness',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-line',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'health', 'metrics', 'reports' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a weekly health metrics report. Analyse logged vitals, activity levels, sleep patterns, and mood data over the past 7 days. Identify trends, compare against targets, and provide personalised wellness recommendations.',
						),
					),
				),
				'appointment_followup_check' => array(
					'name'          => __( 'Appointment Follow-up Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks for recent health appointments and triggers follow-up workflows for post-visit tasks and feedback.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'health_wellness',
					'category'      => 'business',
					'icon'          => 'dashicons-clipboard',
					'schedule_type' => 'workflow',
					'schedule'      => 'daily',
					'tags'          => array( 'health', 'appointments', 'followup' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'get_recent_health_appointments',
								'arguments' => array(
									'since' => '24 hours ago',
								),
								'label'     => __( 'Fetch recent health appointments', 'nvdigital-open-operator-system-oos-pro' ),
							),
							array(
								'tool_slug' => 'send_appointment_followup',
								'arguments' => array(),
								'label'     => __( 'Send follow-up messages', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
			);
		}

		// ------------------------------------------------------------------
		// Upwork Freelancer presets
		// ------------------------------------------------------------------

		/**
		 * Get Upwork Freelancer toolkit presets.
		 *
		 * Industry-standard freelancer workflow automation patterns for job
		 * discovery, proposal management, and client communication following
		 * best practices from leading freelance platforms and productivity
		 * methodologies (GigRadar, Vollna, n8n automation patterns).
		 *
		 * @since  2.1.0
		 * @return array<string, array> Preset definitions.
		 */
		private static function get_upwork_freelancer_presets() {
			return array(
				'upwork_job_discovery_scan'  => array(
					'name'          => __( 'Upwork Job Discovery Scan', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Periodically searches the Upwork marketplace for new job postings matching configured skills, categories, and budget preferences. Surfaces high-potential opportunities before competitors apply. Works in fallback mode via web search when no Upwork connection is configured.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'upwork_freelancer',
					'category'      => 'monitoring',
					'icon'          => 'dashicons-search',
					'schedule_type' => 'workflow',
					'schedule'      => 'wp_mcp_ai_every_30_minutes',
					'tags'          => array( 'upwork', 'freelancer', 'jobs', 'discovery' ),
					'schedule_data' => array(
						'workflow_steps' => array(
							array(
								'tool_slug' => 'search_upwork_jobs',
								'arguments' => array(
									'query'            => '',
									'job_type'         => 'all',
									'experience_level' => 'all',
									'sort'             => 'recency',
									'limit'            => 20,
								),
								'label'     => __( 'Search for new matching jobs', 'nvdigital-open-operator-system-oos-pro' ),
							),
						),
					),
				),
				'upwork_job_scoring'         => array(
					'name'          => __( 'Upwork Job Fit Scoring', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Scores recently discovered Upwork jobs against your freelancer profile, skills, and rate preferences. Ranks opportunities by fit to prioritise proposal effort on the highest-value postings. Supports text-based fallback scoring when no Upwork connection is configured.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'upwork_freelancer',
					'category'      => 'business',
					'icon'          => 'dashicons-star-half',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'upwork', 'freelancer', 'scoring', 'matching' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Search for Upwork jobs posted in the last 24 hours using search_upwork_jobs. For each job, use score_upwork_job to evaluate fit against my freelancer profile and skills. Generate a ranked report showing: job title, client budget, fit score, key matching skills, potential concerns (low client rating, unverified payment), and recommended bid strategy. Focus on jobs with a fit score above 70%.',
						),
					),
				),
				'upwork_proposal_pipeline'   => array(
					'name'          => __( 'Upwork Proposal Pipeline Report', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Generates a daily overview of submitted proposals, pending invitations, and active contract statuses. Tracks proposal-to-interview conversion rate and highlights stalled applications needing attention.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'upwork_freelancer',
					'category'      => 'reporting',
					'icon'          => 'dashicons-clipboard',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'daily',
					'tags'          => array( 'upwork', 'freelancer', 'proposals', 'pipeline', 'tracking' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a daily Upwork proposal pipeline report. Summarise: (1) proposals submitted in the last 7 days with their current status, (2) client response rate and average time to first response, (3) active interviews or pending invitations, (4) proposals with no response after 48 hours that may need follow-up, and (5) weekly win rate trend. Provide recommendations to improve proposal conversion.',
						),
					),
				),
				'upwork_client_followup'     => array(
					'name'          => __( 'Upwork Client Follow-up Check', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Checks for unanswered client messages and interview invitations on Upwork. Sends reminders to ensure prompt responses, maintaining professional communication standards that boost freelancer ranking.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'upwork_freelancer',
					'category'      => 'communication',
					'icon'          => 'dashicons-format-chat',
					'schedule_type' => 'channel_broadcast',
					'schedule'      => 'wp_mcp_ai_every_4_hours',
					'tags'          => array( 'upwork', 'freelancer', 'client', 'followup', 'messages' ),
					'schedule_data' => array(
						'broadcast_config' => array(
							'message'  => 'Upwork client follow-up reminder: check for unanswered messages and interview invitations. Prompt response times improve your Job Success Score and client satisfaction rating.',
							'channels' => array( 'slack' ),
						),
					),
				),
				'upwork_profile_performance' => array(
					'name'          => __( 'Upwork Profile Performance Review', 'nvdigital-open-operator-system-oos-pro' ),
					'description'   => __( 'Weekly review of Upwork profile performance metrics including Job Success Score trends, earnings, proposal win rate, and profile visibility. Provides actionable recommendations to improve marketplace competitiveness.', 'nvdigital-open-operator-system-oos-pro' ),
					'toolkit'       => 'upwork_freelancer',
					'category'      => 'reporting',
					'icon'          => 'dashicons-chart-line',
					'schedule_type' => 'assistant_run',
					'schedule'      => 'weekly',
					'tags'          => array( 'upwork', 'freelancer', 'profile', 'analytics', 'performance' ),
					'schedule_data' => array(
						'assistant_config' => array(
							'message' => 'Generate a weekly Upwork profile performance review. Analyse: (1) Job Success Score trend over the past 4 weeks, (2) total earnings this week vs. previous weeks, (3) proposal submission count and win rate, (4) average project rating received, (5) profile views and search appearance trends. Compare against freelancer benchmarks for my category. Recommend specific actions to improve ranking, such as skill certifications, portfolio updates, or rate adjustments.',
						),
					),
				),
			);
		}
	}
}
