<?php
/**
 * Tool for getting WP All Import status.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent parse errors on PHP < 8.1 by exiting before class definition.
if ( version_compare( PHP_VERSION, '8.1.0', '<' ) ) {
	return;
}

require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php';

/**
 * Gets the status of a WP All Import operation.
 */
class WP_MCP_AI_Tool_Get_All_Import_Status implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * Determine whether WP All Import is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return class_exists( 'PMXI_Plugin' ) || defined( 'PMXI_VERSION' );
	}

	/**
	 * Message explaining why the tool is unavailable.
	 *
	 * @return string
	 */
	public static function get_unavailable_reason() {
		return __( 'The WP All Import tool is disabled because WP All Import plugin is not active.', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'get_all_import_status';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Get WP All Import Status', 'mcp-ai-wpoos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Gets the status and progress of a WP All Import operation. Requires WP All Import plugin.', 'mcp-ai-wpoos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Checking the progress and stats of a known WP All Import operation by import ID.', 'mcp-ai-wpoos' ),
			'when_not_to_use' => __( 'Starting an import; use trigger_all_import. Browsing templates belongs to list_all_import_templates.', 'mcp-ai-wpoos' ),
			'related_tools'   => array( 'trigger_all_import', 'list_all_import_templates', 'trigger_all_export' ),
			'notes'           => __( 'Requires the WP All Import plugin and manage_options; status is idle, processing, or completed.', 'mcp-ai-wpoos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'import_id' => array(
					'type'        => 'integer',
					'description' => __( 'The ID of the import to check status.', 'mcp-ai-wpoos' ),
					'minimum'     => 1,
					'maximum'     => WP_MCP_AI_Tool_Schema_Helper::MAX_SAFE_INTEGER,
				),
			),
			'required'             => array( 'import_id' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! self::is_available() ) {
			return new WP_Error( 'wp_mcp_ai_all_import_missing', __( 'WP All Import is not active on this site.', 'mcp-ai-wpoos' ) );
		}

		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You must be logged in to check import status.', 'mcp-ai-wpoos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'mcp-ai-wpoos' ) );
		}

		if ( ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to check import status.', 'mcp-ai-wpoos' ) );
		}

		if ( empty( $arguments['import_id'] ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_param', __( 'Import ID is required.', 'mcp-ai-wpoos' ) );
		}

		$import_id = absint( $arguments['import_id'] );

		// Verify import exists.
		$import = get_post( $import_id );
		if ( ! $import || 'import' !== $import->post_type ) {
			return new WP_Error( 'wp_mcp_ai_invalid_import', __( 'Invalid import ID.', 'mcp-ai-wpoos' ) );
		}

		// Get import status metadata.
		$processing    = get_post_meta( $import_id, 'processing', true );
		$imported      = get_post_meta( $import_id, 'imported', true );
		$created       = get_post_meta( $import_id, 'created', true );
		$updated       = get_post_meta( $import_id, 'updated', true );
		$skipped       = get_post_meta( $import_id, 'skipped', true );
		$deleted       = get_post_meta( $import_id, 'deleted', true );
		$last_activity = get_post_meta( $import_id, 'registered_on', true );
		$iteration     = get_post_meta( $import_id, 'iteration', true );

		// Determine status.
		$status = 'idle';
		if ( $processing ) {
			$status = 'processing';
		} elseif ( $imported > 0 ) {
			$status = 'completed';
		}

		return $this->ensure_response_message(
			array(
				'import_id'     => $import_id,
				'import_name'   => $import->post_title,
				'status'        => $status,
				'processing'    => (bool) $processing,
				'stats'         => array(
					'imported' => absint( $imported ),
					'created'  => absint( $created ),
					'updated'  => absint( $updated ),
					'skipped'  => absint( $skipped ),
					'deleted'  => absint( $deleted ),
				),
				'iteration'     => absint( $iteration ),
				'last_activity' => $last_activity ? gmdate( DATE_W3C, strtotime( $last_activity ) ) : '',
			),
			sprintf(
				/* translators: 1: import name, 2: status */
				__( 'Successfully retrieved import status for "%1$s": %2$s', 'mcp-ai-wpoos' ),
				$import->post_title,
				$status
			)
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'workflow_automation',

			'pattern_compatibility' => array( 'hierarchical' ),

			'profession_tags'       => array( 'systems_administrator', 'data_engineer' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'requires-plugin',     // Requires WP All Import plugin.
			'read-only',           // Only reads data, does not modify state.
			'local-only',          // No external API calls.
			'cacheable',           // Results can be cached.
			'requires-capability', // Requires 'manage_options' capability.
		);
	}
}
