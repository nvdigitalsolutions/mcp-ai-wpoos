<?php
/**
 * Tool that edits images using Gemini's Nano Banana (image editing) capabilities.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool-llm-sanitizer.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-gemini-client.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-logger.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-media-url-utils.php';
require_once WP_MCP_AI_PATH . 'includes/traits/trait-wp-mcp-ai-attachment-file-resolver.php';
require_once WP_MCP_AI_PATH . 'includes/traits/trait-wp-mcp-ai-nodejs-subprocess.php';
require_once WP_MCP_AI_PATH . 'includes/traits/trait-wp-mcp-ai-svg-vectorizer.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-chat-response.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-image-response.php';
require_once WP_MCP_AI_PATH . 'includes/markup/interface-wp-mcp-ai-markup-aware-tool.php';

/**
 * Provides a tool for editing images via Gemini Nano Banana and storing them as attachments.
 *
 * Implements {@see WP_MCP_AI_Markup_Aware_Tool_Interface} so the LLM
 * can defer the *region of interest* to the user. When
 * `request_user_region` is set and a source attachment is resolvable,
 * `needs_markup()` short-circuits the agentic loop with a
 * `region`-mode markup elicitation. Because Gemini has no native mask
 * channel, the user's painted rectangle is communicated through
 * **prompt augmentation**: `consume_markup()` denormalizes the rect to
 * pixel coordinates, appends an explicit "Apply changes only within
 * the region x=…, y=…, width=…, height=… (out of WxH pixels)"
 * directive to the prompt, persists the rect on `target_region` for
 * downstream observability, clears the elicitation flag, and re-runs
 * `execute()`.
 */
class WP_MCP_AI_Tool_Edit_Gemini_Image implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Model_Requirements_Interface, WP_MCP_AI_Tool_Shortcuts_Interface, WP_MCP_AI_Tool_LLM_Sanitizer_Interface, WP_MCP_AI_Tool_Rules_Interface, WP_MCP_AI_Markup_Aware_Tool_Interface {
	use WP_MCP_AI_Attachment_File_Resolver;
	use WP_MCP_AI_NodeJS_Subprocess;
	use WP_MCP_AI_SVG_Vectorizer;
	use WP_MCP_AI_Tool_Chat_Response;
	use WP_MCP_AI_Tool_Image_Response;

	const DEFAULT_MODEL        = 'gemini-2.5-flash-image';
	const DEFAULT_MIME_TYPE    = 'image/png';
	const DEFAULT_ASPECT_RATIO = '4:3';

	/**
	 * Instruction for LLMs on how to extract URL from attached images.
	 * Repeated in multiple places to ensure LLMs see and follow the pattern.
	 *
	 * @var string
	 */
	const URL_EXTRACTION_INSTRUCTION = 'When the user has attached an image, look for the "url" field in the message content array (within segments of type "input_image") and pass it as the "url" parameter to the tool.';

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'edit_gemini_image';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Edit Gemini Image (Nano Banana)', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Edits an existing image using Gemini Nano Banana (text + image-to-image) and stores the result in the Media Library. IMPORTANT: When a user attaches an image in chat, extract the "url" field from the message content segments (look for type:"input_image" segments with a url field) and pass it as the "url" parameter. Can also edit images from the Media Library by attachment_id.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		$defaults = $this->get_configured_defaults();

		$aspect_choices = array_keys( $this->get_allowed_aspect_ratios() );
		$mime_choices   = array_keys( $this->get_allowed_mime_types() );

		return array(
			'type'                 => 'object',
			'properties'           => array_merge(
				array(
					'prompt'              => array(
						'type'        => 'string',
						'description' => __( 'Text instruction describing the desired edits (e.g., "remove background", "change sky to sunset", "make brighter").', 'nvdigital-open-operator-system-oos' ),
					),
					'attachment_id'       => array(
						'type'        => 'integer',
						'description' => __( 'WordPress attachment ID of the image to edit.', 'nvdigital-open-operator-system-oos' ),
					),
					'file_id'             => $this->get_file_id_parameter_schema( __( 'OpenAI or Gemini file identifier. Use this when the image was uploaded via the files endpoint.', 'nvdigital-open-operator-system-oos' ) ),
					'url'                 => $this->get_url_parameter_schema( 'image', __( 'URL of the image to edit. REQUIRED when user attaches an image in chat - extract the "url" field from the message content segment (look for segments with type:"input_image" that contain a url field). Can be a WordPress media URL or external URL.', 'nvdigital-open-operator-system-oos' ) ),
					'image_url'           => array(
						'type'        => 'string',
						'description' => __( 'URL of the image to edit (legacy parameter, use "url" instead).', 'nvdigital-open-operator-system-oos' ),
					),
					'image_data'          => array(
						'type'        => 'string',
						'description' => __( 'Base64-encoded image data to edit (alternative to attachment_id, url, or file_id). Useful for editing images created in the chat.', 'nvdigital-open-operator-system-oos' ),
					),
					'source_mime_type'    => array(
						'type'        => 'string',
						'description' => __( 'MIME type of the source image data (required when using image_data).', 'nvdigital-open-operator-system-oos' ),
					),
					'model'               => array(
						'type'        => 'string',
						'description' => __( 'Gemini image model to use.', 'nvdigital-open-operator-system-oos' ),
						'default'     => $defaults['model'],
					),
					'aspect_ratio'        => array(
						'type'        => 'string',
						'description' => __( 'Aspect ratio for the edited image.', 'nvdigital-open-operator-system-oos' ),
						'enum'        => $aspect_choices,
						'default'     => $defaults['aspect_ratio'],
					),
					'mime_type'           => array(
						'type'        => 'string',
						'description' => __( 'Preferred MIME type for the saved image.', 'nvdigital-open-operator-system-oos' ),
						'enum'        => $mime_choices,
						'default'     => $defaults['mime_type'],
					),
					'file_name'           => array(
						'type'        => 'string',
						'description' => __( 'Optional base file name for the saved image attachment.', 'nvdigital-open-operator-system-oos' ),
					),
					'timeout'             => array(
						'type'        => 'integer',
						'description' => __( 'Override the Gemini request timeout in seconds.', 'nvdigital-open-operator-system-oos' ),
						'minimum'     => 5,
						'maximum'     => 300,
					),
					'request_user_region' => array(
						'type'        => 'boolean',
						'description' => __( 'When true, pause execution and ask the user to draw a rectangle on the source image marking the region to edit. Because Gemini has no native mask channel, the rectangle is converted to an explicit prompt directive ("Apply changes only within the region x=…, y=…, width=…, height=…") so the model focuses its edit on that area.', 'nvdigital-open-operator-system-oos' ),
						'default'     => false,
					),
				),
				$this->get_output_format_parameter_schema()
			),
			'required'             => array( 'prompt' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_shortcut_tasks() {
		return array(
			array(
				'label'   => __( 'edit_gemini_image', 'nvdigital-open-operator-system-oos' ),
				'payload' => __( 'edit_gemini_image', 'nvdigital-open-operator-system-oos' ),
			),
			array(
				'label'   => __( 'Remove background', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: URL extraction instruction for LLMs */
				'payload' => sprintf( __( 'Use the `edit_gemini_image` tool to remove the background from an image. IMPORTANT: %s Use a prompt like "remove background, make transparent".', 'nvdigital-open-operator-system-oos' ), self::URL_EXTRACTION_INSTRUCTION ),
			),
			array(
				'label'   => __( 'Change image style', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: URL extraction instruction for LLMs */
				'payload' => sprintf( __( 'Use the `edit_gemini_image` tool to change the style of an image. IMPORTANT: %s Create a prompt like "convert to watercolor painting style".', 'nvdigital-open-operator-system-oos' ), self::URL_EXTRACTION_INSTRUCTION ),
			),
			array(
				'label'   => __( 'Enhance photo', 'nvdigital-open-operator-system-oos' ),
				/* translators: %s: URL extraction instruction for LLMs */
				'payload' => sprintf( __( 'Use the `edit_gemini_image` tool to enhance a photo. IMPORTANT: %s Use prompts like "enhance brightness and contrast", "sharpen details", or "improve lighting".', 'nvdigital-open-operator-system-oos' ), self::URL_EXTRACTION_INSTRUCTION ),
			),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id   = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : 0;
		$has_token = ! empty( $context['token_authenticated'] );

		if ( ! $user_id && ! $has_token ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You must be authenticated to edit images.', 'nvdigital-open-operator-system-oos' ), array( 'status' => rest_authorization_required_code() ) );
		}

		if ( $user_id ) {
			if ( ! user_can( $user_id, 'read' ) ) {
				return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to edit images.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
				return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
			}
		}

		$prompt = isset( $arguments['prompt'] ) ? sanitize_textarea_field( $arguments['prompt'] ) : '';
		$prompt = trim( $prompt );

		if ( '' === $prompt ) {
			return new WP_Error( 'wp_mcp_ai_missing_prompt', __( 'No editing instruction was supplied.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 400 ) );
		}

		// Enrich arguments with metadata from context messages if available.
		// This preserves attachment metadata that OpenAI strips from its responses.
		$arguments = $this->enrich_arguments_from_messages( $arguments, $context );

		// Get the source image - either from attachment_id, image_url, or image_data.
		$source_image = $this->get_source_image( $arguments, $user_id );
		if ( is_wp_error( $source_image ) ) {
			return $source_image;
		}

		// Ensure image data is base64-encoded for Gemini API.
		// All sources return raw binary data, so we need to encode it.
		if ( isset( $source_image['data'] ) && ! empty( $source_image['data'] ) ) {
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- base64_encode used to encode binary image data for API transmission, not for obfuscation.
			$source_image['data'] = base64_encode( $source_image['data'] );
		}

		$defaults = $this->get_configured_defaults();

		$aspect_ratio = isset( $arguments['aspect_ratio'] ) ? $this->normalise_aspect_ratio_value( $arguments['aspect_ratio'] ) : $defaults['aspect_ratio'];
		if ( '' === $aspect_ratio ) {
			$aspect_ratio = $defaults['aspect_ratio'];
		}

		$mime_type = isset( $arguments['mime_type'] ) ? $this->normalise_mime_type( $arguments['mime_type'] ) : $defaults['mime_type'];
		if ( '' === $mime_type ) {
			$mime_type = $defaults['mime_type'];
		}

		$model = isset( $arguments['model'] ) ? sanitize_text_field( $arguments['model'] ) : $defaults['model'];
		$model = '' === $model ? $defaults['model'] : $model;

		$file_name = isset( $arguments['file_name'] ) ? sanitize_file_name( $arguments['file_name'] ) : '';
		$timeout   = isset( $arguments['timeout'] ) ? absint( $arguments['timeout'] ) : 0;

		$client  = new WP_MCP_AI_Gemini_Client();
		$options = array(
			'model'        => $model,
			'aspect_ratio' => $aspect_ratio,
			'mime_type'    => $mime_type,
			'source_image' => $source_image,
		);

		if ( $timeout ) {
			$options['timeout'] = max( 5, min( 300, $timeout ) );
		}

		// Use edit_image method (we'll need to add this to the Gemini client).
		$image = $client->edit_image( $prompt, $options );

		if ( is_wp_error( $image ) ) {
			return $image;
		}

		if ( empty( $image['image'] ) ) {
			return new WP_Error( 'wp_mcp_ai_image_storage_error', __( 'Gemini returned an empty image response.', 'nvdigital-open-operator-system-oos' ) );
		}

		$storage = $this->store_image_attachment( $image, $file_name, $prompt, $user_id, $context );

		if ( is_wp_error( $storage ) ) {
			return $storage;
		}

		// Check if SVG output is requested.
		$output_format = isset( $arguments['output_format'] ) ? sanitize_text_field( $arguments['output_format'] ) : 'default';

		if ( 'svg' === $output_format ) {
			// Convert the edited raster image to SVG.
			$svg_storage = $this->convert_to_svg( $storage, $arguments );

			if ( is_wp_error( $svg_storage ) ) {
				// If SVG conversion fails, return the original raster image.
				WP_MCP_AI_Logger::log_error(
					'gemini_edit_svg_conversion_failed',
					'Failed to convert Gemini-edited image to SVG',
					array(
						'error'         => $svg_storage->get_error_message(),
						'attachment_id' => $storage['attachment_id'],
					)
				);
			} else {
				// Replace storage with SVG version.
				$storage = $svg_storage;
			}
		}

		// Build descriptive text message for the LLM and chat UI.
		$text = sprintf(
			/* translators: 1: image title, 2: attachment ID, 3: edit instruction, 4: output format */
			__( 'Successfully edited image "%1$s" (ID: %2$d). Edit instruction: %3$s%4$s', 'nvdigital-open-operator-system-oos' ),
			$storage['title'],
			$storage['attachment_id'],
			$prompt,
			'svg' === $output_format ? ' and converted to SVG' : ''
		);
		$message = $text;

		$result = array(
			'attachment_id'     => $storage['attachment_id'],
			'url'               => $storage['url'],
			'download_url'      => isset( $storage['download_url'] ) && '' !== $storage['download_url'] ? $storage['download_url'] : $storage['url'],
			'file_name'         => $storage['file_name'],
			'mime_type'         => $storage['mime_type'],
			'bytes'             => $storage['bytes'],
			'title'             => $storage['title'],
			'model'             => isset( $image['model'] ) ? $image['model'] : $model,
			'aspect_ratio'      => isset( $image['aspect_ratio'] ) ? $image['aspect_ratio'] : $aspect_ratio,
			'format'            => isset( $image['format'] ) ? $image['format'] : $this->map_mime_type_to_format( $storage['mime_type'] ),
			'edit_instruction'  => $prompt,
			'source_attachment' => isset( $arguments['attachment_id'] ) ? absint( $arguments['attachment_id'] ) : null,
			'provider'          => 'gemini', // Track provider for accurate cost attribution.
			'output_format'     => $output_format,
			'text'              => $text, // Descriptive message for LLM and chat UI.
			'message'           => $message,
		);

		// Add vectorization metadata if SVG output was used.
		if ( 'svg' === $output_format && isset( $storage['vectorized'] ) ) {
			$result['vectorized']  = true;
			$result['svg_size']    = isset( $storage['svg_size'] ) ? $storage['svg_size'] : $storage['bytes'];
			$result['source_size'] = isset( $storage['source_size'] ) ? $storage['source_size'] : 0;
			$result['duration_ms'] = isset( $storage['duration_ms'] ) ? $storage['duration_ms'] : 0;
		}

		// Include usage metadata if available for accurate cost tracking.
		if ( isset( $image['usage'] ) && is_array( $image['usage'] ) ) {
			$result['usage'] = $image['usage'];
		}

		// Note: Inline content payload (base64 encoded image data) is intentionally NOT included
		// in the default response to prevent bloating tool results sent to chat clients and LLMs.
		// If base64 content is needed, it should be retrieved via a separate endpoint or parameter.

		/**
		 * Allow third parties to filter the image editing result before it is returned.
		 *
		 * @param array $result    Result array to be returned.
		 * @param array $arguments Arguments supplied to the tool.
		 * @param array $context   Execution context supplied to the tool.
		 */
		$result = apply_filters( 'wp_mcp_ai_edit_gemini_image_result', $result, $arguments, $context );

		// Add rendered image HTML to the response for display in chat UI.
		$result = $this->add_image_html_to_response( $result );

		return $result;
	}

	/**
	 * Enrich arguments with metadata from context messages.
	 *
	 * When OpenAI processes messages, it strips custom metadata fields (attachment_id,
	 * file_name, mime_type, bytes) from image segments, only preserving the URL.
	 * This method extracts that metadata from the original user messages in the context
	 * to restore it for agentic workflows.
	 *
	 * Enhanced to automatically find the most recent image attachment when no URL is provided,
	 * making agentic workflows more robust when LLMs don't explicitly pass the URL parameter.
	 *
	 * @param array $arguments Tool arguments from OpenAI.
	 * @param array $context   Execution context including messages.
	 * @return array Enriched arguments with metadata.
	 */
	protected function enrich_arguments_from_messages( array $arguments, array $context ) {
		// If attachment_id is already provided, no need to enrich.
		if ( ! empty( $arguments['attachment_id'] ) ) {
			return $arguments;
		}

		// If no messages in context, can't enrich.
		if ( empty( $context['messages'] ) || ! is_array( $context['messages'] ) ) {
			return $arguments;
		}

		// Look for URL in arguments to match against messages.
		$target_url = '';
		if ( ! empty( $arguments['url'] ) ) {
			$target_url = $arguments['url'];
		} elseif ( ! empty( $arguments['image_url'] ) ) {
			$target_url = $arguments['image_url'];
		}

		// If a URL was provided, try to find matching attachment with that URL.
		if ( '' !== $target_url ) {
			// Normalize URL for comparison (strip query strings and fragments).
			$target_url_normalized = strtok( $target_url, '?' );
			$target_url_normalized = strtok( $target_url_normalized, '#' );

			// Search through messages for matching image attachment.
			foreach ( $context['messages'] as $message ) {
				// Only check user messages (where attachments originate).
				if ( ! isset( $message['role'] ) || 'user' !== $message['role'] ) {
					continue;
				}

				// Check if message has content array with segments.
				if ( ! isset( $message['content'] ) || ! is_array( $message['content'] ) ) {
					continue;
				}

				foreach ( $message['content'] as $segment ) {
					if ( ! is_array( $segment ) ) {
						continue;
					}

					// Check for image segments (input_image or image_url type).
					$type = isset( $segment['type'] ) ? $segment['type'] : '';
					if ( ! in_array( $type, array( 'input_image', 'image_url' ), true ) ) {
						continue;
					}

					// Extract URL from segment.
					$segment_url = '';
					if ( isset( $segment['url'] ) ) {
						$segment_url = $segment['url'];
					} elseif ( isset( $segment['image_url']['url'] ) ) {
						$segment_url = $segment['image_url']['url'];
					} elseif ( isset( $segment['image_url'] ) && is_string( $segment['image_url'] ) ) {
						$segment_url = $segment['image_url'];
					}

					if ( '' === $segment_url ) {
						continue;
					}

					// Normalize segment URL for comparison.
					$segment_url_normalized = strtok( $segment_url, '?' );
					$segment_url_normalized = strtok( $segment_url_normalized, '#' );

					// Check if URLs match.
					if ( $segment_url_normalized === $target_url_normalized ) {
						// Found matching image! Extract metadata.
						if ( isset( $segment['attachment_id'] ) && $segment['attachment_id'] > 0 ) {
							$arguments['attachment_id'] = absint( $segment['attachment_id'] );
						}

						if ( isset( $segment['file_name'] ) && '' !== $segment['file_name'] ) {
							$arguments['file_name'] = sanitize_text_field( $segment['file_name'] );
						}

						if ( isset( $segment['mime_type'] ) && '' !== $segment['mime_type'] ) {
							$arguments['source_mime_type'] = sanitize_text_field( $segment['mime_type'] );
						}

						if ( isset( $segment['bytes'] ) && $segment['bytes'] > 0 ) {
							$arguments['bytes'] = absint( $segment['bytes'] );
						}

						// Found the match, no need to continue searching.
						return $arguments;
					}
				}
			}

			// URL was provided but no match found, return arguments as-is.
			return $arguments;
		}

		// No URL provided in arguments, so find the most recent image attachment.
		// Iterate through messages in reverse order to find the latest user message with an image.
		$messages_reversed = array_reverse( $context['messages'] );
		foreach ( $messages_reversed as $message ) {
			// Only check user messages (where attachments originate).
			if ( ! isset( $message['role'] ) || 'user' !== $message['role'] ) {
				continue;
			}

			// Check if message has content array with segments.
			if ( ! isset( $message['content'] ) || ! is_array( $message['content'] ) ) {
				continue;
			}

			foreach ( $message['content'] as $segment ) {
				if ( ! is_array( $segment ) ) {
					continue;
				}

				// Check for image segments (input_image or image_url type).
				$type = isset( $segment['type'] ) ? $segment['type'] : '';
				if ( ! in_array( $type, array( 'input_image', 'image_url' ), true ) ) {
					continue;
				}

				// Found an image segment! Extract all available metadata.
				// Start with URL.
				if ( isset( $segment['url'] ) && '' !== $segment['url'] ) {
					$arguments['url'] = esc_url_raw( $segment['url'] );
				} elseif ( isset( $segment['image_url']['url'] ) && '' !== $segment['image_url']['url'] ) {
					$arguments['url'] = esc_url_raw( $segment['image_url']['url'] );
				} elseif ( isset( $segment['image_url'] ) && is_string( $segment['image_url'] ) && '' !== $segment['image_url'] ) {
					$arguments['url'] = esc_url_raw( $segment['image_url'] );
				}

				// Extract attachment metadata.
				if ( isset( $segment['attachment_id'] ) && $segment['attachment_id'] > 0 ) {
					$arguments['attachment_id'] = absint( $segment['attachment_id'] );
				}

				if ( isset( $segment['file_name'] ) && '' !== $segment['file_name'] ) {
					$arguments['file_name'] = sanitize_text_field( $segment['file_name'] );
				}

				if ( isset( $segment['mime_type'] ) && '' !== $segment['mime_type'] ) {
					$arguments['source_mime_type'] = sanitize_text_field( $segment['mime_type'] );
				}

				if ( isset( $segment['bytes'] ) && $segment['bytes'] > 0 ) {
					$arguments['bytes'] = absint( $segment['bytes'] );
				}

				// Extract file_id if available.
				if ( isset( $segment['file_id'] ) && '' !== $segment['file_id'] ) {
					$arguments['file_id'] = sanitize_text_field( $segment['file_id'] );
				}

				// Found the most recent image attachment, return enriched arguments.
				return $arguments;
			}
		}

		// No image attachments found in any user messages, return arguments as-is.
		return $arguments;
	}

	/**
	 * Get the source image data from attachment_id, file_id, url, image_url, or image_data.
	 *
	 * @param array $arguments Tool arguments.
	 * @param int   $user_id   Current user ID.
	 * @return array|WP_Error Array with image data or WP_Error on failure.
	 */
	protected function get_source_image( array $arguments, $user_id ) {
		$attachment_id = 0;
		$image_url     = '';
		$image_data    = isset( $arguments['image_data'] ) ? $arguments['image_data'] : '';

		// Try to resolve from attachment_id, file_id, or url first.
		if ( ! empty( $arguments['attachment_id'] ) || ! empty( $arguments['file_id'] ) || ! empty( $arguments['url'] ) ) {
			$resolved = $this->resolve_attachment_id( $arguments );

			// Handle remote URL case.
			if ( is_array( $resolved ) && isset( $resolved['url'] ) ) {
				$image_url = $resolved['url'];
			} elseif ( is_wp_error( $resolved ) ) {
				return $resolved;
			} elseif ( $resolved > 0 ) {
				$attachment_id = $resolved;
			}
		}

		// Fallback to legacy image_url parameter.
		if ( 0 === $attachment_id && '' === $image_url && ! empty( $arguments['image_url'] ) ) {
			$image_url = esc_url_raw( $arguments['image_url'] );
		}

		if ( $attachment_id > 0 ) {
			// Get image from WordPress attachment.
			$file_path = get_attached_file( $attachment_id );

			if ( ! $file_path || ! file_exists( $file_path ) ) {
				return new WP_Error( 'wp_mcp_ai_invalid_attachment', __( 'The specified attachment does not exist.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 404 ) );
			}

			// Check if user has permission to read this attachment.
			if ( $user_id && ! current_user_can( 'read_post', $attachment_id ) ) {
				return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to access this attachment.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 403 ) );
			}

			$image_data = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; WP_Filesystem not available in this context.
			if ( false === $image_data ) {
				return new WP_Error( 'wp_mcp_ai_read_error', __( 'Failed to read the image file.', 'nvdigital-open-operator-system-oos' ) );
			}

			$mime_type = get_post_mime_type( $attachment_id );

			// Validate MIME type is supported for image editing.
			$mime_validation = $this->validate_source_mime_type( $mime_type );
			if ( is_wp_error( $mime_validation ) ) {
				return $mime_validation;
			}

			return array(
				'data'      => $image_data,
				'mime_type' => $mime_type,
				'source'    => 'attachment',
			);
		} elseif ( '' !== $image_url ) {
			// Try to resolve URL to attachment ID first.
			// This handles cases where the URL is a WordPress media URL that might have.
			// different scheme (http vs https) or other variations that prevent direct.
			// filesystem access but still refers to a valid local attachment.
			$resolved_attachment_id = $this->resolve_attachment_id_from_url( $image_url );

			if ( $resolved_attachment_id > 0 ) {
				$file_path = get_attached_file( $resolved_attachment_id );

				if ( $file_path && file_exists( $file_path ) && is_readable( $file_path ) ) {
					$image_data = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; WP_Filesystem not available in this context.

					if ( false !== $image_data && '' !== $image_data ) {
						$mime_type = get_post_mime_type( $resolved_attachment_id );

						// Validate MIME type is supported for image editing.
						$mime_validation = $this->validate_source_mime_type( $mime_type );
						if ( is_wp_error( $mime_validation ) ) {
							return $mime_validation;
						}

						return array(
							'data'      => $image_data,
							'mime_type' => $mime_type,
							'source'    => 'attachment_url',
						);
					}
				}
				// If attachment file reading failed, fall through to other methods.
			}

			// Check if this is a local WordPress URL first.
			// If it is, we can read it directly from the filesystem to avoid HTTP auth issues.
			if ( $this->is_local_wordpress_url( $image_url ) ) {
				$file_path = $this->get_file_path_from_local_url( $image_url );

				if ( $file_path && file_exists( $file_path ) && is_readable( $file_path ) ) {
					// Read the file directly from the filesystem.
					$image_data = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; WP_Filesystem not available in this context.

					if ( false !== $image_data && '' !== $image_data ) {
						// Determine MIME type from file.
						$file_info = wp_check_filetype( $file_path );
						$mime_type = ! empty( $file_info['type'] ) ? $file_info['type'] : 'image/png';

						return array(
							'data'      => $image_data,
							'mime_type' => $mime_type,
							'source'    => 'local_url',
						);
					}
				}
				// If local file reading failed, fall through to HTTP download.
			}

			// Download image from URL (for external URLs or if local file reading failed).
			$response = wp_safe_remote_get( $image_url, array( 'timeout' => 30 ) );

			if ( is_wp_error( $response ) ) {
				return new WP_Error( 'wp_mcp_ai_download_error', __( 'Failed to download the source image.', 'nvdigital-open-operator-system-oos' ), array( 'error' => $response->get_error_message() ) );
			}

			$status_code = wp_remote_retrieve_response_code( $response );
			if ( $status_code < 200 || $status_code >= 300 ) {
				/* translators: %d: HTTP status code */
				return new WP_Error( 'wp_mcp_ai_download_error', sprintf( __( 'Failed to download image. HTTP %d', 'nvdigital-open-operator-system-oos' ), $status_code ), array( 'status' => $status_code ) );
			}

			$image_data = wp_remote_retrieve_body( $response );
			if ( '' === $image_data ) {
				return new WP_Error( 'wp_mcp_ai_download_error', __( 'Downloaded image is empty.', 'nvdigital-open-operator-system-oos' ) );
			}

			$headers   = wp_remote_retrieve_headers( $response );
			$mime_type = isset( $headers['content-type'] ) ? $headers['content-type'] : 'image/png';

			return array(
				'data'      => $image_data,
				'mime_type' => $mime_type,
				'source'    => 'url',
			);
		} elseif ( '' !== $image_data ) {
			// Use base64-encoded image data (blob) directly.
			// This is useful for editing images that were just created in the chat.
			$decoded_data = base64_decode( $image_data, true );

			if ( false === $decoded_data ) {
				return new WP_Error( 'wp_mcp_ai_invalid_image_data', __( 'The provided image data is not valid base64.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 400 ) );
			}

			if ( '' === $decoded_data ) {
				return new WP_Error( 'wp_mcp_ai_empty_image_data', __( 'The decoded image data is empty.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 400 ) );
			}

			// Get MIME type from argument or default to PNG.
			$mime_type = isset( $arguments['source_mime_type'] ) ? sanitize_mime_type( $arguments['source_mime_type'] ) : 'image/png';

			// Validate MIME type.
			$allowed_mime_types = array( 'image/png', 'image/jpeg', 'image/jpg', 'image/webp' );
			if ( ! in_array( $mime_type, $allowed_mime_types, true ) ) {
				$mime_type = 'image/png';
			}

			return array(
				'data'      => $decoded_data,
				'mime_type' => $mime_type,
				'source'    => 'blob',
			);
		} else {
			return new WP_Error( 'wp_mcp_ai_missing_source', __( 'You must provide attachment_id, file_id, url, image_url, or image_data.', 'nvdigital-open-operator-system-oos' ), array( 'status' => 400 ) );
		}
	}

	/**
	 * Check if a URL is a local WordPress URL.
	 *
	 * Note: This method is duplicated in both WP_MCP_AI_Tool_Image_Base and this class
	 * because this tool does not extend the base class. The edit_gemini_image tool
	 * interfaces directly with the Gemini API and has different requirements.
	 *
	 * @param string $url URL to check.
	 * @return bool True if the URL belongs to this WordPress installation.
	 */
	protected function is_local_wordpress_url( $url ) {
		if ( '' === $url ) {
			return false;
		}

		$url = esc_url_raw( $url );
		if ( '' === $url ) {
			return false;
		}

		// Normalize URL to remove scheme differences (http vs https).
		$normalized_url = $this->normalize_url_for_comparison( $url );

		// Get the WordPress upload directory URL.
		$upload_dir = wp_upload_dir();
		$base_url   = isset( $upload_dir['baseurl'] ) ? $upload_dir['baseurl'] : '';

		if ( '' !== $base_url ) {
			$normalized_base = $this->normalize_url_for_comparison( $base_url );
			if ( 0 === strpos( $normalized_url, $normalized_base ) ) {
				return true;
			}
		}

		// Also check against home_url and site_url as fallback.
		$home_url            = home_url();
		$site_url            = site_url();
		$normalized_home_url = $this->normalize_url_for_comparison( $home_url );
		$normalized_site_url = $this->normalize_url_for_comparison( $site_url );

		if ( 0 === strpos( $normalized_url, $normalized_home_url ) || 0 === strpos( $normalized_url, $normalized_site_url ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Normalize a URL for comparison by removing the scheme.
	 *
	 * This helps match URLs that differ only in http vs https.
	 *
	 * @param string $url URL to normalize.
	 * @return string Normalized URL without scheme.
	 */
	protected function normalize_url_for_comparison( $url ) {
		if ( '' === $url ) {
			return '';
		}

		// Remove http:// or https:// prefix for comparison.
		$url = preg_replace( '#^https?://#i', '', $url );

		return $url;
	}

	/**
	 * Convert a local WordPress URL to a file path.
	 *
	 * Note: This method is duplicated in both WP_MCP_AI_Tool_Image_Base and this class
	 * because this tool does not extend the base class. The edit_gemini_image tool
	 * interfaces directly with the Gemini API and has different requirements.
	 *
	 * @param string $url Local WordPress URL.
	 * @return string|false File path on success, false on failure.
	 */
	protected function get_file_path_from_local_url( $url ) {
		if ( '' === $url ) {
			return false;
		}

		// Get the WordPress upload directory information.
		$upload_dir = wp_upload_dir();
		$base_url   = isset( $upload_dir['baseurl'] ) ? $upload_dir['baseurl'] : '';
		$base_dir   = isset( $upload_dir['basedir'] ) ? $upload_dir['basedir'] : '';

		if ( '' === $base_url || '' === $base_dir ) {
			return false;
		}

		// Normalize URLs to handle scheme differences (http vs https).
		$normalized_url      = $this->normalize_url_for_comparison( $url );
		$normalized_base_url = $this->normalize_url_for_comparison( $base_url );

		// Check if URL starts with the upload base URL (using normalized comparison).
		if ( 0 === strpos( $normalized_url, $normalized_base_url ) ) {
			// Extract the relative path after the base URL.
			$relative_path = substr( $normalized_url, strlen( $normalized_base_url ) );

			// Security: Decode URL-encoding before checking for traversal sequences so
			// that encoded variants like %2e%2e cannot bypass the check.
			$decoded_relative = urldecode( $relative_path );
			if ( false !== strpos( $decoded_relative, '..' ) ) {
				return false;
			}

			// Build the file path.
			$file_path = $base_dir . $relative_path;

			// Normalize path separators.
			$file_path = wp_normalize_path( $file_path );

			// Security: Verify the resolved path stays within the uploads directory.
			$resolved = realpath( $file_path );
			if ( false === $resolved ) {
				return false;
			}
			$uploads_base = wp_normalize_path( trailingslashit( $base_dir ) );
			if ( 0 !== strpos( wp_normalize_path( $resolved ), $uploads_base ) ) {
				return false;
			}
			return $resolved;
		}

		// Try using WordPress built-in function as fallback.
		// This handles cases where URL might be in a different format.
		$attachment_id = attachment_url_to_postid( $url );
		if ( $attachment_id > 0 ) {
			return get_attached_file( $attachment_id );
		}

		return false;
	}

	/**
	 * Resolve an attachment ID from a URL with scheme-agnostic matching.
	 *
	 * WordPress's attachment_url_to_postid() function is scheme-sensitive and will
	 * fail if the URL scheme (http vs https) doesn't match what's stored in the
	 * database. This method provides a fallback that tries both schemes.
	 *
	 * This is particularly important for the agentic workflow where the LLM may
	 * receive URLs with a different scheme than WordPress is configured with.
	 *
	 * Note: This method is duplicated in both WP_MCP_AI_Tool_Image_Base and this class
	 * because this tool does not extend the base class. The edit_gemini_image tool
	 * interfaces directly with the Gemini API and has different requirements.
	 *
	 * @param string $url URL to resolve.
	 * @return int Attachment ID on success, 0 if not found.
	 */
	protected function resolve_attachment_id_from_url( $url ) {
		if ( '' === $url ) {
			return 0;
		}

		// First, try the URL as-is.
		$attachment_id = attachment_url_to_postid( $url );
		if ( $attachment_id > 0 ) {
			return $attachment_id;
		}

		// If that failed, try with the opposite scheme.
		// This handles cases where the LLM passes a URL with http but WordPress.
		// is configured with https (or vice versa).
		$alternate_url = '';

		if ( 0 === strpos( $url, 'https://' ) ) {
			// Try http instead.
			$alternate_url = 'http://' . substr( $url, 8 );
		} elseif ( 0 === strpos( $url, 'http://' ) ) {
			// Try https instead.
			$alternate_url = 'https://' . substr( $url, 7 );
		}

		if ( '' !== $alternate_url ) {
			$attachment_id = attachment_url_to_postid( $alternate_url );
			if ( $attachment_id > 0 ) {
				return $attachment_id;
			}
		}

		return 0;
	}

	/**
	 * Get the supported MIME types for image editing.
	 *
	 * @return array List of supported MIME types.
	 */
	protected function get_supported_source_mime_types() {
		return array(
			'image/jpeg',
			'image/png',
			'image/gif',
			'image/webp',
			'image/bmp',
		);
	}

	/**
	 * Validate that a MIME type is supported for image editing.
	 *
	 * @param string $mime_type MIME type to validate.
	 * @return true|WP_Error True if valid, WP_Error if not supported.
	 */
	protected function validate_source_mime_type( $mime_type ) {
		$supported_mime_types = $this->get_supported_source_mime_types();

		if ( ! in_array( $mime_type, $supported_mime_types, true ) ) {
			return new WP_Error(
				'wp_mcp_ai_unsupported_image_type',
				sprintf(
					/* translators: %s: MIME type */
					__( 'Image type "%s" is not supported for editing. Please use JPEG, PNG, GIF, WebP, or BMP formats.', 'nvdigital-open-operator-system-oos' ),
					$mime_type
				),
				array( 'status' => 400 )
			);
		}

		return true;
	}

	/**
	 * Retrieve the configured defaults for image editing.
	 *
	 * @return array
	 */
	protected function get_configured_defaults() {
		$defaults = array(
			'model'        => self::DEFAULT_MODEL,
			'mime_type'    => self::DEFAULT_MIME_TYPE,
			'aspect_ratio' => self::DEFAULT_ASPECT_RATIO,
		);

		if ( class_exists( 'WP_MCP_AI_Admin_Settings' ) ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			if ( ! empty( $settings['gemini_image_model'] ) ) {
				$defaults['model'] = sanitize_text_field( $settings['gemini_image_model'] );
			}

			if ( ! empty( $settings['gemini_image_mime_type'] ) ) {
				$mime_type = $this->normalise_mime_type( $settings['gemini_image_mime_type'] );
				if ( '' !== $mime_type ) {
					$defaults['mime_type'] = $mime_type;
				}
			}

			if ( ! empty( $settings['gemini_image_aspect_ratio'] ) ) {
				$aspect_ratio = $this->normalise_aspect_ratio_value( $settings['gemini_image_aspect_ratio'] );
				if ( '' !== $aspect_ratio ) {
					$defaults['aspect_ratio'] = $aspect_ratio;
				}
			}
		}

		/**
		 * Allow third parties to filter the default Gemini image editing settings.
		 *
		 * @param array $defaults Default settings.
		 */
		return apply_filters( 'wp_mcp_ai_gemini_image_edit_defaults', $defaults );
	}

	/**
	 * Get allowed aspect ratios.
	 *
	 * @return array
	 */
	protected function get_allowed_aspect_ratios() {
		return array(
			'auto' => 'Auto (Let AI decide)',
			'1:1'  => '1:1',
			'3:4'  => '3:4',
			'4:3'  => '4:3',
			'9:16' => '9:16',
			'16:9' => '16:9',
		);
	}

	/**
	 * Get allowed MIME types.
	 *
	 * @return array
	 */
	protected function get_allowed_mime_types() {
		return array(
			'image/png'  => 'PNG',
			'image/jpeg' => 'JPEG',
		);
	}

	/**
	 * Normalise aspect ratio value.
	 *
	 * @param string $value Raw aspect ratio value.
	 * @return string
	 */
	protected function normalise_aspect_ratio_value( $value ) {
		$value = strtolower( sanitize_text_field( $value ) );
		$value = str_replace( ' ', '', $value );

		// Special case: "auto" means let the AI decide (no aspectRatio sent to API).
		if ( 'auto' === $value ) {
			return 'auto';
		}

		$value   = strtoupper( $value );
		$allowed = $this->get_allowed_aspect_ratios();

		return isset( $allowed[ $value ] ) ? $value : '';
	}

	/**
	 * Normalise MIME type value.
	 *
	 * @param string $value Raw MIME type value.
	 * @return string
	 */
	protected function normalise_mime_type( $value ) {
		$value   = sanitize_text_field( $value );
		$allowed = $this->get_allowed_mime_types();

		return isset( $allowed[ $value ] ) ? $value : '';
	}

	/**
	 * Store the edited image as a WordPress attachment.
	 *
	 * @param array  $image     Response payload from the Gemini client.
	 * @param string $file_name Optional preferred file name.
	 * @param string $prompt    Original editing instruction.
	 * @param int    $user_id   Acting user ID.
	 * @param array  $context   Optional. Execution context containing parent_job_id.
	 * @return array|WP_Error
	 */
	protected function store_image_attachment( array $image, $file_name, $prompt, $user_id, array $context = array() ) {
		$data      = isset( $image['image'] ) ? $image['image'] : '';
		$mime_type = isset( $image['mime_type'] ) ? $image['mime_type'] : self::DEFAULT_MIME_TYPE;

		if ( '' === $data ) {
			return new WP_Error( 'wp_mcp_ai_image_storage_error', __( 'Unable to determine the image data for storage.', 'nvdigital-open-operator-system-oos' ) );
		}

		$extension = $this->get_extension_from_mime_type( $mime_type );

		// Use job_id for filename if available, otherwise use file_name or default.
		$job_id = isset( $context['parent_job_id'] ) ? sanitize_key( $context['parent_job_id'] ) : '';
		if ( ! empty( $job_id ) ) {
			$file_name = sprintf( 'gemini-edited-%s.%s', $job_id, $extension );
		} else {
			$file_stem = $this->normalise_file_stem( $file_name );
			$file_name = sprintf( '%s-edited-%s.%s', $file_stem, gmdate( 'Ymd-His' ), $extension );
		}

		if ( ! function_exists( 'wp_upload_bits' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$upload = wp_upload_bits( $file_name, null, $data );

		if ( ! empty( $upload['error'] ) ) {
			return new WP_Error( 'wp_mcp_ai_image_upload_failed', __( 'Failed to save the edited image file.', 'nvdigital-open-operator-system-oos' ), array( 'error' => $upload['error'] ) );
		}

		$file_path = isset( $upload['file'] ) ? $upload['file'] : '';

		if ( '' === $file_path || ! file_exists( $file_path ) ) {
			return new WP_Error( 'wp_mcp_ai_image_upload_failed', __( 'Failed to write the edited image file to disk.', 'nvdigital-open-operator-system-oos' ) );
		}

		$title = $this->generate_attachment_title( $prompt );

		$attachment = array(
			'post_mime_type' => $mime_type,
			'post_title'     => $title,
			'post_content'   => '',
			'post_status'    => 'inherit',
		);

		if ( $user_id ) {
			$attachment['post_author'] = $user_id;
		}

		$attachment_id = wp_insert_attachment( $attachment, $file_path );

		if ( is_wp_error( $attachment_id ) ) {
			wp_delete_file( $file_path );
			return new WP_Error( 'wp_mcp_ai_attachment_error', __( 'Failed to register the edited image as an attachment.', 'nvdigital-open-operator-system-oos' ), array( 'error' => $attachment_id ) );
		}

		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$metadata = wp_generate_attachment_metadata( $attachment_id, $file_path );

		if ( is_array( $metadata ) && ! empty( $metadata ) ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		}

		// Store job_id if available - allows correlation between job IDs and files.
		if ( ! empty( $job_id ) ) {
			update_post_meta( $attachment_id, '_gemini_edit_job_id', $job_id );
		}

		$bytes = file_exists( $file_path ) ? filesize( $file_path ) : 0;

		// Get local WordPress URL using utility class for SoC compliance.
		$local_url = WP_MCP_AI_Media_URL_Utils::get_local_upload_url( $upload, $attachment_id );

		return array(
			'attachment_id' => (int) $attachment_id,
			'file'          => $file_path,
			'file_name'     => wp_basename( $file_path ),
			'url'           => $local_url,
			'download_url'  => $local_url,
			'mime_type'     => $mime_type,
			'bytes'         => $bytes ? (int) $bytes : 0,
			'title'         => $title,
		);
	}

	/**
	 * Normalise a file stem used for edited attachments.
	 *
	 * @param string $file_name Raw file name input.
	 * @return string
	 */
	protected function normalise_file_stem( $file_name ) {
		$file_name = sanitize_file_name( (string) $file_name );

		if ( '' === $file_name ) {
			return 'gemini-image';
		}

		$info = pathinfo( $file_name );
		$stem = isset( $info['filename'] ) ? $info['filename'] : $file_name;
		$stem = sanitize_title( $stem );

		if ( '' === $stem ) {
			return 'gemini-image';
		}

		return $stem;
	}

	/**
	 * Get file extension from MIME type.
	 *
	 * @param string $mime_type MIME type.
	 * @return string
	 */
	protected function get_extension_from_mime_type( $mime_type ) {
		$mime_type = strtolower( $mime_type );

		if ( 'image/jpeg' === $mime_type || 'image/jpg' === $mime_type ) {
			return 'jpg';
		}

		return 'png';
	}

	/**
	 * Generate a human readable attachment title using the editing instruction.
	 *
	 * @param string $prompt Original editing instruction.
	 * @return string
	 */
	protected function generate_attachment_title( $prompt ) {
		$prompt = (string) $prompt;
		$prompt = preg_replace( '/\s+/', ' ', $prompt );
		$prompt = trim( $prompt );

		if ( '' === $prompt ) {
			return __( 'Gemini Edited Image', 'nvdigital-open-operator-system-oos' );
		}

		$excerpt = wp_trim_words( $prompt, 8, '…' );

		/* translators: %s: Short excerpt of the editing instruction. */
		return sprintf( __( 'Gemini Edit: %s', 'nvdigital-open-operator-system-oos' ), $excerpt );
	}

	/**
	 * Build an inline content payload for the stored image so API clients can render immediately.
	 *
	 * @param array $storage Stored attachment metadata.
	 * @return array
	 */
	protected function build_inline_content_payload( array $storage ) {
		$file_path = isset( $storage['file'] ) ? $storage['file'] : '';

		if ( '' === $file_path || ! is_readable( $file_path ) ) {
			return array();
		}

		$file_contents = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file read; WP_Filesystem not available in this context.

		if ( false === $file_contents || '' === $file_contents ) {
			return array();
		}

		$encoded = base64_encode( $file_contents );

		if ( '' === $encoded ) {
			return array();
		}

		$mime_type = isset( $storage['mime_type'] ) ? $storage['mime_type'] : '';

		$content = array(
			'encoding' => 'base64',
			'data'     => $encoded,
		);

		if ( '' !== $mime_type ) {
			$content['mime_type'] = $mime_type;
			$content['data_url']  = sprintf( 'data:%s;base64,%s', $mime_type, $encoded );
		}

		if ( isset( $storage['file_name'] ) && '' !== $storage['file_name'] ) {
			$content['file_name'] = $storage['file_name'];
		}

		if ( isset( $storage['bytes'] ) && $storage['bytes'] ) {
			$content['bytes'] = (int) $storage['bytes'];
		}

		return $content;
	}

	/**
	 * Map a MIME type to a file format identifier.
	 *
	 * @param string $mime_type MIME type string.
	 * @return string
	 */
	protected function map_mime_type_to_format( $mime_type ) {
		switch ( $mime_type ) {
			case 'image/jpeg':
				return 'jpeg';
			case 'image/webp':
				return 'webp';
			case 'image/png':
			default:
				return 'png';
		}
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'content_publishing',

			'pattern_compatibility' => array( 'sequential' ),

			'profession_tags'       => array( 'graphic_designer', 'photographer' ),

			'risk_level'            => 'standard',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'requires-credentials', // Requires Gemini API credentials.
			'requires-capability',  // Requires user capabilities.
			'write',                // Creates/modifies media files.
			'async',                // May take significant time to edit images.
			'rate-limited',         // Subject to Gemini rate limits.
			'requires-model',       // Requires image model specification.
			'consumes-tokens',      // Uses AI credits/tokens.
			'model-dependent',      // Output quality varies by model.
			'external-api',         // Downloads images from external URLs and calls Gemini API.
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_model_requirements() {
		return array(
			'image-editing', // Requires model capable of editing images.
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_tool_rules() {
		return array(
			'model_requirements'    => array(
				'providers' => array( 'gemini' ),
				'models'    => array( 'gemini-2.5-flash-image', 'gemini-exp-1206' ),
				'required'  => true,
			),
			'parameter_constraints' => array(
				'required_fields'   => array( 'prompt' ),
				'optional_fields'   => array( 'attachment_id', 'file_id', 'url', 'image_url', 'image_data', 'source_mime_type', 'model', 'aspect_ratio', 'mime_type', 'file_name', 'timeout' ),
				'max_prompt_length' => 4000,
			),
			'rate_limits'           => array(
				'requests_per_minute' => 15,
				'requests_per_hour'   => 100,
				'concurrent_requests' => 2,
			),
			'timeout_constraints'   => array(
				'recommended_timeout' => 60,
				'max_execution_time'  => 120,
			),
			'response_constraints'  => array(
				'max_size'           => 5242880, // 5MB typical image size.
				'supports_streaming' => false,
			),
			'dependencies'          => array(
				'required_settings'   => array(
					'api_key' => 'wp_mcp_ai_gemini_api_key',
				),
				'required_extensions' => array( 'gd' ), // For image processing.
			),
			'orchestration_hints'   => array(
				'can_run_parallel' => true,
				'requires_lock'    => false,
				'cache_ttl'        => 0, // Don't cache - each edit is unique.
				'retry_strategy'   => 'exponential_backoff',
				'max_retries'      => 3,
			),
		);
	}

	/**
	 * Sanitize tool result before passing to LLM.
	 *
	 * Strips large base64-encoded image data to prevent bloating the LLM context.
	 * The full result with inline content is preserved for frontend display.
	 *
	 * For the agentic loop to work with vision models, we add an image_url structure
	 * that allows the model to "see" the edited image in subsequent iterations.
	 *
	 * @param mixed $result Raw tool execution result.
	 * @return mixed Sanitized result safe for LLM context.
	 */
	public function sanitize_for_llm( $result ) {
		if ( ! is_array( $result ) ) {
			return $result;
		}

		// Strip base64 content to reduce token usage.
		if ( isset( $result['content'] ) && is_array( $result['content'] ) ) {
			unset( $result['content']['data'] );
			unset( $result['content']['data_url'] );

			if ( empty( $result['content'] ) ) {
				unset( $result['content'] );
			}
		}

		// Keep only essential metadata for LLM reasoning.
		$keep_fields = array(
			'attachment_id',
			'url',
			'download_url',
			'file_name',
			'mime_type',
			'bytes',
			'title',
			'model',
			'aspect_ratio',
			'format',           // Image format (png, jpeg, webp, svg) for chat UI rendering.
			'edit_instruction',
			'source_attachment',
			'provider',
			'usage',
			'cost',             // Cost data for UI display.
			'text',             // Descriptive message about the edited image.
			'output_format',    // Output format selected (default or svg).
			'vectorized',       // SVG vectorization flag.
			'svg_size',         // SVG file size if vectorized.
			'source_size',      // Source raster size if vectorized.
			'duration_ms',      // Vectorization duration if vectorized.
		);

		$sanitized = array();
		foreach ( $keep_fields as $key ) {
			if ( isset( $result[ $key ] ) ) {
				$sanitized[ $key ] = $result[ $key ];
			}
		}

		// Add image_url structure for the agentic loop.
		// This allows vision models to "see" the edited image in subsequent iterations.
		// Prefer download_url (if available) over url for Gemini images.
		$image_url = isset( $result['download_url'] ) && '' !== $result['download_url']
			? $result['download_url']
			: ( isset( $result['url'] ) && '' !== $result['url'] ? $result['url'] : '' );

		if ( '' !== $image_url ) {
			$sanitized['image_url'] = array(
				'url' => $image_url,
			);
		}

		return ! empty( $sanitized ) ? $sanitized : $result;
	}

	/**
	 * Decide whether to elicit an edit region from the user.
	 *
	 * Returns a markup request when:
	 *  - `request_user_region` is true; and
	 *  - no `target_region` rectangle was already supplied; and
	 *  - the source attachment resolves to an image; and
	 *  - the markup classes are available (foundation PR loaded).
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return WP_MCP_AI_Markup_Request|null
	 */
	public function needs_markup( array $arguments, array $context ) {
		if ( ! class_exists( 'WP_MCP_AI_Markup_Request' ) ) {
			return null;
		}
		if ( empty( $arguments['request_user_region'] ) ) {
			return null;
		}
		// Caller already specified the region — nothing to elicit.
		if ( ! empty( $arguments['target_region'] ) && is_array( $arguments['target_region'] ) ) {
			return null;
		}

		// Reuse the same enrichment path as execute() so
		// chat-message-derived attachment IDs are honoured here too.
		$enriched      = $this->enrich_arguments_from_messages( $arguments, $context );
		$attachment_id = isset( $enriched['attachment_id'] ) ? absint( $enriched['attachment_id'] ) : 0;
		if ( $attachment_id <= 0 ) {
			$candidate_url = '';
			if ( ! empty( $enriched['url'] ) ) {
				$candidate_url = (string) $enriched['url'];
			} elseif ( ! empty( $enriched['image_url'] ) ) {
				$candidate_url = (string) $enriched['image_url'];
			}
			if ( '' !== $candidate_url && method_exists( $this, 'resolve_attachment_id_from_url' ) ) {
				$resolved = $this->resolve_attachment_id_from_url( $candidate_url );
				if ( is_int( $resolved ) && $resolved > 0 ) {
					$attachment_id = $resolved;
				}
			}
		}
		if ( $attachment_id <= 0 || ! wp_attachment_is_image( $attachment_id ) ) {
			return null;
		}

		$meta = wp_get_attachment_metadata( $attachment_id );
		$w    = isset( $meta['width'] ) ? (int) $meta['width'] : 0;
		$h    = isset( $meta['height'] ) ? (int) $meta['height'] : 0;

		$prompt       = isset( $arguments['prompt'] ) ? sanitize_textarea_field( (string) $arguments['prompt'] ) : '';
		$instructions = '' !== $prompt
			? sprintf(
				/* translators: %s: edit prompt */
				__( 'Drag a rectangle around the area you want Gemini to edit. Prompt: %s', 'nvdigital-open-operator-system-oos' ),
				$prompt
			)
			: __( 'Drag a rectangle around the area you want Gemini to edit.', 'nvdigital-open-operator-system-oos' );

		try {
			return new WP_MCP_AI_Markup_Request(
				array(
					'tool_slug'      => $this->get_slug(),
					'target_type'    => 'image',
					'mode'           => 'region',
					'target'         => array(
						'attachment_id' => $attachment_id,
						'width'         => $w,
						'height'        => $h,
					),
					'instructions'   => $instructions,
					'tool_arguments' => $arguments,
					'tool_context'   => $context,
					'assistant_id'   => isset( $context['assistant_id'] ) ? (int) $context['assistant_id'] : 0,
				)
			);
		} catch ( Exception $e ) {
			return null;
		}
	}

	/**
	 * Resume execution with a user-painted edit region.
	 *
	 * Gemini Nano Banana does not accept a discrete mask channel like
	 * OpenAI image edit, so we communicate the region through prompt
	 * augmentation. The rasterizer returns `region_rect` as
	 * `{x, y, width, height, normalized}`. We:
	 *  1. Denormalize to pixel coordinates against the request target
	 *     dimensions when `normalized` is true.
	 *  2. Append an explicit "Apply changes only within the region
	 *     x=…, y=…, width=…, height=… (out of WxH pixels)" directive
	 *     to the prompt so the model focuses its edit on that area.
	 *  3. Persist the rect on `target_region` for downstream
	 *     observability and to short-circuit re-elicitation.
	 *  4. Clear `request_user_region` to prevent infinite loops, then
	 *     re-invoke `execute()`.
	 *
	 * @param array                   $arguments Original tool arguments.
	 * @param WP_MCP_AI_Markup_Result $result    Validated markup result.
	 * @param array                   $context   Execution context.
	 * @return mixed Tool result.
	 */
	public function consume_markup( array $arguments, WP_MCP_AI_Markup_Result $result, array $context ) {
		$rect = $result->get_artifact( 'region_rect', array() );
		if ( is_array( $rect ) && isset( $rect['width'], $rect['height'] ) && $rect['width'] > 0 && $rect['height'] > 0 ) {
			$target = $result->get_request()->get_target();
			$img_w  = isset( $target['width'] ) ? (int) $target['width'] : 0;
			$img_h  = isset( $target['height'] ) ? (int) $target['height'] : 0;

			if ( ! empty( $rect['normalized'] ) && $img_w > 0 && $img_h > 0 ) {
				$px_x = (int) round( (float) $rect['x'] * $img_w );
				$px_y = (int) round( (float) $rect['y'] * $img_h );
				$px_w = max( 1, (int) round( (float) $rect['width'] * $img_w ) );
				$px_h = max( 1, (int) round( (float) $rect['height'] * $img_h ) );
			} else {
				$px_x = (int) round( (float) $rect['x'] );
				$px_y = (int) round( (float) $rect['y'] );
				$px_w = max( 1, (int) round( (float) $rect['width'] ) );
				$px_h = max( 1, (int) round( (float) $rect['height'] ) );
			}

			$arguments['target_region'] = array(
				'x'            => $px_x,
				'y'            => $px_y,
				'width'        => $px_w,
				'height'       => $px_h,
				'image_width'  => $img_w,
				'image_height' => $img_h,
			);

			$base_prompt = isset( $arguments['prompt'] ) ? (string) $arguments['prompt'] : '';
			if ( $img_w > 0 && $img_h > 0 ) {
				$directive = sprintf(
					/* translators: 1: x, 2: y, 3: width, 4: height, 5: image width, 6: image height */
					__( 'Apply the changes only within the rectangular region at x=%1$d, y=%2$d, width=%3$d, height=%4$d (out of %5$dx%6$d pixels). Leave the rest of the image untouched.', 'nvdigital-open-operator-system-oos' ),
					$px_x,
					$px_y,
					$px_w,
					$px_h,
					$img_w,
					$img_h
				);
			} else {
				$directive = sprintf(
					/* translators: 1: x, 2: y, 3: width, 4: height */
					__( 'Apply the changes only within the rectangular region at x=%1$d, y=%2$d, width=%3$d, height=%4$d pixels. Leave the rest of the image untouched.', 'nvdigital-open-operator-system-oos' ),
					$px_x,
					$px_y,
					$px_w,
					$px_h
				);
			}

			$arguments['prompt'] = '' !== trim( $base_prompt )
				? trim( $base_prompt ) . "\n\n" . $directive
				: $directive;
		}
		// Prevent re-elicitation on the recursive call.
		$arguments['request_user_region'] = false;

		return $this->execute( $arguments, $context );
	}
}
