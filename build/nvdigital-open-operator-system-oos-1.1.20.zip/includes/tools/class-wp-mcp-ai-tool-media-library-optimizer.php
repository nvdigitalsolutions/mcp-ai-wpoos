<?php
/**
 * Media Library Optimizer Tool
 *
 * Bulk image compression, format conversion (AVIF/WebP), lazy loading
 * configuration, unused media detection, and CDN preparation.
 *
 * Based on 2026 image optimization standards from:
 * - Google PageSpeed Insights recommendations
 * - Bluehost image optimization guide
 * - WordPress.org performance best practices
 * - WisdmLabs image SEO standards
 *
 * @package    WP_MCP_AI
 * @subpackage Tools
 * @since      1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Media Library Optimizer Tool Class
 *
 * @since 1.0.0
 */
class WP_MCP_AI_Tool_Media_Library_Optimizer {
	use WP_MCP_AI_Tool_WordPress_Native;

	/**
	 * Get tool slug
	 *
	 * @since 1.0.0
	 * @return string Tool slug.
	 */
	public function get_slug() {
		return 'media_library_optimizer';
	}

	/**
	 * Get tool definition
	 *
	 * @since 1.0.0
	 * @return array Tool definition.
	 */
	public function get_definition() {
		return array(
			'name'                => __( 'Media Library Optimizer', 'nvdigital-open-operator-system-oos' ),
			'description'         => __( 'Bulk image compression, AVIF/WebP conversion, lazy loading, unused media detection, and CDN preparation following 2026 standards.', 'nvdigital-open-operator-system-oos' ),
			'category'            => 'media',
			'required_capability' => 'upload_files',
			'parameters'          => array(
				'action'            => array(
					'type'        => 'string',
					'description' => __( 'Action: analyze, compress, convert, detect_unused, or configure_lazy_loading', 'nvdigital-open-operator-system-oos' ),
					'required'    => true,
					'enum'        => array( 'analyze', 'compress', 'convert', 'detect_unused', 'configure_lazy_loading' ),
				),
				'target_format'     => array(
					'type'        => 'string',
					'description' => __( 'Target format for conversion: avif, webp, or auto', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'auto',
					'enum'        => array( 'avif', 'webp', 'auto' ),
				),
				'quality'           => array(
					'type'        => 'integer',
					'description' => __( 'Compression quality (1-100, default: 85)', 'nvdigital-open-operator-system-oos' ),
					'default'     => 85,
					'minimum'     => 1,
					'maximum'     => 100,
				),
				'limit'             => array(
					'type'        => 'integer',
					'description' => __( 'Number of images to process (default: 50)', 'nvdigital-open-operator-system-oos' ),
					'default'     => 50,
				),
				'max_items'         => array(
					'type'        => 'integer',
					'description' => __( 'Maximum total images to scan during analyze / detect_unused (default: 500). Filterable via wp_mcp_ai_tool_max_items.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 500,
				),
				'age_days'          => array(
					'type'        => 'integer',
					'description' => __( 'Age in days for unused media detection (default: 180)', 'nvdigital-open-operator-system-oos' ),
					'default'     => 180,
				),
				'preserve_original' => array(
					'type'        => 'boolean',
					'description' => __( 'Keep original files when converting', 'nvdigital-open-operator-system-oos' ),
					'default'     => true,
				),
			),
		);
	}

	/**
	 * Execute the tool
	 *
	 * @since 1.0.0
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array Tool execution result.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Validate parameters.
		$action            = isset( $arguments['action'] ) ? sanitize_text_field( $arguments['action'] ) : 'analyze';
		$target_format     = isset( $arguments['target_format'] ) ? sanitize_text_field( $arguments['target_format'] ) : 'auto';
		$quality           = isset( $arguments['quality'] ) ? absint( $arguments['quality'] ) : 85;
		$limit             = isset( $arguments['limit'] ) ? absint( $arguments['limit'] ) : 50;
		$age_days          = isset( $arguments['age_days'] ) ? absint( $arguments['age_days'] ) : 180;
		$preserve_original = isset( $arguments['preserve_original'] ) ? (bool) $arguments['preserve_original'] : true;
		$max_items         = WP_MCP_AI_Tool_Artifact_Helper::resolve_max_items(
			$this->get_slug(),
			isset( $arguments['max_items'] ) ? absint( $arguments['max_items'] ) : 0,
			500
		);

		// Validate quality.
		$quality = max( 1, min( 100, $quality ) );

		// Before execution hook.
		$this->do_before_execute( $arguments, $context );

		// Route to action handler.
		switch ( $action ) {
			case 'analyze':
				$result = $this->handle_analyze( $max_items );
				break;

			case 'compress':
				$result = $this->handle_compress( $quality, $limit );
				break;

			case 'convert':
				$result = $this->handle_convert( $target_format, $quality, $limit, $preserve_original );
				break;

			case 'detect_unused':
				$result = $this->handle_detect_unused( $age_days, $max_items );
				break;

			case 'configure_lazy_loading':
				$result = $this->handle_lazy_loading();
				break;

			default:
				$result = array(
					'success' => false,
					'error'   => __( 'Invalid action specified', 'nvdigital-open-operator-system-oos' ),
				);
		}

		// After execution hook.
		$this->do_after_execute( $result, $arguments, $context );

		return $this->apply_result_filter( $result, $arguments, $context );
	}

	/**
	 * Handle analyze action
	 *
	 * @since 1.0.0
	 *
	 * @param int $max_items Maximum images to scan (clamped via wp_mcp_ai_tool_max_items).
	 * @return array Analysis result.
	 */
	private function handle_analyze( $max_items = 500 ) {
		$total_images  = 0;
		$total_size    = 0;
		$format_counts = array(
			'jpeg'  => 0,
			'png'   => 0,
			'gif'   => 0,
			'webp'  => 0,
			'avif'  => 0,
			'other' => 0,
		);

		$optimization_opportunities = array();

		// Use the Phase 1 batch iterator to keep memory bounded for libraries
		// with tens of thousands of attachments.
		$iterator = new WP_MCP_AI_Batch_Iterator(
			'media_library_optimizer_analyze',
			array( 'max_items' => $max_items )
		);

		$query_args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'fields'         => 'ids',
		);

		foreach ( $iterator->paged_iterate( $query_args ) as $batch ) {
			foreach ( $batch as $image_id ) {
				$file_path = get_attached_file( $image_id );
				if ( ! $file_path || ! file_exists( $file_path ) ) {
					continue;
				}

				++$total_images;
				$file_size   = filesize( $file_path );
				$total_size += $file_size;

				$mime_type = get_post_mime_type( $image_id );
				$format    = $this->mime_to_format( $mime_type );
				if ( isset( $format_counts[ $format ] ) ) {
					++$format_counts[ $format ];
				} else {
					++$format_counts['other'];
				}

				if ( $file_size > 500000 ) { // >500KB.
					$optimization_opportunities[] = array(
						'id'          => $image_id,
						'file'        => basename( $file_path ),
						'size'        => $file_size,
						'size_human'  => size_format( $file_size ),
						'format'      => $format,
						'reason'      => __( 'Large file size', 'nvdigital-open-operator-system-oos' ),
						'recommended' => 'png' === $format ? 'avif' : 'webp',
					);
				}
			}
		}

		$iterator->complete();

		$result = array(
			'success'                     => true,
			'summary'                     => array(
				'total_images'       => $total_images,
				'total_size'         => $total_size,
				'total_size_human'   => size_format( $total_size ),
				'average_size'       => $total_images > 0 ? round( $total_size / $total_images ) : 0,
				'average_size_human' => size_format( $total_images > 0 ? round( $total_size / $total_images ) : 0 ),
				'scanned_cap'        => $max_items,
			),
			'format_distribution'         => $format_counts,
			'total_opportunities'         => count( $optimization_opportunities ),
			'estimated_savings_potential' => $this->estimate_savings( $total_size, $format_counts ),
			'recommendations'             => $this->generate_optimization_recommendations( $format_counts, $total_images ),
		);

		// Stream large opportunity lists to an artifact instead of inlining
		// hundreds of rows in the LLM context.
		if ( WP_MCP_AI_Tool_Artifact_Helper::should_stream_to_artifact( count( $optimization_opportunities ), $this->get_slug() ) ) {
			$result['optimization_opportunities_artifact'] = WP_MCP_AI_Tool_Artifact_Helper::stream_to_artifact(
				$optimization_opportunities,
				$this->get_slug(),
				array(
					'count'   => count( $optimization_opportunities ),
					'summary' => sprintf(
						/* translators: %d: opportunity count */
						__( '%d optimization opportunities streamed to artifact.', 'nvdigital-open-operator-system-oos' ),
						count( $optimization_opportunities )
					),
				)
			);
			$result['optimization_opportunities'] = array_slice( $optimization_opportunities, 0, 20 );
		} else {
			$result['optimization_opportunities'] = array_slice( $optimization_opportunities, 0, 20 );
		}

		return $result;
	}

	/**
	 * Handle compress action
	 *
	 * @since 1.0.0
	 * @param int $quality Compression quality.
	 * @param int $limit   Number to process.
	 * @return array Compression result.
	 */
	private function handle_compress( $quality, $limit ) {
		// Get images to compress.
		$images = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'posts_per_page' => $limit,
				'post_status'    => 'inherit',
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- meta_query required to filter media by optimization status meta; no alternative index-based query available.
					array(
						'key'     => '_wp_mcp_ai_compressed',
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);

		$compressed  = 0;
		$failed      = 0;
		$total_saved = 0;
		$details     = array();

		foreach ( $images as $image_id ) {
			$file_path = get_attached_file( $image_id );
			if ( ! file_exists( $file_path ) ) {
				++$failed;
				continue;
			}

			$original_size = filesize( $file_path );

			// Compress image.
			$compressed_result = $this->compress_image( $file_path, $quality );

			if ( $compressed_result['success'] ) {
				$new_size     = filesize( $file_path );
				$saved        = $original_size - $new_size;
				$total_saved += $saved;

				update_post_meta( $image_id, '_wp_mcp_ai_compressed', true );
				update_post_meta( $image_id, '_wp_mcp_ai_compression_quality', $quality );

				$details[] = array(
					'id'            => $image_id,
					'file'          => basename( $file_path ),
					'original_size' => size_format( $original_size ),
					'new_size'      => size_format( $new_size ),
					'saved'         => size_format( $saved ),
					'reduction'     => round( ( $saved / $original_size ) * 100, 2 ) . '%',
				);

				++$compressed;
			} else {
				++$failed;
			}
		}

		return array(
			'success'     => true,
			'processed'   => $compressed + $failed,
			'compressed'  => $compressed,
			'failed'      => $failed,
			'total_saved' => size_format( $total_saved ),
			'quality'     => $quality,
			'details'     => $details,
		);
	}

	/**
	 * Handle convert action
	 *
	 * @since 1.0.0
	 * @param string $target_format     Target format.
	 * @param int    $quality           Conversion quality.
	 * @param int    $limit             Number to process.
	 * @param bool   $preserve_original Keep originals.
	 * @return array Conversion result.
	 */
	private function handle_convert( $target_format, $quality, $limit, $preserve_original ) {
		// Determine best format.
		if ( 'auto' === $target_format ) {
			// AVIF is best (85% smaller than PNG, 50% smaller than WebP).
			// But check for browser support via WordPress.
			$target_format = wp_image_editor_supports( array( 'mime_type' => 'image/avif' ) ) ? 'avif' : 'webp';
		}

		// Get images to convert.
		$images = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => array( 'image/jpeg', 'image/png' ),
				'posts_per_page' => $limit,
				'post_status'    => 'inherit',
				'fields'         => 'ids',
			)
		);

		$converted   = 0;
		$failed      = 0;
		$total_saved = 0;
		$details     = array();

		foreach ( $images as $image_id ) {
			$file_path = get_attached_file( $image_id );
			if ( ! file_exists( $file_path ) ) {
				++$failed;
				continue;
			}

			$original_size = filesize( $file_path );

			// Convert image.
			$convert_result = $this->convert_image_format( $file_path, $target_format, $quality, $preserve_original );

			if ( $convert_result['success'] ) {
				$new_file     = $convert_result['new_file'];
				$new_size     = filesize( $new_file );
				$saved        = $original_size - $new_size;
				$total_saved += $saved;

				// Update attachment.
				update_attached_file( $image_id, $new_file );
				wp_update_post(
					array(
						'ID'             => $image_id,
						'post_mime_type' => $convert_result['mime_type'],
					)
				);

				$details[] = array(
					'id'            => $image_id,
					'original_file' => basename( $file_path ),
					'new_file'      => basename( $new_file ),
					'format'        => $target_format,
					'original_size' => size_format( $original_size ),
					'new_size'      => size_format( $new_size ),
					'saved'         => size_format( $saved ),
					'reduction'     => round( ( $saved / $original_size ) * 100, 2 ) . '%',
				);

				++$converted;
			} else {
				++$failed;
			}
		}

		return array(
			'success'           => true,
			'processed'         => $converted + $failed,
			'converted'         => $converted,
			'failed'            => $failed,
			'target_format'     => $target_format,
			'quality'           => $quality,
			'preserve_original' => $preserve_original,
			'total_saved'       => size_format( $total_saved ),
			'details'           => $details,
		);
	}

	/**
	 * Handle detect unused action
	 *
	 * @since 1.0.0
	 *
	 * @param int $age_days  Age threshold.
	 * @param int $max_items Maximum attachments to scan.
	 * @return array Unused detection result.
	 */
	private function handle_detect_unused( $age_days, $max_items = 500 ) {
		global $wpdb;

		$cutoff_date = gmdate( 'Y-m-d H:i:s', strtotime( "-{$age_days} days" ) );

		$iterator = new WP_MCP_AI_Batch_Iterator(
			'media_library_optimizer_detect_unused',
			array( 'max_items' => $max_items )
		);

		$query_args = array(
			'post_type'   => 'attachment',
			'post_status' => 'inherit',
			'fields'      => 'ids',
			'date_query'  => array(
				array(
					'before' => $cutoff_date,
				),
			),
		);

		$unused        = array();
		$total_size    = 0;
		$total_checked = 0;

		foreach ( $iterator->paged_iterate( $query_args ) as $batch ) {
			foreach ( $batch as $attachment_id ) {
				++$total_checked;
				$parent_id = wp_get_post_parent_id( $attachment_id );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query required for performance-critical aggregation; WP_Query does not support LIKE on post_content of this shape.
				$used_count = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_content LIKE %s AND post_status = 'publish'",
						'%' . $wpdb->esc_like( wp_get_attachment_url( $attachment_id ) ) . '%'
					)
				);

				if ( 0 === $parent_id && 0 === (int) $used_count ) {
					$file_path = get_attached_file( $attachment_id );
					$file_size = $file_path && file_exists( $file_path ) ? filesize( $file_path ) : 0;

					$unused[] = array(
						'id'            => $attachment_id,
						'title'         => get_the_title( $attachment_id ),
						'url'           => wp_get_attachment_url( $attachment_id ),
						'file'          => $file_path ? basename( $file_path ) : '',
						'size'          => size_format( $file_size ),
						'uploaded_date' => get_the_date( 'Y-m-d', $attachment_id ),
						'age_days'      => floor( ( time() - get_post_time( 'U', false, $attachment_id ) ) / DAY_IN_SECONDS ),
					);

					$total_size += $file_size;
				}
			}
		}

		$iterator->complete();

		$result = array(
			'success'            => true,
			'age_threshold_days' => $age_days,
			'total_checked'      => $total_checked,
			'unused_count'       => count( $unused ),
			'unused_total_size'  => size_format( $total_size ),
			'potential_savings'  => size_format( $total_size ),
			'recommendations'    => array(
				__( 'Review unused media before deletion', 'nvdigital-open-operator-system-oos' ),
				__( 'Consider backup before bulk deletion', 'nvdigital-open-operator-system-oos' ),
				__( 'Some media may be used in widgets or theme templates', 'nvdigital-open-operator-system-oos' ),
			),
		);

		if ( WP_MCP_AI_Tool_Artifact_Helper::should_stream_to_artifact( count( $unused ), $this->get_slug() ) ) {
			$result['unused_media_artifact'] = WP_MCP_AI_Tool_Artifact_Helper::stream_to_artifact(
				$unused,
				$this->get_slug(),
				array(
					'count'   => count( $unused ),
					'summary' => sprintf(
						/* translators: %d: unused media row count */
						__( '%d unused media items streamed to artifact.', 'nvdigital-open-operator-system-oos' ),
						count( $unused )
					),
				)
			);
			$result['unused_media'] = array_slice( $unused, 0, 20 );
		} else {
			$result['unused_media'] = array_slice( $unused, 0, 100 );
		}

		return $result;
	}

	/**
	 * Handle lazy loading configuration
	 *
	 * @since 1.0.0
	 * @return array Lazy loading result.
	 */
	private function handle_lazy_loading() {
		// WordPress 5.5+ has native lazy loading.
		$wp_lazy_loading = version_compare( get_bloginfo( 'version' ), '5.5', '>=' );

		return array(
			'success'          => true,
			'wordpress_native' => $wp_lazy_loading,
			'status'           => $wp_lazy_loading
				? __( 'WordPress native lazy loading is enabled', 'nvdigital-open-operator-system-oos' )
				: __( 'Consider upgrading WordPress for native lazy loading', 'nvdigital-open-operator-system-oos' ),
			'recommendations'  => array(
				__( 'WordPress 5.5+ includes native lazy loading', 'nvdigital-open-operator-system-oos' ),
				__( 'Add loading="lazy" attribute to images automatically', 'nvdigital-open-operator-system-oos' ),
				__( 'Consider plugins like Lazy Load by WP Rocket for advanced features', 'nvdigital-open-operator-system-oos' ),
				__( 'Test Core Web Vitals after enabling', 'nvdigital-open-operator-system-oos' ),
			),
		);
	}

	/**
	 * Compress image
	 *
	 * @since 1.0.0
	 * @param string $file_path File path.
	 * @param int    $quality   Quality level.
	 * @return array Compression result.
	 */
	private function compress_image( $file_path, $quality ) {
		$image_editor = wp_get_image_editor( $file_path );

		if ( is_wp_error( $image_editor ) ) {
			return array( 'success' => false );
		}

		$image_editor->set_quality( $quality );
		$saved = $image_editor->save( $file_path );

		if ( is_wp_error( $saved ) ) {
			return array( 'success' => false );
		}

		return array( 'success' => true );
	}

	/**
	 * Convert image format
	 *
	 * @since 1.0.0
	 * @param string $file_path         File path.
	 * @param string $target_format     Target format.
	 * @param int    $quality           Quality level.
	 * @param bool   $preserve_original Keep original.
	 * @return array Conversion result.
	 */
	private function convert_image_format( $file_path, $target_format, $quality, $preserve_original ) {
		$image_editor = wp_get_image_editor( $file_path );

		if ( is_wp_error( $image_editor ) ) {
			return array( 'success' => false );
		}

		$image_editor->set_quality( $quality );

		// Determine new file path.
		$path_info = pathinfo( $file_path );
		$extension = 'avif' === $target_format ? 'avif' : 'webp';
		$new_file  = $path_info['dirname'] . '/' . $path_info['filename'] . '.' . $extension;

		// Set output format.
		$mime_types = array(
			'avif' => 'image/avif',
			'webp' => 'image/webp',
		);
		$mime_type  = isset( $mime_types[ $target_format ] ) ? $mime_types[ $target_format ] : 'image/webp';

		$saved = $image_editor->save( $new_file, $mime_type );

		if ( is_wp_error( $saved ) ) {
			return array( 'success' => false );
		}

		// Delete original if not preserving.
		if ( ! $preserve_original && file_exists( $file_path ) ) {
			wp_delete_file( $file_path );
		}

		return array(
			'success'   => true,
			'new_file'  => $new_file,
			'mime_type' => $mime_type,
		);
	}

	/**
	 * Convert MIME type to format
	 *
	 * @since 1.0.0
	 * @param string $mime_type MIME type.
	 * @return string Format name.
	 */
	private function mime_to_format( $mime_type ) {
		$formats = array(
			'image/jpeg' => 'jpeg',
			'image/jpg'  => 'jpeg',
			'image/png'  => 'png',
			'image/gif'  => 'gif',
			'image/webp' => 'webp',
			'image/avif' => 'avif',
		);

		return isset( $formats[ $mime_type ] ) ? $formats[ $mime_type ] : 'other';
	}

	/**
	 * Estimate savings potential
	 *
	 * @since 1.0.0
	 * @param int   $total_size    Total size.
	 * @param array $format_counts Format distribution.
	 * @return array Savings estimate.
	 */
	private function estimate_savings( $total_size, $format_counts ) {
		// AVIF: ~85% smaller than PNG, ~50% smaller than JPEG.
		// WebP: ~30% smaller than JPEG, ~80% smaller than PNG.

		$jpeg_count = $format_counts['jpeg'];
		$png_count  = $format_counts['png'];

		$estimated_avif_savings = ( $jpeg_count * 0.50 + $png_count * 0.85 ) * ( $total_size / array_sum( $format_counts ) );
		$estimated_webp_savings = ( $jpeg_count * 0.30 + $png_count * 0.80 ) * ( $total_size / array_sum( $format_counts ) );

		return array(
			'avif_potential' => size_format( $estimated_avif_savings ),
			'webp_potential' => size_format( $estimated_webp_savings ),
		);
	}

	/**
	 * Generate optimization recommendations
	 *
	 * @since 1.0.0
	 * @param array $format_counts Format counts.
	 * @param int   $total_images  Total images.
	 * @return array Recommendations.
	 */
	private function generate_optimization_recommendations( $format_counts, $total_images ) {
		$recommendations = array();

		if ( $format_counts['png'] > $total_images * 0.3 ) {
			$recommendations[] = __( 'High PNG usage detected. Consider converting to AVIF for 85% size reduction.', 'nvdigital-open-operator-system-oos' );
		}

		if ( $format_counts['jpeg'] > $total_images * 0.5 ) {
			$recommendations[] = __( 'Many JPEG images detected. WebP conversion can save ~30% file size.', 'nvdigital-open-operator-system-oos' );
		}

		if ( $format_counts['gif'] > 0 ) {
			$recommendations[] = __( 'GIF images detected. Consider converting to video formats (MP4, WebM) for animations.', 'nvdigital-open-operator-system-oos' );
		}

		if ( 0 === $format_counts['avif'] && 0 === $format_counts['webp'] ) {
			$recommendations[] = __( 'No modern formats detected. AVIF/WebP conversion highly recommended.', 'nvdigital-open-operator-system-oos' );
		}

		$recommendations[] = __( 'Enable lazy loading for images below the fold (WordPress 5.5+).', 'nvdigital-open-operator-system-oos' );
		$recommendations[] = __( 'Consider CDN for image delivery to reduce server load.', 'nvdigital-open-operator-system-oos' );
		$recommendations[] = __( 'Regularly audit and remove unused media files.', 'nvdigital-open-operator-system-oos' );

		return $recommendations;
	}

	/**
	 * Check if tool has privacy data
	 *
	 * @since 1.0.0
	 * @return bool False - no privacy data.
	 */
	public function has_privacy_data() {
		return false;
	}
}
