# NV oOS Plugin Skill - Release Notes (v1.1.66 to v1.2.17)

Moved out of SKILL.md to stay under the Zed 100KB skill-size limit.
Operational content stays in SKILL.md; append new per-version sections here.

---

---

## Astro Checkout Wave, Document OCR, November Model Catalog (v1.2.17)

- **No plugin-side tool or route changes** (PRs #7395–#7445) — zero tool-registry diff in-window; `fleet-stats` is a Pro REST route and the bridge/storefront surfaces are addon/app-side. The actionable ops content:
- **November model catalog** (PRs #7416/#7417/#7440) — catalog **v2026.11.03**, 251 models, 18 providers: `default_model` → `gpt-6.1-sol`, selector light/advanced `gpt-6-luna`/`gpt-6.1-sol`, `gemini_image_model` → `gemini-nano-banana-2.1`, high-token fallback `gemini-3.5-flash-lite`; the gpt-4o/4.1 family deprecates (shutdown 2027-01-14, `gpt-4.1-nano` removed with the migration-map entry); the migration rewrites stored references once per catalog version bump. Ops lesson: never assert an image-model identity via an `"image"` substring — use an allowlist (the #7440 fragile-check rule).
- **Astro Bridge** (addon 1.1.3 — three in-window bumps) — the settings page (product source native/woo/both + Woo SSO + System status) pins its capability to `manage_astro`, not `manage_options`; `migrate-native` is dry-run by default (`--run` confirm); the Store API dispatches in-process; the checkout routes are typed 502s. Storefront 0.4.2, gateway 0.3.1, new `claude-gateway-plugin` 0.1.0 addon.
- **Sub-projects** — Cognition: Document OCR (Proposal 109) + DeepSeek-OCR tier (Proposal 111 — Ollama native `/api/chat`; the OpenAI-compat mount drops image features for `deepseekocr`); forge/wp.org state recorded in the astro-forge + wporg-submission skills.

## Deep-Research Reliability + Job Tools, Abilities MCP Adapter Interop, Gateway OAuth Go-Live (v1.2.16)

- **`deep_research` hardening + three new base job tools** (PRs #7376/#7377/#7384) — reports must pass a validation gate (finished answer, supported findings, usable citations; one retry-with-feedback, then explicit `status: partial`); depth is measurable (`basic` 1/0, `standard` 3/2, `comprehensive` 6/5 — `wp_mcp_ai_deep_research_max_queries` caps it, `queries_used` reports it); evidence persists between search and synthesis. The new `research_status`/`research_result`/`research_cancel` tools drive background jobs (24 h expiry). The **`deep_research_model`** setting (Tools → Configuration, `provider:model` + Auto) now exists; the hardcoded `gpt-4.1` fallback is `gpt-5.6-sol`. Thinking-model ops lesson: DeepSeek thinking-mode shares the token budget with the answer — reasoning-only output retries with a ×4 budget (cap 32,768) before falling back (the same ladder ships as the Pro research `WP_MCP_AI_Tool_Research_Completion` trait).
- **Abilities bridge ↔ official MCP Adapter interop** (PR #7383) — `execute_callback` returns the raw `WP_Error` (adapter marks `isError: true`; the legacy `{success:false}` envelope stays behind `wp_mcp_ai_ability_wp_error_passthrough`); annotation mapping is pessimistic — un-flagged tools advertise `destructiveHint: true`. Ops lesson: Elementor 4.3+ registers `__return_false` on `mcp_adapter_create_default_server` (disables the adapter's default server) — the `mcp_adapter_init` custom-server pattern is the verified workaround.
- **Gateway OAuth 2.1 / ChatGPT connector live** (PRs #7373/#7375/#7381, Proposal 099 Phases 0–4) — Auth0 `nvoos.us.auth0.com`, dual-mode with static keys. Ops: `GATEWAY_OAUTH_DEFAULT_SITES` grants fallback slugs to OAuth tokens without a `site:<slug>` scope (ChatGPT requests all AS-metadata scopes; unknown slugs fail boot, explicit scopes win); `tools/list` now emits `_`-namespaced names (`demo_get_environment_status` — dots are illegal in the MCP grammar and ChatGPT mangles them); the OpenAI challenge route serves behind `GATEWAY_OPENAI_CHALLENGE_TOKEN` (404 until set). Gateway **0.3.0** — the version constant is aligned with `package.json` again.
- **New addons** — `chatgpt-gateway-plugin` 0.1.0 (Proposal 101 — the public-directory entry locked to `https://mcp.nvoos.pro/mcp`, `demo_*` skills, canonical-URL validate gate); chatgpt-plugin → 0.2.0 (full submission metadata, #7379).
- **Sub-projects** — dictate → **NV oOS Cognition v0.3.0** (#7387: user-facing rebrand only — `nvoos-dictate` identifiers stay for updater/keychain continuity; `sync-nvoos-cognition.yml` mirror); the Assistant tab opens the console in a first-party window (WebView2 blocks third-party cookies — the iframe sign-in root-fix, #7386); on-device screen OCR (#7380). Forge Bridge wp.org pass (#7388: POST-only verify, `edit_pages` minting, delete/trash hooks, 30/30) + forge npm 0.1.1 (#7391: esbuild `dist/` bins).
- **Zed skill-catalog budget** (#7378) — the summed `description:` frontmatter must stay under ~50 KB or Zed silently drops the alphabetical tail; currently ~46.3 KB. Re-sum after every skill addition.

## Astro Forge Ships, Design-Language Import, Gateway Live on the MCP Registry (v1.2.15)

- **Astro Forge is the generator sibling of the 092/095 storefront** (Proposal 096, PRs #7335–#7344) — `examples/nvoos-astro-forge` turns any WP/Woo site into an Astro 7 frontend (loader-first, webhook → rebuild freshness). Operational: auth lives in the **vault** (`~/.nvoos-forge/vault.json`, AES-256-GCM, `NVOOS_FORGE_VAULT_KEY`; `forge vault set` reads secrets on stdin never argv); the `/mcp` surface fails closed without `NVOOS_FORGE_MCP_TOKEN` (401 `-32001`); the SSRF guard needs `NVOOS_FORGE_OPEN_ANALYZE=1` for arbitrary hosts (loopback is CLI-only). The companion plugin **`plugins/nvoos-forge-bridge` 0.1.0** is a sub-project (own track): HMAC-signed rebuild webhooks (`X-Forge-Signature`, constant-time), 15-minute preview tokens, own PHPUnit workflow.
- **Gateway is live on the official MCP Registry** (PRs #7345–#7349) — `io.github.nvdigitalsolutions/nvoos-mcp-gateway` v0.2.0. Ops lessons: the runtime `VERSION` marker must track `package.json` (the health test now enforces it — a live 0.2.0 build once reported 0.1.1); registry descriptions cap at 100 chars; set `PUBLIC_SITE_SLUGS=demo` in the Velocity env so the unauthenticated `/health` stops advertising private client slugs (typo'd slugs warn at boot, never fatal).
- **The npx MCP bridge can now drive session-gated write surfaces** (PR #7328, npm 0.1.0-alpha.5) — `MCP_AI_LOGIN_URL` + `MCP_AI_LOGIN_EMAIL`/`_PASSWORD` bootstrap a manager session (cookies attached to every upstream request, one 401/403 re-establishment). SDK-v2 servers need the dual-media-type `Accept` header; SSE-framed responses get unwrapped.
- **Console brands from the WordPress site title** (PR #7321) — `siteName` flows through `WP_MCP_AI_Pro_SPA_Config::build()`; the nav logo + tab title render the first three words with the `NV oOS Complete` fallback.
- **NDS addon DTCG importer** (PR #7322) — `prepare()` + all-or-nothing `import()`, 256 KB cap, `{core.x}` references rejected; the admin import surface + 10-test suite ship **without an addon version bump** (0.3.0 stays).
- **Skills:** two new coding-time skills (`astro-forge`, `gateway-ops` — 79 → 81) and a client-reference scrub across seven design/mcp skills (PR #7336).

## Astro Storefront Lands, Bridge Rename + /manage Cookie-Auth Restored, F&B Multi-Connection, Gateway Policy Layer (v1.2.14)

- **The /manage cookie-auth outage (PRs #7306/#7307)** — on single-site HTTPS no cookie authenticates `/wp-json` before `rest_cookie_check_errors()` runs; the secure auth cookie is path-scoped to `/wp-admin`, and whenever the logged-in cookie DOES validate, `auth_cookie_valid` flips `$wp_rest_auth_cookie`, which force-resets nonce-less requests to user 0. Symptom: login 200 with `canManage:true`, then every follow-up 401/403s while wp-admin works. The bridge (renamed **nvoos-astro-bridge 1.0.1**) now re-resolves the session from the logged-in cookie inside its permission callbacks and mints `/auth/nonce` for the restored session (guest-minted nonces fail verification once the session resolves — the 403-every-collection follow-up). Same trap applies to ANY custom REST cookie-auth surface on fleet HTTPS sites.
- **Proposals 092/093/094/095 shipped** — the Astro storefront + standalone Astro CMS `/manage` + Woo product source + ADS tokens + `nvoos-astro-mcp`; F&B multi-connection Drive routing; the MCP gateway policy & governance layer (addon 0.2.0). Commerce sync toolkits now render as E-Commerce subtabs (`subtab_of`; `register_tab()` merges over existing definitions).
- **Ops notes** — deploying the bridge ZIP to a Linux backend: build it with Python `zipfile` (forward slashes); PowerShell `Compress-Archive` backslash entries install into a random-suffix container. NEVER delete the bridge via wp-admin (uninstall.php wipes the live catalog + caps); updates go through the "Replace current with uploaded" step. wp-admin uploads via curl need a browser UA + Referer (Cloudflare JS challenge blocks bare curl).

## Dify Parity Gap-Fill, Console Pagination, Session Identity & OAuth Hardening (v1.2.13)

- **`GET /mcp-ai/v1/session/me` (PR #7257)** — the requesting session's identity (id/name/slug + role capability map) without core's `list_users` gate on `users/me?context=edit`; same no-nonce/no-capability contract as `/session/nonce` (401 without a valid auth cookie, `no-store`). The Complete Console's view-context fallback uses it to recover capabilities so nav gating works for non-admin roles (server still enforces everything).
- **Breeze cache integration (PR #7257)** — `includes/integrations/class-wp-mcp-ai-breeze-cache-integration.php` appends `/dashboard/` + `/wp-admin/` to Breeze's `breeze_exclude_urls` (self-gated on `BREEZE_VERSION`, filterable via `wp_mcp_ai_breeze_cache_excluded_urls`) so cached logged-in page renders can't leak session-bound nonces. Plugin-level only — Cloudways platform cache and Cloudflare zone rules are separate layers.
- **Console stale-nonce boot fix (PR #7257, examples/nvoos-complete-velocity)** — `fetchSessionNonce()` mints from `session/nonce` first (the `/wp-admin/` scrape is fallback-only — cached `/dashboard/` HTML embedded nonces from earlier sessions) and `fetchCurrentUser()` returns `{ user, nonce }` so the 403-fallback's recovered nonce reaches the runtime. Closes the author-role "Cookie check failed" wall (403 `rest_cookie_invalid_nonce`).
- **Console access gating (PR #7259)** — the console endpoint map mirrors `WP_MCP_AI_Pro_SPA_Config::build()`'s capability matrix (admin-gated endpoints are empty strings for non-admin sessions); central `can()`/`usePermissions()` in spa-v2 (`src/auth/permissions.ts`); HITL approval bar, assistants create/edit/delete, and the dashboard command-center section gated to `manage_options`.
- **Console pagination + loading states (PRs #7239/#7255)** — one accessible pager (USWDS / W3C APG: nav landmark, native buttons, `aria-current`, disabled boundaries, polite "Showing X–Y of Z" live region, page-size selector, ellipsis collapse) with **true totals** on every server-side-paged table (records, chat channels, approvals, paper store, operations); the `/approvals` envelope now returns the pending-queue depth + `offset`; the remote records proxy forwards `page` and reports `total`/`total_pages`; keep-previous-data loading states (dimmed stale rows, `aria-busy`, inline spinner). Client-side paging stays for Blueprints + tools.
- **Dify parity gap-fill (PRs #7246/#7247, Proposal 091)** — **Workflow DSL export/import:** `WP_MCP_AI_Workflow_DSL_Codec` (v1 envelope `dsl_version`, validation findings — errors block, warnings don't —, credential redaction by default, canonicalization, `accept_legacy_json()` gate); DSL-aware REST routes (`dry_run`, `dsl` string input, `source: native|dify`, `POST /orchestration/workflows/export` by source); `wp mcp-ai workflow export|import|validate`; the base admin DAG-builder UI; the Pro DSL bridge (presets export directly + the one-way best-effort Dify import adapter with honest `foreign` stubs); Pro SPA export buttons + the dry-run findings import panel. **Prompt versioning lite:** `WP_MCP_AI_Prompt_Versions` (immutable snapshots on save, restore/promote, 50-version cap) + `GET/POST /mcp-ai/v1/assistants/{id}/prompt-versions[/{v}/restore|promote]` + WP-CLI + the Pro version-picker metabox. **Fallback chains:** the `lib/core` ProviderRouter gains ordered chains, provider cooldowns, `Retry-After` honoring; assistant meta wins over the global default; Pro SPA picker. **Observability:** `gen_ai.*` spans (OTel conventions) + opt-in off-by-default OTLP exporter; the annotation store (transcript post meta, D5) + REST controller; `export_annotation_dataset` (+1 Pro) + the AI Observability dashboard.
- **OTLP endpoint deny-list (PR #7251)** — the Pro `update_option` tool's `DENIED_OPTIONS` const (`wp_mcp_ai_otlp_endpoint`) checked **before** the `wp_mcp_ai_*` prefix allowlist — the tracing sink stays out of AI-tool reach even for `manage_options` sessions (DifyTap CVE-2026-41947 class); admin configuration stays available via the `wp_mcp_ai_otlp_endpoint` filter or WP-CLI; any future OTLP settings UI keeps `manage_options` + `validate_endpoint()`.
- **OAuth authorize-URL encoding (PR #7242)** — `add_query_arg()` leaves array values **unencoded**, so every authorize URL sent the `redirect_uri` value with a raw `&`; providers truncated the URI → `redirect_uri_mismatch` (verified live on scm.nvdigital.solutions 2026-10-26). Every builder now `rawurlencode()`s the `redirect_uri` value + `scope` (Pro Remote Sites starts + Gmail direct link, `WP_MCP_AI_Google_OAuth_Service::build_authorize_url()`, the base `WP_MCP_AI_OAuth_Manager::build_google_oauth_url()`; CG Pro + CG-AI platform mirrors byte-identical). `wp_sanitize_redirect()` preserves percent-encoding; token-exchange POST bodies keep the decoded form.
- **Bare-URL OAuth return fallback (PR #7240)** — `handle_actions()` routes a return with `state` + `code`/`error` but no `oauth_handler` to the matching callback when a live per-service OAuth state transient exists (all eight Remote Sites flows; Composio excluded — hosted `session_uri` flow). CSRF posture unchanged. State transient keys: `wp_mcp_ai_{gmail|google_drive|google_chat|teams|upwork|linkedin}_oauth_state_<md5(state)>` + the shared-service `wp_mcp_ai_google_calendar_remote_oauth_state_…` / `wp_mcp_ai_google_classroom_remote_oauth_state_…`.
- **Drive auto-fallback (PR #7244)** — `search_drive`/`get_drive_file` without `connection_id` auto-resolve to the only enabled Remote Sites `google_drive` connection with complete credentials when settings credentials are absent (multiple enabled → actionable ambiguity error listing candidates; disabled/incomplete never picked; settings credentials keep priority; resolved connection ID/name surfaced in tool responses). The Drive settings page lists Remote Sites Drive connections with a neutral status instead of the misleading red "Credentials Required" box.
- **Remote Sites assistant scoping (PR #7258)** — all 12 connection families (Drive, Gmail, Calendar, Classroom, FlowHub, Printful, Composio, Upwork, LinkedIn, PayHere, QuickBooks, iSAMS) honor the assistant's Remote Site Connections allowlist: discovery filtered to allowed connections, explicit `connection_id` → 403 (`*_connection_not_enabled`), auto-resolution inside the allowed list, settings fallbacks refused (`*_settings_not_allowed`), Drive folder scope enforced (`search_drive` rejects a differing `folder_id`; `get_drive_file` verifies the parent chain with a bounded BFS, fail closed). CG Pro mirrors carry the same gates.
- **Sub-projects (PR #7247 Track C)** — nvoos-content-graph-ai RAG upgrades: plugin chunking, hybrid RRF search, local score-based reranker (default), RAGAS-style hit-test runner, and the `searchHybrid` tool + CLI (own track). `nvoos-content-graph-ai-v1.0.4` + `nvoos-content-graph-ai-platform-v2.0.0` ZIPs built in-window.
- **Docs (PRs #7241/#7243/#7254/#7260)** — the SKILL.md OAuth troubleshooting entries (bare-URL fallback + the encoding root cause); spa-ui gains the staleness playbook + jsdom gotchas #6/#7; test-suite pattern #85; schedule-anything-ops gains the failure class + the zero-backend-requests fact; Proposal 092 (Astro storefront layer).
- **Versioning** — 1.2.13 across all version-bearing files. No addon moves. Tool count: **~355 base + ~1,378 Pro (~1,732 total; +1 Pro — `export_annotation_dataset`)**. Coding-time skills 76 (unchanged — four updated in place). Stale 1.2.11 build ZIPs (30 files — 9 + 2 + 19) removed; the 1.2.12 set stays as the fallback.

---

## Magic Login, Native Islands, Tool Picker & Commerce Console Surfaces (v1.2.12)

- **Magic-link sign-in (PRs #7206/#7208)** — opt-in `WP_MCP_AI_REST_Magic_Login_Controller` (`POST /mcp-ai/v1/magic-login/request` + `/confirm`, off by default → 404): ~256-bit CSPRNG tokens (`wp_generate_password(43, false, false)`) stored SHA-256-hashed in transients, 15-min single-use expiry, one outstanding link per user, uniform anti-enumeration responses, transient rate limits (3/identifier/15 min, 10/IP/hour), `wp_login` on confirm. Deliberately **unauthenticated by design** (the `/session/nonce` exception) — a named permission callback still enforces the feature flag + the Security Manager's IP/HTTPS posture. Settings subtab (Authentication → Magic Link Sign-In: `enable_magic_login`, `magic_login_app_origin`); the controller reads the settings registry first with standalone-option fallbacks; the console gains Password/Magic-link tabs + `#/magic-login?token=…`; author sign-in fixed when `users/me?context=edit` 403s (#7224 — nonce re-mint + view-context retry).
- **Native addon islands (PR #7213, Proposal 087)** — `#/docs`/`#/media`/`#/documents` mount Docs Hub / Media Studio / Document Editor as native islands (vendored docs-hub IIFE + `window.NVoosDocsHub.mountDocsHub` + MemoryRouter; lazy `*Asset`/`*Css` config endpoints; `postMessage` auth bridge removed — origin-checked credential injection); new `mcp-ai-pro/v1/okf/docs` OKF adapter (bundle-prefixed slugs, cross-link rewriting, rehype-slug TOC). **Filter semantics changed:** `wp_mcp_ai_pro_spa_docs_url` / `wp_mcp_ai_pro_spa_media_studio_url` / `wp_mcp_ai_pro_spa_document_editor_url` now take `wp-json` REST bases, not front-end/page URLs.
- **Tool picker + tools-list contract (PRs #7221/#7232, Proposal 088)** — a registry-backed ARIA multiselect replaces the comma text field (grouped listbox, capability colour coding, creatable raw-slug entry, add-all/clear; unknown slugs preserved + flagged); `handle_tools_list()` emits per-tool `flags` (+ `_fields` allowlist — the assistant payload contract unchanged); the new `scope=all` route arg lets the picker fetch the full registry (unscoped requests keep resolving the default assistant; token-bound credentials stay pinned; cache keys include `scope`).
- **Connections page (PRs #7220/#7222/#7225/#7229)** — `WP_MCP_AI_Pro_Remote_Sites_REST_Controller` at `mcp-ai-pro/v1/remote-sites` (list/redacted secrets + `has_credentials`, 32-type `/types` catalogue, create/partial-update (blank secrets keep stored values)/delete/test, `manage_options`; the `rest_remote_sites` module always loads); the console-only `#/connections` page (Command Centers → Channels) + `remoteSites` in both SPA configs; the base-settings Gmail aggregated as `base-gmail` (its pseudo connection now carries `name`); dark-mode tokens + the fixed wp-admin deep link.
- **Commerce console surfaces (PR #7231, Proposal 089)** — four WooCommerce-gated commerce feature flags + `content_records`; four schema-driven settings sections on new registry tabs (kill-switch filters for the wp-admin pages); read-only `mcp-ai-pro/v1/commerce/sync-runs`; `remote_site` proxy (structured 404/403/400/502, zero credential echo); product/post/page records entities; `CommerceToolkitPage` + SitePicker + the `SettingsForm` extraction. Deferred (tracked W16e/W16f/W16g): 4f widgets, remote records browsing, 5b retirement, 6b deep-links.
- **Tool-schema bounds (PRs #7210/#7211)** — `WP_MCP_AI_Tool_Schema_Helper` bounds 763 integer fields to the JSON-safe 2^53−1 ceiling (honest bound, no invented caps); `type: object` on 8 legacy flat parameter maps; single-branch `allOf` for 7 root-`anyOf` tools; Site Health `wp_mcp_ai_mcp_schema_compliance` findings cleared + a registry-wide auditor canary. Zero tool-count change.
- **Console + records fixes (PRs #7215/#7218/#7219/#7223/#7224/#7225/#7226/#7233)** — professions meta visible (CPT `custom-fields` support + `register_meta_in_rest()` grants + the `relink_members_after_profession_replace()` team seam); records `restBase` resolved from the registered route base (`post` → `posts`); settings contract (numeric-int round-trip, RAW option keys, `(stored)` options, `__hidden__` tab exclusion); docs island theme sync + full-bleed; dark-mode tokens (`--nvoos-chip-bg`/`--nvoos-muted`); Paper Store page + `paperStore` endpoint; author sign-in fallback.
- **Docs (PRs #7209/#7217/#7227/#7230)** — Proposal 090 (G9 decision #15: Laravel for the standalone stack; the v1.4.0 Laravel adapter spike plan with P1–P7 gates + flip conditions F1–F4); the spa-ui wiring map + theme tokens + rebuild rules; spa-rest-contract bug class 13 + settings-coercion taxonomy; test-suite patterns 80/81/44.
- **Versioning** — 1.2.12 across all version-bearing files. No addon moves (docs-hub/media-studio/document-editor sources gain the island APIs **without** bumps — the shipped ZIPs stay current). Tool count unchanged (~355 base + ~1,377 Pro, ~1,731 total). Coding-time skills 76 (unchanged — three updated in place). Stale 1.2.10 build ZIPs (30 files) removed.

## Velocity Caching, SSE Offload, Console Login & a Fix Wave (v1.2.11)

- **Velocity caching + REST cache opt-in (PR #7197)** — both Velocity apps (`examples/nvoos-complete-velocity` + `examples/schedule-anything-velocity`) gain the full caching contract: `no-cache` + weak-ETag `index.html` (304 revalidation), `immutable` hashed assets, gzip/brotli with `Vary: Accept-Encoding`, and a **default-deny proxy micro-cache** (proxied GETs stored only when WP declares `Cache-Control: public` + explicit `max-age`/`s-maxage`, no `Set-Cookie`, `Vary` ≠ Cookie/Origin/*; nonce + SSE endpoints can never be cached; `X-WP-Nonce` stripped from cached entries; knobs `NVOOS_PROXY_CACHE=0` / `NVOOS_PROXY_CACHE_MAX_TTL` 300 s). `GET /mcp-ai/v1/features` emits `public, max-age=60, s-maxage=60`; the new `WP_MCP_AI_REST_Cache_Control` opts out of WP 6.9's authenticated no-cache injection only when the response explicitly declares public caching.
- **SSE long-run offload — Proposal Phase 4b (PR #7199)** — streams nearing proxy idle-read resets (~75 s default, `wp_mcp_ai_sse_offload_elapsed_seconds`, 0 = off) hand the remaining agentic work to the job queue (`WP_MCP_AI_Chat_Stream_Offload_Worker`, `chat_stream_continuation`, 240 s cap, notifier heartbeats) and close with a `job_offload` event; the continuation snapshot round-trip now persists `assistant_config`/`iteration`/`max_iterations`/`agentic_cost_accumulator`/`pending_tool_calls`/`continuation_kind`; terminal failures record `handle_job_failed()` (a `WP_Error`) + a `chat:error` frame and **throw** (queue row `failed`). `content_format_templates` seeding deferred `init` → `wp_loaded` (PHP 8 `$wp_rewrite` null on fresh boots).
- **Complete Console login/sign-out/session gate (PRs #7190/#7192/#7196)** — branded in-app sign-in (wp-login form replay against the proxy), the global 401/403 → sign-in gate in `fetch-wrapper.ts`, working sign-out (`&#038;`-escaped nonce accepted), z-index + favicon fixes.
- **Console fixes (PRs #7189/#7191/#7193/#7196/#7200/#7201/#7202)** — front-end REST bridge providers eager-required (`rest_console_bridges`) + the command-center lazy `load_provider()` seam + 501 `WP_Error` branches; profession ballooning (counts-cache invalidation + slug-match seeder dedupe); `/dashboards/schema` `disabled` map + `effective_flag_key()`; Security Center structured UI; workflow `NodeEditor`; the command-center 500 (static `$this` fatal); continuation null-safety; console mobile gutters/dock.
- **Dependency advisories (PR #7195)** — 67 of 74 alerts closed across 21 npm trees (vitest-mocker ≥4.1.12 <5, dompurify ^3.4.17, sharp ^0.35.5, ip-address ≥10.7.4, vite → ^6.4.4, esbuild); tracked bundles rebuilt; deferred: #7090 (provider-utils 3.x), #7089 (react-router 7), #7194 (glib).
- **Sub-projects (PRs #7198/#7191)** — nvoos-content-graph 1.0.12 upload prep (memory-graph bridge seams #7145 + guest-token read-route validation mirror #7155; ZIP at `build/nvoos-content-graph-v1.0.12.zip`); docs-hub checked — no shipped changes since 0.5.3; CG-AI-platform profession mirror + v2.0.0 ZIP.
- **Docs (PR #7203)** — Proposal 086 (chat frontend transport abstraction, BYOK backend).
- **Versioning** — 1.2.11 across all version-bearing files. No addon moves. Tool count unchanged (~355 base + ~1,377 Pro, ~1,731 total). Coding-time skills 76 (unchanged). Stale 1.2.9 build ZIPs (30 files) + the superseded content-graph v1.0.11 ZIP removed.

## Console Phase 5b–5d, Crash Fixes, Storage Meter & Advisory Sweep (v1.2.10)

- **Console migration Phase 5b–5d + polish (PR #7180, Proposal 084)** — the orphaned `WP_MCP_AI_REST_Cost_Manager` + `WP_MCP_AI_REST_Analytics_Manager` controllers now register in `includes/bootstrap/loader.php` and power the real Analytics page (`manage_options`-gated, wrapping the existing service layers); the Unified Blueprints page bridges behind `GET /mcp-ai-pro/v1/blueprints` (searchable install catalogue); the Agent Command Center absorbs into the Dashboard (fail-soft). Console-wide: semantic `DataTable`, standardized buttons, grouped collapsible sidebar (W3C disclosure).
- **Crash fixes + chat dock (PR #7184)** — the blueprints 500 (the `admin_blueprints` module gated the page class behind `context => 'admin'` — its static catalogue seams fataled on front-end REST; class loads unconditionally now, only `init()` stays `is_admin()`); React error #310 on four console pages (all hooks before the early returns; `react-hooks/rules-of-hooks` joined the spa-v2 ESLint gate — 21 latent violations); settings page (section cards, cross-tab search, sticky save); chat dock (mode-synced conversation-list collapse, theme switch, stacked composer, textarea drag-resize).
- **Server transcript storage bytes (PR #7185)** — `WP_MCP_AI_Transcript_Repository::get_storage_bytes()` aggregates per-user payload lengths (0 when the CCT is unavailable); the `/chat-transcripts` envelope carries `storage_bytes`; the Pro SPA StatusBar prefers the server figure with a localStorage fallback for older installs (the old meter always read 0 KB — the standalone app's origin can never hold the legacy keys).
- **Dependency advisories (PR #7186)** — markdown-it → 14.3.3 (bounded override `>=14.3.3 <15`), `@modelcontextprotocol/sdk` exact pin → 1.32.0 (gateway, 22/22), launch-editor floor → ≥2.14.2 — 14 of 16 open alerts; the vite pair already fixed on the alpha line.
- **Build (PRs #7182/#7181)** — full tracked-bundle rebuild (16 files — lockfile-only advisory bumps had left tracked bundles stale for 13 days); the standalone SPA mirror gains the `cost`/`blueprints`/`commandCenter` endpoints + the analytics namespace fix.
- **Docs & skills (PRs #7178/#7183/#7185)** — the spa-ui skill gains the rebuild-discipline subsection (lockfile staleness signature, vendor never-commit rule, revert-on-shared-branch play, merge discipline); the dependabot-loop skill gains Step 7 (rebuild tracked JS bundles); the schedule-anything-ops skill gains the Cloudways Anti-Bot Protection (Imunify360 WebShield) failure class; the spa-rest-contract skill gains bug class 11 (wrong-store meters) + the `storage_bytes` baseline; the test-suite skill documents the `run-tests-docker.sh` silent `dump-autoload` fallback.
- **Versioning** — 1.2.10 across all version-bearing files. No addon moves. Tool count unchanged (~355 base + ~1,377 Pro, ~1,731 total). Coding-time skills 76 (unchanged). Stale 1.2.8 build ZIPs removed (30 files).

## Complete Console + Admin Console Migration, SA Visibility & New REST Routes (v1.2.9)

- **Complete Console Velocity app (Proposal 083, PRs #7150/#7154)** — `examples/nvoos-complete-velocity/` serves the full spa-v2 admin surface for Complete customers: build-time composition via the `@nvoos/pro-spa-v2` Vite alias (no spa-v2 fork), cookie auth through the same-origin BFF proxy (`serve.mjs`, no connection screen), and a Schedule Anything-format shell — dashboard home, one route-split page per addon, collapsible nav rail, and a **persistent chat dock** (one `ChatPage` instance; conversations keep streaming while browsing). Mirror sync via `sync-nvoos-complete-velocity.yml` (no-op script shims + dependency strip in the mirror — Velocity deploy fixed by #7151).
- **Admin-surface console migration, Phases 0–4d (Proposal 084, PRs #7164/#7166)** — `WP_MCP_AI_Feature_Flags` + `GET /mcp-ai/v1/features` gate the console nav (fail-open); Approvals/Slash Commands/Triggers/Portability/Security/Teams ports with per-page wp-admin kill-switches; a schema-driven Settings engine (`/settings/schema` + `/settings/values`); ops/diagnostics/token-manager pages + `GET /mcp-ai-pro/v1/ops/overview`; Schedule Manager (P9) + Workflow Builder (ReactFlow canvas); records/dashboards/calendar/F&B/channels/media-ops pages. **REST contract parity audit fixed nine client/server mismatches** (incl. the assistants GET/PUT routes that broke the edit form). Phase 5 (retirement soak + kill-switch flips) remains.
- **Schedule Anything full visibility (PR #7147 — platform 0.1.1 → 0.1.2)** — `GET /mcp-ai-pro/v1/sa-tools` (light paginated registry projection, no inputSchema — replaces the hardcoded 19-tool palette fixture); `GET /toolkits` returns server-decided `tier`/`platform_active`/`entitled`; the missing `flowhub` + `shopify-sync` rows are back (statuses derive from `TOOLKIT_FLAGS`); multisite admins gain `sa_manage_workspace` idempotently; preset facet-driven dropdowns + load-more pagination; same-state toggles are a successful no-op (`update_option()` false-for-unchanged handled).
- **New base routes (PRs #7157/#7164)** — `GET/POST /mcp-ai/v1/settings` (SPA-shaped `{ success, data }`, secrets masked as the admin placeholder — never raw; whitelisted sanitize + SPA→stored key mapping + clamps + settings-cache reset), `GET /mcp-ai/v1/features`, `GET /mcp-ai/v1/teams`, and the settings schema/values pair.
- **Console reliability (PRs #7174/#7176/#7163)** — the Proposal 084 bridges boot from a context-free `rest_console_bridges` registry module (the `admin_sections` `is_admin()` gate never fired for the front-end SPA — six routes 404'd); the schedule picker moved to its own `/schedules/selectable` (two `GET /schedules` handlers collided — last registrant won); dashboards + nav gate on toolkit toggles (fail-open feature map); loading-first hooks kill the empty-then-loaded flashes (assistants edit form blocks premature saves).
- **Opt-in debug logging (PR #7161)** — debug-level events gate behind `enable_debug_logging` (default off; Logs settings subtab); errors/warnings/criticals stay always-on; JetEngine CCT hot-path events removed; the CG Pro logger port mirrors the gate and degrades to a safe no-op standalone.
- **Memory-graph bridge seams (PR #7145)** — `trace_memory_provenance` resolves its bridge/DB walker through three filters and walks `DERIVED_FROM`/`OBSERVED_BY`/`MEMBER_OF` with a new `kind` field; the RRF fusion stream resolves `wp_mcp_ai_memory_rrf_graph_bridge`; the Content Graph plugin self-declares as the bridge (no CG version bump — release prep is a follow-up).
- **SPA contract fixes (PRs #7156/#7155)** — the tools-list client maps the real `{ tools, total }` envelope (route additively returns `slug` + `required_capability`); the knowledge-graph visual-config fetch sends the `wp_rest` nonce (cookie-mode 401 fixed); the CG guest branch validates through the real guest-token layer; transcript 404 = "fresh session"; fail-closed slug-shape guard on `assistant_visible_to_current_user()`; dark-mode user-bubble contrast.
- **Build & dependencies (PRs #7167/#7168/#7175/#7144/#7171/#7173/#7165/#7148/#7146)** — the Pro zip stops shipping root `examples/` (−5.4 MB; per-toolkit blueprint dirs still ship); vite → 8.2.4 / hono ≥4.13.11 / follow-redirects ≥1.16.1 (alerts 1336–1377); dictate workflows install the real rustup arch targets (tauri lipo-merges the universal bundle); standalone SPA `@xyflow/react` lockfile + paths/aliases; SA SPA React 19.1.0 (documented Pattern-B deviation); SA Velocity CSS MIME fix + asset-closure gate + 404-loudly `serve.mjs`.
- **Docs & skills (PRs #7162/#7170/#7169/#7172/#7160/#7153)** — new coding-time skill `mcp-ai-wpoos-spa-rest-contract` (75 → 76); spa-ui (React 19 checklist, clean-install lockfile gotcha, two-bundle squash rule), content-graph-spa + schedule-anything-ops updated; README sponsor section + `FUNDING.yml` (VS16 anchor fixed); Proposal 085 (Funiq Velocity storefront) is docs-only.
- **Tool counts** — ~355 base + ~1,377 Pro (~1,731 total; **unchanged**). Coding-time skills 75 → 76; bundled 77 base + 41 Pro (unchanged). Security classes 12, providers 18, addons 30 — all unchanged. SA platform 0.1.1 → 0.1.2. Media Worker stays 3.4.0. Stale 1.2.7 build ZIPs removed (30 files) + the superseded SA platform v0.1.1 ZIP.

## Schedule Anything API + Single-Site Mode, F&B Worker Offload & OAuth Hardening (v1.2.8)

- **Schedule Anything presets + toolkits API (PR #7124, Proposal 081)** — four `mcp-ai-pro/v1` routes (`rest_schedule_anything`): `GET /toolkits` + `POST /toolkits/{slug}/toggle` (server-side tier entitlements via `SA_Toolkit_Manager`, `403 sa_toolkit_not_entitled`), `GET /presets` + `/presets/{id}` (12 presets across 6 toolkits), idempotent `POST /presets/{id}/install`; schedule records leave REST redacted (`redact_schedule_for_public()`).
- **Schedule Anything Platform single-site mode (PR #7134, Proposal 082 — addon 0.1.0 → 0.1.1)** — sole-tenant self-provisioning, `manage_options` capability seam, offboard-sole-tenant 409, `SA_SAAS_API_KEY`-gated heartbeat; 17-case suite via a self-guarding addon tests bootstrap.
- **F&B ingest × media-worker offload (PR #7114, Proposal 079 + Appendix B)** — worker `POST /api/ingest/parse` (matrix contract) + hardened `/api/image/batch`; F&B sidecar-first cascade seam (`WP_MCP_AI_Fnb_Worker_Client`) with local fallbacks; `optimise_images_batch` + OCR-service PDF paths offload; opt-in `ocr_vision_fallback` rung. **Worker stays 3.4.0** (no bump in-window).
- **MCP OAuth authorize hardening (PR #7133)** — RFC 9700 exact-string redirect matching (wildcard bypass gone), registration-time URI validation, nonce-bound consent page, unknown-scope rejection, token-endpoint `redirect_uri` matching — Pro + CG Pro mirror byte-identical.
- **WP-CLI integration gaps (PR #7135)** — dead `mcp-ai content` fixed; canonical `WP_MCP_AI_Pro_Toolkit_Settings_Map` (40 toolkits); gated `toolkit enable|disable`; new `foundry`/`para`/`qms`/`mcp-app`/`fnb` commands.
- **Chat composer + toolbar (Proposal 080, PRs #7113/#7116/#7118–#7120)** — auto-grow 1→3 lines, iOS keyboard reflow, drag-resize divider, focus composer, in-place collapsing toolbar (202 vitest green).
- **Gmail tools (PR #7110)** — `empty_parts` HTML-only email hydration via `body.attachmentId`; attachment text extraction (smalot/pdfparser); base64url re-padding.
- **F&B fixes (PRs #7108–#7112)** — serial dates (`46023` = 2026-01-01) no longer collapse trends to 1970-01; the universal reader honors `table_map`; resume/retry imports; progress placeholders render.
- **Schedule Anything delivery + distribution (PRs #7130–#7132)** — delivery date/time editing in the Pro Schedule Manager modal; the SA preset registry renamed `WP_MCP_AI_SA_Schedule_Presets` (class-collision fix); the platform's `Requires Plugins` header dropped (folder-slug matching broke the oos-complete bundle).
- **Velocity app (PRs #7125/#7126/#7131)** — `examples/schedule-anything-velocity/` with a root `server.js` ESM shim (PM2 default entry); `NVOOS_SA_VELOCITY_REPO_TOKEN` (40-char secret-name cap).
- **Dictation macOS CI + universal builds (PRs #7122/#7123/#7137)** — `macos-latest` boot-smoke (30 s residency) + headless engine probe, interactive tmate workflow, one universal arm64+x86_64 artifact.
- **Skills + dependency (PRs #7106, #7128, #7129)** — new `mcp-ai-schedule-anything-ops` skill (74 → 75); dictation skill macOS remote loop; `handlebars` → 4.7.10 (GHSA-8r5x-fm3f-whwj).
- **Tool counts** — ~355 base + ~1,377 Pro (~1,731 total; **unchanged**). Coding-time skills 74 → 75; bundled 77 base + 41 Pro (unchanged — the dictation-app bundled copy re-synced). Security classes 12, providers 18, addons 30 — all unchanged. Stale 1.2.6 build ZIPs removed (30 files) + the superseded SA platform v0.1.0 ZIP.

## F&B Universalisation, Sinhala TTS & the Pro SPA Multi-Page Expansion (v1.2.7)

- **Food & Beverage universalisation + open-format ingestion (PRs #7094–#7096, Proposal 078)** — the F&B toolkit moves from a single-tenant demo to a universal product: `WP_MCP_AI_Fnb_Tenant_Profile` de-couples currency (canonical neutral metric keys + legacy `*_lkr` aliases for the 20/20 oracle), `render()` de-venues both assistant delivery surfaces (4 Portability packs + 4 unified Blueprints), `demo_mode => false`, and a DomPDF-first `fnb_export_report` (+1 Pro) with CSV fallback; the universal single-folder reader scores Drive files to table roles (multi-format CSV/TSV/JSON/JSONL/XLSX/ODS/PDF/photo + header-alias dictionary + dry-run); a read-only Ingest & Review dashboard + an analytics dashboard (KPI tiles + trend charts + panel tables).
- **Sinhala-native TTS (PR #7099)** — `generate_sinhala_speech` (+1 base) closes the `generate_openai_speech` gap via SpeechGen `si-LK` (default), Hugging Face `facebook/mms-tts-sin`, or a custom webhook; wired into the `media_generation` preset; `teacher-assistant-sri-lanka.md` pack.
- **Pro SPA multi-page expansion (PRs #7078–#7080)** — `#/docs` / `#/media` / `#/documents` frame the Docs Hub / Media Studio / Document Editor SPAs in sandboxed iframes with filterable endpoints + `nav-*` commands; standalone app defaults `docsHub` to console.nvoos.cloud.
- **Dictation-app skill bundling (PR #7077)** — `mcp-ai-wpoos-dictation-app` ships in `includes/bundled-skills/` + the `bin/sync-agent-skills.php` allowlist (base bundled 76 → 77).
- **Tool-schema hardening (PRs #7087/#7100/#7104)** — per-property boolean `required` hoisted to the top-level array (both `ChatOrchestrator::hoistPropertyRequiredFlags()` + REST `build_tools_payload()`); empty `properties` emitted as `{}` (seven no-arg tools + the central `Tool_Schema_Auditor::normalize_for_mcp()` + the CG-AI `ToolSchemaAuditor` mirror), fixing DeepSeek 400s.
- **Google Workspace unification + native Sheets (PRs #7097/#7101/#7105)** — `search_gmail`/`search_drive` delegate to the shared credential-resolving clients; `get_drive_file` branches native Google Sheets to the Sheets API v4 (`sheet_name`, `tabs`, `row_count`); `extract_google_error_message()` surfaces the real 403 cause.
- **F&B reliability (PRs #7091/#7092/#7102/#7103)** — recoverable unknown-metric errors (Levenshtein closest-ID), complete-by-default + resumable imports (25,000-row cap), header-dictionary metric resolution + covers fallbacks + fixed-height KPI charts, and a WPCS indentation pass.
- **Team-member tool invocation (PR #7088)** — `invoke_team_member()` resolves profession slugs via `build_tools_payload()`. **Framed SPA credential auth + surface fix (PRs #7075/#7076/#7085)** — headless `Bearer cred_…` auth, home-URL iframe fallback removed, keep-alive hub tabs.
- **Dependency (PR #7074)** — `@modelcontextprotocol/sdk` 1.30.1 → 1.31.0 in the mcp-wordpress-gateway (GHSA-6qxp-vccf-f47h).
- **Tool counts** — ~355 base + ~1,377 Pro (~1,731 total; **+1 base +1 Pro**). Coding-time skills 73 → 74; bundled 76 → 77 base + 41 Pro. Security classes 12, providers 18, addons 30 — all unchanged. Stale 1.2.5 build ZIPs removed (30 files).

## Google Drive OAuth Restored, F&B Reliability, OCR vLLM & the Dictation Browser Agent (v1.2.6)

- **Google Drive OAuth restored (PR #7053)** — the #6981 `drive.file`-only narrowing broke `search_drive`, `get_drive_file`, and the F&B tools for pre-existing content; `drive.readonly` restored alongside `drive.file` behind `wp_mcp_ai_google_drive_oauth_scope` (CG-AI platform mirror — sub-project).
- **F&B reader reliability (PRs #7057, #7060, #7061, #7062)** — Sheets-API-v4 multi-worksheet reads (`get_sheet_values()`/`get_sheets_metadata()`, fuzzy tab matching, split-file fallback); `DEMO_WORKBOOK_ID` fallback + `workbook_id()`; the `spreadsheets.readonly` OAuth scope + `maybe_annotate_sheets_error()`; a `WP_MCP_AI_Fnb_Csv_Exporter` + 18 shipped demo tables (`data/*.csv`). No new tool.
- **Self-hosted OCR vLLM contract (PR #7055)** — `ocr_images()` was SGLang-shaped; rewritten to the vLLM OpenAI-compatible payload (`extra_body.vllm_xargs`; `skip_special_tokens` + n-gram args nested), base + CG Pro mirror byte-identical; `model_id` added to `MODEL_DEFAULTS`.
- **Drive fixes (PR #7051)** — the `WP_MCP_AI_Inline_Async_Tick_Trait` double-declare fatal (harness eval scheduler — require through the `trait_exists()`-guarded `require_once`); Drive 400 body logging (`invalid_grant` vs `invalid_client`); `folder_id` clearing (`! array_key_exists()`).
- **Dictation browser agent + FastConformer (PRs #7041, #7043–#7050)** — `examples/nvoos-dictate`: the `agent` feature (CDP browser control via chromiumoxide, ReAct loop, origin-guarded safety gate, HITL Approve/Deny, `settings.agent.model` brain), a `fastconformer` nemo_ctc STT engine, an explicit `polish_enabled` gate, and model-download hardening (`.download` moved out of the install dir, 5× swap retry, `spawn_blocking`).
- **NV oOS SPA hub + Pro SPA v2 fixes (PRs #7063, #7066, #7064, #7072)** — `GET /mcp-ai-pro/v1/spa-surfaces` (`WP_MCP_AI_Pro_SPA_Surfaces_Controller`); the dictate "NV oOS" multi-surface hub; last-message-save + assistant-memory fixes; the `trait-wp-mcp-ai-spa-credential-auth.php` guest/bearer/credential drawer fix (401 in the dictate iframe).
- **Dependency (PR #7059)** — `shell-quote` → `>=1.11.0` (1.12.0) across root/saas-controller/Pro SPA manifests (GHSA-pqg4-j6r4-53mv).
- **Tool counts** — ~354 base + ~1,376 Pro (~1,730 total; **unchanged** — zero registry diff). Security classes 12, providers 18, addons 30 — all unchanged. Stale 1.2.4 build ZIPs removed (30 files).

## GTmetrix × WPCode Toolkit, Food & Beverage Phase 9 & the Hardened Dictation App (v1.2.5)

- **GTmetrix × WPCode performance toolkit (PR #7026, Proposal 068)** — **+24 Pro tools**: a 23-tool `gtmetrix_*` set (`addons/pro/includes/tools/gtmetrix/` behind `enable_gtmetrix_toolkit`) + the read-only `list_wpcode_snippets` (`addons/pro/includes/tools/developer/`). A shared `WP_MCP_AI_Pro_WPCode_Snippet_Repository` (extracted zero-behavior-change from `create_wpcode_snippet`) backs the WPCode bridge; `gtmetrix_install_wpcode_fix` is drafts-only + chat-restricted. Deterministic CWV/grade/weight scoring (41-check oracle), a credit-aware Action Scheduler poller + CPT snapshot store, Basic-auth client (429 backoff, sensitive-resource hard-blocks). Five schedule + two workflow presets; `wp mcp-ai pro gtmetrix seed-assistant`.
- **Food & Beverage Phase 9 (PR #7032)** — **+10 Pro tools**: five transactional-table CPTs (`mcp_ai_fnb_sale|purchase|stock|waste|booking` behind `enable_fnb_native_storage`, idempotent upserts, read by metrics/reports unchanged), the `fnb_import_table` Sheet/CSV→CPT bridge (dry-run, idempotent), and nine `fnb_pr_*` purchase-request tools on the QMS engine (`wp_mcp_ai_qms_state_preconditions`, PO numbering `PR-YYYYMM-###`, release-signature relaxation). The four A1–A4 assistants ship as unified Blueprints; a new top-level F&B admin menu (CRM/PM pattern).
- **F&B admin menu + seeder (PRs #7029/#7033)** — `tools/food-beverage/init.php` wired into the Pro Module Registry (`conditional_toolkits`/`dir_map`) so the admin menu surfaces (tools worked before via the central map); the completed `WP_MCP_AI_Fnb_Assistant_Seeder` makes the one-click admin button + `wp mcp-ai pro fnb seed-assistants` CLI share semantics; CSV-directory status row.
- **Dictation companion app hardened (PRs #7017, #7020, #7021, #7025, #7027, #7030, #7037, #7039, #7040)** — `examples/nvoos-dictate`: cpal stream-hold regression, stuck-Alt hook, adaptive VAD, re-download write-access; whisper+parakeet one binary (vendored `whisper-rs-sys`); whisper RTF 5.2 → 0.36; 0.1.0 → 0.2.0; Windows Credential Manager (`win_cred.rs`, `CRED_PERSIST_LOCAL_MACHINE`); macOS port (P5); local `lm_studio`/`ollama` + video input + proprietary licensing; ONNX-YOLO detection + Qwen2.5-VL label polish. **No plugin registry surface.**
- **Standalone SPA login presets (PR #7031)** — `examples/nvoos-pro-spa-vite` `HOME`-selected login pages + runtime `NVOOS_*` env injection + `NVOOS_AUTO_CONNECT` kiosk mode.
- **Coverage & contract drift (PRs #7035/#7036)** — model-foundry `produces` → null; `enable_webchat_integration` toolkit count 36 → 37; regenerated Pro coverage manifest.
- **Docs & skills** — coding-time skills **71 → 72** (`mcp-ai-artcraft-ops`, `design-performance-audit`); Rust editor config; proposal docs 068/070/071/072/074/075/076; sub-project content-graph 1.0.11 wp.org prep (#7014, flag-not-edited).
- **Tool counts** — ~354 base + ~1,376 Pro (~1,730 total; +34 Pro). Security classes 12, providers 18, addons 30 — all unchanged. Stale 1.2.3 build ZIPs removed.

## MCP Quirk Hardening, Chart Recipes, Model Foundry Phase 1 & the Content Graph SPA Page (v1.2.4)

- **MCP client-quirk hardening (PR #7007, Proposal 066)** — `WP_MCP_AI_Tool_Schema_Auditor` normalizes every advertised `tools/list` schema (root `type: object` injected when missing) and skips-with-reason hazardous ones (bracketed property names, >20 KB schemas via `wp_mcp_ai_tools_list_schema_max_bytes`, >64-char slugs via `wp_mcp_ai_tools_list_max_slug_length`, root combinators) — one bad tool can no longer drop the whole catalog; findings surface as a Site Health direct test + debug-info field (15-min transient cache). `nvoos_get_profile` attaches `structuredContent` whenever its `outputSchema` is advertised (Codex turns declared-outputSchema text-only results into errors). The registry fires `wp_mcp_ai_mcp_tools_list_changed` (once per request) backing `listChanged`; JetEngine MCP + MCP App discovery caches cap at the server `ttlMs` and invalidate on `notifications/tools/list_changed`. The CG-AI standalone mirror ports the hardening (sub-project). 44 new tests on WP 6.9 + 7.1.
- **nvoos-chart recipes + create_chart_fence (PRs #7003, #7005)** — fenced `nvoos-chart` JSON renders as HTML/CSS charts on all three chat surfaces (29 types; sanitisation by construction — extracted before `marked`/DOMPurify; resource caps; grouped-bar fix); **+1 base tool `create_chart_fence`** (server-side validator mirror) + the `design-chart-recipes` skill + byte-identical conformance fixtures across the three suites.
- **Model Foundry Phase 1 — Corpus Foundry (PR #7008, Proposal 067)** — **+3 Pro tools** (`export_trajectory_corpus`/`export_preference_pairs`/`export_plugin_docs_corpus`) behind the consent fail-closed `WP_MCP_AI_Corpus_Governance` engine (`_wp_mcp_ai_training_consent`; caps → exact → fuzzy → opt-in semantic dedup → PII scrub → deterministic holdout split → R12 provenance → guarded sharded write; holdout rows never enter `train.jsonl`; consent UI ships in Phase 3 — `wp_mcp_ai_model_foundry_assistant_consented` is the operational override); deactivatable `model_foundry` Pro module; `ai_ml` preset +3.
- **Content Graph explorer page in the Pro SPA (PR #6998)** — `#/knowledge-graph` in the admin surface + standalone app (vendored Cytoscape explorer, documented wrapper-only delta, lazy 213 KB-gzip chunk); the CG plugin gains a read-only `GET /graph/visual-config` route + assistant-credential read auth — write routes stay `manage_options`-only (sub-project track).
- **Standalone SPA deploy & auth hardening (PRs #6999, #7000, #7002, #7004, #7006)** — cookie-mode login re-scoped through the proxy (absolute `wp-login.php` form actions broke cross-host deploys — login-page buffering + rewrite); a new `ajaxPrefilter` mirrors the fetch wrapper's auth headers onto jQuery (the explorer's `$.ajax` bypassed it); tsconfig paths + CI build-verify unblock the Velocity deploy; `serve.mjs` gains a shebang (Velocity executes the entry through `sh`) + `server.on('error')` logging with an `EADDRINUSE` hint; the Velocity doc gains the entry-path callout.
- **SPA static-server headers (PR #7009)** — `X-Content-Type-Options: nosniff` + `Strict-Transport-Security: max-age=86400` on the static branch only (ramp to `31536000` after a clean week); CSP Report-Only template commented.
- **F&B toolkit toggle restored (PR #7010)** — `enable_fnb_toolkit` was defined but never listed in the `features` subtab group, so the checkbox never rendered; added to the subtab fields + memory map + footer counter with a regression test.
- **Docs & skills (this pass)** — user-directed partial `@since` reconciliation (the literal `@since 2.x.0` placeholder family + the model-foundry `1.6.0` + chart-fence `1.4.0` tags corrected to their true shipped versions, blame-verified; the historical OI-1 groups stay parked per issue #5968); coding-time skills 66 → 69.
- **Tool counts** — ~354 base + ~1,342 Pro (~1,696 total; +1 base +3 Pro). Security classes: 12 (unchanged). Stale 1.2.2 build ZIPs removed (6 files).

## CORS Enforcement, Standalone SPA WordPress Login & SPA REST Auth (v1.2.3)

- **CORS same-origin enforcement (PR #6986)** — WordPress core `rest_send_cors_headers()` (priority 10) reflects **any** `Origin` back with `Access-Control-Allow-Credentials: true` on every REST response, silently no-op'ing the Security → Network "Same Origin" setting. The 12th `includes/security/` class `WP_MCP_AI_CORS_Guard` hooks `rest_pre_serve_request` at priority 20 and, in `site` mode, echoes only exact-allowlisted origins (site origin + the new `cors_allowed_origins` setting, one origin per line + the `wp_mcp_ai_cors_allowed_origins` filter) — everything else gets the site's own origin + credentials off; `star` mode keeps core's reflection. Scope `/mcp-ai/v1` by default (widen via `wp_mcp_ai_cors_guard_route_prefixes`); the MCP/OPTIONS/SSE/controller emitters share one `resolve_allow_origin()`. 20 new tests; 138 related pass.
- **Standalone SPA WordPress login (PR #6993, Proposal 064)** — the fourth auth mode: an Application Password (Basic auth over REST) with `wp/v2/users/me?context=edit` validation and the **real user + capabilities** mounted (full admin surface, real server-side enforcement). UTF-8-safe Basic header (`TextEncoder`); attached **only** to the configured site origin (never the media worker/third parties). Plugin-side fixes: `chat_transcripts_permissions_check()` skips the nonce for Authorization-header requests (application-password users can't mint session nonces; CSRF-safe by construction); `permissions_check()`/`permissions_check_assistant_list()` gained Application Password branches.
- **OOS streaming CORS (PR #6993)** — the OOS SSE emitter sent no CORS headers (pre-existing; every cross-origin browser chat stream was blocked): `WP_MCP_AI_CORS_Guard::emit_stream_cors_headers()` fires from the WP adapter; `lib/core` stays framework-agnostic.
- **SPA REST auth (PR #6990 — closes #6987, #6985)** — transcripts/approvals accept a pure assistant credential via `WP_MCP_AI_REST::validate_request_credential()` (reads scoped to the issuing assistant — mismatched `assistant_id` → 403; `approve`/`deny` stay `manage_options`-only); `handle_session_nonce()` re-binds the auth cookie (`wp_validate_auth_cookie`) before `wp_create_nonce()` — core's `rest_cookie_check_errors` had zeroed the session, so the minted nonce failed `rest_cookie_invalid_nonce` on retry. 10 tests; 38/38 on WP 7.1.3 + 7.2-alpha.
- **Pro Schedule Manager multi-recipient `notify_email` (PR #6991 — closes #6642, #6651)** — comma/space/semicolon lists through `normalize_notify_email()` (reusing `sanitize_email_recipients()`, per-address Symfony validation); `plan_schedules_from_workflow` uses the same normalizer; the form inputs moved to `type="text"` with a comma-separated hint. The five CRM slugs land in `tool-status.txt` as `dev` (OI-5 closed) and the pagination-fields fixture accumulation is fixed (setUp ordering — #6975 item 3).
- **Standalone SPA cookie mode + production proxy (PR #6994)** — cookie-mode proxy detection + JSON guards; the zero-dependency `scripts/serve.mjs` production reverse proxy (`NVOOS_TARGET_SITE`: `/wp-json`, `/wp-admin`, `/wp-login.php`, `/wp-includes` — SSE streaming, login `Location`/`redirect_to` rewriting, `Set-Cookie` Domain stripping, 502 on upstream failure); `App`/`EmbeddedApp` are `React.lazy` in the shell (entry 501 KB → 196 KB minified).
- **`.env` loading (PR #6996)** — `loadEnv(mode, envDir, '')` (empty prefix) so non-`VITE_` keys load; `scripts/dev.mjs` precedence shell > `.env` > `http://localhost:8000`; `serve.mjs` stays process-env-only (Velocity runtime vars).
- **npm ESM dists fixed (PR #6984)** — `nvoos-slash-commands`/`nvoos-dom-batcher`/`nvoos-audio` published invalid ESM (exports inside unclosed IIFEs); all 22 manifests → `"type": "module"`, all 23 packages rebuilt + `examples/nvoos-vite-demo/`; the three alpha.4 publishes deferred (needs npm auth).
- **Build (PRs #6988/#6995)** — spa-standalone workflows pin `main` at git init (`git init -q -b main`) and assemble the deploy tree under `examples/` so Velocity's root directory finds `package.json`.
- **Docs (PRs #6989/#6992)** — the CORS/Velocity deployment guide (`docs/operations/deployment/nvoos-pro-spa-velocity-setup.md`) + the open-issues triage snapshot (`docs/project/open-issues-triage-2026-10-10.md`).
- **Tool counts** — ~353 base + ~1,339 Pro (~1,692 total; unchanged — zero registry diff). Security classes: 11 → 12.

## Chat Profiles Read-Only Mode, F&B Assistant Packs & Google OAuth Production Readiness (v1.2.2)

- **Chat profiles with server-enforced read-only mode (PR #6977, Proposal 015)** — `write` (non-restrictive default) and `read-only` built-ins (blocks tools carrying `write`/`state-changing`/`destructive`/`irreversible`/`financial-impact`/`access-control-change`/`mass-email`/`data-destruction` capability flags). Profiles resolve **server-side per request** (user meta → site default → write fail-safe) so a client can never widen its own grant; client-sent profiles honoured only for `wp_mcp_ai_change_chat_profile` (→ `manage_options`) holders; downgrades allowed for any logged-in user; **guests default to read-only**. The 11th `includes/security/` class `WP_MCP_AI_Read_Only_Profile_Gate` hooks `wp_mcp_ai_before_tool_execution` at priority 0 **before** the destructive-ops gate (deny → ask → allow); 403 `WP_MCP_AI_Chat_Profile_Blocked` envelope; audit events `chat_profile_blocked`/`chat_profile_escalation_attempt`; advisory system-prompt hint. REST `GET/POST /mcp-ai/v1/chat-profile` (deliberately not a tool — the agent can't self-elevate mid-run). WP-CLI `wp mcp-ai chat-profile list|get|set|audit-flags`. Settings `chat_profile_enabled`/`default_chat_profile`/`guest_chat_profile`. Pro SPA v2 `ChatProfileClient` + `useChatProfile()` (server-authoritative switch). 49/49 tests on WP 6.9 + 7.1. Phase D gaps documented (queue-time async enforcement; `confirm_write` deferred).
- **F&B assistant packs A1–A4 (PR #6982, Proposal 062 Phase 4)** — four canonical v1 `nvoos-assistant` bundles in `addons/pro/presets/assistant-packs/fnb/` (A1 Manager, A2 Kitchen & Bar Stock, A3 Financial, A4 Content) with spec-verbatim G-01…G-12 instructions; seeder `wp mcp-ai pro fnb seed-assistants` (`--dry-run`/`--mode`/`--status`/`--porcelain`/`--include-image-tools`) importing through the shared `WP_MCP_AI_Assistant_Portability` engine; READ + DRAFT tiers, ACT off; `fnb_audit_log` A1-only; A4 image tools off by default. Standalone 4/4 validator + 45 tests / 192 assertions.
- **Google OAuth production readiness (PR #6981)** — Drive scopes unified on the non-sensitive `drive.file` scope across all four flows behind the `wp_mcp_ai_google_drive_oauth_scope` filter (removes Drive from the CASA verification surface); Calendar defaults to Minimal (non-sensitive scopes) for new installs; upstream token revocation on Gmail/Drive disconnect (best-effort, non-fatal — Limited Use deletion); publishing-status warnings on the Gmail/Drive footers (7-day Testing token expiry + per-integration verification guidance). GA4 stays service-account based; Graphify's Drive driver intentionally keeps broad metadata scopes. New production-verification plan + customer guide docs.
- **Pro SPA v2 fixes (#6974/#6976)** — the default-assistant fallback delegated to a nonexistent class (`WP_MCP_AI_Assistant_Manager`) — new `wp_mcp_ai_pro_get_default_assistant_id()` (Assistant Service first, settings fallback) also fixes the two other dead references; non-admin directory visibility via `assistant_visible_to_current_user()`; `assistantSelector` runtime flag; embedded sidebar hamburger moved out of the sidebar; `useStorageUsage` keeps the Sessions figure live.
- **Workflow-builder TS parity + full JS rebuild (#6979)** — `exportWorkflow`/`importWorkflow` + DFS `validateWorkflow` ported into the TS edition (Export/Import called undefined at runtime); animated edges restored; five dead `.js` duplicates dropped; every JS package + addon bundle rebuilt.
- **Test drift fixed (#6978/#6980)** — F&B oracle key-name/float-delta drift and the CG-AI platform evolved-prompt guest-profile pollution (pin the `write` chat profile in pass-through filter-chain assertions).
- **Build (#6970/#6972)** — SPA addon tag-release flow fixed (new `release-spa-addons.yml`); demo-videos pipeline manual-only until CI-verified (issue #6971).
- **Sub-projects** — nvoos-docs-hub **0.5.2 → 0.5.3** (#6966 checkout config object name — the modal was dead on arrival; #6967 rebuild reliability — live cache no longer cleared on settings saves/updates, atomic staging promotion, cron-less shutdown tick; #6968 pre-submission pass — PCP 0 blocking errors; **tag `docs-hub-v0.5.3` pushed and 0.5.3 live on the wp.org directory**) and nvoos-content-graph **1.0.9 → 1.0.10** (#6973 — excluded CCTs/CPTs now actually leave the graph via `pruneExcludedSources()`; opt-in CPTs captured; **run Rebuild Graph once after deploying 1.0.10**).
- **Docs** — Proposal 063 (PhreshOS Pro toolkit + Cloudways Velocity addon) added (#6969, docs only); five coding-time skills updated in place.
- **Tool counts** — ~353 base + ~1,339 Pro (~1,692 total; unchanged). Security classes: 10 → 11.

## Food & Beverage Pro Toolkit, Docs Hub Tools & Checkout, MCP Server Identity (v1.2.1)

- **Food & Beverage Management Pro Toolkit (PR #6962, Proposal 062)** — 21 `fnb_*` Pro tools in `addons/pro/includes/tools/food-beverage/` gated behind `enable_fnb_toolkit` (default off): deterministic metrics M-01…M-21 + Kasavana & Smith menu-engineering quadrants + as-of price joins + incurred-vs-paid split over a 17-table registry with column-alias drift tolerance; Drive + CSV fixture readers; report builder R-01…R-13; drafts-only writer. **20/20 Check-totals oracle PASS** against the demo workbook (food cost % 26.88%, beverage % 28.15%, total opex 9,988,745.79, cost per cover 4,092.07; all 59 menu items classified); 18 fixture CSVs + a 243-value oracle ship with a standalone `smoke-run.php` + the ready PHPUnit oracle. 5 schedule presets + 2 workflow presets (`fnb_weekend_prep`, `fnb_monthly_review`) + SA Toolkit Manager + WP-CLI. Phases 4/5b/6/8/9/10 deferred per the implementation plan. The new `mcp-ai-wpoos-toolkit-creation` skill documents the pattern.
- **Docs Hub content management tools (PR #6964)** — five `docs_hub_*` Pro tools in the Document Generation toolkit (write with YAML frontmatter + auto rebuild, read, list, delete dry-run-by-default, sync/async rebuild) with a shared traversal-safe validator (no `..`/absolute/drive-letter paths, non-`.md`/`.txt` rejected, realpath containment, 2 MB cap); active-plugin integration via `uploads_docs_dir()` + `NV_oOS_Docs_Hub_Rebuild_Job::enqueue_async()`, graceful degradation when inactive; writes `manage_options`, reads `edit_posts`. 32 tests / 105 assertions.
- **MCP server identity discovery (PR #6956)** — `mcp_server_info` base tool (+1 base; server name, plugin version, mode, Pro-active flag, site name/URL, MCP endpoint, optional bridge name — non-sensitive by design, `read` capability); `list_mcp_tools` `_meta` identity block (opt-out `include_meta=false`); `X-MCP-Bridge-Name` sanitized + 120-char capped into `$context['bridge_name']` — informational only, never authorization. 9/9 tests; the CG-AI `ListMcpToolsTool` sync is a Pending-sync ecosystem-tracker row.
- **Docs Hub checkout upsell (PR #6963 — addon 0.5.1 → 0.5.2)** — the Content Graph commerce stack ports into the wp.org Docs Hub plugin: five-class `includes/checkout/` (config, vendor client for `nvoos-checkout`, autoload-free license store, `Plugin_Upgrader` installer + base-plugin conflict guard, admin-only REST `/nvoos-docs/v1/payments/*` with per-user throttling + the already-licensed short-circuit) and the `nvoos-dh-*` purchase modal (on-demand Stripe.js, ToS/refund consent + buyer email + EU VAT, pending-intent recovery, manual ZIP download); `== External Services ==` disclosure + commerce review notes; POT 193 → 271 msgids; PCP PASS. Follow-up: tag `docs-hub-v0.5.2` + SVN upload. The new `mcp-ai-wpoos-checkout-integration` skill documents the port.
- **Skill-catalogue gaps fixed (PR #6954)** — subfolder sidecars install (one Git-Tree walk, non-executable extensions, 40-file cap, best-effort); GitHub token support (constant → filter → the existing `github_access_token` setting; GitHub hosts only) with anonymous enrichment capped at 10 skills per source + stopped on the first 403/429; the empty `VoltAgent/awesome-agent-skills` default removed. 17/17 tests. (Full notes pre-staged into the 1.1.99 CHANGELOG section in-window.)
- **Elementor partial-deploy warning flood fixed (PR #6961)** — `class_exists( $widget_class, false )` keeps the widget-registration loop off the Composer autoloader; truncated uploads degrade silently.
- **Sub-projects** — nvoos-content-graph **1.0.8 → 1.0.9** (#6959: pre-init cron → `init`, packaging tri-sync, free-base-version disclosure, regenerated POT; PCP 0 ERRORs / 161 WARNINGs) + the checkout-modal polish (#6958: Stripe loading spinner, filterable free base-version link, dev-status note); Proposal 061 (MCP registry publishing, docs-only) Phase 2 executed (bridge published to the official MCP Registry + npm 0.1.0-alpha.4).
- **Skills** — three new coding-time skills (spa-ui #6955, toolkit-creation #6962, checkout-integration #6963 — count 63 → 66) + the content-graph 1.0.9 lessons in wporg-submission/test-suite (#6960, patterns 67 → 68).
- **Tool counts** — ~353 base + ~1,339 Pro (~1,692 total; +1 base +26 Pro).

## SPA UI Stack, Gateway OAuth 2.1 & the Docs Hub Playground (v1.1.99)

- **SPA UI stack enhancement (PR #6952, Proposal 060)** — toolkit-shell **0.2.0 → 0.3.0** (Radix Dialog/ConfirmDialog/DropdownMenu/Select/Tabs/Checkbox + CVA Button, TanStack TableView with ConfirmDialog deletes, @dnd-kit Kanban with persisted moves, react-hook-form + zod FormView built from the manifest at runtime, sonner toasts, 14 `--nds-*` tokens, ESLint dual-React guard) and schedule-anything-spa → **0.2.0** (Tailwind v4, 16 shadcn-style primitives, @xyflow/react v12, route-level code splitting, `@wordpress/i18n`, axe + jsx-a11y gate); shipped suites 31/31 + 23/23.
- **MCP Gateway OAuth 2.1 resource server (PR #6945, Phase 1)** — RFC 9728 metadata (`GET /.well-known/oauth-protected-resource` + `/mcp` variant), 401 `WWW-Authenticate` challenges with `resource_metadata`/scopes, zero-dependency JWT validation (node:crypto RS/ES, JWKS cache + rotation refetch, strict iss/aud/exp/nbf/scope, fail-closed), scope-based site binding (`site:<slug>`), and **no token passthrough** (OAuth tokens never travel upstream — confused-deputy discipline); inert until `GATEWAY_OAUTH_ISSUER`; Phases 2–5 (Auth0 provisioning, PKCE e2e, registry submission, deployment guide) deferred. Gateway stays 0.1.1.
- **Docs Hub Playground demo + wp.org Live Preview (PRs #6944/#6946–#6949)** — local-first seed + standalone `demo.json` + Live Preview `blueprint.json` (dev-only across all three exclusion lists), the preview-loader self-activate fix (`activate_plugin()` + `include_once` fallback), the 10-page wiki seed, the full-page `/docs/` SPA demo (zero-margin full-bleed), and the Playground badge.
- **Gateway listing prep + Claude Code plugin (PRs #6941–#6943)** — GPL LICENSE + `license` field + the directory-submission doc, the `mcp-gateway.svg` icon + `/assets` static serving, `.claude-plugin/plugin.json` + `/connect` (mirror sync = marketplace source).
- **Figma Agent Skills catalogue (PR #6938)** — `figma/mcp-server-guide` default source + name-dedupe in `normalise_manifest_skills()`; CG Pro mirror byte-identical; Restore Default Catalogues surfaces it for existing installs.
- **Gmail body extraction fixed (PR #6939)** — empty-part skipping, `text/plain` ↔ `text/html` fallback, `message/rfc822` recovery, base64 decoding, actionable `body_source`/`body_empty_reason`.
- **Complete-ZIP blueprint stripping fixed (PRs #6936/#6940)** — the 1.1.98 Complete ZIP shipped 0 of 65 blueprint JSONs; `bin/build-plugin-zip.sh` + `release.yml` excludes root-anchored + a CI guard.
- **Media worker synthetic external targets (PR #6941)** — `STATUS_EXTERNAL_TARGETS`, synthetic-only mode, split-brain `checkedAt` + sweeper `downSince` fixes; worker stays 3.4.0 (bump deferred to the release process).
- **Fleet Operator token masking (PR #6950)** — no plaintext operator tokens (readonly password input + collapsed credential blocks).
- **Tool counts** — ~352 base + ~1,313 Pro (~1,665 total; unchanged).

## Figma-to-Elementor Pipeline, Unified Blueprints Fixes & the Dependabot Sweep (v1.1.98)

- **Figma-to-Elementor design-to-build pipeline (PR #6934, Proposals 057–059 — docs + skill, no PHP)** — the 7-stage agentic pipeline (Scope → Read → Plan → Tokenize → Build → Verify → Handoff) rides the shipped MCP Apps / OAuth / A2A / per-toolkit MCP server machinery: Figma MCP on the read side, Elementor MCP on the write side, single-assistant and split topologies, normative rules (`get_design_context` first, tokenize-before-build, drafts only, never publish, Figma read-only), and the build-manifest contract + JSON Schema. The new bundled skill `design-figma-to-elementor` ships with it (**coding-time 62 → 63, base bundled 75 → 76**) + the user guide. Proposal 058 (transactional DTCG token import) is the user-facing follow-up; Proposal 057 (SPA toolkit design-file system) is parked as reference; Phase 3 (end-to-end demo + Verify seed test) is deferred on live endpoints (Figma account + Elementor 4.3+ site).
- **Unified Blueprints fixed (PR #6933)** — (1) the unanchored `examples` exclusions in `.gitattributes`/`.distignore` matched every directory named `examples`, stripping all 65 toolkit blueprint JSONs + the per-toolkit import tools from `git archive`/release ZIPs — both rules are now root-anchored (`/examples`, `/assets/examples`); (2) the page now gates blueprints on toolkit enablement (`$toolkit_enable_keys` mirrors each import tool's `is_available()` gate; `get_all_blueprints_grouped()` skips disabled toolkits; both AJAX handlers reject them; `post_title` card fallback).
- **Gateway sync dispatch + changelog (PR #6927)** — `sync-mcp-gateway.yml` gains `workflow_dispatch` (manual syncs always possible) + a version guard (syncs skip when the incoming `package.json` is older than the mirror tip — out-of-order runs can never roll `nvoos-mcp-gateway:main` backwards); `addons/mcp-gateway/CHANGELOG.md` tracks 0.1.0 → 0.1.1.
- **Dependabot sweep (PR #6931)** — 138 of 166 open npm alerts resolved via bounded in-major bumps across 17 trees (axios ≥1.20.0 <2, brace-expansion@^1 ≥1.1.21 <2, source-map-js ≥1.2.2 <2, dompurify, proxy-addr, compression, joi, katex ^0.18.2, moment, simple-git ≥4.0.1 + @simple-git/argv-parser, basic-ftp, postcss-selector-parser@^7, webpack-dev-middleware) with npm-pack evidence for each cross-version move; 28 deferred in issue #6930; dashboard dismissed (138 `fix_started` + 28 `tolerable_risk` → 0 open alerts).
- **Tool counts** — ~352 base + ~1,313 Pro (~1,665 total; unchanged).

## NV oOS MCP Bridge npx Package, MCP Gateway Addon & Per-Request Memory Cut (v1.1.96)

- **nvoos-mcp-bridge npx package (PR #6897, Proposals 054/055)** — `@nvdigitalsolutions/nvoos-mcp-bridge` is a zero-dependency stdio↔HTTP relay npm package: `npx -y @nvdigitalsolutions/nvoos-mcp-bridge nvoos-mcp <url> --token <cred>` connects Zed / Claude Desktop / Cursor / Codex to any NV oOS site (Streamable HTTP `/mcp`), and `nvoos-mcp-ssh` owns the SSH port-forward for no-public-route sites (same env vars as the manual `bin/mcp-bridge-ssh.js` spawn: `MCP_AI_SSH_USER`/`_HOST`/`_PORT`/`_REMOTE_HOST`/`_REMOTE_PORT`, `MCP_AI_HOST_HEADER`, `MCP_AI_SSH_EXTRA_ARGS`, `MCP_AI_ENV_FILE`). The package syncs byte-identical from the repo `bin/` (CI drift gate), ships hermetic `node:test` suites + opt-in Docker E2E, and the npm publish workflow (`npm-publish-nvoos-mcp-bridge.yml` + `bin/publish-mcp-bridge.sh`) is ready — **the public publish itself is deferred on the npmjs scope claim + `NPM_TOKEN`**.
- **Fleet Operator editor configs (PR #6897)** — `generate_zed_json()` / `generate_claude_json()` emit copy-paste `context_servers` / `mcpServers` blocks through the npx package; the one-time operator result and the admin page now offer Zed / VS Code / Claude Desktop blocks alongside the Hermes YAML.
- **MCP Gateway addon (PR #6897, Proposal 055 — addon 0.1.0, inventory #31)** — `addons/mcp-gateway/` exposes the whole fleet as one public MCP endpoint: a media-worker-style Express service speaking stateless streamable HTTP (MCP 2026-07-28) at the planned `mcp.nvoos.pro`, with public API-key auth + rotation, per-key rate limits, `<site-slug>.<tool>` tool namespacing against the per-site `/mcp` bridges, graceful per-site degradation, and fail-closed env config (missing config refuses to start). 39/39 node:test suites + `npm audit` 0. Deferred on maintainer credentials: the mirror repo (`MCP_GATEWAY_REPO_TOKEN`), the Velocity deployment + DNS/TLS, and the directory submissions.
- **Per-request memory cut + bootstrap hardening (PR #6896)** — plain front-end requests no longer load ~350 tool classes: `should_eager_load_default_tools()` → `wp_mcp_ai_is_plugin_runtime_context()` defers the defaults (REST/admin/AJAX/cron/CLI/WP-CLI/installing/test contexts load eagerly; the filter lets hosts force eager loading), `ensure_default_tools_loaded()` loads on first access, and third-party `wp_mcp_ai_register_tools`/`wp_mcp_ai_tools_init` registrations win slug conflicts over deferred defaults. The OOS engine pre-warm (12 adapters + 12 provider clients + ~140 core tools) is gated off page views; the model-catalog migration reads the ~250–400 KB JSON only on `filemtime` change; the Pro blob options (`wp_mcp_ai_pro_remote_sites`, workflows, execution logs, Ezuite SKUs, approvals, media-worker secrets, pricing buffers, slash-command history, license key) write `autoload=false` with the one-time `wp_mcp_ai_pro_repair_option_autoload()` repair. The bootstrap-integrity guard + fail-soft loader (`wp_mcp_ai_require_if_exists()`) make missing files after a partial update degrade instead of fataling — skipped files recorded in a non-autoloaded option, one-time admin notice, self-healing prune; updater `VERIFY_FILES` +17 paths; new Site Health `wp_mcp_ai_file_integrity` test. Nine dead FF/Yahoo registry entries removed; the `Inline_Async_Tick_Trait` double-declaration activation fatal fixed (`trait_exists()` guard). **A/B probe: 42 MB deferred vs 74 MB eager per front-end render.**
- **Media Worker runtime version strings (PR #6895)** — a deployed 3.4.0 worker no longer reports 3.3.0: both `/api/health` `version:` fields + the `WORKER_VERSION` heartbeat constant now match `package.json` (the five-spot version-sync checklist lives in `.context/media-worker.md`).
- **Tool counts** — ~350 base + ~1,312 Pro (~1,662 total; unchanged).

## ECC Harness, OOS Parity Closure & Gateway Protocol Negotiation (v1.1.97)

- **Agent-harness enhancements (PR #6912, Proposal 056 — all inert by default)** — six research-grounded features (FrugalGPT cascades, 2026 LLM-as-judge standards, OWASP LLM Top 10 2026, tiered-memory literature; ECC, MIT, credited in `CREDITS.md` + `@credit` tags):
  - **Cascade model routing (P1)** — cheap-tier escalation with judge-verified promotion on **both** engines: `lib/core`'s `CascadeRouter` (extends `ProviderRouter`, injected into the OOS engine via the bridge factory's WordPress `CascadeClassifier`/`CascadeValidator` adapters) and the live legacy base+Pro path (`WP_MCP_AI_Cascade_Executor` gating `WP_MCP_AI_Language_Model_Router::create_chat_completion()`, Pro Jev classifier via the proposal-045 routing signal). One `wp_mcp_ai_cascade_enabled` switch + one classifier/validator seam govern both paths; completes the previously dormant tier machinery with post-call validation + escalation.
  - **`run_assistant_eval` (+1 base)** — three trajectory judges (tool selection / use / response quality) + deterministic checks + the `wp_mcp_ai_eval_judge` seam.
  - **Hook profiles (P3)** — minimal/standard/strict gating, meta → filter → option → constant resolution, master switch + kill list (`includes/hooks/`).
  - **`scan_assistant_security` (+1 base)** — OWASP-informed assistant-config audit with masked secret evidence + posture score.
  - **Session distiller (P5)** — session-end transcript → canonical `wp_mcp_ai_memory_stored` event (MemPalace / CCT / Graphify / recall hydrate; zero provider cost by default).
  - **`suggest_workflows_from_history` (+1 Pro)** — mines the harness trace store for recurring tool chains (frequency × recency × success).
- **OOS parity gaps closed (PR #6913)** — the four Proposal 029 G2 promotion blockers: the destructive-ops gate no longer becomes an HTTP 500 on the OOS path (typed catch → `WP_MCP_AI_REST::translate_gate_exception()` → canonical 428/429 envelopes); `apply_pre_response_render()` runs the Output Guardrail + Citation Verifier at the final payload on all three surfaces (legacy non-streaming, legacy streaming's final SSE event — blocked → `error` event, OOS handler); the OOS bridge fires `wp_mcp_ai_agentic_iteration_complete`; the before-tool-execute waterfall bridge gains regression tests. **`bin/check-chat-parity.php` now tracks all four surfaces (35 → 38 features, 100% parity) with a `parity-check` CI job.**
- **Gateway protocol negotiation (PR #6914)** — the MCP Gateway's `initialize` now negotiates the protocol version (`negotiateProtocolVersion()`, `2024-11-05` fallback, reads `protocolVersion` + `supportedProtocolVersions`) — Zed and other strict MCP clients stop aborting with "Unsupported protocol version" against `mcp.nvoos.pro`. Gateway **0.1.0 → 0.1.1 post-window (#6925)** — the non-force mirror sync bumped the addon so `/health` proves the live Velocity build.
- **Public npm publish shipped (PRs #6898, #6904–#6909, #6911)** — the v1.1.96-deferred publish is executed: all **23 `packages/`** live on the public registry at 0.1.0-alpha.3 (`nvoos-mcp-bridge` `latest` = 0.1.0-alpha.3 — the bare `npx -y @nvdigitalsolutions/nvoos-mcp-bridge` form resolves the bin alias; `nvoos-api`/`nvoos-sse-client` republished at **0.1.0-alpha.4** after the TypeScript was stripped from their shipped `.js` files). GitHub Packages covers all 23 + the new dry-run-by-default `npm-maintenance.yml` (note: `unpublish` via the workflow is blocked for 2FA-bypassing granular tokens — maintainer-local only).
- **Tool counts** — ~352 base + ~1,313 Pro (~1,665 total; +2 base +1 Pro).

## Toolkit Hardening Wave, Real Image Processing, Toolkit Labels & SSE Keepalives (v1.1.95)

- **Real image processing (PR #6881, issue #6877 — Media Worker 3.3.0 → 3.4.0)** — the four placeholder image tools now run real processing through the media worker sidecar and never claim fake success. Wave 1 (Sharp-native): `POST /api/image/enhance` (sharpen/contrast/saturation/denoise) + `POST /api/image/upscale` (factor 2/4/8, lanczos3, 8192px cap, honest `upscale_method`) behind the new Pro `WP_MCP_AI_Sharp_Image_Processing` trait (availability probe, subprocess runner, sidecar decode, media upload; `wp_mcp_ai_local_sharp_available`/`wp_mcp_ai_sharp_process_image` seams) drives `enhance_image_quality` + `upscale_image_ai` (local Sharp → worker → honest `wp_mcp_ai_sharp_unavailable`); `optimize_image_sharp` re-routes enhance to the sidecar. Wave 2 (AI image-to-image): `POST /api/image/edit` (`colorize` | `style_transfer`, 9-preset `STYLE_PROMPTS`, Gemini → OpenAI → Replicate auto-resolution, `503 capability_unavailable` without keys, `REPLICATE_STYLE_TRANSFER_MODEL` required) behind the new Pro `WP_MCP_AI_Provider_Image_Edit` trait drives `colorize_image` + `apply_artistic_style` — `_wp_mcp_ai_colorized`/`_wp_mcp_ai_artistic_style` meta written only on real success. Wave 3 (Real-ESRGAN) deferred.
- **Nine-toolkit hardening wave (PRs #6875–#6893)** — the per-toolkit audit loop (new `mcp-ai-wpoos-toolkit-audit` skill) fixed confirmed fatals across ten clusters: document-generation (`extract_pdf_text`'s unguarded `shell_exec()`, the nonexistent Gemini `generate_content()`, array-content flattening, the repaired fenced-JSON regex, the Anthropic OCR provider); image-production (prompt-optimizer provider bypass, Stability/sidecar guards); CRM (`draft_upwork_proposal`'s Gemini `trim()` fatal, `draft_lead_reply`'s dead `wp_mcp_ai_chat_completion()` path); ECA management (`research_eca` `preg_match()` fatal); ecommerce (unguarded `exec()` → `WP_MCP_AI_ALLOW_SHELL_TOOLS` + Process Service); media (nested `WP_Error` reads, the `year_month` directory traversal closed, the unreferenced-media meta fail-safe); healthcare (HIPAA audit-trail rewire + OpenMed guards); shopify-sync (the `count(null)` failure-path fatal + MCP-server descriptor wiring); orchestration (envelope/parser flattening, cross-tool `is_wp_error()` guards); loose incident tools + shared services (never-loadable `execute()` signatures, the nonexistent Paper Store `maybe_commit()`, Qdrant/gmail/roboflow/data-quality guards). Email-marketing verified clean (tests only). Mirrors byte-identical to CG Pro where they exist.
- **Toolkit labels in `list_mcp_tools` (PR #6874)** — `WP_MCP_AI_Tool_Registry::get_tool_toolkit()` resolves the declared `toolkit` key or derives the namespace from the declaring folder; `wp_mcp_ai_tool_toolkit` filter for addons. Previously-unlabelled Pro tools (`pro_pdf_document`, `transcode_video`, `okf_*`) now respond to `toolkit=`-filtered searches. Newsletter 9.4.6+ bootstrap fatal fixed (loader requires it on `plugins_loaded`); `create_company` → canonical `write`/`state-changing` flags.
- **Inter-step SSE keepalives (PR #6879)** — `send_sse_keepalive()` emits comment frames at four chat-stream boundaries, so Cloudflare/nginx idle-read timeouts no longer reset long agentic streams. Phase 4b (deadline-triggered job-stream offload) is the new proposal doc only.
- **Tool counts** — ~350 base + ~1,312 Pro (~1,662 total; unchanged).

## ChatGPT Plugin Addon, Decision-Scope Guard & MCP Grant Enforcement (v1.1.94)

- **ChatGPT plugin addon + OAuth 2.1 resource-server (PR #6871)** — `addons/chatgpt-plugin/` (0.1.0) packages the site's native MCP bridge for OpenAI agent surfaces: portable `plugin.json` + `mcp.json` (Agent Plugins schema) with a `.codex-plugin` overlay, three runtime skills (`site-operations`, `content-studio`, `commerce-desk`), a local/Git-backed marketplace entry, dependency-free `bin/` scripts (`stamp-site`, `package-plugin`, `validate`), and subtree-split sync (`sync-chatgpt-plugin.yml`) to the `nvoos-chatgpt-plugin` mirror (secret-presence guard until `CHATGPT_PLUGIN_REPO_TOKEN` exists). Tier 1–2 (local/team) works today with assistant credentials; Tier 3 (public ChatGPT plugin) uses the base OAuth contract: `WP_MCP_AI_OAuth_Resource_Server` (RFC 9728), `/.well-known/oauth-protected-resource` + `/.well-known/openai-apps-challenge`, 401 `WWW-Authenticate` on the MCP route (Auth0 contract preferred; the Pro `WP_MCP_AI_OAuth_Server` fallback stays), per-tool `securitySchemes` in `tools/list` (`site:read`; writes add `content:write`; no `noauth` entries), the **`nvoos_get_profile` tool (+1 base)** (stable opaque HMAC id, `_meta["openai/profile"]` + `outputSchema`), and RFC-9728-resource-identifier token acceptance in the REST authenticator.
- **Decision-scope guard (PR #6866, Proposal 052)** — the base `WP_MCP_AI_Decision_Scope_Guard` bounds every decision-model dispatch: declared **domains** (`advisory`/`content`/`operations`/`verification`), an **authority ceiling** (`inform` → `suggest` → `act`), banned domains (`life`, `people`, `ethics`, `identity`) failing closed to the caller's deterministic fallback, and `act` authority gated on the `wp_mcp_ai_decision_act_domains` filter (banned domains can never be granted). The **`WPMCPAI.Decisions.ScopeDeclared`** PHPCS sniff (severity 5) requires `@decision-domain` + `@decision-authority` on every dispatch method — undeclared dispatches fail CI. All six existing Jev dispatch sites declared and gated with zero behavior change.
- **Toolkit MCP grants enforced at runtime (PR #6872)** — the v1.1.88 deny-by-default grant gate was dead code outside wp-admin (the grant-lookup class loaded admin-only). `mcp-servers-init.php` now loads the class definition in every context, so non-granted assistant-scoped `tools/call` requests return `-32601` and `initialize` echoes the exact grant list. Granted servers' tools now flow onto the `wp_mcp_ai_chat_effective_tools` seam (chat payload, `tools/list`, direct execution, `list_mcp_tools` — per-tool capability checks still apply), and the Context Window Estimator counts the same slugs via the new base `wp_mcp_ai_prompt_window_toolkit_tool_slugs` filter.
- **OOS engine chat parity (PR #6872)** — `handle_chat_request_oos()` runs the same `wp_mcp_ai_attention_tool_slugs` → `wp_mcp_ai_chat_effective_tools` pipeline as the legacy path, and the WordPress `EventDispatcher` translates the four mapped domain events into the documented legacy `wp_mcp_ai_*` argument tuples — fixing the `ArgumentCountError` that turned every OOS chat into an HTTP 500 (`$request` is null on the OOS path; subscribers stay null-safe).
- **FlowHub MCP OAuth login proxy (PR #6867)** — `get_oauth_client_options()` resolves the connection's proxy/timeout/SSL options (via `connection_ref` or gateway-URL match) and persists them in the OAuth flow-state transient, so discovery/DCR/token-exchange/refresh/revoke all ride the proxy — geo-blocked deployments can now complete the web login.
- **Safe-mode REST error masking fixed (PR #6869, closes #6860)** — admins (`manage_options`) can opt in per request via `?verbose_errors=1`; every masked response carries a 10-char correlation `ref` backed by a server-side Recent Errors entry; `sanitize_error()` preserves the original HTTP status (500 only as default). Ported byte-identical to the CG AI `RequestGuard`.
- **Site Health fixes (PR #6870)** — `get_site_health` pre-loads `wp-admin/includes/misc.php` before the `wp_check_php_version()` polyfill (WP 6.9 redeclare fatal gone); the schema check verifies `wp_mcp_ai_activated_version`; cold analytics caches no longer warn at 0% hit rate. Docker dev environment: in-container port 8000, `DISABLE_WP_CRON` + cron loop, PHP 8.3 images, `WP_DEBUG_LOG` in `/tmp`.
- **Dependency advisory (PR #6868)** — markdown-it override floor `>=14.2.0` → `>=14.3.1 <15` across three trees (GHSA-253c-mchw-3w2r; lockfile-only).
- **Tool counts** — ~350 base + ~1,312 Pro (~1,662 total; +1 base).

## Fleet Status Monitoring, WP-CLI Parity, FlowHub MCP Apps & October Model Catalog (v1.1.93)

- **Media worker fleet status monitoring (PR #6849 — worker 3.2.0 → 3.3.0)** — the media worker becomes the fleet status/monitoring service, all opt-in behind `STATUS_ENABLED=1`: `POST /api/status/heartbeat`, `GET /api/status/summary|sites/:slug|history/:slug|metrics`, OpenMetrics, and a public allowlisted `GET /status` page (heartbeat validation, `at_risk` → `major_outage` state machine, dead man's switch sweeper, synthetic HTTP/TLS checks through the SSRF guard, HMAC-signed webhook + email alerts). The plugin half ships `WP_MCP_AI_Media_Worker_Config`, an opt-in heartbeat emitter, the `WP_MCP_AI_Status_Alert_Poller`, the `remote_monitor` service-status source, **2 new base tools** (`get_fleet_status`, `get_site_uptime`), `GET /mcp-ai/v1/status/sites`, and the `/status fleet` slash sub-command; Pro adds incident auto-create/resolve + the Status Dashboard Fleet section.
- **WP-CLI parity & hardening (PR #6852, Proposal 050)** — `wp mcp-ai tool call <slug> --args='{…}'` mirrors REST `POST /tools`; new `wp mcp-ai security` (posture, audit, purge-audit, gate, keys) + `wp mcp-ai model` (list, suggestions, discover) Base commands; nine new Pro command trees (`crm`, `incident`, `maintenance`, `schedule`, `workflow`, `vault` metadata-only, `remote-site`, `communication`, `media-studio`); `--fields`/`--field`/`--format=count`; every mutating subcommand gates on `manage_options`; canonical `mcp-ai calendar/place` + `mcp-ai ezuite/flowhub/shopify-sync/profession` namespaces (legacy top-level names remain as aliases); full operator reference in `docs/operations/wp-cli.md`; WP-CLI 2.9+ minimum.
- **FlowHub MCP Apps (PRs #6854/#6861)** — FlowHub-in-MCP-mode connections now appear in the assistant MCP Apps "Add from Remote Sites" dropdown (labelled `Name (FlowHub MCP — https://mcp.flowhub.com)`) with the full OAuth login flow; the connection's proxy (`proxy_url`/`proxy_auth`) now carries into the MCP Apps gateway path so geo-blocked deployments need no direct egress to `mcp.flowhub.com`.
- **Financial Planner OpenStock parity (PR #6857, Proposal 051)** — Finnhub BYO-key market data (masked key inputs), **+3 Pro tools** (`watchlist_sync`, `market_overview_widget`, the orphaned `import_financial_planning_blueprint` registered), `price_alerts` data-mode parity, and an `openstock-market-analyst` blueprint.
- **October 2026 model catalog (PR #6863)** — catalog **v2026.10.03**, 238 models, **18 providers — Z.AI joins**: `gpt-6-sol`/`gpt-6-luna`, `claude-sonnet-5-5`/`claude-opus-5-5`/`claude-mythos-5-1`, `gemini-3.8-live`, `gemini-omni-1.1-flash`, Cloudflare Workers AI refresh, Z.AI `glm-5.3` family; codex-line/Kimi-k2 removals with migration entries; deprecations with sunset dates (`gpt-4o` 2026-10-23, `gpt-5` family 2026-12-11, …); defaults refreshed (`default_gemini_model` → `gemini-3.8-flash`, `gemini_live_model` → `gemini-3.8-live`, `openai_realtime_model` → `gpt-realtime-2.1`, Anthropic sonnet-5-5/opus-5-5, Z.AI `glm-5.3`).
- **Media Studio 0.6.1 + schedules + validated-tool parity fixed (PRs #6853/#6855/#6856/#6858/#6859)** — fashion transforms pass the resolved Gemini image model (no more `/ai/generate` 500); tool-rule validation failures now return HTTP 400 with the error list; `required_settings` falls back to the credential resolver; **Media Studio 0.6.0 → 0.6.1** (the version `/health` + `/ai/capabilities` + `wp mcp-ai media-studio status` report). Schedules no longer trigger on create/save (timing-change-only reschedules; recurring starts one interval out). `aspect_ratio: 'auto'` passes the validated Gemini tools.
- **Dependency advisory (PR #6850)** — undici 7.30.0 across 8 addon lockfiles (GHSA-w293-vg96-wgc3, CVE-2026-84961; lockfile-only).
- **Tool counts** — ~349 base + ~1,312 Pro (~1,661 total; +2 base +3 Pro).

## Media Studio Fashion Production, Inline Vision Data URLs & Provider-Content Fixes (v1.1.92)

- **Media Studio fashion production suite (PRs #6839/#6844 — addon 0.1.0 → 0.6.0)** — the `fashion-studio` AI mode lands in Media Studio: eight Gemini-driven transforms (on-model, model-swap, face-swap, background, recolor, packshot, detail-repair, try-on) via `edit_gemini_image`, REST `/ai/*` routes with the D-1 consent/acknowledgment gate + D-3 cost tripwires ($0.25 per-image / $10 per-job review, $100 hard cap), a lazy-loaded SPA mode, and forced disclosure watermarks on face outputs. Pro Phase 2 adds the fashion identity library (`mcp_ai_fashion_model` CPT + consent gating), the batch/review queue (`mcp_ai_fashion_job` CPT, approve/reject/reroll, WooCommerce + media collection export), and the `fashion_studio` Pro module; Phase 3 ships the marketplace output pipeline (amazon/woocommerce/social/web profiles); Phase 4 ships IPTC 2025.1 XMP + best-effort C2PA provenance; Phase 5 ships a sidecar-backed fashion `video` transform and **8 new Pro tools** (`fashion_onmodel_generate`, `fashion_model_swap`, `fashion_background_generate`, `fashion_recolor`, `fashion_packshot`, `fashion_virtual_tryon`, `fashion_batch_job`, `fashion_identity_manage` — self-gated via `is_available()` on the Media Studio AI service) plus the Workflow Builder `fashion` preset category (10th).
- **Inline vision data URLs + payload optimization (PR #6846)** — OpenAI/DeepSeek vision paths now inline server-fetched base64 bytes (local attachments read off disk, remote URLs downloaded by WordPress) instead of handing URLs to provider servers — fixes `Failed to download image from …` on hotlink-protected/CDN/staging media. Oversized JPEG/PNG downscaled to a 2048px vision-tile cap, opaque PNGs re-encoded JPEG q82, originals never modified. New **Chat Client → Features → Inline Image Optimization** toggle (default on) + `wp_mcp_ai_image_inline_*` filters. See SKILL.md Troubleshooting for the download-failure entry.
- **Provider content + credential fixes (PR #6845)** — the six research tools no longer fatal on array AI content (shared `WP_MCP_AI_Tool_Research_Content_Normalization` trait; `research_project` JSON regexes repaired); `WP_MCP_AI_DeepSeek_Client` flattens array content blocks; `create_post` matches tags on word boundaries (single-word tags suggested only); the vision tools resolve keys via the merged settings + `WP_MCP_AI_Credential_Resolver` (see SKILL.md Troubleshooting).
- **Coverage manifest (PR #6847)** — the Pro tool coverage manifest is regenerated with the 9 fashion-stack classes.
- **Tool counts** — ~347 base + ~1,309 Pro (~1,656 total; +8 Pro).

## FlowHub MCP Mode, OAuth Discovery & JSON Envelope Protection (v1.1.91)

- **FlowHub Connection MCP mode (PR #6836)** — FlowHub Remote Sites connections gain a `flowhub_mode` selector (`api` default | `mcp`); MCP mode designates the connection as the backend for the FlowHub toolkit MCP server. `WP_MCP_AI_FlowHub_Connection_Helper::get_mcp_connection_id()` resolves the first enabled MCP-mode connection; the toolkit MCP REST controller injects its `connection_id` only when the caller passes none — MCP-triggered refresh/sync calls route through the explicit-connection path (decrypted credentials + the connection's encrypted proxy via `http_api_curl`). Explicit `connection_id` always wins; the seam is generic (`WP_MCP_AI_Toolkit_Server_Base::get_mcp_connection_id()`).
- **MCP App OAuth discovery per MCP spec (PR #6835)** — `discover_metadata()` walks the full chain: RFC 8414 metadata (+ §3.2 path insertion) → RFC 9728 protected-resource metadata (every `authorization_servers` entry) → 401 `WWW-Authenticate` probe → OIDC → WordPress REST fallback. RFC 8414 docs accepted only with both endpoints; per-attempt diagnostics surface real transport errors; server-advertised `default_scope` honored; multi-challenge parsing; 10 s per-probe cap. See SKILL.md Troubleshooting for the discovery entry.
- **OAuth redirect allowlists (PRs #6831/#6832)** — LinkedIn, QuickBooks, Mailjet, and Yahoo Sports connect buttons no longer bounce to wp-admin (hosts added to `allowed_redirect_hosts` via per-provider filters). See SKILL.md Troubleshooting.
- **JSON envelope protection (PR #6827)** — orchestration CCTs gate on the physical table (`is_storage_ready()`: table + every required column → transients fallback); the new `WP_MCP_AI_Db_Output_Guard` wraps `execute_tool()` + both REST tool handlers — no surface leaks `$wpdb` error HTML into a JSON response.
- **Fixes (PRs #6829/#6830/#6828)** — Security events table + CSV exporter read canonical `event_type`/`ip_address` keys; the orchestration dashboard no longer renders twice (duplicate loader `new` removed); `rfdetr_catalog_search` joins the `ecommerce` preset + Pro coverage manifest regenerated.
- **Dependency advisories (PRs #6833/#6834)** — `nodemailer` `^10.0.9` in pro + media-worker (GHSA-g57g-f23g-4646; vendor bundle refreshed 8.0.5 → 10.0.9); `fast-uri` ≥4.1.5 across 4 trees (GHSA-jvvf-x445-j334).
- **Ecosystem port (PR #6825)** — the RF-DETR vision cluster ports byte-identical into `nvoos-content-graph-pro` (Wave F3 sub-cluster 1; tracker row appended).
- **Tool counts** — ~347 base + ~1,301 Pro (~1,648 total; unchanged).

## Telegram Delivery Fixes, Memory Bridge & Wave F2 Toolkit Completions (v1.1.75+)

- **Telegram broadcast credentials** (PR #6482) — inline credentials stored as
  JSON strings no longer fatal the array-typed broadcast tool;
  `normalize_channel_credentials()` decodes/rejects, and the Remote Sites
  schema mapping decrypts `api_key`/`token` for the real storage keys.
- **Scheduled delivery credential fallback** (PR #6488) — tier-4 fallback
  resolves the first enabled Remote Sites connection of the channel type for
  cron delivery; `create_pro_schedule`/`update_pro_schedule` and the schedules
  REST endpoint accept `result_delivery`; diagnostics never carry secrets.
- **Content Graph memory bridge + NV oOS Complete checkout** (PR #6486) —
  new `wp_mcp_ai_wake_up_context_graph_retriever` filter seam on
  `wake_up_context`; the checkout sells the Complete bundle (base + Pro) with
  a conflict guard; nvoos-content-graph **1.0.4 → 1.0.6**.
- **Wave F2 port completions** (PRs #6476–#6501) — `nvoos-content-graph-pro`
  (1.0.0) completes the financial-planning, social-media, and mcp-servers
  toolkit ports plus remote-sites/video/analytics/multilingual/cloudways/
  dj-management/image-production slices.
- **Tool count** — unchanged: ~303 base + ~1,265 Pro (~1,568 total).

## RF-DETR Vision Cognition, Strict MCP Scope & Memory Identity Closure (v1.1.90)

- **RF-DETR vision cognition (PR #6824, Proposal 049)** — Pro `WP_MCP_AI_Roboflow_Inference_Service` (one HTTP client, three trust tiers: key-less self-host loopback/private, dedicated, Serverless Cloud API — fail-closed credentials, SSRF-guarded URLs); **2 new Pro tools** (`rfdetr_detect` boxes/masks/keypoints, `rfdetr_catalog_search` fine-tuned catalog models); `roboflow` provider joins `analyze_image_objects` (no new slug); `identify_image` rung 3c reports `rfdetr_detections` (class-guarded — Base skips cleanly); XL/2XL behind a PML consent toggle.
- **Strict MCP assistant-scope toggle (PR #6819)** — opt-in `mcp_require_assistant_scope` (Security → Access & Identity, default OFF): `tools/list`/`tools/call` fail closed with HTTP 403 (`wp_mcp_ai_assistant_scope_required`) when no assistant resolves; the 403 special-case is scoped to this one error code (all other MCP errors keep the HTTP 200 JSON-RPC envelope). See SKILL.md Troubleshooting for the HTTP 403 entry.
- **Upwork MCP as first-class MCP Apps references (PR #6823)** — Upwork-in-MCP-mode connections appear in the assistant "Add from Remote Sites" dropdown with the full OAuth login UI; chat-time ref resolution via the official gateway + decrypted central `mcp_oauth`; post-login reference persistence.
- **Memory identity + IDOR closure (PR #6815)** — the eight memory tools resolve `agent_id` from the execution context; cross-agent access gated behind `manage_options` (403 `mcp_ai_memory_scope_denied`); credential-pattern scan + expiry signalling on the store/retrieve pair.
- **Letterhead personalization (PR #6816)** — `Dear {{to_name}}` + `{{#to_name}}…{{/to_name}}` conditional blocks; bundled template reads prefer the `direct` filesystem transport.
- **Dependency advisories (PR #6817)** — `js-yaml` ≥5.4.1 + `webpack-dev-middleware@^8` ≥8.3.0 across 13 trees (15/17 alerts; AI SDK migration tracked as #6818).
- **Tool counts** — ~347 base + ~1,301 Pro (~1,648 total; +2 Pro — the RF-DETR pair).

## Google Classroom ECA, Design System Rename + Email Templates & Upwork MCP Mode (v1.1.89)

- **Google Classroom integration for the ECA toolkit (PR #6809, Proposal 046)** — shared `includes/google/` Classroom foundation (restricted scopes, Pub/Sub push with shared-secret verification); `google_classroom` Remote Sites connection type; **12 new ECA tools** (`list_classroom_courses` … `manage_classroom_push_watch`) behind `enable_eca_classroom_integration` (default off); nightly sync engine; new base REST route `mcp-ai/v1/google-classroom/webhook`.
- **Design System addon rename + token-driven email templates (PR #6810, Proposals 047/048)** — `addons/crocoblock-ds/` → `addons/nvoos-design-system/` (**0.1.0 → 0.3.0**, zero-breakage shims); 5 built-in accessible email templates + global `wp_mail` wrapper + WCAG/EMC audit gates; **8 admin-gated `nds_*` tools** (addon-provided, not counted in base/Pro totals).
- **Upwork MCP connection mode (PR #6804)** — third `upwork_mode` (`mcp`) against the official Upwork MCP gateway via a sessionful bridge (`upwork__find_jobs`/`upwork__list_accounts`); `org_uid` resolution; OAuth via `connection_ref` with tokens in the encrypted central `mcp_oauth` store.
- **Vision + remote + EZuite fixes (PR #6805)** — `submit_document_prompt` routes images through the `input_image` vision segment path (DeepSeek `deepseek-flash` native vision); remote-connection canonical slug mapping; EZuite `item_code` enforcement; per-provider model-setting migration.
- **Handshake cache (PR #6802)** — 24h per-URL legacy-dialect hint skips the doomed `server/discover` probe (Upwork Test Connection ~24.9s → ~8.5s).
- **Security (PRs #6807/#6806)** — 0 open CodeQL alerts; ip-address/undici/multer advisory patches.
- **Tool counts** — ~347 base + ~1,299 Pro (~1,646 total; +12 Pro — the classroom tools; the 8 `nds_*` tools are addon-provided and not counted).

## Decision-Model Orchestration, MCP Apps Hardening & SaaS Controller 0.3.0 (v1.1.88)

- **Decision-model orchestration Phase A (PR #6792, Proposal 045)** — base `WP_MCP_AI_Verification_Cascade` (SDE-cascade battery, max aggregation, single-rung escalation, injectable decision client) + `wp_mcp_ai_execution_depth_confidence` seam; Pro opt-in Jev tier routing (`enable_jev_tier_routing`) + citation cascade (`enable_jev_citation_escalation`) in `research_eca`/`generate_research_report`; fail-open, off by default.
- **MCP Apps OAuth + credential hardening (PRs #6794/#6795/#6798)** — loopback-only redirect URIs via manual paste-back (`POST mcp-ai/v1/mcp-apps/oauth/complete`, 10-min state TTL); `client_id` in token exchange; inline MCP App secrets + Remote Sites verify tokens now encrypted at rest (AES-256-CBC) with persisted OAuth refresh rotation; `mcp_oauth_refresh` activity events.
- **Toolkit MCP grant gating (PR #6796)** — deny-by-default per-assistant grants (`-32601` for non-granted servers; `toolkitServers` always reflects the grant list). **Transport fixes (PRs #6799/#6800)** — legacy `initialize` fallback on bare HTTP 400; SSE response parsing.
- **Upwork job links (PRs #6790/#6793)** — canonical `/jobs/<slug>_~<jobId>/` form restored; **PayHere/Flowhub guarded requires (PR #6801)** — missing client files self-report instead of fataling.
- **SaaS Controller 0.1.0 → 0.3.0 (PRs #6791/#6797)** — production NV oOS Cloud worker + Phase 12 Plan/Apply Worker-secrets/D1-schema; gateway express 4.22.3 (PR #6787).
- **Tool counts** — unchanged: ~347 base + ~1,287 Pro (~1,634 total).

## Parity Suite, Image Identification & Outbound Booking (v1.1.87)

- **mcp-wordpress parity suite (PR #6777)** — 30 new base tools: comment/user CRUD, content/media/terms, site settings + application passwords (log-masked), 9-tool SEO toolkit — capability checks + multisite guards; gap matrix `docs/developer/mcp-wordpress-tool-parity.md`.
- **Image identification ladder (PR #6780 + #6785, Proposal 043)** — `identify_image` + 4 companions (`get_image_metadata`, `find_similar_media`, `detect_image_content`, `describe_image_layout`) in the Media Generation preset; Pro `ocr_image_classic` + `search_similar_images`; key-gated, fails closed, never a vision LLM.
- **Outbound appointment booking toolkit (PR #6786, Proposal 044)** — Pro toolkit gated by `enable_outbound_booking_toolkit`; 3 new Pro tools (`outbound_get_pipeline_stats`, `outbound_import_leads`, `outbound_manage_angle`); booking shortcode + public REST endpoint.
- **mcp-wordpress gateway addon (PR #6778)** — Streamable HTTP MCP server for Cloudways Velocity; connects via Remote Sites → MCP Server.
- **Session-budget warnings (PR #6776)** — blocked-session messages point at the reset path; `wp_mcp_ai_chat_messages` filter on both chat paths. **Restriction notice fix (PR #6779)** — distinct-user counting + render-time sweep.
- **Upwork refinements (PR #6784)** — `update_pro_schedule` edits `workflow_steps` in place; `search_upwork_jobs` gains `exclude_keywords`/tier/budget parsing.
- **Tool counts:** ~347 base + ~1,287 Pro (~1,634 total). Addons 27 → 28.

## MCP Server Connections, Higgsfield Media, Log Filters & Delivery Templates (v1.1.86)

- **MCP Apps as a Remote Sites connection type** (PR #6761, Proposal 041) — new `mcp_server` connection type with AES-256-CBC-encrypted central credentials (incl. `mcp_oauth`), real JSON-RPC handshake Test Connection, tool-discovery snapshots, restricted-host enforcement, activity logging; auth mapping (`basic_auth`/`application_password` → MCP `basic`, `custom_header` → `header`, `bearer`, `oauth`). Per-assistant `connection_ref` reference mode resolves decrypt-on-use at chat time (credentials never written back to post meta); missing refs skip with error snapshots; imported bundles with missing refs auto-disable. Export/import redacts MCP App `token`/`oauth_data` (opt-out filters). New coding-time skill `design-elementor-mcp-connection` (59 → 60).
- **Higgsfield video/image provider** (PR #6772, Proposal 042) — four new base tools (`generate_higgsfield_video`, `generate_higgsfield_image`, `check_higgsfield_request`, `cancel_higgsfield_request`) on the shared `WP_MCP_AI_Higgsfield_Client` (two-part `Key ID:SECRET` auth, submit/status/cancel lifecycle, backoff+jitter polling, immediate download; settings → env → constants credential chain); provider settings section; `check_video_status` resolves `async_*` job IDs; `lib/core` dual-layer wrappers via `oos-bridge` (not counted). Also fixes the TypeSafe tool schemas + Pro coverage manifest.
- **`get_system_logs` filters** (PR #6768) — optional `since`/`levels`/`search` filters over the structured buffers + file logs (filters summary + `filtered_out` counts; `parse_since()` is the shared canonical parser; CG AI ports base-identical).
- **Action-items template + smart excerpts** (PR #6773) — scheduled digests send only the actionable section (`action_items`, email + chat) and prefer the response's own Summary/TL;DR/action sections over blind 80-word trims.
- **Tool costs in final labels** (PR #6771) — top-level `toolResult.cost` envelope on the agentic loop + SSE streaming; client-side tool-bubble badges.
- **Environment status fixed** (PR #6767) — always-on "no assistants published" warning + dead default-assistant branch repaired; `plugin.default_provider_model` resolves the effective per-provider model.
- **Tool count** — +4 base → ~312 base + ~1,282 Pro (~1,594 total). Model catalog stays v2026.09.22. Stale 1.1.84 build ZIPs removed.

## MCP Apps Connection & Exposure Wave, Docs Hub 0.5.1, README Consolidation (v1.1.85)

- **MCP Apps connection diagnostics** (PR #6753) — per-row Test Connection / Discover Tools buttons with inline results (negotiated protocol, handshake type, server info, session state, latency, live tool count, verbatim errors), persisted per-app status badge + tool-count chip, Test All; basic auth end-to-end (raw `user:pass` auto-encoded or pre-encoded base64) with token masking (stored credentials never echoed; empty = keep); `Mcp-Session-Id` capture + echo; legacy-handshake fallback; mcpServers JSON import; loopback detection with a PHP-FPM deadlock warning; **Security Center → MCP App Allowed Hosts** setting (constant hard override → filter + saved setting merged).
- **Protocol + exposure** (PRs #6754/#6755/#6758) — the client advertises the **negotiated** `protocolVersion` post-initialize and suppresses the `_meta` envelope in legacy sessions; a new `wp_mcp_ai_chat_effective_tools` filter seam (after attention filtering, before capability checks) exposes `mcp_app_<label>_<tool>` bridge slugs to the chat payload, with the resolved assistant ID flowing through `handle_tools_list()`/`handle_tool_request()`/`execute_tool_call_internal()`/the `list_mcp_tools` catalogue.
- **In-process same-site bridge** (PRs #6756/#6757) — same-origin MCP endpoints dispatch via `rest_do_request()` (no outbound socket/TLS/extra PHP-FPM worker) with outbound-HTTP safety rails and `rest_post_dispatch` re-applied for response-side session headers.
- **Docs Hub 0.5.1** (PRs #6749/#6750/#6759) — local-first uploads source, opt-in remote import, `is_path_safe()` symlink hardening, slug-named uploads folder + one-time migration (0 blocking Plugin Check errors).
- **README anchors + consolidation** (PRs #6751/#6752) — VS16-fallback TOC anchors fixed; `bin/validate-readme-anchors.py` repaired to GitHub's real rules + CI enforcement; one 12-release Release History section + complete Previous Releases table.
- **Tool count** — unchanged: ~308 base + ~1,282 Pro (~1,590 total; bridge slugs are dynamic chat-time registrations). Model catalog stays v2026.09.22.

## TypeSafe Jev Enhancement Wave: Fidelity, Guardrails & Decision Tools (v1.1.84)

- **Plan 040 Phases 0–2** (PR #6747) — noul criteria + structured EntryType fields (recursive two-gate walk); bounded 429/5xx retries honouring `retry-after` (native client + OpenRouter bridge; 4xx/transport never retried); the bridge defaults to `typesafe/jev-1.13`; opt-in advisory decision cache (`enable_typesafe_cache`, `cached: true` + zeroed usage); `typesafe_endpoint` setting + filter; `jev-preview` alias; `min_confidence`/`weights`/token warnings + usage aliases on `typesafe_decide`. New base tool **`typesafe_guardrail`** (one noul per hazard category → advisory pass/review/block; `ai_ml` preset + coverage manifest) + bundled skill `mcp-ai-wpoos-jev-decisions` (bundled skills 74 → 75). Pro: fail-open guest-chat guardrail (`enable_jev_guest_guardrail` on the Layer I pre-chat filter), advisory `check_citations()` on `generate_research_report`/`research_eca`, and three new `manage_options`-gated tools — `typesafe_rerank`, `typesafe_eval`, `typesafe_skill_select`.
- **Capability fix** (PR #6745) — `typesafe_decide`'s declared `manage_options` matches the enforced gate (metadata-only, CI-pinned).
- **Tool count** — +1 base +3 Pro → ~308 base + ~1,282 Pro (~1,590 total). Model catalog → **v2026.09.22** (+`jev-preview`). Deferred: extraction tools, the CG port cluster, NV Cloud passthrough.

## TypeSafe Jev Decisions, Assistant Builder, ID-Handoff Contracts & Webchat Fixes (v1.1.83 post)

- **TypeSafe Jev decision provider** (PR #6728) — Jev joins as a first-class *decision* provider deliberately separate from chat: `Interface_WP_MCP_AI_Decision_Client` + `WP_MCP_AI_Typesafe_Client` (typed choice/score/noul over state; 429/`retry-after`; versioned-model logging; `test_connection()`), OpenRouter Decisions bridge (`create_decision()`, filterable endpoint, actionable 404), and the new base tool **`typesafe_decide`** (canonical envelope + two-gate sanitisation, adversarial-state caveat, `manage_options`-gated; `ai_ml` preset + coverage manifest via #6743). Pro: fail-open `WP_MCP_AI_Pro_Jev_Classifier` (`decide()`/`classify_prompt()`/`filter_sources_by_relevance()`), opt-in dispatcher `jev_routing` (REST `compare-models` passthrough), opt-in `enable_jev_research_filter`; fixes the pre-existing dispatcher `chat_completion()` bug. Model catalog → **v2026.09.21** (+3 Jev decision entries).
- **"The Assistant Builder" meta-assistant** (PR #6727) — pre-configured meta-assistant (7-phase build workflow, 10-component prompt framework) appended to `get_default_assistants()` (roster 6 → 7); idempotent install + one-shot `admin_init` backfill (`wp_mcp_ai_assistant_builder_backfilled`).
- **P3 ID-handoff data contracts** (PRs #6729–#6738, closure #6739) — every ID-bearing tool family declares `produces`/`consumes` handoffs (post, cron, term, assistant, vector store, batch, Pro schedule, toolkit_cpt, medical record, plan, calendar, WPCode, session, member, webchat room) with the coverage manifest as single source of truth + permanent L1 honesty / L2 round-trip suites. In-wave fixes: `format_code_prettier` envelopes → canonical `WP_Error` (#6737); webchat `log_activity()` → `log_event( 'activity', … )` (#6738).
- **Usage monitor save fix** (PR #6726) — `handle_save_settings()` now applies the `wp_mcp_ai_admin_settings_sanitize` bridge filter (raw input, pre-sanitize), so the Usage Monitor sub-tab persists again; handlers no-op when their fields are absent.
- **Webchat close-out** (PR #6740) — `get_webchat_messages` queries rebuilt with explicit placeholders (phpcs warnings gone); the last three webchat tools + CG Pro member mirrors gain usage guidance; the CG interface copy gains `WP_MCP_AI_Tool_Usage_Guidance_Interface` (standalone-resolution fatal fix). Residual CG mirror drift (~957 files) → issue #6741.
- **Tool count** — +1 base → ~307 base + ~1,279 Pro (~1,586 total). Coding-time skills: 59 (unchanged — the test-suite skill gained patterns 49–50 and the ecosystem-port skill gained the CG interface-port rule, #6742).

## Tool Guidance, Pro Bootstrap Guard, Telegram Chunking & Upwork-Workflow Delivery (v1.1.83)

- **Tool Description Engineering** (PRs #6686/#6695/#6687–#6723) — `WP_MCP_AI_Tool_Usage_Guidance_Interface` (`when_to_use`/`when_not_to_use`/`related_tools`/`notes`) + the assembled `[Usage: …]` suffix in `get_model_facing_description()` (REST chat path, Tool Service `/tools`, `list_mcp_tools`); legacy-format classes opt in via `get_usage_guidance()` or a `usage_guidance` definition key forwarded by `WP_MCP_AI_Legacy_Tool_Wrapper`. The Phase 2 sweep completes the full base+pro tree (~1,487 tools; 1,584/1,584 files) and the `WPMCPAI.Tools.ToolDescriptionGuidance` sniff is enforced at severity 5. Opt-in adaptive tool cap (`WP_MCP_AI_Tool_Payload_Advisor`, site option + per-assistant override) + lazy schema loading (`tool_slug`/`include_schemas` on `list_mcp_tools`).
- **Pro bootstrap incomplete-install guard** (PR #6677) — `mcp-ai-wpoos-pro.php` `file_exists`-checks the module-registry require and degrades to `wp_mcp_ai_pro_incomplete_install_notice` + a WP_DEBUG line (partial deploys no longer fatal the site). **Telegram auto-chunking** — `send_telegram_message` splits >4,096-char messages (paragraph → line → hard; hard splits drop `parse_mode`; `chunk=false` restores legacy; `wp_mcp_ai_telegram_chunk_error` carries the failed chunk index). **Gmail `connection_id="settings"`** resolves to the settings fallback across the Pro Gmail tools, the Drive client, and base `search_gmail`. **Skill/OKF self-correction** — `load_skill` not-assigned appends `Assigned skills: …`; `okf_bundle_not_found` appends `Available bundles: …` (new `list_bundle_names()`).
- **Upwork search + workflow delivery** (PRs #6678–#6680/#6682/#6684) — `search_upwork_jobs` gains web_search-mode + API credential gates, drops category landing pages, extracts SERP `job_type`/`budget`/`published`, always runs the broad second pass under `min(limit, 5)` jobs, and accepts `sort`/`location` args; workflow deliveries ship the full 50-item result set (filterable cap) with per-item URLs + budget/contract/recency; both markdown converters fold indented continuation lines into a single `<ol>` (digests render 1–10); `steps` render as a compact execution log.
- **Playground Ollama demo** (PR #6683) — the seed now sets `/%postname%/` permalinks (fresh-install `/ollama-test-lab/` 404 fixed); local `npx -y @wp-playground/cli server` is the primary test path; `bin/capture-real-page.sh` rewritten (REST-index wait + cookie jar).
- **npm advisories** (PR #6681) — adm-zip 0.6.1, js-yaml 4.3.2, colord 2.10.0. **Regulatory envelope** (PR #6689) — five regulatory tools migrate to the canonical `WP_Error` envelope.
- **Tool count** — unchanged: ~306 base + ~1,279 Pro (~1,585 total). Coding-time skills: 59 (unchanged — the test-suite skill gained pattern 48 in-window).

## WordPress Playground Demos, Pro SPA Fixes & Token-Tracking Hardening (v1.1.82)

- **WordPress Playground demo blueprints** (PRs #6662/#6663/#6666/#6670/#6673/#6674) — two one-click demos: Content Graph "Project Asteria" (seeded sci-fi universe, deterministic build via the public `nvoos_content_graph/initial_build` hook) and **NV oOS Complete × local Ollama** (the browser worker's `localhost:11434` is the user's machine — provider pre-wired, Oma assistant, Test Lab page with `[ollama_status]` + embedded Pro SPA). `bin/generate-ollama-blueprint.php` auto-discovers the newest Complete bundle ZIP; `build-assets.yml` regenerates the blueprint on every build. New skill `mcp-ai-wpoos-playground-demos` (59th) documents the authoring/CORS/PCP/crash-mode playbook; end-user walkthrough in `docs/user-guides/playground-demo.md`.
- **Pro SPA fixes** (PRs #6665/#6672) — `[nvoos_pro_spa cron_monitor="0"]` no-ops the blocking SSE cron-status stream + REST poll for constrained hosts (default `true`); embedded mode seeds the model store from the assistant's real config (no more hardcoded `gpt-4o` override).
- **Token-tracking table hardening** (PR #6669) — verify-then-version, hourly retry backoff, quiet failure, graceful reads for SQLite-backed environments; ported 1:1 to `nvoos-content-graph-ai`.
- **Result-delivery dedupe** (PR #6661) — `delivery_safe_data()` strips the duplicated response + `assistant_id`/`is_agentic` metadata; summary/SMS prefix dedupe. **`[ollama_status]` banner fixed** (PR #6668) — footer-enqueued checker (shortcodes render markup only). **Portability coverage guards repaired** (PR #6645). **Docs Hub 0.4.7** (PRs #6659/#6667) — third wp.org reviewer pass.
- **Tool count** — unchanged: ~306 base + ~1,279 Pro (~1,585 total). Coding-time skills: 58 → 59.

## Shopify UCP Tool Routing, FlowHub Connections, JobNavigator CRM & OpenTerminal Financial Resilience (v1.1.81)

- **Shopify tools are UCP catalog mode-aware** (PR #6634) — storefront/global
  catalog connections drive live `search_catalog`/`lookup_catalog`/
  `get_product` queries (no caching, `live: true`); admin-only tools refuse
  catalog connections with an actionable hint; `remote_shopify_connection`
  validates UCP modes via the `tools/list` handshake. **Product image cards**
  (PR #6638) — `images[]` + a chat-rendered markdown card (10-card cap) on
  every product-returning path via a shared normalizers trait. CG Pro ports
  byte-identical.
- **FlowHub Remote Sites resolution + proxy** (PRs #6635/#6637) — a shared
  resolver chain (explicit `connection_id` → toolkit settings → sync
  connections → first enabled FlowHub connection) ends the "credentials are
  not configured" failure; live requests honor the connection proxy
  (`http_api_curl`). New base helper `WP_MCP_AI_FlowHub_Connection_Helper`.
- **JobNavigator CRM adoption + Gmail reply poller** (PRs #6636/#6640/#6641)
  — 5 new Pro CRM tools (`bulk_move_deal_stages`, `record_crm_reply`,
  `get_crm_handover`, `get_pipeline_digest`, `create_tracked_link`), deal
  stage history + undo, lead dedup with canonical companies, reply signals,
  won-deal lead release; a cron-driven Gmail reply poller classifies inbound
  replies with sentiment + optional stage advancement; pipeline-digest
  scheduling recipe for Workflow Builder + Pro Schedule Manager.
- **OpenTerminal financial resilience** (PR #6639) — 8 new Pro financial
  tools (`market_screener`, `macro_data_fetcher`, `economic_calendar_fetcher`,
  `earnings_calendar_fetcher`, `options_chain_fetcher`, `crypto_market_data`,
  `portfolio_transaction_log`, `price_alerts`), provider fallback chains +
  stale-while-revalidate caching, keyless microservice auth, technical
  indicators, portfolio transaction ledger with P&L. CG Pro port
  byte-identical.
- **Multi-recipient result-delivery email** (PR #6643) — comma/semicolon/
  whitespace lists normalized on save + sanitized/deduped at the
  `sanitize_result_delivery()` boundary; fanned out via Nodemailer +
  `wp_mail()`; legacy `notify_email` stays single-address.
- **Tool count** — +13 Pro: ~306 base + ~1,279 Pro (~1,585 total).

## Assistant Portability, Shopify UCP Modes, Security Usage Monitor & WP-CLI Repairs (v1.1.80)

- **Assistant export/import across all surfaces** (PR #6628) — canonical
  `WP_MCP_AI_Assistant_Portability` engine with `nvoos-assistant` JSON
  bundles (format_version 1): `wp mcp-ai assistant export|import` rewritten
  (legacy files still import; old export lost `_wp_mcp_ai_*` config — fixed),
  REST `POST /mcp-ai/v1/assistants/export|import` (admin-only, nonce/bearer,
  schema-validated, 2 MB cap, dry-run), admin Import/Export page + row/bulk
  actions, and 3 new base tools (`export_assistant`, `import_assistant`,
  `duplicate_assistant`) + Pro `export_assistant_blueprint`. Credential hashes
  never exported, stripped from imports; the backup provider now shares the
  denylist (previously it exported credential hashes).
- **Security Center Usage Monitor sub-tab** (PR #6632) — new `usage_monitor`
  sub-tab (violation triage log, status cards, shutdown recovery, editable
  config); the admin notice deep-links to it and shows the latest violation;
  `POST /mcp-ai/v1/security/clear-violations` + `/clear-shutdown`
  (`manage_options` + nonce); monitor sanitize-clobber bug fixed (submitted
  keys only); malformed patterns dropped/skipped.
- **Shopify UCP modes** (PRs #6624/#6630) — keyless Storefront + Global
  Catalog modes replace the deprecated REST Catalog API on Pro + CG Pro
  (byte-identical ports; public `/ucp/agent-profile` route); REST catalog
  401s fixed with a 60-min token cap, scope validation, and purge-and-retry
  (PR #6623); JetEngine sync gate unified with the System Status row.
- **WP-CLI repaired + streaming** (PRs #6625/#6626) — `provider list` and
  every base-class command no longer fatal on PHP 8+ (by-reference Formatter
  constructor → by-value `format_items()`); `chat` uses `get_model_router()`;
  `chat --stream` streams natively (cURL SSE) or simulates chunks, honoring
  the shared streaming filters. OKF editor keeps context on save (#6631).
  WhatsApp webhook self-tests on Remote Sites (#6622).
- **Tool count** — +3 base +1 Pro: ~306 base + ~1,266 Pro (~1,572 total).

## Imaging Symlink Hardening, Checkout Hardening Tail & Sub-Project Bumps (v1.1.79)

- **Imaging study deletion hardened against symlink traversal** (PR #6616) —
  both recursive study-deletion paths now remove links as links and never
  follow them; every iterator entry is realpath-verified against the
  storage root; new `study_delete_link_failed` /
  `study_delete_outside_storage_blocked` audit events; the
  `nvoos-content-graph-pro` port ships the same two files byte-identically.
- **Checkout hardening tail** (PRs #6611/#6613, vendor-side) — the Stripe
  statement descriptor now ships as `statement_descriptor_suffix` (fixes the
  424 that failed every live session); product/price creation verifies
  stored Stripe IDs against the current key and recreates them after an
  account switch.
- **Content Graph 1.0.8** (in-session) — Stripe Payment Element
  billing-address mode `never` → `auto` (non-EU purchases no longer die
  client-side with `IntegrationError`); `/payments/session` refuses
  chargeable sessions when the site is already licensed (no double
  charges).
- **Checkout API 0.1.2** (in-session) — buyers are emailed their license
  once per license from both the webhook and `/verify` paths
  (`email_sent_at` DB v4 → v5).
- **Docs Hub 0.4.5 → 0.4.6** (PRs #6615/#6617) — second wp.org reviewer
  pass (external-services disclosure, symlinked cache-dir uninstall guard)
  + full 18-guideline pass (bundled GPLv3 license); PCP 0 blocking errors.
- **Content-graph wp.org readiness** (PRs #6609/#6612/#6619) —
  seller-of-record copy, price-subject-to-change note, packaging tri-sync
  (`node_modules` exclude).
- **Toolkit slash test repair** (test-only, PR #6618) — suite updated to the
  declarative adapter contract from #6604.
- **Tool count** — unchanged: ~303 base + ~1,265 Pro (~1,568 total).

## Slash-Command Rework, DeepSeek V4 Pro Restoration & Checkout Hardening (v1.1.78)

- **Slash commands reworked as declarative tool wrappers** (PR #6604) — the
  toolkit manager is now ~1,000 declarative lines: 36 commands across 15
  toolkits, each mapped to a verified real tool slug; execution delegates to
  `WP_MCP_AI_Tool_Registry::execute_tool()` via the new tool adapter
  (`register_tool_command()`), and every command is exposed as a `slash.*`
  MCP prompt template (`prompts/list` / `prompts/get`). ~76 placeholder
  commands purged; removed outcomes stay reachable via plain chat. The
  Content Graph platform port still ships the old placeholder system —
  owned by the ecosystem-port loop.
- **DeepSeek V4 Pro restored across all tracks** (PR #6608) — DeepSeek's
  2026-09-10 changelog continues V4 Pro past Sep 14: `deepseek-v4-pro` is
  **active** again ($0.66/$1.98 off-peak; migration map deliberately
  unmapped). The Content Graph AI mirror bumps its catalog to v2026.09.10
  and its v4-pro pricing is corrected; `lib/core` mirrors align.
- **Checkout hardening** (PRs #6597/#6598/#6603) — Content Graph assets
  cache-bust by file mtime (`Schema::assetVersion()`; fixes the invisible
  1.0.7 purchase-modal hotfix — year-long `Cache-Control` on
  `?ver=1.0.7`); the purchase modal syncs its price from the vendor
  `/session` response (display-only, vendor re-verifies) with
  `DEFAULT_PRICE_CENTS` **4900 → 3499**; minimalist modal restyle.
- **Docs Hub 0.4.4** (PR #6606) — all wp.org review findings fixed (search
  context filtering, source-code disclosure, symlink-safe deletion,
  staging-transient isolation, sitemap slug leak); PCP gate 0 blocking
  errors.
- **Legal consolidation** (PRs #6599/#6605/#6607) — unified ToS, aligned
  API-LICENSES, two-entity seller model (NV Digital Unlocked LLC sells;
  NV Digital Solutions develops).
- **Tool count** — unchanged: ~303 base + ~1,265 Pro (~1,568 total).

## DeepSeek V4.1 Flash, Base+Pro Gating & Memory CCT Slug (v1.1.77)

- **DeepSeek V4.1 Flash refresh** (PR #6555, corrected 2026-09-12) — the
  catalog's DeepSeek lineup is now `deepseek-flash` (active, vision) +
  `deepseek-v4-pro` (active — DeepSeek announced it continues V4 Pro service
  past 2026-09-14 with unchanged billing; no new sunset date); V4 Flash +
  Vision Exp retired; stored references migrate on the catalog-version bump.
  Cost calculator gains peak/off-peak (`calculate_cost_at()` with a record
  timestamp; legacy `calculate_cost()` stays time-independent).
- **Base+pro gating** (PR #6561) — Pro toolkits now load in base+pro
  installs (gate escape `! $is_base || defined( 'WP_MCP_AI_PRO_VERSION' )`);
  new `tests/basepro/` matrix + `composer run test:basepro` pins it.
- **Pro WP-CLI load-order guard** (PR #6585) — no more
  `Undefined constant WP_MCP_AI_PATH` when Pro activates before the base
  plugin; the CLI loader defers to `plugins_loaded` 30.
- **Memory CCT canonical slug** (PR #6591) — Graphify bridge + Pro memory
  retention read `ai_agent_memories` (canonical) with a legacy-table
  fallback; dormancy sweeps, per-user caps, expiry pruning, and Memory
  Health stats start working.
- **Tool count** — unchanged: ~303 base + ~1,265 Pro (~1,568 total).

## Delivery Formats, Checkout Legal Series & Wave F2 Completions (v1.1.76+)

- **Chat delivery full report + per-channel formats** (PR #6525) — chat
  channels support the `full` template (summary + substantive response +
  envelope data); per-channel `format` allowlists (Telegram
  `html`/`markdown`/`markdown_v2`/`plain`; WhatsApp/Slack/Discord/Teams
  `markdown`/`plain`; Messenger/Google Chat `plain`); Telegram delivery
  routes through `send_telegram_message` directly so `parse_mode` works;
  `MarkdownV2` reserved-char escaping; group-mention skips log
  `telegram_group_mention_required_ignored` instead of silently dropping.
- **Duplicate-summary skip** (PR #6548) — assistant-run delivery skips the
  derived summary when the response already opens with it
  (`response_starts_with_summary()` normalizes tags/whitespace + strips
  the trailing ellipsis).
- **Comic Creation toolkit toggle + playbook seeder idempotency** (#6512,
  direct commit) — the `enable_comic_creation_toolkit` toggle is now
  registered (Tools section, Pro Features subtab, memory estimator,
  WP-CLI maps); `hash_playbook_content()` strips the `Generated:`
  timestamp so playbook syncs no longer recreate attachments.
- **Checkout launch-complete series** (#6507/#6520/#6523/#6550) — required
  ToS consent + buyer email, EU country selector + billing-address block,
  Stripe product/price metadata, license DB v3 (`dbDelta`), manual install
  as primary path (`/verify` returns `download_url`), commercial legal
  docs (`docs/legal/`). Checkout API stays **0.1.0**.
- **Security sweeps** (#6515/#6532/#6546/#6504) — 9 Dependabot alerts,
  SVGO CVE-2026-84370 `>=4.1.0`, svgo/hono/vitest bumps, docs-hub ZIP
  excludes `*.md` (keep `readme.txt`).
- **Wave F2 port completions + new port skill** (PRs #6505–#6549) —
  `nvoos-content-graph-pro` (1.0.0) completes ten toolkit ports
  (comic-creation, dj-management, ai-tool-builder, architect-agent,
  architectural-design, site-creator, document-generation,
  regulatory-registration, healthcare, law-firm); new coding-time skill
  `mcp-ai-wpoos-ecosystem-port` (skill count 55 → 56).
- **Tool count** — unchanged: ~303 base + ~1,265 Pro (~1,568 total).

## Checkout Connectivity Diagnostics & Pro CLI Load-Order Guard (v1.1.77+)

- **Checkout API addon `GET /health`** (PR #6573) — public, no Stripe, no
  rate-limit token, no writes; returns `status`/`service`/`version`/
  `configured`/`server_time`. Live on nvdigitalsolutions.com:
  `GET https://nvdigitalsolutions.com/wp-json/nvoos-checkout/v1/health`.
- **Checkout API admin "REST endpoints" section** (PR #6573) — live
  per-route registered/missing markers (from `rest_get_server()->get_routes()`
  endpoint lists) plus a nonce-protected loopback self-check of `GET /health`
  reporting HTTP status + latency.
- **Content Graph client diagnostics** (PR #6573) — `Vendor::health()` and
  the admin-only `GET /payments/health` route (deliberately NOT throttled,
  so diagnostics cannot trigger the "Too many checkout attempts" lockout);
  the purchase modal offers a "Test connection" action when session
  creation fails.
- **Checkout troubleshooting playbook** — two independent throttles: client
  (transients `nvoos_content_graph_commerce_{session,verify}_throttle_{uid}`,
  5 and 15 attempts per 10 min per user) and vendor (per server IP, 20
  session / 30 verify per 10 min on the checkout-api addon). Diagnose from
  the client site's server:

  ```bash
  # Outbound connectivity from the site's server (works even when other
  # plugins fatal under WP-CLI, see below):
  wp --skip-plugins eval '$main = glob( WP_PLUGIN_DIR . "/*nvoos-content-graph*/nvoos-content-graph.php" ); if ( empty( $main ) ) { exit; } require_once $main[0]; var_export( ( new \NvoosContentGraph\Commerce\Vendor( \NvoosContentGraph\Commerce\Payments::vendorApiUrl() ) )->health() );'

  # Clear the client throttles. If the remote shell mangles $variables,
  # ship the PHP base64-encoded instead:
  wp --skip-plugins eval 'for ( $i = 1; $i <= 200; $i++ ) { delete_transient( "nvoos_content_graph_commerce_session_throttle_" . $i ); delete_transient( "nvoos_content_graph_commerce_verify_throttle_" . $i ); }'
  ```

  The vendor-side per-IP bucket only clears with time (10 min).
- **Pro CLI load-order fatal** — when the Pro addon is activated before the
  base plugin, every `wp` command dies with `Undefined constant
  "WP_MCP_AI_PATH"` (Pro requires its CLI files at include time under
  WP_CLI; web requests are unaffected). Site fix: reorder `active_plugins`
  via `wp --skip-plugins eval` (move the `-pro` entry after the base
  entry). Code fix: PR #6585 defers the CLI require loop to
  `plugins_loaded` when the base constant is missing at include time.
- **Tool count** — unchanged: ~303 base + ~1,265 Pro (~1,568 total).

## Checkout Purchase-Modal Redirect Bug & Release-Tag URL Fix (PR #6594)

Diagnosed live on victory.nvdigital.solutions (client) + nvdigitalsolutions.com
(vendor) when "the purchase modal says nothing and redirects to the GitHub
releases page" with everything seemingly configured correctly.

- **The silent-redirect failure mode.** `checkoutUnavailable()` — the only
  path that redirects to `fallback_url` — fires when the modal's
  `/payments/session` call returns 404/≥500 **or its `.catch` runs**. The
  `.catch` wraps the ENTIRE `.then` chain, so ANY throw after the session
  call (Stripe element setup included) is mislabelled as "checkout
  unavailable". Status-code errors (424/429/403) stay in-modal with a
  "Test connection" action; a redirect means the response was 404/5xx,
  non-JSON, or a post-session throw. The fallback note is shown only 1.2 s
  — users report it as "says nothing, just redirects".
- **Root cause found: invalid Stripe element name.** The modal called
  `elements.create( 'paymentElement', … )` — the core Stripe.js API name is
  **`payment`** (`paymentElement` is the React component name). Stripe threw
  `IntegrationError: A valid Element name must be provided … you passed:
  paymentElement` AFTER a 200 session, and the catch-all redirected. Fix
  (PR #6594): `create( 'payment' )` plus a try/catch around Stripe element
  setup that surfaces a new `stripe_setup_error` message in the modal
  instead of the misleading redirect. The no-browser contract verifier is
  `node plugins/nvoos-content-graph/scripts/verify-commerce-fallback.js`.
- **Release-tag convention mismatch (same PR).** GitHub releases moved to
  `nvdigital-oos-v*.*.*` tags (`build-nvdigital-oos-wporg.yml` is the
  active path; `release.yml` `v*` tags are the legacy wp.org path). The
  checkout-api `default_zip_source()` and the client `Payments::zipUrl()`
  fallback still built `releases/download/v{VERSION}/…` → post-payment
  downloads 404/502 while payment + license succeed. Symptom: buyer pays,
  then "Could not fetch the addon package: 404 Not Found" (vendor download
  server) or a broken fallback URL. Verify: `curl -I …/releases/download/
  nvdigital-oos-v1.1.76/nvdigital-open-operator-system-oos-complete-
  1.1.76.zip` (200) vs the `v1.1.76` tag shape (404). Live-site remedy
  without a release: edit the vendor's **ZIP source** setting to
  `https://github.com/nvdigitalsolutions/mcp-ai-wpoos/releases/download/nvdigital-oos-v{VERSION}/nvdigital-open-operator-system-oos-complete-{VERSION}.zip`
  (keep **Addon version** as the plain `1.1.76` — the tag prefix belongs in
  the ZIP source pattern, not the version field).
- **Browser-side diagnostics that worked** (config lives in
  `window.nvoosContentGraphCommerce` — `rest_url`, `nonce`, `fallback_url` —
  only on the content-graph admin page, admin-logged-in):
  1. Replicate the modal call from the console:
     `fetch( rest_url + '/payments/session', { POST, credentials 'same-origin', X-WP-Nonce: nonce, body '{}' } )`
     — 200 + `client_secret` proves vendor/keys/throttles all healthy
     (each call creates a real live PaymentIntent; cancel it via
     `POST api.stripe.com/v1/payment_intents/{id}/cancel`).
  2. Raw-body variant (`r.text()`) to catch **non-JSON** responses (PHP
     warnings/debug lines, Cloudflare challenge HTML) — those reject
     `response.json()` and trip the redirect.
  3. Monkey-patch `window.fetch` to log every `/payments/` request with
     `r.clone().text()` BEFORE clicking Buy — captures what the modal
     actually sends/receives regardless of the 1.2 s redirect.
  4. To isolate a throw, load the REAL `https://js.stripe.com/v3/` first,
     then wrap the real `window.Stripe` with logging at call → elements →
     create → mount. **Pitfall: replacing `window.Stripe` with a stub
     short-circuits `loadStripeJs` (`if ( window.Stripe )`), so the modal
     never downloads Stripe.js and the stub's undefined return throws — a
     self-inflicted false positive.**
  5. DevTools "pause on caught exceptions" first lands on Stripe's internal
     `ArrayBuffer()` bot-check `try/catch` — harmless noise. Press F8 until
     the pause is in `content-graph-commerce.js` or carries a non-Stripe
     message.
- **Server-side diagnostics from the client site's shell:**
  `curl -sS -X POST https://nvdigitalsolutions.com/wp-json/nvoos-checkout/v1/session -H 'Content-Type: application/json' -d '{"product":"nvoos-oos-complete","site_url":"https://victory.nvdigital.solutions"}'`
  tests the exact server→vendor path (outbound firewall/DNS/SSL issues the
  browser can't see); `wp eval '$v = new \NvoosContentGraph\Commerce\Vendor( \NvoosContentGraph\Commerce\Payments::vendorApiUrl() ); …'`
  runs the plugin's own `health()`/`createSession()` on the site's server.
- **Live config facts (verified):** vendor `GET /health` is public;
  `POST /session` requires `product` ∈ {`nvoos-oos-complete`,
  `nvoos-content-graph-ai`} + `site_url`; a webhook signature test =
  HMAC-SHA256 over `{ts}.{payload}` with the dashboard `whsec_` sent as
  `Stripe-Signature: t={ts},v1={hex}` — a benign `charge.succeeded` event
  answering `{"received":true}` proves the dashboard secret matches the
  plugin's stored one; the Stripe webhook endpoint must subscribe
  `payment_intent.succeeded` + `charge.refunded` (+ optional
  `charge.dispute.created`); the client's commerce REST routes are
  **admin-only by design** (anonymous 403/401 is normal); if the base NV oOS
  plugin is already active on the client site (`mcp-ai/v1` in `/wp-json/`),
  the post-payment install correctly 409s (conflict guard) with a
  manual-download link — purchases on such a site need no install.

## Calendar Query Fix, Email Formats & Wave F2 PM/Calendar (v1.1.74+)

- **Google Calendar date queries** (PR #6460) — calendar query values are
  now `rawurlencode()`d before `add_query_arg()` (the raw `+` in RFC3339
  offsets decoded as a space → 400); `calendar.freebusy` in the Standard
  scope profile (new grants only).
- **Result Delivery email formats** (PR #6465) — new
  `WP_MCP_AI_Markdown_Converter` (escaped + `wp_kses` allowlist +
  protocol-allowlisted links) + per-channel `format` setting (`both`
  default | `html` | `markdown`).
- **Schedule Manager assistant prompts** (PR #6469) — the edit modal shows
  and updates `assistant_run` prompts; `update_pro_schedule` accepts
  `assistant_config` via MCP.
- **Wave F2 PM + calendar-booking ports** (PRs #6450–#6472) —
  `nvoos-content-graph-pro` (1.0.0) completes both toolkit ports;
  perf-suite MCP-abilities fix process-wide in `tests/bootstrap.php`
  (#6470); content-graph-pro excluded from the root WPCS gate (#6457).
- **Tool count** — unchanged: ~303 base + ~1,265 Pro (~1,568 total).

## Woo Tool Upgrades, Queue Bootstrap Fix & Wave F2 (v1.1.73+)

- **`bulk_update_products` variable scope** (PR #6447) — new `scope`
  argument (`all` default, `product` legacy) expands price/stock fields
  from variable parents to variations and grouped parents to children
  (`resolve_update_targets()` + `WC_Product_Variable::sync()`); the
  response reports `targets[]` per input ID + `scope`/`updated_targets`
  keys (acknowledged shape change).
- **`update_woo_product_qty` notify flag** (PR #6448) — `notify` (default
  `true`) suppresses low/no-stock emails for the write via scoped
  `woocommerce_should_send_*` filters removed in a `finally`;
  `woocommerce_*_stock` actions still fire.
- **Async job queue table bootstrap fix** (PR #6423) — the queue class now
  boots in time to create its table (activation + first-load self-heal;
  `get_queue_stats()` fails soft) — no more missing-table SQL floods.
- **Comic Reader 0.5.0** (PR #6402) — Komga-parity upgrade; **Docs Hub
  0.4.3** (PRs #6397/#6403) — wp.org prep; **Wave F2** (PRs #6397–#6445,
  #6449) — new `nvoos-content-graph-pro` v1.0.0 standalone addon (Pro CRM
  + e-commerce ports, 43 e-commerce tools).
- **Tool count** — unchanged: ~303 base + ~1,265 Pro (~1,568 total).

## Woo Price/Qty Tools & Ecosystem Port Waves (v1.1.72+)

- **WooCommerce price & quantity tools** (PR #6388) —
  `update_woo_product_price` (regular/sale, all product types) and
  `update_woo_product_qty` (stock + management) share the new
  `WP_MCP_AI_Woo_Price_Qty_Updater` trait; `bulk_update_products` uses it;
  tool presets register the new slugs.
- **Scheduled sync connection ID** (PR #6386) — EZuite/FlowHub scheduled
  syncs deliver the assigned connection ID (the scheduled action was
  dropping it).
- **Pro update vendor integrity** (PR #6338) — "Update Pro Now" verifies the
  Pro package's `vendor/` before and after updating.
- **Container binding** (PR #6339) — `tool_registry` is registered
  `transient`; every `get()` resolves the live singleton (test-swap safe).
- **Deps + defaults** (PRs #6365, #6332) — browserslist/qs patched (12
  Dependabot alerts); `gpt-image-2` aligned across all three settings
  layers.
- **Ecosystem ports** (PRs #6330–#6387) — Wave D8 closes the standalone
  tool-execution gap in Content Graph AI; Wave E6 engine pieces fold into
  the AI addon; the platform addon closes Waves E2/E3/E5/E1/E4 +
  E-UI-1/2/3. Sub-project versions unchanged (1.0.4 / 1.0.4 / 2.0.0).
- **Tool count** — +2 Pro: ~303 base + ~1,265 Pro (~1,568 total).

## Rate-Limit Unlock, Model Catalog & Ecosystem (v1.1.71+)

- **REST rate-limit unlock** (PR #6322) — `check_rate_limit()` uses fixed-window
  accounting (`{count, first_seen}` payload; TTL never extended past window end)
  with honest remaining-time `retry_after`; the new
  `wp_mcp_ai_rest_request_rate_limit_exceeded` action flags the restriction
  registry, so blocked users appear in Command Center → Restrictions with the
  Lift button (lifting also clears the `wp_mcp_ai_rate_limit_user_{id}`
  transient; guest IP-keyed blocks expire on their own).
- **MemPalace wing scope** (PR #6327) — `wake_up_context` enforces
  `wing`/`room` exclusions (`matches_wake_filters()`); Graphify graph anchors
  only boost scores and never excluded out-of-scope memories.
- **September 2026 model catalog** (PR #6328) — 228 models; new defaults
  `default_gemini_model` → `gemini-3.6-flash`, `openai_image_model` →
  `gpt-image-2`, Kimi default → `kimi-k3`; retired DeepSeek chat/reasoner/coder,
  `gemini-3.1-flash`, `imagen-4` have migration-map successors.
- **Checkout API** (PR #6315) — addon joins the standard build + PHPUnit
  pipeline; token/crypto classes derive `wp_salt()` salts (never raw
  `AUTH_KEY . SECURE_AUTH_KEY`). Connectors links → `options-connectors.php`
  (PR #6314). Coding-time agent skills: 53 → **54** (`mcp-ai-wpoos-updates`).
- **Tool count** — unchanged: ~303 base + ~1,263 Pro (~1,566 total).

## Wave-5 Repair Campaign & Host-Hardening Fixes (v1.1.70+)

- **exec-disabled hosts** — on PHP 8+ a disabled function throws a fatal
  `Error` that `@` cannot suppress; never call `exec`/`shell_exec`/`proc_open`
  unguarded. Use `wp_mcp_ai_check_nodejs_available()` /
  `wp_mcp_ai_get_nodejs_version()` (exec-first, Process Service fallback) and
  the OCR service's `is_cli_tool_available()` / `run_cli_command()` helpers;
  sanitizers clamp with `max( 0, … )`, never `absint()` (it flips negatives).
- **Wave-5 fixes** (PRs #6280–#6312) — transcript `attachments` metadata
  preserved; complexity-based model routing restored; JetEngine gates require
  `JET_ENGINE_VERSION` + a physical CCT-table probe (`is_storage_available()`);
  mesh peer URLs validated before `esc_url_raw()`; Auth0 audiences validated
  structurally (no DNS); image/chart permission checks use the **acting user**;
  markup REST validation errors return `400`; the legacy SSE handshake is
  filterable (`wp_mcp_ai_legacy_sse_enabled`); `wp_mcp_ai_pro_get_tool_map()`
  caches the Pro tool map; settings-repository reads fall back to the canonical
  `wp_mcp_ai_settings` blob so runtime gates see dashboard-saved values;
  agentic events reach the recent-activity feed.
- **Tool count** — unchanged: ~303 base + ~1,263 Pro (~1,566 total).

## Vision Analysis, tagDiv Compat, DeepSeek Schemas & ZipSlip Revival (v1.1.69+)

- **Vision Analysis toolkit (Pro)** — new `analyze_image_objects` tool
  counts objects per category (HF OWLv2 / Ollama `detection`, VLM `vlm`,
  hybrid label normalization; `annotate=true` returns a GD box-annotated
  attachment). Gated by `enable_vision_analysis_toolkit` on the NV oOS →
  Vision Analysis settings page — **off by default**; remote image URLs go
  through the SSRF URL guard. Docs: `docs/toolkits/vision-analysis-toolkit.md`.
- **tagDiv Newspaper admin compat** — the four SiteKit tools return string
  capability-flag arrays (the old `CAPABILITY_CAN_USE_IF_ADMIN` constant
  never existed and fatalled the assistant tools metabox at
  `sitekit_get_adsense`); the sortable shim prints a bundled jQuery UI
  1.14.2 copy whenever `td_wp_admin` is enqueued (detected via the print
  queue — a registered+enqueued core handle can still fail to execute);
  tools metabox CSS is enqueued on `admin_enqueue_scripts` so it prints in
  the head.
- **Tool schemas: `properties` must be an object** — argument-less tools
  encode `"properties": {}` (never `[]`; DeepSeek returns 400 otherwise).
  `LegacyToolAdapter` preserves object maps and upgrades empty arrays; the
  AI Tool Builder scaffold emits `new stdClass()` for parameterless tools.
- **ZipSlip guard** — `ZipArchive::$num_files` does not exist on PHP 8.x;
  the entry loops must use `count( $zip )` (OKF bundle manager + four Pro
  admin pages). The guard was silently dead code.
- **Rate limiting** — `check_rate_limit()` classifies internal dispatches by
  the dispatching request's real HTTP verb; the nefarious monitor keeps its
  own `wp_mcp_ai_nefarious_rate_limit_` counter (never share the chat REST
  limiter's — it halves the chat budget). `wp_mcp_ai_before_chat_request`
  subscribers tolerate the legacy 2-arg emitter shape.
- **Settings save** — capture `wp_suspend_cache_addition()` state *before*
  suspending (the function returns the new state, so reading it after
  suspends re-applies `true` and jams inline-async tick locks on WP 7.1).
- **Tool count** — ~303 base + ~1,263 Pro (~1,566 total).

## Front-End Surfaces, Nonce Self-Heal & Provider Defaults (v1.1.68+)

- **Pro SPA v2 shortcode** — `[nvoos_pro_spa]` embeds the Pro SPA v2 chat
  surface on the front end (chat-first embedded mode: threads, drawers,
  tool shortcuts, OKF drawer; router-free; optional guest mode behind the
  "Allow Guest Access" setting). Proposal 033.
- **Hermes dashboard fleet extensions** — new top-level `extensions/` tree
  (fleet monitoring + control plane, backup-download, external-app-tab,
  mcp-tool-shortcuts; `install.sh` + smoke tests). Plans in
  `docs/developer/integration/`.
- **Stale REST nonce self-heal** — `GET /mcp-ai/v1/session/nonce` mints a
  fresh session-bound nonce from the request's own auth cookie (`no-cache`/
  `no-store`); chat surfaces retry `403 rest_cookie_invalid_nonce` failures
  instead of showing "Cookie check failed" (full-page caching / SPA session
  rotation).
- **Docs Hub 0.4.2** — local-page links resolve to in-app `#/slug` routes,
  TOC anchors match github-slugger, "Accept fix" suggestions are
  directory-relative with `../` validation + skip reasons, sync failures
  surface "Atomic swap failed", and the emoji loader no longer crashes the
  React SPA on docs-browser pages.
- **Provider enable defaults (fresh installs)** — OpenAI/Anthropic/Gemini
  now default to **disabled**; provider dropdowns list only enabled +
  credentialed providers (`get_available_providers()`); the onboarding
  wizard auto-enables the provider whose key you enter. When helping users
  with "no providers available", check both the key **and** the enable
  checkbox.
- **Grouped fixes (third test wave, ~21 PRs)** — calendar granted-scopes
  `%20` normalization; agent-identity canonical-ID int cast; token-budget
  catalog dedup + `wp_mcp_ai_model_tpm_limit` filter seam; assistant
  untrash restores the pre-trash status; presets gain missing tools;
  `wp_mcp_ai_seed_task_templates` AJAX; `fast-uri` >=4.1.4; Tiptap 3.30.4
  pins; jQuery UI sortable shim on post edit screens. Tool count unchanged:
  ~303 base + ~1,262 Pro (~1,565 total).

## Platform Extraction v2.0.0, Ecosystem Port Wave D + D-UI & Google Workspace Read Tools (v1.1.67+)

- **Content Graph platform extraction (v2.0.0)** — the
  `nvoos-content-graph-ai-platform` addon now carries its own business
  logic (Waves A–C + Blueprints: namespace-bridged admin UI, skill/slash-
  command/agent bridges, harness router, 74-skill bundled-skills pack,
  knowledge base, `.github/workflows/phpunit-platform.yml`). Plan:
  `docs/project/plans/content-graph-platform-extraction-plan.md`.
- **Base+Pro → Content Graph ecosystem port (Wave D + D-UI)** — the AI
  runtime lands in `nvoos-content-graph-ai` (chat core, providers beyond
  the 13, model management + analytics/token tracking, security guards,
  assistant admin pages, blocks/widgets/guest tokens/memory/CLI/MCP
  JSON-RPC); **Content Graph AI bumps 1.0.3 → 1.0.4**. Tracker:
  `docs/project/ecosystem-port-tracker.md`.
- **Google Workspace Gmail + Drive read tools (Pro)** — six new Pro tools
  (`get_gmail_message`, `get_gmail_thread`, `list_gmail_connections`,
  `modify_gmail_message` — destructive-ops gated — and `get_drive_file`,
  `list_drive_connections`) with new `WP_MCP_AI_Pro_Gmail_Client` /
  `WP_MCP_AI_Pro_Google_Drive_Client` clients on the shared
  `includes/google/` foundation.
- **PHPUnit repair campaign continuation (~95 PRs, Aug 31 – Sep 2)** — a
  second cluster wave kept the suite green through the extraction/port
  work; the `mcp-ai-wpoos-test-suite` skill now distills 26 root-cause
  patterns. Production seams to know about: `unregister_section()` on the
  settings registry; public `get_tool_multiplier()`; null-safe REST
  tool-error reporting; WhatsApp webhook signature rejection without an
  app secret; destructive-ops gate reads the canonical combined-settings
  array; crawler `base_url` validation + `wp_mcp_ai_crawl4ai_auto_spawn_cron`
  filter. Tool count: ~303 base + ~1,262 Pro (~1,565 total).

## Test-Suite Campaign, REST Hardening & Content Graph AI (v1.1.66+)

- **PHPUnit repair campaign (Aug 28–31, ~100 PRs)** — the single-process
  suite was repaired cluster-by-cluster; the recurring root causes and the
  cluster-PR workflow are catalogued in the sibling
  `.agents/skills/mcp-ai-wpoos-test-suite/SKILL.md` skill, with the
  standing tracker `docs/developer/testing-docs/TEST-SUITE-REMAINING-FIXES-PLAN.md`.
  Coding-time agent skills: 53.
- **Assistant-access caching** — `validate_assistant_access()` caches
  `WP_Error` results like successes; the cache-disable path is the
  `wp_mcp_ai_assistant_access_cache_enabled` filter (never a persisted
  `WP_MCP_AI_DISABLE_CACHE` define from a test).
- **REST/auth hardening** — attachment-segment validation errors return
  explicit HTTP 400s; token-tier endpoint + tier-change audit logging
  fixed; REST permission-callback allowlist refreshed; bearer-auth context
  synced across Simple JWT + assistant-access paths; guest tokens are
  origin-bound.
- **Job queue & notifier** — closure serialization fixed in legacy option
  storage; custom-table queries guard against missing schema (Graphify DB,
  job store, tenant DB); `update_status()` restored with dot-preserving
  job IDs and owner-scoped REST routes; progress events promote cached
  status to running.
- **Tool contract fixes** — Media Toolkit tools return canonical `WP_Error`
  envelopes; Remove Background gained a path guard; memory-capture failure
  envelope restored; web-search result building fixed for Exa/Perplexity;
  auto-categorize router/client fixed.
- **Content Graph AI 1.0.3** — `nvoos-content-graph-ai` standalone plugin
  bumped to 1.0.3 with a tool permission-check fix; `nvoos-content-graph`
  stays 1.0.3, Media Worker stays v3.2.0.

## Google Calendar Connection & Composio Hardening (v1.1.64+)

- **Google Calendar connection (Base + Pro)** — new shared foundation in
  `includes/google/` (OAuth service, Calendar v3 client, scope registry,
  credential resolver, sync + push) replaces four drifted Google OAuth
  start/callback copies; a `google_calendar` connection type exists on both
  surfaces (base Settings → Integrations, Pro Remote Sites). Six new Pro
  tools in `addons/pro/includes/tools/google-workspace/`:
  `list_google_calendars`, `list_google_calendar_events`,
  `update_google_calendar_event`, `delete_google_calendar_event`,
  `check_google_calendar_availability`, `quick_add_google_calendar_event` —
  credentials resolve from an optional `connection_id` or site-level settings,
  and every write passes scope enforcement. Docs:
  `docs/developer/architecture/integrations/google-calendar-connection.md`.
- **Composio account health + hardening (Pro)** — verified account-health
  engine (`WP_MCP_AI_Composio_Account_Health`) with live catalog-discovered
  probes; new seventh tool `composio_manage_accounts`
  (validate/reconnect/delete/prune); proxied provider 401/403 → reconnect
  guidance; zero-argument calls send `arguments: {}`; Health column +
  Verify/Reconnect in Remote Sites.
- **Log hygiene** — tools declare non-loggable result fields via
  `WP_MCP_AI_Tool_Sensitive_Result_Interface` (`get_sensitive_result_fields()`,
  logging-only masking); credential-bearing URL query params are redacted
  from every logged string; rolling log buffers get per-entry byte budgets
  plus Data Management Compact/Delete.
- **Vision tools timeout** — `analyze_image`, `extract_image_text`,
  `generate_image_alt_text`, `generate_image_caption` accept a 5–300s
  `timeout` and inherit the global `request_timeout` (fixes cURL error 28 on
  large images).

