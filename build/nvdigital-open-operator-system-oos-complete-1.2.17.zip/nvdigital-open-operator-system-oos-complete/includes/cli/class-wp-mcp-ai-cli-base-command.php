<?php
/**
 * Base class for WP-CLI commands with enhanced functionality.
 *
 * Provides common utilities for batch processing, progress bars,
 * error handling, and consistent output formatting.
 *
 * @package WP_MCP_AI
 * @since 1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
	return;
}

/**
 * Abstract base class for WP-CLI commands.
 *
 * @since 1.0.0
 */
abstract class WP_MCP_AI_CLI_Base_Command extends WP_CLI_Command {

	/**
	 * Progress bar instance.
	 *
	 * @var \cli\progress\Bar|null
	 */
	protected $progress_bar = null;

	/**
	 * Error count during batch processing.
	 *
	 * @var int
	 */
	protected $error_count = 0;

	/**
	 * Success count during batch processing.
	 *
	 * @var int
	 */
	protected $success_count = 0;

	/**
	 * Start time for performance tracking.
	 *
	 * @var float
	 */
	protected $start_time = 0;

	/**
	 * Create and display a progress bar.
	 *
	 * @param string $message Progress bar message.
	 * @param int    $total   Total number of items to process.
	 * @return \cli\progress\Bar Progress bar instance.
	 */
	protected function create_progress_bar( $message, $total ) {
		$this->progress_bar = WP_CLI\Utils\make_progress_bar( $message, $total );
		return $this->progress_bar;
	}

	/**
	 * Tick the progress bar (advance by one).
	 *
	 * @return void
	 */
	protected function tick_progress() {
		if ( $this->progress_bar ) {
			$this->progress_bar->tick();
		}
	}

	/**
	 * Finish and close the progress bar.
	 *
	 * @return void
	 */
	protected function finish_progress() {
		if ( $this->progress_bar ) {
			$this->progress_bar->finish();
			$this->progress_bar = null;
		}
	}

	/**
	 * Process items in batches with progress tracking.
	 *
	 * @param array    $items    Items to process.
	 * @param callable $callback Callback function to process each item.
	 * @param array    $options  Processing options.
	 * @return array Results with success_count, error_count, errors.
	 */
	protected function batch_process( $items, $callback, $options = array() ) {
		$defaults = array(
			'batch_size'     => 50,
			'progress_label' => __( 'Processing items', 'nvdigital-open-operator-system-oos' ),
			'dry_run'        => false,
			'stop_on_error'  => false,
		);

		$options = wp_parse_args( $options, $defaults );

		$this->error_count   = 0;
		$this->success_count = 0;
		$errors              = array();
		$total               = count( $items );

		// Create progress bar.
		$progress = $this->create_progress_bar( $options['progress_label'], $total );

		// Process in batches to manage memory.
		$chunks = array_chunk( $items, $options['batch_size'] );

		foreach ( $chunks as $chunk ) {
			foreach ( $chunk as $item ) {
				try {
					if ( ! $options['dry_run'] ) {
						$result = call_user_func( $callback, $item );

						if ( is_wp_error( $result ) ) {
							++$this->error_count;
							$errors[] = array(
								'item'    => $item,
								'message' => $result->get_error_message(),
							);

							if ( $options['stop_on_error'] ) {
								break 2; // Break out of both loops.
							}
						} else {
							++$this->success_count;
						}
					} else {
						// Dry run mode - just count.
						++$this->success_count;
					}
				} catch ( Exception $e ) {
					++$this->error_count;
					$errors[] = array(
						'item'    => $item,
						'message' => $e->getMessage(),
					);

					if ( $options['stop_on_error'] ) {
						break 2;
					}
				}

				$this->tick_progress();

				// Clear object cache periodically to prevent memory issues.
				if ( 0 === ( $this->success_count + $this->error_count ) % $options['batch_size'] ) {
					$this->clear_local_cache();

					// Throttle if memory is approaching the configured limit.
					if ( class_exists( 'WP_MCP_AI_Memory_Manager' ) ) {
						WP_MCP_AI_Memory_Manager::throttle_or_abort();
					}
				}
			}
		}

		$this->finish_progress();

		return array(
			'success_count' => $this->success_count,
			'error_count'   => $this->error_count,
			'errors'        => $errors,
			'total'         => $total,
		);
	}

	/**
	 * Display success message.
	 *
	 * @param string $message Success message.
	 * @return void
	 */
	protected function success( $message ) {
		WP_CLI::success( $message );
	}

	/**
	 * Display error message.
	 *
	 * @param string $message Error message.
	 * @param bool   $exit    Whether to exit after displaying error.
	 * @return void
	 */
	protected function error( $message, $exit = true ) {
		WP_CLI::error( $message, $exit );
	}

	/**
	 * Display warning message.
	 *
	 * @param string $message Warning message.
	 * @return void
	 */
	protected function warning( $message ) {
		WP_CLI::warning( $message );
	}

	/**
	 * Display info message.
	 *
	 * @param string $message Info message.
	 * @return void
	 */
	protected function info( $message ) {
		WP_CLI::log( $message );
	}

	/**
	 * Display debug message (only if --debug flag is set).
	 *
	 * @param string $message Debug message.
	 * @return void
	 */
	protected function debug( $message ) {
		WP_CLI::debug( $message );
	}

	/**
	 * Ask user for confirmation.
	 *
	 * When `--yes` (or `-y`) is passed the prompt is skipped and the
	 * confirmation succeeds. Otherwise the standard WP_CLI::confirm() prompt
	 * is shown, which exits when declined.
	 *
	 * @param string $question   Confirmation question.
	 * @param array  $assoc_args Associative arguments.
	 * @return bool True when confirmed (always true — declining exits).
	 */
	protected function confirm( $question, $assoc_args = array() ) {
		if ( WP_CLI\Utils\get_flag_value( $assoc_args, 'yes', false ) || WP_CLI\Utils\get_flag_value( $assoc_args, 'y', false ) ) {
			return true;
		}

		WP_CLI::confirm( $question );
		return true;
	}

	/**
	 * Start performance timer.
	 *
	 * @return void
	 */
	protected function start_timer() {
		$this->start_time = microtime( true );
	}

	/**
	 * Get elapsed time since timer started.
	 *
	 * @return float Elapsed time in seconds.
	 */
	protected function get_elapsed_time() {
		if ( 0 === $this->start_time ) {
			return 0;
		}

		return microtime( true ) - $this->start_time;
	}

	/**
	 * Display execution summary.
	 *
	 * @param array $results Processing results.
	 * @return void
	 */
	protected function display_summary( $results ) {
		$elapsed = $this->get_elapsed_time();

		WP_CLI::log( '' );
		WP_CLI::log( WP_CLI::colorize( '%G' . __( 'Summary:', 'nvdigital-open-operator-system-oos' ) . '%n' ) );
		WP_CLI::log(
			sprintf(
			/* translators: %d: number of items */
				__( '  Total items: %d', 'nvdigital-open-operator-system-oos' ),
				$results['total']
			)
		);
		WP_CLI::log(
			sprintf(
			/* translators: %d: number of items */
				__( '  Successful: %d', 'nvdigital-open-operator-system-oos' ),
				$results['success_count']
			)
		);

		if ( $results['error_count'] > 0 ) {
			WP_CLI::log(
				WP_CLI::colorize(
					sprintf(
						/* translators: %d: number of items */
						'%%R  Failed: %d%%n',
						$results['error_count']
					)
				)
			);
		}

		if ( $elapsed > 0 ) {
			WP_CLI::log(
				sprintf(
				/* translators: %s: elapsed time */
					__( '  Time: %s seconds', 'nvdigital-open-operator-system-oos' ),
					number_format( $elapsed, 2 )
				)
			);

			if ( $results['total'] > 0 ) {
				$rate = $results['total'] / $elapsed;
				WP_CLI::log(
					sprintf(
					/* translators: %s: processing rate */
						__( '  Rate: %s items/second', 'nvdigital-open-operator-system-oos' ),
						number_format( $rate, 2 )
					)
				);
			}
		}

		// Display errors if any.
		if ( ! empty( $results['errors'] ) ) {
			WP_CLI::log( '' );
			WP_CLI::log( WP_CLI::colorize( '%R' . __( 'Errors:', 'nvdigital-open-operator-system-oos' ) . '%n' ) );

			foreach ( array_slice( $results['errors'], 0, 10 ) as $error ) {
				WP_CLI::log(
					sprintf(
						'  - %s',
						$error['message']
					)
				);
			}

			if ( count( $results['errors'] ) > 10 ) {
				WP_CLI::log(
					sprintf(
						/* translators: %d: number of errors */
						__( '  ... and %d more errors', 'nvdigital-open-operator-system-oos' ),
						count( $results['errors'] ) - 10
					)
				);
			}
		}
	}

	/**
	 * Clear local object cache to prevent memory issues.
	 *
	 * @return void
	 */
	protected function clear_local_cache() {
		if ( class_exists( 'WP_MCP_AI_Memory_Manager' ) ) {
			WP_MCP_AI_Memory_Manager::stop_the_insanity();
			return;
		}

		// Fallback: keep historical behaviour if the helper is unavailable.
		global $wpdb, $wp_object_cache;

		if ( $wpdb ) {
			$wpdb->queries = array();
		}

		if ( is_object( $wp_object_cache ) ) {
			$wp_object_cache->group_ops    = array();
			$wp_object_cache->stats        = array();
			$wp_object_cache->cache        = array();
			$wp_object_cache->cache_hits   = 0;
			$wp_object_cache->cache_misses = 0;
		}
	}

	/**
	 * Parse and validate common arguments.
	 *
	 * @param array $assoc_args Associative arguments from command.
	 * @return array Parsed arguments.
	 */
	protected function parse_common_args( $assoc_args ) {
		return array(
			'dry_run' => WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false ),
			'yes'     => WP_CLI\Utils\get_flag_value( $assoc_args, 'yes', false ),
			'format'  => WP_CLI\Utils\get_flag_value( $assoc_args, 'format', 'table' ),
			'limit'   => isset( $assoc_args['limit'] ) ? absint( $assoc_args['limit'] ) : 0,
			'offset'  => isset( $assoc_args['offset'] ) ? absint( $assoc_args['offset'] ) : 0,
		);
	}

	/**
	 * Format data for output.
	 *
	 * @param mixed  $data   Data to format (a list of associative rows).
	 * @param string $format Output format (table, json, yaml, csv).
	 * @param array  $fields Fields to include in output. When empty, fields
	 *                       are derived from the first row's keys.
	 * @return void
	 */
	protected function format_output( $data, $format = 'table', $fields = array() ) {
		if ( empty( $data ) ) {
			WP_CLI::log( __( 'No data to display.', 'nvdigital-open-operator-system-oos' ) );
			return;
		}

		// Derive display fields from the first row when none were requested,
		// matching the legacy WP_CLI\Formatter default-field behaviour.
		if ( empty( $fields ) ) {
			$first = is_array( $data ) ? reset( $data ) : null;
			if ( is_array( $first ) ) {
				$fields = array_keys( $first );
			}
		}

		WP_CLI\Utils\format_items( $format, $data, $fields );
	}

	/**
	 * Require a WordPress capability, or exit with an error.
	 *
	 * When run via WP-CLI, the current user is typically the system user
	 * (ID 0 or 1).  This check ensures that even in CLI context, privileged
	 * operations respect the same capability gates as the admin UI and REST API.
	 *
	 * @since 1.2.0
	 *
	 * @param string $capability WordPress capability name (e.g. 'manage_options').
	 * @return void
	 */
	protected function require_capability( $capability = 'manage_options' ) {
		// phpcs:ignore WordPress.WP.Capabilities.Undetermined -- $capability is validated by callers against known capabilities.
		if ( ! current_user_can( $capability ) ) {
			WP_CLI::error(
				sprintf(
					/* translators: %s: WordPress capability name */
					__( 'Sorry, you are not allowed to perform this action. Required capability: %s', 'nvdigital-open-operator-system-oos' ),
					$capability
				)
			);
		}
	}

	/**
	 * Get the output format from associative args with validation.
	 *
	 * @since 1.2.0
	 *
	 * @param array  $assoc_args Associative arguments from the command.
	 * @param string $fallback   Default format (default: 'table').
	 * @return string Sanitised format string.
	 */
	protected function get_format( $assoc_args, $fallback = 'table' ) {
		$format  = \WP_CLI\Utils\get_flag_value( $assoc_args, 'format', $fallback );
		$allowed = array( 'table', 'json', 'yaml', 'csv', 'ids', 'count' );
		return in_array( $format, $allowed, true ) ? $format : $fallback;
	}

	/**
	 * Resolve the output fields from --fields / --field flags.
	 *
	 * WP-CLI's standard `--fields` convention: a comma-separated column list
	 * (or a single `--field`) overriding the command's default columns.
	 *
	 * @since 1.2.0
	 *
	 * @param array    $assoc_args     Associative arguments from the command.
	 * @param string[] $default_fields Default columns when no flag is given.
	 * @return string[] Columns to render.
	 */
	protected function get_fields( $assoc_args, $default_fields ) {
		$fields = \WP_CLI\Utils\get_flag_value( $assoc_args, 'fields', '' );
		if ( '' !== $fields ) {
			$columns = array_map( 'trim', explode( ',', (string) $fields ) );
			return array_values( array_filter( $columns ) );
		}

		$field = \WP_CLI\Utils\get_flag_value( $assoc_args, 'field', '' );
		if ( '' !== $field ) {
			return array( trim( (string) $field ) );
		}

		return $default_fields;
	}

	/**
	 * Check if dry run mode is enabled.
	 *
	 * @param array $assoc_args Associative arguments.
	 * @return bool True if dry run mode.
	 */
	protected function is_dry_run( $assoc_args ) {
		return WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
	}

	/**
	 * Display dry run notice.
	 *
	 * @return void
	 */
	protected function dry_run_notice() {
		WP_CLI::log( WP_CLI::colorize( '%Y' . __( 'DRY RUN MODE - No changes will be made', 'nvdigital-open-operator-system-oos' ) . '%n' ) );
		WP_CLI::log( '' );
	}
}
