/**
 * WP MCP AI Chat Bubble Block for Gutenberg
 *
 * Registers the floating chat bubble block in the Gutenberg editor.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

( function ( blocks, element, blockEditor, components, i18n ) {
	'use strict';

	const el = element.createElement;
	const __ = i18n.__;
	const InspectorControls = blockEditor.InspectorControls;
	const PanelBody = components.PanelBody;
	const SelectControl = components.SelectControl;
	const ToggleControl = components.ToggleControl;
	const TextControl = components.TextControl;
	const RangeControl = components.RangeControl;

	// Get localized data.
	const data = window.wpMcpAiBlocks || {};
	const assistants = data.assistants || [];

	/**
	 * Build assistant options for SelectControl.
	 *
	 * @return {Array} Options array.
	 */
	function getAssistantOptions() {
		const options = [ { value: 0, label: '— Select an assistant —' } ];
		assistants.forEach( function ( assistant ) {
			options.push( { value: assistant.id, label: assistant.title } );
		} );
		return options;
	}

	blocks.registerBlockType( 'mcp-ai-wpoos/chat-bubble', {
		apiVersion: 3,
		title: __( 'AI Chat Bubble', 'nvdigital-open-operator-system-oos' ),
		description: __( 'Display a floating chat bubble powered by WP oOS.', 'nvdigital-open-operator-system-oos' ),
		icon: 'format-chat',
		category: 'nvdigital-open-operator-system-oos',
		keywords: [ 'ai', 'chat', 'bubble', 'floating', 'assistant' ],
		attributes: {
			assistantId: { type: 'number', default: 0 },
			allowGuests: { type: 'boolean', default: false },
			saveTranscript: { type: 'boolean', default: true },
			enableStreaming: { type: 'boolean', default: true },
			allowSensitiveTools: { type: 'boolean', default: false },
			template: { type: 'string', default: 'compact' },
			bubblePosition: { type: 'string', default: 'bottom-right' },
			bubbleSize: { type: 'string', default: 'medium' },
			bubbleAnimation: { type: 'string', default: 'bounce' },
			bubbleTooltip: { type: 'string', default: '' },
			notificationBadge: { type: 'boolean', default: false },
			autoOpenDelay: { type: 'number', default: 0 },
			rememberState: { type: 'boolean', default: false },
			panelTitle: { type: 'string', default: 'Chat with AI' },
			panelWidth: { type: 'number', default: 400 },
			panelHeight: { type: 'number', default: 550 },
			bubbleColor: { type: 'string', default: '#4f46e5' },
			bubbleTextColor: { type: 'string', default: '#ffffff' },
			headerBackground: { type: 'string', default: '' },
			headerTextColor: { type: 'string', default: '#ffffff' }
		},
		supports: {
			anchor: true,
			html: false
		},
		edit: function ( props ) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;

			const selectedAssistant = assistants.find( function ( a ) {
				return a.id === attributes.assistantId;
			} );

			return el( element.Fragment, {},
				el( InspectorControls, {},

					// Chat Settings.
					el( PanelBody, { title: __( 'Chat Settings', 'nvdigital-open-operator-system-oos' ), initialOpen: true },
						el( SelectControl, {
							label: __( 'Assistant', 'nvdigital-open-operator-system-oos' ),
							value: attributes.assistantId,
							options: getAssistantOptions(),
							onChange: function ( val ) {
								setAttributes( { assistantId: parseInt( val, 10 ) } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Allow Guests', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Allow non-logged-in users to use the chat.', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.allowGuests,
							onChange: function ( val ) {
								setAttributes( { allowGuests: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Save Transcript', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.saveTranscript,
							onChange: function ( val ) {
								setAttributes( { saveTranscript: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Enable Streaming', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.enableStreaming,
							onChange: function ( val ) {
								setAttributes( { enableStreaming: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Allow Sensitive Tools', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Allow tools that modify content.', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.allowSensitiveTools,
							onChange: function ( val ) {
								setAttributes( { allowSensitiveTools: val } );
							}
						} ),
						el( SelectControl, {
							label: __( 'Chat Template', 'nvdigital-open-operator-system-oos' ),
							value: attributes.template || 'classic',
							options: [
								{ label: __( 'Classic', 'nvdigital-open-operator-system-oos' ), value: 'classic' },
								{ label: __( 'Speech Bubbles', 'nvdigital-open-operator-system-oos' ), value: 'speech-bubbles' },
								{ label: __( 'Compact', 'nvdigital-open-operator-system-oos' ), value: 'compact' },
								{ label: __( 'Sidebar', 'nvdigital-open-operator-system-oos' ), value: 'sidebar' }
							],
							onChange: function ( val ) {
								setAttributes( { template: val } );
							}
						} )
					),

					// Bubble Settings.
					el( PanelBody, { title: __( 'Bubble Settings', 'nvdigital-open-operator-system-oos' ), initialOpen: true },
						el( SelectControl, {
							label: __( 'Position', 'nvdigital-open-operator-system-oos' ),
							value: attributes.bubblePosition,
							options: [
								{ label: __( 'Bottom Right', 'nvdigital-open-operator-system-oos' ), value: 'bottom-right' },
								{ label: __( 'Bottom Left', 'nvdigital-open-operator-system-oos' ), value: 'bottom-left' },
								{ label: __( 'Top Right', 'nvdigital-open-operator-system-oos' ), value: 'top-right' },
								{ label: __( 'Top Left', 'nvdigital-open-operator-system-oos' ), value: 'top-left' }
							],
							onChange: function ( val ) {
								setAttributes( { bubblePosition: val } );
							}
						} ),
						el( SelectControl, {
							label: __( 'Size', 'nvdigital-open-operator-system-oos' ),
							value: attributes.bubbleSize,
							options: [
								{ label: __( 'Small', 'nvdigital-open-operator-system-oos' ), value: 'small' },
								{ label: __( 'Medium', 'nvdigital-open-operator-system-oos' ), value: 'medium' },
								{ label: __( 'Large', 'nvdigital-open-operator-system-oos' ), value: 'large' }
							],
							onChange: function ( val ) {
								setAttributes( { bubbleSize: val } );
							}
						} ),
						el( SelectControl, {
							label: __( 'Animation', 'nvdigital-open-operator-system-oos' ),
							value: attributes.bubbleAnimation,
							options: [
								{ label: __( 'Bounce', 'nvdigital-open-operator-system-oos' ), value: 'bounce' },
								{ label: __( 'Pulse', 'nvdigital-open-operator-system-oos' ), value: 'pulse' },
								{ label: __( 'None', 'nvdigital-open-operator-system-oos' ), value: 'none' }
							],
							onChange: function ( val ) {
								setAttributes( { bubbleAnimation: val } );
							}
						} ),
						el( TextControl, {
							label: __( 'Tooltip Text', 'nvdigital-open-operator-system-oos' ),
							value: attributes.bubbleTooltip,
							onChange: function ( val ) {
								setAttributes( { bubbleTooltip: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Notification Badge', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Show a notification badge on the bubble.', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.notificationBadge,
							onChange: function ( val ) {
								setAttributes( { notificationBadge: val } );
							}
						} ),
						el( RangeControl, {
							label: __( 'Auto-Open Delay (seconds)', 'nvdigital-open-operator-system-oos' ),
							value: attributes.autoOpenDelay,
							min: 0,
							max: 60,
							onChange: function ( val ) {
								setAttributes( { autoOpenDelay: val } );
							}
						} ),
						el( ToggleControl, {
							label: __( 'Remember State', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Remember open/closed state across page loads.', 'nvdigital-open-operator-system-oos' ),
							checked: attributes.rememberState,
							onChange: function ( val ) {
								setAttributes( { rememberState: val } );
							}
						} )
					),

					// Panel Settings.
					el( PanelBody, { title: __( 'Panel Settings', 'nvdigital-open-operator-system-oos' ), initialOpen: false },
						el( TextControl, {
							label: __( 'Panel Title', 'nvdigital-open-operator-system-oos' ),
							value: attributes.panelTitle,
							onChange: function ( val ) {
								setAttributes( { panelTitle: val } );
							}
						} ),
						el( RangeControl, {
							label: __( 'Panel Width (px)', 'nvdigital-open-operator-system-oos' ),
							value: attributes.panelWidth,
							min: 300,
							max: 600,
							onChange: function ( val ) {
								setAttributes( { panelWidth: val } );
							}
						} ),
						el( RangeControl, {
							label: __( 'Panel Height (px)', 'nvdigital-open-operator-system-oos' ),
							value: attributes.panelHeight,
							min: 400,
							max: 800,
							onChange: function ( val ) {
								setAttributes( { panelHeight: val } );
							}
						} )
					),

					// Colors.
					el( PanelBody, { title: __( 'Colors', 'nvdigital-open-operator-system-oos' ), initialOpen: false },
						el( TextControl, {
							label: __( 'Bubble Color', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Hex color code (e.g. #4f46e5).', 'nvdigital-open-operator-system-oos' ),
							value: attributes.bubbleColor,
							onChange: function ( val ) {
								setAttributes( { bubbleColor: val } );
							}
						} ),
						el( TextControl, {
							label: __( 'Bubble Text Color', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Hex color code (e.g. #ffffff).', 'nvdigital-open-operator-system-oos' ),
							value: attributes.bubbleTextColor,
							onChange: function ( val ) {
								setAttributes( { bubbleTextColor: val } );
							}
						} ),
						el( TextControl, {
							label: __( 'Header Background', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Hex color code for the chat panel header.', 'nvdigital-open-operator-system-oos' ),
							value: attributes.headerBackground,
							onChange: function ( val ) {
								setAttributes( { headerBackground: val } );
							}
						} ),
						el( TextControl, {
							label: __( 'Header Text Color', 'nvdigital-open-operator-system-oos' ),
							help: __( 'Hex color code (e.g. #ffffff).', 'nvdigital-open-operator-system-oos' ),
							value: attributes.headerTextColor,
							onChange: function ( val ) {
								setAttributes( { headerTextColor: val } );
							}
						} )
					)
				),

				// Block preview.
				el( 'div', { className: 'wp-mcp-ai-block-preview wp-mcp-ai-chat-bubble-block-preview' },
					el( 'div', { style: { display: 'flex', alignItems: 'center', gap: '12px' } },
						el( 'span', {
							style: {
								width: '48px',
								height: '48px',
								borderRadius: '50%',
								background: attributes.bubbleColor || '#4f46e5',
								display: 'flex',
								alignItems: 'center',
								justifyContent: 'center',
								color: attributes.bubbleTextColor || '#fff',
								fontSize: '20px'
							}
						}, '💬' ),
						el( 'div', {},
							el( 'strong', {}, __( 'AI Chat Bubble', 'nvdigital-open-operator-system-oos' ) ),
							el( 'br' ),
							el( 'small', {}, attributes.bubblePosition + ' · ' + attributes.bubbleSize ),
							selectedAssistant ? el( 'small', {}, ' · ' + selectedAssistant.title ) : null
						)
					),
					el( 'p', { style: { marginTop: '8px', opacity: 0.6, fontSize: '12px' } },
						__( 'A floating chat bubble will appear on the frontend.', 'nvdigital-open-operator-system-oos' )
					)
				)
			);
		},
		save: function () {
			// Dynamic block - rendered via PHP.
			return null;
		}
	} );
} ( wp.blocks, wp.element, wp.blockEditor, wp.components, wp.i18n ) );
