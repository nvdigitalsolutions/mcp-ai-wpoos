# Pro CLI

## Purpose

Hosts the Pro-only WP-CLI command handlers (`wp mcp-ai connection`, `task`, `project`, `mcp-server`, `toolkit`, `pro status`) that surface Pro toolkits, remote-site connections, schedule manager, and toolkit MCP servers to operators and CI.

## Tier

| | |
|---|---|
| **Distribution** | Pro |
| **PHP target** | 8.1+ |
| **Loaded by** | Each command file self-registers via `WP_CLI::add_command( 'mcp-ai …', WP_MCP_AI_Pro_CLI_*_Command::class )`, gated on `defined( 'WP_CLI' ) && WP_CLI`. The bundle is required from [`addons/pro/mcp-ai-wpoos-pro.php`](../../mcp-ai-wpoos-pro.php) at boot when `WP_CLI` is defined |
| **Optional dependencies** | none — every subcommand asserts Pro is loaded (`assert_pro_loaded()`) and the relevant toolkit is enabled (`assert_toolkit_enabled()`) before doing work |

## Public Surface

The contract is the **`wp mcp-ai <subcommand>`** invocation, not the PHP class. Operators script against the CLI command; do not call the classes directly.

| Symbol | File | Subcommands | Used by |
|---|---|---|---|
| `WP_MCP_AI_Pro_CLI_Base_Command` (abstract) | `class-wp-mcp-ai-pro-cli-base-command.php` | — extends Base's `WP_MCP_AI_CLI_Base_Command`; adds `assert_pro_loaded()` + `assert_toolkit_enabled()` + `render_envelope()` | All concrete Pro commands |
| `WP_MCP_AI_Pro_Toolkit_Settings_Map` | `class-wp-mcp-ai-pro-toolkit-settings-map.php` | — canonical toolkit key → label map consumed by `toolkit` and `pro status` (no WP-CLI dependency) | WP-CLI runtime + tests |
| `WP_MCP_AI_Pro_CLI_Connection_Command` → `wp mcp-ai connection` | `class-wp-mcp-ai-pro-cli-connection-command.php` | `list`, `create`, `get`, `delete`, `test`. Use `--remote-url` (not `--url`) for create. | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Project_Command` → `wp mcp-ai project` | `class-wp-mcp-ai-pro-cli-project-command.php` | `list`, `create`, `get`, `update`, `delete`. Requires `enable_project_management` toolkit. | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Task_Command` → `wp mcp-ai task` | `class-wp-mcp-ai-pro-cli-task-command.php` | `list`, `create`, `get`, `update`, `delete`, `complete`, `dependencies`. Requires `enable_project_management` toolkit. | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Mcp_Server_Command` → `wp mcp-ai mcp-server` | `class-wp-mcp-ai-pro-cli-mcp-server-command.php` | `list`, `get`, `enable`, `disable`, `tools`, `token-generate`, `token-list`, `token-revoke`. Reference implementation. | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Toolkit_Command` → `wp mcp-ai toolkit` | `class-wp-mcp-ai-pro-cli-toolkit-command.php` | `list`, `enable`, `disable` (mutations gated `manage_options`, `--yes` skips the prompt). Reads the canonical settings map. | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Status_Command` → `wp mcp-ai pro status` | `class-wp-mcp-ai-pro-cli-status-command.php` | Default action showing Pro version, core version, active toolkits, remote connections. | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_CRM_Command` → `wp mcp-ai crm` | `class-wp-mcp-ai-pro-cli-crm-command.php` | `lead`, `deal`, `company`, `customer`, `activity`, `ticket` × list/get (CRM toolkit). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Incident_Command` → `wp mcp-ai incident` | `class-wp-mcp-ai-pro-cli-incident-command.php` | `list`, `get`, `resolve` (gated `manage_options`). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Maintenance_Command` → `wp mcp-ai maintenance` | `class-wp-mcp-ai-pro-cli-maintenance-command.php` | `list`, `get`, `cancel` (gated). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Schedule_Command` → `wp mcp-ai schedule` | `class-wp-mcp-ai-pro-cli-schedule-command.php` | `list`, `get`, `run` (gated, `--dry-run`). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Workflow_Command` → `wp mcp-ai workflow` | `class-wp-mcp-ai-pro-cli-workflow-command.php` | `list`, `get`, `validate`. | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Vault_Command` → `wp mcp-ai vault` | `class-wp-mcp-ai-pro-cli-vault-command.php` | `list`, `get` (metadata only — never renders secret material; gated). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Remote_Site_Command` → `wp mcp-ai remote-site` | `class-wp-mcp-ai-pro-cli-remote-site-command.php` | `list`, `get`, `test`, `peer-list` (read-only). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Communication_Command` → `wp mcp-ai communication` | `class-wp-mcp-ai-pro-cli-communication-command.php` | `contacts`, `messages` (chat-channels toolkit). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Media_Studio_Command` → `wp mcp-ai media-studio` | `class-wp-mcp-ai-pro-cli-media-studio-command.php` | `status`, `list-jobs`. | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Foundry_Command` → `wp mcp-ai foundry` | `class-wp-mcp-ai-pro-cli-foundry-command.php` | `status`, `export <assistant-id>` (`--corpus`, `--dry-run`; export gated `manage_options` — routes through the canonical export tools). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Para_Command` → `wp mcp-ai para` | `class-wp-mcp-ai-pro-cli-para-command.php` | `list`, `get` (read-only over `mcp_ai_area`). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Qms_Command` → `wp mcp-ai qms` | `class-wp-mcp-ai-pro-cli-qms-command.php` | `status`, `list` (read-only over `mcp_ai_doc_record`). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Mcp_App_Command` → `wp mcp-ai mcp-app` | `class-wp-mcp-ai-pro-cli-mcp-app-command.php` | `list --assistant-id=<id>` (metadata only — never renders token / oauth_data). | WP-CLI runtime |
| `WP_MCP_AI_Pro_CLI_Fnb_Command` → `wp mcp-ai fnb` | `class-wp-mcp-ai-pro-cli-fnb-command.php` | `status` (toolkit gate, tenant profile, native-storage flag). | WP-CLI runtime |

## Inputs / Outputs / Neighbors

- **Reads from:** WP-CLI `$args` / `$assoc_args`; `wp_mcp_ai_settings` option (toolkit flags); the tool registry; Pro CPT/CCT data (projects, tasks, ECAs, …); remote-site manager state; toolkit MCP server registry
- **Writes to:** stdout (formatted via `WP_CLI::log` / `WP_CLI\Utils\format_items`); Pro CPTs and post meta on mutating subcommands; the same options/DB surfaces as the Pro REST controllers
- **Upstream callers:** the `wp` binary (operators, CI, deploy scripts); occasionally other CLI commands chain into these via `WP_CLI::runcommand`
- **Downstream collaborators:** [`includes/tools/`](../tools/) via `WP_MCP_AI_Tool_Registry`, [`addons/pro/includes/services/`](../services/), [`addons/pro/includes/data-stores/`](../data-stores/), [`addons/pro/includes/mcp-servers/`](../mcp-servers/), [`addons/pro/includes/class-wp-mcp-ai-pro-remote-site-manager.php`](../class-wp-mcp-ai-pro-remote-site-manager.php), [`addons/pro/includes/class-wp-mcp-ai-pro-schedule-manager.php`](../class-wp-mcp-ai-pro-schedule-manager.php)
- **Events fired:** none beyond what the underlying tool / service already emits
- **Events listened to:** none — registration is unconditional once `WP_CLI` is defined

## Conventions

Folder-specific deltas:

- Every concrete command extends `WP_MCP_AI_Pro_CLI_Base_Command` (which extends Base's `WP_MCP_AI_CLI_Base_Command`) so progress bars, batch counters, capability checks, and error/success summaries stay consistent with Base.
- Each file MUST be a no-op outside WP-CLI — guard with `if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) { return; }` near the top, and gate `WP_CLI::add_command(…)` on `class_exists( 'WP_CLI' )`.
- Every new command file MUST be added to the `$wp_mcp_ai_pro_cli_files` list in `wp_mcp_ai_pro_load_cli_commands()` ([`addons/pro/mcp-ai-wpoos-pro.php`](../../mcp-ai-wpoos-pro.php)) — a file that self-registers but is never required silently drops its command (the `mcp-ai content` regression).
- Always call `assert_pro_loaded()` first and `assert_toolkit_enabled( $setting_key, $label )` before invoking toolkit-scoped operations.
- Mutating subcommands MUST call `$this->require_capability( 'manage_options' )` (inherited from base) after input validation.
- Toolkit labels come from `WP_MCP_AI_Pro_Toolkit_Settings_Map` — never hardcode a second copy of the key → label list.
- Output goes through `WP_CLI::log` / `WP_CLI::success` / `WP_CLI::warning` / `WP_CLI::error` — never `echo` or `print_r`.
- Use `$this->get_format( $assoc_args )` / `$this->get_fields( $assoc_args, $defaults )` / `$this->render_envelope( $result, $format )` for consistent output (inherited from base).
- Long-running subcommands SHOULD accept `--dry-run` and `--batch-size=` flags where applicable; mirror the shapes used by Base's `WP_MCP_AI_CLI_Bulk_Command`.

## Tests

```bash
vendor/bin/phpunit addons/pro/tests/test-wp-cli-pro-commands.php
vendor/bin/phpunit addons/pro/tests/test-pro-cli-mcp-server-command.php
```

Tests load command files in isolation (no WP-CLI bootstrap) and assert against argument-parsing, capability gating, and command metadata. Deeper end-to-end coverage of the underlying tools/services lives in their own suites.

## Also Load

- [`.context/conventions.md`](../../../../.context/conventions.md) — naming + style (always)
- [`.context/security-checklist.md`](../../../../.context/security-checklist.md) — capability + sanitisation rules (always)
- [`.context/tool-registry.md`](../../../../.context/tool-registry.md) — for `wp mcp-ai tool …` / `mcp-server tools`
- [`.context/pro-vs-base.md`](../../../../.context/pro-vs-base.md) — what belongs in Pro CLI vs Base CLI
- [`.context/testing.md`](../../../../.context/testing.md) — running CLI tests
- [`CLAUDE.md`](../../../../CLAUDE.md) — PHP-compat + two-gate sanitisation rules

## See Also

- Base counterpart: [`includes/cli/`](../../../../includes/cli/) — `wp mcp-ai assistant|bulk|content|credential|dlq|log|measurement|settings|sla|slash|tool`
- Sibling surfaces: [`addons/pro/includes/rest/`](../rest/), [`addons/pro/includes/slash-commands/`](../slash-commands/) — many Pro CLI commands have chat-side slash-command and REST counterparts
- Collaborators: [`addons/pro/includes/mcp-servers/`](../mcp-servers/), [`addons/pro/includes/services/`](../services/), [`addons/pro/includes/class-wp-mcp-ai-pro-remote-site-manager.php`](../class-wp-mcp-ai-pro-remote-site-manager.php)
