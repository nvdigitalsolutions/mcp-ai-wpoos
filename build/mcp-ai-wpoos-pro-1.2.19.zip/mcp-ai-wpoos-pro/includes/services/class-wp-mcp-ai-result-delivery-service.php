<?php
/**
 * Pro Schedule Result Delivery Service.
 *
 * Routes successful and failed schedule run results to configured delivery
 * channels: email, chat platforms (Slack, Teams, Discord, Telegram, etc.),
 * SMS, Paper Store, WordPress posts, and external webhooks.
 *
 * Exists as a standalone service so any schedule type (task, workflow,
 * assistant_run, channel_broadcast, workflow_builder) can route its output
 * through the same delivery pipeline without duplicating back-end logic.
 *
 * @package WP_MCP_AI_Pro
 * @since   1.0.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions. All rights reserved.
 * @license   Proprietary
 *
 * SPDX-License-Identifier: LicenseRef-Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-wp-mcp-ai-markdown-converter.php';

if ( ! class_exists( 'WP_MCP_AI_Result_Delivery_Service' ) ) {
	/**
	 * Result Delivery Service — static methods, no constructor state.
	 *
	 * Called from {@see WP_MCP_AI_Pro_Schedule_Manager::dispatch()} after
	 * `record_run()` completes. Iterates the schedule's `result_delivery`
	 * configuration and sends the result envelope (or failure message) to
	 * each enabled channel.
	 */
	class WP_MCP_AI_Result_Delivery_Service {

		/**
		 * Supported delivery channel slugs.
		 *
		 * @var string[]
		 */
		const SUPPORTED_CHANNELS = array(
			'email',
			'slack',
			'telegram',
			'discord',
			'teams',
			'messenger',
			'whatsapp',
			'google_chat',
			'sms',
			'paper_store',
			'webhook',
			'wordpress',
		);

		/**
		 * Valid template modes for email delivery.
		 *
		 * - `full`: response + execution log (all structured envelope data).
		 * - `summary`: summary line + relevant response excerpt (no execution log).
		 * - `error`: error message.
		 * - `response_only`: the substantive response only — no summary, no log.
		 * - `action_items`: only the actionable section of the response — no
		 *   roundup intro or informational filler.
		 *
		 * @var string[]
		 */
		const EMAIL_TEMPLATES = array( 'full', 'summary', 'error', 'response_only', 'action_items' );

		/**
		 * Valid presentation formats for email delivery.
		 *
		 * - `both`: HTML body rendered from Markdown plus a text/plain Markdown
		 *   fallback (multipart/alternative — the industry-standard shape).
		 * - `html`: HTML body only.
		 * - `markdown`: plain-text Markdown only.
		 *
		 * @var string[]
		 */
		const EMAIL_FORMATS = array( 'both', 'html', 'markdown' );

		/**
		 * Valid template modes for chat / SMS delivery.
		 *
		 * - `summary`: summary line + response excerpt.
		 * - `error`: error message.
		 * - `response_only`: the substantive response only.
		 * - `full`: the complete report — summary, response, and structured
		 *   data — mirroring the email `full` template.
		 * - `action_items`: only the actionable section of the response — no
		 *   roundup intro or informational filler.
		 *
		 * @var string[]
		 */
		const CHAT_TEMPLATES = array( 'summary', 'error', 'response_only', 'full', 'action_items' );

		/**
		 * Valid presentation formats for chat delivery.
		 *
		 * - `html`: Telegram HTML parse mode (<b>bold</b> etc.).
		 * - `markdown`: *bold* markup — rendered natively by Slack, Discord,
		 *   Teams, and WhatsApp; sent to Telegram as legacy Markdown parse mode.
		 * - `markdown_v2`: Telegram MarkdownV2 parse mode (strict escaping).
		 * - `plain`: no markup and no parse mode.
		 *
		 * Availability is per-channel (see {@see resolve_chat_format()}).
		 *
		 * @var string[]
		 */
		const CHAT_FORMATS = array( 'html', 'markdown', 'markdown_v2', 'plain' );

		/**
		 * Valid template modes for SMS delivery.
		 *
		 * @var string[]
		 */
		const SMS_TEMPLATES = array( 'short', 'error' );

		// -------------------------------------------------------------------------
		// Public entry points — called from Schedule Manager
		// -------------------------------------------------------------------------

		/**
		 * Deliver a successful run result to all configured channels.
		 *
		 * @since 1.0.0
		 *
		 * @param string              $schedule_id Schedule identifier.
		 * @param array               $envelope    Structured result envelope (from record_run).
		 * @param array               $schedule    Schedule record.
		 * @param array<string,mixed> $action_log  Raw action log from the dispatcher.
		 * @return array<string,array> Per-channel delivery status, keyed by channel slug.
		 */
		public static function deliver_success( $schedule_id, array $envelope, array $schedule, array $action_log = array() ) {
			$delivery = isset( $schedule['result_delivery']['on_success']['channels'] ) && is_array( $schedule['result_delivery']['on_success']['channels'] )
				? $schedule['result_delivery']['on_success']['channels']
				: array();

			if ( empty( $delivery ) ) {
				return array();
			}

			return self::deliver_to_channels( $schedule_id, $envelope, $delivery, $schedule, $action_log, true );
		}

		/**
		 * Deliver a failure notification to all configured channels.
		 *
		 * Falls back to legacy `notify_*` fields when `result_delivery` is absent
		 * so that existing schedules continue to function without migration.
		 *
		 * @since 1.0.0
		 *
		 * @param string $schedule_id Schedule identifier.
		 * @param string $error_msg   Error message from the failed run.
		 * @param array  $schedule    Schedule record.
		 * @return array<string,array> Per-channel delivery status, keyed by channel slug.
		 */
		public static function deliver_failure( $schedule_id, $error_msg, array $schedule ) {
			$delivery = isset( $schedule['result_delivery']['on_failure']['channels'] ) && is_array( $schedule['result_delivery']['on_failure']['channels'] )
				? $schedule['result_delivery']['on_failure']['channels']
				: array();

			// Fallback: migrate legacy notify_* fields on the fly.
			if ( empty( $delivery ) ) {
				$delivery = self::build_legacy_failure_channels( $schedule );
			}

			if ( empty( $delivery ) ) {
				return array();
			}

			// Build a minimal failure envelope so format_for_channel has something to work with.
			$envelope = array(
				'status'       => 'failure',
				'summary'      => $error_msg,
				'generated_at' => time(),
			);

			return self::deliver_to_channels( $schedule_id, $envelope, $delivery, $schedule, array(), false );
		}

		// -------------------------------------------------------------------------
		// Delivery orchestrator
		// -------------------------------------------------------------------------

		/**
		 * Fan-out delivery to all enabled channels.
		 *
		 * Each channel send is wrapped in its own try/catch so a failure in one
		 * channel (e.g. Slack webhook timeout) never blocks delivery to another.
		 *
		 * @param string              $schedule_id  Schedule identifier.
		 * @param array               $envelope     Result envelope (or failure stub).
		 * @param array               $channel_cfgs Per-channel config keyed by slug.
		 * @param array               $schedule     Schedule record.
		 * @param array<string,mixed> $action_log   Raw action log from dispatch.
		 * @param bool                $is_success   Whether this is a success or failure delivery.
		 * @return array<string,array> Per-channel status.
		 */
		protected static function deliver_to_channels( $schedule_id, array $envelope, array $channel_cfgs, array $schedule, array $action_log, $is_success ) {
			$statuses = array();

			// Pre-compute whether the AI already created posts via its own tool
			// calls, so that each WordPress channel can decide individually
			// (based on its skip_if_ai_posted setting) whether to auto-skip.
			$ai_created_post = self::should_skip_wordpress_delivery( $action_log );

			foreach ( $channel_cfgs as $raw_channel => $config ) {
				// Normalise canonical casing for WordPress to avoid case-sensitivity
				// bugs (older data may have been stored with lowercase key).
				// phpcs:ignore WordPress.WP.CapitalPDangit.MisspelledInText -- intentional lowercase key comparison
				$channel = 'wordpress' === $raw_channel ? 'WordPress' : $raw_channel;

				if ( ! is_array( $config ) || empty( $config['enabled'] ) ) {
					continue;
				}

				if ( ! in_array( $channel, self::SUPPORTED_CHANNELS, true ) ) {
					continue;
				}

				// Skip WordPress delivery when the AI already handled post creation
				// via create_post or save_post tool calls during the run — UNLESS
				// the user explicitly opted out of this guard.
				if ( 'WordPress' === $channel && $ai_created_post ) {
					$skip_if_ai = ! isset( $config['skip_if_ai_posted'] ) || ! empty( $config['skip_if_ai_posted'] );
					if ( $skip_if_ai ) {
						$statuses['wordpress'] = self::log_delivery_skip(
							$schedule_id,
							__( 'Skipped — AI already created post via create_post/save_post tool.', 'mcp-ai-wpoos-pro' ),
							$is_success
						);
						continue;
					}
				}

				$template = isset( $config['template'] ) ? (string) $config['template'] : 'summary';
				$payload  = self::format_for_channel( $envelope, $channel, $template, $schedule, $action_log, $config );

				try {
					$result = self::send_to_channel( $channel, $payload, $config, $schedule );
				} catch ( Throwable $e ) {
					$result = new WP_Error(
						'result_delivery_exception',
						$e->getMessage()
					);
				}

				$statuses[ $channel ] = self::log_delivery( $schedule_id, $channel, $result, $is_success );
			}

			return $statuses;
		}

		/**
		 * Determine whether the WordPress delivery channel should be skipped.
		 *
		 * When an assistant_run schedule instructs the AI to call create_post
		 * or save_post, the post already exists in WordPress.  Enabling the
		 * WordPress delivery channel on top of that would produce a duplicate
		 * envelope-summary post, which is almost never the desired behaviour.
		 *
		 * This guard inspects the action_log to see whether any tool call
		 * during the run matches a post-creation slug.  It is intentionally
		 * scoped to assistant_run dispatches; workflow, task, and broadcast
		 * schedules are unaffected because they do not populate the
		 * `assistant.tool_calls` key.
		 *
		 * @since 1.0.0
		 *
		 * @param array $action_log Raw action log from the dispatcher.
		 * @return bool True if WordPress delivery should be suppressed.
		 */
		protected static function should_skip_wordpress_delivery( array $action_log ) {
			$tool_calls = isset( $action_log['assistant']['tool_calls'] ) && is_array( $action_log['assistant']['tool_calls'] )
				? $action_log['assistant']['tool_calls']
				: array();

			if ( empty( $tool_calls ) ) {
				return false;
			}

			$post_creation_tools = array( 'create_post', 'save_post', 'save_post_validated' );

			foreach ( $tool_calls as $tool_call ) {
				$name = isset( $tool_call['name'] ) ? (string) $tool_call['name'] : '';
				if ( in_array( $name, $post_creation_tools, true ) ) {
					return true;
				}
			}

			return false;
		}

		// -------------------------------------------------------------------------
		// Formatting — envelope → channel-appropriate payload
		// -------------------------------------------------------------------------

		/**
		 * Shape the raw result envelope into a format suitable for a specific channel.
		 *
		 * @param array               $envelope    Result envelope.
		 * @param string              $channel     Channel slug.
		 * @param string              $template    Template mode (full, summary, short, error).
		 * @param array               $schedule    Schedule record (for name, tags, etc.).
		 * @param array<string,mixed> $action_log  Raw action log.
		 * @param array               $config      Channel config (template, format, destination fields).
		 * @return array Formatted payload keyed by channel needs (subject, body, html, etc.).
		 */
		protected static function format_for_channel( array $envelope, $channel, $template, array $schedule, array $action_log, array $config = array() ) {
			$schedule_name = isset( $schedule['name'] ) ? (string) $schedule['name'] : '';
			$schedule_type = isset( $schedule['schedule_type'] ) ? (string) $schedule['schedule_type'] : 'task';
			$summary       = isset( $envelope['summary'] ) ? (string) $envelope['summary'] : '';
			$response      = isset( $envelope['response'] ) ? (string) $envelope['response'] : '';
			$status        = isset( $envelope['status'] ) ? (string) $envelope['status'] : '';
			$is_success    = 'failure' !== $status;
			$generated_at  = isset( $envelope['generated_at'] ) ? (int) $envelope['generated_at'] : time();

			$formatted = array(
				'schedule_name' => $schedule_name,
				'summary'       => $summary,
				'response'      => $response,
				'status'        => $status,
				'is_success'    => $is_success,
				'generated_at'  => $generated_at,
				'schedule_type' => $schedule_type,
			);

			switch ( $channel ) {
				case 'email':
					return self::format_email( $formatted, $envelope, $template );

				case 'sms':
					return self::format_sms( $formatted, $template );

				case 'paper_store':
					return self::format_paper_store( $formatted, $envelope, $schedule );

				case 'WordPress':
					return self::format_wordpress_post( $formatted, $envelope, $schedule );

				case 'webhook':
					return self::format_webhook( $formatted, $envelope, $schedule, $action_log );

				// Chat channels: slack, telegram, discord, teams, messenger,
				// whatsapp, google_chat.
				default:
					$format = self::resolve_chat_format( $channel, $config );
					return self::format_chat( $formatted, $template, $format, $envelope );
			}
		}

		/**
		 * Resolve the presentation format for a chat channel from its config.
		 *
		 * Each channel supports a subset of {@see CHAT_FORMATS}. Telegram is the
		 * only channel with parse modes, so it defaults to `html` (best rendering
		 * with the escaping already applied); WhatsApp, Slack, Discord, and Teams
		 * render *bold* Markdown natively and default to `markdown`; Messenger and
		 * Google Chat do not render markup and default to `plain`. Invalid or
		 * missing values fall back to the channel default.
		 *
		 * @param string $channel Channel slug.
		 * @param array  $config  Channel config from schedule['result_delivery'].
		 * @return string Resolved format.
		 */
		protected static function resolve_chat_format( $channel, array $config ) {
			$defaults = array(
				'telegram'    => 'html',
				'whatsapp'    => 'markdown',
				'slack'       => 'markdown',
				'discord'     => 'markdown',
				'teams'       => 'markdown',
				'messenger'   => 'plain',
				'google_chat' => 'plain',
			);
			$allowed  = array(
				'telegram'    => array( 'html', 'markdown', 'markdown_v2', 'plain' ),
				'whatsapp'    => array( 'markdown', 'plain' ),
				'slack'       => array( 'markdown', 'plain' ),
				'discord'     => array( 'markdown', 'plain' ),
				'teams'       => array( 'markdown', 'plain' ),
				'messenger'   => array( 'plain' ),
				'google_chat' => array( 'plain' ),
			);

			$default = isset( $defaults[ $channel ] ) ? $defaults[ $channel ] : 'markdown';
			if ( ! isset( $allowed[ $channel ] ) ) {
				return $default;
			}

			$format = isset( $config['format'] ) ? sanitize_key( (string) $config['format'] ) : '';
			return in_array( $format, $allowed[ $channel ], true ) ? $format : $default;
		}

		/**
		 * Map a chat presentation format to a Telegram parse_mode.
		 *
		 * @param string $format Chat presentation format.
		 * @return string Telegram parse_mode, or empty string for plain text.
		 */
		protected static function telegram_parse_mode( $format ) {
			switch ( $format ) {
				case 'html':
					return 'HTML';
				case 'markdown':
					return 'Markdown';
				case 'markdown_v2':
					return 'MarkdownV2';
				default:
					return '';
			}
		}

		/**
		 * Escape Telegram MarkdownV2 reserved characters.
		 *
		 * MarkdownV2 rejects messages containing unescaped reserved characters
		 * (`_ * [ ] ( ) ~ ` > # + - = | { } . !`) with a 400 parse error, so
		 * every content-derived value must be escaped before sending.
		 *
		 * @param string $text Raw text.
		 * @return string Escaped text.
		 */
		protected static function escape_markdown_v2( $text ) {
			$text = (string) $text;
			foreach ( array( '_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!' ) as $char ) {
				$text = str_replace( $char, '\\' . $char, $text );
			}
			return $text;
		}

		/**
		 * Format for email delivery.
		 *
		 * The payload carries both a `plain` (Markdown source, used as the
		 * text/plain multipart alternative) and an `html_body` (Markdown
		 * rendered to email-safe HTML) so the sender can honour the channel's
		 * presentation format setting.
		 *
		 * @param array  $shared   Common formatted fields.
		 * @param array  $envelope Full envelope.
		 * @param string $template Template mode.
		 * @return array Email payload (subject, plain, html_body, template_mode).
		 */
		protected static function format_email( array $shared, array $envelope, $template ) {
			$site_name = get_bloginfo( 'name' );
			$is_error  = 'error' === $template;
			$emoji     = $is_error ? "\u{26A0}\u{FE0F}" : "\u{2705}";

			$subject = sprintf(
				/* translators: 1: status emoji, 2: site name, 3: schedule name */
				__( '%1$s [%2$s] %3$s', 'mcp-ai-wpoos-pro' ),
				$emoji,
				$site_name,
				$shared['schedule_name']
			);

			$body = '';
			if ( $is_error ) {
				$body = $shared['summary'];
			} elseif ( 'response_only' === $template ) {
				// Deliver only the substantive AI/tool response — no summary, no log.
				$body = isset( $shared['response'] ) ? (string) $shared['response'] : $shared['summary'];
			} elseif ( 'action_items' === $template ) {
				// Only the actionable section of the response. Roundup intros
				// and informational filler are noise on a notification, so
				// when no action section exists fall back to the substantive
				// response (mirroring response_only) instead of the trimmed
				// summary.
				$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
				$block    = self::extract_action_items( $response );
				$body     = '' !== $block
					? __( 'Action items', 'mcp-ai-wpoos-pro' ) . ":\n" . $block
					: ( '' !== $response ? $response : $shared['summary'] );
			} elseif ( 'full' === $template && isset( $envelope['data'] ) ) {
				// Full mode: include the response prominently, then the data structure.
				// Assistant-run envelopes derive the summary from the response's
				// first words, so leading with the summary would print the header
				// twice inside the delivered email.
				$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
				$summary  = (string) $shared['summary'];
				$body     = '';
				if ( '' !== $summary && ! self::response_starts_with_summary( $response, $summary ) ) {
					$body = $summary;
				}
				if ( '' !== $response ) {
					if ( '' !== $body ) {
						$body .= "\n\n---\n\n";
					}
					/* translators: heading for the main result output in emails */
					$body .= __( 'Results', 'mcp-ai-wpoos-pro' ) . ":\n";
					$body .= $response;
				}
				// Render the structured data section for delivery. Assistant-run
				// envelopes store a duplicate of the response plus internal
				// execution metadata under `data`; delivery_safe_data() strips
				// those keys so the report does not repeat the response or end
				// with assistant_id / is_agentic metadata as a footer.
				$data_text = self::envelope_data_to_delivery_text( isset( $envelope['data'] ) ? $envelope['data'] : array() );
				if ( '' !== trim( $data_text ) ) {
					if ( '' !== $body ) {
						$body .= "\n\n---\n\n";
					}
					$body .= $data_text;
				}
			} else {
				// Summary template: summary line plus a relevant excerpt of the
				// response (distillation/action section, or centroid-ranked
				// sentences) — see select_representative_excerpt(). Assistant-run
				// summaries are a trim of the response's first words, so skip the
				// summary line when the response already opens with it.
				$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
				$summary  = (string) $shared['summary'];
				$is_dup   = '' !== $response && '' !== $summary && self::response_starts_with_summary( $response, $summary );
				$body     = '';
				if ( ! $is_dup && '' !== $summary ) {
					$body = $summary;
				}
				if ( '' !== $response ) {
					$excerpt = self::select_representative_excerpt( $response, 80 );
					if ( '' !== trim( $excerpt ) ) {
						if ( '' !== $body ) {
							$body .= "\n\n---\n\n";
						}
						$body .= $excerpt;
					}
				}
				if ( '' === $body ) {
					$body = $summary;
				}
			}

			$manage_url = admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=orchestration' );

			// Render the Markdown source to email-safe HTML so clients can
			// display the formatted digest. The Markdown itself is kept as the
			// multipart text/plain alternative — Markdown reads cleanly as
			// plain text, satisfying the industry-standard fallback.
			$html_body = WP_MCP_AI_Markdown_Converter::to_html( $body );

			return array(
				'subject'       => $subject,
				'plain'         => $body,
				'html_body'     => $html_body,
				'summary'       => $shared['summary'],
				'is_error'      => $is_error,
				'template_mode' => $template,
				'site_name'     => $site_name,
				'manage_url'    => $manage_url,
				'generated_at'  => $shared['generated_at'],
			);
		}

		/**
		 * Determine whether a response already opens with the summary text.
		 *
		 * Assistant-run envelopes derive their summary from the response's
		 * first words via {@see wp_trim_words()}, so the `full` delivery
		 * templates would otherwise print the header twice — once as the
		 * summary and again at the top of the response. The comparison
		 * normalises tags and whitespace (wp_trim_words() joins words with
		 * single spaces) and ignores the summary's trailing ellipsis, which
		 * never appears verbatim inside the response.
		 *
		 * @param string $response Substantive response text.
		 * @param string $summary  Summary text.
		 * @return bool True when the response begins with the summary.
		 */
		protected static function response_starts_with_summary( $response, $summary ) {
			$normalize = static function ( $text ) {
				$text = wp_strip_all_tags( (string) $text );
				$text = preg_replace( '/\s+/u', ' ', trim( $text ) );
				$text = preg_replace( '/…+\s*$/u', '', $text );
				return trim( $text );
			};

			$response_norm = $normalize( $response );
			$summary_norm  = $normalize( $summary );

			if ( '' === $summary_norm || '' === $response_norm ) {
				return false;
			}

			if ( 0 !== mb_strpos( $response_norm, $summary_norm ) ) {
				return false;
			}

			// The summary must end on a word boundary: the next character in
			// the response must not continue the word ("Word" must not match
			// the start of "Wordsmith").
			$next = mb_substr( $response_norm, mb_strlen( $summary_norm ), 1 );
			return '' === $next || 1 !== preg_match( '/^[\p{L}\p{N}_]$/u', $next );
		}

		/**
		 * Determine whether a response line reads as a section heading.
		 *
		 * A line reads as a heading when it is a Markdown heading, a standalone
		 * bold label (excluding bold list items), or a short label-style line
		 * that is not a list item and ends with a colon or dash.
		 *
		 * @param string $line Response line.
		 * @return bool True when the line reads as a heading.
		 */
		protected static function line_is_heading( $line ) {
			$trimmed = trim( $line );
			if ( '' === $trimmed ) {
				return false;
			}
			if ( 1 === preg_match( '/^#+/u', $trimmed ) ) {
				return true;
			}
			if ( 1 === preg_match( '/^\*\*(.+?)\*\*$/u', $trimmed, $m ) ) {
				// Bold list items (e.g. **1. "Title" — date**) are content.
				return 1 !== preg_match( '/^\d+[.)]/u', trim( $m[1] ) );
			}
			if ( 1 === preg_match( '/^([-*\u{2022}]|\d+[.)])\s/u', $trimmed ) ) {
				return false;
			}
			return ( ! function_exists( 'mb_strlen' ) || mb_strlen( $trimmed ) <= 80 )
				&& 1 === preg_match( '/[:\x{FF1A}\-\u{2013}\u{2014}]\s*$/u', $trimmed );
		}

		/**
		 * Extract the block under the first heading whose label matches a phrase.
		 *
		 * Shared engine behind {@see extract_action_items()} and the summary
		 * template's relevant-block selection. Starts at the first heading whose
		 * label (the text before a colon, with Markdown markers stripped)
		 * matches `$phrase` — unless it matches `$negative` — and ends at the
		 * next section heading. Headings may carry an item on the same line
		 * after a colon.
		 *
		 * @param string $response Response text.
		 * @param string $phrase   Heading-label phrase pattern (PCRE).
		 * @param string $negative Optional negative phrase pattern; labels
		 *                         matching it are ignored.
		 * @return string Extracted block, or an empty string when no matching
		 *                heading exists.
		 */
		protected static function extract_section_block( $response, $phrase, $negative = '' ) {
			$text  = wp_strip_all_tags( (string) $response );
			$lines = preg_split( '/\r\n|\r|\n/', $text );

			if ( ! is_array( $lines ) || empty( $lines ) ) {
				return '';
			}

			$block_lines = array();
			$collecting  = false;
			foreach ( $lines as $line ) {
				if ( ! $collecting ) {
					// List items and prose are not section headings.
					if ( 1 === preg_match( '/^([-*\u{2022}]|\d+[.)])\s/u', $line ) ) {
						continue;
					}

					// Strip Markdown markers so the label can be matched directly.
					$candidate = trim( preg_replace( '/^#+\s*/u', '', $line ) );
					$candidate = trim( preg_replace( '/^\*\*/u', '', $candidate ) );
					$candidate = trim( preg_replace( '/\*\*$/u', '', $candidate ) );
					$label     = preg_split( '/[:\x{FF1A}]/u', $candidate, 2 );
					$label     = trim( is_array( $label ) ? $label[0] : $candidate );

					if (
						'' === $label
						|| 1 !== preg_match( $phrase, $label )
						|| ( '' !== $negative && 1 === preg_match( $negative, $label ) )
					) {
						continue;
					}

					// The label must read as a heading: a heading-style line, or a
					// short standalone phrase (not a prose sentence).
					if (
						! self::line_is_heading( $line )
						&& ( function_exists( 'mb_strlen' ) && mb_strlen( $label ) > 40 )
					) {
						continue;
					}

					$collecting = true;
					// Headings may carry an item on the same line after a colon.
					$parts = preg_split( '/[:\x{FF1A}]/u', $candidate, 2 );
					if ( is_array( $parts ) && isset( $parts[1] ) && '' !== trim( $parts[1] ) ) {
						$block_lines[] = trim( $parts[1] );
					}
					continue;
				}

				if ( self::line_is_heading( $line ) ) {
					// Next section heading — the block ends here.
					break;
				}
				$block_lines[] = $line;
			}

			return trim( implode( "\n", $block_lines ) );
		}

		/**
		 * Extract the actionable portion of an assistant response.
		 *
		 * Roundup-style responses bury the useful part under an intro, so the
		 * `action_items` delivery templates forward only the block under the
		 * first action-signalling heading ("Action Items", "Needs your
		 * attention", "Next steps", "To-do", "Follow-ups", "Recommendations",
		 * …). Negative phrasings ("no action needed") are not treated as
		 * action headings.
		 *
		 * @param string $response Substantive response text.
		 * @return string Extracted block, or an empty string when the response
		 *                carries no action section.
		 */
		protected static function extract_action_items( $response ) {
			$action_phrase = '/(?:action(?:\s+item)?s?(?:\s+(?:required|needed))?|actionable|needs?\s+(?:your\s+)?attention|follow[\s\-]?ups?|to[\s\-]?do|next\s+steps?|recommendations?)/iu';
			$negative      = '/(?:no|without)\s+(?:action|follow[\s\-]?ups?|next\s+steps?|recommendations?)/iu';

			return self::extract_section_block( $response, $action_phrase, $negative );
		}

		/**
		 * Select the most representative block of a response for an excerpt.
		 *
		 * Digest notifications should be concise, prioritised, and scannable,
		 * so the excerpt leads with the most relevant content instead of the
		 * first words of the response. Priority order:
		 *
		 * 1. The response's own distillation section ("Summary", "TL;DR",
		 *    "Key points", "Highlights", "Results", …).
		 * 2. The actionable section (see {@see extract_action_items()}).
		 * 3. Centroid extraction: sentences are scored by content-word
		 *    frequency (MEAD-style centrality) weighted by position, and the
		 *    top-ranked sentences are returned in original order — the
		 *    position-augmented centrality baseline of extractive
		 *    summarisation, with a lead trim as the final fallback.
		 *
		 * @param string $response    Substantive response text.
		 * @param int    $word_budget Maximum words in the returned excerpt.
		 * @return string Representative excerpt.
		 */
		protected static function select_representative_excerpt( $response, $word_budget = 80 ) {
			$word_budget = max( 1, (int) $word_budget );
			$text        = wp_strip_all_tags( (string) $response );

			// 1. The author's own distillation section.
			$summary_phrase   = '/(?:tldr|tl;dr|executive\s+summary|summary|overview|highlights?|key\s+points?|takeaways?|findings?|results?|conclusions?|bottom\s+line|recap)/iu';
			$summary_negative = '/(?:no|without)\s+(?:summary|results?|findings?)/iu';
			$block            = self::extract_section_block( $text, $summary_phrase, $summary_negative );

			// 2. The actionable section.
			if ( '' === $block ) {
				$block = self::extract_action_items( $text );
			}

			if ( '' !== $block ) {
				return wp_trim_words( $block, $word_budget, '…' );
			}

			// 3. Centroid extraction with a positional lead bias.
			$sentences = preg_split( '/(?<=[.!?\u{2026}])\s+(?=\p{Lu})/u', $text );
			if ( ! is_array( $sentences ) || count( $sentences ) < 2 ) {
				return wp_trim_words( $text, $word_budget, '…' );
			}

			$stopwords = array(
				'a',
				'an',
				'the',
				'and',
				'or',
				'but',
				'for',
				'of',
				'in',
				'on',
				'at',
				'to',
				'with',
				'by',
				'is',
				'are',
				'was',
				'were',
				'be',
				'been',
				'being',
				'this',
				'that',
				'these',
				'those',
				'it',
				'its',
				'as',
				'from',
				'here',
				'your',
				'you',
				'we',
				'our',
				'they',
				'he',
				'she',
				'i',
				'us',
				'them',
				'have',
				'has',
				'had',
				'do',
				'does',
				'did',
				'not',
				'no',
				'so',
				'also',
				'just',
				'then',
				'than',
				'can',
				'could',
				'will',
				'would',
				'should',
				'there',
				'their',
				'what',
				'when',
				'who',
				'which',
				'get',
				'got',
				'into',
				'up',
				'out',
				'about',
				'over',
				'under',
				'after',
				'before',
			);
			$stop      = array_flip( $stopwords );
			$lowercase = function_exists( 'mb_strtolower' ) ? 'mb_strtolower' : 'strtolower';

			// Content tokens: stopword-free words of four or more characters.
			$content_tokens = static function ( $sentence ) use ( $stop, $lowercase ) {
				$tokens = preg_split( '/[^\p{L}\p{N}]+/u', call_user_func( $lowercase, $sentence ), -1, PREG_SPLIT_NO_EMPTY );
				if ( ! is_array( $tokens ) ) {
					return array();
				}
				return array_values(
					array_filter(
						$tokens,
						static function ( $token ) use ( $stop ) {
							return mb_strlen( $token ) >= 4 && ! isset( $stop[ $token ] );
						}
					)
				);
			};

			// Content-word frequency across the response (centroid weights).
			$freq = array();
			foreach ( $sentences as $sentence ) {
				foreach ( $content_tokens( $sentence ) as $token ) {
					$freq[ $token ] = isset( $freq[ $token ] ) ? $freq[ $token ] + 1 : 1;
				}
			}

			// Score = mean centroid weight × positional decay; the lead sentence
			// keeps full weight and later sentences decay by 0.85 per position.
			$scored = array();
			foreach ( $sentences as $index => $sentence ) {
				$tokens = $content_tokens( $sentence );
				$score  = 0.0;
				if ( ! empty( $tokens ) ) {
					$sum = 0;
					foreach ( $tokens as $token ) {
						$sum += isset( $freq[ $token ] ) ? $freq[ $token ] : 0;
					}
					$score = $sum / count( $tokens );
				}
				$score   *= pow( 0.85, $index );
				$scored[] = array(
					'score' => $score,
					'index' => $index,
					'words' => count( preg_split( '/\s+/', trim( $sentence ), -1, PREG_SPLIT_NO_EMPTY ) ),
				);
			}

			// Pick the top-ranked sentences, then restore the original order.
			$order = array_keys( $scored );
			usort(
				$order,
				static function ( $a, $b ) use ( $scored ) {
					return $scored[ $b ]['score'] <=> $scored[ $a ]['score'];
				}
			);

			$selected = array();
			$used     = 0;
			foreach ( $order as $index ) {
				if ( $used > 0 && $used + $scored[ $index ]['words'] > $word_budget ) {
					continue;
				}
				$selected[] = $index;
				$used      += $scored[ $index ]['words'];
			}
			sort( $selected );

			$excerpt = '';
			foreach ( $selected as $index ) {
				$excerpt .= ( '' === $excerpt ? '' : ' ' ) . trim( $sentences[ $index ] );
			}

			if ( '' === trim( $excerpt ) ) {
				return wp_trim_words( $text, $word_budget, '…' );
			}

			return wp_trim_words( $excerpt, $word_budget, '…' );
		}

		/**
		 * Format for chat channel delivery (Slack, Teams, Discord, Telegram, etc.).
		 *
		 * Builds the message per presentation format: `html` uses <b> tags,
		 * `markdown`/`markdown_v2` use *bold* markers, and `plain` adds no markup.
		 * The `full` template appends the complete response and the structured
		 * envelope data, mirroring the email `full` template.
		 *
		 * @param array  $shared   Common formatted fields.
		 * @param string $template Template mode.
		 * @param string $format   Presentation format (html, markdown, markdown_v2, plain).
		 * @param array  $envelope Full result envelope (used by the full template).
		 * @return array Chat payload (message + Telegram parse_mode).
		 */
		protected static function format_chat( array $shared, $template, $format = 'markdown', array $envelope = array() ) {
			$is_error = 'error' === $template;
			$emoji    = $is_error ? "\u{26A0}\u{FE0F}" : "\u{2705}";
			$site     = get_bloginfo( 'name' );
			$format   = in_array( $format, self::CHAT_FORMATS, true ) ? $format : 'markdown';

			// Escape content per format: plain keeps raw text, MarkdownV2 escapes
			// Telegram reserved characters, everything else uses HTML escaping
			// (valid inside both Telegram HTML and *-based Markdown markup).
			$esc = static function ( $text ) use ( $format ) {
				$text = (string) $text;
				if ( 'plain' === $format ) {
					return wp_strip_all_tags( $text );
				}
				if ( 'markdown_v2' === $format ) {
					return self::escape_markdown_v2( wp_strip_all_tags( $text ) );
				}
				return esc_html( $text );
			};

			// Bold wrapper per format.
			$bold = static function ( $text ) use ( $format ) {
				if ( 'html' === $format ) {
					return '<b>' . $text . '</b>';
				}
				if ( 'markdown' === $format || 'markdown_v2' === $format ) {
					return '*' . $text . '*';
				}
				return $text;
			};

			$message  = $emoji . ' ' . $bold( $esc( $shared['schedule_name'] ) ) . "\n";
			$message .= "\u{1F3E2} " . $esc( $site ) . '  |  ';
			$message .= "\u{1F4C5} " . $esc( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $shared['generated_at'] ) ) . "\n";

			if ( 'full' === $template ) {
				// Full report: complete summary, substantive response, and the
				// structured envelope data — mirrors the email full template.
				// Assistant-run summaries are a trim of the response's first
				// words, so skip the summary when the response already opens
				// with it (otherwise the header prints twice).
				$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
				$summary  = (string) $shared['summary'];
				if ( '' === $summary || ! self::response_starts_with_summary( $response, $summary ) ) {
					$message .= "\n" . $esc( $summary );
				}

				if ( '' !== $response ) {
					$message .= "\n\n" . $esc( '---' ) . "\n\n";
					/* translators: heading for the main result output in chat messages */
					$message .= $esc( __( 'Results', 'mcp-ai-wpoos-pro' ) ) . ":\n";
					$message .= $esc( $response );
				}

				// Strip duplicate/internal keys before rendering the data
				// section (see delivery_safe_data()) so the report does not
				// repeat the response or end with assistant_id / is_agentic
				// metadata as a footer.
				$data_text = self::envelope_data_to_delivery_text( isset( $envelope['data'] ) ? $envelope['data'] : array() );
				if ( '' !== trim( $data_text ) ) {
					$message .= "\n\n" . $esc( '---' ) . "\n\n";
					$message .= $esc( $data_text );
				}
			} elseif ( 'response_only' === $template ) {
				// Deliver only the substantive AI/tool response.
				$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
				if ( '' !== $response ) {
					$message .= "\n" . $esc( $response );
				} else {
					$message .= "\n" . $esc( $shared['summary'] );
				}
			} elseif ( 'action_items' === $template ) {
				// Action items only: forward the actionable section of the
				// response when one exists — roundup intros and informational
				// filler are noise on a chat channel. Falls back to the
				// summary rendering when the response carries no action
				// section.
				$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
				$block    = self::extract_action_items( $response );
				if ( '' !== $block ) {
					$message .= "\n\n\u{1F3AF} " . $bold( $esc( __( 'Action items', 'mcp-ai-wpoos-pro' ) ) ) . "\n";
					$message .= $esc( $block );
				} else {
					$summary = (string) $shared['summary'];
					$is_dup  = '' !== $response && '' !== $summary && self::response_starts_with_summary( $response, $summary );
					if ( ! $is_dup && '' !== $summary ) {
						$message .= "\n" . $esc( wp_trim_words( $summary, 60, '…' ) );
					}
					if ( '' !== $response ) {
						$message .= "\n\n\u{1F4CB} " . $esc( self::select_representative_excerpt( $response, 80 ) );
					}
				}
			} else {
				// Summary template: summary line plus a response excerpt below.
				// Assistant-run summaries are a trim of the response's first
				// words, so when the response already opens with the summary
				// the excerpt subsumes the summary line — skip the standalone
				// line to avoid printing the same text twice.
				$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
				$summary  = (string) $shared['summary'];
				$is_dup   = '' !== $response && '' !== $summary && self::response_starts_with_summary( $response, $summary );
				if ( ! $is_dup && '' !== $summary ) {
					$truncated = wp_trim_words( $summary, 60, '…' );
					$message  .= "\n" . $esc( $truncated );
				}
			}

			// Include a response excerpt when available — this is the substantive
			// output the schedule produced and is what recipients actually want.
			// The excerpt is the most representative block of the response (a
			// distillation/action section, or centroid-ranked sentences) rather
			// than a blind trim of the first words. Only appended in summary
			// mode; response_only already includes the full response, full
			// includes it above, and action_items appends its own block (or
			// falls back to the summary rendering inline).
			if ( 'full' !== $template && 'response_only' !== $template && 'error' !== $template && 'action_items' !== $template ) {
				$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
				if ( '' !== $response ) {
					$excerpt  = self::select_representative_excerpt( $response, 80 );
					$message .= "\n\n\u{1F4CB} " . $esc( $excerpt );
				}
			}

			return array(
				'message'    => $message,
				'parse_mode' => self::telegram_parse_mode( $format ),
			);
		}

		/**
		 * Format for SMS delivery (160-char GSM-7 limit).
		 *
		 * @param array  $shared Common formatted fields.
		 * @param string $template Template mode.
		 * @return array SMS payload.
		 */
		protected static function format_sms( array $shared, $template ) {
			$is_error = 'error' === $template;
			$prefix   = $is_error ? "\u{26A0} " : "\u{2705} ";
			$name     = mb_substr( $shared['schedule_name'], 0, 40 );
			$summary  = $is_error
				? mb_substr( $shared['summary'], 0, 100 )
				: wp_trim_words( $shared['summary'], 10, '…' );

			$message = $prefix . $name;

			// Append a response excerpt when available and not an error. When
			// the response already opens with the summary (assistant-run
			// summaries are a trim of the response's first words) the excerpt
			// subsumes the summary, so only the excerpt is sent to avoid
			// printing the same text twice.
			$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
			if ( ! $is_error && '' !== $response ) {
				$excerpt = wp_trim_words( $response, 12, '…' );
				if ( '' !== (string) $shared['summary'] && '' !== $summary && ! self::response_starts_with_summary( $response, (string) $shared['summary'] ) ) {
					$message .= ': ' . $summary . ' - ' . $excerpt;
				} else {
					$message .= ': ' . $excerpt;
				}
			} elseif ( '' !== $summary ) {
				$message .= ': ' . $summary;
			}

			// Truncate to ~160 chars (GSM-7 safe).
			if ( function_exists( 'mb_strlen' ) && mb_strlen( $message ) > 155 ) {
				$message = mb_substr( $message, 0, 152 ) . '…';
			} elseif ( strlen( $message ) > 155 ) {
				$message = substr( $message, 0, 152 ) . '…';
			}

			return array(
				'message' => $message,
			);
		}

		/**
		 * Format for Paper Store record.
		 *
		 * @param array $shared   Common formatted fields.
		 * @param array $envelope Full envelope.
		 * @param array $schedule Schedule record.
		 * @return array Paper Store payload.
		 */
		protected static function format_paper_store( array $shared, array $envelope, array $schedule ) {
			$record_id = sanitize_key(
				( isset( $schedule['id'] ) ? $schedule['id'] : 'schedule' )
				. '-' . gmdate( 'Y-m-d-His', $shared['generated_at'] )
			);

			$tags = isset( $schedule['tags'] ) && is_array( $schedule['tags'] )
				? $schedule['tags']
				: array();

			return array(
				'id'           => $record_id,
				'type'         => 'scheduled-research',
				'title'        => $shared['schedule_name'] . ' — ' . gmdate( 'Y-m-d', $shared['generated_at'] ),
				'description'  => isset( $schedule['description'] ) ? (string) $schedule['description'] : '',
				'schedule_id'  => isset( $schedule['id'] ) ? (string) $schedule['id'] : '',
				'generated_at' => $shared['generated_at'],
				'summary'      => $shared['summary'],
				'tags'         => $tags,
				'status'       => 'published',
				'body'         => array(
					'markdown' => self::envelope_to_markdown( $shared, $envelope, $schedule ),
					'json'     => $envelope,
				),
			);
		}

		/**
		 * Format for WordPress post auto-creation.
		 *
		 * @param array $shared   Common formatted fields.
		 * @param array $envelope Full envelope.
		 * @param array $schedule Schedule record.
		 * @return array WordPress post payload.
		 */
		protected static function format_wordpress_post( array $shared, array $envelope, array $schedule ) {
			$post_title   = $shared['schedule_name'] . ' — ' . gmdate( 'Y-m-d', $shared['generated_at'] );
			$post_content = self::envelope_to_markdown( $shared, $envelope, $schedule );

			// Convert markdown headings to HTML paragraphs for wp_insert_post.
			// A proper markdown→HTML conversion would use a library; simple
			// newline→<br> for now — integrators can filter.
			$post_content_html = wpautop( esc_html( $post_content ) );

			return array(
				'post_title'   => $post_title,
				'post_content' => $post_content_html,
				'post_excerpt' => wp_trim_words( $shared['summary'], 30, '…' ),
			);
		}

		/**
		 * Format for webhook delivery.
		 *
		 * @param array               $shared     Common formatted fields.
		 * @param array               $envelope   Full envelope.
		 * @param array               $schedule   Schedule record.
		 * @param array<string,mixed> $action_log Action log.
		 * @return array Webhook payload.
		 */
		protected static function format_webhook( array $shared, array $envelope, array $schedule, array $action_log ) {
			return array(
				'event'         => $shared['is_success'] ? 'schedule.run.success' : 'schedule.run.failure',
				'schedule_id'   => isset( $schedule['id'] ) ? $schedule['id'] : '',
				'schedule_name' => $shared['schedule_name'],
				'schedule_type' => $shared['schedule_type'],
				'status'        => $shared['status'],
				'summary'       => $shared['summary'],
				'response'      => isset( $shared['response'] ) ? (string) $shared['response'] : '',
				'action_log'    => $action_log,
				'timestamp'     => gmdate( 'c', $shared['generated_at'] ),
				'site_url'      => home_url(),
			);
		}

		// -------------------------------------------------------------------------
		// Credential resolution
		// -------------------------------------------------------------------------

		/**
		 * Resolve credentials for a delivery channel using a four-tier fallback.
		 *
		 * Priority:
		 *   1. connection_id → Remote Sites stored connection
		 *   2. Inline {channel}_credentials in the channel config
		 *   3. Chat Channels Toolkit global settings (via filter)
		 *   4. First enabled Remote Sites connection of this channel's type
		 *      (preferring one the schedule's assistant is assigned to)
		 *
		 * Tier 4 exists so schedules configured without an explicit credential
		 * reference still deliver — the bot token lives on the Remote Sites
		 * connection that also powers interactive chat, so reusing it is
		 * predictable and avoids credential duplication.
		 *
		 * @since 1.0.0
		 *
		 * @param string $channel  Channel slug (slack, telegram, etc.).
		 * @param array  $config   Channel config from schedule['result_delivery'].
		 * @param array  $schedule Schedule record (for assistant-scoped preference).
		 * @return array Empty array if no credentials resolved, or credential map keyed by channel.
		 */
		protected static function resolve_channel_credentials( $channel, array $config, array $schedule = array() ) {
			// 1. Try Remote Sites connection reference.
			if ( ! empty( $config['connection_id'] ) ) {
				if ( class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
					$connection = WP_MCP_AI_Pro_Remote_Site_Manager::get_connection( $config['connection_id'] );
					if ( is_array( $connection ) && ! empty( $connection ) ) {
						$creds = self::extract_credentials_from_connection( $channel, $connection );
						if ( ! empty( $creds ) ) {
							$creds = self::merge_channel_destination_fields( $channel, $creds, $config );
							if ( ! empty( $creds ) ) {
								return $creds;
							}
						}
					}
				}
			}

			// 2. Try inline credentials stored under the canonical key.
			if ( isset( $config[ $channel . '_credentials' ] ) ) {
				$inline = self::normalize_channel_credentials( $config[ $channel . '_credentials' ] );
				if ( ! empty( $inline ) ) {
					return $inline;
				}
			}

			// 3. Allow integrators to supply global defaults.
			$defaults = apply_filters( 'wp_mcp_ai_delivery_channel_default_credentials', array(), $channel, $config );
			if ( ! empty( $defaults ) ) {
				return $defaults;
			}

			// 4. Fall back to an enabled Remote Sites connection of this
			// channel's type. Prefer the connection the schedule's assistant
			// is assigned to; otherwise use the first enabled match.
			$conn_type = self::get_channel_connection_type( $channel );
			if ( '' !== $conn_type && class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
				$assistant_id   = isset( $schedule['assistant_config']['assistant_id'] ) ? absint( $schedule['assistant_config']['assistant_id'] ) : 0;
				$fallback_creds = null;

				foreach ( WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections() as $connection ) {
					if ( ! is_array( $connection ) || empty( $connection['enabled'] ) ) {
						continue;
					}

					$stored_type = isset( $connection['connection_type'] ) ? sanitize_key( (string) $connection['connection_type'] ) : '';
					if ( $stored_type !== $conn_type ) {
						continue;
					}

					$creds = self::extract_credentials_from_connection( $channel, $connection );
					if ( empty( $creds ) ) {
						continue;
					}

					// Prefer the connection the schedule's assistant is assigned to.
					if ( $assistant_id > 0 && ! empty( $connection['assigned_assistant_ids'] ) && is_array( $connection['assigned_assistant_ids'] ) ) {
						$assigned = array_map( 'absint', $connection['assigned_assistant_ids'] );
						if ( in_array( $assistant_id, $assigned, true ) ) {
							return self::merge_channel_destination_fields( $channel, $creds, $config );
						}
					}

					if ( null === $fallback_creds ) {
						$fallback_creds = $creds;
					}
				}

				if ( null !== $fallback_creds ) {
					return self::merge_channel_destination_fields( $channel, $fallback_creds, $config );
				}
			}

			return array();
		}

		/**
		 * Map a delivery channel slug to its Remote Sites connection type.
		 *
		 * Chat channels are stored under slightly different type keys in the
		 * Remote Site Manager (e.g. messenger → facebook_messenger, teams →
		 * microsoft_teams), so a single mapping is shared by credential
		 * resolution and diagnostics.
		 *
		 * @since 1.1.75
		 *
		 * @param string $channel Delivery channel slug.
		 * @return string Remote Sites connection type, or empty string when the
		 *                channel has no Remote Sites equivalent.
		 */
		protected static function get_channel_connection_type( $channel ) {
			$map = array(
				'telegram'    => 'telegram',
				'slack'       => 'slack',
				'discord'     => 'discord',
				'teams'       => 'microsoft_teams',
				'messenger'   => 'facebook_messenger',
				'whatsapp'    => 'whatsapp',
				'google_chat' => 'google_chat',
			);

			return isset( $map[ $channel ] ) ? $map[ $channel ] : '';
		}

		/**
		 * Extract delivery credentials from a Remote Sites connection record.
		 *
		 * Maps the real Remote Sites storage schema to the per-channel shape
		 * expected by unified_channel_broadcast. Tokens are stored encrypted
		 * under `api_key` (Slack, Discord, Telegram, Messenger, WhatsApp) or
		 * `token` (Microsoft Teams), so they are decrypted here. Destination
		 * fields (chat/channel IDs) live on the schedule's channel config and
		 * are merged in by {@see merge_channel_destination_fields()}.
		 *
		 * @since 1.0.0
		 *
		 * @param string $channel    Channel slug.
		 * @param array  $connection Remote Sites connection record.
		 * @return array Credential map for this channel, or empty array.
		 */
		protected static function extract_credentials_from_connection( $channel, array $connection ) {
			$decrypt = function ( $key ) use ( $connection ) {
				if ( empty( $connection[ $key ] ) ) {
					return '';
				}

				// decrypt_value() returns plaintext values untouched, so this is
				// safe for both encrypted records and legacy plaintext ones.
				return WP_MCP_AI_Pro_Remote_Site_Manager::decrypt_value( (string) $connection[ $key ] );
			};

			$map = array(
				'slack'     => array(
					'token' => $decrypt( 'api_key' ),
				),
				'telegram'  => array(
					'token' => $decrypt( 'api_key' ),
				),
				'discord'   => array(
					'token' => $decrypt( 'api_key' ),
				),
				'teams'     => array(
					'token' => $decrypt( 'token' ),
				),
				'messenger' => array(
					'access_token' => $decrypt( 'api_key' ),
				),
				'whatsapp'  => array(
					'access_token'    => $decrypt( 'api_key' ),
					'phone_number_id' => isset( $connection['phone_number_id'] ) ? (string) $connection['phone_number_id'] : '',
				),
			);

			if ( isset( $map[ $channel ] ) ) {
				$filtered = array_filter(
					$map[ $channel ],
					function ( $v ) {
						return '' !== $v;
					}
				);
				if ( ! empty( $filtered ) ) {
					return $filtered;
				}
			}

			return array();
		}

		/**
		 * Merge per-channel destination fields from the channel config into
		 * credentials resolved from a Remote Sites connection.
		 *
		 * Connections store the secret (token) but not the delivery destination,
		 * which the user supplies per-schedule (e.g. the Telegram `chat_id`
		 * field in the Schedule Manager edit modal).
		 *
		 * @since 1.0.0
		 *
		 * @param string $channel Channel slug.
		 * @param array  $creds   Credentials resolved from the connection.
		 * @param array  $config  Channel config from schedule['result_delivery'].
		 * @return array Merged credential map.
		 */
		protected static function merge_channel_destination_fields( $channel, array $creds, array $config ) {
			$fields = array(
				'telegram'  => array( 'chat_id' ),
				'slack'     => array( 'channel' ),
				'discord'   => array( 'channel_id' ),
				'teams'     => array( 'team_id', 'channel_id' ),
				'messenger' => array( 'recipient_id' ),
				'whatsapp'  => array( 'to' ),
			);

			if ( ! isset( $fields[ $channel ] ) ) {
				return $creds;
			}

			foreach ( $fields[ $channel ] as $field ) {
				if ( empty( $creds[ $field ] ) && ! empty( $config[ $field ] ) ) {
					$creds[ $field ] = sanitize_text_field( $config[ $field ] );
				}
			}

			return $creds;
		}

		// -------------------------------------------------------------------------
		// Senders — payload → channel API
		// -------------------------------------------------------------------------

		/**
		 * Send a formatted payload to the appropriate channel backend.
		 *
		 * @param string $channel  Channel slug.
		 * @param array  $payload  Formatted payload.
		 * @param array  $config   Channel config from schedule['result_delivery'].
		 * @param array  $schedule Schedule record (for assistant-scoped credential fallback).
		 * @return true|WP_Error True on success, WP_Error on failure.
		 */
		protected static function send_to_channel( $channel, array $payload, array $config, array $schedule = array() ) {
			switch ( $channel ) {
				case 'email':
					return self::send_email( $payload, $config );

				case 'sms':
					return self::send_sms( $payload, $config );

				case 'paper_store':
					return self::send_paper_store( $payload, $config );

				case 'WordPress':
					return self::send_wordpress_post( $payload, $config );

				case 'webhook':
					return self::send_webhook( $payload, $config );

				// Chat channels route through unified_channel_broadcast.
				case 'slack':
				case 'telegram':
				case 'discord':
				case 'teams':
				case 'messenger':
				case 'whatsapp':
				case 'google_chat':
					return self::send_chat( $channel, $payload, $config, $schedule );

				default:
					return new WP_Error(
						'unsupported_channel',
						/* translators: %s: channel slug */
						sprintf( __( 'Delivery channel "%s" is not supported.', 'mcp-ai-wpoos-pro' ), $channel )
					);
			}
		}

		/**
		 * Send email via Nodemailer (preferred) or wp_mail fallback.
		 *
		 * Honours the channel's `format` setting (EMAIL_FORMATS):
		 * - `both` (default): HTML body + text/plain Markdown alternative.
		 * - `html`: HTML body only.
		 * - `markdown`: text/plain Markdown only.
		 *
		 * @param array $payload Formatted email payload (subject, plain, html_body).
		 * @param array $config  Channel config ('to' may hold one or more comma-separated recipients; optional 'format').
		 * @return true|WP_Error
		 */
		protected static function send_email( array $payload, array $config ) {
			$to = self::sanitize_email_recipients( isset( $config['to'] ) ? $config['to'] : '' );
			if ( '' === $to ) {
				return new WP_Error( 'missing_email_recipient', __( 'No email recipient configured.', 'mcp-ai-wpoos-pro' ) );
			}

			$subject = isset( $payload['subject'] ) ? (string) $payload['subject'] : __( 'Schedule Result', 'mcp-ai-wpoos-pro' );
			$plain   = isset( $payload['plain'] ) ? (string) $payload['plain'] : '';
			$format  = self::resolve_email_format( $config );

			// Build the HTML body (MJML when available) for html/both formats.
			$html = 'markdown' === $format ? '' : self::build_email_html( $payload );

			// Try Nodemailer first. Supplying both html and text lets it emit
			// a multipart/alternative message (the industry-standard shape).
			if ( class_exists( 'WP_MCP_AI_Nodemailer_Service' ) ) {
				$nodemailer = new WP_MCP_AI_Nodemailer_Service();
				if ( $nodemailer->is_available() ) {
					$email_args = array(
						'to'      => $to,
						'subject' => $subject,
					);
					if ( 'markdown' !== $format && '' !== $html ) {
						$email_args['html'] = $html;
					}
					if ( 'html' !== $format && '' !== $plain ) {
						$email_args['text'] = $plain;
					}

					$result = $nodemailer->send_email( $email_args );
					if ( ! is_wp_error( $result ) ) {
						return true;
					}
					// Fall through to wp_mail on failure.
				}
			}

			// wp_mail fallback. wp_mail has no built-in multipart/alternative
			// support, so send a single body per the selected format.
			if ( 'markdown' === $format ) {
				$sent = wp_mail(
					$to,
					$subject,
					$plain,
					array( 'Content-Type: text/plain; charset=UTF-8' )
				);
			} else {
				$sent = wp_mail(
					$to,
					$subject,
					$html,
					array( 'Content-Type: text/html; charset=UTF-8' )
				);
			}

			return $sent ? true : new WP_Error( 'wp_mail_failed', __( 'wp_mail() returned false.', 'mcp-ai-wpoos-pro' ) );
		}

		/**
		 * Resolve the email presentation format from a channel config.
		 *
		 * Defaults to `both` so existing schedules (saved without a format
		 * field) immediately benefit from properly rendered HTML emails with a
		 * plain-text fallback.
		 *
		 * @param array $config Channel config from schedule['result_delivery'].
		 * @return string One of self::EMAIL_FORMATS.
		 */
		protected static function resolve_email_format( array $config ) {
			return isset( $config['format'] ) && in_array( $config['format'], self::EMAIL_FORMATS, true )
				? $config['format']
				: 'both';
		}

		/**
		 * Normalize a recipient field into a comma-separated list of valid emails.
		 *
		 * Accepts a single address, a comma/semicolon/whitespace-separated list,
		 * or an array of addresses (defensive — presets and MCP tools may pass
		 * either shape). Each token is sanitized individually and empty tokens
		 * are dropped so wp_mail() and Nodemailer receive a clean recipient
		 * list. Duplicates are removed to avoid double delivery.
		 *
		 * @since 1.1.81
		 *
		 * @param string|array $value Raw recipient value.
		 * @return string Comma-separated sanitized list, empty when nothing valid remains.
		 */
		public static function sanitize_email_recipients( $value ) {
			if ( is_array( $value ) ) {
				$value = implode( ',', $value );
			}

			$value = (string) $value;
			if ( '' === trim( $value ) ) {
				return '';
			}

			$tokens = preg_split( '/[\s,;]+/', $value );
			$emails = array();
			if ( is_array( $tokens ) ) {
				foreach ( $tokens as $token ) {
					$email = sanitize_email( trim( $token ) );
					if ( '' !== $email ) {
						$emails[] = $email;
					}
				}
			}

			return implode( ', ', array_unique( $emails ) );
		}

		/**
		 * Normalize channel credentials into the array shape expected by the
		 * unified_channel_broadcast tool.
		 *
		 * The Schedule Manager edit modal stores inline credentials as raw
		 * strings (e.g. a JSON literal or a bare bot token). Passing those
		 * through to the broadcast tool triggers a TypeError because its
		 * per-channel credentials parameter is type-hinted as an array. This
		 * helper coerces JSON strings into arrays and rejects any other
		 * non-array value with an empty array so callers fail gracefully with
		 * a descriptive error instead of a fatal.
		 *
		 * @since 1.0.0
		 *
		 * @param mixed $raw Raw credentials value from a channel config.
		 * @return array Credential map, empty when the value is not a valid array.
		 */
		protected static function normalize_channel_credentials( $raw ) {
			if ( is_array( $raw ) ) {
				return $raw;
			}

			if ( is_string( $raw ) && '' !== trim( $raw ) ) {
				$decoded = json_decode( $raw, true );
				if ( is_array( $decoded ) ) {
					return $decoded;
				}
			}

			return array();
		}

		/**
		 * Send a message to chat channels via unified_channel_broadcast tool.
		 *
		 * @param string $channel  Channel slug (slack, telegram, etc.).
		 * @param array  $payload  Formatted chat payload (must contain 'message').
		 * @param array  $config   Channel config.
		 * @param array  $schedule Schedule record (for credential fallback and user context).
		 * @return true|WP_Error
		 */
		protected static function send_chat( $channel, array $payload, array $config, array $schedule = array() ) {
			if ( ! class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
				return new WP_Error( 'no_tool_registry', __( 'Tool registry not available.', 'mcp-ai-wpoos-pro' ) );
			}

			$message = isset( $payload['message'] ) ? (string) $payload['message'] : '';

			/*
			 * Resolve credentials using four-tier fallback:
			 *   1. connection_id → Remote Sites connection.
			 *   2. Inline {channel}_credentials in config.
			 *   3. Chat Channels Toolkit global settings (via filter).
			 *   4. First enabled Remote Sites connection of this channel's type.
			 */
			$credentials = array();
			$resolved    = self::resolve_channel_credentials( $channel, $config, $schedule );
			if ( ! empty( $resolved ) ) {
				$credentials[ $channel ] = self::normalize_channel_credentials( $resolved );
			} elseif ( isset( $config['credentials'] ) ) {
				$credentials[ $channel ] = self::normalize_channel_credentials( $config['credentials'] );
			} elseif ( isset( $config[ $channel . '_credentials' ] ) ) {
				$credentials[ $channel ] = self::normalize_channel_credentials( $config[ $channel . '_credentials' ] );
			}

			if ( empty( $credentials[ $channel ] ) ) {
				return new WP_Error(
					'missing_channel_credentials',
					sprintf(
						/* translators: %s: channel name */
						__( 'No valid credentials found for the %s channel.', 'mcp-ai-wpoos-pro' ),
						$channel
					),
					self::build_credential_diagnostics( $channel, $config )
				);
			}

			if ( 'telegram' === $channel ) {
				$telegram_creds = $credentials[ $channel ];
				if ( empty( $telegram_creds['token'] ) || empty( $telegram_creds['chat_id'] ) ) {
					return new WP_Error(
						'missing_telegram_credentials',
						__( 'Token and chat_id are required for Telegram delivery.', 'mcp-ai-wpoos-pro' )
					);
				}
				return self::send_telegram_direct( $payload, $telegram_creds, $schedule );
			}

			$tool = WP_MCP_AI_Tool_Registry::get_instance()->get_tool( 'unified_channel_broadcast' );
			if ( ! $tool ) {
				return new WP_Error( 'no_broadcast_tool', __( 'Unified channel broadcast tool not available.', 'mcp-ai-wpoos-pro' ) );
			}

			$result = $tool->execute(
				array(
					'message'     => $message,
					'channels'    => array( $channel ),
					'credentials' => $credentials,
				),
				array(
					'source'  => 'pro_schedule_manager_result_delivery',
					'user_id' => isset( $schedule['created_by'] ) ? absint( $schedule['created_by'] ) : 0,
				)
			);

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			// Check partial failure.
			if ( is_array( $result ) && isset( $result['summary']['successful_channels'] ) ) {
				if ( 0 === (int) $result['summary']['successful_channels'] ) {
					return new WP_Error(
						'broadcast_failed',
						/* translators: %s: channel name */
						sprintf( __( 'Failed to deliver to %s.', 'mcp-ai-wpoos-pro' ), $channel )
					);
				}
			}

			return true;
		}

		/**
		 * Send a Telegram message directly via the dedicated tool.
		 *
		 * Keeps the selected parse_mode (HTML / Markdown / MarkdownV2) intact,
		 * which the unified broadcast path cannot do because it sanitizes
		 * messages to plain text. Uses the same acting-user context as
		 * {@see send_chat()} so the capability waiver applies.
		 *
		 * @param array $payload Formatted chat payload (message + parse_mode).
		 * @param array $creds   Resolved Telegram credentials (token + chat_id).
		 * @param array $schedule Schedule record (for acting-user context).
		 * @return true|WP_Error
		 */
		protected static function send_telegram_direct( array $payload, array $creds, array $schedule = array() ) {
			if ( ! class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
				return new WP_Error( 'no_tool_registry', __( 'Tool registry not available.', 'mcp-ai-wpoos-pro' ) );
			}

			$tool = WP_MCP_AI_Tool_Registry::get_instance()->get_tool( 'send_telegram_message' );
			if ( ! $tool ) {
				return new WP_Error( 'no_telegram_tool', __( 'Telegram message tool not available.', 'mcp-ai-wpoos-pro' ) );
			}

			$args = array(
				'token'   => $creds['token'],
				'chat_id' => $creds['chat_id'],
				'text'    => isset( $payload['message'] ) ? (string) $payload['message'] : '',
			);

			$parse_mode = isset( $payload['parse_mode'] ) ? (string) $payload['parse_mode'] : '';
			if ( '' !== $parse_mode && in_array( $parse_mode, array( 'HTML', 'Markdown', 'MarkdownV2' ), true ) ) {
				$args['parse_mode'] = $parse_mode;
			}

			return $tool->execute(
				$args,
				array(
					'source'  => 'pro_schedule_manager_result_delivery',
					'user_id' => isset( $schedule['created_by'] ) ? absint( $schedule['created_by'] ) : 0,
				)
			);
		}

		/**
		 * Build diagnostics describing why a channel's credentials did not resolve.
		 *
		 * Attached as WP_Error data so the delivery warning log tells the admin
		 * exactly which tier failed and whether a usable Remote Sites connection
		 * exists at all. Never contains secret material.
		 *
		 * @since 1.1.75
		 *
		 * @param string $channel Channel slug.
		 * @param array  $config  Channel config from schedule['result_delivery'].
		 * @return array<string,mixed> Diagnostic map.
		 */
		protected static function build_credential_diagnostics( $channel, array $config ) {
			$diagnostics = array(
				'channel'                      => $channel,
				'connection_id'                => isset( $config['connection_id'] ) ? sanitize_text_field( (string) $config['connection_id'] ) : '',
				'has_inline_credentials'       => ! empty( $config[ $channel . '_credentials' ] ) || ! empty( $config['credentials'] ),
				'has_destination_field'        => isset( $config['chat_id'] ) ? ! empty( $config['chat_id'] ) : false,
				'matching_connections'         => 0,
				'enabled_matching_connections' => 0,
			);

			$conn_type = self::get_channel_connection_type( $channel );
			if ( '' !== $conn_type && class_exists( 'WP_MCP_AI_Pro_Remote_Site_Manager' ) ) {
				foreach ( WP_MCP_AI_Pro_Remote_Site_Manager::get_all_connections() as $connection ) {
					if ( ! is_array( $connection ) ) {
						continue;
					}

					$stored_type = isset( $connection['connection_type'] ) ? sanitize_key( (string) $connection['connection_type'] ) : '';
					if ( $stored_type !== $conn_type ) {
						continue;
					}

					++$diagnostics['matching_connections'];
					if ( ! empty( $connection['enabled'] ) && ! empty( $connection['api_key'] ) ) {
						++$diagnostics['enabled_matching_connections'];
					}
				}
			}

			return $diagnostics;
		}

		/**
		 * Send SMS via the schedule_notify_sms tool.
		 *
		 * @param array $payload Formatted SMS payload (must contain 'message').
		 * @param array $config  Channel config (must contain 'to').
		 * @return true|WP_Error
		 */
		protected static function send_sms( array $payload, array $config ) {
			$to = isset( $config['to'] ) ? (string) $config['to'] : '';
			if ( '' === $to ) {
				return new WP_Error( 'missing_sms_recipient', __( 'No SMS recipient configured.', 'mcp-ai-wpoos-pro' ) );
			}

			$message = isset( $payload['message'] ) ? (string) $payload['message'] : '';

			if ( class_exists( 'WP_MCP_AI_Tool_Registry' ) ) {
				$tool = WP_MCP_AI_Tool_Registry::get_instance()->get_tool( 'schedule_notify_sms' );
				if ( $tool ) {
					$result = $tool->execute(
						array(
							'to'      => $to,
							'message' => $message,
						),
						array( 'source' => 'pro_schedule_manager_result_delivery' )
					);
					return is_wp_error( $result ) ? $result : true;
				}
			}

			return new WP_Error( 'sms_tool_unavailable', __( 'SMS notification tool is not available.', 'mcp-ai-wpoos-pro' ) );
		}

		/**
		 * Write a record to the Paper Store.
		 *
		 * @param array $payload Formatted Paper Store payload.
		 * @param array $config  Channel config (collection, driver, retention, git_commit).
		 * @return true|WP_Error
		 */
		protected static function send_paper_store( array $payload, array $config ) {
			if ( ! class_exists( 'WP_MCP_AI_Paper_Store_Manager' ) ) {
				return new WP_Error( 'paper_store_unavailable', __( 'Paper Store is not available.', 'mcp-ai-wpoos-pro' ) );
			}

			$collection = isset( $config['collection'] ) ? sanitize_key( $config['collection'] ) : 'schedule-results';
			if ( '' === $collection ) {
				return new WP_Error( 'missing_paper_collection', __( 'No Paper Store collection configured.', 'mcp-ai-wpoos-pro' ) );
			}

			try {
				$store      = WP_MCP_AI_Paper_Store_Manager::get_instance();
				$repository = $store->get_repository( $collection );

				// Enforce retention: trim oldest records beyond the configured limit.
				$retention = isset( $config['retention'] ) ? (int) $config['retention'] : 0;
				if ( $retention > 0 ) {
					$all = $repository->all();
					if ( is_array( $all ) && count( $all ) >= $retention ) {
						// Sort by generated_at descending, keep newest $retention - 1.
						usort(
							$all,
							function ( $a, $b ) {
								$ta = isset( $a['generated_at'] ) ? (int) $a['generated_at'] : 0;
								$tb = isset( $b['generated_at'] ) ? (int) $b['generated_at'] : 0;
								return $tb - $ta;
							}
						);
						$to_remove = array_slice( $all, $retention - 1 );
						foreach ( $to_remove as $old ) {
							if ( isset( $old['id'] ) ) {
								$repository->delete( $old['id'] );
							}
						}
					}
				}

				$saved = $repository->save( $payload );
				if ( is_wp_error( $saved ) ) {
					return $saved;
				}

				// Trigger Git auto-commit when configured and the Pro driver supports it.
				// WP_MCP_AI_Paper_Git_Sync exposes sync() (maybe_commit() never existed;
				// the previous call fataled inside the catch below and masked every
				// paper_store delivery as failed). Sync failures are logged, never
				// allowed to fail the delivery — the record is already saved.
				if ( ! empty( $config['git_commit'] ) && class_exists( 'WP_MCP_AI_Paper_Git_Sync' ) ) {
					$git_sync = WP_MCP_AI_Paper_Git_Sync::get_instance()->sync();
					if ( is_wp_error( $git_sync ) && class_exists( 'WP_MCP_AI_Logger' ) ) {
						WP_MCP_AI_Logger::log_event(
							'error',
							sprintf(
								/* translators: %s: error message */
								__( 'Paper Store git auto-commit failed: %s', 'mcp-ai-wpoos-pro' ),
								$git_sync->get_error_message()
							)
						);
					}
				}

				return true;
			} catch ( Throwable $e ) {
				return new WP_Error(
					'paper_store_error',
					sprintf(
						/* translators: %s: error message */
						__( 'Paper Store write failed: %s', 'mcp-ai-wpoos-pro' ),
						$e->getMessage()
					)
				);
			}
		}

		/**
		 * Auto-create a WordPress post from the result.
		 *
		 * @param array $payload Formatted WordPress post payload.
		 * @param array $config  Channel config (post_type, post_status, category).
		 * @return true|WP_Error
		 */
		protected static function send_wordpress_post( array $payload, array $config ) {
			$post_type   = isset( $config['post_type'] ) ? sanitize_key( $config['post_type'] ) : 'post';
			$post_status = isset( $config['post_status'] ) ? sanitize_key( $config['post_status'] ) : 'draft';
			$category    = isset( $config['category'] ) ? absint( $config['category'] ) : 0;

			// Validate post type.
			if ( ! post_type_exists( $post_type ) ) {
				return new WP_Error(
					'invalid_post_type',
					/* translators: %s: post type slug */
					sprintf( __( 'Post type "%s" does not exist.', 'mcp-ai-wpoos-pro' ), $post_type )
				);
			}

			$post_data = array(
				'post_title'   => isset( $payload['post_title'] ) ? (string) $payload['post_title'] : '',
				'post_content' => isset( $payload['post_content'] ) ? (string) $payload['post_content'] : '',
				'post_excerpt' => isset( $payload['post_excerpt'] ) ? (string) $payload['post_excerpt'] : '',
				'post_type'    => $post_type,
				'post_status'  => $post_status,
			);

			if ( $category > 0 ) {
				$post_data['post_category'] = array( $category );
			}

			$post_id = wp_insert_post( $post_data, true );

			if ( is_wp_error( $post_id ) ) {
				return $post_id;
			}

			// Set featured image if provided in the payload.
			if ( ! empty( $payload['featured_image_id'] ) ) {
				$thumbnail_id = absint( $payload['featured_image_id'] );
				if ( $thumbnail_id > 0 && wp_attachment_is_image( $thumbnail_id ) ) {
					set_post_thumbnail( $post_id, $thumbnail_id );
				}
			}

			// Auto-generate featured image if configured.
			if ( ! empty( $config['generate_featured_image'] ) && class_exists( 'WP_MCP_AI_Featured_Image_Service' ) ) {
				$image_style  = isset( $config['image_style'] ) ? sanitize_key( $config['image_style'] ) : 'photographic';
				$image_result = WP_MCP_AI_Featured_Image_Service::generate(
					$post_data['post_title'],
					'blog post',
					array( 'style' => $image_style )
				);
				if ( ! is_wp_error( $image_result ) ) {
					set_post_thumbnail( $post_id, $image_result['attachment_id'] );
				}
			}

			return true;
		}

		/**
		 * POST result to an external webhook URL.
		 *
		 * @param array $payload Webhook payload.
		 * @param array $config  Channel config (url, secret).
		 * @return true|WP_Error
		 */
		protected static function send_webhook( array $payload, array $config ) {
			$url = isset( $config['url'] ) ? esc_url_raw( $config['url'] ) : '';
			if ( '' === $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
				return new WP_Error( 'invalid_webhook_url', __( 'Invalid webhook URL.', 'mcp-ai-wpoos-pro' ) );
			}

			$body    = wp_json_encode( $payload );
			$headers = array( 'Content-Type' => 'application/json' );

			$secret = isset( $config['secret'] ) ? (string) $config['secret'] : '';
			if ( '' !== $secret ) {
				$ts                               = (string) time();
				$headers['X-WP-MCP-AI-Timestamp'] = $ts;
				$headers['X-WP-MCP-AI-Signature'] = 'sha256=' . hash_hmac( 'sha256', $ts . '.' . $body, $secret );
			}

			$response = wp_remote_post(
				$url,
				array(
					'body'    => $body,
					'headers' => $headers,
					'timeout' => 15,
				)
			);

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$code = wp_remote_retrieve_response_code( $response );
			if ( $code < 200 || $code >= 300 ) {
				return new WP_Error(
					'webhook_http_error',
					/* translators: %d: HTTP status code */
					sprintf( __( 'Webhook returned HTTP %d.', 'mcp-ai-wpoos-pro' ), $code )
				);
			}

			return true;
		}

		// -------------------------------------------------------------------------
		// Logging
		// -------------------------------------------------------------------------

		/**
		 * Log a per-channel delivery attempt and fire an action hook.
		 *
		 * @param string        $schedule_id Schedule identifier.
		 * @param string        $channel     Channel slug.
		 * @param true|WP_Error $result    Delivery result.
		 * @param bool          $is_success  Whether this was a success or failure delivery.
		 * @return array Status array with channel, success, and error keys.
		 */
		protected static function log_delivery( $schedule_id, $channel, $result, $is_success ) {
			$is_ok  = true === $result || ! is_wp_error( $result );
			$status = array(
				'channel'    => $channel,
				'success'    => $is_ok,
				'error'      => is_wp_error( $result ) ? $result->get_error_message() : '',
				'error_data' => is_wp_error( $result ) ? $result->get_error_data() : null,
			);

			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event(
					$is_ok ? 'info' : 'warning',
					sprintf(
						'Result delivery to %s: %s (schedule: %s, type: %s)',
						$channel,
						$is_ok ? 'OK' : 'FAILED',
						$schedule_id,
						$is_success ? 'success' : 'failure'
					),
					$status
				);
			}

			/**
			 * Fires after a schedule result delivery attempt to a specific channel.
			 *
			 * Enables OTel subscribers, external monitoring, and custom notification
			 * handlers to react to delivery outcomes without modifying the service.
			 *
			 * @since 1.0.0
			 *
			 * @param string $schedule_id Schedule identifier.
			 * @param string $channel     Channel slug (email, slack, paper_store, etc.).
			 * @param bool   $is_ok       Whether delivery succeeded.
			 * @param string $error       Error message if delivery failed.
			 * @param bool   $is_success  Whether this was a success-run or failure-run delivery.
			 */
			do_action(
				'wp_mcp_ai_pro_schedule_result_delivered',
				$schedule_id,
				$channel,
				$is_ok,
				$status['error'],
				$is_success
			);

			return $status;
		}

		/**
		 * Log an intentional WordPress channel skip (AI already created the post).
		 *
		 * Produces the same status-array shape as {@see self::log_delivery()} so
		 * callers that iterate the per-channel statuses don't need a special case.
		 *
		 * @since 1.0.0
		 *
		 * @param string $schedule_id Schedule identifier.
		 * @param string $reason      Human-readable reason for the skip.
		 * @param bool   $is_success  Whether this was a success-run or failure-run delivery.
		 * @return array Status array with channel, success, skipped, and reason keys.
		 */
		protected static function log_delivery_skip( $schedule_id, $reason, $is_success ) {
			$status = array(
				'channel' => 'wordpress',
				'success' => true,
				'skipped' => true,
				'reason'  => $reason,
				'error'   => '',
			);

			if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
				WP_MCP_AI_Logger::log_event(
					'info',
					sprintf(
						'Result delivery to WordPress: SKIPPED (schedule: %s, type: %s) — %s',
						$schedule_id,
						$is_success ? 'success' : 'failure',
						$reason
					),
					$status
				);
			}

			/** This action is documented in log_delivery(). */
			do_action(
				'wp_mcp_ai_pro_schedule_result_delivered',
				$schedule_id,
				'WordPress',
				true,
				$reason,
				$is_success
			);

			return $status;
		}

		// -------------------------------------------------------------------------
		// Helpers
		// -------------------------------------------------------------------------

		/**
		 * Build a legacy failure channel config from old notify_* fields.
		 *
		 * Ensures existing schedules with only the old-style notify fields
		 * continue to receive failure notifications without requiring migration.
		 *
		 * @param array $schedule Schedule record.
		 * @return array Channel configs compatible with deliver_to_channels().
		 */
		protected static function build_legacy_failure_channels( array $schedule ) {
			$channels = array();

			// Legacy email notification.
			if ( ! empty( $schedule['notify_on_failure'] ) && ! empty( $schedule['notify_email'] ) ) {
				$channels['email'] = array(
					'enabled'  => true,
					'to'       => $schedule['notify_email'],
					'template' => 'error',
				);
			}

			// Legacy channel notification (slack, telegram, etc.).
			if ( ! empty( $schedule['notify_channels'] ) && is_array( $schedule['notify_channels'] ) ) {
				$credentials = isset( $schedule['notify_channel_credentials'] ) && is_array( $schedule['notify_channel_credentials'] )
					? $schedule['notify_channel_credentials']
					: array();

				foreach ( $schedule['notify_channels'] as $chan ) {
					if ( isset( $channels[ $chan ] ) ) {
						continue; // Already configured.
					}
					$chan_config = array(
						'enabled'  => true,
						'template' => 'error',
					);
					if ( isset( $credentials[ $chan ] ) ) {
						$chan_config[ $chan . '_credentials' ] = $credentials[ $chan ];
					}
					$channels[ $chan ] = $chan_config;
				}
			}

			return $channels;
		}

		/**
		 * Build an HTML email body from a formatted email payload.
		 *
		 * Prefers MJML compilation when the service is available; falls back
		 * to a simple inline-HTML template.
		 *
		 * @param array $payload Formatted email payload.
		 * @return string HTML.
		 */
		protected static function build_email_html( array $payload ) {
			$is_error     = ! empty( $payload['is_error'] );
			$header_color = $is_error ? '#cc1818' : '#2271b1';
			$status_label = $is_error
				? __( 'Failed', 'mcp-ai-wpoos-pro' )
				: __( 'Completed', 'mcp-ai-wpoos-pro' );
			$site_name    = isset( $payload['site_name'] ) ? $payload['site_name'] : get_bloginfo( 'name' );
			$schedule     = isset( $payload['schedule_name'] ) ? $payload['schedule_name'] : '';
			$body_text    = isset( $payload['plain'] ) ? $payload['plain'] : '';
			// Prefer the pre-rendered Markdown→HTML body; fall back to the
			// legacy nl2br(esc_html()) rendering for callers that only supply
			// a plain body.
			$body_html  = isset( $payload['html_body'] ) && '' !== (string) $payload['html_body']
				? (string) $payload['html_body']
				: nl2br( esc_html( $body_text ) );
			$manage_url = isset( $payload['manage_url'] ) ? $payload['manage_url'] : admin_url();

			// Try MJML first.
			if ( class_exists( 'WP_MCP_AI_MJML_Service' ) ) {
				$mjml_service = new WP_MCP_AI_MJML_Service();
				if ( $mjml_service->is_available() ) {
					$mjml_src  = '<mjml><mj-head>';
					$mjml_src .= '<mj-attributes><mj-all font-family="Arial, sans-serif" /></mj-attributes>';
					$mjml_src .= '</mj-head><mj-body background-color="#f4f4f4">';
					$mjml_src .= '<mj-section background-color="' . $header_color . '" padding="20px 24px">';
					$mjml_src .= '<mj-column><mj-text font-size="20px" color="#ffffff" font-weight="bold">';
					$mjml_src .= esc_html( $schedule . ' — ' . $status_label );
					$mjml_src .= '</mj-text></mj-column></mj-section>';
					$mjml_src .= '<mj-section background-color="#ffffff" padding="20px 24px">';
					$mjml_src .= '<mj-column><mj-text font-size="14px" color="#333">';
					$mjml_src .= $body_html;
					$mjml_src .= '</mj-text></mj-column></mj-section>';
					$mjml_src .= '<mj-section background-color="#ffffff" padding="0 24px 20px">';
					$mjml_src .= '<mj-column>';
					$mjml_src .= '<mj-button background-color="#2271b1" color="#ffffff" href="' . esc_url( $manage_url ) . '">';
					$mjml_src .= esc_html__( 'View Dashboard', 'mcp-ai-wpoos-pro' );
					$mjml_src .= '</mj-button></mj-column></mj-section>';
					$mjml_src .= '</mj-body></mjml>';

					$compiled = $mjml_service->compile( $mjml_src, array( 'minify' => true ) );
					if ( ! is_wp_error( $compiled ) && ! empty( $compiled ) ) {
						return $compiled;
					}
				}
			}

			// Fallback inline HTML.
			$html  = '<html><body style="font-family:sans-serif;color:#333">';
			$html .= '<div style="background:' . $header_color . ';color:#fff;padding:16px 20px;font-size:18px;font-weight:bold">';
			$html .= esc_html( $schedule . ' — ' . $status_label );
			$html .= '</div>';
			$html .= '<div style="padding:20px;background:#fff">';
			$html .= '<p style="font-size:13px;color:#888;margin:0 0 12px">' . esc_html( $site_name ) . '</p>';
			$html .= '<div style="font-size:14px;line-height:1.6">' . $body_html . '</div>';
			$html .= '</div>';
			$html .= '<div style="padding:12px 20px;background:#f9f9f9">';
			$html .= '<a href="' . esc_url( $manage_url ) . '" style="color:#2271b1">' . esc_html__( 'View Dashboard', 'mcp-ai-wpoos-pro' ) . '</a>';
			$html .= '</div>';
			$html .= '</body></html>';

			return $html;
		}

		/**
		 * Convert an envelope's data section to plain text.
		 *
		 * Handles nested arrays and objects by flattening them into key: value lines.
		 *
		 * @param array  $data   Envelope data.
		 * @param int    $depth  Current indentation depth.
		 * @param string $prefix Key prefix for nested structures.
		 * @return string Plain-text representation.
		 */
		protected static function envelope_data_to_text( array $data, $depth = 0, $prefix = '' ) {
			$lines  = array();
			$indent = str_repeat( '  ', $depth );

			foreach ( $data as $key => $value ) {
				$full_key = $prefix ? $prefix . '.' . $key : $key;

				if ( is_array( $value ) ) {
					// Empty structures render as meaningless "key:" lines — skip.
					if ( empty( $value ) ) {
						continue;
					}

					if ( isset( $value[0] ) && is_scalar( $value[0] ) ) {
						// Simple indexed array — comma-separated, empty entries dropped.
						$non_empty = array_values( array_filter( array_map( 'strval', $value ), 'strlen' ) );
						if ( ! empty( $non_empty ) ) {
							$lines[] = $indent . $full_key . ': ' . implode( ', ', $non_empty );
						}
					} else {
						// Nested structure — recurse. Only emit the key header when
						// the recursion produced readable content.
						$nested = self::envelope_data_to_text( $value, $depth + 1, $full_key );
						if ( '' !== $nested ) {
							$lines[] = $indent . $full_key . ':';
							$lines[] = $nested;
						}
					}
				} elseif ( is_scalar( $value ) && null !== $value && '' !== (string) $value ) {
					$lines[] = $indent . $full_key . ': ' . (string) $value;
				}
			}

			return implode( "\n", $lines );
		}

		/**
		 * Whether an envelope data section consists solely of a workflow step list.
		 *
		 * Workflow envelopes store the dispatcher's step log under
		 * `data.steps`; when nothing else sits alongside it the substantive
		 * output already lives in the envelope `response`, so the delivery
		 * formatters render a compact execution log instead of flattening the
		 * nested result payloads into unreadable dot-notation lines.
		 *
		 * @since 1.1.83
		 *
		 * @param mixed $data Envelope data section.
		 * @return bool True when the section is a pure workflow step list.
		 */
		protected static function is_workflow_steps_data( $data ) {
			return is_array( $data )
				&& 1 === count( $data )
				&& isset( $data['steps'] )
				&& is_array( $data['steps'] )
				&& ! empty( $data['steps'] );
		}

		/**
		 * Resolve a step's outcome label and duration suffix.
		 *
		 * @since 1.1.83
		 *
		 * @param mixed $result Step result (array, string, or WP_Error).
		 * @param mixed $duration Step duration in seconds.
		 * @return string Outcome text fragment ("completed · 0.94s").
		 */
		protected static function workflow_step_outcome( $result, $duration ) {
			$meta = array();

			if ( is_wp_error( $result ) ) {
				$meta[] = __( 'failed', 'mcp-ai-wpoos-pro' ) . ': ' . $result->get_error_message();
			} else {
				$meta[] = __( 'completed', 'mcp-ai-wpoos-pro' );
			}

			if ( isset( $duration ) && is_numeric( $duration ) ) {
				$meta[] = sprintf( '%.2fs', (float) $duration );
			}

			return implode( ' · ', $meta );
		}

		/**
		 * Render workflow step records as a compact plain-text execution log.
		 *
		 * One line per step: label (tool slug) — status · duration. The step
		 * `result` payloads are intentionally not flattened — the substantive
		 * output is already rendered from the envelope `response` above this
		 * section, and raw nested arrays read as noise to human recipients.
		 *
		 * @since 1.1.83
		 *
		 * @param array $steps Workflow step records from the action log.
		 * @return string Compact execution log.
		 */
		protected static function workflow_steps_to_text( array $steps ) {
			$lines = array();

			foreach ( $steps as $idx => $step ) {
				if ( ! is_array( $step ) ) {
					continue;
				}

				$tool   = isset( $step['tool_slug'] ) ? (string) $step['tool_slug'] : '';
				$label  = isset( $step['label'] ) && '' !== (string) $step['label'] ? (string) $step['label'] : $tool;
				$result = isset( $step['result'] ) ? $step['result'] : null;
				$dur    = isset( $step['duration'] ) ? $step['duration'] : null;

				$line = ( $idx + 1 ) . '. ' . $label;
				if ( '' !== $tool && $tool !== $label ) {
					$line .= ' (' . $tool . ')';
				}
				$line .= ' — ' . self::workflow_step_outcome( $result, $dur );

				$lines[] = $line;
			}

			return implode( "\n", $lines );
		}

		/**
		 * Render workflow step records as compact Markdown bullets.
		 *
		 * Markdown counterpart of {@see workflow_steps_to_text()} for the
		 * Paper Store and WordPress post delivery paths.
		 *
		 * @since 1.1.83
		 *
		 * @param array $steps Workflow step records from the action log.
		 * @return string Compact execution log in Markdown.
		 */
		protected static function workflow_steps_to_markdown( array $steps ) {
			$lines = array();

			foreach ( $steps as $idx => $step ) {
				if ( ! is_array( $step ) ) {
					continue;
				}

				$tool   = isset( $step['tool_slug'] ) ? (string) $step['tool_slug'] : '';
				$label  = isset( $step['label'] ) && '' !== (string) $step['label'] ? (string) $step['label'] : $tool;
				$result = isset( $step['result'] ) ? $step['result'] : null;
				$dur    = isset( $step['duration'] ) ? $step['duration'] : null;

				$line = esc_html( ( $idx + 1 ) . '. ' . $label );
				if ( '' !== $tool && $tool !== $label ) {
					$line .= ' (' . esc_html( $tool ) . ')';
				}
				$line .= ' — ' . esc_html( self::workflow_step_outcome( $result, $dur ) );

				$lines[] = '- ' . $line;
			}

			return implode( "\n", $lines ) . "\n";
		}

		/**
		 * Render an envelope data section for plain-text delivery.
		 *
		 * Pure workflow step lists render as a compact execution log (see
		 * {@see workflow_steps_to_text()}); everything else falls back to the
		 * generic key flattening. Always strips keys that duplicate the
		 * response or expose internal metadata via {@see delivery_safe_data()}.
		 *
		 * @since 1.1.83
		 *
		 * @param mixed $data Envelope data section (expected array).
		 * @return string Plain-text representation.
		 */
		protected static function envelope_data_to_delivery_text( $data ) {
			if ( ! is_array( $data ) ) {
				return '';
			}

			$data = self::delivery_safe_data( $data );

			if ( self::is_workflow_steps_data( $data ) ) {
				return self::workflow_steps_to_text( $data['steps'] );
			}

			return self::envelope_data_to_text( $data );
		}

		/**
		 * Render the envelope details section for Markdown delivery.
		 *
		 * Pure workflow step lists render as a compact bulleted execution log;
		 * everything else falls back to the generic recursive Markdown
		 * rendering.
		 *
		 * @since 1.1.83
		 *
		 * @param array $data Envelope data section (delivery-safe).
		 * @return string Markdown.
		 */
		protected static function envelope_details_to_markdown( array $data ) {
			if ( self::is_workflow_steps_data( $data ) ) {
				return self::workflow_steps_to_markdown( $data['steps'] );
			}

			return self::envelope_data_to_markdown( $data, 2 );
		}

		/**
		 * Strip keys that duplicate already-rendered content or expose internal
		 * execution metadata from an envelope data section before it is rendered
		 * into a delivered report (email, chat, Paper Store, WordPress post).
		 *
		 * Assistant-run envelopes store `response` — a truncated copy of the
		 * response rendered above the data section — plus `assistant_id` and
		 * `is_agentic` execution flags. Rendering them would repeat the response
		 * as a trailing footer and leak implementation details recipients do not
		 * need. All other keys (steps, broadcast, hook, args, …) pass through.
		 *
		 * @since 1.1.82
		 *
		 * @param mixed $data Envelope data section (expected array).
		 * @return array Data section safe to render for delivery.
		 */
		protected static function delivery_safe_data( $data ) {
			if ( ! is_array( $data ) ) {
				return array();
			}

			return array_diff_key(
				$data,
				array(
					'response'     => true,
					'assistant_id' => true,
					'is_agentic'   => true,
				)
			);
		}

		/**
		 * Convert an envelope to a Markdown document.
		 *
		 * Used by both Paper Store and WordPress post formatters.
		 *
		 * @param array $shared   Common formatted fields.
		 * @param array $envelope Full envelope.
		 * @param array $schedule Schedule record.
		 * @return string Markdown.
		 */
		protected static function envelope_to_markdown( array $shared, array $envelope, array $schedule ) {
			$md  = '# ' . $shared['schedule_name'] . "\n\n";
			$md .= '_Generated: ' . esc_html( gmdate( 'Y-m-d H:i:s T', $shared['generated_at'] ) ) . "_  \n";
			$md .= '_Status: ' . esc_html( $shared['status'] ) . "_  \n";

			if ( ! empty( $schedule['description'] ) ) {
				$md .= '_' . esc_html( $schedule['description'] ) . "_\n";
			}

			$md .= "\n---\n\n";

			// Response — the substantive output: the AI reply, tool results,
			// or final node output that the schedule produced. This is what
			// recipients actually want; the execution log follows below.
			$response = isset( $shared['response'] ) ? (string) $shared['response'] : '';
			if ( '' !== $response ) {
				$md .= "## Response\n\n";
				// Allow basic Markdown in the response (assistant runs produce
				// formatted output); escape only bare-HTML that could break layout.
				$md .= wp_kses(
					$response,
					array(
						'strong'     => array(),
						'em'         => array(),
						'code'       => array(),
						'pre'        => array(),
						'a'          => array( 'href' => array() ),
						'ul'         => array(),
						'ol'         => array(),
						'li'         => array(),
						'p'          => array(),
						'br'         => array(),
						'h1'         => array(),
						'h2'         => array(),
						'h3'         => array(),
						'h4'         => array(),
						'blockquote' => array(),
					)
				) . "\n\n";
				$md .= "---\n\n";
			}

			if ( ! empty( $shared['summary'] ) ) {
				$summary = (string) $shared['summary'];
				// Skip the summary section when the response above already opens
				// with it — assistant-run summaries are a trim of the response's
				// first words and would otherwise print twice.
				if ( '' !== $summary && ! self::response_starts_with_summary( $response, $summary ) ) {
					$md .= "## Summary\n\n" . esc_html( $summary ) . "\n\n";
				}
			}

			// Render the details section without keys that duplicate the response
			// or expose internal metadata (see delivery_safe_data()).
			$details = self::delivery_safe_data( isset( $envelope['data'] ) ? $envelope['data'] : array() );
			if ( ! empty( $details ) ) {
				$md .= "## Details\n\n";
				$md .= self::envelope_details_to_markdown( $details );
			}

			if ( ! empty( $schedule['tags'] ) ) {
				$md .= "\n\n**Tags:** " . implode( ', ', array_map( 'esc_html', $schedule['tags'] ) ) . "\n";
			}

			return $md;
		}

		/**
		 * Recursively convert envelope data to Markdown sections.
		 *
		 * @param array $data       Data to convert.
		 * @param int   $depth      Heading level (2 = ##, 3 = ###, etc.).
		 * @return string Markdown.
		 */
		protected static function envelope_data_to_markdown( array $data, $depth = 2 ) {
			$md     = '';
			$hashes = str_repeat( '#', min( $depth, 6 ) );

			foreach ( $data as $key => $value ) {
				if ( is_array( $value ) ) {
					if ( isset( $value[0] ) && is_scalar( $value[0] ) ) {
						$md .= '- **' . esc_html( $key ) . ':** ' . esc_html( implode( ', ', array_map( 'strval', $value ) ) ) . "\n";
					} elseif ( isset( $value[0] ) && is_array( $value[0] ) ) {
						$md .= $hashes . '# ' . esc_html( ucfirst( str_replace( '_', ' ', $key ) ) ) . "\n\n";
						foreach ( $value as $item ) {
							if ( is_array( $item ) ) {
								foreach ( $item as $ik => $iv ) {
									if ( is_scalar( $iv ) && null !== $iv && '' !== (string) $iv ) {
										$md .= '- **' . esc_html( $ik ) . ':** ' . esc_html( (string) $iv ) . "\n";
									}
								}
								$md .= "\n";
							}
						}
					} else {
						$md .= $hashes . '# ' . esc_html( ucfirst( str_replace( '_', ' ', $key ) ) ) . "\n\n";
						$md .= self::envelope_data_to_markdown( $value, $depth + 1 );
					}
				} elseif ( is_scalar( $value ) && null !== $value && '' !== (string) $value ) {
					$md .= '- **' . esc_html( $key ) . ':** ' . esc_html( (string) $value ) . "\n";
				}
			}

			return $md;
		}

		/**
		 * Relax the chat delivery tool capability checks for scheduled deliveries.
		 *
		 * Applies to both unified_channel_broadcast and send_telegram_message
		 * (used directly when a Telegram parse mode is configured).
		 *
		 * Result delivery runs inside WP cron, where no user is logged in, so the
		 * tools' manage_options gate would otherwise reject every scheduled chat
		 * delivery. The schedule itself was configured by an administrator
		 * (manage_options) at creation time and the outgoing message is
		 * system-generated, so the per-user capability check is waived for this
		 * internal delivery context only.
		 *
		 * @since 1.1.75
		 *
		 * @param string|false $required Required capability (manage_options by default).
		 * @param array        $context  Execution context from the tool call.
		 * @return string|false
		 */
		public static function broadcast_capability_for_scheduled_delivery( $required, $context ) {
			if ( isset( $context['source'] ) && 'pro_schedule_manager_result_delivery' === $context['source'] ) {
				return false;
			}

			return $required;
		}
	}

	add_filter(
		'wp_mcp_ai_unified_channel_broadcast_capability',
		array( 'WP_MCP_AI_Result_Delivery_Service', 'broadcast_capability_for_scheduled_delivery' ),
		10,
		2
	);

	add_filter(
		'wp_mcp_ai_send_telegram_message_capability',
		array( 'WP_MCP_AI_Result_Delivery_Service', 'broadcast_capability_for_scheduled_delivery' ),
		10,
		2
	);
}
