# MCP Apps — Per-Assistant Remote MCP Server Connections

## Purpose

Houses the Pro-only "MCP Apps" subsystem that lets each assistant connect to up to ten remote MCP servers over JSON-RPC 2.0 / Streamable HTTP and bridges their discovered tools into the local tool registry — and nothing else.

## Tier

| | |
|---|---|
| **Distribution** | Pro |
| **PHP target** | 8.1+ |
| **Loaded by** | [`addons/pro/includes/mcp-apps/mcp-apps-init.php`](./mcp-apps-init.php) — required from `addons/pro/mcp-ai-wpoos-pro.php` inside `wp_mcp_ai_pro_init()` |
| **Optional dependencies** | none — the remote endpoint is the only external surface; transport uses `wp_remote_*` |

## Public Surface

| Symbol | File | Used by |
|---|---|---|
| `WP_MCP_AI_MCP_App_Client` | `class-wp-mcp-ai-mcp-app-client.php` | `MCP_App_Registry`, `MCP_App_Tool_Bridge`, the REST controller, CLI/slash-command surfaces |
| `WP_MCP_AI_MCP_App_Client::get_last_tools_ttl_ms()` | same | `MCP_App_Registry::discover_tools()` — the server-declared freshness bound from the last `tools/list` (SEP-2549) |
| `WP_MCP_AI_MCP_App_Registry` (singleton) | `class-wp-mcp-ai-mcp-app-registry.php` | `mcp-apps-init.php` (tool registration), assistant metaboxes, REST controller |
| `WP_MCP_AI_MCP_App_Registry::resolve_cache_ttl()` | same | pure ttlMs→TTL helper used by `discover_tools()` |
| `WP_MCP_AI_MCP_App_Registry::invalidate_discovery_for_url()` / `handle_remote_notification()` | same | invalidate discovery caches when a remote server pushes `notifications/tools/list_changed` |
| `WP_MCP_AI_MCP_App_Tool_Bridge` | `class-wp-mcp-ai-mcp-app-tool-bridge.php` | `MCP_App_Registry::register_remote_tools()` — wraps each discovered remote tool as a local `WP_MCP_AI_Tool_Interface` |
| `WP_MCP_AI_MCP_App_OAuth_Client` | `class-wp-mcp-ai-mcp-app-oauth-client.php` | OAuth 2.0 client for MCP Apps — handles metadata discovery, DCR, PKCE flow, token exchange/refresh/revocation |
| `WP_MCP_AI_REST_MCP_Apps_Controller` | `class-wp-mcp-ai-rest-mcp-apps-controller.php` | self-registers under namespace `mcp-ai/v1` on `rest_api_init`; includes OAuth endpoints (`/oauth/probe`, `/oauth/init`, `/oauth/callback`, `/oauth/refresh`, `/oauth/revoke`) |
| `wp_mcp_ai_mcp_apps_register_tools()` | `mcp-apps-init.php` | hooked at priority 50 on `wp_mcp_ai_register_tools` |

Storage / protocol constants (stable contract): `WP_MCP_AI_MCP_App_Registry::META_KEY = '_wp_mcp_ai_mcp_apps'`, `WP_MCP_AI_MCP_App_Registry::STATUS_META_KEY = '_wp_mcp_ai_mcp_app_status'` (per-app connection snapshots keyed by `md5(server_url|auth_type|header_name|connection_ref)` — see `record_app_status()` / `get_app_status()`), `MAX_APPS_PER_ASSISTANT = 10`, `CACHE_TTL = 300`, `WP_MCP_AI_MCP_App_Client::PROTOCOL_VERSION = '2026-07-28'` (stateless core per SEP-2575), `WP_MCP_AI_MCP_App_Client::LEGACY_HINT_PREFIX = 'wp_mcp_ai_mcp_app_legacy_'` + `LEGACY_HINT_TTL = DAY_IN_SECONDS` (per-server dialect hint), `MAX_RESPONSE_SIZE = 2 MB`.

Protocol negotiation: `WP_MCP_AI_MCP_App_Client::handshake()` owns dialect selection and is the single entry point for `test_connection()` and `discover_tools()`. The client attempts the stateless `server/discover` handshake first and falls back to the legacy sessionful `initialize` handshake when the server responds with `-32601` (method not found), `-32600` (e.g. "Missing Mcp-Session-Id header"), or a bare HTTP 400/404/405/501 without a JSON-RPC error envelope (strict 2025-era gateways, e.g. Upwork, reject the unknown method that way). A successful legacy fallback records a **dialect hint** transient (`wp_mcp_ai_mcp_app_legacy_<md5(url)>`, 1-day TTL) so subsequent connections skip the doomed probe and open with `initialize()` directly — one fewer round trip per connect/test cycle. A stale hint self-heals: if `initialize()` is rejected with a stateless signature (`-32601`/`-32600` or HTTP 400/404/405/501), the hint is cleared and `discover()` is retried. The fallback `initialize` handshake and every request inside a legacy session omit the 2026-only `MCP-Protocol-Version` / `Mcp-Method` routing headers (SEP-2243) and the `_meta` envelope, so legacy requests look exactly like a 2025-era client. Session IDs from the `Mcp-Session-Id` response header are captured and echoed on every subsequent request — so both 2026-07-28 and 2025-era Streamable HTTP servers work. Sessionful servers may also answer any post-initialize request (notably `tools/list` and `tools/call`) with an SSE stream (`text/event-stream` — the Envoy AI Gateway does) instead of a JSON body: the client detects SSE via the Content-Type header or body sniffing and extracts the JSON-RPC message from the `message` event before decoding. Auth types supported: `none`, `bearer`, `basic` (raw `user:password` or pre-encoded base64 — a `:` in the token triggers encoding), `header`, `oauth`.

OAuth metadata discovery (`WP_MCP_AI_MCP_App_OAuth_Client::discover_metadata()`) follows the MCP Authorization Specification chain: (1) RFC 8414 authorization server metadata on the MCP origin with the RFC 8414 §3.2 path-insertion variant (e.g. `/.well-known/oauth-authorization-server/v1/mcp`); (2) RFC 9728 protected resource metadata (`/.well-known/oauth-protected-resource` + path-inserted variant), trying **every** advertised `authorization_servers` entry — not just the first; (3) a 401 `WWW-Authenticate: Bearer resource_metadata="…"` probe of the MCP endpoint; (4) OIDC discovery (`/.well-known/openid-configuration`) as a compatibility fallback for gateways fronting Auth0/Okta/Cognito; (5) the WordPress REST metadata endpoint for self-hosted WP servers. Individual probes cap at 10 s (`discovery_timeout`). RFC 8414 documents are only accepted when both `authorization_endpoint` **and** `token_endpoint` are present (both are REQUIRED by RFC 8414 §2 for the authorization code flow). Every attempt is recorded (URL → HTTP status / transport error) and returned in the `WP_Error` data (`attempts` + `hint`) so the metabox can distinguish "server has no OAuth" from "site could not reach it" (cURL/DNS/TLS) and point at the API-key alternative — never replace this with a generic message.

## Inputs / Outputs / Neighbors

- **Reads from:** assistant post meta `_wp_mcp_ai_mcp_apps` (per-assistant app configs — URL, auth, allow-list), remote MCP servers (JSON-RPC `initialize` / `tools/list` / `tools/call` / `resources/read`), the request body / query / `$_POST` for the current `assistant_id`, the `wp_mcp_ai_mcp_apps_assistant_id` filter as a fallback resolver, transient cache (`wp_mcp_ai_mcp_app_tools_*`, 5 min TTL; `wp_mcp_ai_mcp_app_legacy_*`, 1-day dialect hint).
- **Writes to:** the same assistant post meta on save, transient tool-discovery cache and the legacy-dialect hint, telemetry via the standard tool-execution hooks when bridged tools run.
- **Upstream callers:** REST clients (CRUD via `mcp-ai/v1/mcp-apps`), chat service via the tool registry, the Pro slash-command `/mcp-app` (see `addons/pro/includes/slash-commands/`).
- **Downstream collaborators:** [`includes/tools/`](../../../../includes/tools/) tool registry (`wp_mcp_ai_register_tools`), [`includes/services/`](../../../../includes/services/) chat service (executes bridged tools transparently), `wp_remote_post`/`wp_remote_get` for transport.
- **Events fired:** `wp_mcp_ai_mcp_apps_assistant_id` (filter — let callers supply an assistant ID when the request doesn't carry one); `wp_mcp_ai_remote_mcp_notification` (fired by the client for every JSON-RPC notification parsed from an SSE response — method, params, server URL).
- **Events listened to:** `rest_api_init`, `wp_mcp_ai_register_tools` (priority 50, so the bridge registers after base + Pro tools), `wp_mcp_ai_remote_mcp_notification` (via `wp_mcp_ai_mcp_apps_handle_remote_notification()` in `mcp-apps-init.php` — `notifications/tools/list_changed` invalidates the matching discovery cache).

## Conventions

- **Per-assistant scope is mandatory.** Every public method on `MCP_App_Registry` takes an `assistant_id`; never read or write the `_wp_mcp_ai_mcp_apps` meta key directly from other folders.
- **Connection references (v1.1.85).** Entries may carry `connection_ref` pointing at an `mcp_server` connection in `WP_MCP_AI_Pro_Remote_Site_Manager` (option `wp_mcp_ai_pro_remote_sites`). `resolve_apps()` expands references at chat time (decrypt-on-use, credentials never written back to post meta); unresolvable references are skipped with an error status snapshot. Keep entries with a reference even though `server_url` is empty — `save_apps()` and the portability importer must not drop them.
- **`MAX_APPS_PER_ASSISTANT = 10` is a hard cap.** Enforce it on every save path — UI, REST, CLI, slash command — so a single assistant can never balloon discovery cost.
- **Remote URLs must pass `WP_MCP_AI_MCP_App_Registry::is_allowed_server_url()`** (HTTPS-only, blocks loopback/private ranges unless explicitly allow-listed). The hostname allowlist resolves from three sources: the `WP_MCP_AI_MCP_APP_ALLOWED_HOSTS` constant (hard override when defined), the `wp_mcp_ai_mcp_app_allowed_hosts` filter, and the **Settings → Security Center → Network & Headers → "MCP App Allowed Hosts"** textarea (filter + setting are merged). Do not bypass this for "internal" servers — add an allow-list entry instead.
- **Transport is JSON-RPC 2.0 over Streamable HTTP per the MCP spec.** When the spec bumps (e.g. SEP-1865 MCP Apps extension finalises), update `WP_MCP_AI_MCP_App_Client::PROTOCOL_VERSION` and the `server/discover` handshake — don't shim older transports inside this folder.
- **Connection failures are never silent.** `register_remote_tools()` records a per-app status snapshot (`last_status` / `last_error` / `tool_count`) via `record_app_status()` and logs a warning; the metabox renders the snapshots as status badges and the `/mcp-apps/test` + `/mcp-apps/discover` REST endpoints refresh them on demand.
- **Cap remote responses at 2 MB** (`MAX_RESPONSE_SIZE`). Truncate and surface an error rather than allocating an arbitrary payload — a remote MCP server is untrusted input.
- **Cache `tools/list` results in transients keyed by `md5( app_config )`** so a configuration change naturally invalidates the cache; do not hand-build cache keys elsewhere. **A positive server `ttlMs` (SEP-2549) caps the discovery TTL** at the server's freshness bound via `resolve_cache_ttl()`; an absent/zero `ttlMs` keeps the settings TTL (per-chat re-discovery would double the handshake round trips).
- **Bridged tools are exposed to the LLM automatically.** The `wp_mcp_ai_mcp_apps_expose_tools` callback (registered on the base plugin's `wp_mcp_ai_chat_effective_tools` seam) appends the bridge slugs for the current assistant to the chat payload, because bridge tools are registered at chat time and can never be ticked in the Tools metabox. Capability gating (`edit_posts`) still applies per tool. Use `WP_MCP_AI_MCP_App_Registry::get_remote_tool_slugs( $assistant_id )` to resolve the slugs without registering anything.
- **Same-site servers are bridged in-process.** When the MCP App URL points at this WordPress site and the derived REST route is registered, `WP_MCP_AI_MCP_App_Client::dispatch_request()` executes the JSON-RPC call through `rest_do_request()` instead of an outbound HTTP call — a self-request over the public hostname can deadlock a small PHP-FPM pool or stall on missing hairpin NAT. The `wp_mcp_ai_mcp_app_disable_inprocess_bridge` filter opts out per deployment.

## Tests

```bash
vendor/bin/phpunit tests/test-mcp-apps.php
vendor/bin/phpunit tests/mcp-apps/test-mcp-app-client-connection-enhancements.php
vendor/bin/phpunit tests/mcp-apps/test-mcp-app-oauth-loopback-fallback.php
vendor/bin/phpunit tests/mcp-apps/test-mcp-app-oauth-discovery-chain.php
vendor/bin/phpunit tests/mcp-apps/test-mcp-app-registry-connection-enhancements.php
vendor/bin/phpunit tests/mcp-apps/test-mcp-app-cache-freshness.php
vendor/bin/phpunit tests/mcp-apps/test-rest-mcp-apps-connection-enhancements.php
vendor/bin/phpunit addons/pro/tests/test-pro-slash-command-mcp-app.php
```

(The base-tree test exercises the registry, client, and tool-bridge; `tests/mcp-apps/` covers basic auth, session capture/fallback, negotiated protocol headers, status persistence, and the REST handlers with `pre_http_request` mocks — one test class per file because PHPUnit 11 only discovers the first class in a file; the Pro-tree test covers the `/mcp-app` slash-command surface that drives this folder from the assistant UI.)

## Also Load

- [`.context/conventions.md`](../../../../.context/conventions.md) — naming + style (always)
- [`.context/security-checklist.md`](../../../../.context/security-checklist.md) — outbound HTTP, SSRF, secrets (always — this folder talks to untrusted remotes)
- [`.context/tool-registry.md`](../../../../.context/tool-registry.md) — bridged tools must honour the canonical envelope
- [`.context/pro-vs-base.md`](../../../../.context/pro-vs-base.md) — placement rationale
- [`CLAUDE.md`](../../../../CLAUDE.md) — PHP-compat (8.1+ here) and the two-gate sanitisation rule
- [`docs/features/mcp-apps.md`](../../../../docs/features/mcp-apps.md) — feature reference, if present

## See Also

- Sibling: [`../mcp-servers/`](../mcp-servers/) — the inverse direction (this plugin *exposing* MCP servers to other clients)
- Sibling: [`../slash-commands/`](../slash-commands/) — the `/mcp-app` slash command driving CRUD
- Upstream: [`../../../../includes/tools/`](../../../../includes/tools/) — tool registry the bridge plugs into
- Spec: <https://modelcontextprotocol.io/specification/2025-03-26>
