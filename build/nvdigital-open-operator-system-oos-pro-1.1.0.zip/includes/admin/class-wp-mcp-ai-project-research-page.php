<?php
/**
 * Research & Add admin page for Project CPT.
 *
 * Provides a dedicated page for researching projects before adding them,
 * with full chat interface for AI assistance.
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/trait-wp-mcp-ai-research-page-featured-image.php';
require_once __DIR__ . '/trait-wp-mcp-ai-research-page-enhancements.php';

/**
 * Project Research Admin Page
 *
 * Adds a submenu page under Projects menu for AI-powered project research.
 */
class WP_MCP_AI_Project_Research_Page {
	use WP_MCP_AI_Research_Page_Featured_Image;
	use WP_MCP_AI_Research_Page_Import_Handler;
	use WP_MCP_AI_Research_Page_Consolidation;
	use WP_MCP_AI_Research_Page_Data_Validation;
	use WP_MCP_AI_Research_Page_Mode_Tabs;

	/**
	 * Page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'research-project';

	/**
	 * Initialize the page.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu_page' ), 20 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_wp_mcp_ai_create_project_from_research', array( __CLASS__, 'handle_create_from_research' ) );
		add_action( 'wp_ajax_wp_mcp_ai_import_project', array( __CLASS__, 'handle_import' ) );
	}

	/**
	 * Add submenu page under Projects menu.
	 */
	public static function add_menu_page() {
		add_submenu_page(
			'edit.php?post_type=mcp_ai_project',
			__( 'Research & Add Project', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Research & Add', 'nvdigital-open-operator-system-oos-pro' ),
			'edit_posts',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue assets for the research page.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function enqueue_assets( $hook ) {
		// Only load on our research page.
		if ( 'mcp_ai_project_page_' . self::PAGE_SLUG !== $hook ) {
			return;
		}

		// Enqueue chat assets.
		if ( class_exists( 'WP_MCP_AI_Shortcode' ) ) {
			$shortcode_instance = new WP_MCP_AI_Shortcode();
			$shortcode_instance->register_assets();
			wp_enqueue_style( WP_MCP_AI_Shortcode::STYLE_HANDLE );
			wp_enqueue_script( WP_MCP_AI_Shortcode::SCRIPT_HANDLE );
		}

		// Enqueue enhanced research page styles.
		wp_enqueue_style(
			'wp-mcp-ai-enhanced-research-page',
			WP_MCP_AI_URL . 'assets/css/enhanced-research-page.css',
			array(),
			WP_MCP_AI_VERSION
		);

		// Enqueue enhanced research page script.
		wp_enqueue_script(
			'wp-mcp-ai-enhanced-research-page',
			WP_MCP_AI_URL . 'assets/js/enhanced-research-page.js',
			array( 'jquery' ),
			WP_MCP_AI_VERSION,
			true
		);

		// Localize script.
		wp_localize_script(
			'wp-mcp-ai-enhanced-research-page',
			'wpMcpAiResearchPage',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'wp_mcp_ai_research_project' ),
				'entityType' => 'project',
			)
		);
	}

	/**
	 * Render the research page.
	 */
	public static function render_page() {
		// Get assistant from settings.
		$settings     = get_option( 'wp_mcp_ai_project_settings', array() );
		$assistant_id = isset( $settings['assistant_id'] ) ? absint( $settings['assistant_id'] ) : 0;

		// If no assistant configured or invalid, get the first available assistant.
		if ( ! $assistant_id || 'publish' !== get_post_status( $assistant_id ) ) {
			$assistants = get_posts(
				array(
					'post_type'      => 'mcp_ai_assistant',
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'orderby'        => 'date',
					'order'          => 'DESC',
				)
			);

			$assistant_id = ! empty( $assistants ) ? $assistants[0]->ID : 0;
		}

		?>
		<div class="wrap wp-mcp-ai-research-page">
			<h1 class="wp-heading-inline">
				<?php esc_html_e( 'Research & Add Project', 'nvdigital-open-operator-system-oos-pro' ); ?>
			</h1>

			<hr class="wp-header-end">

			<?php self::render_chat_interface( $assistant_id ); ?>
		</div>
		<?php
	}

	/**
	 * Render the chat interface.
	 *
	 * @param int $assistant_id Assistant ID.
	 */
	protected static function render_chat_interface( $assistant_id ) {
		?>
			<div class="wp-mcp-ai-research-container">
				<div class="wp-mcp-ai-research-sidebar">
					<div class="wp-mcp-ai-research-intro">
						<h2><?php esc_html_e( 'How It Works', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
						<ol>
							<li><?php esc_html_e( 'Search existing projects or research new ideas on the web', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Use calendar view to check timelines and conflicts', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Create projects with tasks and milestones', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><?php esc_html_e( 'Manage project resources and assignments', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						</ol>
					</div>

					<div class="wp-mcp-ai-research-tips">
						<h3><?php esc_html_e( 'Research Tips', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
						<ul>
							<li><strong><?php esc_html_e( 'Search first:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'List existing projects to avoid duplicates', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><strong><?php esc_html_e( 'Check timeline:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Review schedule conflicts before creating', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><strong><?php esc_html_e( 'Web research:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Find best practices and methodologies', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
							<li><strong><?php esc_html_e( 'Break it down:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Define tasks and milestones after creating', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						</ul>
					</div>

					<div class="wp-mcp-ai-research-examples">
						<h3><?php esc_html_e( 'Example Queries', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
						<ul class="wp-mcp-ai-example-list">
							<li><button type="button" class="button button-secondary wp-mcp-ai-example-query" data-query="Research a website redesign project with timeline, phases, and deliverables">
								<?php esc_html_e( '"Research a website redesign project..."', 'nvdigital-open-operator-system-oos-pro' ); ?>
							</button></li>
							<li><button type="button" class="button button-secondary wp-mcp-ai-example-query" data-query="Find information about planning a product launch including marketing strategy and milestones">
								<?php esc_html_e( '"Find information about planning a product launch..."', 'nvdigital-open-operator-system-oos-pro' ); ?>
							</button></li>
							<li><button type="button" class="button button-secondary wp-mcp-ai-example-query" data-query="Research an employee training program with curriculum, schedule, and assessment plan">
								<?php esc_html_e( '"Research an employee training program..."', 'nvdigital-open-operator-system-oos-pro' ); ?>
							</button></li>
						</ul>
					</div>

					<div class="wp-mcp-ai-research-actions">
						<h3><?php esc_html_e( 'Quick Actions', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
						<p>
							<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_project' ) ); ?>" class="button">
								<?php esc_html_e( 'View All Projects', 'nvdigital-open-operator-system-oos-pro' ); ?>
							</a>
						</p>
						<p>
							<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=mcp_ai_project' ) ); ?>" class="button">
								<?php esc_html_e( 'Add Project Manually', 'nvdigital-open-operator-system-oos-pro' ); ?>
							</a>
						</p>
					</div>
				</div>

				<div class="wp-mcp-ai-research-main">
					<!-- Workflow Mode Selector -->
					<div class="wp-mcp-ai-workflow-selector">
						<h2><?php esc_html_e( 'Choose Your Workflow', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
						<div class="workflow-options">
							<button type="button" class="workflow-option active" data-workflow="research">
								<span class="dashicons dashicons-format-chat"></span>
								<strong><?php esc_html_e( 'AI Research', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
								<p><?php esc_html_e( 'Research and create projects with AI assistance', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
							</button>
							<button type="button" class="workflow-option" data-workflow="import">
								<span class="dashicons dashicons-upload"></span>
								<strong><?php esc_html_e( 'Import Data', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
								<p><?php esc_html_e( 'Bulk import project data', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
							</button>
							<button type="button" class="workflow-option" data-workflow="review">
								<span class="dashicons dashicons-analytics"></span>
								<strong><?php esc_html_e( 'Review & Quality', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
								<p><?php esc_html_e( 'View project quality and completeness', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
							</button>
						</div>
					</div>

					<!-- AI Research Workflow (Default) -->
					<div id="workflow-research" class="workflow-content active">
					<?php if ( $assistant_id > 0 ) : ?>
						<div class="wp-mcp-ai-research-chat">
							<?php
							// Render chat interface with comprehensive project tools.
							// Includes research, creation, task management, and calendar tools.
							echo do_shortcode(
								'[mcp_ai_chat assistant="' . absint( $assistant_id ) . '" additional_tools="research_project,create_project,list_projects,create_task,list_tasks,create_event,list_events,get_calendar_view,web_search,search_content"]'
							);
							?>
						</div>

					<?php else : ?>
						<div class="notice notice-error">
							<p>
								<?php
								echo wp_kses_post(
									sprintf(
										/* translators: %s: Link to create assistant */
										__( 'No AI assistant found. Please <a href="%s">create an assistant</a> first.', 'nvdigital-open-operator-system-oos-pro' ),
										admin_url( 'post-new.php?post_type=mcp_ai_assistant' )
									)
								);
								?>
							</p>
						</div>
					<?php endif; ?>
					</div>

					<!-- Import Data Workflow -->
					<div id="workflow-import" class="workflow-content">
						<?php self::render_import_workflow(); ?>
					</div>

					<!-- Review & Quality Workflow -->
					<div id="workflow-review" class="workflow-content">
						<?php self::render_review_workflow(); ?>
					</div>
				</div>
			</div>
		<?php
	}

	/**
	 * Handle AJAX request to create project from research.
	 */
	public static function handle_create_from_research() {
		// Verify nonce.
		check_ajax_referer( 'wp_mcp_ai_research_project', 'nonce' );

		// Check user capability.
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to create projects.', 'nvdigital-open-operator-system-oos-pro' ) ) );
		}

		// Get research data from request.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Data is sanitized below per field.
		$research_data_raw = isset( $_POST['research_data'] ) ? wp_unslash( $_POST['research_data'] ) : '';

		if ( empty( $research_data_raw ) ) {
			wp_send_json_error( array( 'message' => __( 'No research data provided.', 'nvdigital-open-operator-system-oos-pro' ) ) );
		}

		$research_data = json_decode( $research_data_raw, true );

		// Validate JSON decoding.
		if ( null === $research_data || JSON_ERROR_NONE !== json_last_error() ) {
			wp_send_json_error( array( 'message' => __( 'Invalid JSON data format.', 'nvdigital-open-operator-system-oos-pro' ) ) );
		}

		if ( empty( $research_data['title'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Project title is required.', 'nvdigital-open-operator-system-oos-pro' ) ) );
		}

		// Process featured image generation request.
		$research_data = self::process_featured_image_request( $research_data, $research_data['title'], 'a project' );

		// Use the create_project tool to create the project.
		if ( ! class_exists( 'WP_MCP_AI_Tool_Create_Project' ) ) {
			wp_send_json_error( array( 'message' => __( 'Create Project tool not available.', 'nvdigital-open-operator-system-oos-pro' ) ) );
		}

		$tool   = new WP_MCP_AI_Tool_Create_Project();
		$result = $tool->execute(
			$research_data,
			array( 'user_id' => get_current_user_id() )
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		// Return success with project ID and edit URL.
		$project_id = isset( $result['project_id'] ) ? $result['project_id'] : 0;
		$edit_url   = $project_id > 0 ? admin_url( 'post.php?post=' . $project_id . '&action=edit' ) : '';

		wp_send_json_success(
			array(
				'message'    => __( 'Project created successfully!', 'nvdigital-open-operator-system-oos-pro' ),
				'project_id' => $project_id,
				'edit_url'   => $edit_url,
			)
		);
	}

	/**
	 * Get supported import formats.
	 *
	 * @return array Format key => label pairs.
	 */
	protected static function get_import_formats() {
		return array(
			'xml'  => 'MS Project XML',
			'csv'  => 'CSV',
			'json' => 'JSON',
		);
	}

	/**
	 * Process imported data.
	 *
	 * @param mixed  $data   Data to process.
	 * @param string $format Import format.
	 * @return array|WP_Error Processed data or error.
	 */
	protected static function process_import_data( $data, $format ) {
		// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- Parameters reserved for future implementation.
		return new WP_Error( 'not_implemented', __( 'Project import processing coming soon', 'nvdigital-open-operator-system-oos-pro' ) );
	}

	/**
	 * Get validation schema for projects.
	 *
	 * @return array Validation schema with required and recommended fields.
	 */
	protected static function get_validation_schema() {
		return array(
			'required_fields'    => array(
				'name'       => __( 'Project Name', 'nvdigital-open-operator-system-oos-pro' ),
				'start_date' => __( 'Start Date', 'nvdigital-open-operator-system-oos-pro' ),
				'duration'   => __( 'Duration', 'nvdigital-open-operator-system-oos-pro' ),
			),
			'recommended_fields' => array(
				'end_date'    => __( 'End Date', 'nvdigital-open-operator-system-oos-pro' ),
				'budget'      => __( 'Budget', 'nvdigital-open-operator-system-oos-pro' ),
				'status'      => __( 'Status', 'nvdigital-open-operator-system-oos-pro' ),
				'description' => __( 'Description', 'nvdigital-open-operator-system-oos-pro' ),
			),
			'validation_rules'   => array(
				'start_date' => array( 'type' => 'datetime' ),
				'end_date'   => array( 'type' => 'datetime' ),
				'budget'     => array(
					'type'      => 'numeric',
					'min_value' => 0,
				),
			),
			'quality_dimensions' => array(
				'completeness',
				'accuracy',
				'constraint_validation',
				'dependency_integrity',
			),
		);
	}

	/**
	 * Calculate completeness metrics for projects.
	 *
	 * @return array Completeness percentage and suggestions.
	 */
	protected static function calculate_completeness() {
		$projects = get_posts(
			array(
				'post_type'      => 'mcp_ai_project',
				'post_status'    => 'any',
				'posts_per_page' => -1,
			)
		);

		$total    = count( $projects );
		$complete = 0;

		foreach ( $projects as $project ) {
			$start_date = get_post_meta( $project->ID, 'start_date', true );
			$status     = get_post_meta( $project->ID, 'status', true );
			if ( ! empty( $start_date ) && ! empty( $status ) && ! empty( $project->post_content ) ) {
				++$complete;
			}
		}

		$percentage = $total > 0 ? round( ( $complete / $total ) * 100 ) : 0;

		return array(
			'percentage'  => $percentage,
			'missing'     => array(),
			'suggestions' => array(
				__( 'Set start and end dates for all projects', 'nvdigital-open-operator-system-oos-pro' ),
				__( 'Define project budgets and milestones', 'nvdigital-open-operator-system-oos-pro' ),
				__( 'Add detailed project descriptions', 'nvdigital-open-operator-system-oos-pro' ),
			),
		);
	}

	/**
	 * Get items for review.
	 *
	 * @return array Array of project items with metadata.
	 */
	protected static function get_items_for_review() {
		$projects = get_posts(
			array(
				'post_type'      => 'mcp_ai_project',
				'post_status'    => 'any',
				'posts_per_page' => 20,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		$items = array();
		foreach ( $projects as $project ) {
			$items[] = array(
				'id'    => $project->ID,
				'title' => $project->post_title,
				'meta'  => array(
					'start_date' => get_post_meta( $project->ID, 'start_date', true ),
					'end_date'   => get_post_meta( $project->ID, 'end_date', true ),
					'status'     => get_post_meta( $project->ID, 'status', true ),
				),
			);
		}

		return $items;
	}

	/**
	 * Calculate quality score for a project item.
	 *
	 * @param array $item Project item data.
	 * @return array Quality score with level, status, and issues.
	 */
	protected static function calculate_quality_score( $item ) {
		$score  = 0;
		$issues = array();

		if ( ! empty( $item['meta']['start_date'] ) ) {
			$score += 30;
		} else {
			$issues[] = __( 'Missing start date', 'nvdigital-open-operator-system-oos-pro' );
		}

		if ( ! empty( $item['meta']['end_date'] ) ) {
			$score += 30;
		} else {
			$issues[] = __( 'Missing end date', 'nvdigital-open-operator-system-oos-pro' );
		}

		if ( ! empty( $item['meta']['status'] ) ) {
			$score += 20;
		} else {
			$issues[] = __( 'Missing status', 'nvdigital-open-operator-system-oos-pro' );
		}

		if ( ! empty( $item['title'] ) && strlen( $item['title'] ) > 10 ) {
			$score += 20;
		} else {
			$issues[] = __( 'Title needs improvement', 'nvdigital-open-operator-system-oos-pro' );
		}

		$level = $score >= 80 ? 'high' : ( $score >= 50 ? 'medium' : 'low' );

		return array(
			'score'  => $score,
			'level'  => $level,
			'status' => 'high' === $level ? __( 'Complete', 'nvdigital-open-operator-system-oos-pro' ) : __( 'Needs Work', 'nvdigital-open-operator-system-oos-pro' ),
			'issues' => $issues,
		);
	}

	/**
	 * Handle AJAX import request.
	 */
	public static function handle_import() {
		// Verify nonce.
		check_ajax_referer( 'wp_mcp_ai_research_project', 'nonce' );

		// Check user capability.
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to import projects.', 'nvdigital-open-operator-system-oos-pro' ) ) );
		}

		// Get import data from request.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Data is sanitized below per field.
		$import_data_raw = isset( $_POST['import_data'] ) ? wp_unslash( $_POST['import_data'] ) : '';
		$format          = isset( $_POST['format'] ) ? sanitize_text_field( wp_unslash( $_POST['format'] ) ) : '';

		if ( empty( $import_data_raw ) || empty( $format ) ) {
			wp_send_json_error( array( 'message' => __( 'Import data and format are required.', 'nvdigital-open-operator-system-oos-pro' ) ) );
		}

		// Process import.
		$result = self::process_import_data( $import_data_raw, $format );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Import completed successfully!', 'nvdigital-open-operator-system-oos-pro' ),
				'result'  => $result,
			)
		);
	}

	/**
	 * Render import workflow.
	 */
	protected static function render_import_workflow() {
		?>
		<div class="wp-mcp-ai-import-section">
			<h2><?php esc_html_e( 'Import Project Data', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Import projects from CSV, JSON, XML, or paste structured data. The AI will automatically parse and organize the project information.', 'nvdigital-open-operator-system-oos-pro' ); ?>
			</p>
			
			<div class="import-tips">
				<h4><?php esc_html_e( 'Tips for better results:', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
				<ul>
					<li><?php esc_html_e( '✓ Include project name, start date, and duration', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( '✓ Specify budget, status, and description', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( '✓ Add tasks and milestones when available', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( '✓ Include team member assignments', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>
			</div>

			<div class="import-form">
				<h3><?php esc_html_e( 'Upload File or Paste Data', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<form id="wp-mcp-ai-import-form" method="post" enctype="multipart/form-data">
					<?php wp_nonce_field( 'wp_mcp_ai_import_projects', 'import_nonce' ); ?>
					
					<div class="import-file-section">
						<input type="file" id="wp-mcp-ai-import-file-input" name="import_file" accept=".csv,.json,.xml,.txt" style="display: none;">
						<button type="button" class="button" onclick="document.getElementById('wp-mcp-ai-import-file-input').click();">
							<span class="dashicons dashicons-upload"></span>
							<?php esc_html_e( 'Choose File', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</button>
						<span class="import-file-selected" style="margin-left: 10px; display: none;"></span>
						<p class="description"><?php esc_html_e( 'Supported: CSV, JSON, XML, TXT', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</div>

					<p><strong><?php esc_html_e( 'OR', 'nvdigital-open-operator-system-oos-pro' ); ?></strong></p>

					<textarea 
						id="wp-mcp-ai-import-text" 
						name="import_data" 
						class="widefat" 
						rows="12" 
						placeholder="<?php esc_attr_e( 'Example:\n\nProject Name: Website Redesign\nStart Date: 2024-01-15\nEnd Date: 2024-04-30\nBudget: 50000\nStatus: In Progress\nDescription: Complete website redesign with new branding\n\nProject Name: Mobile App Development\nStart Date: 2024-02-01\nDuration: 6 months\nStatus: Planning', 'nvdigital-open-operator-system-oos-pro' ); ?>"
					></textarea>
					
					<div class="import-options">
						<label>
							<input type="checkbox" name="auto_create" value="1" checked>
							<?php esc_html_e( 'Automatically create projects (recommended)', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</label>
						<label>
							<input type="checkbox" name="validate_data" value="1" checked>
							<?php esc_html_e( 'Validate data quality before importing', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</label>
					</div>

					<p>
						<button type="submit" class="button button-primary button-large">
							<span class="dashicons dashicons-update"></span>
							<?php esc_html_e( 'Import & Process', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</button>
					</p>
					<div class="import-result" style="display: none;"></div>
				</form>
			</div>
		</div>
		<?php
	}

	/**
	 * Render review workflow.
	 */
	protected static function render_review_workflow() {
		// Get project statistics.
		$total_projects  = wp_count_posts( 'mcp_ai_project' );
		$published_count = isset( $total_projects->publish ) ? $total_projects->publish : 0;

		// Calculate data quality metrics.
		$projects = get_posts(
			array(
				'post_type'      => 'mcp_ai_project',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
			)
		);

		$complete_count  = 0;
		$with_start_date = 0;
		$with_status     = 0;

		foreach ( $projects as $project ) {
			$start_date = get_post_meta( $project->ID, 'start_date', true );
			$status     = get_post_meta( $project->ID, 'status', true );
			$has_desc   = ! empty( $project->post_content );

			if ( ! empty( $start_date ) ) {
				++$with_start_date;
			}
			if ( ! empty( $status ) ) {
				++$with_status;
			}
			if ( ! empty( $start_date ) && ! empty( $status ) && $has_desc ) {
				++$complete_count;
			}
		}

		$completeness = $published_count > 0 ? round( ( $complete_count / $published_count ) * 100 ) : 0;

		?>
		<div class="wp-mcp-ai-consolidate-section">
			<h2><?php esc_html_e( 'Project Quality Dashboard', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<div class="quality-dashboard">
				<h3><?php esc_html_e( 'Overall Completeness', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<div class="completeness-indicator">
					<div class="completeness-bar" style="width: <?php echo esc_attr( $completeness ); ?>%;"></div>
					<span class="completeness-percentage"><?php echo esc_html( $completeness ); ?>%</span>
				</div>

				<div class="quality-metrics">
					<div class="quality-metric">
						<span class="quality-metric-value"><?php echo esc_html( $published_count ); ?></span>
						<span class="quality-metric-label"><?php esc_html_e( 'Total Projects', 'nvdigital-open-operator-system-oos-pro' ); ?></span>
					</div>
					<div class="quality-metric">
						<span class="quality-metric-value"><?php echo esc_html( $complete_count ); ?></span>
						<span class="quality-metric-label"><?php esc_html_e( 'Fully Complete', 'nvdigital-open-operator-system-oos-pro' ); ?></span>
					</div>
					<div class="quality-metric">
						<span class="quality-metric-value"><?php echo esc_html( $with_start_date ); ?></span>
						<span class="quality-metric-label"><?php esc_html_e( 'With Start Date', 'nvdigital-open-operator-system-oos-pro' ); ?></span>
					</div>
					<div class="quality-metric">
						<span class="quality-metric-value"><?php echo esc_html( $with_status ); ?></span>
						<span class="quality-metric-label"><?php esc_html_e( 'With Status', 'nvdigital-open-operator-system-oos-pro' ); ?></span>
					</div>
				</div>

				<?php if ( $completeness < 80 ) : ?>
					<div class="notice notice-warning inline">
						<p>
							<?php
							printf(
								/* translators: %d: Completeness percentage */
								esc_html__( 'Project completeness is %d%%. Consider adding start dates, statuses, and descriptions to improve quality.', 'nvdigital-open-operator-system-oos-pro' ),
								esc_html( $completeness )
							);
							?>
						</p>
					</div>
				<?php endif; ?>
			</div>

			<?php self::render_quality_table(); ?>

			<div class="items-list-table">
				<h3><?php esc_html_e( 'Quick Actions', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<p>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=mcp_ai_project' ) ); ?>" class="button button-primary">
						<?php esc_html_e( 'View All Projects', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</a>
					<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=mcp_ai_project' ) ); ?>" class="button">
						<?php esc_html_e( 'Add New Project', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</a>
					<button type="button" class="button refresh-quality-data">
						<span class="dashicons dashicons-update"></span>
						<?php esc_html_e( 'Refresh Data', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</button>
				</p>
			</div>
		</div>
		<?php
	}
}

// Initialize.
WP_MCP_AI_Project_Research_Page::init();
