<?php
/**
 * ECA Settings Page
 *
 * Provides settings page for configuring AI provider, model, and assistant
 * for ECA Research & Add functionality.
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load base class.
require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-cpt-settings-page-base.php';

/**
 * ECA Settings Page
 */
class WP_MCP_AI_ECA_Settings_Page extends WP_MCP_AI_CPT_Settings_Page_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->option_name = 'wp_mcp_ai_eca_settings';
		$this->post_type   = 'mcp_ai_eca';
		$this->page_title  = __( 'ECA Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->menu_title  = __( 'Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->page_slug   = 'eca-settings';

		// Call parent constructor to set up hooks.
		parent::__construct();
	}

	/**
	 * Render overview tab.
	 *
	 * @since 1.2.0
	 */
	protected function render_overview_tab() {
		?>
		<h2><?php esc_html_e( 'Extra-Curricular Activities (ECA) Toolkit Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
		
		<p><?php esc_html_e( 'Comprehensive toolkit for managing school extra-curricular activities including creation, enrollment, research, and iSAMS integration.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

		<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Activity Management: Create, update, and track extra-curricular activities', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Student Enrollment: Manage student enrollments and participation tracking', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'AI Research: Discover new activity ideas and program structures', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'iSAMS Integration: Sync activities from iSAMS school management system', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Activity Analytics: Track participation rates and activity popularity', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
		</ul>

		<h3><?php esc_html_e( 'Use Cases', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Schools managing clubs, sports teams, and after-school programs', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Enrichment program coordinators planning new activities', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Educational institutions syncing with iSAMS', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
		</ul>
		<?php
	}

	/**
	 * Get tools list.
	 *
	 * @since 1.2.0
	 * @return array Tools list with slugs and names.
	 */
	protected function get_tools_list() {
		return array(
			'create_eca'           => __( 'Create ECA', 'nvdigital-open-operator-system-oos-pro' ),
			'list_ecas'            => __( 'List ECAs', 'nvdigital-open-operator-system-oos-pro' ),
			'get_eca'              => __( 'Get ECA', 'nvdigital-open-operator-system-oos-pro' ),
			'update_eca'           => __( 'Update ECA', 'nvdigital-open-operator-system-oos-pro' ),
			'delete_eca'           => __( 'Delete ECA', 'nvdigital-open-operator-system-oos-pro' ),
			'enroll_student_eca'   => __( 'Enroll Student in ECA', 'nvdigital-open-operator-system-oos-pro' ),
			'research_eca'         => __( 'Research ECA', 'nvdigital-open-operator-system-oos-pro' ),
			'sync_ecas_from_isams' => __( 'Sync ECAs from iSAMS', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		// Call parent to register base fields (assistant).
		parent::register_settings();

		// Add ECA-specific settings.
		add_settings_field(
			'enable_research',
			__( 'Enable Research & Add', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_enable_research_field' ),
			$this->option_name,
			$this->option_name . '_section'
		);
	}

	/**
	 * Render enable research field.
	 */
	public function render_enable_research_field() {
		$options = get_option( $this->option_name, array() );
		$value   = isset( $options['enable_research'] ) ? (bool) $options['enable_research'] : true;

		?>
		<label>
			<input
				type="checkbox"
				name="<?php echo esc_attr( $this->option_name ); ?>[enable_research]"
				id="enable_research"
				value="1"
				<?php checked( $value, true ); ?>
			/>
			<?php esc_html_e( 'Enable the Research & Add page for ECA research', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</label>
		<p class="description">
			<?php esc_html_e( 'When enabled, users can access the Research & Add page to create extra-curricular activities using AI assistance.', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</p>
		<?php
	}

	/**
	 * Sanitize settings.
	 *
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public function sanitize_settings( $input ) {
		// Call parent sanitization for base fields.
		$sanitized = parent::sanitize_settings( $input );

		// Add ECA-specific sanitization.
		if ( isset( $input['enable_research'] ) ) {
			$sanitized['enable_research'] = (bool) $input['enable_research'];
		} else {
			$sanitized['enable_research'] = false;
		}

		return $sanitized;
	}
}

// Initialize.
new WP_MCP_AI_ECA_Settings_Page();
