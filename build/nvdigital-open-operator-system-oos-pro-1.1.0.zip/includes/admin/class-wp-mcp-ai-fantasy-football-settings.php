<?php
/**
 * Fantasy Football Settings Page
 *
 * Provides tabbed settings page for configuring AI assistant
 * and Fantasy Football toolkit preferences.
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load base class.
require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-cpt-settings-page-base.php';

/**
 * Fantasy Football Settings Page
 */
class WP_MCP_AI_Fantasy_Football_Settings extends WP_MCP_AI_CPT_Settings_Page_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->option_name = 'wp_mcp_ai_fantasy_football_settings';
		$this->post_type   = 'ff_team';
		$this->page_title  = __( 'Fantasy Football Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->menu_title  = __( 'Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->page_slug   = 'fantasy-football-settings';

		// Call parent constructor to set up hooks.
		parent::__construct();
	}

	/**
	 * Render overview tab.
	 *
	 * @since 1.2.0
	 */
	protected function render_overview_tab() {
		?>
		<h2><?php esc_html_e( 'Fantasy Football Toolkit Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
		
		<p><?php esc_html_e( 'Comprehensive fantasy football management system with Yahoo Fantasy Sports API integration, AI-powered team logo generation, league reports, and player research.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

		<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Yahoo Fantasy Sports Integration: Connect with Yahoo Fantasy Sports API to sync leagues, rosters, and player data', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'League Management: Track team standings, win/loss records, and points for/against', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Trade Analysis: AI-powered trade analyzer to evaluate potential trades', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Team Branding: Generate custom team logos with AI assistance', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'League Reports: Create comprehensive league reports with AI analysis', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Player Research: AI-powered player research and watchlist management', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
		</ul>

		<h3><?php esc_html_e( 'Use Cases', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Fantasy football league commissioners managing multiple leagues', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Sports enthusiasts tracking team performance and player stats', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Content creators producing fantasy football analysis and reports', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
		</ul>
		<?php
	}

	/**
	 * Get tools list.
	 *
	 * @since 1.2.0
	 * @return array Tools list with slugs and names.
	 */
	protected function get_tools_list() {
		return array(
			'yahoo_ff_auth'           => __( 'Yahoo Fantasy Sports Authentication', 'nvdigital-open-operator-system-oos-pro' ),
			'yahoo_ff_get_leagues'    => __( 'Get User Leagues', 'nvdigital-open-operator-system-oos-pro' ),
			'yahoo_ff_get_roster'     => __( 'Get Team Roster', 'nvdigital-open-operator-system-oos-pro' ),
			'yahoo_ff_get_player_stats' => __( 'Get Player Statistics', 'nvdigital-open-operator-system-oos-pro' ),
			'yahoo_ff_trade_analyzer' => __( 'Analyze Trade Proposals', 'nvdigital-open-operator-system-oos-pro' ),
			'yahoo_ff_league_standings' => __( 'Get League Standings', 'nvdigital-open-operator-system-oos-pro' ),
			'ff_generate_team_logo'   => __( 'Generate Team Logo', 'nvdigital-open-operator-system-oos-pro' ),
			'ff_create_league_report' => __( 'Create League Report', 'nvdigital-open-operator-system-oos-pro' ),
			'ff_player_research'      => __( 'Player Research & Watchlist', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		// Call parent to register base fields (assistant).
		parent::register_settings();

		// Add Yahoo API Credentials section.
		add_settings_section(
			$this->option_name . '_yahoo_api_section',
			__( 'Yahoo Fantasy Sports API', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_yahoo_api_section' ),
			$this->option_name
		);

		add_settings_field(
			'yahoo_client_id',
			__( 'Yahoo Client ID', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_text_field' ),
			$this->option_name,
			$this->option_name . '_yahoo_api_section',
			array(
				'id'          => 'yahoo_client_id',
				'placeholder' => __( 'Consumer Key from Yahoo Developer', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		add_settings_field(
			'yahoo_client_secret',
			__( 'Yahoo Client Secret', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_text_field' ),
			$this->option_name,
			$this->option_name . '_yahoo_api_section',
			array(
				'id'          => 'yahoo_client_secret',
				'type'        => 'password',
				'placeholder' => __( 'Consumer Secret from Yahoo Developer', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		// Default Preferences section.
		add_settings_section(
			$this->option_name . '_preferences_section',
			__( 'Default Preferences', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_preferences_section' ),
			$this->option_name
		);

		add_settings_field(
			'default_season',
			__( 'Default Season', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_text_field' ),
			$this->option_name,
			$this->option_name . '_preferences_section',
			array(
				'id'          => 'default_season',
				'type'        => 'number',
				'placeholder' => gmdate( 'Y' ),
			)
		);

		add_settings_field(
			'auto_sync',
			__( 'Auto-Sync Teams', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_checkbox_field' ),
			$this->option_name,
			$this->option_name . '_preferences_section',
			array(
				'id'          => 'auto_sync',
				'description' => __( 'Automatically sync team data from Yahoo daily', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		// Team Branding Defaults section.
		add_settings_section(
			$this->option_name . '_branding_section',
			__( 'Team Branding Defaults', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_branding_section' ),
			$this->option_name
		);

		add_settings_field(
			'default_logo_style',
			__( 'Default Logo Style', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_select_field' ),
			$this->option_name,
			$this->option_name . '_branding_section',
			array(
				'id'      => 'default_logo_style',
				'options' => array(
					'modern'     => __( 'Modern', 'nvdigital-open-operator-system-oos-pro' ),
					'classic'    => __( 'Classic', 'nvdigital-open-operator-system-oos-pro' ),
					'minimalist' => __( 'Minimalist', 'nvdigital-open-operator-system-oos-pro' ),
					'mascot'     => __( 'Mascot', 'nvdigital-open-operator-system-oos-pro' ),
					'emblem'     => __( 'Emblem', 'nvdigital-open-operator-system-oos-pro' ),
				),
			)
		);

		add_settings_field(
			'default_team_color',
			__( 'Default Team Color', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_color_field' ),
			$this->option_name,
			$this->option_name . '_branding_section',
			array(
				'id' => 'default_team_color',
			)
		);

		// Report Preferences section.
		add_settings_section(
			$this->option_name . '_report_section',
			__( 'Report Preferences', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_report_section' ),
			$this->option_name
		);

		add_settings_field(
			'include_charts_default',
			__( 'Include Charts', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_checkbox_field' ),
			$this->option_name,
			$this->option_name . '_report_section',
			array(
				'id'          => 'include_charts_default',
				'description' => __( 'Include Chart.js visualizations in reports by default', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);

		add_settings_field(
			'include_analysis_default',
			__( 'Include AI Analysis', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_checkbox_field' ),
			$this->option_name,
			$this->option_name . '_report_section',
			array(
				'id'          => 'include_analysis_default',
				'description' => __( 'Include AI-powered insights in reports by default', 'nvdigital-open-operator-system-oos-pro' ),
			)
		);
	}

	/**
	 * Render Yahoo API section description.
	 */
	public function render_yahoo_api_section() {
		?>
		<p>
			<?php
			printf(
				/* translators: %s: Yahoo Developer URL */
				esc_html__( 'Enter your Yahoo Fantasy Sports API credentials. Get them from %s.', 'nvdigital-open-operator-system-oos-pro' ),
				'<a href="https://developer.yahoo.com/apps/" target="_blank">Yahoo Developer Network</a>'
			);
			?>
		</p>
		<?php
	}

	/**
	 * Render preferences section description.
	 */
	public function render_preferences_section() {
		?>
		<p><?php esc_html_e( 'Configure default preferences for fantasy football management.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
		<?php
	}

	/**
	 * Render branding section description.
	 */
	public function render_branding_section() {
		?>
		<p><?php esc_html_e( 'Set default branding options for new team logos and graphics.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
		<?php
	}

	/**
	 * Render report section description.
	 */
	public function render_report_section() {
		?>
		<p><?php esc_html_e( 'Configure default options for league reports.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
		<?php
	}

	/**
	 * Render text field.
	 *
	 * @param array $args Field arguments.
	 */
	public function render_text_field( $args ) {
		$settings    = get_option( $this->option_name, array() );
		$value       = isset( $settings[ $args['id'] ] ) ? $settings[ $args['id'] ] : '';
		$type        = isset( $args['type'] ) ? $args['type'] : 'text';
		$placeholder = isset( $args['placeholder'] ) ? $args['placeholder'] : '';
		?>
		<input 
			type="<?php echo esc_attr( $type ); ?>" 
			id="<?php echo esc_attr( $args['id'] ); ?>" 
			name="<?php echo esc_attr( $this->option_name . '[' . $args['id'] . ']' ); ?>" 
			value="<?php echo esc_attr( $value ); ?>" 
			placeholder="<?php echo esc_attr( $placeholder ); ?>"
			class="regular-text"
		/>
		<?php
	}

	/**
	 * Render checkbox field.
	 *
	 * @param array $args Field arguments.
	 */
	public function render_checkbox_field( $args ) {
		$settings    = get_option( $this->option_name, array() );
		$value       = isset( $settings[ $args['id'] ] ) ? $settings[ $args['id'] ] : false;
		$description = isset( $args['description'] ) ? $args['description'] : '';
		?>
		<label>
			<input 
				type="checkbox" 
				id="<?php echo esc_attr( $args['id'] ); ?>" 
				name="<?php echo esc_attr( $this->option_name . '[' . $args['id'] . ']' ); ?>" 
				value="1"
				<?php checked( $value, true ); ?>
			/>
			<?php echo esc_html( $description ); ?>
		</label>
		<?php
	}

	/**
	 * Render select field.
	 *
	 * @param array $args Field arguments.
	 */
	public function render_select_field( $args ) {
		$settings = get_option( $this->option_name, array() );
		$value    = isset( $settings[ $args['id'] ] ) ? $settings[ $args['id'] ] : '';
		?>
		<select 
			id="<?php echo esc_attr( $args['id'] ); ?>" 
			name="<?php echo esc_attr( $this->option_name . '[' . $args['id'] . ']' ); ?>"
		>
			<option value=""><?php esc_html_e( '-- Select --', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
			<?php foreach ( $args['options'] as $option_value => $option_label ) : ?>
				<option value="<?php echo esc_attr( $option_value ); ?>" <?php selected( $value, $option_value ); ?>>
					<?php echo esc_html( $option_label ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	/**
	 * Render color field.
	 *
	 * @param array $args Field arguments.
	 */
	public function render_color_field( $args ) {
		$settings = get_option( $this->option_name, array() );
		$value    = isset( $settings[ $args['id'] ] ) ? $settings[ $args['id'] ] : '#000000';
		?>
		<input 
			type="color" 
			id="<?php echo esc_attr( $args['id'] ); ?>" 
			name="<?php echo esc_attr( $this->option_name . '[' . $args['id'] . ']' ); ?>" 
			value="<?php echo esc_attr( $value ); ?>"
		/>
		<?php
	}

	/**
	 * Sanitize settings.
	 *
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public function sanitize_settings( $input ) {
		$sanitized = parent::sanitize_settings( $input );

		// Text fields.
		$text_fields = array( 'yahoo_client_id', 'yahoo_client_secret', 'default_season', 'default_logo_style' );
		foreach ( $text_fields as $field ) {
			if ( isset( $input[ $field ] ) ) {
				$sanitized[ $field ] = sanitize_text_field( $input[ $field ] );
			}
		}

		// Checkbox fields.
		$checkbox_fields = array( 'auto_sync', 'include_charts_default', 'include_analysis_default' );
		foreach ( $checkbox_fields as $field ) {
			$sanitized[ $field ] = isset( $input[ $field ] ) && '1' === $input[ $field ];
		}

		// Color field.
		if ( isset( $input['default_team_color'] ) ) {
			$sanitized['default_team_color'] = sanitize_hex_color( $input['default_team_color'] );
		}

		return $sanitized;
	}

	/**
	 * Get a specific setting value.
	 *
	 * @param string $key           Setting key.
	 * @param mixed  $default_value Default value if not set.
	 * @return mixed Setting value.
	 */
	public static function get_setting( $key, $default_value = null ) {
		$settings = get_option( 'wp_mcp_ai_fantasy_football_settings', array() );
		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default_value;
	}
}
