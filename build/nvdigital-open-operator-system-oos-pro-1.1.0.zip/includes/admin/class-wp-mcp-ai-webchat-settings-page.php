<?php
/**
 * WebChat Settings Page
 *
 * Provides settings page for configuring AI provider, model, and assistant
 * for WebChat functionality.
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load base class.
require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-cpt-settings-page-base.php';

/**
 * WebChat Settings Page
 */
class WP_MCP_AI_WebChat_Settings_Page extends WP_MCP_AI_CPT_Settings_Page_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->option_name = 'wp_mcp_ai_webchat_settings';
		$this->post_type   = 'mcp_ai_webchat';
		$this->page_title  = __( 'WebChat Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->menu_title  = __( 'Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->page_slug   = 'webchat-settings';

		// Call parent constructor to set up hooks.
		parent::__construct();
	}

	/**
	 * Render overview tab.
	 *
	 * @since 1.2.0
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview" style="max-width: 1200px;">
			<h2><?php esc_html_e( 'WebChat Toolkit Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<p><?php esc_html_e( 'Real-time WebRTC-based peer-to-peer video chat integration with room management, participant tracking, and anonymous chat support. Enables decentralized, serverless chat directly on your WordPress site.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

			<div class="toolkit-card" style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin: 20px 0;">
				<h3><?php esc_html_e( '🚀 Quick Start Guide', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				
				<h4><?php esc_html_e( 'Step 1: Enable WebChat Integration', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
				<p>
					<?php
					$settings_url = admin_url( 'admin.php?page=wp_mcp_ai_settings&tab=tools' );
					echo wp_kses_post(
						sprintf(
							/* translators: %s: Link to settings page */
							__( 'Go to <a href="%s">Settings → NV oOS → Tools & Features</a>, click the <strong>Features</strong> tab, check <strong>"Enable WebChat Integration"</strong>, and save your changes.', 'nvdigital-open-operator-system-oos-pro' ),
							esc_url( $settings_url )
						)
					);
					?>
				</p>

				<h4><?php esc_html_e( 'Step 2: Create a WebChat Room', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
				<p>
					<?php
					$add_room_url = admin_url( 'post-new.php?post_type=mcp_ai_webchat' );
					echo wp_kses_post(
						sprintf(
							/* translators: %s: Link to add room page */
							__( '<a href="%s">Create a new WebChat Room</a> with a title, description, and optional settings like max participants and signaling server URL.', 'nvdigital-open-operator-system-oos-pro' ),
							esc_url( $add_room_url )
						)
					);
					?>
				</p>

				<h4><?php esc_html_e( 'Step 3: Configure Room Settings', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
				<p><?php esc_html_e( 'In the Room Details metabox, configure:', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Room ID:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Auto-generated unique identifier for the chat room', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Max Participants:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Set capacity limit (2-100)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Signaling Server:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'WebSocket URL for WebRTC signaling (optional)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Status:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Active, Inactive, or Archived', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>
			</div>

			<div class="toolkit-card" style="background: #f8f9fa; border: 1px solid #ccd0d4; padding: 20px; margin: 20px 0;">
				<h3><?php esc_html_e( '📋 Configuration Options', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				
				<h4><?php esc_html_e( 'Default Settings', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
				<p><?php esc_html_e( 'Configure global defaults in the Settings tab above:', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Default Signaling Server URL:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Sets default WebSocket URL for all new rooms', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Default Max Participants:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Default capacity for new rooms', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Enable Anonymous Chat:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Allow non-authenticated users to join rooms', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Enable WebChat Integration:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Master switch for WebChat features', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>

				<h4><?php esc_html_e( 'Room Configuration Example', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
				<pre style="background: #fff; padding: 15px; border: 1px solid #ddd; overflow-x: auto; font-size: 13px;">
<strong><?php esc_html_e( 'Room Title:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Product Demo Meeting', 'nvdigital-open-operator-system-oos-pro' ); ?>

<strong><?php esc_html_e( 'Room Description:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
<?php esc_html_e( 'Interactive product demonstration and Q&A session for potential customers.', 'nvdigital-open-operator-system-oos-pro' ); ?>


<strong><?php esc_html_e( 'Room Settings:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
- <?php esc_html_e( 'Max Participants: 20', 'nvdigital-open-operator-system-oos-pro' ); ?>

- <?php esc_html_e( 'Signaling Server: wss://signaling.yoursite.com', 'nvdigital-open-operator-system-oos-pro' ); ?>

- <?php esc_html_e( 'Status: Active', 'nvdigital-open-operator-system-oos-pro' ); ?>

- <?php esc_html_e( 'Anonymous Access: Enabled', 'nvdigital-open-operator-system-oos-pro' ); ?></pre>
			</div>

			<div class="toolkit-card" style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin: 20px 0;">
				<h3><?php esc_html_e( '🔧 AI Integration', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<p><?php esc_html_e( 'AI assistants can interact with WebChat rooms using the following tools:', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
				
				<h4><code>send_webchat_message</code></h4>
				<p><?php esc_html_e( 'Send AI-generated messages to WebChat rooms for moderation, automated responses, or announcements.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
				<pre style="background: #f8f9fa; padding: 15px; border: 1px solid #ddd; overflow-x: auto; font-size: 13px;">
{
  "room_id": "abc123xyz",
  "message": "Welcome! I'm an AI assistant here to help.",
  "sender_name": "Support Bot"
}</pre>

				<h4><code>create_webchat_room</code></h4>
				<p><?php esc_html_e( 'AI can dynamically create rooms based on user requests.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
				<pre style="background: #f8f9fa; padding: 15px; border: 1px solid #ddd; overflow-x: auto; font-size: 13px;">
{
  "title": "Team Standup - Jan 15",
  "description": "Daily team sync meeting",
  "max_participants": 10,
  "status": "active"
}</pre>

				<h4><code>list_webchat_rooms</code></h4>
				<p><?php esc_html_e( 'AI can list available rooms to help users find active chats.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

				<h4><code>get_webchat_room</code></h4>
				<p><?php esc_html_e( 'Retrieve details about a specific room, including participant count.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

				<h4><code>get_webchat_status</code></h4>
				<p><?php esc_html_e( 'Monitor room status and participant activity in real-time.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
			</div>

			<div class="toolkit-card" style="background: #fff3cd; border: 1px solid #ffc107; padding: 20px; margin: 20px 0;">
				<h3><?php esc_html_e( '⚠️ Requirements', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<ul>
					<li>
						<strong><?php esc_html_e( 'Browser Extension:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
						<?php
						echo wp_kses_post(
							sprintf(
								/* translators: %s: WebChat GitHub URL */
								__( ' Users need the <a href="%s" target="_blank">WebChat browser extension</a> to participate in P2P chat rooms.', 'nvdigital-open-operator-system-oos-pro' ),
								'https://github.com/molvqingtai/WebChat'
							)
						);
						?>
					</li>
					<li>
						<strong><?php esc_html_e( 'HTTPS:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
						<?php esc_html_e( ' WebRTC requires a secure HTTPS connection for video/audio streaming.', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</li>
					<li>
						<strong><?php esc_html_e( 'Modern Browser:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
						<?php esc_html_e( ' Chrome, Firefox, Safari, or Edge with WebRTC support.', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</li>
					<li>
						<strong><?php esc_html_e( 'Signaling Server (Optional):', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
						<?php esc_html_e( ' Custom WebSocket server for advanced signaling control.', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</li>
				</ul>
			</div>

			<div class="toolkit-card" style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin: 20px 0;">
				<h3><?php esc_html_e( '✨ Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<ul>
					<li><strong><?php esc_html_e( 'Decentralized Chat:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Peer-to-peer WebRTC communication without server-side message storage', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Room Management:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Create and manage multiple chat rooms with custom settings', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'WebRTC Video/Audio:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Browser-based video and audio communication', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Participant Tracking:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Monitor active participants and enforce room capacity', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Anonymous Access:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Optional anonymous access for public rooms', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Privacy-First:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' End-to-end encrypted peer-to-peer messages', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'AI-Powered Moderation:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' AI assistants can send messages and moderate rooms', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>
			</div>

			<div class="toolkit-card" style="background: #f8f9fa; border: 1px solid #ccd0d4; padding: 20px; margin: 20px 0;">
				<h3><?php esc_html_e( '💼 Use Cases', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<ul>
					<li><strong><?php esc_html_e( 'Virtual Meetings:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Team collaboration and remote standups', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Online Tutoring:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' One-on-one or group educational sessions', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Customer Support:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Live video consultation and troubleshooting', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Community Events:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Webinars, Q&A sessions, and virtual meetups', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Product Demos:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Interactive product demonstrations for prospects', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Healthcare:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( ' Telemedicine and remote patient consultations', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>
			</div>

			<div class="toolkit-card" style="background: #e7f3ff; border: 1px solid #007cba; padding: 20px; margin: 20px 0;">
				<h3><?php esc_html_e( '🔐 Privacy & Security', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<ul>
					<li><?php esc_html_e( 'Messages are transmitted peer-to-peer and not stored on servers', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'WebRTC provides end-to-end encryption for all communications', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Room IDs are unique and difficult to guess', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Optional authentication controls via WordPress user accounts', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Participant capacity limits prevent room flooding', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>
			</div>

			<div class="toolkit-card" style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin: 20px 0;">
				<h3><?php esc_html_e( '📚 Learn More', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<ul>
					<li>
						<?php
						echo wp_kses_post(
							sprintf(
								/* translators: %s: WebChat GitHub URL */
								__( '<a href="%s" target="_blank">WebChat Browser Extension Documentation</a>', 'nvdigital-open-operator-system-oos-pro' ),
								'https://github.com/molvqingtai/WebChat'
							)
						);
						?>
					</li>
					<li>
						<?php
						echo wp_kses_post(
							sprintf(
								/* translators: %s: WebRTC info URL */
								__( '<a href="%s" target="_blank">Learn about WebRTC Technology</a>', 'nvdigital-open-operator-system-oos-pro' ),
								'https://webrtc.org/'
							)
						);
						?>
					</li>
					<li>
						<?php
						$tools_tab_url = add_query_arg( 'tab', 'tools' );
						echo wp_kses_post(
							sprintf(
								/* translators: %s: Tools tab URL */
								__( '<a href="%s">View Available WebChat Tools</a>', 'nvdigital-open-operator-system-oos-pro' ),
								esc_url( $tools_tab_url )
							)
						);
						?>
					</li>
				</ul>
			</div>
		</div>
		<?php
	}

	/**
	 * Get tools list.
	 *
	 * @since 1.2.0
	 * @return array Tools list with slugs and names.
	 */
	protected function get_tools_list() {
		return array(
			'create_webchat_room' => __( 'Create WebChat Room', 'nvdigital-open-operator-system-oos-pro' ),
			'list_webchat_rooms'  => __( 'List WebChat Rooms', 'nvdigital-open-operator-system-oos-pro' ),
			'get_webchat_room'    => __( 'Get WebChat Room', 'nvdigital-open-operator-system-oos-pro' ),
			'get_webchat_status'  => __( 'Get WebChat Status', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		// Call parent to register base fields (assistant).
		parent::register_settings();

		// Add WebChat-specific settings section.
		add_settings_section(
			$this->option_name . '_defaults_section',
			__( 'Default WebChat Settings', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_defaults_section_description' ),
			$this->option_name
		);

		add_settings_field(
			'default_signaling_server',
			__( 'Default Signaling Server URL', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_default_signaling_server_field' ),
			$this->option_name,
			$this->option_name . '_defaults_section'
		);

		add_settings_field(
			'default_max_participants',
			__( 'Default Max Participants', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_default_max_participants_field' ),
			$this->option_name,
			$this->option_name . '_defaults_section'
		);

		add_settings_field(
			'enable_anonymous_chat',
			__( 'Enable Anonymous Chat', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_enable_anonymous_chat_field' ),
			$this->option_name,
			$this->option_name . '_defaults_section'
		);

		add_settings_field(
			'enable_webchat_integration',
			__( 'Enable WebChat Integration', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_enable_webchat_integration_field' ),
			$this->option_name,
			$this->option_name . '_defaults_section'
		);
	}

	/**
	 * Render defaults section description.
	 */
	public function render_defaults_section_description() {
		echo '<p>' . esc_html__( 'Configure default values for WebChat rooms.', 'nvdigital-open-operator-system-oos-pro' ) . '</p>';
	}

	/**
	 * Render default signaling server field.
	 */
	public function render_default_signaling_server_field() {
		$options = get_option( $this->option_name, array() );
		$value   = isset( $options['default_signaling_server'] ) ? esc_url( $options['default_signaling_server'] ) : '';

		?>
		<input
			type="url"
			name="<?php echo esc_attr( $this->option_name ); ?>[default_signaling_server]"
			id="default_signaling_server"
			value="<?php echo esc_attr( $value ); ?>"
			class="regular-text"
			placeholder="wss://signaling.example.com"
		/>
		<p class="description">
			<?php esc_html_e( 'Default WebSocket URL for WebRTC signaling server.', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</p>
		<?php
	}

	/**
	 * Render default max participants field.
	 */
	public function render_default_max_participants_field() {
		$options = get_option( $this->option_name, array() );
		$value   = isset( $options['default_max_participants'] ) ? absint( $options['default_max_participants'] ) : 10;

		?>
		<input
			type="number"
			name="<?php echo esc_attr( $this->option_name ); ?>[default_max_participants]"
			id="default_max_participants"
			value="<?php echo esc_attr( $value ); ?>"
			min="2"
			max="100"
			step="1"
			class="regular-text"
		/>
		<p class="description">
			<?php esc_html_e( 'Maximum number of participants allowed in a room. Must be between 2 and 100.', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</p>
		<?php
	}

	/**
	 * Render enable anonymous chat field.
	 */
	public function render_enable_anonymous_chat_field() {
		$options = get_option( $this->option_name, array() );
		$value   = isset( $options['enable_anonymous_chat'] ) ? (bool) $options['enable_anonymous_chat'] : false;

		?>
		<label>
			<input
				type="checkbox"
				name="<?php echo esc_attr( $this->option_name ); ?>[enable_anonymous_chat]"
				id="enable_anonymous_chat"
				value="1"
				<?php checked( $value, true ); ?>
			/>
			<?php esc_html_e( 'Allow anonymous users to join chat rooms', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</label>
		<p class="description">
			<?php esc_html_e( 'When enabled, rooms can allow anonymous participants without WordPress authentication.', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</p>
		<?php
	}

	/**
	 * Render enable webchat integration field.
	 */
	public function render_enable_webchat_integration_field() {
		$options = get_option( $this->option_name, array() );
		$value   = isset( $options['enable_webchat_integration'] ) ? (bool) $options['enable_webchat_integration'] : false;

		?>
		<label>
			<input
				type="checkbox"
				name="<?php echo esc_attr( $this->option_name ); ?>[enable_webchat_integration]"
				id="enable_webchat_integration"
				value="1"
				<?php checked( $value, true ); ?>
			/>
			<?php esc_html_e( 'Enable WebChat tools and room management', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</label>
		<p class="description">
			<?php esc_html_e( 'When enabled, AI assistants can create and manage WebChat rooms.', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</p>
		<?php
	}

	/**
	 * Sanitize settings.
	 *
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public function sanitize_settings( $input ) {
		// Call parent sanitization for base fields.
		$sanitized = parent::sanitize_settings( $input );

		// Add WebChat-specific sanitization.
		if ( isset( $input['default_signaling_server'] ) ) {
			$sanitized['default_signaling_server'] = esc_url_raw( $input['default_signaling_server'] );
		}

		if ( isset( $input['default_max_participants'] ) ) {
			$max_participants                         = absint( $input['default_max_participants'] );
			$sanitized['default_max_participants'] = max( 2, min( 100, $max_participants ) );
		}

		if ( isset( $input['enable_anonymous_chat'] ) ) {
			$sanitized['enable_anonymous_chat'] = (bool) $input['enable_anonymous_chat'];
		} else {
			// Checkbox not checked.
			$sanitized['enable_anonymous_chat'] = false;
		}

		if ( isset( $input['enable_webchat_integration'] ) ) {
			$sanitized['enable_webchat_integration'] = (bool) $input['enable_webchat_integration'];
		} else {
			// Checkbox not checked.
			$sanitized['enable_webchat_integration'] = false;
		}

		return $sanitized;
	}
}

// Initialize.
new WP_MCP_AI_WebChat_Settings_Page();
