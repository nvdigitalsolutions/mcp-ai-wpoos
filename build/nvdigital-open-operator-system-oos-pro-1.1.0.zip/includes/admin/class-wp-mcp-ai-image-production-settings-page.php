<?php
/**
 * Image Production Toolkit Settings Page
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-toolkit-settings-base.php';

/**
 * Image Production Toolkit Settings Page Class
 */
class WP_MCP_AI_Image_Production_Settings_Page extends WP_MCP_AI_Toolkit_Settings_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->toolkit_slug     = 'image_production';
		$this->toolkit_name     = __( 'Image Production Toolkit', 'nvdigital-open-operator-system-oos-pro' );
		$this->option_name      = 'wp_mcp_ai_image_production_toolkit_settings';
		$this->page_slug        = 'wp-mcp-ai-image-production-toolkit-settings';
		$this->has_research     = true;
		$this->has_remote_sites = true;
		$this->icon             = 'dashicons-format-image';

		parent::__construct();
	}

	/**
	 * Get toolkit slug
	 *
	 * @return string
	 */
	protected function get_toolkit_slug() {
		return $this->toolkit_slug;
	}

	/**
	 * Get toolkit name
	 *
	 * @return string
	 */
	protected function get_toolkit_name() {
		return $this->toolkit_name;
	}

	/**
	 * Render overview tab
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-overview">
			<h2><?php esc_html_e( 'Image Production Toolkit Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'AI-powered image creation and editing toolkit with 15 professional tools for generating, enhancing, and optimizing images.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'AI Image Generation: Create images from text descriptions using DALL-E, Midjourney, or Stable Diffusion', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Background Removal: Automatically remove backgrounds from product photos', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Upscaling: Enhance image resolution using AI-powered upscaling', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Batch Processing: Apply transformations to multiple images at once', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Style Transfer: Apply artistic styles to existing images', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Format Conversion: Convert between formats and optimize for web delivery', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render configuration tab
	 */
	protected function render_configuration_tab() {
		?>
		<div class="toolkit-configuration">
			<h2><?php esc_html_e( 'Image Production Toolkit Configuration', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Image Generator', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<select name="default_image_generator" class="regular-text">
							<option value="dalle">DALL-E</option>
							<option value="midjourney">Midjourney</option>
							<option value="stable_diffusion">Stable Diffusion</option>
						</select>
						<p class="description"><?php esc_html_e( 'Default AI service for image generation', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Default Output Format', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<select name="default_output_format" class="regular-text">
							<option value="jpg">JPEG</option>
							<option value="png">PNG</option>
							<option value="webp">WebP</option>
						</select>
						<p class="description"><?php esc_html_e( 'Default format for processed images', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Max Image Dimensions', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
					<td>
						<input type="number" name="max_image_width" value="2048" min="100" class="small-text" />
						<span>×</span>
						<input type="number" name="max_image_height" value="2048" min="100" class="small-text" />
						<span>px</span>
						<p class="description"><?php esc_html_e( 'Maximum dimensions for generated images', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/**
	 * Get tools list
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'generate_image_ai'              => __( 'Generate Image (AI)', 'nvdigital-open-operator-system-oos-pro' ),
			'generate_image_variations'      => __( 'Generate Image Variations', 'nvdigital-open-operator-system-oos-pro' ),
			'image_inpainting'               => __( 'Image Inpainting', 'nvdigital-open-operator-system-oos-pro' ),
			'text_to_image_prompt_optimizer' => __( 'Text to Image Prompt Optimizer', 'nvdigital-open-operator-system-oos-pro' ),
			'remove_image_background'        => __( 'Remove Image Background', 'nvdigital-open-operator-system-oos-pro' ),
			'upscale_image_ai'               => __( 'Upscale Image (AI)', 'nvdigital-open-operator-system-oos-pro' ),
			'enhance_image_quality'          => __( 'Enhance Image Quality', 'nvdigital-open-operator-system-oos-pro' ),
			'apply_artistic_style'           => __( 'Apply Artistic Style', 'nvdigital-open-operator-system-oos-pro' ),
			'colorize_image'                 => __( 'Colorize Image', 'nvdigital-open-operator-system-oos-pro' ),
			'compress_image'                 => __( 'Compress Image', 'nvdigital-open-operator-system-oos-pro' ),
			'convert_image_format'           => __( 'Convert Image Format', 'nvdigital-open-operator-system-oos-pro' ),
			'resize_image_smart'             => __( 'Resize Image (Smart)', 'nvdigital-open-operator-system-oos-pro' ),
			'batch_process_images'           => __( 'Batch Process Images', 'nvdigital-open-operator-system-oos-pro' ),
			'generate_responsive_images'     => __( 'Generate Responsive Images', 'nvdigital-open-operator-system-oos-pro' ),
			'optimize_for_web'               => __( 'Optimize for Web', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}
}

// Initialize settings page.
if ( is_admin() ) {
	new WP_MCP_AI_Image_Production_Settings_Page();
}
