<?php
/**
 * Event Settings Page
 *
 * Provides settings page for configuring AI provider, model, and assistant
 * for Event Management functionality.
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load base class.
require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-cpt-settings-page-base.php';

/**
 * Event Settings Page
 */
class WP_MCP_AI_Event_Settings_Page extends WP_MCP_AI_CPT_Settings_Page_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->option_name = 'wp_mcp_ai_event_settings';
		$this->post_type   = 'mcp_ai_event';
		$this->page_title  = __( 'Event Management Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->menu_title  = __( 'Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->page_slug   = 'event-settings';

		// Call parent constructor to set up hooks.
		parent::__construct();
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		// Call parent to register base fields (assistant).
		parent::register_settings();

		// Add event-specific settings.
		add_settings_field(
			'enable_research',
			__( 'Enable Research & Add', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_enable_research_field' ),
			$this->option_name,
			$this->option_name . '_section'
		);
	}

	/**
	 * Render enable research field.
	 */
	public function render_enable_research_field() {
		$options = get_option( $this->option_name, array() );
		$value   = isset( $options['enable_research'] ) ? (bool) $options['enable_research'] : true;

		?>
		<label>
			<input
				type="checkbox"
				name="<?php echo esc_attr( $this->option_name ); ?>[enable_research]"
				id="enable_research"
				value="1"
				<?php checked( $value, true ); ?>
			/>
			<?php esc_html_e( 'Enable the Research & Add page for event research', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</label>
		<p class="description">
			<?php esc_html_e( 'When enabled, users can access the Research & Add page to create events using AI assistance.', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</p>
		<?php
	}

	/**
	 * Render overview tab.
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-card">
			<h2><?php esc_html_e( 'Event Management Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'AI-powered event creation and management system. Plan, organize, and manage events with AI assistance for venue selection, scheduling, and attendee management.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Event Planning: AI-assisted event planning and organization', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Venue Management: Find and manage event venues', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Calendar Integration: Sync events with calendars (iCal/Google)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Attendee Management: Track and manage event attendees', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Real-time Tracking: Track event metrics and attendance', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Research & Add: AI-powered event research and creation', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Get tools list for this CPT.
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'create_event'                => __( 'Create Event', 'nvdigital-open-operator-system-oos-pro' ),
			'update_event'                => __( 'Update Event', 'nvdigital-open-operator-system-oos-pro' ),
			'get_events'                  => __( 'Get Events', 'nvdigital-open-operator-system-oos-pro' ),
			'delete_event'                => __( 'Delete Event', 'nvdigital-open-operator-system-oos-pro' ),
			'real_time_event_tracking'    => __( 'Real-time Event Tracking', 'nvdigital-open-operator-system-oos-pro' ),
			'create_event_booking'        => __( 'Create Event Booking (DJ)', 'nvdigital-open-operator-system-oos-pro' ),
			'update_event_details'        => __( 'Update Event Details (DJ)', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Render section description.
	 */
	public function render_section_description() {
		echo '<p>' . esc_html__( 'Configure the AI assistant for Event Management AI features.', 'nvdigital-open-operator-system-oos-pro' ) . '</p>';
	}

	/**
	 * Sanitize settings.
	 *
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public function sanitize_settings( $input ) {
		// Call parent sanitization for base fields.
		$sanitized = parent::sanitize_settings( $input );

		// Add event-specific sanitization.
		if ( isset( $input['enable_research'] ) ) {
			$sanitized['enable_research'] = (bool) $input['enable_research'];
		} else {
			$sanitized['enable_research'] = false;
		}

		return $sanitized;
	}
}

// Initialize.
new WP_MCP_AI_Event_Settings_Page();
