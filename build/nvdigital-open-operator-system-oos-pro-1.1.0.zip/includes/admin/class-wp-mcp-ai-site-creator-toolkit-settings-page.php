<?php
/**
 * Site Creator Toolkit Settings Page
 *
 * Admin page for configuring the Site Creator toolkit with page/section/widget builders,
 * template management, and Architect Agent integration.
 *
 * @package WP_MCP_AI
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Site Creator Toolkit Settings Page
 *
 * Provides configuration options for the Site Creator toolkit including:
 * - Research and discovery tools
 * - Page builder capabilities
 * - Section builder tools
 * - Widget builder features
 * - Template management
 * - Architect Agent integration
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Site_Creator_Toolkit_Settings_Page {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_settings_page' ), 20 );
	}

	/**
	 * Add settings page to admin menu.
	 *
	 * @since 1.2.0
	 */
	public function add_settings_page() {
		// Add top-level menu page for Site Creator.
		add_menu_page(
			__( 'Site Creator', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Site Creator', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_options',
			'nvoos-site-creator',
			array( $this, 'render_settings_page' ),
			'dashicons-admin-site-alt3',
			31
		);

		// Remove the auto-generated submenu item (has same title as top-level menu).
		remove_submenu_page( 'nvoos-site-creator', 'nvoos-site-creator' );

		// Add submenu items for Site Creator.
		add_submenu_page(
			'nvoos-site-creator',
			__( 'Overview', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Overview', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_options',
			'nvoos-site-creator',
			array( $this, 'render_settings_page' )
		);

		add_submenu_page(
			'nvoos-site-creator',
			__( 'Tools', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Tools', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_options',
			'nvoos-site-creator-tools',
			array( $this, 'render_tools_page' )
		);

		add_submenu_page(
			'nvoos-site-creator',
			__( 'Templates', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Templates', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_options',
			'nvoos-site-creator-templates',
			array( $this, 'render_templates_page' )
		);

		add_submenu_page(
			'nvoos-site-creator',
			__( 'Research & Add', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Research & Add', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_options',
			'nvoos-site-creator-research',
			array( $this, 'render_research_page' )
		);

		add_submenu_page(
			'nvoos-site-creator',
			__( 'Consolidate & Add', 'nvdigital-open-operator-system-oos-pro' ),
			__( 'Consolidate & Add', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_options',
			'nvoos-site-creator-consolidate',
			array( $this, 'render_consolidate_page' )
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.2.0
	 */
	public function render_settings_page() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Site Creator Toolkit', 'nvdigital-open-operator-system-oos-pro' ); ?></h1>

			<div class="card">
				<h2><?php esc_html_e( 'About Site Creator Toolkit', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p>
					<?php
					esc_html_e(
						'The Site Creator Toolkit provides advanced AI-powered tools for automated WordPress site creation, following industry best practices and modern standards. It integrates with the Architect Agent for self-editing capabilities and automated development workflows.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>

				<h3><?php esc_html_e( 'Available Tool Categories', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<ul>
					<li><strong><?php esc_html_e( 'Research & Discovery (4 tools)', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> - <?php esc_html_e( 'Web search for best practices, competitor analysis, site planning, template suggestions', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Page Building (5 tools)', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> - <?php esc_html_e( 'Landing pages, homepage layouts, about pages, service pages, blog layouts', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Section Building (6 tools)', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> - <?php esc_html_e( 'Hero sections, features, testimonials, CTAs, galleries, contact sections', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Widget Building (4 tools)', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> - <?php esc_html_e( 'Custom widgets, navigation menus, sidebar widgets, footer widgets', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Template Management (4 tools)', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> - <?php esc_html_e( 'Save/import/export templates, version control', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Integration Tools (3 tools)', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> - <?php esc_html_e( 'Architect Agent integration, theme scaffolding, automated workflows', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<ul>
					<li><?php esc_html_e( 'Industry best practices from 2025 web standards', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Performance optimization (Core Web Vitals)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Accessibility compliance (WCAG 2.2)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Mobile-first responsive design', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'SEO optimization', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'AI-enhanced workflows', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Block-based design (Gutenberg compatible)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Elementor integration', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Integration with Architect Agent', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<p>
					<?php
					esc_html_e(
						'When enabled, the Site Creator Toolkit integrates with the Architect Agent to provide:',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>
				<ul>
					<li><?php esc_html_e( 'Automated code generation (PHP, CSS, JavaScript)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Self-editing capabilities for generated code', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Version control integration (Git)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Quality assurance checks (linting, testing)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Automated development workflows', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Documentation', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<p>
					<?php
					printf(
						/* translators: %s: documentation file path */
						esc_html__( 'For complete setup instructions and usage examples, see %s', 'nvdigital-open-operator-system-oos-pro' ),
						'<code>addons/pro/includes/tools/site-creator-toolkit/README.md</code>'
					);
					?>
				</p>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Configuration', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p>
					<?php
					esc_html_e(
						'To enable or disable this toolkit, go to Settings → NV oOS → Tools → Features and toggle the "Enable Site Creator Toolkit" option.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>
				<p>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=tools&subtab=features' ) ); ?>" class="button button-primary">
						<?php esc_html_e( 'Go to Features Settings', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</a>
				</p>

				<?php
				// Show current status.
				$settings   = get_option( 'wp_mcp_ai_settings', array() );
				$is_enabled = ! empty( $settings['enable_site_creator_toolkit'] );
				?>
				<p>
					<strong><?php esc_html_e( 'Toolkit Status:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
					<?php if ( $is_enabled ) : ?>
						<span style="color: #46b450;">✓ <?php esc_html_e( 'Enabled', 'nvdigital-open-operator-system-oos-pro' ); ?></span>
					<?php else : ?>
						<span style="color: #dc3232;">✗ <?php esc_html_e( 'Disabled', 'nvdigital-open-operator-system-oos-pro' ); ?></span>
					<?php endif; ?>
				</p>
			</div>

			<?php if ( $is_enabled ) : ?>
			<div class="card">
				<h2><?php esc_html_e( 'Permissions', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p>
					<?php
					esc_html_e(
						'Configure what actions AI assistants are allowed to perform when using Site Creator tools. All permissions require manage_options capability.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>
				<form method="post" action="options.php">
					<?php
					settings_fields( 'wp_mcp_ai_settings' );
					?>
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row"><?php esc_html_e( 'Enable Site Creator', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<td>
									<label>
										<input type="checkbox" name="wp_mcp_ai_settings[enable_site_creator]" value="1" <?php checked( ! empty( $settings['enable_site_creator'] ) ); ?> />
										<?php esc_html_e( 'Allow AI to create and configure sites', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</label>
									<p class="description">
										<?php esc_html_e( 'When enabled, AI assistants can use site creator tools to automatically install themes, plugins, update options, and create content.', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e( 'Plugin Installation', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<td>
									<label>
										<input type="checkbox" name="wp_mcp_ai_settings[site_creator_allow_plugin_install]" value="1" <?php checked( ! empty( $settings['site_creator_allow_plugin_install'] ) ); ?> />
										<?php esc_html_e( 'Enable automatic plugin installation from WordPress.org', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</label>
									<p class="description">
										<?php esc_html_e( 'Allows AI to install and activate plugins from the WordPress.org repository. Plugins are only installed from trusted WordPress.org sources.', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e( 'Theme Installation', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<td>
									<label>
										<input type="checkbox" name="wp_mcp_ai_settings[site_creator_allow_theme_install]" value="1" <?php checked( ! empty( $settings['site_creator_allow_theme_install'] ) ); ?> />
										<?php esc_html_e( 'Enable automatic theme installation from WordPress.org', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</label>
									<p class="description">
										<?php esc_html_e( 'Allows AI to install and activate themes from the WordPress.org repository. Themes are only installed from trusted WordPress.org sources.', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e( 'Option Updates', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<td>
									<label>
										<input type="checkbox" name="wp_mcp_ai_settings[site_creator_allow_option_updates]" value="1" <?php checked( ! empty( $settings['site_creator_allow_option_updates'] ) ); ?> />
										<?php esc_html_e( 'Enable automatic WordPress option updates', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</label>
									<p class="description">
										<?php esc_html_e( 'Allows AI to update WordPress options (e.g., blogname, blogdescription) via the update_option tool.', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e( 'WP-CLI Tools', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<td>
									<label>
										<input type="checkbox" name="wp_mcp_ai_settings[site_creator_allow_wp_cli_tools]" value="1" <?php checked( ! empty( $settings['site_creator_allow_wp_cli_tools'] ) ); ?> />
										<?php esc_html_e( 'Enable WP-CLI inspection and execution tools', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</label>
									<p class="description">
										<?php esc_html_e( 'Allows AI to inspect and interact with the WP-CLI environment. This includes checking WP-CLI availability and version information.', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php esc_html_e( 'Elementor Kit Import', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
								<td>
									<label>
										<input type="checkbox" name="wp_mcp_ai_settings[site_creator_allow_elementor_kit_import]" value="1" <?php checked( ! empty( $settings['site_creator_allow_elementor_kit_import'] ) ); ?> />
										<?php esc_html_e( 'Enable Elementor template kit import', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</label>
									<p class="description">
										<?php esc_html_e( 'Allows AI to import Elementor template kits from the Media Library. Requires Elementor to be active.', 'nvdigital-open-operator-system-oos-pro' ); ?>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
					<?php submit_button( __( 'Save Permissions', 'nvdigital-open-operator-system-oos-pro' ) ); ?>
				</form>
			</div>
			<?php endif; ?>

			<div class="card">
				<h2><?php esc_html_e( 'Template Management', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p>
					<?php
					esc_html_e(
						'Site templates, page templates, and reusable sections are stored as custom post types. You can manage them from the WordPress admin menu.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>
				<?php if ( $is_enabled ) : ?>
					<p>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wp_site_template' ) ); ?>" class="button">
							<?php esc_html_e( 'Manage Site Templates', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</a>
					</p>
				<?php endif; ?>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Security & Best Practices', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p>
					<?php
					esc_html_e(
						'The Site Creator Toolkit follows WordPress security best practices:',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>
				<ul>
					<li><?php esc_html_e( 'Requires manage_options capability for all operations', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Input sanitization and output escaping', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Nonce verification for state changes', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Comprehensive audit logging', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Generated code follows WordPress Coding Standards', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Requirements', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<ul>
					<li><?php esc_html_e( 'PHP 7.4 or higher', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'WordPress 6.0 or higher', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'NV oOS Pro addon', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'OpenAI API key (for AI-powered features)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Architect Agent Toolkit (for automated development)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Optional: Elementor (for enhanced page building)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Optional: JetEngine (for CCT storage)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Warning', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p style="color: #d63638;">
					<strong><?php esc_html_e( 'Important:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
					<?php
					esc_html_e(
						'The Site Creator Toolkit provides powerful capabilities that enable AI agents to generate and modify site structure and code. Only grant access to trusted administrators with manage_options capability. Always use in development environments with version control and backups.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the tools page.
	 *
	 * @since 1.2.0
	 */
	public function render_tools_page() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Site Creator Tools', 'nvdigital-open-operator-system-oos-pro' ); ?></h1>

			<div class="card">
				<h2><?php esc_html_e( 'Available Tools', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p>
					<?php
					esc_html_e(
						'The Site Creator Toolkit provides 26 specialized tools across 6 categories for automated WordPress site creation.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>

				<h3><?php esc_html_e( 'Tool Categories', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>

				<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 20px;">
					<div class="card" style="margin: 0;">
						<h4><span class="dashicons dashicons-search" style="color: #2271b1;"></span> <?php esc_html_e( 'Research & Discovery', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
						<p><?php esc_html_e( '4 tools for best practices, competitor analysis, site planning, and template suggestions', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</div>

					<div class="card" style="margin: 0;">
						<h4><span class="dashicons dashicons-admin-page" style="color: #2271b1;"></span> <?php esc_html_e( 'Page Building', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
						<p><?php esc_html_e( '5 tools for landing pages, homepage layouts, about pages, service pages, and blog layouts', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</div>

					<div class="card" style="margin: 0;">
						<h4><span class="dashicons dashicons-editor-table" style="color: #2271b1;"></span> <?php esc_html_e( 'Section Building', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
						<p><?php esc_html_e( '6 tools for hero sections, features, testimonials, CTAs, galleries, and contact sections', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</div>

					<div class="card" style="margin: 0;">
						<h4><span class="dashicons dashicons-layout" style="color: #2271b1;"></span> <?php esc_html_e( 'Widget Building', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
						<p><?php esc_html_e( '4 tools for custom widgets, navigation menus, sidebar widgets, and footer widgets', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</div>

					<div class="card" style="margin: 0;">
						<h4><span class="dashicons dashicons-portfolio" style="color: #2271b1;"></span> <?php esc_html_e( 'Template Management', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
						<p><?php esc_html_e( '4 tools for saving, importing, exporting templates, and version control', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</div>

					<div class="card" style="margin: 0;">
						<h4><span class="dashicons dashicons-admin-tools" style="color: #2271b1;"></span> <?php esc_html_e( 'Integration Tools', 'nvdigital-open-operator-system-oos-pro' ); ?></h4>
						<p><?php esc_html_e( '3 tools for Architect Agent integration, theme scaffolding, and automated workflows', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					</div>
				</div>

				<h3 style="margin-top: 30px;"><?php esc_html_e( 'Tool Configuration', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<p>
					<?php
					esc_html_e(
						'To enable or disable individual tools, go to the main NV oOS Settings page.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>
				<p>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=tools&subtab=site_creator' ) ); ?>" class="button button-primary">
						<?php esc_html_e( 'Configure Tools', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</a>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the templates page.
	 *
	 * @since 1.2.0
	 */
	public function render_templates_page() {
		$settings   = get_option( 'wp_mcp_ai_settings', array() );
		$is_enabled = ! empty( $settings['enable_site_creator_toolkit'] );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Site Creator Templates', 'nvdigital-open-operator-system-oos-pro' ); ?></h1>

			<?php if ( ! $is_enabled ) : ?>
				<div class="notice notice-warning inline">
					<p>
						<strong><?php esc_html_e( 'Site Creator Toolkit is not enabled.', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
						<?php esc_html_e( 'Enable it in the main settings to use template features.', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</p>
					<p>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=tools&subtab=site_creator' ) ); ?>" class="button">
							<?php esc_html_e( 'Go to Settings', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</a>
					</p>
				</div>
			<?php endif; ?>

			<div class="card">
				<h2><?php esc_html_e( 'Template Management', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p>
					<?php
					esc_html_e(
						'Site templates, page templates, and reusable sections created by the Site Creator Toolkit are stored as custom post types.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>

				<?php if ( $is_enabled ) : ?>
					<h3><?php esc_html_e( 'Manage Templates', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
					<p>
						<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wp_site_template' ) ); ?>" class="button button-primary">
							<?php esc_html_e( 'View All Site Templates', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</a>
					</p>

					<h3 style="margin-top: 30px;"><?php esc_html_e( 'Template Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
					<ul>
						<li><?php esc_html_e( 'Save templates from generated sites', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Import/export templates between sites', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Version control for template changes', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Reusable sections and components', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					</ul>
				<?php endif; ?>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Template Best Practices', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<ul>
					<li><?php esc_html_e( 'Use descriptive names for templates', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Test templates in staging before production', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Keep templates updated with latest best practices', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Document any custom modifications', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><?php esc_html_e( 'Use version control for tracking changes', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the research & add page.
	 *
	 * @since 1.2.0
	 */
	public function render_research_page() {
		$settings   = get_option( 'wp_mcp_ai_settings', array() );
		$is_enabled = ! empty( $settings['enable_site_creator_toolkit'] );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Research & Add Site Templates', 'nvdigital-open-operator-system-oos-pro' ); ?></h1>

			<?php if ( ! $is_enabled ) : ?>
				<div class="notice notice-warning inline">
					<p>
						<strong><?php esc_html_e( 'Site Creator Toolkit is not enabled.', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
						<?php esc_html_e( 'Enable it in the main settings to use research features.', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</p>
					<p>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=tools&subtab=site_creator' ) ); ?>" class="button">
							<?php esc_html_e( 'Go to Settings', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</a>
					</p>
				</div>
			<?php endif; ?>

			<div class="card">
				<h2><?php esc_html_e( 'AI-Powered Site Research', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p>
					<?php
					esc_html_e(
						'Use AI assistance to research and plan site templates before creating them. The AI can help you discover best practices, analyze competitor sites, suggest layouts, and plan complete site structures.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>

				<h3><?php esc_html_e( 'Research Capabilities', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<ul>
					<li><strong><?php esc_html_e( 'Best Practices Research:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Discover industry standards and modern web design principles', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Competitor Analysis:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Analyze competitor websites for inspiration and insights', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Site Planning:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Generate comprehensive site plans and architecture', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Template Suggestions:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Get AI-powered template and pattern recommendations', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Content Strategy:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Plan content structure and information architecture', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>

				<?php if ( $is_enabled ) : ?>
					<h3><?php esc_html_e( 'How to Use', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
					<ol>
						<li><?php esc_html_e( 'Start a conversation with the AI assistant below', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Describe your site requirements or ask research questions', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Review AI suggestions and research findings', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Refine your requirements through conversation', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Create site templates directly from the research insights', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					</ol>

					<div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 4px;">
						<h3 style="margin-top: 0;"><?php esc_html_e( 'AI Assistant', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
						<p><?php esc_html_e( 'Chat with the AI assistant to research and plan your site templates:', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
						
						<?php
						// Render the chat interface.
						if ( class_exists( 'WP_MCP_AI_Shortcode' ) ) {
							echo do_shortcode( '[nvoos-ai-chat assistant="site-creator-research" mode="inline"]' );
						} else {
							?>
							<div class="notice notice-info inline">
								<p><?php esc_html_e( 'Chat interface not available. Please ensure NV oOS is properly configured.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
							</div>
							<?php
						}
						?>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( $is_enabled ) : ?>
				<div class="card">
					<h2><?php esc_html_e( 'Example Research Questions', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
					<ul>
						<li>"What are the best practices for e-commerce homepage design in 2025?"</li>
						<li>"Analyze the top 3 SaaS landing pages and suggest a layout"</li>
						<li>"Create a site plan for a restaurant website with online ordering"</li>
						<li>"What sections should I include in a professional services website?"</li>
						<li>"Suggest template patterns for a portfolio website"</li>
					</ul>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render the consolidate & add page.
	 *
	 * @since 1.2.0
	 */
	public function render_consolidate_page() {
		$settings   = get_option( 'wp_mcp_ai_settings', array() );
		$is_enabled = ! empty( $settings['enable_site_creator_toolkit'] );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Consolidate & Add Site Templates', 'nvdigital-open-operator-system-oos-pro' ); ?></h1>

			<?php if ( ! $is_enabled ) : ?>
				<div class="notice notice-warning inline">
					<p>
						<strong><?php esc_html_e( 'Site Creator Toolkit is not enabled.', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
						<?php esc_html_e( 'Enable it in the main settings to use consolidation features.', 'nvdigital-open-operator-system-oos-pro' ); ?>
					</p>
					<p>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-mcp-ai-dashboard&tab=tools&subtab=site_creator' ) ); ?>" class="button">
							<?php esc_html_e( 'Go to Settings', 'nvdigital-open-operator-system-oos-pro' ); ?>
						</a>
					</p>
				</div>
			<?php endif; ?>

			<div class="card">
				<h2><?php esc_html_e( 'Bulk Import & Consolidation', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
				<p>
					<?php
					esc_html_e(
						'Import and consolidate site templates from various sources. Batch process multiple templates, validate data quality, and streamline your template library management.',
						'nvdigital-open-operator-system-oos-pro'
					);
					?>
				</p>

				<h3><?php esc_html_e( 'Import Options', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
				<ul>
					<li><strong><?php esc_html_e( 'JSON Import:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Import site templates from JSON files', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'ZIP Archives:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Import complete template kits from ZIP files', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'XML Import:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Import from XML format (WordPress export compatible)', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'URL Import:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Import templates directly from remote URLs', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					<li><strong><?php esc_html_e( 'Batch Processing:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Process multiple templates in a single operation', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				</ul>

				<?php if ( $is_enabled ) : ?>
					<h3><?php esc_html_e( 'Consolidation Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
					<ul>
						<li><?php esc_html_e( 'Duplicate detection and merging', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Data quality validation', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Automatic categorization', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Preview before importing', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
						<li><?php esc_html_e( 'Rollback support for failed imports', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
					</ul>

					<div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 4px;">
						<h3 style="margin-top: 0;"><?php esc_html_e( 'Import Templates', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
						
						<form method="post" enctype="multipart/form-data" style="max-width: 600px;">
							<?php wp_nonce_field( 'wp_mcp_ai_template_import', 'wp_mcp_ai_template_import_nonce' ); ?>
							
							<table class="form-table" role="presentation">
								<tr>
									<th scope="row">
										<label for="import_type"><?php esc_html_e( 'Import Type', 'nvdigital-open-operator-system-oos-pro' ); ?></label>
									</th>
									<td>
										<select name="import_type" id="import_type" class="regular-text">
											<option value="json"><?php esc_html_e( 'JSON File', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
											<option value="zip"><?php esc_html_e( 'ZIP Archive', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
											<option value="xml"><?php esc_html_e( 'XML File', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
											<option value="url"><?php esc_html_e( 'Remote URL', 'nvdigital-open-operator-system-oos-pro' ); ?></option>
										</select>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="import_file"><?php esc_html_e( 'File', 'nvdigital-open-operator-system-oos-pro' ); ?></label>
									</th>
									<td>
										<input type="file" name="import_file" id="import_file" class="regular-text" accept=".json,.zip,.xml" />
										<p class="description"><?php esc_html_e( 'Select a file to import', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="import_url"><?php esc_html_e( 'URL', 'nvdigital-open-operator-system-oos-pro' ); ?></label>
									</th>
									<td>
										<input type="url" name="import_url" id="import_url" class="regular-text" placeholder="https://example.com/template.json" />
										<p class="description"><?php esc_html_e( 'Or enter a URL to import from', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php esc_html_e( 'Options', 'nvdigital-open-operator-system-oos-pro' ); ?></th>
									<td>
										<label style="display: block; margin-bottom: 8px;">
											<input type="checkbox" name="validate_data" value="1" checked />
											<?php esc_html_e( 'Validate data quality before importing', 'nvdigital-open-operator-system-oos-pro' ); ?>
										</label>
										<label style="display: block; margin-bottom: 8px;">
											<input type="checkbox" name="check_duplicates" value="1" checked />
											<?php esc_html_e( 'Check for duplicates', 'nvdigital-open-operator-system-oos-pro' ); ?>
										</label>
										<label style="display: block; margin-bottom: 8px;">
											<input type="checkbox" name="auto_categorize" value="1" checked />
											<?php esc_html_e( 'Automatically categorize templates', 'nvdigital-open-operator-system-oos-pro' ); ?>
										</label>
										<label style="display: block;">
											<input type="checkbox" name="preview_mode" value="1" />
											<?php esc_html_e( 'Preview only (do not import)', 'nvdigital-open-operator-system-oos-pro' ); ?>
										</label>
									</td>
								</tr>
							</table>

							<p class="submit">
								<button type="submit" name="action" value="import" class="button button-primary">
									<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
									<?php esc_html_e( 'Import Templates', 'nvdigital-open-operator-system-oos-pro' ); ?>
								</button>
							</p>
						</form>

						<div style="margin-top: 20px; padding: 15px; background: #fff8e5; border-left: 4px solid #dba617; border-radius: 4px;">
							<p style="margin: 0;">
								<strong><?php esc_html_e( 'Note:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong>
								<?php esc_html_e( 'Large imports may take several minutes. Please do not close this page during import.', 'nvdigital-open-operator-system-oos-pro' ); ?>
							</p>
						</div>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( $is_enabled ) : ?>
				<div class="card">
					<h2><?php esc_html_e( 'AI-Assisted Consolidation', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
					<p><?php esc_html_e( 'Use the AI assistant to help with template consolidation and data cleanup:', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
					
					<?php
					// Render the chat interface.
					if ( class_exists( 'WP_MCP_AI_Shortcode' ) ) {
						echo do_shortcode( '[nvoos-ai-chat assistant="site-creator-consolidate" mode="inline"]' );
					} else {
						?>
						<div class="notice notice-info inline">
							<p><?php esc_html_e( 'Chat interface not available. Please ensure NV oOS is properly configured.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
						</div>
						<?php
					}
					?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}

// Initialize the settings page.
new WP_MCP_AI_Site_Creator_Toolkit_Settings_Page();
