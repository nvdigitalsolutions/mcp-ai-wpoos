<?php
/**
 * Project Settings Page
 *
 * Provides settings page for configuring AI provider, model, and assistant
 * for Project Management functionality.
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load base class.
require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-cpt-settings-page-base.php';

/**
 * Project Settings Page
 */
class WP_MCP_AI_Project_Settings_Page extends WP_MCP_AI_CPT_Settings_Page_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->option_name = 'wp_mcp_ai_project_settings';
		$this->post_type   = 'mcp_ai_project';
		$this->page_title  = __( 'Project Management Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->menu_title  = __( 'Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->page_slug   = 'project-settings';

		// Call parent constructor to set up hooks.
		parent::__construct();
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		// Call parent to register base fields (assistant).
		parent::register_settings();

		// Add project-specific settings.
		add_settings_field(
			'enable_research',
			__( 'Enable Research & Add', 'nvdigital-open-operator-system-oos-pro' ),
			array( $this, 'render_enable_research_field' ),
			$this->option_name,
			$this->option_name . '_section'
		);
	}

	/**
	 * Render enable research field.
	 */
	public function render_enable_research_field() {
		$options = get_option( $this->option_name, array() );
		$value   = isset( $options['enable_research'] ) ? (bool) $options['enable_research'] : true;

		?>
		<label>
			<input
				type="checkbox"
				name="<?php echo esc_attr( $this->option_name ); ?>[enable_research]"
				id="enable_research"
				value="1"
				<?php checked( $value, true ); ?>
			/>
			<?php esc_html_e( 'Enable the Research & Add page for project research', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</label>
		<p class="description">
			<?php esc_html_e( 'When enabled, users can access the Research & Add page to create projects using AI assistance.', 'nvdigital-open-operator-system-oos-pro' ); ?>
		</p>
		<?php
	}

	/**
	 * Render section description.
	 */
	public function render_section_description() {
		echo '<p>' . esc_html__( 'Configure the AI assistant for Project Management AI features.', 'nvdigital-open-operator-system-oos-pro' ) . '</p>';
	}

	/**
	 * Render overview tab.
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-card">
			<h2><?php esc_html_e( 'Project Management Toolkit Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<p><?php esc_html_e( 'Comprehensive project management system with AI-powered tools for managing projects, tasks, events, timelines, and team collaboration.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<ul>
				<li><strong><?php esc_html_e( 'Project Management:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Create, track, and manage projects with AI assistance', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><strong><?php esc_html_e( 'Task Management:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Break down projects into manageable tasks with dependencies and assignments', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><strong><?php esc_html_e( 'Event Scheduling:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Schedule meetings, milestones, and deadlines with calendar integration', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><strong><?php esc_html_e( 'Ralph Loop Orchestration:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Autonomous task execution with continuous improvement cycles', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><strong><?php esc_html_e( 'Task Plans:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Markdown-based execution plans with checkbox progress tracking', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><strong><?php esc_html_e( 'Task Templates:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Reusable templates for common workflows and project types', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><strong><?php esc_html_e( 'High-Performance Storage:', 'nvdigital-open-operator-system-oos-pro' ); ?></strong> <?php esc_html_e( 'Automatic CCT (JetEngine) support for enterprise scalability', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Get tools list.
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			// Project Tools.
			'research_project'                 => __( 'Research Project', 'nvdigital-open-operator-system-oos-pro' ),
			'create_project'                   => __( 'Create Project', 'nvdigital-open-operator-system-oos-pro' ),
			'update_project'                   => __( 'Update Project', 'nvdigital-open-operator-system-oos-pro' ),
			'list_projects'                    => __( 'List Projects', 'nvdigital-open-operator-system-oos-pro' ),
			'get_project'                      => __( 'Get Project Details', 'nvdigital-open-operator-system-oos-pro' ),
			'delete_project'                   => __( 'Delete Project', 'nvdigital-open-operator-system-oos-pro' ),

			// Task Tools.
			'create_task'                      => __( 'Create Task', 'nvdigital-open-operator-system-oos-pro' ),
			'update_task'                      => __( 'Update Task', 'nvdigital-open-operator-system-oos-pro' ),
			'list_tasks'                       => __( 'List Tasks', 'nvdigital-open-operator-system-oos-pro' ),
			'get_task'                         => __( 'Get Task Details', 'nvdigital-open-operator-system-oos-pro' ),
			'delete_task'                      => __( 'Delete Task', 'nvdigital-open-operator-system-oos-pro' ),

			// Event Tools.
			'create_event'                     => __( 'Create Event', 'nvdigital-open-operator-system-oos-pro' ),
			'update_event'                     => __( 'Update Event', 'nvdigital-open-operator-system-oos-pro' ),
			'list_events'                      => __( 'List Events', 'nvdigital-open-operator-system-oos-pro' ),
			'get_event'                        => __( 'Get Event Details', 'nvdigital-open-operator-system-oos-pro' ),
			'delete_event'                     => __( 'Delete Event', 'nvdigital-open-operator-system-oos-pro' ),

			// Ralph Loop Orchestration Tools.
			'create_task_plan'                 => __( 'Create Task Plan', 'nvdigital-open-operator-system-oos-pro' ),
			'update_task_plan'                 => __( 'Update Task Plan', 'nvdigital-open-operator-system-oos-pro' ),
			'get_task_plan'                    => __( 'Get Task Plan', 'nvdigital-open-operator-system-oos-pro' ),
			'list_task_plans'                  => __( 'List Task Plans', 'nvdigital-open-operator-system-oos-pro' ),
			'manage_autonomous_session'        => __( 'Manage Autonomous Session', 'nvdigital-open-operator-system-oos-pro' ),
			'detect_completion_indicators'     => __( 'Detect Completion Indicators', 'nvdigital-open-operator-system-oos-pro' ),
			'check_exit_conditions'            => __( 'Check Exit Conditions', 'nvdigital-open-operator-system-oos-pro' ),
			'analyze_loop_health'              => __( 'Analyze Loop Health', 'nvdigital-open-operator-system-oos-pro' ),
			'get_session_status'               => __( 'Get Session Status', 'nvdigital-open-operator-system-oos-pro' ),
			'calculate_orchestration_capacity' => __( 'Calculate Orchestration Capacity', 'nvdigital-open-operator-system-oos-pro' ),

			// Task Template Tools.
			'create_template'                  => __( 'Create Task Template', 'nvdigital-open-operator-system-oos-pro' ),
			'list_templates'                   => __( 'List Task Templates', 'nvdigital-open-operator-system-oos-pro' ),
			'instantiate_template'             => __( 'Instantiate Template', 'nvdigital-open-operator-system-oos-pro' ),
			'seed_template_library'            => __( 'Seed Template Library', 'nvdigital-open-operator-system-oos-pro' ),

			// Calendar & View Tools.
			'get_calendar_view'                => __( 'Get Calendar View', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Sanitize settings.
	 *
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public function sanitize_settings( $input ) {
		// Call parent sanitization for base fields.
		$sanitized = parent::sanitize_settings( $input );

		// Add project-specific sanitization.
		if ( isset( $input['enable_research'] ) ) {
			$sanitized['enable_research'] = (bool) $input['enable_research'];
		} else {
			$sanitized['enable_research'] = false;
		}

		return $sanitized;
	}
}

// Initialize.
new WP_MCP_AI_Project_Settings_Page();
