<?php
/**
 * Regulatory Product CPT Settings Page
 *
 * Settings page for the Regulatory Product custom post type with Overview, Settings, and Tools tabs.
 *
 * @package WP_MCP_AI_Pro
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-cpt-settings-page-base.php';

/**
 * Regulatory Product CPT Settings Page Class
 *
 * Provides settings interface for the Regulatory Product toolkit with
 * overview information and tools listing.
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Regulatory_Product_Settings_Page extends WP_MCP_AI_CPT_Settings_Page_Base {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->cpt_slug      = 'mcp_ai_reg_product';
		$this->page_slug     = 'regulatory-product-settings';
		$this->page_title    = __( 'Regulatory Product Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->menu_title    = __( 'Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->option_name   = 'wp_mcp_ai_regulatory_product_settings';
		$this->settings_key  = 'enable_regulatory_registration_toolkit';

		parent::__construct();
	}

	/**
	 * Render overview tab.
	 *
	 * @since 1.2.0
	 */
	protected function render_overview_tab() {
		?>
		<h2><?php esc_html_e( 'Regulatory Registration Toolkit Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
		
		<p><?php esc_html_e( 'Comprehensive regulatory product registration and compliance management system for multi-country regulatory submissions (Sri Lanka NMRA, UAE MOHAP, Saudi SFDA, and more).', 'nvdigital-open-operator-system-oos-pro' ); ?></p>

		<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Product Registration Management: Track products, registrations, and documentation across multiple countries', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Document Management: Organize and track regulatory documents, expiry dates, and versions', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Compliance Validation: Validate INCI ingredients, HS codes, and regulatory requirements', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'PDF Generation: Generate regulatory dossiers, cover letters, and compliance certificates', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Multi-Country Support: Manage registrations for Sri Lanka, UAE, Saudi Arabia, Qatar, Kuwait, Oman, India', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Registration Timeline Tracking: Monitor application status from submission to approval', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Expiry Notifications: Track document and registration renewal dates', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'API Integration: Sync with NMRA, MOHAP, and SFDA regulatory authorities', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
		</ul>

		<h3><?php esc_html_e( 'Tool Categories', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Product Management: 8 tools for CRUD operations and validation', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Registration Management: 10 tools for tracking and managing registrations', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Document Management: 8 tools for regulatory documentation', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'Compliance: 6 tools for validation and regulatory checks', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'PDF Generation: 3 tools for dossiers, letters, certificates', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			<li><?php esc_html_e( 'API Integration: 3 tools for authority system sync', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
		</ul>
		<?php
	}

	/**
	 * Get tools list.
	 *
	 * @since 1.2.0
	 * @return array Tools list with slugs and names.
	 */
	protected function get_tools_list() {
		return array(
			// Product Management Tools (8).
			'create_reg_product'              => __( 'Create Regulatory Product', 'nvdigital-open-operator-system-oos-pro' ),
			'list_reg_products'               => __( 'List Regulatory Products', 'nvdigital-open-operator-system-oos-pro' ),
			'get_reg_product'                 => __( 'Get Regulatory Product', 'nvdigital-open-operator-system-oos-pro' ),
			'update_reg_product'              => __( 'Update Regulatory Product', 'nvdigital-open-operator-system-oos-pro' ),
			'delete_reg_product'              => __( 'Delete Regulatory Product', 'nvdigital-open-operator-system-oos-pro' ),
			'search_reg_products'             => __( 'Search Regulatory Products', 'nvdigital-open-operator-system-oos-pro' ),
			'duplicate_reg_product'           => __( 'Duplicate Regulatory Product', 'nvdigital-open-operator-system-oos-pro' ),
			'validate_reg_product'            => __( 'Validate Regulatory Product', 'nvdigital-open-operator-system-oos-pro' ),

			// Registration Management Tools (10).
			'create_registration'             => __( 'Create Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'list_registrations'              => __( 'List Registrations', 'nvdigital-open-operator-system-oos-pro' ),
			'get_registration'                => __( 'Get Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'update_registration_status'      => __( 'Update Registration Status', 'nvdigital-open-operator-system-oos-pro' ),
			'list_expiring_registrations'     => __( 'List Expiring Registrations', 'nvdigital-open-operator-system-oos-pro' ),
			'submit_registration'             => __( 'Submit Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'approve_registration'            => __( 'Approve Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'renew_registration'              => __( 'Renew Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'get_registration_timeline'       => __( 'Get Registration Timeline', 'nvdigital-open-operator-system-oos-pro' ),
			'list_registrations_by_country'   => __( 'List Registrations by Country', 'nvdigital-open-operator-system-oos-pro' ),

			// Document Management Tools (8).
			'list_reg_documents'              => __( 'List Regulatory Documents', 'nvdigital-open-operator-system-oos-pro' ),
			'check_document_expiry'           => __( 'Check Document Expiry', 'nvdigital-open-operator-system-oos-pro' ),
			'upload_reg_document'             => __( 'Upload Regulatory Document', 'nvdigital-open-operator-system-oos-pro' ),
			'update_reg_document'             => __( 'Update Regulatory Document', 'nvdigital-open-operator-system-oos-pro' ),
			'get_reg_document'                => __( 'Get Regulatory Document', 'nvdigital-open-operator-system-oos-pro' ),
			'validate_document_checklist'     => __( 'Validate Document Checklist', 'nvdigital-open-operator-system-oos-pro' ),
			'generate_submission_pack'        => __( 'Generate Submission Pack', 'nvdigital-open-operator-system-oos-pro' ),
			'track_document_version'          => __( 'Track Document Version', 'nvdigital-open-operator-system-oos-pro' ),

			// Compliance Tools (6).
			'add_regulatory_requirement'      => __( 'Add Regulatory Requirement', 'nvdigital-open-operator-system-oos-pro' ),
			'get_regulatory_requirements'     => __( 'Get Regulatory Requirements', 'nvdigital-open-operator-system-oos-pro' ),
			'check_product_compliance'        => __( 'Check Product Compliance', 'nvdigital-open-operator-system-oos-pro' ),
			'validate_inci_ingredients'       => __( 'Validate INCI Ingredients', 'nvdigital-open-operator-system-oos-pro' ),
			'check_hs_code'                   => __( 'Check HS Code', 'nvdigital-open-operator-system-oos-pro' ),
			'get_regulatory_updates'          => __( 'Get Regulatory Updates', 'nvdigital-open-operator-system-oos-pro' ),

			// PDF Generation Tools (3).
			'generate_pdf_dossier'            => __( 'Generate PDF Dossier', 'nvdigital-open-operator-system-oos-pro' ),
			'generate_cover_letter'           => __( 'Generate Cover Letter', 'nvdigital-open-operator-system-oos-pro' ),
			'generate_compliance_certificate' => __( 'Generate Compliance Certificate', 'nvdigital-open-operator-system-oos-pro' ),

			// API Integration Tools (3).
			'sync_with_nmra'                  => __( 'Sync with NMRA (Sri Lanka)', 'nvdigital-open-operator-system-oos-pro' ),
			'sync_with_mohap'                 => __( 'Sync with MOHAP (UAE)', 'nvdigital-open-operator-system-oos-pro' ),
			'sync_with_sfda'                  => __( 'Sync with SFDA (Saudi Arabia)', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}

	/**
	 * Get settings fields.
	 *
	 * @since 1.2.0
	 * @return array Settings fields configuration.
	 */
	protected function get_settings_fields() {
		return array(
			array(
				'id'          => 'assistant_id',
				'label'       => __( 'Assistant', 'nvdigital-open-operator-system-oos-pro' ),
				'type'        => 'assistant_select',
				'description' => __( 'Select the AI assistant to use for regulatory registration tasks.', 'nvdigital-open-operator-system-oos-pro' ),
			),
		);
	}
}

// Initialize settings page.
new WP_MCP_AI_Regulatory_Product_Settings_Page();
