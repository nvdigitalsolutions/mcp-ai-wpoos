<?php
/**
 * Registration Settings Page
 *
 * Provides settings page for configuring AI provider, model, and assistant
 * for Regulatory Registration Research & Add functionality.
 *
 * @package WP_MCP_AI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load base class.
require_once WP_MCP_AI_PRO_PATH . 'includes/admin/class-wp-mcp-ai-cpt-settings-page-base.php';

/**
 * Registration Settings Page
 */
class WP_MCP_AI_Registration_Settings_Page extends WP_MCP_AI_CPT_Settings_Page_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->option_name = 'wp_mcp_ai_registration_settings';
		$this->post_type   = 'mcp_ai_registration';
		$this->page_title  = __( 'Registration Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->menu_title  = __( 'Settings', 'nvdigital-open-operator-system-oos-pro' );
		$this->page_slug   = 'registration-settings';

		// Call parent constructor to set up hooks.
		parent::__construct();
	}

	/**
	 * Render overview tab.
	 */
	protected function render_overview_tab() {
		?>
		<div class="toolkit-card">
			<h2><?php esc_html_e( 'Registration Management Overview', 'nvdigital-open-operator-system-oos-pro' ); ?></h2>
			
			<div class="toolkit-description">
				<p><?php esc_html_e( 'AI-powered regulatory registration management for multi-country submissions. Track registration status, timelines, documents, and compliance requirements with comprehensive AI assistance.', 'nvdigital-open-operator-system-oos-pro' ); ?></p>
			</div>

			<h3><?php esc_html_e( 'Key Features', 'nvdigital-open-operator-system-oos-pro' ); ?></h3>
			<ul>
				<li><?php esc_html_e( 'Multi-Country Registration: Manage registrations across multiple regulatory authorities', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Status Tracking: Monitor registration status from submission to approval', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Document Management: Track required documents and expiry dates', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Timeline Management: Track submission, review, and approval dates', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Compliance Validation: Validate requirements and document checklists', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Renewal Tracking: Monitor expiry dates and renewal requirements', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
				<li><?php esc_html_e( 'Research & Add: AI-assisted registration creation and research', 'nvdigital-open-operator-system-oos-pro' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Get tools list for this CPT.
	 *
	 * @return array
	 */
	protected function get_tools_list() {
		return array(
			'create_registration'           => __( 'Create Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'list_registrations'            => __( 'List Registrations', 'nvdigital-open-operator-system-oos-pro' ),
			'get_registration'              => __( 'Get Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'update_registration_status'    => __( 'Update Registration Status', 'nvdigital-open-operator-system-oos-pro' ),
			'list_expiring_registrations'   => __( 'List Expiring Registrations', 'nvdigital-open-operator-system-oos-pro' ),
			'submit_registration'           => __( 'Submit Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'approve_registration'          => __( 'Approve Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'renew_registration'            => __( 'Renew Registration', 'nvdigital-open-operator-system-oos-pro' ),
			'get_registration_timeline'     => __( 'Get Registration Timeline', 'nvdigital-open-operator-system-oos-pro' ),
			'list_registrations_by_country' => __( 'List Registrations by Country', 'nvdigital-open-operator-system-oos-pro' ),
			'list_reg_products'             => __( 'List Regulatory Products', 'nvdigital-open-operator-system-oos-pro' ),
			'get_reg_product'               => __( 'Get Regulatory Product', 'nvdigital-open-operator-system-oos-pro' ),
			'check_product_compliance'      => __( 'Check Product Compliance', 'nvdigital-open-operator-system-oos-pro' ),
			'web_search'                    => __( 'Web Search', 'nvdigital-open-operator-system-oos-pro' ),
		);
	}
}

// Initialize settings page.
new WP_MCP_AI_Registration_Settings_Page();
