<?php
/**
 * Pro Workflow Builder Admin Page
 *
 * Advanced visual workflow builder with React-based UI.
 * Implements 2026 industry standards for AI workflow tools.
 *
 * @package WP_MCP_AI
 * @subpackage Admin
 * @since 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pro Workflow Builder Admin Page Class
 *
 * @since 2.0.0
 */
class WP_MCP_AI_Pro_Workflow_Builder_Page {

	/**
	 * Page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'nvoos-pro-workflow-builder';

	/**
	 * Cached templates class instance.
	 *
	 * @var WP_MCP_AI_Pattern_Workflow_Templates|null
	 */
	private static $templates_instance = null;

	/**
	 * Initialize the page.
	 *
	 * @since 2.0.0
	 */
	public static function init() {
		// Register admin menu with priority 26 to ensure parent menu (nvoos-pro-dashboard at priority 25) exists.
		add_action( 'admin_menu', array( __CLASS__, 'register_page' ), 26 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_wp_mcp_ai_save_pro_workflow', array( __CLASS__, 'ajax_save_workflow' ) );
		add_action( 'wp_ajax_wp_mcp_ai_load_pro_workflow', array( __CLASS__, 'ajax_load_workflow' ) );
		add_action( 'wp_ajax_wp_mcp_ai_delete_pro_workflow', array( __CLASS__, 'ajax_delete_workflow' ) );
		add_action( 'wp_ajax_wp_mcp_ai_get_workflow_templates', array( __CLASS__, 'ajax_get_templates' ) );
	}

	/**
	 * Register admin page.
	 *
	 * @since 2.0.0
	 */
	public static function register_page() {
		add_submenu_page(
			'nvoos-pro-dashboard',
			__( 'Pro Workflow Builder', 'nvdigital-open-operator-system-oos' ),
			__( 'Pro Workflows', 'nvdigital-open-operator-system-oos' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @since 2.0.0
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function enqueue_assets( $hook ) {
		// Hook format: nvoos-pro-dashboard_page_{PAGE_SLUG}
		if ( 'nvoos-pro-dashboard_page_' . self::PAGE_SLUG !== $hook ) {
			return;
		}

		// Enqueue the React-based workflow builder.
		$asset_file = WP_MCP_AI_PATH . 'addons/pro/build/workflow-builder/workflow-builder.asset.php';
		
		if ( file_exists( $asset_file ) ) {
			$asset = require $asset_file;
			
			wp_enqueue_script(
				'mcp-ai-pro-workflow-builder',
				WP_MCP_AI_URL . 'addons/pro/build/workflow-builder/workflow-builder.js',
				$asset['dependencies'],
				$asset['version'],
				true
			);

			wp_enqueue_style(
				'mcp-ai-pro-workflow-builder',
				WP_MCP_AI_URL . 'addons/pro/build/workflow-builder/workflow-builder.css',
				array(),
				$asset['version']
			);
		} else {
			// Fallback for development - load from src.
			wp_enqueue_script(
				'mcp-ai-pro-workflow-builder',
				WP_MCP_AI_URL . 'src/workflow-builder/index.jsx',
				array( 'wp-element', 'wp-i18n' ),
				WP_MCP_AI_VERSION,
				true
			);
		}

		// Localize script with data.
		wp_localize_script(
			'mcp-ai-pro-workflow-builder',
			'mcpAiWorkflowBuilder',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'mcp_ai_pro_workflow_builder' ),
				'workflows' => self::get_all_workflows(),
				'templates' => self::get_workflow_templates(),
			)
		);
	}

	/**
	 * Render admin page.
	 *
	 * @since 2.0.0
	 */
	public static function render_page() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Pro Workflow Builder', 'nvdigital-open-operator-system-oos' ); ?></h1>
			<div id="mcp-ai-pro-workflow-builder-root"></div>
		</div>
		<?php
	}

	/**
	 * Get all workflows.
	 *
	 * @since 2.0.0
	 *
	 * @return array Workflows.
	 */
	protected static function get_all_workflows() {
		$workflows = get_option( 'wp_mcp_ai_pro_workflows', array() );
		return is_array( $workflows ) ? $workflows : array();
	}

	/**
	 * Get workflow templates.
	 *
	 * @since 2.0.0
	 *
	 * @return array Templates.
	 */
	protected static function get_workflow_templates() {
		// Cache the templates class instance to avoid repeated instantiation.
		if ( null === self::$templates_instance && class_exists( 'WP_MCP_AI_Pattern_Workflow_Templates' ) ) {
			self::$templates_instance = new WP_MCP_AI_Pattern_Workflow_Templates();
		}

		if ( ! self::$templates_instance ) {
			return array();
		}

		return self::$templates_instance->get_all_templates();
	}

	/**
	 * AJAX handler for saving workflows.
	 *
	 * @since 2.0.0
	 */
	public static function ajax_save_workflow() {
		check_ajax_referer( 'mcp_ai_pro_workflow_builder', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		$workflow_json = isset( $_POST['workflow'] ) ? wp_unslash( $_POST['workflow'] ) : '';
		
		if ( empty( $workflow_json ) ) {
			wp_send_json_error( array( 'message' => __( 'Workflow data required.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		$workflow = json_decode( $workflow_json, true );
		
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			wp_send_json_error( array( 'message' => __( 'Invalid workflow data.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		// Validate workflow structure.
		if ( empty( $workflow['name'] ) || empty( $workflow['nodes'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Workflow must have a name and nodes.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		// Sanitize workflow data.
		$workflow['name']        = sanitize_text_field( $workflow['name'] );
		$workflow['description'] = isset( $workflow['description'] ) ? sanitize_textarea_field( $workflow['description'] ) : '';
		
		// Generate workflow ID from name.
		$workflow_id = sanitize_key( $workflow['name'] );

		// Get existing workflows.
		$workflows = self::get_all_workflows();

		// Add/update workflow.
		$workflows[ $workflow_id ] = array(
			'id'          => $workflow_id,
			'name'        => $workflow['name'],
			'description' => $workflow['description'],
			'nodes'       => $workflow['nodes'],
			'edges'       => $workflow['edges'],
			'created_at'  => isset( $workflows[ $workflow_id ]['created_at'] ) ? $workflows[ $workflow_id ]['created_at'] : time(),
			'updated_at'  => time(),
		);

		// Save workflows.
		$result = update_option( 'wp_mcp_ai_pro_workflows', $workflows );

		if ( $result ) {
			wp_send_json_success( array(
				'message'  => __( 'Workflow saved successfully.', 'nvdigital-open-operator-system-oos' ),
				'workflow' => $workflows[ $workflow_id ],
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to save workflow.', 'nvdigital-open-operator-system-oos' ) ) );
		}
	}

	/**
	 * AJAX handler for loading workflow.
	 *
	 * @since 2.0.0
	 */
	public static function ajax_load_workflow() {
		check_ajax_referer( 'mcp_ai_pro_workflow_builder', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		$workflow_id = isset( $_POST['workflow_id'] ) ? sanitize_key( $_POST['workflow_id'] ) : '';

		if ( empty( $workflow_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Workflow ID required.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		$workflows = self::get_all_workflows();

		if ( ! isset( $workflows[ $workflow_id ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Workflow not found.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		wp_send_json_success( array(
			'workflow' => $workflows[ $workflow_id ],
		) );
	}

	/**
	 * AJAX handler for deleting workflows.
	 *
	 * @since 2.0.0
	 */
	public static function ajax_delete_workflow() {
		check_ajax_referer( 'mcp_ai_pro_workflow_builder', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		$workflow_id = isset( $_POST['workflow_id'] ) ? sanitize_key( $_POST['workflow_id'] ) : '';

		if ( empty( $workflow_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Workflow ID required.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		$workflows = self::get_all_workflows();

		if ( ! isset( $workflows[ $workflow_id ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Workflow not found.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		unset( $workflows[ $workflow_id ] );

		$result = update_option( 'wp_mcp_ai_pro_workflows', $workflows );

		if ( $result ) {
			wp_send_json_success( array( 'message' => __( 'Workflow deleted successfully.', 'nvdigital-open-operator-system-oos' ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to delete workflow.', 'nvdigital-open-operator-system-oos' ) ) );
		}
	}

	/**
	 * AJAX handler for getting workflow templates.
	 *
	 * @since 2.0.0
	 */
	public static function ajax_get_templates() {
		check_ajax_referer( 'mcp_ai_pro_workflow_builder', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'nvdigital-open-operator-system-oos' ) ) );
		}

		$templates = self::get_workflow_templates();

		wp_send_json_success( array(
			'templates' => $templates,
		) );
	}
}

// Initialize the pro workflow builder page if pro version is enabled.
if ( ! defined( 'WP_MCP_AI_BASE_VERSION' ) || ! WP_MCP_AI_BASE_VERSION ) {
	WP_MCP_AI_Pro_Workflow_Builder_Page::init();
}
