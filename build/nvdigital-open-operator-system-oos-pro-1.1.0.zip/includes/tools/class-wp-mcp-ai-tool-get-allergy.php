<?php
/**
 * Tool for getting a single allergy.
 *
 * @package WP_MCP_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get a single allergy record.
 */
class WP_MCP_AI_Tool_Get_Allergy implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface {
	public function get_slug() {
		return 'get_allergy';
	}

	public function get_name() {
		return __( 'Get Allergy', 'nvdigital-open-operator-system-oos-pro' );
	}

	public function get_description() {
		return __( 'Retrieves detailed information about a specific allergy record.', 'nvdigital-open-operator-system-oos-pro' );
	}

	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'allergy_id' => array(
					'type'        => 'integer',
					'description' => __( 'Allergy ID (required)', 'nvdigital-open-operator-system-oos-pro' ),
					'minimum'     => 1,
				),
			),
			'required'             => array( 'allergy_id' ),
			'additionalProperties' => false,
		);
	}

	public function get_capability_flags() {
		return array( 'pro', 'database-read' );
	}

	public static function is_available() {
		if ( function_exists( 'wp_mcp_ai_is_base_version' ) && wp_mcp_ai_is_base_version() ) {
			return false;
		}
		$settings = get_option( 'wp_mcp_ai_settings', array() );
		return ! empty( $settings['enable_health_wellness_management'] );
	}

	public function execute( array $arguments = array(), array $context = array() ) {
		$current_user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $current_user_id || ! user_can( $current_user_id, 'read' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to view allergies.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$allergy_id = isset( $arguments['allergy_id'] ) ? absint( $arguments['allergy_id'] ) : 0;

		if ( ! $allergy_id ) {
			return new WP_Error( 'wp_mcp_ai_missing_id', __( 'Allergy ID is required.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$allergy = get_post( $allergy_id );

		if ( ! $allergy || 'mcp_ai_allergy' !== $allergy->post_type ) {
			return new WP_Error( 'wp_mcp_ai_not_found', __( 'Allergy not found.', 'nvdigital-open-operator-system-oos-pro' ) );
		}

		$severities = wp_get_object_terms( $allergy_id, 'mcp_ai_allergy_severity', array( 'fields' => 'slugs' ) );
		$severity   = ! empty( $severities ) && ! is_wp_error( $severities ) ? $severities[0] : '';

		$member_id   = get_post_meta( $allergy_id, '_allergy_member_id', true );
		$member_name = '';
		if ( $member_id ) {
			$member      = get_post( $member_id );
			$member_name = $member ? $member->post_title : '';
		}

		return array(
			'success' => true,
			'allergy' => array(
				'id'             => $allergy_id,
				'allergen'       => $allergy->post_title,
				'member_id'      => $member_id,
				'member_name'    => $member_name,
				'severity'       => $severity,
				'reactions'      => get_post_meta( $allergy_id, '_allergy_reactions', true ),
				'diagnosed_date' => get_post_meta( $allergy_id, '_allergy_diagnosed_date', true ),
				'notes'          => $allergy->post_content,
				'created_at'     => $allergy->post_date,
				'modified_at'    => $allergy->post_modified,
			),
		);
	}
}
