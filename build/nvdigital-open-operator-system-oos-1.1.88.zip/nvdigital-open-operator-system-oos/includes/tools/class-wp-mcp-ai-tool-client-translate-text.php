<?php
/**
 * Tool that translates text using browser-native Transformers.js
 *
 * @package WP_MCP_AI
 * @since 1.2.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-restrict-from-chat-client.php';

/**
 * Browser-native translation tool
 *
 * Uses Transformers.js to translate between 200+ languages.
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Tool_Client_Translate_Text implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Restrict_From_Chat_Client;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'client_translate_text';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Browser Translate Text', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Translate text between 200+ languages using browser-native AI. Processes instantly without server round-trip. Supports major world languages.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Translating short text between languages in the browser without API calls.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'High-accuracy translation of long documents; the browser model is best suited to short passages.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'client_summarize_text', 'client_analyze_sentiment' ),
			'notes'           => __( 'Language codes use NLLB format (e.g. eng_Latn, fra_Latn). Defaults: English to French.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'text'        => array(
					'type'        => 'string',
					'description' => __( 'The text to translate.', 'nvdigital-open-operator-system-oos' ),
				),
				'source_lang' => array(
					'type'        => 'string',
					'description' => __( 'Source language code (e.g., "eng_Latn" for English). Default is English.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'eng_Latn',
				),
				'target_lang' => array(
					'type'        => 'string',
					'description' => __( 'Target language code (e.g., "fra_Latn" for French). Default is French.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'fra_Latn',
				),
			),
			'required'             => array( 'text' ),
			'additionalProperties' => false,
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'communication_outreach',

			'pattern_compatibility' => array( 'sequential' ),

			'profession_tags'       => array( 'translator', 'content_creator' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'external-api'    => false,
			'consumes-tokens' => false,
			'read-only'       => true,
			'client-side'     => true,
			'offline'         => true,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array Tool execution result.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! class_exists( 'WP_MCP_AI_Transformers_Enqueue' ) ||
			! WP_MCP_AI_Transformers_Enqueue::is_transformers_enabled() ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'Browser-native AI tasks are not enabled.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$text        = isset( $arguments['text'] ) ? $arguments['text'] : '';
		$source_lang = isset( $arguments['source_lang'] ) ? sanitize_text_field( $arguments['source_lang'] ) : 'eng_Latn';
		$target_lang = isset( $arguments['target_lang'] ) ? sanitize_text_field( $arguments['target_lang'] ) : 'fra_Latn';

		if ( empty( $text ) ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'Text parameter is required.', 'nvdigital-open-operator-system-oos' )
			);
		}

		return array(
			'success'           => true,
			'client_executable' => true,
			'client_method'     => 'translate',
			'client_arguments'  => array(
				'text'    => $text,
				'options' => array(
					'sourceLang' => $source_lang,
					'targetLang' => $target_lang,
				),
			),
			'message'           => __( 'Translating text in browser...', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function should_exclude_from_client() {
		return true;
	}
}
