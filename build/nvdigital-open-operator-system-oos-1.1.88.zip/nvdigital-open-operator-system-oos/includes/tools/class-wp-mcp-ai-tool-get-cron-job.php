<?php
/**
 * Tool for getting details of a specific WordPress cron job.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Cron_Manager' ) ) {
	require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-cron-manager.php';
}

/**
 * Allows users to get details of a specific WordPress cron job.
 */
class WP_MCP_AI_Tool_Get_Cron_Job implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface, WP_MCP_AI_Tool_Data_Contract_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'get_cron_job';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Get Cron Job', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Retrieves detailed information about a specific WordPress cron job by its job ID.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Inspecting the schedule, arguments, or status of one known cron job ID.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Browsing scheduled jobs when no ID is known; use list_cron_jobs to discover job IDs first.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'list_cron_jobs', 'create_cron_job', 'delete_cron_job' ),
			'notes'           => __( 'job_id is a 32-character md5 hash returned directly by create_cron_job or create_cron_job_validated, and listed by list_cron_jobs.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'job_id' => array(
					'type'        => 'string',
					'description' => __( 'The unique identifier of the cron job to retrieve.', 'nvdigital-open-operator-system-oos' ),
					'minLength'   => 1,
				),
			),
			'required'             => array( 'job_id' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_data_contract() {
		return array(
			'produces' => null,
			'consumes' => array( 'job_id' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Check if cron orchestration is enabled.
		if ( class_exists( 'WP_MCP_AI_Orchestration_Budget_Enforcement_Service' ) ) {
			if ( ! WP_MCP_AI_Orchestration_Budget_Enforcement_Service::is_cron_orchestration_enabled() ) {
				return new WP_Error( 'wp_mcp_ai_cron_disabled', __( 'Cron-based task orchestration is currently disabled. Enable it in Settings → Orchestration Layer → Settings.', 'nvdigital-open-operator-system-oos' ) );
			}
		}

		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to view cron jobs.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		$job_id = isset( $arguments['job_id'] ) ? sanitize_text_field( (string) $arguments['job_id'] ) : '';

		if ( '' === $job_id ) {
			return new WP_Error( 'wp_mcp_ai_invalid_job_id', __( 'A valid job ID is required.', 'nvdigital-open-operator-system-oos' ) );
		}

		$job = WP_MCP_AI_Cron_Manager::get_job( $job_id );

		if ( ! $job ) {
			return new WP_Error( 'wp_mcp_ai_job_not_found', __( 'The specified cron job was not found.', 'nvdigital-open-operator-system-oos' ) );
		}

		$hook  = isset( $job['hook'] ) ? (string) $job['hook'] : '';
		$args  = isset( $job['args'] ) ? $job['args'] : array();
		$event = wp_get_scheduled_event( $hook, $args );

		$next_run   = $event ? $event->timestamp : null;
		$schedule   = isset( $job['schedule'] ) ? $job['schedule'] : 'single';
		$created_by = isset( $job['created_by'] ) ? (int) $job['created_by'] : 0;

		$creator = '';
		if ( $created_by > 0 ) {
			$user = get_userdata( $created_by );
			if ( $user ) {
				$creator = $user->display_name;
			}
		}

		if ( '' === $creator ) {
			$creator = __( 'System', 'nvdigital-open-operator-system-oos' );
		}

		$summary_text = sprintf(
			/* translators: 1: cron hook name, 2: job ID */
			__( 'Cron job: %1$s (ID: %2$s)', 'nvdigital-open-operator-system-oos' ),
			$hook,
			$job_id
		);

		$result = array(
			'message'  => $summary_text, // Chat client display.
			'summary'  => $summary_text, // Backward compatibility.
			'job_id'   => $job_id,
			'hook'     => $hook,
			'schedule' => $schedule,
			'args'     => $args,
			'creator'  => $creator,
		);

		if ( $next_run ) {
			$result['next_run']           = $next_run;
			$result['next_run_formatted'] = wp_date( DATE_ATOM, $next_run );
			$result['status']             = 'scheduled';
		} else {
			$result['next_run']           = null;
			$result['next_run_formatted'] = __( 'Not scheduled', 'nvdigital-open-operator-system-oos' );
			$result['status']             = 'not_scheduled';
		}

		if ( isset( $job['created_at'] ) && $job['created_at'] ) {
			$result['created_at']           = (int) $job['created_at'];
			$result['created_at_formatted'] = wp_date( DATE_ATOM, (int) $job['created_at'] );
		}

		if ( isset( $job['first_timestamp'] ) && $job['first_timestamp'] ) {
			$result['first_timestamp']           = (int) $job['first_timestamp'];
			$result['first_timestamp_formatted'] = wp_date( DATE_ATOM, (int) $job['first_timestamp'] );
		}

		// Add schedule interval information for recurring jobs.
		if ( 'single' !== $schedule && '' !== $schedule ) {
			$schedules = wp_get_schedules();
			if ( isset( $schedules[ $schedule ] ) ) {
				$result['schedule_display']  = $schedules[ $schedule ]['display'];
				$result['schedule_interval'] = $schedules[ $schedule ]['interval'];
			}
		}

		return $result;
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'workflow_automation',

			'pattern_compatibility' => array( 'hierarchical' ),

			'profession_tags'       => array( 'systems_administrator' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',            // Only reads data, does not modify state.
			'local-only',           // No external API calls.
			'requires-capability',  // Requires user capabilities.
		);
	}
}
