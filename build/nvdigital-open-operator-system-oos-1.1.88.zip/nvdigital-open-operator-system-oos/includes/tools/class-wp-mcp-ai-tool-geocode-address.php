<?php
/**
 * Tool that geocodes addresses using Google Maps Platform Geocoding API.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-google-maps-client.php';
require_once WP_MCP_AI_PATH . 'includes/class-wp-mcp-ai-logger.php';

/**
 * Provides a tool for geocoding addresses (address to coordinates) and reverse geocoding.
 * Follows separation of concerns: handles WordPress integration while delegating API calls to client.
 */
class WP_MCP_AI_Tool_Geocode_Address implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'geocode_address';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Geocode Address', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Convert addresses to geographic coordinates (latitude/longitude) or coordinates to addresses using Google Maps Geocoding API.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Converting an address to coordinates, or coordinates to an address, via Google Maps Geocoding.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Discovering places by name or category; use search_places for location search.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'search_places', 'gemini_geospatial_query', 'get_open_meteo_forecast' ),
			'notes'           => __( 'Pass address for forward geocoding or both latitude and longitude for reverse; language and region refine results.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'address'     => array(
					'type'        => 'string',
					'description' => __( 'The address to geocode (e.g., "1600 Amphitheatre Parkway, Mountain View, CA"). Required for forward geocoding.', 'nvdigital-open-operator-system-oos' ),
				),
				'latitude'    => array(
					'type'        => 'number',
					'description' => __( 'Latitude coordinate for reverse geocoding. Required with longitude for reverse geocoding.', 'nvdigital-open-operator-system-oos' ),
				),
				'longitude'   => array(
					'type'        => 'number',
					'description' => __( 'Longitude coordinate for reverse geocoding. Required with latitude for reverse geocoding.', 'nvdigital-open-operator-system-oos' ),
				),
				'language'    => array(
					'type'        => 'string',
					'description' => __( 'Language code for results (e.g., "en", "es", "fr").', 'nvdigital-open-operator-system-oos' ),
				),
				'region'      => array(
					'type'        => 'string',
					'description' => __( 'Region code for geocoding bias (e.g., "us", "uk").', 'nvdigital-open-operator-system-oos' ),
				),
				'result_type' => array(
					'type'        => 'string',
					'description' => __( 'Filter results by type for reverse geocoding (e.g., "street_address", "locality").', 'nvdigital-open-operator-system-oos' ),
				),
				'timeout'     => array(
					'type'        => 'integer',
					'description' => __( 'Request timeout in seconds (5-60).', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 5,
					'maximum'     => 60,
				),
			),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		$user_id   = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();
		$has_token = ! empty( $context['token_authenticated'] );

		if ( ! $user_id && ! $has_token ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You must be authenticated to use geocoding.', 'nvdigital-open-operator-system-oos' ), array( 'status' => rest_authorization_required_code() ) );
		}

		if ( $user_id ) {
			if ( ! user_can( $user_id, 'read' ) ) {
				return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to use geocoding.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
				return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
			}
		}

		$address   = isset( $arguments['address'] ) ? sanitize_text_field( $arguments['address'] ) : '';
		$latitude  = isset( $arguments['latitude'] ) ? floatval( $arguments['latitude'] ) : null;
		$longitude = isset( $arguments['longitude'] ) ? floatval( $arguments['longitude'] ) : null;

		$client  = new WP_MCP_AI_Google_Maps_Client();
		$options = array();

		if ( isset( $arguments['language'] ) ) {
			$options['language'] = sanitize_text_field( $arguments['language'] );
		}

		if ( isset( $arguments['region'] ) ) {
			$options['region'] = sanitize_text_field( $arguments['region'] );
		}

		if ( isset( $arguments['result_type'] ) ) {
			$options['result_type'] = sanitize_text_field( $arguments['result_type'] );
		}

		if ( isset( $arguments['timeout'] ) ) {
			$options['timeout'] = max( 5, min( 60, absint( $arguments['timeout'] ) ) );
		}

		// Determine if this is forward or reverse geocoding.
		if ( ! empty( $address ) ) {
			// Forward geocoding: address to coordinates.
			$result = $client->geocode( $address, $options );
		} elseif ( null !== $latitude && null !== $longitude ) {
			// Reverse geocoding: coordinates to address.
			$result = $client->reverse_geocode( $latitude, $longitude, $options );
		} else {
			return new WP_Error(
				'wp_mcp_ai_missing_parameters',
				__( 'Either "address" or both "latitude" and "longitude" must be provided.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 400 )
			);
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Add summary for frontend display.
		if ( ! empty( $address ) ) {
			$summary = sprintf(
				/* translators: %s: address */
				__( 'Geocoded address: %s', 'nvdigital-open-operator-system-oos' ),
				$address
			);
		} else {
			$summary = sprintf(
				/* translators: 1: latitude, 2: longitude */
				__( 'Reverse geocoded coordinates: %1$s, %2$s', 'nvdigital-open-operator-system-oos' ),
				$latitude,
				$longitude
			);
		}

		$result = array_merge(
			array(
				'message' => $summary, // Chat client display.
				'summary' => $summary, // Backward compatibility.
			),
			$result
		);

		/**
		 * Allow third parties to filter the geocoding result before it is returned.
		 *
		 * @param array $result    Final response payload.
		 * @param array $arguments Original tool arguments.
		 * @param array $context   Invocation context.
		 */
		$result = apply_filters( 'wp_mcp_ai_geocode_address_result', $result, $arguments, $context );

		return $result;
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'geospatial_location',

			'pattern_compatibility' => array( 'event_driven' ),

			'profession_tags'       => array( 'urban_planner', 'logistics_coordinator' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'external-api',        // Makes external API calls.
			'requires-capability', // Requires user capabilities.
		);
	}
}
