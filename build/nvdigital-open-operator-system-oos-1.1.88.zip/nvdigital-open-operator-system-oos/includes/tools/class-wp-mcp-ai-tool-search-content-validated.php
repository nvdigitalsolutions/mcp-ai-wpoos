<?php
/**
 * Tool that searches WordPress content with taxonomy and meta filters (Validated version).
 *
 * This is the Symfony Validator version of the search_content tool.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../validators/class-wp-mcp-ai-validated-tool.php';
require_once __DIR__ . '/../validators/arguments/class-search-content-arguments.php';

/**
 * Searches published content using WP_Query with optional filters using Symfony Validator.
 */
class WP_MCP_AI_Tool_Search_Content_Validated extends WP_MCP_AI_Validated_Tool implements WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {

	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'search_content_validated';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Search Content (Validated)', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Search published posts by keyword, post type, taxonomy terms, and metadata. Uses Symfony Validator for argument validation.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Keyword post search where Symfony Validator should reject bad post types or out-of-range limits before querying.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Unvalidated or semantic searches; use search_content for the plain path or semantic_content_search for meaning-based hits.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'search_content', 'semantic_content_search' ),
			'notes'           => __( 'Same query surface as search_content with validated arguments; invalid input returns a WP_Error.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		$settings  = get_option( 'wp_mcp_ai_settings', array() );
		$max_limit = isset( $settings['query_posts_limit'] ) && $settings['query_posts_limit'] > 0 ? absint( $settings['query_posts_limit'] ) : 50;
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'search_term'       => array(
					'type'        => 'string',
					'description' => __( 'Keyword or phrase to search for.', 'nvdigital-open-operator-system-oos' ),
				),
				'post_type'         => array(
					'type'        => 'string',
					'description' => __( 'Limit results to a specific post type. Use "any" to search across public types.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'any',
				),
				'limit'             => array(
					'type'        => 'integer',
					'description' => __( 'Maximum number of results to return.', 'nvdigital-open-operator-system-oos' ),
					'minimum'     => 1,
					'maximum'     => $max_limit,
					'default'     => 10,
				),
				'taxonomy_filters'  => array(
					'type'        => 'array',
					'description' => __( 'Optional taxonomy filters. Each filter requires a taxonomy name and one or more terms.', 'nvdigital-open-operator-system-oos' ),
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'taxonomy', 'terms' ),
						'properties'           => array(
							'taxonomy' => array(
								'type'        => 'string',
								'description' => __( 'Taxonomy to filter by (e.g. category, post_tag).', 'nvdigital-open-operator-system-oos' ),
							),
							'terms'    => array(
								'type'        => 'array',
								'items'       => array(
									'type' => 'string',
								),
								'minItems'    => 1,
								'description' => __( 'List of terms to match. Accepts slugs by default.', 'nvdigital-open-operator-system-oos' ),
							),
							'operator' => array(
								'type'        => 'string',
								'enum'        => array( 'IN', 'NOT IN', 'AND', 'EXISTS', 'NOT EXISTS' ),
								'description' => __( 'Comparison operator.', 'nvdigital-open-operator-system-oos' ),
								'default'     => 'IN',
							),
							'field'    => array(
								'type'        => 'string',
								'enum'        => array( 'slug', 'name', 'term_id', 'term_taxonomy_id' ),
								'description' => __( 'Term field to query against.', 'nvdigital-open-operator-system-oos' ),
								'default'     => 'slug',
							),
						),
						'additionalProperties' => false,
					),
				),
				'taxonomy_relation' => array(
					'type'        => 'string',
					'enum'        => array( 'AND', 'OR' ),
					'description' => __( 'Logical relation between multiple taxonomy filters.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'AND',
				),
				'meta_filters'      => array(
					'type'        => 'array',
					'description' => __( 'Optional post meta filters.', 'nvdigital-open-operator-system-oos' ),
					'items'       => array(
						'type'                 => 'object',
						'required'             => array( 'key', 'value' ),
						'properties'           => array(
							'key'     => array(
								'type'        => 'string',
								'description' => __( 'Meta key to compare.', 'nvdigital-open-operator-system-oos' ),
							),
							'value'   => array(
								'type'        => 'string',
								'description' => __( 'Meta value to compare. Can be a string or JSON-encoded array for IN/NOT IN comparisons.', 'nvdigital-open-operator-system-oos' ),
							),
							'compare' => array(
								'type'        => 'string',
								'enum'        => array( '=', '!=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'EXISTS', 'NOT EXISTS' ),
								'description' => __( 'Meta comparison operator.', 'nvdigital-open-operator-system-oos' ),
								'default'     => '=',
							),
							'type'    => array(
								'type'        => 'string',
								'enum'        => array( 'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED' ),
								'description' => __( 'Data type to cast the meta value for comparisons.', 'nvdigital-open-operator-system-oos' ),
							),
						),
						'additionalProperties' => false,
					),
				),
				'meta_relation'     => array(
					'type'        => 'string',
					'enum'        => array( 'AND', 'OR' ),
					'description' => __( 'Logical relation between multiple meta filters.', 'nvdigital-open-operator-system-oos' ),
					'default'     => 'AND',
				),
			),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	protected function get_validation_class() {
		return \WP_MCP_AI\Tools\Arguments\SearchContentArguments::class;
	}

	/**
	 * Execute the tool with validated arguments.
	 *
	 * @param \WP_MCP_AI\Tools\Arguments\SearchContentArguments $validated_args Validated arguments object.
	 * @param array                                             $context        Execution context including user_id.
	 * @return array|WP_Error Tool results or error.
	 */
	protected function execute_validated( $validated_args, $context ) {
		$user_id = isset( $context['user_id'] ) ? absint( $context['user_id'] ) : get_current_user_id();

		if ( ! $user_id || ! user_can( $user_id, 'read' ) ) {
			return new WP_Error( 'wp_mcp_ai_forbidden', __( 'You do not have permission to search content.', 'nvdigital-open-operator-system-oos' ) );
		}

		if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
			return new WP_Error( 'wp_mcp_ai_wrong_site', __( 'You do not have access to this site.', 'nvdigital-open-operator-system-oos' ) );
		}

		$settings    = get_option( 'wp_mcp_ai_settings', array() );
		$max_limit   = isset( $settings['query_posts_limit'] ) && $settings['query_posts_limit'] > 0 ? absint( $settings['query_posts_limit'] ) : 50;
		$search_term = sanitize_text_field( $validated_args->search_term );
		$post_type   = sanitize_key( $validated_args->post_type );
		$limit       = min( absint( $validated_args->limit ), $max_limit );

		$taxonomy_filters = $this->prepare_taxonomy_filters( $validated_args );
		$meta_filters     = $this->prepare_meta_filters( $validated_args );

		if ( '' === $search_term && empty( $taxonomy_filters ) && empty( $meta_filters ) ) {
			return new WP_Error( 'wp_mcp_ai_missing_criteria', __( 'Provide a search term, taxonomy filter, or meta filter to narrow the results.', 'nvdigital-open-operator-system-oos' ) );
		}

		$query_args = array(
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $limit,
			'orderby'                => 'date',
			'order'                  => 'DESC',
			'ignore_sticky_posts'    => true,
			'suppress_filters'       => false,
			'no_found_rows'          => true,  // Performance: Skip counting total rows.
			'update_post_term_cache' => false, // Performance: Skip term cache if not using taxonomy data.
			'update_post_meta_cache' => true,  // Keep meta cache as we need post meta.
		);

		if ( '' !== $search_term ) {
			$query_args['s'] = $search_term;
		}

		if ( ! empty( $taxonomy_filters ) ) {
			$query_args['tax_query'] = $taxonomy_filters; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- tax_query required for taxonomy-based content filtering; no alternative index-based query available.
		}

		if ( ! empty( $meta_filters ) ) {
			$query_args['meta_query'] = $meta_filters; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- meta_query required for user-defined content search filters; no alternative index-based query available.
		}

		$query = new WP_Query( $query_args );

		$results = array();
		foreach ( $query->posts as $post ) {
			$post_id = $post instanceof WP_Post ? $post->ID : $post;

			$results[] = array(
				'ID'        => $post_id,
				'title'     => get_the_title( $post_id ),
				'permalink' => get_permalink( $post_id ),
				'excerpt'   => wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ), 30 ),
				'date'      => get_the_date( DATE_W3C, $post_id ),
				'post_type' => get_post_type( $post_id ),
			);
		}

		$summary_text = sprintf(
			/* translators: 1: number of results, 2: search term */
			__( 'Found %1$d result(s) for "%2$s"', 'nvdigital-open-operator-system-oos' ),
			count( $results ),
			$search_term
		);

		return array(
			'message' => $summary_text,
			'summary' => $summary_text,
			'results' => $results,
			'count'   => count( $results ),
		);
	}

	/**
	 * Prepare a tax_query argument from validated inputs.
	 *
	 * @param \WP_MCP_AI\Tools\Arguments\SearchContentArguments $validated_args Validated arguments.
	 * @return array
	 */
	protected function prepare_taxonomy_filters( $validated_args ) {
		if ( empty( $validated_args->taxonomy_filters ) || ! is_array( $validated_args->taxonomy_filters ) ) {
			return array();
		}

		$relation = strtoupper( sanitize_text_field( $validated_args->taxonomy_relation ) );

		$tax_query = array();

		foreach ( $validated_args->taxonomy_filters as $filter ) {
			if ( ! is_array( $filter ) ) {
				continue;
			}

			$taxonomy = isset( $filter['taxonomy'] ) ? sanitize_key( $filter['taxonomy'] ) : '';
			if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}

			$terms = array();
			if ( isset( $filter['terms'] ) && is_array( $filter['terms'] ) ) {
				$terms = $filter['terms'];
			}

			$operator = isset( $filter['operator'] ) ? strtoupper( sanitize_text_field( $filter['operator'] ) ) : 'IN';
			$field    = isset( $filter['field'] ) ? sanitize_key( $filter['field'] ) : 'slug';

			if ( ! in_array( $operator, array( 'IN', 'NOT IN', 'AND', 'EXISTS', 'NOT EXISTS' ), true ) ) {
				$operator = 'IN';
			}

			if ( ! in_array( $field, array( 'slug', 'name', 'term_id', 'term_taxonomy_id' ), true ) ) {
				$field = 'slug';
			}

			$sanitized_terms = array();
			foreach ( $terms as $term ) {
				if ( in_array( $field, array( 'term_id', 'term_taxonomy_id' ), true ) ) {
					$sanitized_terms[] = absint( $term );
				} else {
					$sanitized_terms[] = sanitize_text_field( $term );
				}
			}

			$sanitized_terms = array_filter(
				$sanitized_terms,
				static function ( $value ) {
					if ( is_string( $value ) ) {
						return '' !== $value;
					}

					return null !== $value;
				}
			);

			$clause = array(
				'taxonomy' => $taxonomy,
				'field'    => $field,
				'operator' => $operator,
			);

			if ( ! in_array( $operator, array( 'EXISTS', 'NOT EXISTS' ), true ) ) {
				if ( empty( $sanitized_terms ) ) {
					continue;
				}

				$clause['terms'] = array_values( $sanitized_terms );
			}

			$tax_query[] = $clause;
		}

		if ( empty( $tax_query ) ) {
			return array();
		}

		if ( count( $tax_query ) > 1 || 'AND' !== $relation ) {
			array_unshift( $tax_query, array( 'relation' => $relation ) );
		}

		return $tax_query;
	}

	/**
	 * Prepare a meta_query argument from validated inputs.
	 *
	 * @param \WP_MCP_AI\Tools\Arguments\SearchContentArguments $validated_args Validated arguments.
	 * @return array
	 */
	protected function prepare_meta_filters( $validated_args ) {
		if ( empty( $validated_args->meta_filters ) || ! is_array( $validated_args->meta_filters ) ) {
			return array();
		}

		$relation = strtoupper( sanitize_text_field( $validated_args->meta_relation ) );

		$meta_query = array();

		foreach ( $validated_args->meta_filters as $filter ) {
			if ( ! is_array( $filter ) ) {
				continue;
			}

			$key = isset( $filter['key'] ) ? sanitize_key( $filter['key'] ) : '';
			if ( '' === $key ) {
				continue;
			}

			$compare = isset( $filter['compare'] ) ? strtoupper( sanitize_text_field( $filter['compare'] ) ) : '=';
			if ( ! in_array( $compare, array( '=', '!=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'EXISTS', 'NOT EXISTS' ), true ) ) {
				$compare = '=';
			}

			$value = isset( $filter['value'] ) ? $filter['value'] : '';
			if ( in_array( $compare, array( 'IN', 'NOT IN' ), true ) ) {
				$value = is_array( $value ) ? $value : array( $value );
				$value = array_filter( array_map( 'sanitize_text_field', array_map( 'strval', $value ) ) );
				if ( empty( $value ) ) {
					continue;
				}
			} elseif ( in_array( $compare, array( 'EXISTS', 'NOT EXISTS' ), true ) ) {
				$value = null;
			} else {
				$value = sanitize_text_field( (string) $value );
				if ( '' === $value ) {
					continue;
				}
			}

			$clause = array(
				'key'     => $key,
				'compare' => $compare,
			);

			if ( null !== $value ) {
				$clause['value'] = $value;
			}

			if ( ! empty( $filter['type'] ) ) {
				$type = strtoupper( sanitize_text_field( $filter['type'] ) );
				if ( in_array( $type, array( 'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED' ), true ) ) {
					$clause['type'] = $type;
				}
			}

			$meta_query[] = $clause;
		}

		if ( empty( $meta_query ) ) {
			return array();
		}

		if ( count( $meta_query ) > 1 || 'AND' !== $relation ) {
			array_unshift( $meta_query, array( 'relation' => $relation ) );
		}

		return $meta_query;
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'content_publishing',

			'pattern_compatibility' => array( 'orchestrator', 'peer_to_peer' ),

			'profession_tags'       => array( 'writer', 'researcher', 'editor' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',            // Only reads data, does not modify state.
			'local-only',           // No external API calls.
			'requires-capability',  // Requires 'read' capability.
			'cacheable',            // Results can be cached.
		);
	}
}
