<?php
/**
 * Gemini API client wrapper.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_MCP_AI_Gemini_Client' ) ) {
	/**
	 * Provides a wrapper around Gemini's generateContent endpoint.
	 */
	class WP_MCP_AI_Gemini_Client {
		const API_ENDPOINT            = 'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent';
		const API_STREAM_ENDPOINT     = 'https://generativelanguage.googleapis.com/v1beta/models/%s:streamGenerateContent';
		const API_LIST_MODELS         = 'https://generativelanguage.googleapis.com/v1beta/models';
		const API_COUNT_TOKENS        = 'https://generativelanguage.googleapis.com/v1beta/models/%s:countTokens';
		const API_EMBED_CONTENT       = 'https://generativelanguage.googleapis.com/v1beta/models/%s:embedContent';
		const API_BATCH_EMBED_CONTENT = 'https://generativelanguage.googleapis.com/v1beta/models/%s:batchEmbedContent';
		const API_CORPORA_ENDPOINT    = 'https://generativelanguage.googleapis.com/v1beta/corpora';
		const API_BASE_URL            = 'https://generativelanguage.googleapis.com/v1beta/';
		const DEFAULT_BASE_URL        = 'https://generativelanguage.googleapis.com/v1beta';

			/**
			 * In-memory API key override. Set via set_api_key().
			 *
			 * @since 2026.07
			 * @var string|null
			 */
			private $api_key_override = null;

			/**
			 * Retrieve the configured API key.
			 *
			 * @return string
			 */
		public function get_api_key() {
			// If a transient API key was set via set_api_key(), use it instead
			// of the persisted setting. This prevents TOCTOU race conditions
			// when testing a key before saving it.
			if ( isset( $this->api_key_override ) && is_string( $this->api_key_override ) ) {
				return $this->api_key_override;
			}

			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$key      = isset( $settings['gemini_api_key'] ) ? $settings['gemini_api_key'] : '';

			if ( empty( $key ) && class_exists( 'WP_MCP_AI_Credential_Resolver' ) ) {
				$key = WP_MCP_AI_Credential_Resolver::get_api_key( 'gemini' ) ?? '';
			}

			return $key;
		}

			/**
			 * Override the API key for the lifetime of this instance only.
			 *
			 * Use this when testing a key before persisting it, instead of
			 * temporarily writing it to wp_options (which creates a TOCTOU
			 * race condition).
			 *
			 * @since 2026.07
			 * @param string $api_key The API key to use for this instance.
			 */
		public function set_api_key( $api_key ) {
			$this->api_key_override = $api_key;
		}

		/**
		 * Retrieve the configured base URL for the Gemini API.
		 *
		 * When a custom base URL is configured (e.g. for Vertex AI Enterprise
		 * or a Gemini-compatible proxy), all requests are routed through it.
		 *
		 * @return string Base URL without trailing slash.
		 */
		public function get_custom_base_url() {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$base_url = isset( $settings['gemini_base_url'] ) ? trim( $settings['gemini_base_url'] ) : '';

			if ( '' === $base_url ) {
				$base_url = self::DEFAULT_BASE_URL;
			}

			return untrailingslashit( $base_url );
		}

		/**
		 * Resolve a full endpoint URL respecting any custom base URL.
		 *
		 * Replaces the default Gemini API base with the configured base URL
		 * so that all requests honour custom proxy / Vertex AI endpoints.
		 *
		 * @param string $default_url The default Gemini endpoint URL.
		 * @return string Resolved endpoint URL.
		 */
		public function resolve_endpoint( $default_url ) {
			$base_url = $this->get_custom_base_url();

			if ( self::DEFAULT_BASE_URL === $base_url ) {
				return $default_url;
			}

			// Replace the default base with the custom base.
			$path = str_replace( self::DEFAULT_BASE_URL, '', $default_url );

			return $base_url . $path;
		}

		/**
		 * Build the standard HTTP request headers for Gemini API calls.
		 *
		 * Includes x-goog-api-key and Content-Type headers.
		 * Follows Google's API authentication standards including support
		 * for Gemini Enterprise and Vertex AI deployment keys.
		 *
		 * @param string $api_key      API key for the x-goog-api-key header.
		 * @param string $content_type Content-Type header value. Default 'application/json'.
		 * @return array Associative array of HTTP headers.
		 */
		public function build_request_headers( $api_key, $content_type = 'application/json' ) {
			$headers = array(
				'Content-Type'   => $content_type,
				'x-goog-api-key' => $api_key,
			);

			/**
			 * Filter the Gemini request headers before sending.
			 *
			 * Allows third-party plugins to inject or modify headers for all
			 * Gemini API requests (e.g. adding custom tracking or proxy headers).
			 *
			 * @since 2.6.0
			 *
			 * @param array  $headers  Associative array of HTTP headers.
			 * @param string $api_key  The API key being used.
			 */
			$headers = apply_filters( 'wp_mcp_ai_gemini_request_headers', $headers, $api_key );

			return $headers;
		}

		/**
		 * Perform a chat completion request against Gemini.
		 *
		 * @param array $messages Message payload to send to Gemini.
		 * @param array $options  Additional options (model, temperature, tools, timeout).
		 * @return array|WP_Error
		 */
		public function create_chat_completion( array $messages, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$model = $this->resolve_model( $options );

			if ( empty( $model ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_model',
					__( 'No Gemini model has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_model' => __( 'Choose a Gemini model in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$payload = $this->build_payload( $messages, $options );

			if ( is_wp_error( $payload ) ) {
				return $payload;
			}

			// Pre-flight context-window validation (shared with all providers).
			if ( class_exists( 'WP_MCP_AI_Token_Budget_Manager' ) ) {
				$preflight = WP_MCP_AI_Token_Budget_Manager::validate_context_window( $payload, $model, 'gemini', $options, $messages );
				if ( is_wp_error( $preflight ) ) {
					return $preflight;
				}
			}

			$endpoint = $this->resolve_endpoint( sprintf( self::API_ENDPOINT, rawurlencode( $model ) ) );
			$url      = $endpoint;

			$request_args = array(
				'headers' => $this->build_request_headers( $api_key ),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $this->resolve_timeout( $options ),
			);

			WP_MCP_AI_Logger::log_event( 'gemini_request', 'Sending request to Gemini.', array( 'payload' => $this->obfuscate_request_for_log( $payload ) ) );

			// Provider circuit breaker (1.2.0): skip HTTP when circuit is open.
			if ( class_exists( 'WP_MCP_AI_Provider_Circuit_Breaker' ) && ! WP_MCP_AI_Provider_Circuit_Breaker::is_allowed( 'gemini' ) ) {
				return new WP_Error(
					'provider_circuit_open',
					__( 'Gemini API is temporarily unavailable due to repeated failures. Please try again shortly.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'      => 503,
						'retry_after' => 60,
					)
				);
			}

			$response = wp_remote_post( $url, $request_args );

			// Provider circuit breaker: track success/failure.
			if ( class_exists( 'WP_MCP_AI_Provider_Circuit_Breaker' ) ) {
				if ( is_wp_error( $response ) ) {
					WP_MCP_AI_Provider_Circuit_Breaker::record_failure( 'gemini' );
				} else {
					$cb_status = wp_remote_retrieve_response_code( $response );
					if ( $cb_status >= 500 ) {
						WP_MCP_AI_Provider_Circuit_Breaker::record_failure( 'gemini' );
					} else {
						WP_MCP_AI_Provider_Circuit_Breaker::record_success( 'gemini' );
					}
				}
			}

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini API request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code     = wp_remote_retrieve_response_code( $response );
			$body     = wp_remote_retrieve_body( $response );
			$decoded  = json_decode( $body, true );
			$json_err = json_last_error();

			if ( JSON_ERROR_NONE !== $json_err ) {
				WP_MCP_AI_Logger::log_error( 'Failed to decode Gemini response.', array( 'body' => $body ) );

				return new WP_Error( 'wp_mcp_ai_invalid_response', __( 'The Gemini API returned malformed JSON.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Gemini.', 'nvdigital-open-operator-system-oos' );

				WP_MCP_AI_Logger::log_error(
					'Gemini returned an error response.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $decoded,
					)
				);
			}

			$normalized = $this->normalize_response( $decoded );

			if ( ! isset( $normalized['model'] ) && ! empty( $model ) ) {
				$normalized['model'] = $model;
			}

			WP_MCP_AI_Logger::log_event( 'gemini_response', 'Gemini request completed.', array( 'response' => $normalized ) );

			return $normalized;
		}

		/**
		 * Generate an image using Gemini's multimodal endpoint.
		 *
		 * @param string $prompt  Natural language prompt describing the desired image.
		 * @param array  $options Optional overrides (model, mime_type, aspect_ratio, timeout).
		 * @return array|WP_Error
		 */
		public function generate_image( $prompt, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$prompt = sanitize_textarea_field( $prompt );

			if ( '' === $prompt ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_prompt',
					__( 'A text prompt must be supplied to generate an image.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			$default_model        = isset( $settings['gemini_image_model'] ) && '' !== $settings['gemini_image_model'] ? sanitize_text_field( $settings['gemini_image_model'] ) : 'gemini-3.1-flash-image';
			$default_mime_type    = isset( $settings['gemini_image_mime_type'] ) && '' !== $settings['gemini_image_mime_type'] ? $this->normalise_image_mime_type( $settings['gemini_image_mime_type'] ) : 'image/png';
			$default_aspect_ratio = isset( $settings['gemini_image_aspect_ratio'] ) && '' !== $settings['gemini_image_aspect_ratio'] ? $this->normalise_aspect_ratio( $settings['gemini_image_aspect_ratio'] ) : '4:3';

			$model        = isset( $options['model'] ) && '' !== $options['model'] ? sanitize_text_field( $options['model'] ) : $default_model;
			$mime_type    = isset( $options['mime_type'] ) && '' !== $options['mime_type'] ? $this->normalise_image_mime_type( $options['mime_type'] ) : $default_mime_type;
			$aspect_ratio = isset( $options['aspect_ratio'] ) && '' !== $options['aspect_ratio'] ? $this->normalise_aspect_ratio( $options['aspect_ratio'] ) : $default_aspect_ratio;

			if ( '' === $mime_type ) {
				$mime_type = 'image/png';
			}

			if ( '' === $aspect_ratio ) {
				$aspect_ratio = '4:3';
			}

			$payload = array(
				'contents' => array(
					array(
						'role'  => 'user',
						'parts' => array(
							array(
								'text' => $prompt,
							),
						),
					),
				),
			);

			$generation_config = array(
				'responseModalities' => array( 'IMAGE' ),
			);

			$image_config = array();

			// Only set aspectRatio if it's not "auto" (let AI decide).
			if ( '' !== $aspect_ratio && 'auto' !== $aspect_ratio ) {
				$image_config['aspectRatio'] = $aspect_ratio;
			}

			if ( ! empty( $image_config ) ) {
				$generation_config['imageConfig'] = $image_config;
			}

			if ( array_key_exists( 'temperature', $options ) && '' !== $options['temperature'] && null !== $options['temperature'] ) {
				$generation_config['temperature'] = (float) $options['temperature'];
			}

			if ( ! empty( $generation_config ) ) {
				$payload['generationConfig'] = $generation_config;
			}

			/**
			 * Allow third parties to filter the Gemini image payload prior to dispatch.
			 *
			 * @param array  $payload Prepared request payload.
			 * @param array  $options Original method options.
			 * @param string $prompt  Prompt text supplied by the caller.
			 */
			$payload = apply_filters( 'wp_mcp_ai_gemini_image_payload', $payload, $options, $prompt );

			$encoded_payload = wp_json_encode( $payload );

			if ( false === $encoded_payload ) {
				return new WP_Error( 'wp_mcp_ai_encoding_error', __( 'Failed to encode the Gemini request payload.', 'nvdigital-open-operator-system-oos' ) );
			}

			$endpoint = $this->resolve_endpoint( sprintf( self::API_ENDPOINT, rawurlencode( $model ) ) );
			$url      = $endpoint;

			$request_args = array(
				'headers' => $this->build_request_headers( $api_key ),
				'timeout' => $this->resolve_timeout( $options ),
				'body'    => $encoded_payload,
			);

			WP_MCP_AI_Logger::log_event(
				'gemini_image_request',
				'Sending image generation request to Gemini.',
				array(
					'model'        => $model,
					'mime_type'    => $mime_type,
					'aspect_ratio' => $aspect_ratio,
				)
			);

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini image request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini API request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code     = wp_remote_retrieve_response_code( $response );
			$body     = wp_remote_retrieve_body( $response );
			$decoded  = json_decode( $body, true );
			$json_err = json_last_error();

			if ( JSON_ERROR_NONE !== $json_err ) {
				WP_MCP_AI_Logger::log_error( 'Failed to decode Gemini image response.', array( 'body' => $body ) );

				return new WP_Error( 'wp_mcp_ai_invalid_response', __( 'The Gemini API returned malformed JSON.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Gemini.', 'nvdigital-open-operator-system-oos' );

				WP_MCP_AI_Logger::log_error(
					'Gemini returned an error response for image generation.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $decoded,
					)
				);
			}

			$image_payload = $this->extract_image_payload_from_response( $decoded, $options );

			if ( is_wp_error( $image_payload ) ) {
				return $image_payload;
			}

			$result = array(
				'image'          => $image_payload['data'],
				'mime_type'      => $image_payload['mime_type'],
				'format'         => $image_payload['format'],
				'model'          => $model,
				'prompt'         => $prompt,
				'aspect_ratio'   => $aspect_ratio,
				'created'        => time(),
				'revised_prompt' => $image_payload['revised_prompt'],
			);

			// Extract usage metadata from the response for token tracking.
			if ( isset( $decoded['usageMetadata'] ) && is_array( $decoded['usageMetadata'] ) ) {
				$usage = array();

				if ( isset( $decoded['usageMetadata']['promptTokenCount'] ) ) {
					$usage['prompt_tokens'] = (int) $decoded['usageMetadata']['promptTokenCount'];
				}

				if ( isset( $decoded['usageMetadata']['candidatesTokenCount'] ) ) {
					$usage['completion_tokens'] = (int) $decoded['usageMetadata']['candidatesTokenCount'];
				}

				if ( isset( $decoded['usageMetadata']['totalTokenCount'] ) ) {
					$usage['total_tokens'] = (int) $decoded['usageMetadata']['totalTokenCount'];
				}

				if ( ! empty( $usage ) ) {
					$result['usage'] = $usage;
				}
			}

			/**
			 * Allow third parties to filter the Gemini image result payload.
			 *
			 * @param array $result        Normalised image response payload.
			 * @param array $decoded       Raw decoded API response.
			 * @param array $options       Original method options.
			 */
			$result = apply_filters( 'wp_mcp_ai_gemini_image_result', $result, $decoded, $options );

			WP_MCP_AI_Logger::log_event(
				'gemini_image_response',
				'Gemini image generation completed.',
				array(
					'model'        => $model,
					'mime_type'    => $result['mime_type'],
					'aspect_ratio' => $aspect_ratio,
					'format'       => $result['format'],
				)
			);

			return $result;
		}

		/**
		 * Edit an image using Gemini's image editing capabilities (Nano Banana).
		 *
		 * @param string $prompt  Natural language prompt describing the desired edits.
		 * @param array  $options Optional overrides (model, source_image, mime_type, aspect_ratio, timeout).
		 * @return array|WP_Error Edited image data or error.
		 */
		public function edit_image( $prompt, array $options = array() ) {
			// Image editing uses the same endpoint as generation, but with a source image.
			// Gemini's Nano Banana processes both generation and editing.
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$prompt = sanitize_textarea_field( $prompt );

			if ( '' === $prompt ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_prompt',
					__( 'A text prompt must be supplied to edit an image.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			// Source image is required for editing.
			if ( empty( $options['source_image'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_source_image',
					__( 'A source image must be provided for editing.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			$source_image = $options['source_image'];

			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			$default_model        = isset( $settings['gemini_image_model'] ) && '' !== $settings['gemini_image_model'] ? sanitize_text_field( $settings['gemini_image_model'] ) : 'gemini-3.1-flash-image';
			$default_mime_type    = isset( $settings['gemini_image_mime_type'] ) && '' !== $settings['gemini_image_mime_type'] ? $this->normalise_image_mime_type( $settings['gemini_image_mime_type'] ) : 'image/png';
			$default_aspect_ratio = isset( $settings['gemini_image_aspect_ratio'] ) && '' !== $settings['gemini_image_aspect_ratio'] ? $this->normalise_aspect_ratio( $settings['gemini_image_aspect_ratio'] ) : '4:3';

			$model        = isset( $options['model'] ) && '' !== $options['model'] ? sanitize_text_field( $options['model'] ) : $default_model;
			$mime_type    = isset( $options['mime_type'] ) && '' !== $options['mime_type'] ? $this->normalise_image_mime_type( $options['mime_type'] ) : $default_mime_type;
			$aspect_ratio = isset( $options['aspect_ratio'] ) && '' !== $options['aspect_ratio'] ? $this->normalise_aspect_ratio( $options['aspect_ratio'] ) : $default_aspect_ratio;

			if ( '' === $mime_type ) {
				$mime_type = 'image/png';
			}

			if ( '' === $aspect_ratio ) {
				$aspect_ratio = '4:3';
			}

			// Build payload with source image and edit prompt.
			$payload = array(
				'contents' => array(
					array(
						'role'  => 'user',
						'parts' => array(
							array(
								'text' => $prompt,
							),
							array(
								'inline_data' => array(
									'mime_type' => $source_image['mime_type'],
									'data'      => $source_image['data'],
								),
							),
						),
					),
				),
			);

			$generation_config = array(
				'responseModalities' => array( 'IMAGE' ),
			);

			$image_config = array();

			// Only set aspectRatio if it's not "auto" (let AI decide).
			if ( '' !== $aspect_ratio && 'auto' !== $aspect_ratio ) {
				$image_config['aspectRatio'] = $aspect_ratio;
			}

			if ( ! empty( $image_config ) ) {
				$generation_config['imageConfig'] = $image_config;
			}

			if ( array_key_exists( 'temperature', $options ) && '' !== $options['temperature'] && null !== $options['temperature'] ) {
				$generation_config['temperature'] = (float) $options['temperature'];
			}

			if ( ! empty( $generation_config ) ) {
				$payload['generationConfig'] = $generation_config;
			}

			/**
			 * Allow third parties to filter the Gemini image edit payload prior to dispatch.
			 *
			 * @param array  $payload Prepared request payload.
			 * @param array  $options Original method options.
			 * @param string $prompt  Prompt text supplied by the caller.
			 */
			$payload = apply_filters( 'wp_mcp_ai_gemini_image_edit_payload', $payload, $options, $prompt );

			$encoded_payload = wp_json_encode( $payload );

			if ( false === $encoded_payload ) {
				return new WP_Error( 'wp_mcp_ai_encoding_error', __( 'Failed to encode the Gemini request payload.', 'nvdigital-open-operator-system-oos' ) );
			}

			$endpoint = $this->resolve_endpoint( sprintf( self::API_ENDPOINT, rawurlencode( $model ) ) );
			$url      = $endpoint;

			$request_args = array(
				'headers' => $this->build_request_headers( $api_key ),
				'timeout' => $this->resolve_timeout( $options ),
				'body'    => $encoded_payload,
			);

			WP_MCP_AI_Logger::log_event(
				'gemini_image_edit_request',
				'Sending image edit request to Gemini.',
				array(
					'model'        => $model,
					'mime_type'    => $mime_type,
					'aspect_ratio' => $aspect_ratio,
				)
			);

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini image edit request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini API request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code     = wp_remote_retrieve_response_code( $response );
			$body     = wp_remote_retrieve_body( $response );
			$decoded  = json_decode( $body, true );
			$json_err = json_last_error();

			if ( JSON_ERROR_NONE !== $json_err ) {
				WP_MCP_AI_Logger::log_error( 'Failed to decode Gemini image edit response.', array( 'body' => $body ) );

				return new WP_Error( 'wp_mcp_ai_invalid_response', __( 'The Gemini API returned malformed JSON.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Gemini.', 'nvdigital-open-operator-system-oos' );

				WP_MCP_AI_Logger::log_error(
					'Gemini returned an error response for image editing.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $decoded,
					)
				);
			}

			$image_payload = $this->extract_image_payload_from_response( $decoded, $options );

			if ( is_wp_error( $image_payload ) ) {
				return $image_payload;
			}

			$result = array(
				'image'          => $image_payload['data'],
				'mime_type'      => $image_payload['mime_type'],
				'format'         => $image_payload['format'],
				'model'          => $model,
				'prompt'         => $prompt,
				'aspect_ratio'   => $aspect_ratio,
				'created'        => time(),
				'revised_prompt' => $image_payload['revised_prompt'],
			);

			// Extract usage metadata from the response for token tracking.
			if ( isset( $decoded['usageMetadata'] ) && is_array( $decoded['usageMetadata'] ) ) {
				$usage = array();

				if ( isset( $decoded['usageMetadata']['promptTokenCount'] ) ) {
					$usage['prompt_tokens'] = (int) $decoded['usageMetadata']['promptTokenCount'];
				}

				if ( isset( $decoded['usageMetadata']['candidatesTokenCount'] ) ) {
					$usage['completion_tokens'] = (int) $decoded['usageMetadata']['candidatesTokenCount'];
				}

				if ( isset( $decoded['usageMetadata']['totalTokenCount'] ) ) {
					$usage['total_tokens'] = (int) $decoded['usageMetadata']['totalTokenCount'];
				}

				if ( ! empty( $usage ) ) {
					$result['usage'] = $usage;
				}
			}

			/**
			 * Allow third parties to filter the Gemini image edit result payload.
			 *
			 * @param array $result        Normalised image response payload.
			 * @param array $decoded       Raw decoded API response.
			 * @param array $options       Original method options.
			 */
			$result = apply_filters( 'wp_mcp_ai_gemini_image_edit_result', $result, $decoded, $options );

			WP_MCP_AI_Logger::log_event(
				'gemini_image_edit_response',
				'Gemini image edit completed.',
				array(
					'model'        => $model,
					'mime_type'    => $result['mime_type'],
					'aspect_ratio' => $aspect_ratio,
					'format'       => $result['format'],
				)
			);

			return $result;
		}

		/**
		 * List available models from Gemini.
		 *
		 * @param array $options Optional parameters (page_size, page_token, timeout, bypass_cache).
		 * @return array|WP_Error Array containing models list or WP_Error on failure.
		 */
		public function list_models( array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			// Check if caching is enabled.
			$settings     = WP_MCP_AI_Admin_Settings::get_settings();
			$use_cache    = ! empty( $settings['enable_gemini_api_caching'] );
			$bypass_cache = isset( $options['bypass_cache'] ) && $options['bypass_cache'];

			// Allow disabling via constant.
			if ( defined( 'WP_MCP_AI_DISABLE_API_CACHE' ) && WP_MCP_AI_DISABLE_API_CACHE ) {
				$use_cache = false;
			}

			/**
			 * Filter whether to cache Gemini model list requests.
			 *
			 * @param bool  $use_cache Whether to use caching.
			 * @param array $options   Request options.
			 */
			$use_cache = apply_filters( 'wp_mcp_ai_cache_gemini_models', $use_cache, $options );

			if ( $use_cache && ! $bypass_cache ) {
				// For paginated results, include pagination params in cache key.
				$cache_key_parts = array( 'gemini_models_list' );
				if ( isset( $options['page_size'] ) ) {
					$cache_key_parts[] = 'ps_' . absint( $options['page_size'] );
				}
				if ( isset( $options['page_token'] ) ) {
					$cache_key_parts[] = 'pt_' . md5( sanitize_text_field( $options['page_token'] ) );
				}
				$cache_key = implode( '_', $cache_key_parts );

				// Get cache TTL from settings or use default (12 hours).
				$cache_ttl = isset( $settings['gemini_model_list_cache_ttl'] ) ? absint( $settings['gemini_model_list_cache_ttl'] ) : 12 * HOUR_IN_SECONDS;

				/**
				 * Filter the cache TTL for Gemini model list.
				 *
				 * @param int $cache_ttl Cache TTL in seconds.
				 */
				$cache_ttl = apply_filters( 'wp_mcp_ai_gemini_model_list_ttl', $cache_ttl );

				return WP_MCP_AI_Cache_Helper::remember(
					$cache_key,
					function () use ( $api_key, $options ) {
						return $this->fetch_models_from_api( $api_key, $options );
					},
					$cache_ttl
				);
			}

			return $this->fetch_models_from_api( $api_key, $options );
		}

		/**
		 * Fetch models from Gemini API (internal method).
		 *
		 * @param string $api_key Gemini API key.
		 * @param array  $options Optional parameters.
		 * @return array|WP_Error Array of models or WP_Error on failure.
		 */
		private function fetch_models_from_api( $api_key, $options ) {
			$url = $this->resolve_endpoint( self::API_LIST_MODELS );

			$query_args = array();

			if ( isset( $options['page_size'] ) ) {
				$query_args['pageSize'] = absint( $options['page_size'] );
			}

			if ( isset( $options['page_token'] ) ) {
				$query_args['pageToken'] = sanitize_text_field( $options['page_token'] );
			}

			if ( ! empty( $query_args ) ) {
				$url = add_query_arg( $query_args, $url );
			}

			$request_args = array(
				'headers' => $this->build_request_headers( $api_key ),
				'timeout' => $this->resolve_timeout( $options ),
			);

			WP_MCP_AI_Logger::log_event( 'gemini_list_models', 'Requesting available Gemini models.' );

			$response = wp_remote_get( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini list models request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini API request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code    = wp_remote_retrieve_response_code( $response );
			$body    = wp_remote_retrieve_body( $response );
			$decoded = json_decode( $body, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				WP_MCP_AI_Logger::log_error( 'Failed to decode Gemini list models response.', array( 'body' => $body ) );

				return new WP_Error( 'wp_mcp_ai_invalid_response', __( 'The Gemini API returned malformed JSON.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Gemini.', 'nvdigital-open-operator-system-oos' );

				WP_MCP_AI_Logger::log_error(
					'Gemini returned an error response for list models.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $decoded,
					)
				);
			}

			WP_MCP_AI_Logger::log_event( 'gemini_list_models_response', 'Gemini models list retrieved successfully.' );

			return $decoded;
		}


		/**
		 * Count tokens for a given content payload.
		 *
		 * @param array $messages Message payload to count tokens for.
		 * @param array $options  Additional options (model, timeout, bypass_cache).
		 * @return array|WP_Error Token count data or WP_Error on failure.
		 */
		public function count_tokens( array $messages, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$model = $this->resolve_model( $options );

			if ( empty( $model ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_model',
					__( 'No Gemini model has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_model' => __( 'Choose a Gemini model in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			// Check if caching is enabled.
			$settings     = WP_MCP_AI_Admin_Settings::get_settings();
			$use_cache    = ! empty( $settings['enable_gemini_api_caching'] );
			$bypass_cache = isset( $options['bypass_cache'] ) && $options['bypass_cache'];

			// Allow disabling via constant.
			if ( defined( 'WP_MCP_AI_DISABLE_API_CACHE' ) && WP_MCP_AI_DISABLE_API_CACHE ) {
				$use_cache = false;
			}

			/**
			 * Filter whether to cache Gemini token count requests.
			 *
			 * @param bool  $use_cache Whether to use caching.
			 * @param array $messages  Messages to count.
			 * @param array $options   Request options.
			 */
			$use_cache = apply_filters( 'wp_mcp_ai_cache_gemini_token_count', $use_cache, $messages, $options );

			if ( $use_cache && ! $bypass_cache ) {
				// Build cache key from messages and model.
				$cache_key_data = array(
					'messages' => $messages,
					'model'    => $model,
				);

				$cache_key = 'gemini_token_count_' . md5( wp_json_encode( $cache_key_data ) );

				// Get cache TTL from settings or use default (1 hour).
				$cache_ttl = isset( $settings['gemini_token_count_cache_ttl'] ) ? absint( $settings['gemini_token_count_cache_ttl'] ) : HOUR_IN_SECONDS;

				/**
				 * Filter the cache TTL for Gemini token count.
				 *
				 * @param int   $cache_ttl Cache TTL in seconds.
				 * @param array $options   Request options.
				 */
				$cache_ttl = apply_filters( 'wp_mcp_ai_gemini_token_count_ttl', $cache_ttl, $options );

				return WP_MCP_AI_Cache_Helper::remember(
					$cache_key,
					function () use ( $api_key, $messages, $options, $model ) {
						return $this->fetch_token_count_from_api( $api_key, $messages, $options, $model );
					},
					$cache_ttl
				);
			}

			return $this->fetch_token_count_from_api( $api_key, $messages, $options, $model );
		}

		/**
		 * Fetch token count from Gemini API (internal method).
		 *
		 * @param string $api_key Gemini API key.
		 * @param array  $messages Messages to count.
		 * @param array  $options Optional parameters.
		 * @param string $model   Model name.
		 * @return array|WP_Error Token count data or WP_Error on failure.
		 */
		private function fetch_token_count_from_api( $api_key, $messages, $options, $model ) {
			$payload = $this->build_payload( $messages, $options );

			if ( is_wp_error( $payload ) ) {
				return $payload;
			}

			$endpoint = $this->resolve_endpoint( sprintf( self::API_COUNT_TOKENS, rawurlencode( $model ) ) );
			$url      = $endpoint;

			$request_args = array(
				'headers' => $this->build_request_headers( $api_key ),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $this->resolve_timeout( $options ),
			);

			WP_MCP_AI_Logger::log_event( 'gemini_count_tokens', 'Sending token count request to Gemini.' );

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini token count request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini API request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code    = wp_remote_retrieve_response_code( $response );
			$body    = wp_remote_retrieve_body( $response );
			$decoded = json_decode( $body, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				WP_MCP_AI_Logger::log_error( 'Failed to decode Gemini token count response.', array( 'body' => $body ) );

				return new WP_Error( 'wp_mcp_ai_invalid_response', __( 'The Gemini API returned malformed JSON.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Gemini.', 'nvdigital-open-operator-system-oos' );

				WP_MCP_AI_Logger::log_error(
					'Gemini returned an error response for token count.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $decoded,
					)
				);
			}

			WP_MCP_AI_Logger::log_event( 'gemini_count_tokens_response', 'Gemini token count completed.' );

			return $decoded;
		}


		/**
		 * Create text embeddings for RAG/semantic search.
		 *
		 * @param string $text    Text content to embed.
		 * @param array  $options Additional options:
		 *                        - model (string): Embedding model. Defaults to 'gemini-embedding-001'.
		 *                        - task_type (string): Optimisation hint — RETRIEVAL_QUERY, RETRIEVAL_DOCUMENT,
		 *                          SEMANTIC_SIMILARITY, CLASSIFICATION, CLUSTERING, QUESTION_ANSWERING,
		 *                          FACT_VERIFICATION, CODE_RETRIEVAL_QUERY.
		 *                        - title (string): Optional document title (RETRIEVAL_DOCUMENT only).
		 *                        - output_dimensionality (int): Reduce embedding dimensions (e.g. 768, 1536, 3072).
		 *                        - timeout (int): HTTP request timeout in seconds.
		 *                        - bypass_cache (bool): Skip transient cache for this request.
		 * @return array|WP_Error Embedding data or WP_Error on failure.
		 */
		public function create_embedding( $text, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$text = sanitize_textarea_field( $text );

			if ( '' === $text ) {
				return new WP_Error(
					'wp_mcp_ai_missing_text',
					__( 'No text content was provided for embedding.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			// Check if caching is enabled.
			$settings     = WP_MCP_AI_Admin_Settings::get_settings();
			$use_cache    = ! empty( $settings['enable_gemini_api_caching'] );
			$bypass_cache = isset( $options['bypass_cache'] ) && $options['bypass_cache'];

			// Allow disabling via constant.
			if ( defined( 'WP_MCP_AI_DISABLE_API_CACHE' ) && WP_MCP_AI_DISABLE_API_CACHE ) {
				$use_cache = false;
			}

			/**
			 * Filter whether to cache Gemini embedding requests.
			 *
			 * @param bool   $use_cache Whether to use caching.
			 * @param string $text      Text content.
			 * @param array  $options   Request options.
			 */
			$use_cache = apply_filters( 'wp_mcp_ai_cache_gemini_embeddings', $use_cache, $text, $options );

			if ( $use_cache && ! $bypass_cache ) {
				// Build cache key from text and relevant options.
				$model       = isset( $options['model'] ) && '' !== $options['model'] ? sanitize_text_field( $options['model'] ) : 'gemini-embedding-001';
				$task_type   = isset( $options['task_type'] ) && '' !== $options['task_type'] ? sanitize_text_field( $options['task_type'] ) : '';
				$title       = isset( $options['title'] ) && '' !== $options['title'] ? sanitize_text_field( $options['title'] ) : '';
				$output_dims = isset( $options['output_dimensionality'] ) ? absint( $options['output_dimensionality'] ) : 0;

				$cache_key_data = array(
					'text'                  => $text,
					'model'                 => $model,
					'task_type'             => $task_type,
					'title'                 => $title,
					'output_dimensionality' => $output_dims,
				);

				$cache_key = 'gemini_embedding_' . md5( wp_json_encode( $cache_key_data ) );

				// Get cache TTL from settings or use default (24 hours).
				$cache_ttl = isset( $settings['gemini_embedding_cache_ttl'] ) ? absint( $settings['gemini_embedding_cache_ttl'] ) : 24 * HOUR_IN_SECONDS;

				/**
				 * Filter the cache TTL for Gemini embeddings.
				 *
				 * @param int   $cache_ttl Cache TTL in seconds.
				 * @param array $options   Request options.
				 */
				$cache_ttl = apply_filters( 'wp_mcp_ai_gemini_embedding_ttl', $cache_ttl, $options );

				return WP_MCP_AI_Cache_Helper::remember(
					$cache_key,
					function () use ( $api_key, $text, $options ) {
						return $this->fetch_embedding_from_api( $api_key, $text, $options );
					},
					$cache_ttl
				);
			}

			return $this->fetch_embedding_from_api( $api_key, $text, $options );
		}

		/**
		 * Fetch embedding from Gemini API (internal method).
		 *
		 * @param string $api_key Gemini API key.
		 * @param string $text    Text to embed.
		 * @param array  $options Optional parameters.
		 * @return array|WP_Error Embedding data or WP_Error on failure.
		 */
		private function fetch_embedding_from_api( $api_key, $text, $options ) {
			// Default to gemini-embedding-001 model (GA, replaces deprecated text-embedding-004).
			$model = isset( $options['model'] ) && '' !== $options['model'] ? sanitize_text_field( $options['model'] ) : 'gemini-embedding-001';

			$payload = array(
				'content' => array(
					'parts' => array(
						array(
							'text' => $text,
						),
					),
				),
			);

			// Optional task type for optimised embeddings.
			if ( isset( $options['task_type'] ) && '' !== $options['task_type'] ) {
				$task_type = sanitize_text_field( $options['task_type'] );
				// Valid task types per Gemini API docs.
				$allowed_task_types = array(
					'RETRIEVAL_QUERY',
					'RETRIEVAL_DOCUMENT',
					'SEMANTIC_SIMILARITY',
					'CLASSIFICATION',
					'CLUSTERING',
					'QUESTION_ANSWERING',
					'FACT_VERIFICATION',
					'CODE_RETRIEVAL_QUERY',
				);

				if ( in_array( $task_type, $allowed_task_types, true ) ) {
					$payload['taskType'] = $task_type;
				}
			}

			// Optional title for RETRIEVAL_DOCUMENT task type.
			if ( isset( $options['title'] ) && '' !== $options['title'] ) {
				$payload['title'] = sanitize_text_field( $options['title'] );
			}

			// Optional output dimensionality — reduces vector size for storage/latency trade-offs.
			// Typical values for gemini-embedding-001: 768, 1536, 3072. The API validates the value.
			if ( isset( $options['output_dimensionality'] ) && $options['output_dimensionality'] > 0 ) {
				$payload['outputDimensionality'] = absint( $options['output_dimensionality'] );
			}

			/**
			 * Allow third parties to filter the Gemini embedding payload prior to dispatch.
			 *
			 * @param array  $payload Prepared request payload.
			 * @param array  $options Original method options.
			 * @param string $text    Text content supplied by the caller.
			 */
			$payload = apply_filters( 'wp_mcp_ai_gemini_embedding_payload', $payload, $options, $text );

			$endpoint = $this->resolve_endpoint( sprintf( self::API_EMBED_CONTENT, rawurlencode( $model ) ) );
			$url      = $endpoint;

			$request_args = array(
				'headers' => $this->build_request_headers( $api_key ),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $this->resolve_timeout( $options ),
			);

			WP_MCP_AI_Logger::log_event( 'gemini_create_embedding', 'Sending embedding request to Gemini.', array( 'model' => $model ) );

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini embedding request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini API request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code    = wp_remote_retrieve_response_code( $response );
			$body    = wp_remote_retrieve_body( $response );
			$decoded = json_decode( $body, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				WP_MCP_AI_Logger::log_error( 'Failed to decode Gemini embedding response.', array( 'body' => $body ) );

				return new WP_Error( 'wp_mcp_ai_invalid_response', __( 'The Gemini API returned malformed JSON.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Gemini.', 'nvdigital-open-operator-system-oos' );

				WP_MCP_AI_Logger::log_error(
					'Gemini returned an error response for embedding.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $decoded,
					)
				);
			}

			WP_MCP_AI_Logger::log_event( 'gemini_embedding_response', 'Gemini embedding completed.', array( 'model' => $model ) );

			return $decoded;
		}


		/**
		 * Create embeddings for multiple text inputs in batch.
		 *
		 * This method is more efficient than calling create_embedding() multiple times
		 * as it processes all texts in a single API request.
		 *
		 * @param array $texts   Array of text strings to embed.
		 * @param array $options Optional parameters:
		 *                       - model (string): Embedding model (default: 'gemini-embedding-001').
		 *                       - task_type (string): Optimisation hint — RETRIEVAL_QUERY, RETRIEVAL_DOCUMENT,
		 *                         SEMANTIC_SIMILARITY, CLASSIFICATION, CLUSTERING, QUESTION_ANSWERING,
		 *                         FACT_VERIFICATION, CODE_RETRIEVAL_QUERY.
		 *                       - output_dimensionality (int): Reduce embedding dimensions (e.g. 768, 1536, 3072).
		 *                       - timeout (int): Request timeout in seconds.
		 *                       - bypass_cache (bool): Skip cache for this request.
		 * @return array|WP_Error Batch embedding results with 'embeddings' array or error.
		 */
		public function batch_embed_content( $texts, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			if ( empty( $texts ) || ! is_array( $texts ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_texts',
					__( 'No text content was provided for batch embedding.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			// Check if caching is enabled.
			$settings     = WP_MCP_AI_Admin_Settings::get_settings();
			$use_cache    = ! empty( $settings['enable_gemini_api_caching'] );
			$bypass_cache = isset( $options['bypass_cache'] ) && $options['bypass_cache'];

			// Allow disabling via constant.
			if ( defined( 'WP_MCP_AI_DISABLE_API_CACHE' ) && WP_MCP_AI_DISABLE_API_CACHE ) {
				$use_cache = false;
			}

			/**
			 * Filter whether to cache Gemini batch embedding requests.
			 *
			 * @param bool  $use_cache Whether to use caching.
			 * @param array $texts     Texts to embed.
			 * @param array $options   Request options.
			 */
			$use_cache = apply_filters( 'wp_mcp_ai_cache_gemini_batch_embeddings', $use_cache, $texts, $options );

			if ( $use_cache && ! $bypass_cache ) {
				// Build cache key from texts and relevant options.
				$model       = isset( $options['model'] ) && '' !== $options['model'] ? sanitize_text_field( $options['model'] ) : 'gemini-embedding-001';
				$task_type   = isset( $options['task_type'] ) && '' !== $options['task_type'] ? sanitize_text_field( $options['task_type'] ) : '';
				$output_dims = isset( $options['output_dimensionality'] ) ? absint( $options['output_dimensionality'] ) : 0;

				$cache_key_data = array(
					'texts'                 => $texts,
					'model'                 => $model,
					'task_type'             => $task_type,
					'output_dimensionality' => $output_dims,
				);

				$cache_key = 'gemini_batch_embedding_' . md5( wp_json_encode( $cache_key_data ) );

				// Get cache TTL from settings or use default (24 hours - same as single embeddings).
				$cache_ttl = isset( $settings['gemini_embedding_cache_ttl'] ) ? absint( $settings['gemini_embedding_cache_ttl'] ) : 24 * HOUR_IN_SECONDS;

				/**
				 * Filter the cache TTL for Gemini batch embeddings.
				 *
				 * @param int   $cache_ttl Cache TTL in seconds.
				 * @param array $options   Request options.
				 */
				$cache_ttl = apply_filters( 'wp_mcp_ai_gemini_batch_embedding_ttl', $cache_ttl, $options );

				return WP_MCP_AI_Cache_Helper::remember(
					$cache_key,
					function () use ( $api_key, $texts, $options ) {
						return $this->fetch_batch_embeddings_from_api( $api_key, $texts, $options );
					},
					$cache_ttl
				);
			}

			return $this->fetch_batch_embeddings_from_api( $api_key, $texts, $options );
		}

		/**
		 * Fetch batch embeddings from Gemini API (internal method).
		 *
		 * @param string $api_key Gemini API key.
		 * @param array  $texts   Texts to embed.
		 * @param array  $options Optional parameters.
		 * @return array|WP_Error Batch embedding data or WP_Error on failure.
		 */
		private function fetch_batch_embeddings_from_api( $api_key, $texts, $options ) {
			// Default to gemini-embedding-001 model (GA, replaces deprecated text-embedding-004).
			$model = isset( $options['model'] ) && '' !== $options['model'] ? sanitize_text_field( $options['model'] ) : 'gemini-embedding-001';

			// Resolve shared options once before the loop.
			$task_type             = '';
			$output_dimensionality = 0;

			if ( isset( $options['task_type'] ) && '' !== $options['task_type'] ) {
				$candidate = sanitize_text_field( $options['task_type'] );
				// Valid task types per Gemini API docs.
				$allowed_task_types = array(
					'RETRIEVAL_QUERY',
					'RETRIEVAL_DOCUMENT',
					'SEMANTIC_SIMILARITY',
					'CLASSIFICATION',
					'CLUSTERING',
					'QUESTION_ANSWERING',
					'FACT_VERIFICATION',
					'CODE_RETRIEVAL_QUERY',
				);
				if ( in_array( $candidate, $allowed_task_types, true ) ) {
					$task_type = $candidate;
				}
			}

			if ( isset( $options['output_dimensionality'] ) && $options['output_dimensionality'] > 0 ) {
				$output_dimensionality = absint( $options['output_dimensionality'] );
			}

			// Build requests array.
			$requests = array();
			foreach ( $texts as $text ) {
				$sanitized_text = sanitize_textarea_field( $text );
				if ( '' === $sanitized_text ) {
					continue;
				}

				$request = array(
					// model is always required per-request in batchEmbedContents.
					'model'   => 'models/' . $model,
					'content' => array(
						'parts' => array(
							array( 'text' => $sanitized_text ),
						),
					),
				);

				if ( '' !== $task_type ) {
					$request['taskType'] = $task_type;
				}

				if ( $output_dimensionality > 0 ) {
					$request['outputDimensionality'] = $output_dimensionality;
				}

				$requests[] = $request;
			}

			if ( empty( $requests ) ) {
				return new WP_Error(
					'wp_mcp_ai_empty_batch',
					__( 'No valid text content was provided for batch embedding after sanitization.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			$payload = array( 'requests' => $requests );

			/**
			 * Allow third parties to filter the Gemini batch embedding payload prior to dispatch.
			 *
			 * @param array $payload Prepared request payload.
			 * @param array $options Original method options.
			 * @param array $texts   Text content supplied by the caller.
			 */
			$payload = apply_filters( 'wp_mcp_ai_gemini_batch_embedding_payload', $payload, $options, $texts );

			$endpoint = $this->resolve_endpoint( sprintf( self::API_BATCH_EMBED_CONTENT, rawurlencode( $model ) ) );
			$url      = $endpoint;

			$request_args = array(
				'headers' => $this->build_request_headers( $api_key ),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $this->resolve_timeout( $options ),
			);

			WP_MCP_AI_Logger::log_event(
				'gemini_batch_embed',
				'Sending batch embedding request to Gemini.',
				array(
					'model' => $model,
					'count' => count( $requests ),
				)
			);

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini batch embedding request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini API request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code    = wp_remote_retrieve_response_code( $response );
			$body    = wp_remote_retrieve_body( $response );
			$decoded = json_decode( $body, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				WP_MCP_AI_Logger::log_error( 'Failed to decode Gemini batch embedding response.', array( 'body' => $body ) );

				return new WP_Error( 'wp_mcp_ai_invalid_response', __( 'The Gemini API returned malformed JSON.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Gemini.', 'nvdigital-open-operator-system-oos' );

				WP_MCP_AI_Logger::log_error(
					'Gemini returned an error response for batch embedding.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $decoded,
					)
				);
			}

			WP_MCP_AI_Logger::log_event(
				'gemini_batch_embedding_response',
				'Gemini batch embedding completed.',
				array(
					'model' => $model,
					'count' => count( $requests ),
				)
			);

			return $decoded;
		}


		/**
		 * Perform a streaming chat completion request against Gemini.
		 *
		 * @param array    $messages Message payload to send to Gemini.
		 * @param array    $options  Additional options (model, temperature, tools, timeout).
		 * @param callable $callback Callback function to process each chunk of streaming data.
		 * @return array|WP_Error Final response summary or WP_Error on failure.
		 */
		public function stream_chat_completion( array $messages, array $options = array(), $callback = null ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$model = $this->resolve_model( $options );

			if ( empty( $model ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_model',
					__( 'No Gemini model has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_model' => __( 'Choose a Gemini model in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$payload = $this->build_payload( $messages, $options );

			if ( is_wp_error( $payload ) ) {
				return $payload;
			}

			$endpoint = $this->resolve_endpoint( sprintf( self::API_STREAM_ENDPOINT, rawurlencode( $model ) ) );
			$url      = add_query_arg( 'alt', 'sse', $endpoint );

			$request_args = array(
				'headers'  => $this->build_request_headers( $api_key ),
				'body'     => wp_json_encode( $payload ),
				'timeout'  => $this->resolve_timeout( $options ),
				'stream'   => true,
				'blocking' => true,
			);

			WP_MCP_AI_Logger::log_event( 'gemini_stream_request', 'Sending streaming request to Gemini.', array( 'payload' => $this->obfuscate_request_for_log( $payload ) ) );

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini streaming request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini API streaming request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code = wp_remote_retrieve_response_code( $response );
			$body = wp_remote_retrieve_body( $response );

			if ( $code < 200 || $code >= 300 ) {
				$decoded = json_decode( $body, true );
				if ( JSON_ERROR_NONE !== json_last_error() ) {
					$decoded = null;
				}

				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Gemini.', 'nvdigital-open-operator-system-oos' );

				WP_MCP_AI_Logger::log_error(
					'Gemini returned an error response for streaming.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $decoded,
					)
				);
			}

			// Process SSE stream response.
			$accumulated = array(
				'content'    => '',
				'tool_calls' => array(),
				'usage'      => array(),
			);

			$lines = explode( "\n", $body );

			foreach ( $lines as $line ) {
				$line = trim( $line );

				if ( '' === $line || 'data: [DONE]' === $line ) {
					continue;
				}

				if ( 0 === strpos( $line, 'data: ' ) ) {
					$json_str = substr( $line, 6 );
					$chunk    = json_decode( $json_str, true );

					if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $chunk ) ) {
						continue;
					}

					// Process chunk.
					if ( isset( $chunk['candidates'] ) && is_array( $chunk['candidates'] ) ) {
						foreach ( $chunk['candidates'] as $candidate ) {
							if ( isset( $candidate['content']['parts'] ) && is_array( $candidate['content']['parts'] ) ) {
								foreach ( $candidate['content']['parts'] as $part ) {
									if ( isset( $part['text'] ) ) {
										$accumulated['content'] .= $part['text'];

										if ( is_callable( $callback ) ) {
											call_user_func( $callback, $part['text'], 'text' );
										}
									}

									if ( isset( $part['thought'] ) ) {
										// Gemini 2.0 Flash Thinking mode provides thinking text.

										if ( ! isset( $accumulated['thinking'] ) ) {
											$accumulated['thinking'] = '';
										}
										$accumulated['thinking'] .= $part['thought'];

										if ( is_callable( $callback ) ) {
											call_user_func( $callback, $part['thought'], 'thought' );
										}
									}

									if ( isset( $part['functionCall'] ) && is_array( $part['functionCall'] ) ) {
										$accumulated['tool_calls'][] = $part['functionCall'];

										if ( is_callable( $callback ) ) {
											call_user_func( $callback, $part['functionCall'], 'function_call' );
										}
									}
								}
							}
						}
					}

					// Accumulate usage metadata.
					if ( isset( $chunk['usageMetadata'] ) && is_array( $chunk['usageMetadata'] ) ) {
						$accumulated['usage'] = $chunk['usageMetadata'];
					}
				}
			}

			$normalized = array(
				'choices'  => array(
					array(
						'index'   => 0,
						'message' => array(
							'role'    => 'assistant',
							'content' => array(
								array(
									'type' => 'text',
									'text' => $accumulated['content'],
								),
							),
						),
					),
				),
				'provider' => 'gemini',
				'model'    => $model,
			);

			if ( ! empty( $accumulated['tool_calls'] ) ) {
				$normalized['choices'][0]['message']['tool_calls'] = $accumulated['tool_calls'];
			}

			if ( ! empty( $accumulated['usage'] ) ) {
				$usage = array();

				if ( isset( $accumulated['usage']['promptTokenCount'] ) ) {
					$usage['prompt_tokens'] = (int) $accumulated['usage']['promptTokenCount'];
				}

				if ( isset( $accumulated['usage']['candidatesTokenCount'] ) ) {
					$usage['completion_tokens'] = (int) $accumulated['usage']['candidatesTokenCount'];
				}

				if ( isset( $accumulated['usage']['totalTokenCount'] ) ) {
					$usage['total_tokens'] = (int) $accumulated['usage']['totalTokenCount'];
				}

							// Extract cached tokens from Gemini's usageMetadata (streaming).
				if ( isset( $accumulated['usage']['cachedContentTokenCount'] ) ) {
					$usage['cached_tokens'] = (int) $accumulated['usage']['cachedContentTokenCount'];
				}

				if ( ! empty( $usage ) ) {
					$normalized['usage'] = $usage;
				}
			}

			WP_MCP_AI_Logger::log_event( 'gemini_stream_response', 'Gemini streaming request completed.' );

			return $normalized;
		}

		/**
		 * Resolve the model identifier for the request.
		 *
		 * @param array $options Request options.
		 * @return string
		 */
		protected function resolve_model( array $options ) {
			if ( ! empty( $options['model'] ) ) {
				return sanitize_text_field( $options['model'] );
			}

			$settings = WP_MCP_AI_Admin_Settings::get_settings();

			if ( ! empty( $settings['default_gemini_model'] ) ) {
				return $settings['default_gemini_model'];
			}

			return 'gemini-2.5-flash';
		}

		/**
		 * Create a geospatial query with Google Maps grounding.
		 *
		 * @param string $query   Natural language query about locations or places.
		 * @param array  $options Additional options (model, location, timeout).
		 * @return array|WP_Error Response with geospatial context token or error.
		 */
		public function create_geospatial_query( $query, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$query = sanitize_textarea_field( $query );

			if ( '' === $query ) {
				return new WP_Error(
					'wp_mcp_ai_missing_query',
					__( 'A query must be supplied for geospatial search.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			$model = $this->resolve_model( $options );

			if ( empty( $model ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_model',
					__( 'No Gemini model has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_model' => __( 'Choose a Gemini model in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			// Build the payload with Google Maps grounding.
			$payload = array(
				'contents' => array(
					array(
						'role'  => 'user',
						'parts' => array(
							array(
								'text' => $query,
							),
						),
					),
				),
				'tools'    => array(
					array(
						'google_search_retrieval' => array(
							'dynamic_retrieval_config' => array(
								'mode'              => 'MODE_DYNAMIC',
								'dynamic_threshold' => 0.3,
							),
						),
					),
					array(
						'google_maps' => array(
							'enabled' => true,
						),
					),
				),
			);

			// Add optional location context for better results.
			if ( isset( $options['location'] ) && is_array( $options['location'] ) ) {
				if ( isset( $options['location']['latitude'] ) && isset( $options['location']['longitude'] ) ) {
					$payload['location_context'] = array(
						'latitude'  => floatval( $options['location']['latitude'] ),
						'longitude' => floatval( $options['location']['longitude'] ),
					);
				}
			}

			// Add generation config if temperature is specified.
			if ( isset( $options['temperature'] ) ) {
				$payload['generationConfig'] = array(
					'temperature' => floatval( $options['temperature'] ),
				);
			}

			/**
			 * Allow third parties to filter the Gemini geospatial payload prior to dispatch.
			 *
			 * @param array  $payload Prepared request payload.
			 * @param array  $options Original method options.
			 * @param string $query   Query text supplied by the caller.
			 */
			$payload = apply_filters( 'wp_mcp_ai_gemini_geospatial_payload', $payload, $options, $query );

			$endpoint = $this->resolve_endpoint( sprintf( self::API_ENDPOINT, rawurlencode( $model ) ) );
			$url      = $endpoint;

			$request_args = array(
				'headers' => $this->build_request_headers( $api_key ),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $this->resolve_timeout( $options ),
			);

			WP_MCP_AI_Logger::log_event(
				'gemini_geospatial_request',
				'Sending geospatial query request to Gemini with Google Maps grounding.',
				array(
					'query' => $query,
					'model' => $model,
				)
			);

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini geospatial request failed.', array( 'error' => $response->get_error_message() ) );

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini API request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code     = wp_remote_retrieve_response_code( $response );
			$body     = wp_remote_retrieve_body( $response );
			$decoded  = json_decode( $body, true );
			$json_err = json_last_error();

			if ( JSON_ERROR_NONE !== $json_err ) {
				WP_MCP_AI_Logger::log_error( 'Failed to decode Gemini geospatial response.', array( 'body' => $body ) );

				return new WP_Error( 'wp_mcp_ai_invalid_response', __( 'The Gemini API returned malformed JSON.', 'nvdigital-open-operator-system-oos' ) );
			}

			if ( $code < 200 || $code >= 300 ) {
				$error_message = isset( $decoded['error']['message'] ) ? $decoded['error']['message'] : __( 'Unexpected response from Gemini.', 'nvdigital-open-operator-system-oos' );

				WP_MCP_AI_Logger::log_error(
					'Gemini returned an error response for geospatial query.',
					array(
						'code' => $code,
						'body' => $decoded,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $decoded,
					)
				);
			}

			$normalized = $this->normalize_response( $decoded );

			// Extract text content from the first candidate for direct access.
			if ( isset( $decoded['candidates'][0]['content']['parts'] ) && is_array( $decoded['candidates'][0]['content']['parts'] ) ) {
				foreach ( $decoded['candidates'][0]['content']['parts'] as $part ) {
					if ( isset( $part['text'] ) ) {
						$normalized['content'] = (string) $part['text'];
						break;
					}
				}
			}

			// Extract Google Maps context token if available.
			if ( isset( $decoded['candidates'][0]['googleMapsWidgetContextToken'] ) ) {
				$normalized['google_maps_context_token'] = $decoded['candidates'][0]['googleMapsWidgetContextToken'];
			}

			if ( ! isset( $normalized['model'] ) && ! empty( $model ) ) {
				$normalized['model'] = $model;
			}

			WP_MCP_AI_Logger::log_event(
				'gemini_geospatial_response',
				'Gemini geospatial query completed.',
				array(
					'has_context_token' => isset( $normalized['google_maps_context_token'] ),
				)
			);

			return $normalized;
		}

		/**
		 * Build the request payload sent to Gemini.
		 *
		 * @param array $messages Chat messages.
		 * @param array $options  Request options.
		 * @return array|WP_Error
		 */
		protected function build_payload( array $messages, array $options ) {
			if ( empty( $messages ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_messages',
					__( 'No chat messages were provided for the request.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'review_request_payload' => __( 'Provide at least one user or system message before calling the API.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

						// Filter orphaned tool messages before building the Gemini payload.
						// Gemini's API requires every functionCall to be immediately followed
						// by a matching functionResponse in the next user turn.
						$messages = $this->filter_tool_messages_for_payload( $messages );

						// Normalise content arrays into strings for compatibility.
						// The REST layer represents text-only messages as arrays of
						// segments; collapse them back to strings that Gemini expects.
						$messages = $this->normalise_messages_for_payload( $messages );

						$contents               = array();
						$system_fragments       = array();
						$pending_tool_calls     = array();
						$latest_assistant_index = null;

			foreach ( $messages as $message ) {
				if ( ! is_array( $message ) ) {
					continue;
				}

				$role    = isset( $message['role'] ) ? sanitize_key( $message['role'] ) : 'user';
				$content = isset( $message['content'] ) ? $message['content'] : array();

				if ( 'system' === $role ) {
					$system_fragments = array_merge( $system_fragments, $this->normalize_segments_to_text( $content ) );
					continue;
				}

				$text_segments = $this->normalize_segments_to_text( $content );

				if ( empty( $text_segments ) ) {
					$text_segments = array();
				}

				$gemini_role = 'user';
				if ( 'assistant' === $role ) {
					$pending_tool_calls     = array();
					$latest_assistant_index = null;
					$gemini_role            = 'model';
				}

				if ( 'user' === $role ) {
					$pending_tool_calls     = array();
					$latest_assistant_index = null;
				}

				$parts                 = array();
				$message_tool_call_ids = array();

				if ( 'assistant' === $role && ! empty( $message['tool_calls'] ) && is_array( $message['tool_calls'] ) ) {
					foreach ( $message['tool_calls'] as $tool_call ) {
						$function_call = $this->convert_tool_call_to_function_call( $tool_call );

						if ( $function_call ) {
							$parts[] = array( 'functionCall' => $function_call );

							if ( isset( $tool_call['id'] ) ) {
								$tool_call_id = sanitize_text_field( $tool_call['id'] );
								if ( '' !== $tool_call_id ) {
									$message_tool_call_ids[] = $tool_call_id;
								}
							}
						}
					}
				}

				if ( 'tool' === $role ) {
					$gemini_role  = 'user';
					$tool_call_id = isset( $message['tool_call_id'] ) ? sanitize_text_field( $message['tool_call_id'] ) : '';

					if ( '' === $tool_call_id || ! isset( $pending_tool_calls[ $tool_call_id ] ) ) {
						continue;
					}

					$last_index   = count( $contents ) - 1;
					$origin_index = $pending_tool_calls[ $tool_call_id ];

					if ( $last_index < 0 || null === $latest_assistant_index ) {
						unset( $pending_tool_calls[ $tool_call_id ] );
						continue;
					}

					if ( $origin_index !== $latest_assistant_index || $origin_index > $last_index ) {
						unset( $pending_tool_calls[ $tool_call_id ] );
						continue;
					}

					$function_response = $this->convert_tool_message_to_function_response( $message );

					if ( $function_response ) {
						$parts[]       = array( 'functionResponse' => $function_response );
						$text_segments = array();
						unset( $pending_tool_calls[ $tool_call_id ] );
					} else {
						unset( $pending_tool_calls[ $tool_call_id ] );
						continue;
					}
				}

				// Add text segments as text parts.
				foreach ( $text_segments as $segment_text ) {
					$parts[] = array( 'text' => $segment_text );
				}

				// Add file parts (e.g., videos uploaded to Gemini File API).
				if ( 'user' === $role || 'assistant' === $role ) {
					$file_parts = $this->extract_file_parts( $content );
					foreach ( $file_parts as $file_part ) {
						$parts[] = $file_part;
					}
				}

				if ( empty( $parts ) ) {
					continue;
				}

				if ( ! empty( $message_tool_call_ids ) ) {
					$next_index = count( $contents );

					foreach ( $message_tool_call_ids as $tool_call_id ) {
						$pending_tool_calls[ $tool_call_id ] = $next_index;
					}

					$latest_assistant_index = $next_index;
				} elseif ( 'assistant' === $role ) {
					$latest_assistant_index = null;
				}

				$contents[] = array(
					'role'  => $gemini_role,
					'parts' => $parts,
				);

				if ( 'assistant' === $role && null === $latest_assistant_index ) {
					$latest_assistant_index = count( $contents ) - 1;
				}
			}

			if ( ! empty( $options['system_prompt'] ) ) {
				$system_fragments[] = wp_kses_post( $options['system_prompt'] );
			}

			if ( ! empty( $options['memory_documents'] ) && is_array( $options['memory_documents'] ) ) {
				$system_fragments = array_merge( $system_fragments, $this->build_memory_fragments( $options['memory_documents'] ) );
			}

			$payload = array(
				'contents' => array_values( $contents ),
			);

			if ( ! empty( $system_fragments ) ) {
				$system_parts = array();
				foreach ( $system_fragments as $fragment ) {
					$fragment = trim( $fragment );
					if ( '' === $fragment ) {
						continue;
					}
					$system_parts[] = array( 'text' => $fragment );
				}

				if ( ! empty( $system_parts ) ) {
					$payload['system_instruction'] = array( 'parts' => $system_parts );

					// Prompt caching: Gemini 2.5+ models use automatic implicit caching
					// (no inline cache_control needed). The WP_MCP_AI_Prompt_Optimizer
					// already reorders messages to put static content first, maximising
					// cache-hit probability. For older models, explicit caching via the
					// cachedContents API requires pre-creating a cache resource — this is
					// not currently implemented because implicit caching covers the
					// majority of production use (Gemini 2.5+).
				}
			}

			if ( ! isset( $payload['generationConfig'] ) ) {
				$payload['generationConfig'] = array();
			}

			if ( array_key_exists( 'temperature', $options ) && '' !== $options['temperature'] && null !== $options['temperature'] ) {
				$payload['generationConfig']['temperature'] = (float) $options['temperature'];
			}

					// Apply resource-aware max_output_tokens if not explicitly set.
					// Supports max_completion_tokens (OpenAI-compatible), max_tokens, and
					// max_output_tokens (Gemini-native) naming conventions.
			if ( ! isset( $options['max_tokens'] ) && ! isset( $options['max_completion_tokens'] ) && ! isset( $options['max_output_tokens'] ) ) {
				$resource_mgr      = WP_MCP_AI_Resource_Manager::instance();
				$max_output_tokens = $resource_mgr->get_max_tokens();

				/**
				 * Filter the maximum output tokens for Gemini requests.
				 *
				 * @param int   $max_output_tokens The maximum output tokens to use.
				 * @param array $options           Request options.
				 */
				$max_output_tokens = apply_filters( 'wp_mcp_ai_gemini_max_output_tokens', $max_output_tokens, $options );

				if ( $max_output_tokens > 0 ) {
					$payload['generationConfig']['maxOutputTokens'] = $max_output_tokens;
				}
			} elseif ( isset( $options['max_completion_tokens'] ) ) {
				$payload['generationConfig']['maxOutputTokens'] = absint( $options['max_completion_tokens'] );
			} elseif ( isset( $options['max_tokens'] ) ) {
				$payload['generationConfig']['maxOutputTokens'] = absint( $options['max_tokens'] );
			} elseif ( isset( $options['max_output_tokens'] ) ) {
				$payload['generationConfig']['maxOutputTokens'] = absint( $options['max_output_tokens'] );
			}

			// Add support for JSON schema responses.
			if ( isset( $options['response_mime_type'] ) && '' !== $options['response_mime_type'] ) {
				$payload['generationConfig']['responseMimeType'] = sanitize_text_field( $options['response_mime_type'] );
			}

			if ( isset( $options['response_schema'] ) && is_array( $options['response_schema'] ) ) {
				$payload['generationConfig']['responseSchema'] = $options['response_schema'];
			}

			if ( isset( $options['response_json_schema'] ) && is_array( $options['response_json_schema'] ) ) {
				$payload['generationConfig']['responseJsonSchema'] = $options['response_json_schema'];
			}

			// Additional generationConfig sampling parameters.
			if ( isset( $options['top_p'] ) && is_numeric( $options['top_p'] ) ) {
				$payload['generationConfig']['topP'] = (float) $options['top_p'];
			}

			if ( isset( $options['top_k'] ) && is_numeric( $options['top_k'] ) ) {
				$payload['generationConfig']['topK'] = (int) $options['top_k'];
			}

			if ( isset( $options['candidate_count'] ) && is_numeric( $options['candidate_count'] ) ) {
				$payload['generationConfig']['candidateCount'] = max( 1, (int) $options['candidate_count'] );
			}

			if ( ! empty( $options['stop_sequences'] ) && is_array( $options['stop_sequences'] ) ) {
				$payload['generationConfig']['stopSequences'] = array_values( array_map( 'sanitize_text_field', $options['stop_sequences'] ) );
			}

			if ( isset( $options['presence_penalty'] ) && is_numeric( $options['presence_penalty'] ) ) {
				$payload['generationConfig']['presencePenalty'] = (float) $options['presence_penalty'];
			}

			if ( isset( $options['frequency_penalty'] ) && is_numeric( $options['frequency_penalty'] ) ) {
				$payload['generationConfig']['frequencyPenalty'] = (float) $options['frequency_penalty'];
			}

			if ( isset( $options['seed'] ) && is_numeric( $options['seed'] ) ) {
				$payload['generationConfig']['seed'] = (int) $options['seed'];
			}

			// Extended thinking / reasoning support (Gemini 2.5+ models).
			// When thinking_budget_tokens is set, enable the thinkingConfig with the specified budget.
			if ( ! empty( $options['thinking_budget_tokens'] ) && is_numeric( $options['thinking_budget_tokens'] ) ) {
				$payload['generationConfig']['thinkingConfig'] = array(
					'thinkingBudget' => (int) $options['thinking_budget_tokens'],
				);
			}

			// Return log probabilities of output tokens.
			if ( isset( $options['response_logprobs'] ) ) {
				$payload['generationConfig']['responseLogprobs'] = (bool) $options['response_logprobs'];
			}

			if ( isset( $options['logprobs'] ) && is_numeric( $options['logprobs'] ) ) {
				$payload['generationConfig']['logprobs'] = max( 0, min( 20, (int) $options['logprobs'] ) );
			}

			// Response modalities: which output types the model may return (TEXT, IMAGE, AUDIO).
			if ( ! empty( $options['response_modalities'] ) && is_array( $options['response_modalities'] ) ) {
				$allowed_modalities = array( 'TEXT', 'IMAGE', 'AUDIO' );
				$modalities         = array();
				foreach ( $options['response_modalities'] as $modality ) {
					$normalised = strtoupper( (string) $modality );
					if ( in_array( $normalised, $allowed_modalities, true ) ) {
						$modalities[] = $normalised;
					}
				}
				if ( ! empty( $modalities ) ) {
					$payload['generationConfig']['responseModalities'] = $modalities;
				}
			}

			// Media resolution for image inputs: LOW (64 tokens), MEDIUM (256 tokens), HIGH (256 tokens, zoomed).
			$allowed_resolutions = array( 'MEDIA_RESOLUTION_LOW', 'MEDIA_RESOLUTION_MEDIUM', 'MEDIA_RESOLUTION_HIGH' );
			if ( isset( $options['media_resolution'] ) && in_array( $options['media_resolution'], $allowed_resolutions, true ) ) {
				$payload['generationConfig']['mediaResolution'] = $options['media_resolution'];
			}

			if ( empty( $payload['generationConfig'] ) ) {
				unset( $payload['generationConfig'] );
			}

			// Add support for safety settings configuration.
			if ( isset( $options['safety_settings'] ) && is_array( $options['safety_settings'] ) ) {
				$safety_settings = array();

				$allowed_categories = array(
					'HARM_CATEGORY_HARASSMENT',
					'HARM_CATEGORY_HATE_SPEECH',
					'HARM_CATEGORY_SEXUALLY_EXPLICIT',
					'HARM_CATEGORY_DANGEROUS_CONTENT',
				);

				$allowed_thresholds = array(
					'BLOCK_NONE',
					'BLOCK_ONLY_HIGH',
					'BLOCK_MEDIUM_AND_ABOVE',
					'BLOCK_LOW_AND_ABOVE',
					'HARM_BLOCK_THRESHOLD_UNSPECIFIED',
				);

				foreach ( $options['safety_settings'] as $category => $threshold ) {
					// Support both array format and direct category => threshold mapping.
					if ( is_array( $threshold ) ) {
						$cat_value       = isset( $threshold['category'] ) ? sanitize_text_field( $threshold['category'] ) : $category;
						$threshold_value = isset( $threshold['threshold'] ) ? sanitize_text_field( $threshold['threshold'] ) : 'BLOCK_MEDIUM_AND_ABOVE';
					} else {
						$cat_value       = sanitize_text_field( $category );
						$threshold_value = sanitize_text_field( $threshold );
					}

					if ( in_array( $cat_value, $allowed_categories, true ) && in_array( $threshold_value, $allowed_thresholds, true ) ) {
						$safety_settings[] = array(
							'category'  => $cat_value,
							'threshold' => $threshold_value,
						);
					}
				}

				if ( ! empty( $safety_settings ) ) {
					$payload['safetySettings'] = $safety_settings;
				}
			}

			if ( ! empty( $options['tools'] ) && is_array( $options['tools'] ) ) {
				$translated_tools = $this->translate_tools( $options['tools'] );
				if ( ! empty( $translated_tools ) ) {
					$payload['tools'] = $translated_tools;
				}
			}

			// Google Search grounding: enables dynamic retrieval from Google Search.
			// Requires the google_search_grounding option to be truthy.
			if ( ! empty( $options['google_search_grounding'] ) ) {
				$grounding_tool = array( 'googleSearch' => (object) array() );
				if ( isset( $payload['tools'] ) && is_array( $payload['tools'] ) ) {
					$payload['tools'][] = $grounding_tool;
				} else {
					$payload['tools'] = array( $grounding_tool );
				}
			}

			// Code execution tool: lets the model generate and run Python code (sandboxed by Gemini).
			if ( ! empty( $options['code_execution'] ) ) {
				$code_tool = array( 'codeExecution' => (object) array() );
				if ( isset( $payload['tools'] ) && is_array( $payload['tools'] ) ) {
					$payload['tools'][] = $code_tool;
				} else {
					$payload['tools'] = array( $code_tool );
				}
			}

			// Gemini Corpus semantic retrieval (native RAG).
			// When a corpus_name is configured, inject a semanticRetriever tool so the model
			// can ground its responses against the user-provided corpus documents.
			if ( ! empty( $options['corpus_name'] ) ) {
				$corpus_source = sanitize_text_field( $options['corpus_name'] );

				// Ensure the source uses the full "corpora/{id}" resource name format.
				if ( 0 !== strpos( $corpus_source, 'corpora/' ) ) {
					$corpus_source = 'corpora/' . $corpus_source;
				}

				// Extract the last user message to use as the retrieval query.
				$query_text = '';
				for ( $i = count( $messages ) - 1; $i >= 0; $i-- ) {
					if ( isset( $messages[ $i ]['role'] ) && 'user' === $messages[ $i ]['role'] ) {
						$raw_content = isset( $messages[ $i ]['content'] ) ? $messages[ $i ]['content'] : '';
						if ( is_string( $raw_content ) ) {
							$query_text = $raw_content;
						} elseif ( is_array( $raw_content ) ) {
							foreach ( $raw_content as $part ) {
								if ( is_string( $part ) ) {
									$query_text = $part;
									break;
								}
								if ( is_array( $part ) && isset( $part['text'] ) ) {
									$query_text = (string) $part['text'];
									break;
								}
							}
						}
						break;
					}
				}

				$retrieval_tool = array(
					'retrieval' => array(
						'semanticRetriever' => array(
							'source' => $corpus_source,
							'query'  => array(
								'parts' => array(
									array( 'text' => sanitize_text_field( $query_text ) ),
								),
							),
						),
					),
				);

				if ( isset( $payload['tools'] ) && is_array( $payload['tools'] ) ) {
					$payload['tools'][] = $retrieval_tool;
				} else {
					$payload['tools'] = array( $retrieval_tool );
				}
			}

			// Prompt caching: Gemini does not support inline cache_control on
			// tools[] (unlike Anthropic). See system_instruction comment above
			// for details on Gemini's implicit caching mechanism.

			// Tool config: controls function calling behaviour (function_calling_mode: AUTO, ANY, NONE).
			// Optionally restrict to specific function names via allowed_function_names.
			if ( isset( $options['tool_config'] ) && is_array( $options['tool_config'] ) ) {
				$allowed_modes = array( 'AUTO', 'ANY', 'NONE' );
				$fc_mode       = isset( $options['tool_config']['mode'] ) ? strtoupper( sanitize_text_field( $options['tool_config']['mode'] ) ) : '';
				if ( in_array( $fc_mode, $allowed_modes, true ) ) {
					$payload['toolConfig'] = array(
						'functionCallingConfig' => array(
							'mode' => $fc_mode,
						),
					);
					if ( 'ANY' === $fc_mode && ! empty( $options['tool_config']['allowed_function_names'] ) && is_array( $options['tool_config']['allowed_function_names'] ) ) {
						$allowed_names = array();
						foreach ( $options['tool_config']['allowed_function_names'] as $fn_name ) {
							$allowed_names[] = sanitize_text_field( (string) $fn_name );
						}
						$payload['toolConfig']['functionCallingConfig']['allowedFunctionNames'] = $allowed_names;
					}
				}
			}

			return $payload;
		}

		/**
		 * Drop tool role messages that are not associated with the most recent
		 * assistant tool call.
		 *
		 * Gemini's API requires every functionCall to be immediately followed
		 * by a matching functionResponse in the next user turn. When intervening
		 * messages appear between those entries the request may be rejected.
		 * This normaliser filters out any tool messages that no longer have a
		 * matching pending call so the payload remains valid.
		 *
		 * Logic mirrors WP_MCP_AI_OpenAI_Client::filter_tool_messages_for_payload().
		 *
		 * @since 2026.07
		 *
		 * @param array $messages Chat history supplied by the caller.
		 * @return array
		 */
		protected function filter_tool_messages_for_payload( array $messages ) {
			if ( empty( $messages ) ) {
				return $messages;
			}

			$filtered                = array();
			$pending_calls           = array();
			$awaiting_tool_responses = false;
			$incomplete_group_start  = null;

			foreach ( $messages as $message ) {
				if ( ! is_array( $message ) ) {
					continue;
				}

				$role = isset( $message['role'] ) ? sanitize_key( $message['role'] ) : '';

				if ( '' === $role ) {
					continue;
				}

				if ( in_array( $role, array( 'system', 'user' ), true ) ) {
					// If the previous assistant message had tool_calls that were never
					// fully answered, drop the entire incomplete group.
					if ( $awaiting_tool_responses && null !== $incomplete_group_start ) {
						$filtered = array_slice( $filtered, 0, $incomplete_group_start );
						if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
							WP_MCP_AI_Logger::log_event(
								'gemini_dropped_incomplete_tool_group',
								'Dropped assistant message with unresolved tool_calls before user/system message.',
								array(
									'pending_call_ids' => array_keys( $pending_calls ),
								)
							);
						}
					}

					$pending_calls           = array();
					$awaiting_tool_responses = false;
					$incomplete_group_start  = null;
					$filtered[]              = $message;
					continue;
				}

				if ( 'assistant' === $role ) {
					// If the PREVIOUS assistant had unresolved tool_calls, drop that group.
					if ( $awaiting_tool_responses && null !== $incomplete_group_start ) {
						$filtered = array_slice( $filtered, 0, $incomplete_group_start );
						if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
							WP_MCP_AI_Logger::log_event(
								'gemini_dropped_incomplete_tool_group',
								'Dropped assistant message with unresolved tool_calls before next assistant message.',
								array(
									'pending_call_ids' => array_keys( $pending_calls ),
								)
							);
						}
					}

					$pending_calls           = array();
					$awaiting_tool_responses = false;
					$incomplete_group_start  = null;

					if ( isset( $message['tool_calls'] ) && is_array( $message['tool_calls'] ) ) {
						foreach ( $message['tool_calls'] as $tool_call ) {
							if ( ! is_array( $tool_call ) ) {
								continue;
							}

							$call_id = isset( $tool_call['id'] ) ? sanitize_text_field( (string) $tool_call['id'] ) : '';

							if ( '' === $call_id ) {
								continue;
							}

							$pending_calls[ $call_id ] = true;
						}
					}

					if ( ! empty( $pending_calls ) ) {
						$awaiting_tool_responses = true;
						$incomplete_group_start  = count( $filtered );
					}

					$filtered[] = $message;
					continue;
				}

				if ( 'tool' === $role ) {
					$tool_call_id = isset( $message['tool_call_id'] ) ? sanitize_text_field( (string) $message['tool_call_id'] ) : '';

					if ( '' === $tool_call_id || ! $awaiting_tool_responses || ! isset( $pending_calls[ $tool_call_id ] ) ) {
						if ( class_exists( 'WP_MCP_AI_Logger' ) ) {
							WP_MCP_AI_Logger::log_event(
								'gemini_dropped_orphan_tool_message',
								'Dropping tool message without matching tool call before Gemini request.',
								array(
									'tool_call_id' => $tool_call_id,
									'reason'       => '' === $tool_call_id
										? 'missing_tool_call_id'
										: ( $awaiting_tool_responses ? 'tool_call_not_found' : 'no_pending_tool_calls' ),
								)
							);
						}

						continue;
					}

					unset( $pending_calls[ $tool_call_id ] );

					if ( empty( $pending_calls ) ) {
						$awaiting_tool_responses = false;
						$incomplete_group_start  = null;
					}

					$filtered[] = $message;
					continue;
				}

				$pending_calls           = array();
				$awaiting_tool_responses = false;
				$incomplete_group_start  = null;
				$filtered[]              = $message;
			}

			return array_values( $filtered );
		}

		/**
		 * Prepare chat messages for the Gemini payload.
		 *
		 * The REST layer represents text-only messages as arrays of segments so
		 * attachments and tool calls can be normalised consistently. Older
		 * Gemini models may only accept plain strings for the text parts.
		 * To remain compatible we collapse text-only segment arrays back into
		 * strings while preserving multimodal payloads that rely on structured
		 * segments.
		 *
		 * Logic mirrors WP_MCP_AI_OpenAI_Client::normalise_messages_for_payload().
		 *
		 * @since 2026.07
		 *
		 * @param array $messages Sanitised chat messages.
		 * @return array
		 */
		protected function normalise_messages_for_payload( array $messages ) {
			$normalised = array();

			foreach ( $messages as $message ) {
				if ( ! isset( $message['content'] ) || ! is_array( $message['content'] ) ) {
					$normalised[] = $message;
					continue;
				}

				$segments = array_values( $message['content'] );

				if ( empty( $segments ) ) {
					$message['content'] = '';
					$normalised[]       = $message;
					continue;
				}

				$all_text   = true;
				$text_parts = array();

				foreach ( $segments as $segment ) {
					if ( ! is_array( $segment ) ) {
						$all_text = false;
						break;
					}

					$type = isset( $segment['type'] ) ? sanitize_key( $segment['type'] ) : '';

					if ( 'text' !== $type ) {
						$all_text = false;
						break;
					}

					$text_parts[] = isset( $segment['text'] ) ? (string) $segment['text'] : '';
				}

				if ( $all_text ) {
					$text_parts         = array_filter(
						$text_parts,
						static function ( $part ) {
							return '' !== trim( $part );
						}
					);
					$message['content'] = implode( "\n\n", $text_parts );
				} else {
					$message['content'] = $segments;
				}

				$normalised[] = $message;
			}

			return $normalised;
		}

		/**
		 * Normalise segments to text fragments.
		 *
		 * @param mixed $segments Message segments.
		 * @return array
		 */
		protected function normalize_segments_to_text( $segments ) {
			if ( is_string( $segments ) || is_numeric( $segments ) ) {
				$text = trim( wp_kses_post( (string) $segments ) );

				return '' === $text ? array() : array( $text );
			}

			if ( ! is_array( $segments ) ) {
				return array();
			}

			$fragments = array();

			foreach ( $segments as $segment ) {
				if ( is_string( $segment ) || is_numeric( $segment ) ) {
					$text = trim( wp_kses_post( (string) $segment ) );
					if ( '' !== $text ) {
						$fragments[] = $text;
					}
					continue;
				}

				if ( ! is_array( $segment ) ) {
					continue;
				}

				$type = isset( $segment['type'] ) ? sanitize_key( $segment['type'] ) : 'text';

				switch ( $type ) {
					case 'input_text':
					case 'text':
						$text = '';
						if ( isset( $segment['text'] ) ) {
							$text = (string) $segment['text'];
						} elseif ( isset( $segment['content'] ) ) {
							$text = (string) $segment['content'];
						}
						$text = trim( wp_kses_post( $text ) );
						if ( '' !== $text ) {
							$fragments[] = $text;
						}
						break;

					case 'input_image':
						$label = __( '[Image attachment]', 'nvdigital-open-operator-system-oos' );
						if ( isset( $segment['caption'] ) && '' !== $segment['caption'] ) {
							$label = '[Image: ' . sanitize_text_field( $segment['caption'] ) . ']';
						} elseif ( isset( $segment['image_url']['url'] ) && '' !== $segment['image_url']['url'] ) {
							$label = '[Image: ' . esc_url_raw( $segment['image_url']['url'] ) . ']';
						} elseif ( isset( $segment['url'] ) && '' !== $segment['url'] ) {
							$name  = isset( $segment['name'] ) ? sanitize_text_field( $segment['name'] ) : 'Image';
							$label = '[' . $name . ': ' . esc_url_raw( $segment['url'] ) . ']';
						}
						$fragments[] = $label;
						break;

					case 'input_file':
						$label = __( '[File attachment]', 'nvdigital-open-operator-system-oos' );

						// Prefer display_name, fallback to name, or use 'File'.
						$name = 'File';
						if ( isset( $segment['display_name'] ) && '' !== $segment['display_name'] ) {
							$name = sanitize_text_field( $segment['display_name'] );
						} elseif ( isset( $segment['name'] ) && '' !== $segment['name'] ) {
							$name = sanitize_text_field( $segment['name'] );
						}

						// If URL is available, show it with the name.
						if ( isset( $segment['url'] ) && '' !== $segment['url'] ) {
							$label = '[' . $name . ': ' . esc_url_raw( $segment['url'] ) . ']';
						} else {
							$label = '[File: ' . $name . ']';
						}

						$fragments[] = $label;
						break;

					case 'tool_result':
						$result_text = $this->render_tool_result_text( $segment );
						if ( '' !== $result_text ) {
							$fragments[] = $result_text;
						}
						break;

					default:
						if ( isset( $segment['text'] ) && '' !== $segment['text'] ) {
							$fragments[] = trim( wp_kses_post( (string) $segment['text'] ) );
						}
						break;
				}
			}

			return $fragments;
		}

		/**
		 * Extract file parts from message content.
		 *
		 * Extracts file data (e.g., video files uploaded to Gemini File API)
		 * from message content segments and formats them for Gemini API.
		 *
		 * @param mixed $content Message content (string or array of segments).
		 * @return array Array of file parts suitable for Gemini API.
		 */
		protected function extract_file_parts( $content ) {
			if ( is_string( $content ) || is_numeric( $content ) ) {
				return array();
			}

			if ( ! is_array( $content ) ) {
				return array();
			}

			$file_parts = array();

			foreach ( $content as $segment ) {
				if ( ! is_array( $segment ) ) {
					continue;
				}

				$type = isset( $segment['type'] ) ? sanitize_key( $segment['type'] ) : 'text';

				// Handle file segments (video/audio uploaded via Gemini File API).
				if ( 'file' === $type || 'input_file' === $type ) {
					$file_part = $this->format_file_part( $segment );
					if ( null !== $file_part ) {
						$file_parts[] = $file_part;
					}
				}

				// Handle image segments – use inlineData (base64) or fileData (Gemini File API).
				if ( 'input_image' === $type || 'image_url' === $type || 'image_file' === $type ) {
					$image_part = $this->format_image_part( $segment );
					if ( null !== $image_part ) {
						$file_parts[] = $image_part;
					}
				}
			}

			return $file_parts;
		}

		/**
		 * Format a file segment as a Gemini fileData part.
		 *
		 * @param array $segment File segment with fileUri and mimeType.
		 * @return array|null Gemini fileData part or null if invalid.
		 */
		protected function format_file_part( $segment ) {
			// Extract file URI (could be 'file_uri', 'fileUri', or 'uri').
			$file_uri = '';
			if ( isset( $segment['file_uri'] ) && '' !== $segment['file_uri'] ) {
				$file_uri = esc_url_raw( $segment['file_uri'] );
			} elseif ( isset( $segment['fileUri'] ) && '' !== $segment['fileUri'] ) {
				$file_uri = esc_url_raw( $segment['fileUri'] );
			} elseif ( isset( $segment['uri'] ) && '' !== $segment['uri'] ) {
				$file_uri = esc_url_raw( $segment['uri'] );
			}

			if ( empty( $file_uri ) ) {
				return null;
			}

			// Extract MIME type (could be 'mime_type' or 'mimeType').
			$mime_type = '';
			if ( isset( $segment['mime_type'] ) && '' !== $segment['mime_type'] ) {
				$mime_type = sanitize_mime_type( $segment['mime_type'] );
			} elseif ( isset( $segment['mimeType'] ) && '' !== $segment['mimeType'] ) {
				$mime_type = sanitize_mime_type( $segment['mimeType'] );
			}

			if ( empty( $mime_type ) ) {
				return null;
			}

			// Build fileData part for Gemini API.
			return array(
				'fileData' => array(
					'fileUri'  => $file_uri,
					'mimeType' => $mime_type,
				),
			);
		}

		/**
		 * Format an image segment as a Gemini inlineData or fileData part.
		 *
		 * Priority order:
		 * 1. Gemini File API name (file_id starting with "files/") -- fileData
		 * 2. Explicit Gemini file URI (file_uri / uri) -- fileData
		 * 3. Local WordPress attachment file (via attachment_id) -- inlineData
		 * 4. Remote image URL (image_url.url / url) -- inlineData via HTTP download
		 *
		 * @param array $segment {
		 *     Image segment of type input_image / image_url / image_file.
		 *
		 *     @type string $file_id       Optional. Gemini File API name (e.g., "files/abc123") or OpenAI file ID.
		 *     @type string $file_uri      Optional. Full Gemini File API URI.
		 *     @type string $uri           Optional. Alias for file_uri.
		 *     @type int    $attachment_id Optional. WordPress attachment post ID for local file reads.
		 *     @type array  $image_url     Optional. Array with 'url' key for remote image download.
		 *     @type string $url           Optional. Direct image URL fallback.
		 *     @type string $mime_type     Optional. MIME type of the image (e.g., "image/jpeg").
		 *     @type string $mimeType      Optional. Camel-case alias for mime_type.
		 * }
		 * @return array|null Gemini inlineData or fileData part, or null if unable to build one.
		 */
		protected function format_image_part( array $segment ) {
			$mime_type = '';
			if ( isset( $segment['mime_type'] ) && '' !== $segment['mime_type'] ) {
				$mime_type = sanitize_mime_type( $segment['mime_type'] );
			} elseif ( isset( $segment['mimeType'] ) && '' !== $segment['mimeType'] ) {
				$mime_type = sanitize_mime_type( $segment['mimeType'] );
			}

			// 1. Check for a Gemini File API name (e.g., "files/abc123").
			if ( ! empty( $segment['file_id'] ) ) {
				$file_id = sanitize_text_field( wp_unslash( $segment['file_id'] ) );

				if ( 0 === strpos( $file_id, 'files/' ) ) {
					// Construct the full Gemini File API URI from the name.
					$file_uri = 'https://generativelanguage.googleapis.com/v1beta/' . rawurlencode( $file_id );

					if ( empty( $mime_type ) ) {
						// Without a MIME type Gemini rejects the request.
						return null;
					}

					return array(
						'fileData' => array(
							'fileUri'  => $file_uri,
							'mimeType' => $mime_type,
						),
					);
				}
			}

			// 2. Explicit Gemini file URI already stored in the segment.
			$file_uri = '';
			if ( ! empty( $segment['file_uri'] ) ) {
				$file_uri = esc_url_raw( $segment['file_uri'] );
			} elseif ( ! empty( $segment['uri'] ) ) {
				$file_uri = esc_url_raw( $segment['uri'] );
			}

			if ( '' !== $file_uri && false !== strpos( $file_uri, 'generativelanguage.googleapis.com' ) ) {
				if ( ! empty( $mime_type ) ) {
					return array(
						'fileData' => array(
							'fileUri'  => $file_uri,
							'mimeType' => $mime_type,
						),
					);
				}
			}

			// 3. Read binary data from the local WordPress attachment (fastest path).
			if ( ! empty( $segment['attachment_id'] ) ) {
				$attachment_id = absint( $segment['attachment_id'] );
				$file_path     = get_attached_file( $attachment_id );

				if ( $file_path && file_exists( $file_path ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading local file; not a remote URL.
					$data = file_get_contents( $file_path );

					if ( false !== $data && '' !== $data ) {
						if ( empty( $mime_type ) ) {
							$mime_type = get_post_mime_type( $attachment_id );
						}
						$mime_type = $mime_type ? sanitize_mime_type( $mime_type ) : '';

						if ( '' !== $mime_type ) {
							return array(
								'inlineData' => array(
									// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Encoding binary image for Gemini inlineData.
									'data'     => base64_encode( $data ),
									'mimeType' => $mime_type,
								),
							);
						}
					}
				}
			}

			// 4. Download from URL as a last resort.
			$url = '';
			if ( ! empty( $segment['image_url'] ) && is_array( $segment['image_url'] ) && ! empty( $segment['image_url']['url'] ) ) {
				$url = esc_url_raw( $segment['image_url']['url'] );
			} elseif ( ! empty( $segment['url'] ) ) {
				$url = esc_url_raw( $segment['url'] );
			}

			if ( '' !== $url ) {
				$download = $this->download_image_from_url( $url, array() );

				if ( ! is_wp_error( $download ) && ! empty( $download['body'] ) ) {
					if ( empty( $mime_type ) && ! empty( $download['content_type'] ) ) {
						$ct_parts  = explode( ';', $download['content_type'] );
						$raw_ct    = strtolower( trim( $ct_parts[0] ) );
						$mime_type = sanitize_mime_type( $raw_ct );
					}

					if ( '' !== $mime_type ) {
						return array(
							'inlineData' => array(
								// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Encoding downloaded image for Gemini inlineData.
								'data'     => base64_encode( $download['body'] ),
								'mimeType' => $mime_type,
							),
						);
					}
				}
			}

			return null;
		}

		/**
		 * Convert tool result segment into plain text.
		 *
		 * @param array $segment Tool result segment.
		 * @return string
		 */
		protected function render_tool_result_text( array $segment ) {
			if ( isset( $segment['output'] ) ) {
				if ( is_string( $segment['output'] ) ) {
					return $segment['output'];
				} elseif ( is_array( $segment['output'] ) ) {
					$parts = $this->normalize_segments_to_text( $segment['output'] );
					if ( ! empty( $parts ) ) {
						return implode( "\n\n", $parts );
					}
				} elseif ( is_object( $segment['output'] ) ) {
					return wp_json_encode( $segment['output'] );
				}
			}

			if ( isset( $segment['content'] ) ) {
				$parts = $this->normalize_segments_to_text( $segment['content'] );
				if ( ! empty( $parts ) ) {
					return implode( "\n\n", $parts );
				}
			}

			return '';
		}

		/**
		 * Convert an OpenAI-style tool call into a Gemini functionCall part.
		 *
		 * @param array $tool_call Tool call payload.
		 * @return array|null
		 */
		protected function convert_tool_call_to_function_call( array $tool_call ) {
			if ( empty( $tool_call ) || ! is_array( $tool_call ) ) {
				return null;
			}

			$type = isset( $tool_call['type'] ) ? sanitize_key( $tool_call['type'] ) : 'function';

			if ( 'function' !== $type ) {
				return null;
			}

			$function = array();
			if ( isset( $tool_call['function'] ) && is_array( $tool_call['function'] ) ) {
				$function = $tool_call['function'];
			}

			$name = isset( $function['name'] ) ? sanitize_text_field( $function['name'] ) : '';

			if ( '' === $name ) {
				return null;
			}

			$args = array();

			if ( isset( $function['arguments'] ) ) {
				$args = $this->normalise_tool_arguments( $function['arguments'] );
			} elseif ( isset( $tool_call['arguments'] ) ) {
				$args = $this->normalise_tool_arguments( $tool_call['arguments'] );
			}

			return array(
				'name' => $name,
				'args' => $args,
			);
		}

		/**
		 * Normalise tool arguments into an array suitable for Gemini.
		 *
		 * @param mixed $arguments Raw arguments payload.
		 * @return array
		 */
		protected function normalise_tool_arguments( $arguments ) {
			if ( is_array( $arguments ) ) {
				return $arguments;
			}

			if ( is_object( $arguments ) ) {
				return (array) $arguments;
			}

			if ( is_string( $arguments ) || is_numeric( $arguments ) ) {
				$decoded = json_decode( (string) $arguments, true );

				if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
					return $decoded;
				}

				$text = sanitize_textarea_field( (string) $arguments );

				if ( '' !== $text ) {
					return array( 'raw' => $text );
				}
			}

			return array();
		}

		/**
		 * Convert a tool result message into a Gemini functionResponse part.
		 *
		 * @param array $message Tool message payload.
		 * @return array|null
		 */
		protected function convert_tool_message_to_function_response( array $message ) {
			$name = isset( $message['name'] ) ? sanitize_text_field( $message['name'] ) : '';

			if ( '' === $name ) {
				return null;
			}

			$response = array();

			if ( isset( $message['content'] ) ) {
				$response = $this->normalise_tool_response_content( $message['content'] );
			}

			if ( empty( $response ) && isset( $message['output'] ) ) {
				$response = $this->normalise_tool_response_content( $message['output'] );
			}

			if ( ! is_array( $response ) ) {
				$response = array();
			}

			if ( isset( $message['tool_call_id'] ) ) {
				$response['tool_call_id'] = sanitize_text_field( $message['tool_call_id'] );
			}

			return array(
				'name'     => $name,
				'response' => $response,
			);
		}

		/**
		 * Normalise tool response content into an array representation.
		 *
		 * @param mixed $content Tool content payload.
		 * @return array
		 */
		protected function normalise_tool_response_content( $content ) {
			if ( is_array( $content ) ) {
				if ( wp_is_numeric_array( $content ) ) {
					$text = implode( "\n\n", $this->normalize_segments_to_text( $content ) );

					return $this->decode_tool_text_to_response( $text );
				}

				return $content;
			}

			if ( is_object( $content ) ) {
				return (array) $content;
			}

			if ( is_string( $content ) || is_numeric( $content ) ) {
				return $this->decode_tool_text_to_response( (string) $content );
			}

			return array();
		}

		/**
		 * Attempt to decode tool text content into a structured response array.
		 *
		 * @param string $text Tool output as text.
		 * @return array
		 */
		protected function decode_tool_text_to_response( $text ) {
			$text = trim( (string) $text );

			if ( '' === $text ) {
				return array();
			}

			$decoded = json_decode( $text, true );

			if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
				return $decoded;
			}

			return array( 'output' => sanitize_textarea_field( $text ) );
		}

		/**
		 * Translate OpenAI-style tool definitions into Gemini declarations.
		 *
		 * @param array $tools Tool definitions.
		 * @return array
		 */
		protected function translate_tools( array $tools ) {
			$declarations = array();

			foreach ( $tools as $tool ) {
				if ( ! is_array( $tool ) ) {
					continue;
				}

				$type = isset( $tool['type'] ) ? sanitize_key( $tool['type'] ) : '';
				if ( 'function' !== $type ) {
					continue;
				}

				if ( empty( $tool['function'] ) || ! is_array( $tool['function'] ) ) {
					continue;
				}

				$function = $tool['function'];
				$name     = isset( $function['name'] ) ? sanitize_text_field( $function['name'] ) : '';

				if ( '' === $name ) {
					continue;
				}

				$declaration = array( 'name' => $name );

				if ( ! empty( $function['description'] ) ) {
					$declaration['description'] = sanitize_text_field( $function['description'] );
				}

				if ( isset( $function['parameters'] ) && is_array( $function['parameters'] ) ) {
					// Sanitize parameters to remove fields not supported by Gemini API.
					$declaration['parameters'] = $this->sanitize_parameters_for_gemini( $function['parameters'] );
				}

				$declarations[] = $declaration;
			}

			if ( empty( $declarations ) ) {
				return array();
			}

			return array(
				array(
					'functionDeclarations' => $declarations,
				),
			);
		}

		/**
		 * Normalize malformed property values in a properties object.
		 *
		 * Ensures that all values in a 'properties' object are proper Schema objects
		 * (arrays with at least a 'type' field), not scalar values. This prevents
		 * Gemini API errors like: "Invalid value... expecting Schema object but got string".
		 *
		 * @since 1.0.0
		 * @param array $properties The properties object to normalize.
		 * @return array Normalized properties object.
		 */
		protected function normalize_property_schemas( array $properties ) {
			$normalized = array();

			foreach ( $properties as $prop_name => $prop_value ) {
				// If a property value is a scalar (string/number/bool) instead of a schema object,.

				// convert it to a proper schema object with that value as the type.
				if ( ! is_array( $prop_value ) && ! is_object( $prop_value ) ) {
					// Assume the scalar value is meant to be the type.
					$normalized[ $prop_name ] = array(
						'type' => is_string( $prop_value ) ? $prop_value : 'string',
					);

					WP_MCP_AI_Logger::log_event(
						'gemini_schema_fix',
						'Converted scalar property value to schema object',
						array(
							'property'       => $prop_name,
							'original_value' => $prop_value,
							'converted_to'   => $normalized[ $prop_name ],
						)
					);
				} else {
					$normalized[ $prop_name ] = $prop_value;
				}
			}

			return $normalized;
		}

		/**
		 * Sanitize JSON Schema parameters for Gemini API compatibility.
		 *
		 * Gemini API uses a restricted subset of OpenAPI 3.0 Schema Object and does NOT support:
		 * - additionalProperties: Not supported at any level
		 * - type as array: Union types like ['string', 'array'] must be converted to single type
		 * - default: Default values for parameters
		 * - examples: Example values array
		 * - const: Constant value constraints
		 * - nullable: Nullable type indicator (use type array instead, which we convert)
		 * - $ref, $schema, $id: JSON Schema meta-keywords
		 * - oneOf, anyOf, allOf: Schema composition keywords (we extract the first option)
		 * - format: Format validators (limited/no support in function declarations)
		 *
		 * This method recursively strips these unsupported schema keywords while preserving
		 * property names that may match keyword names (e.g., a parameter named 'format').
		 *
		 * For schema composition keywords (oneOf, anyOf, allOf), we extract the first schema
		 * option and merge it into the parent schema to preserve type information.
		 *
		 * @param array  $schema     JSON Schema object to sanitize.
		 * @param string $parent_key The parent key to determine context (internal use).
		 * @return array Sanitized schema compatible with Gemini API.
		 */
		protected function sanitize_parameters_for_gemini( array $schema, $parent_key = '' ) {
			$sanitized = array();

			// List of unsupported keywords to filter out.
			$unsupported_keywords = array(
				'additionalProperties',
				'default',
				'examples',
				'const',
				'nullable',
				'$ref',
				'$schema',
				'$id',
				'format',
			);

			// Handle oneOf, anyOf, allOf - schema composition keywords.
			// Extract the first schema option and merge it into the current schema.
			$composition_keywords = array( 'oneOf', 'anyOf', 'allOf' );
			foreach ( $composition_keywords as $comp_key ) {
				if ( isset( $schema[ $comp_key ] ) && is_array( $schema[ $comp_key ] ) && ! empty( $schema[ $comp_key ] ) ) {
					// Get the first schema from the composition array.
					$first_option = $schema[ $comp_key ][0];
					if ( is_array( $first_option ) ) {
						// Merge the first option into the current schema.
						// This allows properties from the first option to be used.
						foreach ( $first_option as $opt_key => $opt_value ) {
							// Don't override existing keys in the schema.
							if ( ! isset( $schema[ $opt_key ] ) ) {
								$schema[ $opt_key ] = $opt_value;
							}
						}

						// Log the composition keyword handling for debugging.
						WP_MCP_AI_Logger::log_event(
							'gemini_schema_composition',
							"Converted {$comp_key} to first option in schema",
							array(
								'composition_keyword' => $comp_key,
								'parent_key'          => $parent_key,
								'first_option_type'   => isset( $first_option['type'] ) ? $first_option['type'] : 'unknown',
								'options_count'       => count( $schema[ $comp_key ] ),
							)
						);
					}
					// Remove the composition keyword after extracting its first option.
					unset( $schema[ $comp_key ] );
				}
			}

			foreach ( $schema as $key => $value ) {
				// IMPORTANT: Only filter schema keywords, not property names.
				// When parent_key is 'properties', the keys are parameter names, not schema keywords.
				// Example: A parameter named 'format' should be preserved, but a 'format' keyword should be removed.
				if ( 'properties' !== $parent_key && in_array( $key, $unsupported_keywords, true ) ) {
					continue;
				}

				// Handle 'type' field - convert arrays to single type.
				if ( 'type' === $key && is_array( $value ) ) {
					// For union types, use the first type (most specific).
					// E.g., ['string', 'array'] becomes 'string'.
					$sanitized[ $key ] = is_string( $value[0] ) ? $value[0] : 'string';
					continue;
				}

				// Handle 'enum' field - Gemini API requires all enum values to be strings (TYPE_STRING).
				// Cast any non-string scalar values (e.g. integers like 0, 90, 180, 270) to strings.
				if ( 'enum' === $key && is_array( $value ) ) {
					$sanitized[ $key ] = array_map( 'strval', $value );
					continue;
				}

				// Handle 'required' field - preserve as-is (array of property names).
				if ( 'required' === $key && is_array( $value ) ) {
					$sanitized[ $key ] = $value;
					continue;
				}

				// Recursively sanitize nested objects and arrays.
				// Pass the current key as parent_key to track context.
				if ( is_array( $value ) ) {
					$sanitized[ $key ] = $this->sanitize_parameters_for_gemini( $value, $key );
				} else {
					$sanitized[ $key ] = $value;
				}
			}

			// Critical fix: Normalize property values to ensure they are schema objects, not scalars.
			// This prevents Gemini API errors where scalars are sent instead of Schema objects.
			if ( isset( $sanitized['properties'] ) && is_array( $sanitized['properties'] ) ) {
				$sanitized['properties'] = $this->normalize_property_schemas( $sanitized['properties'] );
			}

			// Enhancement: Ensure property schemas have a 'type' field.
			// If we're processing a property definition (parent_key is a property name from 'properties'),.

			// or an items definition (parent_key is 'items'), and it lacks a 'type' field,.

			// infer an appropriate type based on schema structure.
			if ( 'properties' === $parent_key ) {
				foreach ( $sanitized as $prop_name => $prop_schema ) {
					if ( is_array( $prop_schema ) && ! isset( $prop_schema['type'] ) ) {
						// Determine the appropriate type based on schema structure.
						$inferred_type = 'string'; // Default fallback.
						$reason        = 'default';

						if ( isset( $prop_schema['items'] ) ) {
							// If 'items' is present, this should be an array type.
							$inferred_type = 'array';
							$reason        = 'has_items';
						} elseif ( isset( $prop_schema['properties'] ) ) {
							// If 'properties' is present, this should be an object type.
							$inferred_type = 'object';
							$reason        = 'has_properties';
						}

						$sanitized[ $prop_name ]['type'] = $inferred_type;

						WP_MCP_AI_Logger::log_event(
							'gemini_schema_enhancement',
							'Added missing type field to property schema',
							array(
								'property'      => $prop_name,
								'inferred_type' => $inferred_type,
								'reason'        => $reason,
							)
						);
					}
				}
			} elseif ( 'items' === $parent_key && is_array( $sanitized ) && ! isset( $sanitized['type'] ) ) {
				// Handle the items schema itself when it's missing a type.
				$inferred_type = 'string'; // Default fallback.
				$reason        = 'default';

				if ( isset( $sanitized['items'] ) ) {
					// If 'items' is present, this should be an array type.
					$inferred_type = 'array';
					$reason        = 'has_items';
				} elseif ( isset( $sanitized['properties'] ) ) {
					// If 'properties' is present, this should be an object type.
					$inferred_type = 'object';
					$reason        = 'has_properties';
				}

				$sanitized['type'] = $inferred_type;

				WP_MCP_AI_Logger::log_event(
					'gemini_schema_enhancement',
					'Added missing type field to items schema',
					array(
						'inferred_type' => $inferred_type,
						'reason'        => $reason,
					)
				);
			}

			// Gemini API requires enum values to be TYPE_STRING. When a schema property
			// declares a numeric type (integer/number) together with an enum, the type must
			// be changed to 'string' so it matches the now-stringified enum values.
			if ( isset( $sanitized['enum'] ) && isset( $sanitized['type'] ) && in_array( $sanitized['type'], array( 'integer', 'number' ), true ) ) {
				$sanitized['type'] = 'string';
			}

			return $sanitized;
		}

		/**
		 * Build memory document fragments used in the system instruction.
		 *
		 * @param array $documents Memory documents.
		 * @return array
		 */
		protected function build_memory_fragments( array $documents ) {
			$fragments = array();

			foreach ( $documents as $document ) {
				if ( empty( $document['chunks'] ) || ! is_array( $document['chunks'] ) ) {
					continue;
				}

				$title = isset( $document['title'] ) && '' !== $document['title'] ? sanitize_text_field( $document['title'] ) : __( 'Document', 'nvdigital-open-operator-system-oos' );

				$chunks = array_values( array_filter( array_map( 'strval', $document['chunks'] ) ) );

				$parts      = count( $chunks );
				$part_index = 0;

				foreach ( $chunks as $chunk ) {
					++$part_index;

					$label = $title;
					if ( $parts > 1 ) {
						/* translators: %1$s: document title, %2$d: chunk number. */
						$label = sprintf( __( '%1$s (Part %2$d)', 'nvdigital-open-operator-system-oos' ), $title, $part_index );
					}

					/* translators: %1$s: document title, %2$s: extracted text snippet. */
					$fragments[] = sprintf( __( 'Reference document "%1$s": %2$s', 'nvdigital-open-operator-system-oos' ), $label, $chunk );
				}
			}

			return $fragments;
		}

		/**
		 * Extract the first inline or downloadable image from the Gemini response payload.
		 *
		 * @param array $response Decoded API response.
		 * @param array $options  Original request options.
		 * @return array|WP_Error
		 */
		protected function extract_image_payload_from_response( array $response, array $options ) {
			if ( empty( $response['candidates'] ) || ! is_array( $response['candidates'] ) ) {
				WP_MCP_AI_Logger::log_error( 'Gemini image response missing candidates.', array( 'response' => $response ) );

				return new WP_Error( 'wp_mcp_ai_image_empty', __( 'Gemini returned an empty image response.', 'nvdigital-open-operator-system-oos' ) );
			}

			foreach ( $response['candidates'] as $candidate ) {
				$revised_prompt = $this->extract_revised_prompt_from_candidate( $candidate, $response );

				if ( empty( $candidate['content']['parts'] ) || ! is_array( $candidate['content']['parts'] ) ) {
					continue;
				}

				foreach ( $candidate['content']['parts'] as $part ) {
					if ( isset( $part['inlineData'] ) && is_array( $part['inlineData'] ) ) {
						$inline    = $part['inlineData'];
						$data      = isset( $inline['data'] ) ? $inline['data'] : '';
						$mime_type = isset( $inline['mimeType'] ) ? $this->normalise_image_mime_type( $inline['mimeType'] ) : '';

						if ( '' === $data ) {
							continue;
						}

						$decoded_data = $this->decode_inline_image_data( $data );

						if ( is_wp_error( $decoded_data ) ) {
							return $decoded_data;
						}

						if ( '' === $mime_type ) {
							$mime_type = 'image/png';
						}

						return array(
							'data'           => $decoded_data,
							'mime_type'      => $mime_type,
							'format'         => $this->map_mime_type_to_format( $mime_type ),
							'revised_prompt' => $revised_prompt,
						);
					}

					if ( isset( $part['fileData'] ) && is_array( $part['fileData'] ) ) {
						$file_data = $part['fileData'];
						$file_uri  = isset( $file_data['fileUri'] ) ? esc_url_raw( $file_data['fileUri'] ) : '';

						if ( '' === $file_uri ) {
							continue;
						}

						$download = $this->download_image_from_url( $file_uri, $options );

						if ( is_wp_error( $download ) ) {
							return $download;
						}

						$mime_type = isset( $file_data['mimeType'] ) ? $this->normalise_image_mime_type( $file_data['mimeType'] ) : '';

						if ( '' === $mime_type && ! empty( $download['content_type'] ) ) {
							$mime_type = $this->normalise_image_mime_type( $download['content_type'] );
						}

						if ( '' === $mime_type ) {
							$mime_type = 'image/png';
						}

						return array(
							'data'           => $download['body'],
							'mime_type'      => $mime_type,
							'format'         => $this->map_mime_type_to_format( $mime_type ),
							'revised_prompt' => $revised_prompt,
						);
					}
				}
			}

			WP_MCP_AI_Logger::log_error( 'Gemini image response missing supported payload keys.', array( 'response' => $response ) );

			return new WP_Error( 'wp_mcp_ai_image_empty', __( 'Gemini returned an empty image response.', 'nvdigital-open-operator-system-oos' ) );
		}

		/**
		 * Extract any revised prompt text that Gemini returned alongside an image payload.
		 *
		 * @param array $candidate Individual candidate payload from Gemini.
		 * @param array $response  Full decoded Gemini response payload.
		 * @return string
		 */
		protected function extract_revised_prompt_from_candidate( array $candidate, array $response ) {
			$fragments = array();

			if ( isset( $candidate['content']['parts'] ) && is_array( $candidate['content']['parts'] ) ) {
				foreach ( $candidate['content']['parts'] as $part ) {
					if ( isset( $part['text'] ) && is_string( $part['text'] ) ) {
						$text = sanitize_textarea_field( $part['text'] );

						if ( '' !== $text ) {
							$fragments[] = $text;
						}
					}
				}
			}

			if ( empty( $fragments ) && isset( $response['promptFeedback'] ) && is_array( $response['promptFeedback'] ) ) {
				if ( isset( $response['promptFeedback']['blockReasonMessage'] ) ) {
					$text = sanitize_textarea_field( $response['promptFeedback']['blockReasonMessage'] );

					if ( '' !== $text ) {
						$fragments[] = $text;
					}
				}

				if ( isset( $response['promptFeedback']['safetyFeedback'] ) && is_array( $response['promptFeedback']['safetyFeedback'] ) ) {
					foreach ( $response['promptFeedback']['safetyFeedback'] as $feedback ) {
						if ( isset( $feedback['description'] ) ) {
							$text = sanitize_textarea_field( $feedback['description'] );

							if ( '' !== $text ) {
								$fragments[] = $text;
							}
						}
					}
				}
			}

			$fragments = array_values( array_unique( array_filter( $fragments, 'strlen' ) ) );

			if ( empty( $fragments ) ) {
				return '';
			}

			return implode( "\n\n", $fragments );
		}

		/**
		 * Normalise supported image MIME types returned by Gemini.
		 *
		 * @param string $mime_type Raw MIME type value.
		 * @return string
		 */
		protected function normalise_image_mime_type( $mime_type ) {
			$mime_type = sanitize_mime_type( (string) $mime_type );

			$allowed = array( 'image/png', 'image/jpeg', 'image/jpg', 'image/webp' );

			if ( in_array( $mime_type, $allowed, true ) ) {
				if ( 'image/jpg' === $mime_type ) {
					return 'image/jpeg';
				}

				return $mime_type;
			}

			return '';
		}

		/**
		 * Normalise an aspect ratio string.
		 *
		 * @param string $aspect_ratio Raw aspect ratio input.
		 * @return string
		 */
		protected function normalise_aspect_ratio( $aspect_ratio ) {
			$aspect_ratio = strtolower( (string) $aspect_ratio );
			$aspect_ratio = str_replace( ' ', '', $aspect_ratio );

			// Special case: "auto" means let the AI decide (no aspectRatio sent to API).
			if ( 'auto' === $aspect_ratio ) {
				return 'auto';
			}

			$aspect_ratio = strtoupper( $aspect_ratio );

			if ( preg_match( '/^(\d+):(\d+)$/', $aspect_ratio, $matches ) ) {
				$left  = ltrim( $matches[1], '0' );
				$right = ltrim( $matches[2], '0' );

				if ( '' === $left ) {
					$left = '0';
				}

				if ( '' === $right ) {
					$right = '0';
				}

				return $left . ':' . $right;
			}

			$allowed = array( '1:1', '2:3', '3:2', '3:4', '4:3', '9:16', '16:9', '21:9' );

			if ( in_array( $aspect_ratio, $allowed, true ) ) {
				return $aspect_ratio;
			}

			return '';
		}

		/**
		 * Map a MIME type to a common file extension identifier.
		 *
		 * @param string $mime_type MIME type string.
		 * @return string
		 */
		protected function map_mime_type_to_format( $mime_type ) {
			switch ( $mime_type ) {
				case 'image/jpeg':
					return 'jpeg';
				case 'image/webp':
					return 'webp';
				case 'image/png':
				default:
					return 'png';
			}
		}

		/**
		 * Download an image from a remote Gemini file URI.
		 *
		 * @param string $url     Remote file URL.
		 * @param array  $options Request options including timeout.
		 * @return array|WP_Error Array containing body and content_type.
		 */
		protected function download_image_from_url( $url, array $options ) {
			$timeout = $this->resolve_timeout( $options );

			$request_args = array(
				'timeout' => $timeout,
			);

			$response = wp_remote_get( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error(
					'Failed to download image from Gemini file URI.',
					array(
						'url'   => $url,
						'error' => $response->get_error_message(),
					)
				);

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'The Gemini image download request failed to complete.', 'nvdigital-open-operator-system-oos' ),
					__( 'Gemini', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code = wp_remote_retrieve_response_code( $response );

			if ( $code < 200 || $code >= 300 ) {
				WP_MCP_AI_Logger::log_error(
					'Gemini returned a non-200 status while downloading image.',
					array(
						'url'  => $url,
						'code' => $code,
					)
				);

				return new WP_Error( 'wp_mcp_ai_http_error', __( 'Gemini returned an unexpected status while downloading the image.', 'nvdigital-open-operator-system-oos' ), array( 'status' => $code ) );
			}

			$body = wp_remote_retrieve_body( $response );

			if ( '' === $body ) {
				WP_MCP_AI_Logger::log_error( 'Gemini image download returned an empty body.', array( 'url' => $url ) );

				return new WP_Error( 'wp_mcp_ai_image_empty', __( 'Gemini returned an empty image response.', 'nvdigital-open-operator-system-oos' ) );
			}

			return array(
				'body'         => $body,
				'content_type' => wp_remote_retrieve_header( $response, 'content-type' ),
			);
		}

		/**
		 * Decode an inline base64 image payload returned by Gemini.
		 *
		 * @param string $data Raw base64 or base64url encoded string.
		 * @return string|WP_Error
		 */
		protected function decode_inline_image_data( $data ) {
			$data    = (string) $data;
			$decoded = base64_decode( $data, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decoding binary image data from API response.

			if ( false !== $decoded ) {
				return $decoded;
			}

			$normalised = $this->normalise_base64_string( $data );

			if ( '' !== $normalised ) {
				$decoded = base64_decode( $normalised, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decoding binary image data from API response.

				if ( false !== $decoded ) {
					return $decoded;
				}
			}

			$decoded = base64_decode( $data ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decoding binary image data from API response.

			if ( false !== $decoded ) {
				return $decoded;
			}

			WP_MCP_AI_Logger::log_error(
				'Gemini inline image data could not be decoded.',
				array(
					'length' => strlen( $data ),
				)
			);

			return new WP_Error(
				'wp_mcp_ai_image_decode_error',
				__( 'Gemini returned an invalid inline image payload.', 'nvdigital-open-operator-system-oos' ),
				array( 'status' => 500 )
			);
		}

		/**
		 * Normalise a base64 or base64url string for decoding.
		 *
		 * @param string $data Raw base64 input.
		 * @return string
		 */
		protected function normalise_base64_string( $data ) {
			$data = (string) $data;
			$data = str_replace( array( "\r", "\n" ), '', $data );
			$data = strtr( $data, '-_', '+/' );

			$remainder = strlen( $data ) % 4;

			if ( 0 !== $remainder ) {
				$data .= str_repeat( '=', 4 - $remainder );
			}

			return $data;
		}

		/**
		 * Resolve the timeout for the request.
		 *
		 * @param array $options Request options.
		 * @return int
		 */
		protected function resolve_timeout( array $options ) {
			$settings     = WP_MCP_AI_Admin_Settings::get_settings();
			$resource_mgr = WP_MCP_AI_Resource_Manager::instance();

			$timeout = isset( $settings['request_timeout'] ) ? absint( $settings['request_timeout'] ) : $resource_mgr->get_request_timeout();

			if ( isset( $options['timeout'] ) && $options['timeout'] ) {
				$timeout = max( 5, absint( $options['timeout'] ) );
			}

			return max( 5, $timeout );
		}

		/**
		 * Convert a Gemini response to an OpenAI-style structure for downstream compatibility.
		 *
		 * @param array $response Decoded Gemini response.
		 * @return array
		 */
		protected function normalize_response( array $response ) {
			$choices = array();

			if ( isset( $response['candidates'] ) && is_array( $response['candidates'] ) ) {
				foreach ( $response['candidates'] as $index => $candidate ) {
					$message    = array( 'role' => 'assistant' );
					$segments   = array();
					$tool_calls = array();
					$thinking   = '';

					if ( isset( $candidate['content']['parts'] ) && is_array( $candidate['content']['parts'] ) ) {
						foreach ( $candidate['content']['parts'] as $part ) {
							if ( isset( $part['text'] ) ) {
								$segments[] = array(
									'type' => 'text',
									'text' => (string) $part['text'],
								);
								continue;
							}

							if ( isset( $part['thought'] ) ) {
								// Gemini 2.0 Flash Thinking mode provides thinking text.

								$thinking .= (string) $part['thought'];
								continue;
							}

							if ( isset( $part['functionCall'] ) && is_array( $part['functionCall'] ) ) {
								$tool_call = $this->convert_function_call_to_tool_call( $part['functionCall'], $index );
								if ( $tool_call ) {
									$tool_calls[] = $tool_call;
								}
							}

							if ( isset( $part['functionResponse'] ) && is_array( $part['functionResponse'] ) ) {
								// Preserve function response as structured data so the
								// frontend can render it with proper tool-call linkage.
								// This mirrors the OpenAI-compatible tool_result format
								// that the chat UI expects for agentic loop messages.
								$function_name   = isset( $part['functionResponse']['name'] )
									? sanitize_text_field( $part['functionResponse']['name'] )
									: '';
								$function_result = isset( $part['functionResponse']['response'] )
									? $part['functionResponse']['response']
									: array();

								$segments[] = array(
									'type'        => 'tool_result',
									'tool_name'   => $function_name,
									'tool_result' => $function_result,
									'text'        => $this->render_function_response_text( $part['functionResponse'] ),
								);
							}
						}
					}

					if ( ! empty( $segments ) ) {
						$message['content'] = $segments;
					}

					if ( ! empty( $tool_calls ) ) {
						$message['tool_calls'] = $tool_calls;
					}

					if ( ! empty( $thinking ) ) {
						$message['thinking'] = $thinking;
					}

					$choice = array(
						'index'   => $index,
						'message' => $message,
					);

					if ( isset( $candidate['finishReason'] ) ) {
						$choice['finish_reason'] = $candidate['finishReason'];
					}

					$choices[] = $choice;
				}
			}

			$normalized = array(
				'choices'  => $choices,
				'provider' => 'gemini',
			);

			if ( isset( $response['usageMetadata'] ) && is_array( $response['usageMetadata'] ) ) {
				$usage = array();

				if ( isset( $response['usageMetadata']['promptTokenCount'] ) ) {
					$usage['prompt_tokens'] = (int) $response['usageMetadata']['promptTokenCount'];
				}

				if ( isset( $response['usageMetadata']['candidatesTokenCount'] ) ) {
					$usage['completion_tokens'] = (int) $response['usageMetadata']['candidatesTokenCount'];
				}

				if ( isset( $response['usageMetadata']['totalTokenCount'] ) ) {
					$usage['total_tokens'] = (int) $response['usageMetadata']['totalTokenCount'];
				}

				// Extract cached tokens from Gemini's usageMetadata.
				if ( isset( $response['usageMetadata']['cachedContentTokenCount'] ) ) {
					$usage['cached_tokens'] = (int) $response['usageMetadata']['cachedContentTokenCount'];
				}

				if ( ! empty( $usage ) ) {
					$normalized['usage'] = $usage;
				}
			}

			return $normalized;
		}

		/**
		 * Convert a Gemini function call into an OpenAI-style tool call payload.
		 *
		 * @param array $function_call Gemini function call payload.
		 * @param int   $index         Candidate index.
		 * @return array|null
		 */
		protected function convert_function_call_to_tool_call( array $function_call, $index ) {
			$name = isset( $function_call['name'] ) ? sanitize_text_field( $function_call['name'] ) : '';

			if ( '' === $name ) {
				return null;
			}

			$args = '{}';
			if ( isset( $function_call['args'] ) && is_array( $function_call['args'] ) ) {
				$args = wp_json_encode( $function_call['args'] );
			}

			return array(
				'id'       => sprintf( 'gemini-function-%d-%s', $index, uniqid() ),
				'type'     => 'function',
				'function' => array(
					'name'      => $name,
					'arguments' => $args,
				),
			);
		}

		/**
		 * Render a Gemini function response into text.
		 *
		 * @param array $function_response Gemini function response payload.
		 * @return string
		 */
		protected function render_function_response_text( array $function_response ) {
			if ( isset( $function_response['name'] ) && isset( $function_response['response'] ) ) {
				$rendered = sprintf( '%s: %s', sanitize_text_field( $function_response['name'] ), wp_json_encode( $function_response['response'] ) );

				return $rendered;
			}

			if ( isset( $function_response['text'] ) ) {
				return (string) $function_response['text'];
			}

			return '';
		}

		/**
		 * Remove large payloads from the logged request.
		 *
		 * @param array $payload Request payload.
		 * @return array
		 */
		protected function obfuscate_request_for_log( array $payload ) {
			if ( isset( $payload['contents'] ) ) {
				$payload['contents'] = '[redacted]';
			}

			if ( isset( $payload['system_instruction'] ) ) {
				$payload['system_instruction'] = '[redacted]';
			}

			return $payload;
		}

		/**
		 * Transcribe audio using Google Speech-to-Text API.
		 *
		 * @param string $file_path Path to the audio file.
		 * @param array  $options   Additional options (language, encoding, etc.).
		 * @return array|WP_Error Transcription result or error.
		 */
		public function transcribe_audio( $file_path, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini/Google API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$file_path = (string) $file_path;

			if ( '' === $file_path || ! file_exists( $file_path ) ) {
				return new WP_Error(
					'wp_mcp_ai_transcription_missing_file',
					__( 'The audio file to transcribe could not be located.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 404 )
				);
			}

			// Read and base64 encode the file.
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading a local plugin or temp file; WP_Filesystem is not available in this REST/cron/tool execution context.
			$file_data = file_get_contents( $file_path );

			if ( false === $file_data ) {
				return new WP_Error(
					'wp_mcp_ai_file_read_error',
					__( 'Could not read the audio file.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 500 )
				);
			}

			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- base64_encode used to encode binary image data for API transmission, not for obfuscation.
			$audio_content = base64_encode( $file_data );

			// Get language code (default to auto-detect).
			$language_code = isset( $options['language'] ) && '' !== $options['language'] ? sanitize_text_field( $options['language'] ) : 'en-US';

			// Build request payload for Google Speech-to-Text API.
			$payload = array(
				'config' => array(
					'encoding'                   => 'LINEAR16', // Will be overridden by auto-detection.
					'languageCode'               => $language_code,
					'enableAutomaticPunctuation' => true,
				),
				'audio'  => array(
					'content' => $audio_content,
				),
			);

			$url = 'https://speech.googleapis.com/v1/speech:recognize?key=' . rawurlencode( $api_key );

			$timeout = isset( $options['timeout'] ) && '' !== $options['timeout'] ? absint( $options['timeout'] ) : 60;
			$timeout = max( 5, $timeout );

			$request_args = array(
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $timeout,
			);

			WP_MCP_AI_Logger::log_event(
				'google_transcribe_audio',
				'Sending audio transcription request to Google Speech-to-Text.',
				array(
					'language'  => $language_code,
					'file_size' => strlen( $file_data ),
					'timeout'   => $timeout,
				)
			);

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error(
					'Google Speech-to-Text transcription failed.',
					array( 'error' => $response->get_error_message() )
				);

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'Google Speech-to-Text transcription request failed.', 'nvdigital-open-operator-system-oos' ),
					__( 'Google Speech-to-Text', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code = wp_remote_retrieve_response_code( $response );
			$body = wp_remote_retrieve_body( $response );

			if ( $code < 200 || $code >= 300 ) {
				$error_message = __( 'Google Speech-to-Text transcription returned an error.', 'nvdigital-open-operator-system-oos' );
				$decoded_body  = json_decode( $body, true );

				if ( is_array( $decoded_body ) && isset( $decoded_body['error']['message'] ) ) {
					$error_message .= ' ' . sanitize_text_field( $decoded_body['error']['message'] );
				}

				WP_MCP_AI_Logger::log_error(
					'Google Speech-to-Text transcription error.',
					array(
						'status' => $code,
						'body'   => $body,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $body,
					)
				);
			}

			$decoded = json_decode( $body, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				return new WP_Error(
					'wp_mcp_ai_invalid_response',
					__( 'Invalid JSON response from Google Speech-to-Text.', 'nvdigital-open-operator-system-oos' ),
					array( 'body' => $body )
				);
			}

			// Google Speech-to-Text returns: {"results": [{"alternatives": [{"transcript": "text", "confidence": 0.95}]}]}.
			// Extract the transcript from the first result.
			$text = '';
			if ( isset( $decoded['results'] ) && is_array( $decoded['results'] ) ) {
				foreach ( $decoded['results'] as $result ) {
					if ( isset( $result['alternatives'][0]['transcript'] ) ) {
						$text .= $result['alternatives'][0]['transcript'] . ' ';
					}
				}
			}

			$text = trim( $text );

			WP_MCP_AI_Logger::log_event(
				'google_transcribe_audio_success',
				'Successfully transcribed audio with Google Speech-to-Text.',
				array(
					'language'     => $language_code,
					'text_length'  => strlen( $text ),
					'result_count' => isset( $decoded['results'] ) ? count( $decoded['results'] ) : 0,
				)
			);

			// Check if transcription is empty.
			if ( '' === $text ) {
				return new WP_Error(
					'wp_mcp_ai_empty_transcription',
					__( 'Google Speech-to-Text returned an empty transcription. The audio may not contain speech or may be in an unsupported format.', 'nvdigital-open-operator-system-oos' ),
					array( 'response' => $decoded )
				);
			}

			// Normalize to consistent format.
			return array(
				'text'     => $text,
				'model'    => 'google-speech-to-text',
				'format'   => 'json',
				'language' => $language_code,
				'raw'      => $decoded,
			);
		}

		/**
		 * Generate speech using Google Text-to-Speech API.
		 *
		 * @param string $text    Text to convert to speech.
		 * @param array  $options Additional options (voice, language, etc.).
		 * @return array|WP_Error Audio data or error.
		 */
		public function generate_speech( $text, array $options = array() ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini/Google API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$text = sanitize_textarea_field( $text );

			if ( '' === $text ) {
				return new WP_Error(
					'wp_mcp_ai_missing_speech_input',
					__( 'A text prompt must be supplied to generate speech.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			// Get voice and language settings.
			$language_code = isset( $options['language'] ) && '' !== $options['language'] ? sanitize_text_field( $options['language'] ) : 'en-US';
			$voice_name    = isset( $options['voice'] ) && '' !== $options['voice'] ? sanitize_text_field( $options['voice'] ) : 'en-US-Neural2-C';

			// Build request payload for Google Text-to-Speech API.
			$payload = array(
				'input'       => array(
					'text' => $text,
				),
				'voice'       => array(
					'languageCode' => $language_code,
					'name'         => $voice_name,
				),
				'audioConfig' => array(
					'audioEncoding' => 'MP3',
				),
			);

			// Add speaking rate if provided.
			if ( isset( $options['speed'] ) && '' !== $options['speed'] ) {
				$speed                                  = floatval( $options['speed'] );
				$speed                                  = max( 0.25, min( 4.0, $speed ) );
				$payload['audioConfig']['speakingRate'] = $speed;
			}

			$url = 'https://texttospeech.googleapis.com/v1/text:synthesize?key=' . rawurlencode( $api_key );

			$timeout = isset( $options['timeout'] ) && '' !== $options['timeout'] ? absint( $options['timeout'] ) : 60;
			$timeout = max( 5, $timeout );

			$request_args = array(
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
				'timeout' => $timeout,
			);

			WP_MCP_AI_Logger::log_event(
				'google_generate_speech',
				'Sending text-to-speech request to Google TTS.',
				array(
					'language'    => $language_code,
					'voice'       => $voice_name,
					'text_length' => strlen( $text ),
					'timeout'     => $timeout,
				)
			);

			$response = wp_remote_post( $url, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_error(
					'Google TTS request failed.',
					array( 'error' => $response->get_error_message() )
				);

				return WP_MCP_AI_HTTP::prepare_transport_error(
					$response,
					'wp_mcp_ai_http_error',
					__( 'Google Text-to-Speech request failed.', 'nvdigital-open-operator-system-oos' ),
					__( 'Google Text-to-Speech', 'nvdigital-open-operator-system-oos' )
				);
			}

			$code = wp_remote_retrieve_response_code( $response );
			$body = wp_remote_retrieve_body( $response );

			if ( $code < 200 || $code >= 300 ) {
				$error_message = __( 'Google Text-to-Speech returned an error.', 'nvdigital-open-operator-system-oos' );
				$decoded_body  = json_decode( $body, true );

				if ( is_array( $decoded_body ) && isset( $decoded_body['error']['message'] ) ) {
					$error_message .= ' ' . sanitize_text_field( $decoded_body['error']['message'] );
				}

				WP_MCP_AI_Logger::log_error(
					'Google TTS error.',
					array(
						'status' => $code,
						'body'   => $body,
					)
				);

				return new WP_Error(
					'wp_mcp_ai_api_error',
					$error_message,
					array(
						'status' => $code,
						'body'   => $body,
					)
				);
			}

			$decoded = json_decode( $body, true );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				return new WP_Error(
					'wp_mcp_ai_invalid_response',
					__( 'Invalid JSON response from Google TTS.', 'nvdigital-open-operator-system-oos' ),
					array( 'body' => $body )
				);
			}

			// Google TTS returns: {"audioContent": "base64-encoded-audio"}.
			if ( ! isset( $decoded['audioContent'] ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_audio',
					__( 'No audio content received from Google TTS.', 'nvdigital-open-operator-system-oos' ),
					array( 'response' => $decoded )
				);
			}

			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- base64_decode used to decode binary image/file data received from the API, not for code obfuscation.
			$audio_data = base64_decode( $decoded['audioContent'] ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decoding binary image data from API response.

			if ( false === $audio_data ) {
				return new WP_Error(
					'wp_mcp_ai_audio_decode_error',
					__( 'Could not decode audio content from Google TTS.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 500 )
				);
			}

			WP_MCP_AI_Logger::log_event(
				'google_generate_speech_success',
				'Successfully generated speech with Google TTS.',
				array(
					'language'   => $language_code,
					'voice'      => $voice_name,
					'audio_size' => strlen( $audio_data ),
				)
			);

			// Return audio data in format compatible with OpenAI response.
			return array(
				'audio_data' => $audio_data,
				'format'     => 'mp3',
				'raw'        => $decoded,
			);
		}

		/**
		 * Execute a chat completion with tools and recursive tool execution.
		 *
		 * This method provides automatic tool execution in a loop for Gemini.
		 * It will:
		 * 1. Send messages with tool definitions to Gemini
		 * 2. If tools are called, execute them and add results to conversation
		 * 3. Repeat until no more tools are needed or max recursion is reached
		 *
		 * @since 1.0.0
		 *
		 * @param array $messages Array of conversation messages.
		 * @param array $tools    Array of tool definitions with executable functions.
		 * @param array $options  Optional configuration:
		 *                        - strictValidation (bool): Validate arguments before execution. Default: true.
		 *                        - maxRecursiveToolRuns (int): Maximum recursion depth. Default: 5.
		 *                        - streamFinalResponse (bool): Enable streaming (not implemented for PHP). Default: false.
		 *                        - verbose (bool): Detailed logging. Default: false.
		 *                        - autoTrimTools (bool): Context-based tool selection. Default: false.
		 *                        - maxTools (int): Max tools when trimming. Default: 10.
		 *                        - model, temperature, timeout, etc.
		 * @return array|WP_Error Final response or error.
		 * @throws Exception If tool function is not callable.
		 */
		public function run_with_tools( array $messages, array $tools = array(), array $options = array() ) {
			// Configuration options with defaults.
			$strict_validation     = isset( $options['strictValidation'] ) ? (bool) $options['strictValidation'] : true;
			$max_recursive_runs    = isset( $options['maxRecursiveToolRuns'] ) ? absint( $options['maxRecursiveToolRuns'] ) : 5;
			$stream_final_response = isset( $options['streamFinalResponse'] ) ? (bool) $options['streamFinalResponse'] : false;
			$verbose               = isset( $options['verbose'] ) ? (bool) $options['verbose'] : false;
			$auto_trim_tools       = isset( $options['autoTrimTools'] ) ? (bool) $options['autoTrimTools'] : false;

			if ( $verbose ) {
				WP_MCP_AI_Logger::log_event(
					'gemini_run_with_tools_start',
					'Starting Gemini embedded function calling.',
					array(
						'message_count'      => count( $messages ),
						'tool_count'         => count( $tools ),
						'strict_validation'  => $strict_validation,
						'max_recursive_runs' => $max_recursive_runs,
						'auto_trim_tools'    => $auto_trim_tools,
					)
				);
			}

			// Validate tools array.
			if ( empty( $tools ) ) {
				return new WP_Error(
					'wp_mcp_ai_no_tools',
					__( 'At least one tool must be provided for embedded function calling.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			// Auto-trim tools if enabled.
			if ( $auto_trim_tools ) {
				$tools = $this->auto_trim_tools( $messages, $tools, $options );
				if ( $verbose ) {
					WP_MCP_AI_Logger::log_event(
						'gemini_auto_trim_tools',
						'Automatically trimmed tools based on context.',
						array( 'remaining_tool_count' => count( $tools ) )
					);
				}
			}

			// Convert tools to Gemini format and create tool lookup.
			$tool_definitions = array();
			$tool_functions   = array();

			foreach ( $tools as $tool ) {
				if ( ! isset( $tool['name'] ) || ! isset( $tool['function'] ) ) {
					continue;
				}

				$tool_name = sanitize_text_field( $tool['name'] );

				// Build tool definition for API.
				$definition = array(
					'name'        => $tool_name,
					'description' => isset( $tool['description'] ) ? sanitize_text_field( $tool['description'] ) : '',
				);

				if ( isset( $tool['parameters'] ) && is_array( $tool['parameters'] ) ) {
					$definition['parameters'] = $tool['parameters'];
				}

				$tool_definitions[] = array(
					'type'     => 'function',
					'function' => $definition,
				);

				// Store executable function.
				$tool_functions[ $tool_name ] = $tool['function'];
			}

			// Prepare options with tools.
			$request_options          = $options;
			$request_options['tools'] = $tool_definitions;

			// Execute recursive tool calling loop.
			$conversation_messages = $messages;
			$recursion_count       = 0;

			while ( $recursion_count < $max_recursive_runs ) {
				++$recursion_count;

				if ( $verbose ) {
					WP_MCP_AI_Logger::log_event(
						'gemini_tool_run_iteration',
						sprintf( 'Tool execution iteration %d/%d', $recursion_count, $max_recursive_runs ),
						array( 'message_count' => count( $conversation_messages ) )
					);
				}

				// Make API request.
				$response = $this->create_chat_completion( $conversation_messages, $request_options );

				if ( is_wp_error( $response ) ) {
					return $response;
				}

				// Check if model wants to call any tools.
				$tool_calls = array();
				if ( isset( $response['choices'][0]['message']['tool_calls'] ) ) {
					$tool_calls = $response['choices'][0]['message']['tool_calls'];
				}

				// If no tool calls, we're done.
				if ( empty( $tool_calls ) ) {
					if ( $verbose ) {
						WP_MCP_AI_Logger::log_event(
							'gemini_run_with_tools_complete',
							'Completed without tool calls.',
							array( 'iterations' => $recursion_count )
						);
					}

					// Return final response.
					return $response;
				}

				// Add assistant's tool call message to conversation.
				$conversation_messages[] = $response['choices'][0]['message'];

				// Execute each tool call.
				foreach ( $tool_calls as $tool_call ) {
					if ( ! isset( $tool_call['function']['name'] ) ) {
						continue;
					}

					$function_name = $tool_call['function']['name'];
					$tool_call_id  = isset( $tool_call['id'] ) ? $tool_call['id'] : uniqid( 'tool-', true );

					// Check if function exists.
					if ( ! isset( $tool_functions[ $function_name ] ) ) {
						$error_message = sprintf(
							/* translators: %s: function name */
							__( 'Tool function "%s" not found.', 'nvdigital-open-operator-system-oos' ),
							$function_name
						);

						$conversation_messages[] = array(
							'role'         => 'tool',
							'tool_call_id' => $tool_call_id,
							'name'         => $function_name,
							'content'      => wp_json_encode( array( 'error' => $error_message ) ),
						);

						WP_MCP_AI_Logger::log_error(
							'Gemini tool function not found.',
							array(
								'function_name' => $function_name,
								'tool_call_id'  => $tool_call_id,
							)
						);
						continue;
					}

					// Parse arguments.
					$arguments = array();
					if ( isset( $tool_call['function']['arguments'] ) ) {
						$args_json = $tool_call['function']['arguments'];
						if ( is_string( $args_json ) ) {
							$arguments = json_decode( $args_json, true );
							if ( JSON_ERROR_NONE !== json_last_error() ) {
								$arguments = array();
							}
						} elseif ( is_array( $args_json ) ) {
							$arguments = $args_json;
						}
					}

					// Validate arguments if strict validation is enabled.
					if ( $strict_validation ) {
						$validation_error = $this->validate_tool_arguments( $function_name, $arguments, $tool_definitions );
						if ( is_wp_error( $validation_error ) ) {
							$conversation_messages[] = array(
								'role'         => 'tool',
								'tool_call_id' => $tool_call_id,
								'name'         => $function_name,
								'content'      => wp_json_encode( array( 'error' => $validation_error->get_error_message() ) ),
							);

							WP_MCP_AI_Logger::log_error(
								'Gemini tool argument validation failed.',
								array(
									'function_name' => $function_name,
									'error'         => $validation_error->get_error_message(),
								)
							);
							continue;
						}
					}

					// Execute the tool function.
					try {
						$function_callable = $tool_functions[ $function_name ];

						if ( ! is_callable( $function_callable ) ) {
							throw new Exception( 'Tool function is not callable.' );
						}

						$result = call_user_func( $function_callable, $arguments );

						// Convert result to JSON string.
						$result_content = is_string( $result ) ? $result : wp_json_encode( $result );

						$conversation_messages[] = array(
							'role'         => 'tool',
							'tool_call_id' => $tool_call_id,
							'name'         => $function_name,
							'content'      => $result_content,
						);

						if ( $verbose ) {
							WP_MCP_AI_Logger::log_event(
								'gemini_tool_executed',
								sprintf( 'Executed tool: %s', $function_name ),
								array(
									'function_name' => $function_name,
									'tool_call_id'  => $tool_call_id,
									'result_length' => strlen( $result_content ),
								)
							);
						}
					} catch ( Exception $e ) {
						$error_message = $e->getMessage();

						$conversation_messages[] = array(
							'role'         => 'tool',
							'tool_call_id' => $tool_call_id,
							'name'         => $function_name,
							'content'      => wp_json_encode( array( 'error' => $error_message ) ),
						);

						WP_MCP_AI_Logger::log_error(
							'Gemini tool execution failed.',
							array(
								'function_name' => $function_name,
								'error'         => $error_message,
							)
						);
					}
				}
			}

			// Max recursion reached.
			if ( $verbose ) {
				WP_MCP_AI_Logger::log_event(
					'gemini_max_recursion_reached',
					'Maximum recursive tool runs reached.',
					array( 'max_runs' => $max_recursive_runs )
				);
			}

			return new WP_Error(
				'wp_mcp_ai_max_tool_recursion',
				__( 'Maximum recursive tool runs reached without completion.', 'nvdigital-open-operator-system-oos' ),
				array(
					'status'         => 500,
					'max_runs'       => $max_recursive_runs,
					'final_messages' => $conversation_messages,
				)
			);
		}

		/**
		 * Validate tool arguments against the tool definition schema.
		 *
		 * @since 1.0.0
		 *
		 * @param string $function_name    Name of the function being called.
		 * @param array  $arguments        Arguments provided by the model.
		 * @param array  $tool_definitions Array of tool definitions.
		 * @return true|WP_Error True if valid, WP_Error otherwise.
		 */
		protected function validate_tool_arguments( $function_name, $arguments, $tool_definitions ) {
			// Find the tool definition.
			$tool_schema = null;
			foreach ( $tool_definitions as $tool_def ) {
				if ( isset( $tool_def['function']['name'] ) && $tool_def['function']['name'] === $function_name ) {
					$tool_schema = isset( $tool_def['function']['parameters'] ) ? $tool_def['function']['parameters'] : null;
					break;
				}
			}

			if ( null === $tool_schema ) {
				return true; // No schema to validate against.
			}

			// Check required parameters.
			if ( isset( $tool_schema['required'] ) && is_array( $tool_schema['required'] ) ) {
				foreach ( $tool_schema['required'] as $required_param ) {
					if ( ! isset( $arguments[ $required_param ] ) ) {
						return new WP_Error(
							'wp_mcp_ai_missing_required_param',
							sprintf(
								/* translators: %1$s: parameter name, %2$s: function name */
								__( 'Required parameter "%1$s" missing for tool "%2$s".', 'nvdigital-open-operator-system-oos' ),
								$required_param,
								$function_name
							),
							array( 'parameter' => $required_param )
						);
					}
				}
			}

			// Validate parameter types if schema includes type definitions.
			if ( isset( $tool_schema['properties'] ) && is_array( $tool_schema['properties'] ) ) {
				foreach ( $arguments as $param_name => $param_value ) {
					if ( ! isset( $tool_schema['properties'][ $param_name ] ) ) {
						// Ignore extra parameters (non-strict mode).
						continue;
					}

					$param_schema = $tool_schema['properties'][ $param_name ];
					if ( ! isset( $param_schema['type'] ) ) {
						continue;
					}

					$expected_type = $param_schema['type'];
					$actual_type   = gettype( $param_value );

					// Map PHP types to JSON Schema types.
					$type_map = array(
						'boolean' => 'boolean',
						'integer' => 'number',
						'double'  => 'number',
						'string'  => 'string',
						'array'   => 'array',
						'object'  => 'object',
						'NULL'    => 'null',
					);

					$mapped_type = isset( $type_map[ $actual_type ] ) ? $type_map[ $actual_type ] : $actual_type;

					// Allow integer for number type.
					if ( 'number' === $expected_type && in_array( $mapped_type, array( 'number', 'integer' ), true ) ) {
						continue;
					}

					if ( $expected_type !== $mapped_type ) {
						return new WP_Error(
							'wp_mcp_ai_invalid_param_type',
							sprintf(
								/* translators: %1$s: parameter name, %2$s: expected type, %3$s: actual type */
								__( 'Parameter "%1$s" expected type "%2$s" but got "%3$s".', 'nvdigital-open-operator-system-oos' ),
								$param_name,
								$expected_type,
								$mapped_type
							),
							array(
								'parameter'     => $param_name,
								'expected_type' => $expected_type,
								'actual_type'   => $mapped_type,
							)
						);
					}
				}
			}

			return true;
		}

		/**
		 * Automatically trim tools based on context to reduce token usage.
		 *
		 * @since 1.0.0
		 *
		 * @param array $messages Message history.
		 * @param array $tools    Array of tool definitions.
		 * @param array $options  Request options.
		 * @return array Trimmed tools array.
		 */
		protected function auto_trim_tools( $messages, $tools, $options = array() ) {
			// Get the last user message to determine relevance.
			$last_user_message = '';
			for ( $i = count( $messages ) - 1; $i >= 0; $i-- ) {
				if ( isset( $messages[ $i ]['role'] ) && 'user' === $messages[ $i ]['role'] ) {
					$last_user_message = isset( $messages[ $i ]['content'] ) ? strtolower( (string) $messages[ $i ]['content'] ) : '';
					break;
				}
			}

			if ( empty( $last_user_message ) || empty( $tools ) ) {
				return $tools;
			}

			// Score each tool based on relevance.
			$scored_tools = array();
			foreach ( $tools as $tool ) {
				$score = 0;

				// Check name relevance.
				if ( isset( $tool['name'] ) ) {
					$tool_name  = strtolower( str_replace( array( '-', '_' ), ' ', $tool['name'] ) );
					$name_words = explode( ' ', $tool_name );
					foreach ( $name_words as $word ) {
						if ( ! empty( $word ) && false !== strpos( $last_user_message, $word ) ) {
							$score += 3; // Higher weight for name match.
						}
					}
				}

				// Check description relevance.
				if ( isset( $tool['description'] ) ) {
					$tool_desc  = strtolower( $tool['description'] );
					$desc_words = explode( ' ', $tool_desc );
					foreach ( $desc_words as $word ) {
						if ( strlen( $word ) > 3 && false !== strpos( $last_user_message, $word ) ) {
							++$score;
						}
					}
				}

				$scored_tools[] = array(
					'tool'  => $tool,
					'score' => $score,
				);
			}

			// Sort by score (descending).
			usort(
				$scored_tools,
				function ( $a, $b ) {
					return $b['score'] - $a['score'];
				}
			);

			// Keep top tools (limit to maxTools option).
			$max_tools     = isset( $options['maxTools'] ) ? absint( $options['maxTools'] ) : 10;
			$trimmed_tools = array();

			foreach ( array_slice( $scored_tools, 0, $max_tools ) as $scored ) {
				// Only include tools with a relevance score.
				if ( $scored['score'] > 0 || count( $trimmed_tools ) < 3 ) {
					// Always keep at least 3 tools even if score is 0.
					$trimmed_tools[] = $scored['tool'];
				}
			}

			// If no tools passed the relevance test, keep all original tools.
			if ( empty( $trimmed_tools ) ) {
				return $tools;
			}

			return $trimmed_tools;
		}

		/**
		 * Build a common set of request args for Gemini Corpus API calls.
		 *
		 * @param string $method  HTTP method ('GET', 'POST', 'DELETE').
		 * @param int    $timeout Request timeout in seconds.
		 * @param mixed  $body    Payload to JSON-encode (omit for GET/DELETE).
		 * @return array|WP_Error
		 */
		protected function build_corpus_request_args( $method, $timeout, $body = null ) {
			$api_key = $this->get_api_key();

			if ( empty( $api_key ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_gemini_api_key',
					__( 'No Gemini API key has been configured.', 'nvdigital-open-operator-system-oos' ),
					array(
						'status'  => 400,
						'actions' => array(
							'configure_gemini_api_key' => __( 'Add a Gemini API key in the NV oOS settings.', 'nvdigital-open-operator-system-oos' ),
						),
					)
				);
			}

			$args = array(
				'method'  => $method,
				'headers' => $this->build_request_headers( $api_key ),
				'timeout' => max( 5, $timeout ),
			);

			if ( null !== $body ) {
				$encoded = wp_json_encode( $body );
				if ( false === $encoded ) {
					return new WP_Error( 'wp_mcp_ai_encoding_error', __( 'Failed to encode the request payload.', 'nvdigital-open-operator-system-oos' ) );
				}
				$args['body'] = $encoded;
			}

			return $args;
		}

		/**
		 * Create a new Gemini corpus.
		 *
		 * @param string $display_name Human-readable display name for the corpus.
		 * @param array  $options      Optional parameters (timeout).
		 * @return array|WP_Error Created corpus object or error.
		 */
		public function create_corpus( $display_name, array $options = array() ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$timeout  = isset( $options['timeout'] ) ? absint( $options['timeout'] ) : absint( $settings['request_timeout'] );

			$display_name = sanitize_text_field( $display_name );
			if ( empty( $display_name ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_display_name',
					__( 'A display name is required to create a Gemini corpus.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			$request_args = $this->build_corpus_request_args( 'POST', $timeout, array( 'display_name' => $display_name ) );
			if ( is_wp_error( $request_args ) ) {
				return $request_args;
			}

			WP_MCP_AI_Logger::log_event( 'gemini_corpus_create', 'Creating Gemini corpus.', array( 'display_name' => $display_name ) );

			$response = wp_remote_post( $this->resolve_endpoint( self::API_CORPORA_ENDPOINT ), $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_event( 'gemini_corpus_create_error', 'Gemini corpus creation failed.', array( 'error' => $response->get_error_message() ) );
				return $response;
			}

			$http_code     = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );
			$decoded       = json_decode( $response_body, true );

			if ( 200 !== $http_code ) {
				$error_message = __( 'Gemini corpus creation failed.', 'nvdigital-open-operator-system-oos' );
				if ( isset( $decoded['error']['message'] ) ) {
					$error_message = sanitize_text_field( $decoded['error']['message'] );
				}
				WP_MCP_AI_Logger::log_event( 'gemini_corpus_create_error', 'Gemini corpus creation failed with HTTP code ' . $http_code, array( 'response' => $decoded ) );
				return new WP_Error( 'wp_mcp_ai_gemini_corpus_error', $error_message, array( 'status' => $http_code ) );
			}

			WP_MCP_AI_Logger::log_event( 'gemini_corpus_create_success', 'Gemini corpus created successfully.' );
			return $decoded;
		}

		/**
		 * List Gemini corpora.
		 *
		 * @param array $options Optional parameters (page_size, page_token, timeout).
		 * @return array|WP_Error List of corpora or error.
		 */
		public function list_corpora( array $options = array() ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$timeout  = isset( $options['timeout'] ) ? absint( $options['timeout'] ) : absint( $settings['request_timeout'] );

			$request_args = $this->build_corpus_request_args( 'GET', $timeout );
			if ( is_wp_error( $request_args ) ) {
				return $request_args;
			}

			$query_args = array();
			if ( ! empty( $options['page_size'] ) ) {
				$query_args['pageSize'] = absint( $options['page_size'] );
			}
			if ( ! empty( $options['page_token'] ) ) {
				$query_args['pageToken'] = sanitize_text_field( $options['page_token'] );
			}

			$endpoint = $this->resolve_endpoint( self::API_CORPORA_ENDPOINT );
			if ( ! empty( $query_args ) ) {
				$endpoint = add_query_arg( $query_args, $endpoint );
			}

			$response = wp_remote_get( $endpoint, $request_args );

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$http_code     = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );
			$decoded       = json_decode( $response_body, true );

			if ( 200 !== $http_code ) {
				$error_message = __( 'Failed to retrieve Gemini corpora list.', 'nvdigital-open-operator-system-oos' );
				if ( isset( $decoded['error']['message'] ) ) {
					$error_message = sanitize_text_field( $decoded['error']['message'] );
				}
				return new WP_Error( 'wp_mcp_ai_gemini_corpus_error', $error_message, array( 'status' => $http_code ) );
			}

			return $decoded;
		}

		/**
		 * Retrieve a single Gemini corpus by name.
		 *
		 * @param string $corpus_name Resource name of the corpus (e.g. "corpora/my-corpus").
		 * @param array  $options     Optional parameters (timeout).
		 * @return array|WP_Error Corpus object or error.
		 */
		public function get_corpus( $corpus_name, array $options = array() ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$timeout  = isset( $options['timeout'] ) ? absint( $options['timeout'] ) : absint( $settings['request_timeout'] );

			$corpus_name = sanitize_text_field( $corpus_name );
			if ( empty( $corpus_name ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_corpus_name',
					__( 'A corpus name is required.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			// Accept bare IDs as well as full resource names.
			if ( 0 !== strpos( $corpus_name, 'corpora/' ) ) {
				$corpus_name = 'corpora/' . $corpus_name;
			}

			$request_args = $this->build_corpus_request_args( 'GET', $timeout );
			if ( is_wp_error( $request_args ) ) {
				return $request_args;
			}

			$endpoint = $this->resolve_endpoint( self::API_BASE_URL . $corpus_name );
			$response = wp_remote_get( $endpoint, $request_args );

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$http_code     = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );
			$decoded       = json_decode( $response_body, true );

			if ( 200 !== $http_code ) {
				$error_message = __( 'Failed to retrieve Gemini corpus.', 'nvdigital-open-operator-system-oos' );
				if ( isset( $decoded['error']['message'] ) ) {
					$error_message = sanitize_text_field( $decoded['error']['message'] );
				}
				return new WP_Error( 'wp_mcp_ai_gemini_corpus_error', $error_message, array( 'status' => $http_code ) );
			}

			return $decoded;
		}

		/**
		 * Delete a Gemini corpus.
		 *
		 * @param string $corpus_name Resource name of the corpus (e.g. "corpora/my-corpus").
		 * @param array  $options     Optional parameters (timeout, force — delete non-empty corpus).
		 * @return true|WP_Error True on success or error.
		 */
		public function delete_corpus( $corpus_name, array $options = array() ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$timeout  = isset( $options['timeout'] ) ? absint( $options['timeout'] ) : absint( $settings['request_timeout'] );

			$corpus_name = sanitize_text_field( $corpus_name );
			if ( empty( $corpus_name ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_corpus_name',
					__( 'A corpus name is required.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			if ( 0 !== strpos( $corpus_name, 'corpora/' ) ) {
				$corpus_name = 'corpora/' . $corpus_name;
			}

			$request_args = $this->build_corpus_request_args( 'DELETE', $timeout );
			if ( is_wp_error( $request_args ) ) {
				return $request_args;
			}

			$endpoint = $this->resolve_endpoint( self::API_BASE_URL . $corpus_name );
			if ( ! empty( $options['force'] ) ) {
				$endpoint = add_query_arg( 'force', 'true', $endpoint );
			}

			WP_MCP_AI_Logger::log_event( 'gemini_corpus_delete', 'Deleting Gemini corpus.', array( 'corpus_name' => $corpus_name ) );

			$response = wp_remote_request( $endpoint, $request_args );

			if ( is_wp_error( $response ) ) {
				WP_MCP_AI_Logger::log_event( 'gemini_corpus_delete_error', 'Gemini corpus deletion failed.', array( 'error' => $response->get_error_message() ) );
				return $response;
			}

			$http_code     = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );

			if ( 200 !== $http_code ) {
				$decoded       = json_decode( $response_body, true );
				$error_message = __( 'Failed to delete Gemini corpus.', 'nvdigital-open-operator-system-oos' );
				if ( isset( $decoded['error']['message'] ) ) {
					$error_message = sanitize_text_field( $decoded['error']['message'] );
				}
				WP_MCP_AI_Logger::log_event( 'gemini_corpus_delete_error', 'Gemini corpus deletion failed with HTTP code ' . $http_code );
				return new WP_Error( 'wp_mcp_ai_gemini_corpus_error', $error_message, array( 'status' => $http_code ) );
			}

			WP_MCP_AI_Logger::log_event( 'gemini_corpus_delete_success', 'Gemini corpus deleted successfully.' );
			return true;
		}

		/**
		 * Query a Gemini corpus directly using the Semantic Retrieval API.
		 *
		 * This method performs a direct relevance-based query against a corpus without
		 * going through a full generateContent request.  Useful for testing retrieval
		 * or pre-fetching context chunks.
		 *
		 * @param string $corpus_name Resource name of the corpus (e.g. "corpora/my-corpus").
		 * @param string $query       Natural-language query string.
		 * @param array  $options     Optional parameters (results_count, metadata_filters, timeout).
		 * @return array|WP_Error Query results or error.
		 */
		public function query_corpus( $corpus_name, $query, array $options = array() ) {
			$settings = WP_MCP_AI_Admin_Settings::get_settings();
			$timeout  = isset( $options['timeout'] ) ? absint( $options['timeout'] ) : absint( $settings['request_timeout'] );

			$corpus_name = sanitize_text_field( $corpus_name );
			if ( empty( $corpus_name ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_corpus_name',
					__( 'A corpus name is required.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			$query = sanitize_text_field( $query );
			if ( empty( $query ) ) {
				return new WP_Error(
					'wp_mcp_ai_missing_query',
					__( 'A query string is required.', 'nvdigital-open-operator-system-oos' ),
					array( 'status' => 400 )
				);
			}

			if ( 0 !== strpos( $corpus_name, 'corpora/' ) ) {
				$corpus_name = 'corpora/' . $corpus_name;
			}

			$body = array(
				'query' => array(
					'parts' => array(
						array( 'text' => $query ),
					),
				),
			);

			if ( ! empty( $options['results_count'] ) ) {
				$body['resultsCount'] = absint( $options['results_count'] );
			}

			if ( ! empty( $options['metadata_filters'] ) && is_array( $options['metadata_filters'] ) ) {
				$body['metadataFilters'] = $options['metadata_filters'];
			}

			$request_args = $this->build_corpus_request_args( 'POST', $timeout, $body );
			if ( is_wp_error( $request_args ) ) {
				return $request_args;
			}

			$endpoint = $this->resolve_endpoint( self::API_BASE_URL . $corpus_name . ':query' );
			$response = wp_remote_post( $endpoint, $request_args );

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$http_code     = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );
			$decoded       = json_decode( $response_body, true );

			if ( 200 !== $http_code ) {
				$error_message = __( 'Gemini corpus query failed.', 'nvdigital-open-operator-system-oos' );
				if ( isset( $decoded['error']['message'] ) ) {
					$error_message = sanitize_text_field( $decoded['error']['message'] );
				}
				return new WP_Error( 'wp_mcp_ai_gemini_corpus_error', $error_message, array( 'status' => $http_code ) );
			}

			return $decoded;
		}
	}
}
