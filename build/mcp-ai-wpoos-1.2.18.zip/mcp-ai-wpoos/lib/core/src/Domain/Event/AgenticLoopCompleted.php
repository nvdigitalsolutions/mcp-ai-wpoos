<?php
/**
 * Fired after the full agentic loop finishes (all iterations done).
 *
 * Replaces: do_action('wp_mcp_ai_agentic_loop_completed', ...)
 *
 * @package Nvoos\Core
 * @since   1.0.0
 * @license MIT
 */

declare(strict_types=1);

namespace Nvoos\Core\Domain\Event;

final class AgenticLoopCompleted {

	/**
	 * @param array<int, array<string, mixed>> $toolResults
	 */
	public function __construct(
		public readonly int $totalIterations,
		public readonly int $assistantId,
		public readonly array $toolResults,
		public readonly bool $limitReached,
	) {}
}
