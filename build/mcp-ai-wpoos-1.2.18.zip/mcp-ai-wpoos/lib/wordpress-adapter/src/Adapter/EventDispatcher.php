<?php
/**
 * WordPress adapter: EventDispatcherInterface implementation.
 *
 * Wraps WordPress action hooks (do_action) and filter hooks (apply_filters)
 * behind the framework-agnostic, domain-owned EventDispatcherInterface.
 *
 * This adapter bridges two worlds:
 *  - Core dispatch()  → WordPress do_action
 *  - Core filter()    → WordPress apply_filters
 *  - Existing WP hooks (wp_mcp_ai_*) continue to work alongside both.
 *
 * @package Nvoos\WordPress
 * @since   1.0.0
 * @license GPL-3.0-or-later
 */

declare(strict_types=1);

namespace Nvoos\WordPress\Adapter;

use Nvoos\Core\Domain\Contract\EventDispatcherInterface;
use Nvoos\Core\Domain\Contract\WaterfallEventDispatcherInterface;
use Nvoos\Core\Domain\Event\WaterfallChain;

class EventDispatcher implements EventDispatcherInterface, WaterfallEventDispatcherInterface {

	/**
	 * Map of domain event class names to WordPress hook names.
	 *
	 * Translates domain event classes to the wp_mcp_ai_* hook names
	 * that existing subscribers listen on.
	 *
	 * @var array<class-string, string>
	 */
	private array $eventHookMap = array();

	/**
	 * Registered domain listeners keyed by event class name.
	 *
	 * @var array<class-string, array<int, callable[]>>
	 */
	private array $listeners = array();

	/**
	 * Registered filter listeners keyed by event name.
	 *
	 * @var array<string, array<int, callable[]>>
	 */
	private array $filters = array();

	/**
	 * Registered waterfall listeners keyed by event name.
	 *
	 * @var array<string, array<int, callable[]>>
	 */
	private array $waterfalls = array();

	/**
	 * Registered serial listeners keyed by event name.
	 *
	 * @var array<string, array<int, callable[]>>
	 */
	private array $serials = array();

	/**
	 * Map a domain event class to a WordPress hook name.
	 *
	 * Events of this class are dispatched through the given WordPress hook
	 * (via do_action) in addition to PSR-14 listeners.
	 */
	public function mapEventToHook( string $eventClass, string $hookName ): void {
		$this->eventHookMap[ $eventClass ] = $hookName;
	}

	public function dispatch( object $event ): object {
		$eventClass = \get_class( $event );

		// 1. Notify registered domain listeners.
		if ( isset( $this->listeners[ $eventClass ] ) ) {
			foreach ( $this->getSortedCallbacks( $this->listeners[ $eventClass ] ) as $listener ) {
				$listener( $event );
			}
		}

		// 2. Fire the WordPress action hook for backward compatibility.
		$hookName = $this->eventHookMap[ $eventClass ] ?? null;
		if ( null !== $hookName && \has_action( $hookName ) ) {
			\do_action( $hookName, ...$this->legacyArgsFor( $event ) );
		}

		return $event;
	}

	/**
	 * Translate a domain event into the legacy wp_mcp_ai_* argument tuple.
	 *
	 * Existing WordPress subscribers register against the documented legacy
	 * shapes (e.g. `wp_mcp_ai_after_chat_response( $assistant_id, $response,
	 * $request )`), so firing the hook with the raw event object breaks every
	 * subscriber that declares required parameters. Known chat/tool lifecycle
	 * events are translated to their legacy shapes; unknown events keep the
	 * single-event shape.
	 *
	 * @param object $event Domain event instance.
	 * @return array<int, mixed> Legacy hook arguments.
	 */
	private function legacyArgsFor( object $event ): array {
		if ( $event instanceof \Nvoos\Core\Domain\Event\BeforeChatRequest ) {
			return array( $event->assistantId, $event->messages, $event->options, null );
		}

		if ( $event instanceof \Nvoos\Core\Domain\Event\AfterChatResponse ) {
			return array( $event->assistantId, $event->response, null );
		}

		if ( $event instanceof \Nvoos\Core\Domain\Event\BeforeToolExecution ) {
			return array( $event->toolSlug, $event->arguments, $event->context );
		}

		if ( $event instanceof \Nvoos\Core\Domain\Event\AfterToolExecution ) {
			return array( $event->toolSlug, $event->arguments, $event->context, $event->result );
		}

		return array( $event );
	}

	public function filter( string $eventName, mixed $value, mixed ...$args ): mixed {
		// 1. Run registered core filter listeners.
		if ( isset( $this->filters[ $eventName ] ) ) {
			foreach ( $this->getSortedCallbacks( $this->filters[ $eventName ] ) as $filter ) {
				$value = $filter( $value, ...$args );
			}
		}

		// 2. Run WordPress apply_filters for backward compatibility.
		if ( \has_filter( $eventName ) ) {
			$value = \apply_filters( $eventName, $value, ...$args );
		}

		return $value;
	}

	public function listen( string $eventName, callable $listener, int $priority = 10 ): void {
		// If the event name matches a WordPress hook, register on both sides.
		if ( $this->isWordPressHook( $eventName ) ) {
			\add_action( $eventName, $listener, $priority, 99 );
		}

		// Domain listener registration (keyed by event class name).
		if ( \class_exists( $eventName ) || \interface_exists( $eventName ) ) {
			$this->listeners[ $eventName ][ $priority ][] = $listener;
			return;
		}

		// Generic event name — store as a plain listener.
		$this->listeners[ $eventName ][ $priority ][] = $listener;
	}

	public function listenFilter( string $eventName, callable $filter, int $priority = 10 ): void {
		// Register with WordPress filter system for backward compatibility.
		if ( $this->isWordPressHook( $eventName ) ) {
			\add_filter( $eventName, $filter, $priority, 99 );
		}

		$this->filters[ $eventName ][ $priority ][] = $filter;
	}

	public function listenWaterfall( string $eventName, callable $listener, int $priority = 10 ): void {
		$this->waterfalls[ $eventName ][ $priority ][] = $listener;
	}

	public function waterfall( string $eventName, object $event, callable $final ): mixed {
		$listeners = $this->getSortedCallbacks( $this->waterfalls[ $eventName ] ?? array() );

		return WaterfallChain::build( $listeners, $final )( $event );
	}

	public function listenSerial( string $eventName, callable $listener, int $priority = 10 ): void {
		$this->serials[ $eventName ][ $priority ][] = $listener;
	}

	public function serial( string $eventName, object $event ): void {
		foreach ( $this->getSortedCallbacks( $this->serials[ $eventName ] ?? array() ) as $listener ) {
			$listener( $event );
		}
	}

	public function removeListener( string $eventName, callable $listener ): bool {
		$removed = false;

		// Remove from waterfall listeners.
		if ( isset( $this->waterfalls[ $eventName ] ) ) {
			foreach ( $this->waterfalls[ $eventName ] as $priority => &$callbacks ) {
				foreach ( $callbacks as $index => $registered ) {
					if ( $registered === $listener ) {
						unset( $callbacks[ $index ] );
						$removed = true;
					}
				}
			}
		}

		// Remove from serial listeners.
		if ( isset( $this->serials[ $eventName ] ) ) {
			foreach ( $this->serials[ $eventName ] as $priority => &$callbacks ) {
				foreach ( $callbacks as $index => $registered ) {
					if ( $registered === $listener ) {
						unset( $callbacks[ $index ] );
						$removed = true;
					}
				}
			}
		}

		// Remove from WordPress hooks.
		if ( $this->isWordPressHook( $eventName ) ) {
			$removed = \remove_action( $eventName, $listener ) || \remove_filter( $eventName, $listener );
		}

		// Remove from domain listeners.
		if ( isset( $this->listeners[ $eventName ] ) ) {
			foreach ( $this->listeners[ $eventName ] as $priority => &$callbacks ) {
				foreach ( $callbacks as $index => $registered ) {
					if ( $registered === $listener ) {
						unset( $callbacks[ $index ] );
						$removed = true;
					}
				}
			}
		}

		// Remove from filters.
		if ( isset( $this->filters[ $eventName ] ) ) {
			foreach ( $this->filters[ $eventName ] as $priority => &$callbacks ) {
				foreach ( $callbacks as $index => $registered ) {
					if ( $registered === $listener ) {
						unset( $callbacks[ $index ] );
						$removed = true;
					}
				}
			}
		}

		return $removed;
	}

	/**
	 * Whether the given name matches an existing WordPress hook pattern.
	 */
	private function isWordPressHook( string $name ): bool {
		// WordPress hooks use the wp_mcp_ai_ prefix or common WP patterns.
		return \str_starts_with( $name, 'wp_mcp_ai_' )
			|| \str_starts_with( $name, 'pre_' )
			|| \str_starts_with( $name, 'rest_' );
	}

	/**
	 * Sort callbacks by priority (descending — highest first, WP convention).
	 *
	 * @param array<int, callable[]> $priorityMap
	 * @return callable[]
	 */
	private function getSortedCallbacks( array $priorityMap ): array {
		\krsort( $priorityMap, \SORT_NUMERIC );

		$sorted = array();
		foreach ( $priorityMap as $callbacks ) {
			foreach ( $callbacks as $callback ) {
				$sorted[] = $callback;
			}
		}

		return $sorted;
	}
}
