<?php
/**
 * Tool for checking workflow health status.
 *
 * Allows AI assistants to check if workflows are stuck in initialized state
 * and get recommendations for fixing workflow issues.
 *
 * @package WP_MCP_AI
 * @since 1.1.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Check health status of team workflows.
 *
 * This tool helps diagnose workflows that are stuck in initialized state,
 * which is common in WordPress plugins where workflows may be waiting for
 * cron execution or async processing.
 *
 * @since 1.1.0
 */
class WP_MCP_AI_Tool_Check_Workflow_Health implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Chat_Response;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'check_workflow_health';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Check Workflow Health', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Checks the health status of workflows to detect if they are stuck in initialized state. Provides recommendations for fixing workflow issues. Important for WordPress plugins where workflows may wait for cron/async processing.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Diagnosing workflows stuck in initialized state or verifying overall workflow health before execution.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Running or linting workflow logic; use execute_workflow to run and validate_workflow to check definitions.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'execute_workflow', 'validate_workflow' ),
			'notes'           => __( 'Optional workflow_id scopes the check to one workflow; omit it to check all active workflows.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'workflow_id' => array(
					'type'        => 'string',
					'description' => __( 'Optional workflow ID to check. If not provided, checks all active workflows.', 'nvdigital-open-operator-system-oos' ),
				),
			),
			'additionalProperties' => false,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array Tool results.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		// Check if orchestrator is available.
		if ( ! class_exists( 'WP_MCP_AI_Agent_Team_Orchestrator' ) ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'Agent orchestration system not available.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$orchestrator = new WP_MCP_AI_Agent_Team_Orchestrator();

		// If workflow_id is provided, check specific workflow.
		if ( ! empty( $arguments['workflow_id'] ) ) {
			$workflow_id = sanitize_text_field( $arguments['workflow_id'] );
			$health      = $orchestrator->check_workflow_health( $workflow_id );

			if ( 'error' === $health['status'] ) {
				return new WP_Error(
					'wp_mcp_ai_error',
					$health['message']
				);
			}

			return array(
				'success' => true,
				'message' => __( 'Workflow health check completed.', 'nvdigital-open-operator-system-oos' ),
				'health'  => $health,
			);
		}

		// Check all workflows using enhanced coordinator if available.
		if ( class_exists( 'WP_MCP_AI_Enhanced_Workflow_Coordinator' ) ) {
			$coordinator = new WP_MCP_AI_Enhanced_Workflow_Coordinator();
			$health      = $coordinator->get_workflows_health();

			$message = 'healthy' === $health['status']
				? __( 'All workflows are healthy.', 'nvdigital-open-operator-system-oos' )
				: __( 'Some workflows require attention.', 'nvdigital-open-operator-system-oos' );

			return array(
				'success' => true,
				'message' => $message,
				'health'  => $health,
			);
		}

		return new WP_Error(
			'wp_mcp_ai_error',
			__( 'Enhanced workflow coordinator not available.', 'nvdigital-open-operator-system-oos' )
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'workflow_automation',

			'pattern_compatibility' => array( 'hierarchical' ),

			'profession_tags'       => array( 'project_manager', 'devops_engineer' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'read-only',           // Read-only operation.
			'local-only',          // No external API calls.
			'idempotent',          // Can be called multiple times safely.
			'requires-capability', // Needs user authentication.
		);
	}
}
