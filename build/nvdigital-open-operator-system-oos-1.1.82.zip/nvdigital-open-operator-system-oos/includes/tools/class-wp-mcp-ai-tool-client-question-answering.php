<?php
/**
 * Tool that answers questions using browser-native Transformers.js
 *
 * @package WP_MCP_AI
 * @since 1.2.0
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WP_MCP_AI_PATH . 'includes/interfaces/interface-wp-mcp-ai-tool.php';
require_once WP_MCP_AI_PATH . 'includes/tools/trait-wp-mcp-ai-tool-restrict-from-chat-client.php';

/**
 * Browser-native question answering tool
 *
 * Uses Transformers.js to extract answers from context documents.
 *
 * @since 1.2.0
 */
class WP_MCP_AI_Tool_Client_Question_Answering implements WP_MCP_AI_Tool_Interface, WP_MCP_AI_Tool_Capability_Flags_Interface, WP_MCP_AI_Tool_Usage_Guidance_Interface {
	use WP_MCP_AI_Tool_Restrict_From_Chat_Client;

	/**
	 * {@inheritdoc}
	 */
	public function get_slug() {
		return 'client_question_answering';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name() {
		return __( 'Browser Question Answering', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_description() {
		return __( 'Extract answers to questions from provided context using browser-native AI. Processes instantly without server round-trip.', 'nvdigital-open-operator-system-oos' );
	}

	/**
	 * Get usage guidance for the tool.
	 *
	 * @return array
	 */
	public function get_usage_guidance() {
		return array(
			'when_to_use'     => __( 'Answering a specific question from a provided context passage entirely in the browser.', 'nvdigital-open-operator-system-oos' ),
			'when_not_to_use' => __( 'Finding relevant documents across a corpus; use client_semantic_search or semantic_content_search first.', 'nvdigital-open-operator-system-oos' ),
			'related_tools'   => array( 'client_semantic_search', 'client_extract_entities', 'client_summarize_text' ),
			'notes'           => __( 'Requires both question and context parameters. Client-side only; browser-native AI must be enabled.', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_parameters_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'question' => array(
					'type'        => 'string',
					'description' => __( 'The question to answer.', 'nvdigital-open-operator-system-oos' ),
				),
				'context'  => array(
					'type'        => 'string',
					'description' => __( 'The context document containing the answer to the question.', 'nvdigital-open-operator-system-oos' ),
				),
			),
			'required'             => array( 'question', 'context' ),
			'additionalProperties' => false,
		);
	}


	/**

	 * Get extended tool definition including toolkit metadata.
	 *
	 * @since 1.1.0
	 *
	 * @return array Tool definition with metadata.
	 */
	public function get_definition() {

		return array(

			'name'                  => $this->get_name(),

			'description'           => $this->get_description(),

			'toolkit'               => 'research_discovery',

			'pattern_compatibility' => array( 'orchestrator' ),

			'profession_tags'       => array( 'researcher', 'analyst' ),

			'risk_level'            => 'info',

		);
	}


	/**
	 * {@inheritdoc}
	 */
	public function get_capability_flags() {
		return array(
			'external-api'    => false,
			'consumes-tokens' => false,
			'read-only'       => true,
			'client-side'     => true,
			'offline'         => true,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_required_capability() {
		return 'edit_posts';
	}

	/**
	 * Execute the tool.
	 *
	 * @param array $arguments Tool arguments.
	 * @param array $context   Execution context.
	 * @return array Tool execution result.
	 */
	public function execute( array $arguments = array(), array $context = array() ) {
		if ( ! class_exists( 'WP_MCP_AI_Transformers_Enqueue' ) ||
			! WP_MCP_AI_Transformers_Enqueue::is_transformers_enabled() ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'Browser-native AI tasks are not enabled.', 'nvdigital-open-operator-system-oos' )
			);
		}

		$question = isset( $arguments['question'] ) ? $arguments['question'] : '';
		$ctx      = isset( $arguments['context'] ) ? $arguments['context'] : '';

		if ( empty( $question ) || empty( $ctx ) ) {
			return new WP_Error(
				'wp_mcp_ai_error',
				__( 'Both question and context parameters are required.', 'nvdigital-open-operator-system-oos' )
			);
		}

		return array(
			'success'           => true,
			'client_executable' => true,
			'client_method'     => 'questionAnswering',
			'client_arguments'  => array(
				'question' => $question,
				'context'  => $ctx,
			),
			'message'           => __( 'Finding answer in browser...', 'nvdigital-open-operator-system-oos' ),
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function should_exclude_from_client() {
		return true;
	}
}
