<?php
/**
 * JetEngine Custom Content Type registration for AI Peers.
 *
 * @package WP_MCP_AI
 * @author    NV Digital Solutions
 * @copyright Copyright (c) 2025-2026 NV Digital Solutions
 * @license   GPL-3.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ensure the AI Peers CCT exists and expose helper accessors.
 */
class WP_MCP_AI_JetEngine_AI_Peers_CCT {
	const SLUG = 'ai_peers';

	/**
	 * Base ID for meta field identifiers.
	 * Using 21000 range to avoid conflicts with other CCT fields.
	 */
	const FIELD_ID_BASE = 21000;

	/**
	 * Hook into JetEngine to provision the ai_peers content type.
	 */
	public static function bootstrap() {
		// Run after JetEngine initialises the Custom Content Types module but before.
		// the manager registers existing instances (priority 10).
		add_action( 'init', array( __CLASS__, 'maybe_register_cct' ), 0 );

		// Ensure data stores module is enabled when JetEngine is active.
		add_action( 'init', array( __CLASS__, 'maybe_enable_data_stores' ), 0 );
	}

	/**
	 * Retrieve the ai_peers CCT slug.
	 *
	 * @return string
	 */
	public static function get_slug() {
		return self::SLUG;
	}

	/**
	 * Retrieve the JetEngine item handler for the ai_peers content type.
	 *
	 * Consumers can use the returned handler similarly to `jet_engine()->cct->item_handler`
	 * when interacting with the ai_peers records programmatically.
	 *
	 * @return object|null
	 */
	public static function get_item_handler() {
		$module = self::get_cct_module();

		if ( ! $module ) {
			return null;
		}

		if ( empty( $module->manager ) ) {
			return null;
		}

		$instance = $module->manager->get_content_types( self::SLUG );

		if ( ! $instance ) {
			return null;
		}

		return $instance->get_item_handler();
	}

	/**
	 * Automatically enable the JetEngine data stores module if it's not already active.
	 */
	public static function maybe_enable_data_stores() {
		if ( ! function_exists( 'jet_engine' ) ) {
			return;
		}

		$engine = jet_engine();

		if ( empty( $engine->modules ) || ! method_exists( $engine->modules, 'is_module_active' ) ) {
			return;
		}

		// Check if data stores module is already active.
		if ( $engine->modules->is_module_active( 'data-stores' ) ) {
			return;
		}

		// Check if the module exists.
		if ( ! method_exists( $engine->modules, 'get_module' ) ) {
			return;
		}

		$module = $engine->modules->get_module( 'data-stores' );

		if ( ! $module ) {
			return;
		}

		// Activate the data stores module.
		if ( method_exists( $engine->modules, 'activate_module' ) ) {
			$engine->modules->activate_module( 'data-stores' );
		}
	}

	/**
	 * Register the ai_peers CCT if it is missing.
	 */
	public static function maybe_register_cct() {
		$module = self::get_cct_module();

		if ( ! $module ) {
			return;
		}

		if ( empty( $module->manager ) || empty( $module->manager->data ) ) {
			return;
		}

		if ( self::cct_exists( $module ) ) {
			return;
		}

		$data    = $module->manager->data;
		$request = self::get_registration_request();

		$data->set_request( $request );

		if ( method_exists( $data, 'sanitize_item_request' ) && ! $data->sanitize_item_request() ) {
			return;
		}

		$item = $data->sanitize_item_from_request();

		if ( empty( $item ) || ! is_array( $item ) ) {
			return;
		}

		$data->before_item_update( $item, true );

		$item_id = $data->update_item_in_db( $item );

		if ( ! $item_id ) {
			return;
		}

		$item['id'] = $item_id;

		$data->after_item_update( $item, true );

		// Refresh JetEngine's internal cache of custom post types.
		// The 'post_types' query forces JetEngine to reload the CCT definitions,.
		// ensuring the newly registered CCT is immediately available.
		if ( ! empty( $data->db ) && method_exists( $data->db, 'query_raw' ) ) {
			$data->db->query_raw( 'post_types' );
		}
	}

	/**
	 * Determine whether the ai_peers CCT already exists.
	 *
	 * @param \Jet_Engine\Modules\Custom_Content_Types\Module $module Module instance.
	 * @return bool
	 */
	protected static function cct_exists( $module ) {
		$data = $module->manager->data;

		if ( empty( $data->db ) ) {
			return false;
		}

		$records = $data->db->query(
			'post_types',
			array(
				'slug'   => self::SLUG,
				'status' => 'content-type',
			),
			null,
			false
		);

		return ! empty( $records );
	}

	/**
	 * Retrieve the JetEngine Custom Content Types module instance.
	 *
	 * @return \Jet_Engine\Modules\Custom_Content_Types\Module|null
	 */
	protected static function get_cct_module() {
		if ( ! function_exists( 'jet_engine' ) ) {
			return null;
		}

		$engine = jet_engine();

		if ( empty( $engine->modules ) || ! method_exists( $engine->modules, 'is_module_active' ) ) {
			return null;
		}

		if ( ! $engine->modules->is_module_active( 'custom-content-types' ) ) {
			return null;
		}

		$module_wrapper = $engine->modules->get_module( 'custom-content-types' );

		if ( empty( $module_wrapper ) || empty( $module_wrapper->instance ) ) {
			return null;
		}

		return $module_wrapper->instance;
	}

	/**
	 * Build the request payload used to register the content type.
	 *
	 * @return array
	 */
	protected static function get_registration_request() {
		$label = __( 'AI Peers', 'mcp-ai-wpoos' );

		return array(
			'name'        => $label,
			'slug'        => self::SLUG,
			'args'        => self::get_cct_args( $label ),
			'meta_fields' => self::get_meta_fields(),
		);
	}

	/**
	 * Assemble the JetEngine arguments for the ai_peers CCT.
	 *
	 * @param string $label Human-readable label for the content type.
	 * @return array
	 */
	protected static function get_cct_args( $label ) {
		return array(
			'name'                => $label,
			'slug'                => self::SLUG,
			'position'            => '-1',
			'icon'                => 'dashicons-networking',
			'capability'          => 'manage_options',
			'has_single'          => false,
			'create_index'        => true,
			'hide_field_names'    => false,
			'rest_get_enabled'    => true,
			'rest_put_enabled'    => true,
			'rest_post_enabled'   => true,
			'rest_delete_enabled' => true,
			'rest_get_access'     => 'manage_options',
			'rest_put_access'     => 'manage_options',
			'rest_post_access'    => 'manage_options',
			'rest_delete_access'  => 'manage_options',
			'admin_columns'       => array(
				'_ID'           => array(
					'enabled'     => true,
					'prefix'      => '#',
					'is_sortable' => true,
					'is_num'      => true,
				),
				'site_name'     => array(
					'enabled'     => true,
					'is_sortable' => true,
				),
				'site_url'      => array(
					'enabled'     => true,
					'is_sortable' => false,
				),
				'health_status' => array(
					'enabled'     => true,
					'is_sortable' => true,
				),
				'latency_p50'   => array(
					'enabled'     => true,
					'is_sortable' => true,
				),
				'cct_created'   => array(
					'enabled'     => true,
					'is_sortable' => true,
				),
			),
		);
	}

	/**
	 * Define the ai_peers meta field configuration.
	 *
	 * @return array
	 */
	protected static function get_meta_fields() {
		$base_id = self::FIELD_ID_BASE;

		$fields = array(
			self::build_field(
				++$base_id,
				'site_name',
				__( 'Site Name', 'mcp-ai-wpoos' ),
				'text',
				array(
					'is_required' => true,
					'description' => __( 'Name of the peer site.', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'site_url',
				__( 'Site URL', 'mcp-ai-wpoos' ),
				'text',
				array(
					'description' => __( 'URL of the peer site.', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'mcp_url',
				__( 'MCP Endpoint', 'mcp-ai-wpoos' ),
				'text',
				array(
					'description' => __( 'MCP protocol endpoint URL.', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'jwks_uri',
				__( 'JWKS URI', 'mcp-ai-wpoos' ),
				'text',
				array(
					'description' => __( 'JSON Web Key Set URI for authentication.', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'capabilities',
				__( 'Capabilities', 'mcp-ai-wpoos' ),
				'textarea',
				array(
					'description' => __( 'JSON array of peer capabilities.', 'mcp-ai-wpoos' ),
					'rows'        => 4,
				)
			),
			self::build_field(
				++$base_id,
				'regions',
				__( 'Regions', 'mcp-ai-wpoos' ),
				'textarea',
				array(
					'description' => __( 'JSON array of supported regions.', 'mcp-ai-wpoos' ),
					'rows'        => 2,
				)
			),
			self::build_field(
				++$base_id,
				'data_tags',
				__( 'Data Tags', 'mcp-ai-wpoos' ),
				'textarea',
				array(
					'description' => __( 'JSON array of data policy tags.', 'mcp-ai-wpoos' ),
					'rows'        => 2,
				)
			),
			self::build_field(
				++$base_id,
				'health_status',
				__( 'Health Status', 'mcp-ai-wpoos' ),
				'text',
				array(
					'description' => __( 'Current health status (healthy, degraded, down).', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'latency_p50',
				__( 'Latency P50 (ms)', 'mcp-ai-wpoos' ),
				'number',
				array(
					'min'         => 0,
					'description' => __( 'P50 latency in milliseconds.', 'mcp-ai-wpoos' ),
				)
			),
			self::build_field(
				++$base_id,
				'last_verified',
				__( 'Last Verified', 'mcp-ai-wpoos' ),
				'text',
				array(
					'description' => __( 'Timestamp of last verification.', 'mcp-ai-wpoos' ),
				)
			),
		);

		foreach ( $fields as &$field ) {
			$field['show_in_rest'] = true;
		}

		return $fields;
	}

	/**
	 * Utility to construct a JetEngine meta field definition.
	 *
	 * @param int    $id        Deterministic field identifier.
	 * @param string $name      Field slug.
	 * @param string $label     Field label.
	 * @param string $type      JetEngine field type.
	 * @param array  $overrides Optional overrides for the base configuration.
	 * @return array
	 */
	protected static function build_field( $id, $name, $label, $type, $overrides = array() ) {
		$field = array(
			'id'          => absint( $id ),
			'name'        => sanitize_key( $name ),
			'title'       => $label,
			'object_type' => 'field',
			'type'        => $type,
			'width'       => '100%',
			'isNested'    => false,
			'options'     => array(),
		);

		return array_merge( $field, $overrides );
	}
}

WP_MCP_AI_JetEngine_AI_Peers_CCT::bootstrap();
